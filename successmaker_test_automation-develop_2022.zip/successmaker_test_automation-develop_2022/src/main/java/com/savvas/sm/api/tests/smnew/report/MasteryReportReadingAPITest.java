package com.savvas.sm.api.tests.smnew.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.smnew.report.model.ReportRequest;
import com.savvas.sm.api.tests.smnew.report.model.ReportResponse;
import com.savvas.sm.api.tests.smnew.users.CreateStudentAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.ReportAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetupProcessor;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

public class MasteryReportReadingAPITest extends UserAPI {
    String smUrl;
    Map<String, String> response;
    String orgId;
    String username;
    String userId;
    String groupId;
    String browser;
    List<ReportResponse> actualLst = new ArrayList<>();
    List<ReportResponse> lst = new ArrayList<>();
    HashMap<String, String> mathAssignmentDetails = new HashMap<>();
    HashMap<String, String> readingAssignmentDetails = new HashMap<>();
    static List<String> studentId = new ArrayList<>();
    String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String flexSchoolTeacherDetails;
    String orgID;
    String userID;
    String studentDetail;
    String studentUserID;
    String studentUsername;
    String teacherUsername;
    String password;
    String courseName;
    String courseId;
    String assignmentID;
    String assignmentUserId;
    boolean lastSessionValue;
    public String isItMt = "";
    String subject;
    RBSUtils rbsUtils = new RBSUtils();
    Map<String, String> assignmentResponse = new HashMap<>();
    HashMap<String, String> groupdetails = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();

    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void beforeTest() throws Exception {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        // Getting Teacher from flex School        
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        userID = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        // Getting ORGID of Flex school       
        orgID = RBSDataSetup.organizationIDs.get( flexSchool );
        // Getting Students from Flex school        
        studentDetail = RBSDataSetup.getMyStudent( flexSchool, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();

        // Create a custom course for the flex teacher 
        courseName = "CustomSettingCourse" + System.nanoTime();
        courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.READING, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_READING.json" );

        String accessToken = new RBSUtils().getAccessToken( teacherUsername, password );

        // Creating Group to add the student to assign assignment
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, userID );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgID );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );
        // Create Assignment and assign to a student HashMap<String, String>
        assignmentDetails = new HashMap<>();
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
        assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

        executeCourse( studentUsername, courseName, false, "100", "3", "8" );

    }

    @Test ( dataProvider = "getData", groups = { "smoke_test_case", "SMK-68779", "Mastery Report API Test", "API", "P1" }, priority = 1 )
    public void testMasteryRepostAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> params = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );

        //Test Data
        String authorization = "Basic YWRtaW50ZXN0OnRlc3Q=";
        //String authorization = new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
        String endPoint = ReportAPIConstants.MASTERY_REPORT_ENDPOINT;
        ObjectMapper mapper = new ObjectMapper();
        ReportRequest request = new ReportRequest();
        request.getStudents().add( studentUserID );
        request.setSubject( ReportAPIConstants.READING_ID );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( ReportAPIConstants.districtId, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
        actualLst = new ArrayList<>();
        lst = new ArrayList<>();

        switch ( scenarioType ) {
            case "GET METHOD":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                break;
            case "VALID_STUDENT_IDS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_STUDENT_IDS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                List<String> studentIdLst = new ArrayList<>();
                studentIdLst.add( "test" );
                request.setStudents( studentIdLst );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "WITHOUT_TOKEN":
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "VALID_SUBJECT":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setSubject( ReportAPIConstants.READING_ID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_SUBJECT":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setSubject( 12345 );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_SUBJECT_STRING":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setSubject( ReportAPIConstants.INVALID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "VALID_LIMIT":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setLimit( 1 );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_LIMIT":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setLimit( ReportAPIConstants.INVALID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_LIMIT_ZERO":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setLimit( 0 );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "VALID_OFFSET":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setOffset( 1 );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_OFFSET":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setOffset( ReportAPIConstants.INVALID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "VALID_ASSIGNMENT_IDS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setAssignmentIds( Arrays.asList( "313" ) );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_ASSIGNMENT_IDS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setAssignmentIds( Arrays.asList( ReportAPIConstants.INVALID ) );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_RBS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setRbs( ReportAPIConstants.INVALID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "VALID_RBS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setRbs( Boolean.FALSE );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "VALID_RBS_WITHOUT_STV":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setRbs( Boolean.TRUE );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_STV":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setRbs( Boolean.TRUE );
                request.setStv( ReportAPIConstants.INVALID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "VALID_STV":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                request.setRbs( Boolean.TRUE );
                request.setStv( 1 );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;

        }
        Log.message( response.toString() );
        // Validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData() {
        return new Object[][] { { "TC001", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "VALID_STUDENT_IDS" },
                { "TC002", "200", "Verify the status code 200 for response body for providing only invalid studentIds in request body and validate response message", "INVALID_STUDENT_IDS" },
                { "TC003", "401", "Verify the status code 401 for response body for providing not providing Authorization in header", "WITHOUT_TOKEN" },
                { "TC004", "200", "Verify the status code 200 for response body for providing valid studentIds and subject in request body ", "VALID_SUBJECT" },
                { "TC005", "400", "Verify the status code 400 for response body for providing valid studentIds and invalid subject in request body ", "INVALID_SUBJECT" },
                { "TC006", "400", "Verify the status code 400 for response body for providing valid studentIds and invalid subject in request body ", "INVALID_SUBJECT_STRING" },
                { "TC007", "200", "Verify the status code 200 for response body for providing valid studentIds and limit in request body", "VALID_LIMIT" },
                { "TC008", "400", "Verify the status code 400 for response body for providing valid studentIds and invald limit in request body", "INVALID_LIMIT" },
                { "TC009", "400", "Verify the status code 400 for response body for providing valid studentIds and invald limit (0) in request body", "INVALID_LIMIT_ZERO" },
                { "TC010", "200", "Verify the status code 200 for response body for providing valid studentIds and offset in request body", "VALID_OFFSET" },
                { "TC011", "400", "Verify the status code 400 for response body for providing valid studentIds and invald offset in request body", "INVALID_OFFSET" },
                { "TC012", "200", "Verify the status code 200 for response body for providing valid studentIds and assignmentIds in request body", "VALID_ASSIGNMENT_IDS" },
                { "TC013", "400", "Verify the status code 400 for response body for providing valid studentIds and invalid assignmentIds  in request body", "INVALID_ASSIGNMENT_IDS" },
                { "TC014", "400", "Verify the status code 400 for response body for providing valid studentIds and invalid rbs  in request body", "INVALID_RBS" },
                { "TC015", "200", "Verify the status code 200 for response body for providing valid studentIds and valid rbs in request body", "VALID_RBS" },
                { "TC016", "400", "Verify the status code 400 for response body for providing valid studentIds and valid rbs without stv in request body", "VALID_RBS_WITHOUT_STV" },
                { "TC017", "400", "Verify the status code 200 for response body for providing valid studentIds and valid rbs and invalid stv in request body", "INVALID_STV" },
                { "TC018", "200", "Verify the status code 200 for response body for providing valid studentIds and valid rbs and valid stv in request body", "VALID_STV" },
                { "TC019 ", "405", "Verify status code 405 when method type is GET", "GET METHOD" } };
    }

    public String createTestTeacher() throws Exception {
        HashMap<String, String> userDetails = new HashMap<>();
        String teacherUserName = "Teacher" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_FROM_CONFIG ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, teacherUserName );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
        // Creating District Admin
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
        return new RBSUtils().createUser( userDetails );
    }

    public String createTestStudent() throws Exception {
        HashMap<String, String> studentDetails = new HashMap<>();
        studentDetails = new CreateStudentAPITest().generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, orgId );
        studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, orgId );
        studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, userId );
        studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        HashMap<String, String> stuDetails = createStudent( smUrl, studentDetails );
        return SMUtils.getKeyValueFromResponse( stuDetails.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA );
    }

    public String createTestGroup() throws Exception {
        HashMap<String, String> groupDetails = new HashMap<>();
        String groupName = "Group " + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, userId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
        return SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentId ).get( Constants.BODY ), "data,groupId" );
    }

    public String assignCourseToTestGroup() throws Exception {
        String assignCoursetoGroupBody;
        assignCoursetoGroupBody = SMUtils.convertFileToString( configProperty.getProperty( "assignCourseToGroupPayload" ) );
        assignCoursetoGroupBody = assignCoursetoGroupBody.replace( Constants.SESSION_LENGTH_ID, "1" );
        assignCoursetoGroupBody = assignCoursetoGroupBody.replace( Constants.IDLE_TIME_ID, "2" );
        assignCoursetoGroupBody = assignCoursetoGroupBody.replace( Constants.GROUPID, groupId );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        headers.put( Constants.USERID_SM_HEADER, userId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        String endPoint = CreateGroupAPIConstants.ASSIGN_COURSE_GROUP;
        endPoint = endPoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
        endPoint = endPoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
        endPoint = endPoint.replace( Constants.COURSE_ID, CourseAPIConstants.STRING_ONE );

        //Parameters
        HashMap<String, String> params = new HashMap<>();
        HashMap<String, String> res = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, assignCoursetoGroupBody );

        if ( res.get( Constants.STATUS_CODE ).equals( Constants.VALID_RESPONSE_200 ) ) {
            endPoint = CreateGroupAPIConstants.ASSIGN_COURSE_GROUP;
            endPoint = endPoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endPoint = endPoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endPoint = endPoint.replace( Constants.COURSE_ID, CourseAPIConstants.STRING_TWO );
            res = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, assignCoursetoGroupBody );
        }
        return res.get( Constants.STATUS_CODE );
    }

    /**
     * To execute the course
     *
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, String percentage, String numberOfSession, String loCount ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    public String formatDate( LocalDate date ) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "yyyy-MM-dd" );
        return date.format( formatter );
    }

    /**
     * To assign an assignment to a user(s) or groups(s)
     *
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            org ID & course ID
     * @param studentRumbaIds
     * @param type should be users or groups
     * @return
     * @throws Exception
     */
    public HashMap<String, String> assignAssignment( String envUrl, HashMap<String, String> assignmentDetails, List<String> studentRumbaIds, String type ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.CREATE_ASSIGNMENT_API;

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.ASSIGN_ASSIGNMENT_PAYLOAD ) );

        if ( !studentRumbaIds.isEmpty() ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {

                listString += studentID.concat( "\",\"" );

            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_IDS ), listString ) );

            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_GRADE_IDS ), listString ).replace( ",,", "," ) );
        } else {
            Log.fail( "Student / Group ID missing" );
        }

        if ( type.equalsIgnoreCase( AssignmentAPIConstants.USERS_TYPE ) ) {
            requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.USERS_TYPE ) );
        } else if ( type.equalsIgnoreCase( AssignmentAPIConstants.GROUPS_TYPE ) ) {
            requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.GROUPS_TYPE ) );
        } else {
            Log.fail( "Invalid Type: " + type );
        }

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{courseID}", courseID );

        return RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );

    }

    /**
     * This Method will generate headers
     *
     * @param userreqDetails should contains bearer token, teacher rumbaID & org
     *            ID
     * @return
     */
    public Map<String, String> getHeaders( HashMap<String, String> userreqDetails ) {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userreqDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        headers.put( Constants.USERID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.ORG_ID ) );
        return headers;
    }

    /**
     * To create a custom course
     *
     * @param smUrl
     * @param token
     * @param subject
     * @param teacherID
     * @param orgID
     * @param courseType
     * @param courseName
     * @param jsonFileName
     * @return
     * @throws Exception
     */
    public String createCustomCourse( String smUrl, String token, String subject, String teacherID, String orgID, String courseType, String courseName, String jsonFileName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        DataSetupProcessor dataprocess = new DataSetupProcessor();
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherID );
            headers.put( Constants.ORGID_SM_HEADER, orgID );
            // Input Params
            HashMap<String, String> params = new HashMap<>();

            // EndPoint Details
            String endPoint_post = CourseAPIConstants.POST_STANDARD_COURSE_COPY;
            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgID );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherID );

            Map<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( courseType.equalsIgnoreCase( DataSetupConstants.SETTINGS ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.SKILL ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.STANDARD ) ) {
                List<String> standardDetails = new ArrayList<>();

                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    standardDetails = SqlHelperAssignment.getRandomStandardGradeID( DataSetupConstants.MATH, isItMt.equalsIgnoreCase( "true" ) );
                } else {
                    standardDetails = SqlHelperAssignment.getRandomStandardGradeID( DataSetupConstants.READING, isItMt.equalsIgnoreCase( "true" ) );
                }

                List<String> listLO = SqlHelperAssignment.getLOIDsRandomStandard( standardDetails.get( 0 ), standardDetails.get( 1 ), isItMt.equalsIgnoreCase( "true" ) );
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
                courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }

            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.ONE_LO ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_ONE_LO, courseDetails );
                }
            }
            response_post = RestHttpClientUtil.POST( smUrl, headers, params, endPoint_post, requestBody );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }

}
