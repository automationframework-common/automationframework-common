package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class RemoveStuFromGroup extends BaseTest {

    List<String> expectedCourseTypesInDropdown = Arrays.asList( "Focus Courses", "Default Courses", "Custom Courses", "All Courses" );

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    private String teacherId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    List<String> studentIdList = null;
    List<String> studentUserNames = null;
    List<String> studentDetails = null;

    private AtomicReference<String> schoolUsed = new AtomicReference<>();

    @BeforeClass
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        String teacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        studentDetails = new ArrayList<>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<>();
        studentUserNames = new ArrayList<>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

    }

    @Test ( description = "Verify remove student from Group functionality in Students tab", groups = { "Students", "SMK-39148" }, priority = 1 )
    public void tcStuRemoveFromGroup001( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "tcStuRemoveFromGroup001: Verify remove student from Group functionality in Students tab. <small><b><i>[" + browser + "]</b></i></small>" );
        String firstName = SMUtils.getKeyValueFromResponseWithArray( studentDetails.get( 0 ), RBSDataSetupConstants.FIRSTNAME );
        String lastName = SMUtils.getKeyValueFromResponseWithArray( studentDetails.get( 0 ), RBSDataSetupConstants.LASTNAME );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            //Navigate to group tab
            GroupPage grouppage = teacherHomePage.topNavBar.navigateToGroupsTab();
            String groupName = grouppage.getGroupListNames().get( 0 );

            // Navigate to Students tab
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );
            Log.softAssertThat( studentsPage.verifyRemoveStudentToGroupText( groupName ), "Remove Student from Group text is displayed after clicking ellips icon", "Remove Student from text is not displayed after clicking ellips icon" );
            studentsPage.clickRemoveStudentToGroupText( groupName );
            SMUtils.logDescriptionTC( "SMK-8171 : Verify the screen elements present in \"Remove Students from Group\" popup" );
            Log.assertThat( studentsPage.verifyRemoveStudentFromGroupPopup( firstName + " " + lastName, groupName ), "Verified all the screen elements in Remove Student from Group popup", "Screen elements is not fully displayed" );
            SMUtils.logDescriptionTC( "SMK-8174 : Validate the X button functionality in \"Remove student from Group\" popup" );
            studentsPage.clickCloseIconInPopup();
            Log.assertThat( studentsPage.isGroupnamePresent( groupName ), "Group name " + groupName + " is present in Students page", "Group name " + groupName + " is not present in the page" );
            studentsPage.clickRemoveStudentToGroupText( groupName );
            SMUtils.logDescriptionTC( "SMK-8173 : Validate the Cancel button functionality in \"Remove student from Group\" popup" );
            studentsPage.clickCancelButtonInPopup();
            Log.assertThat( studentsPage.isGroupnamePresent( groupName ), "Group name " + groupName + " is present in Students page", "Group name " + groupName + " is not present in the page" );
            studentsPage.clickRemoveStudentToGroupText( groupName );
            SMUtils.logDescriptionTC( "SMK-8172 : Validate the Remove button functionality in \"Remove student from Group\" popup" );
            SMUtils.logDescriptionTC( "SMK-10225 : Verify the \"Remove\" button color in Remove Student from Group popup for teacher user" );
            Log.assertThat( SMUtils.checkBackgroundColor( studentsPage.removeAndCancelButton( Constants.Students.removeText ), Constants.BUTTON_COLOR_CODE ), "Delete button color code is displayed as " + Constants.BUTTON_COLOR_CODE,
                    "Delete button color code is not displayed as " + Constants.BUTTON_COLOR_CODE );
            studentsPage.clickRemoveButtonInPopup();
            Log.assertThat( !studentsPage.isGroupnamePresent( groupName ), "Group name " + groupName + " is  not present in Students page", "Group name " + groupName + " is present in the page" );
            // perform signout action
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

}