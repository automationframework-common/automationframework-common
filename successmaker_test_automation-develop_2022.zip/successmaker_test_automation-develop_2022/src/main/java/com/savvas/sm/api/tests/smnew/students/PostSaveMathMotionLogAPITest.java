package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class PostSaveMathMotionLogAPITest extends EnvProperties {

    private String smUrl;
    private String teacherDetails;
    private String teacherUsername;
    private String teacherUserId;
    private String orgId;
    private String studentDetails;
    private String studentUsername;
    private String studentUserId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private List<String> studentRumbaIds = new ArrayList<>();
    private Map<String, String> courseName = new HashMap<>();
    private Map<String, String> courseIds = new HashMap<>();
    private Map<String, String> assignmentIds = new HashMap<>();
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String browser;
    String assignmentUserId;
    
    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {
        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        studentDetails = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );

        //Math Course Names
        courseName.put( Constants.MATH, AssignmentAPIConstants.MATH_COURSE );
        courseName.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );

        String teacherAccessToken = null;
        try {
            teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Issue in get the accces token - " + e.getMessage() );
            try {
                Log.message( "Retrying to get the access token!!!!" );
                teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            } catch ( Exception e1 ) {
                Log.fail( "Unable to create the access token for the teacher - " + teacherUsername );
            }
        }

        //Math course Ids
        courseIds.put( Constants.MATH, AssignmentAPIConstants.MATH );

        try {
            courseIds.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );
            courseIds.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SKILL, courseName.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ) );

            courseIds.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ) );
        } catch ( Exception e ) {
            Log.message( "Issue in Math Custom course creation!! - " + e.getMessage() );
        }

        Log.message( "Course Ids for " + school + ": " + courseIds );

        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        Log.message( "Assigning assignment..." );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, studentRumbaIds, new ArrayList( courseIds.values() ) );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );

            Log.message( "Assignment IDs - " + assignmentIds );
        }

    }
    @Test ( priority = 1, dataProvider = "saveMathMotionLog", groups = { "smoke_test_case", "SMK-51970/SMK-66835", "Students", "Save Math motion log", "P1", "API" } )
    public void tcPositiveTestcases( String tcId, String description, String scenario, String statusCode ) throws Throwable {
        Log.testCaseInfo( tcId + ":-" + description );
        // Response response = null;
        String body = "";
        Response response = null;
        String sessionId;
        switch ( scenario ) {
            case "VALID__DEFAULTMATH":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.MATH ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = saveMathMotionLogPOST( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId, Constants.MATH, LicenseAPIConstants.DEFAULT );
                Log.message( String.valueOf( response.getStatusCode() ) );
                Log.assertThat( response.getStatusCode() == 201, "Getting the 200 satus code for save math motion log Test", "Not Getting the 200 satus code for save math motion log Test" );

                break;

            case "VALID__SETTING_MATH":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = saveMathMotionLogPOST( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId, Constants.MATH, LicenseAPIConstants.DEFAULT );
                Log.message( String.valueOf( response.getStatusCode()) );
                Log.assertThat( response.getStatusCode() == 201, "Getting the 201 satus code for save math motion log Test", "Not Getting the 201 satus code for save math motion log Test" );

                break;

            case "VALID__SKILL_MATH":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = saveMathMotionLogPOST( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId, Constants.MATH, LicenseAPIConstants.DEFAULT );
                Log.message( String.valueOf( response ) );
                Log.assertThat( response.getStatusCode() == 201, "Getting the 201 satus code for save math motion log Test", "Not Getting the 201 satus code for save math motion log Test" );

                break;

            case "VALID__STANDARDS_MATH":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = saveMathMotionLogPOST( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId, Constants.MATH, LicenseAPIConstants.DEFAULT );
                Log.assertThat( response.getStatusCode() == 201, "Getting the 201 satus code for save math motion log Test", "Not Getting the 201 satus code for save math motion log Test" );

                break;

        }

    }

    @DataProvider ( name = "saveMathMotionLog" )
    public Object[][] saveMathMotionLog() {

        Object[][] inputData = { { "saveMathMotionLog_TC001", "Verify the response code is 201 for Defaut Math Course", "VALID__DEFAULTMATH", CommonAPIConstants.STATUS_CODE_CREATED },
                { "saveMathMotionLog_TC002", "Verify the response code is 201 for custom by Settings", "VALID__SETTING_MATH", CommonAPIConstants.STATUS_CODE_CREATED },
                { "saveMathMotionLog_TC003", "Verify the response code is 201 for custom by Skills", "VALID__SKILL_MATH", CommonAPIConstants.STATUS_CODE_CREATED },
                { "saveMathMotionLog_TC004", "Verify the response code is 201 for custom by Standard", "VALID__STANDARDS_MATH", CommonAPIConstants.STATUS_CODE_CREATED }, };

        return inputData;
    }

    /**
     * To get IPM complete student completed the assignment
     * 
     * @param smUrl
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @param sessionId
     * @return
     * @throws Throwable
     */
    public Response saveMathMotionLogPOST( String smUrl, String userId, String orgId, String studentUsername, String password, String assignmntUserId, String sessionId, String subject, String assignmentType ) throws Throwable {
        String endPoint = "/lms/web/assignments/mathmotionlog";
        Map<String, String> header = new HashMap<>();
        Map<String, Object> requestBody = new HashMap<>();
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + "" + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            Log.fail( "Issue in getting the accesstoken for student - " + studentUsername );
        }
        //Adding headers details
        header.put( LicenseAPIConstants.USERID, userId );
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( "session-id", sessionId );
        header.put( ("Content-Type"), "application/json" );
        
        //Adding request body details
        requestBody.put( "assignmentUserId", assignmntUserId );
        requestBody.put( "subject", subject );
        requestBody.put( LicenseAPIConstants.ASSIGNMENTTYPE, assignmentType );
        requestBody.put( LicenseAPIConstants.CURRETNT_ATTEMPT_NUMBER, "1" );
        requestBody.put( LicenseAPIConstants.SESSION_NUMBER, "11" );
        requestBody.put( LicenseAPIConstants.SME_ID_NUMBER, "1" );
        requestBody.put( LicenseAPIConstants.LO_VALUE, "SMMA_LO_01812" );
        requestBody.put( LicenseAPIConstants.MASTERY_TABLE_VALUE, "app4" );
        requestBody.put( LicenseAPIConstants.LO_ATTEMPT_NUMBER, "2" );
        requestBody.put( LicenseAPIConstants.INTREACTION_RESULT, "Wrong" );
        requestBody.put( LicenseAPIConstants.JUDGEMENT, "Awaiting Judgment" );
        requestBody.put( LicenseAPIConstants.PROBABILITY_VAL, "0.3874" );
        requestBody.put( LicenseAPIConstants.MOTION_DECISION, "Less than minimum required LOs" );
        requestBody.put( LicenseAPIConstants.COMMENT, "NOT_REVIEW" );
        requestBody.put( LicenseAPIConstants.PHASE, "First" );
        requestBody.put( LicenseAPIConstants.MOTION_TYPE, "STANDARD" );
        requestBody.put( LicenseAPIConstants.LATENCY_TYME, "PT4M17S" );
        requestBody.put( LicenseAPIConstants.TIMES_TAMP, "2022-04-27T18:10:58.466Z" );
        requestBody.put( LicenseAPIConstants.TOTAL_COURSE_TIME, "370" );
        requestBody.put( LicenseAPIConstants.TOTAK_IPM_TIME, "365" );
        requestBody.put( LicenseAPIConstants.IPM_STATUS, "INACTIVE" );
        requestBody.put( LicenseAPIConstants.IPM_LEVEL, "8.14" );
        requestBody.put( LicenseAPIConstants.COURSE_AVERAGE, "8.14" );
        requestBody.put( LicenseAPIConstants.TOTAKSKILL_COMPLETED, "0" );
        requestBody.put( LicenseAPIConstants.TOTAK_SKILL_MASTERED, "0" );
        requestBody.put( LicenseAPIConstants.DOMAIN_NAME, smUrl );
        
        
        return  RestAssuredAPIUtil.POST_REQ( smUrl, header, requestBody, endPoint );

    }

    /**
     * To Create and get the session Id for given student
     *
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @return
     */
    public String getSessionId( String smUrl, String userId, String orgId, String studentUsername, String password, String assignmentUserId ) {
        String endPoint1 = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        List<String> pathParamsList = new ArrayList<>();
        HashMap<String, String> header = new HashMap<>();
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( LicenseAPIConstants.USERID, userId );
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        pathParamsList.add( assignmentUserId );
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint1, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, header, endPoint1, pathParams );
        Log.message( response.getBody().asString() );
        String sessionId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "sessionId" );
        Log.message( "Session ID  - " + sessionId );
        return sessionId;
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "10" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "3" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    /**
     * Returns response of POST API method execution
     * 
     * @param baseURL
     * @param headers
     * @param body
     * @param url
     * @return Response of POST command
     */
    public static Response POST_REQUEST( String baseURL, Map<String, String> headers, Map<String, String> body, String url ) {
        setBaseURL( baseURL );
        Response resp = RestAssured.given().headers( headers ).body( body ).post( url ).andReturn();
        Log.message( "running POST command" );
        Log.message( "URL \n" + url );
        Log.message( "Header \n" + resp.getHeaders().toString() );
        Log.event( "Response body \n" + resp.asString() );
        Log.message( "Time taken to get response is \n" + resp.getTime() + " milli second" );

        return resp;

    }
    
    /**
     * setBaseURL method sets baseURL
     * 
     * @param baseURL
     */
    public static void setBaseURL( String baseURL ) {
        try {
            if ( !baseURL.isEmpty() || !baseURL.contains( null ) ) {
                RestAssured.baseURI = baseURL;
            }
        } catch ( NullPointerException e ) {
            System.out.println( "Base URL is set as null" );
        }
    }
    
}
