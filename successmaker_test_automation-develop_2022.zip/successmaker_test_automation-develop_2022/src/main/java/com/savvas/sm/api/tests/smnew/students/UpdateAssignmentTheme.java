package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class UpdateAssignmentTheme extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String assignmentID;
    RBSUtils rbsutils = new RBSUtils();
    private String studentDetail;
    private String studentUserID;
    private String studentUsername;
    private String courseName;
    Map<String, String> response = new HashMap<>();
    Map<String, String> assignmentResponse = new HashMap<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ).toString();
        SMUtils.getKeyValueFromResponse( studentDetail, "lastName" ).toString();
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( dataProvider = "positiveData", priority = 1, groups = { "SMK-66843", "smoke_test_case", "P1", "API" } )
    public void updateAssignmentRewardPoints( String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupdetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentUserID );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );

        String CourseId;
        switch ( scenario ) {

            case "Default Math":
                courseName = Constants.MATH;
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                String accessToken = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId );

                selectCourse( studentUsername, courseName );
                String SessionId = SqlHelperAssignment.getSessionId( assignmentUserId );
                Log.message( "SessionId : " + SessionId );

                response = updateRewardsPoint( orgId, studentUserID, accessToken, assignmentUserId, SessionId );
                Log.message( "Response = " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "Custom Setting Math":
                courseName = "CustomSettingMath" + System.nanoTime();
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( courseName ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                String accessToken1 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId1 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId1 );

                selectCourse( studentUsername, courseName );
                String SessionId1 = SqlHelperAssignment.getSessionId( assignmentUserId1 );
                Log.message( "SessionId : " + SessionId1 );

                
               response = updateRewardsPoint( orgId, studentUserID, accessToken1, assignmentUserId1, SessionId1 );
               Log.message( "Response = " + response );

                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "Custom Skill Math":
                courseName = "CustomSkillMath" + System.nanoTime();
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, String.format( courseName ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                String accessToken2 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId2 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId2 );

                selectCourse( studentUsername, courseName );
                String SessionId2 = SqlHelperAssignment.getSessionId( assignmentUserId2 );
                Log.message( "SessionId : " + SessionId2 );

               response = updateRewardsPoint( orgId, studentUserID, accessToken2, assignmentUserId2, SessionId2 );
               Log.message( "Response = " + response );

                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "Custom Standard Math":
                courseName = "CustomStandardMath" + System.nanoTime();
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, String.format( courseName ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                String accessToken3 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId3 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId3 );

                selectCourse( studentUsername, courseName );
                String SessionId3 = SqlHelperAssignment.getSessionId( assignmentUserId3 );
                Log.message( "SessionId : " + SessionId3 );
        
               response = updateRewardsPoint( orgId, studentUserID, accessToken3, assignmentUserId3, SessionId3 );
               Log.message( "Response = " + response );

                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;
            case "Default Focus Math":
                courseName = Constants.SM_FOCUS_MATH_GRADE1;
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );
                String accessToken4 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId4 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId4 );

                selectCourse( studentUsername, courseName );
                String SessionId4 = SqlHelperAssignment.getSessionId( assignmentUserId4 );
                Log.message( "SessionId : " + SessionId4 );

                response = updateRewardsPoint( orgId, studentUserID, accessToken4, assignmentUserId4, SessionId4 );
                Log.message( "Response = " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;
            case "Default Reading":
                courseName = Constants.READING;
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                String accessToken5 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId5 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId5 );

                selectCourse( studentUsername, courseName );
                String SessionId5 = SqlHelperAssignment.getSessionId( assignmentUserId5 );
                Log.message( "SessionId : " + SessionId5 );
                response = updateRewardsPoint( orgId, studentUserID, accessToken5, assignmentUserId5, SessionId5 );
                Log.message( "Response = " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;
            case "Default Focus Reading":
                courseName = Constants.SM_FOCUS_READING_GRADE1;
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );
                String accessToken6 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId6 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId6 );
                selectCourse( studentUsername, courseName );
                String SessionId6 = SqlHelperAssignment.getSessionId( assignmentUserId6 );
                Log.message( "SessionId : " + SessionId6 );
                response = updateRewardsPoint( orgId, studentUserID, accessToken6, assignmentUserId6, SessionId6 );
               Log.message( "Response = " + response );

                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "Custom Setting Reading":
                courseName = "CustomSettingReading" + System.nanoTime();
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( courseName ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                String accessToken7 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId7 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId7 );

                selectCourse( studentUsername, courseName );
                String SessionId7 = SqlHelperAssignment.getSessionId( assignmentUserId7 );
                Log.message( "SessionId : " + SessionId7 );
           
               response = updateRewardsPoint( orgId, studentUserID, accessToken7, assignmentUserId7, SessionId7 );
               Log.message( "Response = " + response );

                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "Custom Skill Reading":
                courseName = "CustomSkillReading" + System.nanoTime();
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, String.format( courseName ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                String accessToken8 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId8 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId8 );

                selectCourse( studentUsername, courseName );
                String SessionId8 = SqlHelperAssignment.getSessionId( assignmentUserId8 );
                Log.message( "SessionId : " + SessionId8 );
             
               response = updateRewardsPoint( orgId, studentUserID, accessToken8, assignmentUserId8, SessionId8 );
               Log.message( "Response = " + response );

                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "Custom Standard Reading":
                courseName = "CustomStandardReading" + System.nanoTime();
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.STANDARD, String.format( courseName ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                String accessToken9 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId9 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId9 );

                selectCourse( studentUsername, courseName );
                String SessionId9 = SqlHelperAssignment.getSessionId( assignmentUserId9 );
                Log.message( "SessionId : " + SessionId9 );
               response = updateRewardsPoint( orgId, studentUserID, accessToken9, assignmentUserId9, SessionId9 );
               Log.message( "Response = " + response );

                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "Custome course from teacher 1 to another":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingMath" + System.nanoTime();
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( courseName ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId10 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                //Creating the teacher in the Same school
                String coTeacherUsername = "SchTeacher" + System.nanoTime();

                String coTeacherDetails = new UserAPI().createUserWithCustomization( coTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( school ) ) );
                String coTeacherID = SMUtils.getKeyValueFromResponse( coTeacherDetails, RBSDataSetupConstants.USERID );

                //Creating group with existing student for above created teacher
                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), coTeacherID, Arrays.asList( studentUserID ), orgId, new RBSUtils().getAccessToken( coTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                String accessToken10 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId10 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId10 );

                selectCourse( studentUsername, courseName );
                String SessionId10 = SqlHelperAssignment.getSessionId( assignmentUserId10 );
                Log.message( "SessionId : " + SessionId10 );
              
               response = updateRewardsPoint( orgId, studentUserID, accessToken10, assignmentUserId10, SessionId10 );
               Log.message( "Response = " + response );

                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "SHARED_COURSES":
                courseName = "CustomSettingMath" + System.nanoTime();
                CourseId = new SharedCourses().createCustomCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                HashMap<String, String> assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                HashMap<String, String> putCallResponse = new HashMap<>();
                List<String> mathSchoolStudentRumbaIds = new ArrayList<>();
                String assignmentUserId11 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId11 );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SHARED_COURSES", "TRUE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                String accessToken11 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId11 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId11 );

                selectCourse( studentUsername, courseName );
                String SessionId11 = SqlHelperAssignment.getSessionId( assignmentUserId11 );
                Log.message( "SessionId : " + SessionId11 );

               response = updateRewardsPoint( orgId, studentUserID, accessToken11, assignmentUserId11, SessionId11 );
               Log.message( "Response = " + response );

                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the status code is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            default:
                Log.message( "Case is invalid" );
                break;
        }

    }

    public HashMap<String, String> updateRewardsPoint( String orgId, String userId, String token, String assignmentId, String SessionId ) {
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
          
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.USERID_SM_HEADER, userId );
            headers.put( Constants.SESSIONID_HEADER, SessionId );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );

            HashMap<String, String> params = new HashMap<>();

            // Input Path Parameters
            String endPoint = Constants.UPDATE_COURSE_LEVEL;

            endPoint = endPoint.replace( "{assignmentId}", assignmentId );
            endPoint = endPoint.replace( "{value}", "2" );
            endPoint = endPoint.replace( "{rewardCourseLevel}", "99" );

            String requestBody = "";
            HashMap<String, String> response = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, requestBody );
            return response;
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * This method generates the request body required for API.
     * 
     * @param requestBodyTemplate
     * @param requestDetails
     * @return
     */
    public String generateRequestBody( String requestBodyTemplate, Map<String, String> requestDetails ) {
        String requestBody = requestBodyTemplate;
        if ( requestBody.contains( Constants.GROUPNAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.GROUPNAME_VALUE, requestDetails.get( Constants.GROUP_NAME ) );
        }
        return requestBody;
    }

    @DataProvider ( name = "positiveData" )
    public Object[][] positiveData() {
        Object[][] data = { 
                { "TC01 Verify the valid response to Default Math", "Default Math", CommonAPIConstants.STATUS_CODE_OK },
                { "TC02 Verify the valid response to Custom Setting Math", "Custom Setting Math", CommonAPIConstants.STATUS_CODE_OK },
                { "TC03 Verify the valid response to Custom Skill Math", "Custom Skill Math", CommonAPIConstants.STATUS_CODE_OK },
                { "TC04 Verify the valid response to Custom Standard Math", "Custom Standard Math", CommonAPIConstants.STATUS_CODE_OK },
                { "TC05 Verify the valid response to Focus Math", "Default Focus Math", CommonAPIConstants.STATUS_CODE_OK },
                { "TC06 Verify the valid response to Default Reading", "Default Reading", CommonAPIConstants.STATUS_CODE_OK },
                { "TC10 Verify the valid response to Focus Reading", "Default Focus Reading", CommonAPIConstants.STATUS_CODE_OK },
                { "TC07 Verify the valid response to Custom Setting Math", "Custom Setting Reading", CommonAPIConstants.STATUS_CODE_OK },
                { "TC08 Verify the valid response to Custom Skill Reading", "Custom Skill Reading", CommonAPIConstants.STATUS_CODE_OK },
                { "TC09 Verify the valid response to Custom Standard Reading", "Custom Standard Reading", CommonAPIConstants.STATUS_CODE_OK },
                { "TC11 Verify the valid response to Custome course one teacher to another", "Custome course from teacher 1 to another", CommonAPIConstants.STATUS_CODE_OK },
                { "TC12 Verify the valid response to Shared Course", "SHARED_COURSES", CommonAPIConstants.STATUS_CODE_OK }, };
        return data;
    }

    /**
     * This method is used to select the course based on courseName.
     *
     * @param studentUserName
     * @param courseName
     */
    public void selectCourse( String studentUserName, String courseName ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );
        Log.message( "Student username :" + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentPage = new StudentDashboardPage( driver );
        SMUtils.nap( 30 );
        studentPage.selectAssignmentByName( courseName );
        SMUtils.nap( 5 );
    }

}
