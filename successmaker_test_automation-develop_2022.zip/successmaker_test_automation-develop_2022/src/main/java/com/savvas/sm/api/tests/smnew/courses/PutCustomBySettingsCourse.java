package com.savvas.sm.api.tests.smnew.courses;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.DBQueryFor;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class PutCustomBySettingsCourse extends CourseAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String teacherDetails1 = null;
    private String flexSchoolTeacherDetails = null;
    private String flexSchoolTeacherDetails1 = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String token = null;
    String customCourseId = null;
    String sessionLengthName = null;
    Long sessionLengthId = null;
    String sessionLengthValue = null;
    String idleTimeName = null;
    Long idleTimeId = null;
    String idleTimeValue = null;
    String orgID = null;
    String userID = null;
    String secondUserID = null;
    String tokenForDiffTeacher = null;
    String endpoint;
    String groupName = null;
    private HashMap<String, String> groupDetails = new HashMap<>();
    String username = null;
    private String flexSchoolStudentDetails = null;
    String StudentId = null;
    AssignmentAPI assignment = new AssignmentAPI();
    HashMap<String, String> mathGradeStandardDetails = new HashMap<String, String>();
    HashMap<String, String> readingGradeStandardDetails = new HashMap<String, String>();
    HashMap<String, String> mathGradeSkillDetails = new HashMap<String, String>();
    HashMap<String, String> readingGradeSkillDetails = new HashMap<String, String>();
    public static String isItMt = null;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws IOException {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        orgID = RBSDataSetup.organizationIDs.get( flexSchool );
        userID = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" );

        flexSchoolTeacherDetails1 = RBSDataSetup.getMyTeacher( flexSchool );
        secondUserID = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails1, "userId" );

        username = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME );
        flexSchoolStudentDetails = RBSDataSetup.getMyStudent( flexSchool, username );
        StudentId = SMUtils.getKeyValueFromResponse( flexSchoolStudentDetails, "userId" );
        Log.message( StudentId );
        isItMt = configProperty.getProperty( "isMTExecution" );

        //To get Random Skill and Standard ID's for Math and Reading Courses
        mathGradeStandardDetails = SqlHelperCourses.getGradeStandardID( Constants.MATH, isItMt.equalsIgnoreCase( "true" ) );
        readingGradeStandardDetails = SqlHelperCourses.getGradeStandardID( Constants.READING, isItMt.equalsIgnoreCase( "true" ) );
        mathGradeSkillDetails = SqlHelperCourses.getSCOIDsOfRandomSkillID( Constants.MATH );
        while ( readingGradeSkillDetails.get( "LOName" ) == null || readingGradeSkillDetails.get( "LOName" ).isEmpty() || readingGradeSkillDetails.get( "LOName" ).startsWith( "_" ) ) {
            readingGradeSkillDetails = SqlHelperCourses.getSCOIDsOfRandomSkillID( Constants.READING );
        }

    }

    @Test ( priority = 1, dataProvider = "putCustomBySettingsPositiveScenarios", groups = { "SMK-52076", "Update CustomCourse By Settings", "Course", "P1", "API", "smoke_test_case" } )
    public void createCourseAndUpdateCustomBySettingsPositiveScenarios( String description, String scenario, String snenario1, String statusCode, String gradeId, String courseId, String contentBaseId, String standardFrmeworkId, String parentNode,
            String ChildNode, String level, String includeLOS, String message ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> courseDetails = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();

        // Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        //Create Custom course
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, orgID );
        headers.put( Constants.USERID_SM_HEADER, userID );

        courseDetails.put( Constants.GRADE_VALUE, gradeId );
        courseDetails.put( Constants.STANDARD_FRAMEWORK_VALUE, standardFrmeworkId );
        courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
        courseDetails.put( CourseAPIConstants.PARENT_NODE, parentNode );
        courseDetails.put( CourseAPIConstants.CHILD_NODE, ChildNode );
        courseDetails.put( Constants.COURSE_NAME, "Skills" + System.nanoTime() );

        //Get Settings
        HashMap<String, String> courseSettings = new HashMap<>();
        HashMap<String, String> apiResponseGetSettings = new HashMap<>();

        //Create custom course
        switch ( snenario1 ) {
            case "customByStandards":
                apiResponse = createCourseByStandard( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );

                customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                break;
            case "customBySkill":
                apiResponse = createCourseBySkill( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );

                customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                break;
            case "customBySettings":
                apiResponse = createCourseBySettings( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );

                customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                break;

        }

        courseSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        courseSettings.put( CourseAPIConstants.TEACHER_ID, userID );
        courseSettings.put( CourseAPIConstants.ORG_ID, orgID );
        courseSettings.put( CourseAPIConstants.COURSE_ID, customCourseId );
        courseSettings.put( CourseAPIConstants.BANK_ID, gradeId );
        courseSettings.put( CourseAPIConstants.CONTENT_BASE_ID, contentBaseId );
        courseSettings.put( CourseAPIConstants.LEVEL, level );
        courseSettings.put( CourseAPIConstants.INCLUDE_LOS, includeLOS );
        apiResponseGetSettings = getCoursesSettings( smUrl, courseSettings, "false", customCourseId );
        Log.message( "Get Settings : " + apiResponseGetSettings );

        JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj( apiResponseGetSettings.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

        JSONObject data2 = getSettingsResp.getJSONObject( CourseAPIConstants.SESSION_LENGTH );
        sessionLengthName = data2.getString( CourseAPIConstants.NAME );
        sessionLengthId = data2.getLong( CourseAPIConstants.ID );
        sessionLengthValue = data2.getString( CourseAPIConstants.CURRENT_VALUE );
        Log.message( "Name of the session length : " + sessionLengthName );
        Log.message( "Id of the session length : " + sessionLengthId );
        Log.message( "CurrentValue of the session length : " + sessionLengthValue );

        JSONObject data3 = getSettingsResp.getJSONObject( CourseAPIConstants.IDLE_TIME );
        idleTimeName = data3.getString( CourseAPIConstants.NAME );
        idleTimeId = data3.getLong( CourseAPIConstants.ID );
        idleTimeValue = data3.getString( CourseAPIConstants.CURRENT_VALUE );
        Log.message( "Name of the idleTime : " + idleTimeName );
        Log.message( "Id of the idleTime : " + idleTimeId );
        Log.message( "CurrentValue of the idleTime : " + idleTimeValue );

        courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( sessionLengthId ) );
        courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName );
        courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
        courseSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
        courseSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
        courseSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue );

        apiResponse = updateCourseBySettings( smUrl, headers, courseDetails, courseSettings, scenario, description );
        Log.message( "Update course : " + apiResponse );

        //Assertion
        Log.softAssertThat( verifyMessage( apiResponse.get( "body" ), message ), "Message gatting as expected", "Message getting as not expected" );
        Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    @Test ( priority = 2, dataProvider = "putCustomBySettingsNegativeScenarios", groups = { "SMK-52076", "Update CustomCourse by Settings", "Course", "P1", "API" } )
    public void createCourseAndUpdateCustomBySettingsNegativeScenarios( String description, String scenario, String scenario1, String statusCode, String gradeId, String courseId, String contentBaseId, String standardFrmeworkId, String parentNode,
            String ChildNode, String level, String includeLOS, String updateCourseId, String orgId, String staffId, String courseName, String settingsName, String settingsId, String currentValue, String exception ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> courseDetails = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();

        // Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        // Authorization
        tokenCreationForDiffTeacher( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        //Create Custom course by standards
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, orgID );
        headers.put( Constants.USERID_SM_HEADER, userID );
        courseDetails.put( Constants.GRADE_VALUE, gradeId );
        courseDetails.put( Constants.STANDARD_FRAMEWORK_VALUE, standardFrmeworkId );
        courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
        courseDetails.put( CourseAPIConstants.PARENT_NODE, parentNode );
        courseDetails.put( CourseAPIConstants.CHILD_NODE, ChildNode );
        courseDetails.put( Constants.COURSE_NAME, "Skills" + System.nanoTime() );
        apiResponse = createCourseByStandard( smUrl, headers, courseDetails, scenario );
        Log.message( "response from POST Call - " + apiResponse );

        customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );

        //Get Settings
        HashMap<String, String> courseSettings = new HashMap<>();
        HashMap<String, String> apiResponseGetSettings = new HashMap<>();

        courseSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        courseSettings.put( CourseAPIConstants.TEACHER_ID, userID );
        courseSettings.put( CourseAPIConstants.ORG_ID, orgID );
        courseSettings.put( CourseAPIConstants.COURSE_ID, customCourseId );
        courseSettings.put( CourseAPIConstants.BANK_ID, gradeId );
        courseSettings.put( CourseAPIConstants.LEVEL, level );
        courseSettings.put( CourseAPIConstants.INCLUDE_LOS, includeLOS );
        apiResponseGetSettings = getCoursesSettings( smUrl, courseSettings, "false", customCourseId );
        Log.message( "Get Settings : " + apiResponseGetSettings );

        JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj( apiResponseGetSettings.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

        JSONObject data2 = getSettingsResp.getJSONObject( CourseAPIConstants.SESSION_LENGTH );
        sessionLengthName = data2.getString( CourseAPIConstants.NAME );
        sessionLengthId = data2.getLong( CourseAPIConstants.ID );
        sessionLengthValue = data2.getString( CourseAPIConstants.CURRENT_VALUE );
        Log.message( "Name of the session length : " + sessionLengthName );
        Log.message( "Id of the session length : " + sessionLengthId );
        Log.message( "CurrentValue of the session length : " + sessionLengthValue );

        JSONObject data3 = getSettingsResp.getJSONObject( CourseAPIConstants.IDLE_TIME );
        idleTimeName = data3.getString( CourseAPIConstants.NAME );
        idleTimeId = data3.getLong( CourseAPIConstants.ID );
        idleTimeValue = data3.getString( CourseAPIConstants.CURRENT_VALUE );
        Log.message( "Name of the idleTime : " + idleTimeName );
        Log.message( "Id of the idleTime : " + idleTimeId );
        Log.message( "CurrentValue of the idleTime : " + idleTimeValue );

        HashMap<String, String> updateSettings = new HashMap<>();

        switch ( scenario1 ) {
            case "NegativeScenariosForCourse":

                updateSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                updateSettings.put( CourseAPIConstants.TEACHER_ID, userID );
                updateSettings.put( CourseAPIConstants.ORG_ID, orgID );
                updateSettings.put( CourseAPIConstants.COURSE_ID, updateCourseId );
                updateSettings.put( CourseAPIConstants.BANK_ID, gradeId );
                updateSettings.put( CourseAPIConstants.CONTENT_BASE_ID, contentBaseId );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( sessionLengthId ) );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue );

                apiResponse = updateCourseBySettings( smUrl, headers, courseDetails, updateSettings, scenario, description );
                Log.message( "Update course : " + apiResponse );

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                break;

            case "InvalidNameForSettings":

                updateSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                updateSettings.put( CourseAPIConstants.TEACHER_ID, staffId );
                updateSettings.put( CourseAPIConstants.ORG_ID, orgId );
                updateSettings.put( CourseAPIConstants.COURSE_ID, customCourseId );
                updateSettings.put( CourseAPIConstants.BANK_ID, gradeId );
                updateSettings.put( CourseAPIConstants.CONTENT_BASE_ID, contentBaseId );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( sessionLengthId ) );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, settingsName );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue );

                apiResponse = updateCourseBySettings( smUrl, headers, courseDetails, updateSettings, scenario, description );
                Log.message( "Update course : " + apiResponse );

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                break;
            case "InvalidIdForSettings":

                updateSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                updateSettings.put( CourseAPIConstants.TEACHER_ID, staffId );
                updateSettings.put( CourseAPIConstants.ORG_ID, orgId );
                updateSettings.put( CourseAPIConstants.COURSE_ID, customCourseId );
                updateSettings.put( CourseAPIConstants.BANK_ID, gradeId );
                updateSettings.put( CourseAPIConstants.CONTENT_BASE_ID, contentBaseId );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, settingsId );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue );

                apiResponse = updateCourseBySettings( smUrl, headers, courseDetails, updateSettings, scenario, description );
                Log.message( "Update course : " + apiResponse );

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                break;

            case "InvalidCurrentValueForIdelTime":

                updateSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                updateSettings.put( CourseAPIConstants.TEACHER_ID, staffId );
                updateSettings.put( CourseAPIConstants.ORG_ID, orgId );
                updateSettings.put( CourseAPIConstants.COURSE_ID, customCourseId );
                updateSettings.put( CourseAPIConstants.BANK_ID, gradeId );
                updateSettings.put( CourseAPIConstants.CONTENT_BASE_ID, contentBaseId );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( sessionLengthId ) );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, currentValue );

                apiResponse = updateCourseBySettings( smUrl, headers, courseDetails, updateSettings, scenario, description );
                Log.message( "Update course : " + apiResponse );

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                break;

            case "InvalidAuthentication":

                HashMap<String, String> headersInvalidToken = new HashMap<>();

                headersInvalidToken.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.AUTHORIZATION, "Bearer " + CourseAPIConstants.INVALID_AUTHORIZATION_ID );
                headersInvalidToken.put( Constants.ORGID_SM_HEADER, orgID );
                headersInvalidToken.put( Constants.USERID_SM_HEADER, userID );

                updateSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                updateSettings.put( CourseAPIConstants.TEACHER_ID, staffId );
                updateSettings.put( CourseAPIConstants.ORG_ID, orgId );
                updateSettings.put( CourseAPIConstants.COURSE_ID, customCourseId );
                updateSettings.put( CourseAPIConstants.BANK_ID, gradeId );
                updateSettings.put( CourseAPIConstants.CONTENT_BASE_ID, contentBaseId );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( sessionLengthId ) );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue );

                apiResponse = updateCourseBySettings( smUrl, headersInvalidToken, courseDetails, updateSettings, scenario, description );
                Log.message( "Update course : " + apiResponse );

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                break;
            case "NegativeScenariosForCourseCreatedByDeffTeacher":

                HashMap<String, String> headersInvalid = new HashMap<>();

                headersInvalid.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalid.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalid.put( Constants.AUTHORIZATION, "Bearer " + tokenForDiffTeacher );
                headersInvalid.put( Constants.ORGID_SM_HEADER, orgID );
                headersInvalid.put( Constants.USERID_SM_HEADER, secondUserID );

                updateSettings.put( RBSDataSetupConstants.BEARER_TOKEN, tokenForDiffTeacher );
                updateSettings.put( CourseAPIConstants.TEACHER_ID, secondUserID );
                updateSettings.put( CourseAPIConstants.ORG_ID, orgID );
                updateSettings.put( CourseAPIConstants.COURSE_ID, customCourseId );
                updateSettings.put( CourseAPIConstants.BANK_ID, gradeId );
                updateSettings.put( CourseAPIConstants.CONTENT_BASE_ID, contentBaseId );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( sessionLengthId ) );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue );

                apiResponse = updateCourseBySettings( smUrl, headersInvalid, courseDetails, updateSettings, scenario, description );
                Log.message( "Update course : " + apiResponse );

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                break;

            case "updateDefaultCourses":

                updateSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                updateSettings.put( CourseAPIConstants.TEACHER_ID, userID );
                updateSettings.put( CourseAPIConstants.ORG_ID, orgID );
                updateSettings.put( CourseAPIConstants.COURSE_ID, updateCourseId );
                updateSettings.put( CourseAPIConstants.BANK_ID, gradeId );
                updateSettings.put( CourseAPIConstants.CONTENT_BASE_ID, contentBaseId );

                apiResponse = updateDefaultCourseBySettings( smUrl, headers, courseDetails, updateSettings, scenario );
                Log.message( "Update course : " + apiResponse );

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                break;

            case "InvalidURL":

                updateSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                updateSettings.put( CourseAPIConstants.TEACHER_ID, userID );
                updateSettings.put( CourseAPIConstants.ORG_ID, orgID );
                updateSettings.put( CourseAPIConstants.COURSE_ID, customCourseId );
                updateSettings.put( CourseAPIConstants.BANK_ID, gradeId );
                updateSettings.put( CourseAPIConstants.CONTENT_BASE_ID, contentBaseId );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( sessionLengthId ) );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName );
                updateSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
                updateSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue );

                apiResponse = updateCourseBySettings( smUrl, headers, courseDetails, updateSettings, scenario, description );
                Log.message( "Update course : " + apiResponse );

                //Assertion
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                break;

        }
        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    /**
     * Data provider for Custom Course positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "putCustomBySettingsPositiveScenarios" )
    public Object[][] createCourseAndUpdateCustomBySettings() {
        Object[][] inputData = {
                { "TC002_When the valid test data for Math(custom by Standard ) is given.", "DEFAULTMATH", "customByStandards", "200", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ),
                        mathGradeStandardDetails.get( "bankID" ), mathGradeStandardDetails.get( "scoID" ), "0", "true", "Course setting updated successfully." },
                { "TC001_When the valid test data for Math(custom by Skill ) is given.", "DEFAULTMATH", "customBySkill", "200", mathGradeSkillDetails.get( "GradeID" ), "1", "3", null, mathGradeSkillDetails.get( "ParentNode" ),
                        mathGradeSkillDetails.get( "LOName" ), "0", "true", "Course setting updated successfully." },
                { "TC003_When the valid test data for Math(custom by Settings ) is given.", "DEFAULTMATH", "customBySettings", "200", null, "1", "2", null, null, null, "0", "true", "Course setting updated successfully." },
                { "TC004_When the valid test data for Reading(custom by Skill ) is given.", "DEFAULTREADING", "customBySkill", "200", readingGradeSkillDetails.get( "GradeID" ), "2", "3", null, readingGradeSkillDetails.get( "ParentNode" ),
                        readingGradeSkillDetails.get( "LOName" ), "0", "true", "Course setting updated successfully." },
                { "TC005_When the valid test data for Reading(custom by Standard ) is given.", "DEFAULTREADING", "customByStandards", "200", readingGradeStandardDetails.get( "GradeID" ), "2", "4", readingGradeStandardDetails.get( "StandardID" ),
                        readingGradeStandardDetails.get( "bankID" ), readingGradeStandardDetails.get( "scoID" ), "0", "true", "Course setting updated successfully." },
                { "TC006_When the valid test data for Reading(custom by Settings ) is given.", "DEFAULTREADING", "customBySettings", "200", null, "2", "2", null, null, null, "0", "true", "Course setting updated successfully." },
                { "TC032 Update custom by standards focus math", "FOCUSMATH", "customByStandards", "200", mathGradeStandardDetails.get( "GradeID" ), "3", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", "Course setting updated successfully." },
                { "TC033 Update custom by standards focus reading", "READING", "customByStandards", "200", readingGradeStandardDetails.get( "GradeID" ), "15", "4", readingGradeStandardDetails.get( "StandardID" ),
                        readingGradeStandardDetails.get( "bankID" ), readingGradeStandardDetails.get( "scoID" ), "0", "true", "Course setting updated successfully." } };
        return inputData;
    }

    @DataProvider ( name = "putCustomBySettingsNegativeScenarios" )
    public Object[][] updateCustomBySettingsNegativeScenarios() {
        Object[][] inputData = {
                { "TC07 invalid course id abc ", "DEFAULTMATH", "NegativeScenariosForCourse", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", "abc", orgID, userID, null, null, null, null, "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
                { "TC008_Verify the status code is 400 when the invalid(Null) Course Id is given.", "DEFAULTMATH", "NegativeScenariosForCourse", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ),
                        mathGradeStandardDetails.get( "bankID" ), mathGradeStandardDetails.get( "scoID" ), "0", "true", "null", orgID, userID, null, null, null, null, "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },

                { "TC025_Verify the status code is 400 when valid data is given for course which is created by another teacher..", "DEFAULTMATH", "NegativeScenariosForCourseCreatedByDeffTeacher", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4",
                        mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ), mathGradeStandardDetails.get( "scoID" ), "0", "true", "abc", orgID, secondUserID, null, null, null, null,
                        "com.savvas.core.exceptions.BusinessRuleViolationException" },

                { "TC09 non existing course id ", "DEFAULTMATH", "NegativeScenariosForCourse", "200", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", "7123", orgID, userID, null, null, null, null, "com.savvas.core.exceptions.DataNotFoundException" },

                { "TC12 name as integer ", "DEFAULTMATH", "InvalidNameForSettings", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, "3435", null, null, "com.pst.exceptions.ValidationException" },
                { "TC13 name as null ", "DEFAULTMATH", "InvalidNameForSettings", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, "null", null, null, "com.pst.exceptions.ValidationException" },
                { "TC14 invalid name ", "DEFAULTMATH", "InvalidNameForSettings", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, "abc", null, null, "com.pst.exceptions.ValidationException" },
                { "TC15 invalid id ", "DEFAULTMATH", "InvalidIdForSettings", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, null, "223ggg", null, "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC16 null id ", "DEFAULTMATH", "InvalidIdForSettings", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, null, "null", null, "com.pst.exceptions.ValidationException" },
                { "TC17 non existing id ", "DEFAULTMATH", "InvalidIdForSettings", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, null, "2233340", null, "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC18 invalid value ", "DEFAULTMATH", "InvalidCurrentValueForIdelTime", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, null, "5740790", "aabb583", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC20 beyond range value above max", "DEFAULTMATH", "InvalidCurrentValueForIdelTime", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, null, "5740790", "1000", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC20 beyond range value below min ", "DEFAULTMATH", "InvalidCurrentValueForIdelTime", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, null, "5740790", "gg1000", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC20 when change values ", "DEFAULTMATH", "InvalidCurrentValueForIdelTime", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, null, "5740790", "ggbhh", "null" },
                { "TC10 Verify 401 for invalid authentication ", "DEFAULTMATH", "InvalidAuthentication", "401", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, null, null, null, "java.lang.Exception" },
                { "InvalidURL: TC011_Verify the status code is 404 when the invalid url is given", "DEFAULTMATH", "InvalidURL", "404", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ),
                        mathGradeStandardDetails.get( "bankID" ), mathGradeStandardDetails.get( "scoID" ), "0", "true", null, orgID, userID, null, null, null, null, "java.lang.Exception" },

                { "TC21 Verify 400 for Default Math update ", "DEFAULTMATH_UPDATE", "updateDefaultCourses", "400", mathGradeStandardDetails.get( "GradeID" ), "1", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", "1", orgID, userID, null, null, null, null, "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC22 Verify 400 for Default Reading update ", "DEFAULTREADING_UPDATE", "updateDefaultCourses", "400", readingGradeStandardDetails.get( "GradeID" ), "2", "4", readingGradeStandardDetails.get( "StandardID" ),
                        readingGradeStandardDetails.get( "bankID" ), readingGradeStandardDetails.get( "scoID" ), "0", "true", "2", orgID, userID, null, null, null, null, "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC23 Verify 400 for Focus Math update ", "FOCUSMATH_UPDATE", "updateDefaultCourses", "400", mathGradeStandardDetails.get( "GradeID" ), "3", "4", mathGradeStandardDetails.get( "StandardID" ), mathGradeStandardDetails.get( "bankID" ),
                        mathGradeStandardDetails.get( "scoID" ), "0", "true", "3", orgID, userID, null, null, null, null, "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC24 Verify 400 for Focus Reading update ", "FOCUSREADING_UPDATE", "updateDefaultCourses", "400", "505", "15", "4", "504", "507", "smre_ip_00841_507", "0", "true", "15", orgID, userID, null, null, null, null,
                        "com.savvas.core.exceptions.BusinessRuleViolationException" } };
        return inputData;
    }

    //Token creation
    public void tokenCreation( String school ) {
        try {

            teacherDetails = flexSchoolTeacherDetails;

            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        } catch ( Exception e ) {
            Log.message( "Issue occured in tokenCreation" );
        }
    }

    //Token creation
    public void tokenCreationForDiffTeacher( String school ) {
        try {

            teacherDetails1 = flexSchoolTeacherDetails1;

            tokenForDiffTeacher = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        } catch ( Exception e ) {
            Log.message( "Issue occured in tokenCreation" );
        }
    }

    /**
     * Verifying the Exception information
     * 
     * @param actualResponse
     * @param exception
     * @return boolean
     * @throws IOException
     */
    public boolean verifyExceptionMessage( String actualResponse, String exception ) throws IOException {

        boolean flag = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.message( "Exception Verified successfully!" );
            flag = true;
        } else {
            Log.message( "Issue in displaying exception!" );
        }
        return flag;
    }

    /**
     * Verifying the message
     * 
     * @param actualResponse
     * @param message
     * @return boolean
     * @throws IOException
     */
    public boolean verifyMessage( String actualResponse, String message ) throws IOException {

        boolean flag = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).equalsIgnoreCase( message ) ) {
            Log.message( "status Verified successfully!" );
            flag = true;
        } else {
            Log.message( "Issue in displaying status!" );
        }
        return flag;
    }

    /**
     * Get response for the Create Course By Standard API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseByStandard( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardReading" ) ) );

            } else if ( scenario.contains( "DEFAULTMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardMath" ) ) );
            } else if ( scenario.contains( "FOCUSMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusMath" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.STANDARDFRAMEWORK_ID, courseDetails.get( Constants.STANDARD_FRAMEWORK_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

    /**
     * Get response for the Create Course By Skill API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySkill( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySkillsReading" ) ) );

            } else if ( scenario.contains( "DEFAULTMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySkillsMath" ) ) );
            } else if ( scenario.contains( "FOCUSMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusMath" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

    /**
     * Get response for the Create Course By Settings API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySettings( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySettingsReading" ) ) );

            } else if ( scenario.contains( "DEFAULTMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySettingsMath" ) ) );
            } else if ( scenario.contains( "FOCUSMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusMath" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

    /**
     * Get response for the update Course By Settings API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> updateCourseBySettings( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, HashMap<String, String> updateSettings, String scenario, String description ) {
        try {

            if ( description.contains( "InvalidURL:" ) ) {
                endpoint = CourseAPIConstants.CUSTOM_COURSE_SETTINGS_INVALID;
            } else {
                endpoint = CourseAPIConstants.CUSTOM_COURSE_SETTINGS;
            }

            Log.message( "update custom course by standard= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, updateSettings.get( CourseAPIConstants.ORG_ID ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, updateSettings.get( CourseAPIConstants.TEACHER_ID ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, updateSettings.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + envUrl + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "READING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "updateCustomBySettingsCourse" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "updateCustomBySettingsCourse" ) ) );
            }

            requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_ID, updateSettings.get( CourseAPIConstants.SESSION_STRENGTH_ID ) ) );
            requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_NAME, updateSettings.get( CourseAPIConstants.SESSION_STRENGTH_NAME ) ) );
            requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_VALUE, updateSettings.get( CourseAPIConstants.SESSION_STRENGTH_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.IDLE_TIME_ID, updateSettings.get( CourseAPIConstants.IDLE_TIME_ID ) ) );
            requestBody.set( requestBody.get().replace( Constants.IDLE_TIME_NAME, updateSettings.get( CourseAPIConstants.IDLE_TIME_NAME ) ) );
            requestBody.set( requestBody.get().replace( Constants.IDLE_TIME_VALUE, updateSettings.get( CourseAPIConstants.IDLE_TIME_VALUE ) ) );

            Log.message( "payload : " + requestBody.get() );
            Log.message( headers.toString() );

            return RestHttpClientUtil.PUT( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in updating the Course method" );
            return null;
        }
    }

    /**
     * Get response for the update DefaultCourses By Settings API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> updateDefaultCourseBySettings( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, HashMap<String, String> updateSettings, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CUSTOM_COURSE_SETTINGS;

            Log.message( "update custom course by standard= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, updateSettings.get( CourseAPIConstants.ORG_ID ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, updateSettings.get( CourseAPIConstants.TEACHER_ID ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, updateSettings.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + envUrl + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();

            if ( scenario.contains( "DEFAULTMATH_UPDATE" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "updateDefaultMathBySettings" ) ) );

            } else if ( scenario.contains( "DEFAULTREADING_UPDATE" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "updateDefaultReadingBySettings" ) ) );
            } else if ( scenario.contains( "FOCUSMATH_UPDATE" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "updateFocusMathBySettings" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "updateFocusReadingBySettings" ) ) );
            }
            Log.message( "payload : " + requestBody.get() );
            Log.message( headers.toString() );

            return RestHttpClientUtil.PUT( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in updating the Course method" );
            return null;
        }
    }

    public String createCourse( String envUrl, String token, String subject, String teacherId, String orgId, String courseType, String courseName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        // Input Params
        HashMap<String, String> params = new HashMap<>();
        // EndPoint Details
        String endPoint_post = CourseAPIConstants.CREATE_CUSTOM_COURSE;
        try {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );

            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgId );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherId );

            HashMap<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( courseType.equalsIgnoreCase( DataSetupConstants.SETTINGS ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SETTING_GENERIC_MATH ), courseDetails );
                } else {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SETTING_GENERIC_READING ), courseDetails );
                }
            }
            //TODO To get RandomSkills
            else if ( courseType.equalsIgnoreCase( DataSetupConstants.SKILL ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SKILLS_GENERIC_MATH ), courseDetails );
                } else {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SKILLS_GENERIC_READING ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.STANDARD ) ) {
                List<String> standardDetails = new ArrayList<>();

                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    standardDetails = getRandomStandardGradeID( "Teacher", DataSetupConstants.MATH, isItMt.equalsIgnoreCase( "true" ) );
                } else {
                    standardDetails = getRandomStandardGradeID( "Teacher", DataSetupConstants.READING, isItMt.equalsIgnoreCase( "true" ) );
                }

                List<String> listLO = getLOIDsRandomStandard( "Teacher", standardDetails.get( 0 ), standardDetails.get( 1 ), isItMt.equalsIgnoreCase( "true" ) );
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
                courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_MATH ), courseDetails );
                } else {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_READING ), courseDetails );
                }

            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.ONE_LO ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = new RBSUtils().generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_ONE_LO, courseDetails );
                }
            }
            response_post = RestHttpClientUtil.POST( envUrl, headers, params, endPoint_post, requestBody );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }

    /**
     * To get LOID with bankID for the random standards
     * 
     * @param dashboard
     * @param standID
     * @param gradeID
     * 
     * @return
     * @throws IOException
     */
    public static List<String> getLOIDsRandomStandard( String dashboard, String standID, String gradeID, Boolean isMTInstance ) throws IOException {
        String query = null;
        if ( dashboard.equalsIgnoreCase( "Admin" ) ) {
            if ( Boolean.TRUE.equals( isMTInstance ) ) {
                query = SMUtils.getDBQuery( DBQueryFor.ADMIN, "getLObyStandard_mt.sql" );
            } else {
                query = SMUtils.getDBQuery( DBQueryFor.ADMIN, "getLObyStandard.sql" );
            }
        } else {
            if ( Boolean.TRUE.equals( isMTInstance ) ) {
                query = SMUtils.getDBQuery( DBQueryFor.TEACHER, "getLObyStandard_mt.sql" );
            } else {
                query = SMUtils.getDBQuery( DBQueryFor.TEACHER, "getLObyStandard.sql" );
            }
        }
        String bankID = "";
        String loID = "";
        List<String> loIds = new ArrayList<String>();
        query = query.replace( "<standard_id>", standID ).replace( "<grade_id>", gradeID );
        List<Object[]> result = SQLUtil.executeQuery( query );
        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                bankID = list[0].toString();
                loID = list[1].toString();
            }
        }
        String[] splitIndividualID = loID.split( ";" );
        for ( int loCount = 0; loCount < 1; loCount++ ) {
            loIds.add( splitIndividualID[loCount] + "_" + bankID );
        }
        return loIds;
    }

    /**
     * @param dashboard
     * @param courseType
     * 
     * @return
     * @throws IOException
     */
    public static List<String> getRandomStandardGradeID( String dashboard, String courseType, Boolean isMTInstance ) throws IOException {
        String query = null;
        if ( dashboard.equalsIgnoreCase( "Admin" ) ) {
            if ( Boolean.TRUE.equals( isMTInstance ) ) {
                query = SMUtils.getDBQuery( DBQueryFor.ADMIN, "getRandomStandards_mt.sql" );
            } else {
                query = SMUtils.getDBQuery( DBQueryFor.ADMIN, "getRandomStandards.sql" );
            }
        } else {
            if ( Boolean.TRUE.equals( isMTInstance ) ) {
                query = SMUtils.getDBQuery( DBQueryFor.TEACHER, "getRandomStandards_mt.sql" );
            } else {
                query = SMUtils.getDBQuery( DBQueryFor.TEACHER, "getRandomStandards.sql" );
            }
        }
        List<String> standardDetails = new ArrayList<String>();
        if ( courseType.equalsIgnoreCase( "MATH" ) ) {
            query = query.replace( "<subjectID>", "1" );
        } else {
            query = query.replace( "<subjectID>", "4" );
        }

        List<Object[]> result = SQLUtil.executeQuery( query );
        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                standardDetails.add( list[0].toString() );
                standardDetails.add( list[1].toString() );
            }
        }
        Log.message( "Selected Standard => " + standardDetails.get( 0 ) );
        return standardDetails;
    }
}
