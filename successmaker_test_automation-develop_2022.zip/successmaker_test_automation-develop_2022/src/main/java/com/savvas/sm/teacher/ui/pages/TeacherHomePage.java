package com.savvas.sm.teacher.ui.pages;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.HelpPage_AnnoucementPageTitles;
import com.savvas.sm.common.utils.Constants.HomePageWidgetConstants;
import com.savvas.sm.common.utils.Constants.UsageGoal;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class TeacherHomePage extends LoadableComponent<TeacherHomePage> {

    private WebDriver driver;
    boolean isPageLoaded;
    public TopNavBar topNavBar;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    // ********* SuccessMaker Home Page Elements ***************
    @IFindBy ( how = How.CSS, using = "cel-platform-navbar.hydrated", AI = false )
    public WebElement topNavBarwithShadow;

    @IFindBy ( how = How.CSS, using = ".layout-one .layout-heading", AI = false )
    public WebElement coursesWidgetTitle;
    
//    @IFindBy ( how = How.CSS, using = "div.layouts-part-one > div.card.layouts.layout-one > div.layout-heading", AI = false )
//    public WebElement coursesWidgetTitle;
    
    @FindBy ( css = ".course-row:nth-of-type(1) .tile,.course-row:nth-of-type(2) .tile" )
    List<WebElement> coursesParent;

    @IFindBy ( how = How.CSS, using = "div.course-widget-view-all a.view-all-link", AI = false )
    public WebElement viewAllLink;

    @FindBy ( css = "span.tile__info" )
    List<WebElement> createdUpdatedDate;

    @FindBy ( css = ".tile__body .tile__tooltip" )
    List<WebElement> coursetiles;

    @IFindBy ( how = How.CSS, using = "div.dialog-header", AI = false )
    public WebElement dialogHeader;

    @FindBy ( css = "cel-button.cel-button-assign" )
    List<WebElement> rootAsignBnt;

    @IFindBy ( how = How.CSS, using = "cel-toggle-button.toggle-button", AI = false )
    public WebElement usageToggleBtnRoot;

    @IFindBy ( how = How.CSS, using = "student-usage div.student-usage div.zero-state-content", AI = false )
    public WebElement lblstudentUsagechartForZeroState;

    @FindBy ( css = "student-usage span.week" )
    List<WebElement> lblUsageFields;

    @FindBy ( css = "student-usage svg.legend-font g" )
    List<WebElement> lblStudentUsageLegends;

    @IFindBy ( how = How.CSS, using = "student-usage svg g#yaxis text.axis-label", AI = false )
    public WebElement lblYaxis;

    @IFindBy ( how = How.CSS, using = "student-usage svg g#xaxis text.axis-label", AI = false )
    public WebElement lblXaxis;

    @FindBy ( css = "student-usage g#xaxis g.tick text" )
    List<WebElement> lblXaxisIntervals;

    @FindBy ( css = "student-usage g#yaxis g.tick text" )
    List<WebElement> lblYaxisIntervals;

    @FindBy ( css = "student-usage app-chart svg  g[fill ='#32325D'] rect" )
    List<WebElement> readingBars;

    @FindBy ( css = "student-usage app-chart svg  g[fill ='#9ECA47'] rect" )
    List<WebElement> mathBars;

    @FindBy ( css = "student-usage app-chart svg  g[fill]:not([fill='none'])" )
    List<WebElement> mathandReadingBars;

    @IFindBy ( how = How.CSS, using = "student-usage app-chart svg  g#recttooltip_charts text", AI = false )
    public WebElement toolTipUsageChart;

    @IFindBy ( how = How.CSS, using = "student-widget.student-widget cel-multi-check-dropdown", AI = false )
    public WebElement studentUsageAssignmentDropdownRoot;

    @IFindBy ( how = How.CSS, using = "student-widget cel-button.apply-button", AI = false )
    public WebElement btnUsageApplyFilterRoot;

    @IFindBy ( how = How.CSS, using = ".col-md-2 cel-icon.dropdown-select-caret", AI = false )
    public WebElement masterySubjectDropDown;

    @IFindBy ( how = How.CSS, using = ".col-md-5 cel-icon.dropdown-select-caret", AI = false )
    public WebElement masterySkillsDropDown;

    @FindBy ( css = ".col-md-2 .dropdown-option-label" )
    List<WebElement> subjectList;

    @FindBy ( css = ".col-md-2 li[aria-selected='false'] .dropdown-option-label" )
    List<WebElement> masterySubjectList;

    @IFindBy ( how = How.CSS, using = ".col-md-2 .dropdown-select-label", AI = false )
    public WebElement masterySubjectDropdown;

    @FindBy ( css = ".col-md-5 cel-dropdown-select div[aria-hidden='false'] li" )
    List<WebElement> skillList;

    @IFindBy ( how = How.CSS, using = ".col-md-4 cel-multi-check-dropdown.hydrated", AI = false )
    public WebElement assignmentDropdownBtn;

    @IFindBy ( how = How.CSS, using = "div[class='col-2 pl-0'] cel-button.hydrated", AI = false )
    public WebElement applyFilterBtnHost;

    @IFindBy ( how = How.CSS, using = "cel-tile.custom-course-widget-tile img[alt='Math']", AI = false )
    public WebElement ruleforCourseicon;

    @IFindBy ( how = How.CSS, using = "div.tile__body span", AI = false )
    public WebElement courseDetails;

    // Usage Goals
    @IFindBy ( how = How.CSS, using = "usage-goals div.header div.cell-tooltip span", AI = false )
    public WebElement lblUsageGoalSubjectHeader;

    @IFindBy ( how = How.CSS, using = "usage-goals div.header div.lastname span", AI = false )
    public WebElement lblUsageGoalHeader;

    @IFindBy ( how = How.CSS, using = "a.header-back-link", AI = false )
    public WebElement btnBackIconInUsageGoalStudentPage;

    @FindBy ( css = "usage-goals table thead tr th span.d-inline-flex" )
    List<WebElement> lblColumnHeaders;

    @FindBy ( css = "td.table-cell" )
    List<WebElement> lblstudentNames;

    @FindBy ( css = "tbody tr.table-row" )
    List<WebElement> tableRow;

    @FindBy ( css = ".mastery-inner-container .mastery-column" )
    List<WebElement> performanceColumns;

    @FindBy ( css = ".mastery-inner-container .mastery-column .badge-container cel-badge" )
    List<WebElement> performanceNumber;

    @IFindBy ( how = How.CSS, using = "div.zero-state-wrapper", AI = false )
    public WebElement zeroStateWrapper;

    @IFindBy ( how = How.CSS, using = "div.zero-state-content", AI = false )
    public WebElement zeroStateContent;

    @IFindBy ( how = How.CSS, using = "cel-button[class=\"secondary-button hydrated\"]", AI = false )
    public WebElement continueToAssignMSDAPopup;

    @FindBy ( css = "span.tile__info" )
    List<WebElement> CustomCourseWithDateAssigned;
    
    @FindBy (how = How.CSS, using = "div.widget-height > div > cel-tile.custom-assignment-widget-tile > div.tile")
    List <WebElement> AssignmentsWidgetList;

    private String topNavStudentMenuCSSSelector = "#Students";
    private String topNavGroupMenuCSSSelector = "#Groups";
    private String topNavCoursewareMenuCSSSelector = "a#Courseware";
    private String coursewareMenuItemsCSSSelectorwithShadow = "cel-dropdown-menu-box.hydrated";
    private String coursesSubMenuItemCSSSelector = "ul li:nth-child(2) a";
    private String userProfileMenuCSSSelector = ".platform__navbar--dropdown-menu";
    private String userProfileDropdownTriggerCSSSelector = ".dropdown-trigger";
    private String userProfileDropdownMenuItemsCSSSelector = "cel-dropdown-menu-box.hydrated";
    private String signOutMenuItemCSSSelector = "ul li:nth-child(4)";
    private String courseTitleCSS = ".tile__body .tile__tooltip";
    private String courseTypeCSS = ".tile__tag";
    private String courseAssignBtnCSSShadow = ".tile__button>.cel-button-assign";
    private String caretSymbol = ".icon-inner";

    private String childAssignBtn = ".primary_button";
    private String usageGoalsChild = "button[aria-pressed='false']";
    private String selectAllCheckBoxChild = "div input";
    private String ruleforCourse = "cel-tile.custom-course-widget-tile img[alt='%s']";
    private String txtStudentUsageHeader = "div.toggle-button button[aria-pressed='true']";
    private String txtindividualField = "span.hours";
    private String btnExpandAssignmentDropdownchild = "button.dropdown-head";
    private String chbxSelectALLAssignmentDropdownParentRoot = "div.dropdown-all-select cel-checkbox.hydrated";
    private String chbxAssignmentDropdownParentRoot = "ul.dropdown-list-items cel-checkbox.hydrated";
    private String chbxAssignmentDropdownChild = "span.checkbox__custom";
    private String lblAssignmentName = "div.primary__checkbox";
    private String btnUsageApplyFilterChild = "button.primary_button";
    private String txtDropDownValue = "a span";
    private String assignmentLabel = "span[class='head-label']";
    private String assignmentSubList = "ul.dropdown-list-items li.dropdown-item .hydrated";
    private String individualAssignmentLabel = "label.checkbox__label";
    private String checkBoxAssignment = ".dropdown-list-head li cel-checkbox.hydrated";
    private String checkBoxAssignmentParent = ".dropdown-list-items li cel-checkbox.hydrated";
    private String inputTag = "input";
    private String performanceHeader = ".mastery-home-header";
    private String performanceBadge = ".badge-container cel-badge";
    private String zeroStatePage = ".projected p.message";
    private String divTag = "div>span";

    private String tableColumn = "td";
    private String lblGoalStatus = "td span.status-heading";
    private String lblStudentName = "td.table-cell";
    private String chbxForStudentsInUsageGoal = "td cel-checkbox";

    // ********* SuccessMaker Home Page Elements ***************

    private String courseAssignBtnCSS = ".primary_button";

    @IFindBy ( how = How.CLASS_NAME, using = "view-all-link", AI = false )
    public WebElement viewAllCourses;

    @IFindBy ( how = How.CSS, using = ".layout-two>.layout-heading", AI = false )
    public WebElement announcementWidgetTitle;

    @IFindBy ( how = How.CSS, using = ".layout-three>.layout-heading", AI = false )
    public WebElement masteryWidgetTitle;

    @IFindBy ( how = How.CSS, using = ".layout-assignment-four .layout-heading", AI = false )
    public WebElement assignmentsWidgetTitle;

    @IFindBy ( how = How.CSS, using = "div[class='assignment-widget-view-all'] span", AI = false )
    public WebElement assignmentsWidgetViewAll;

    @IFindBy ( how = How.CSS, using = ".col-10.assignment-heading.pl-0", AI = false )
    public WebElement assignmentsPageTitle;

    @IFindBy ( how = How.CSS, using = ".layout-five .student-widget", AI = false )
    public WebElement studentUsageWidgetTitle;

    @IFindBy ( how = How.CSS, using = "div.layout-six h1.heading", AI = false )
    public WebElement didYouknowWidgetTitle;

    @IFindBy ( how = How.CSS, using = "div cel-toggle-button", AI = false )
    public WebElement usageGoalsToggleRoot;

    @IFindBy ( how = How.CSS, using = "div:nth-child(1)>div.title-block.row button", AI = false )
    public WebElement mathUsageGoals;

    @IFindBy ( how = How.CSS, using = "div:nth-child(2)>div.title-block.row button", AI = false )
    public WebElement readingUsageGoals;

    @IFindBy ( how = How.CSS, using = "th.th-check cel-checkbox", AI = false )
    public WebElement goalsSelectAllCheckbox;

    @IFindBy ( how = How.CSS, using = "div.child-container cel-button", AI = false )
    public WebElement btnEditUsageGoals;

    @FindBy ( css = "div.widget-height div.row cel-tile.custom-assignment-widget-tile div.tile div.tile__body span.tile__title" )
    List<WebElement> listofAssignmentsInWidget;

    @FindBy ( css = "div.widget-height div.row cel-tile.custom-assignment-widget-tile div.tile div.tile__body span.tile__title > span" )
    List<WebElement> listofAssignmentsTootltipInWidget;

    @IFindBy ( how = How.CSS, using = "div.widget-height div.row:nth-of-type(1) div.tile__body>span:nth-of-type(1)", AI = false )
    public WebElement firstAssignmentInWidget;

    @IFindBy ( how = How.CSS, using = "div.tile__body>span:nth-of-type(1)", AI = false )
    public WebElement assignmentTitleInDetailsPage;

    @IFindBy ( how = How.CSS, using = "div[class='col custom-course-widget-container course-widget-view-all'] span", AI = false )
    public WebElement viewAllTitle;

    @IFindBy ( how = How.CSS, using = "div.tile__body>span:nth-of-type(1) > span", AI = false )
    public WebElement assignmentTooltipTitleInDetailsPage;

    // To fetch the first assignment student's count from the Home page Assignment
    // widget

    @IFindBy ( how = How.CSS, using = "div.widget-height div.row:nth-of-type(1) div.tile__body>span:nth-of-type(2)", AI = false )
    public WebElement firstAssignmentInWidgetByStudentCount;

    @IFindBy ( how = How.CSS, using = "div.layout-assignment-four>div.layout-heading", AI = false )
    public WebElement assignmentsWidgetTitleName;

    @FindBy ( css = "div.widget-height div.row div.tile__body>span:nth-of-type(1)" )
    List<WebElement> assignmentsInWidget;

    // To fetch first Assignment from the Home page Assignments widget

    @IFindBy ( how = How.CSS, using = "div.widget-height div.row:nth-of-type(1) div.tile__body>span:nth-of-type(1)>span", AI = false )
    public WebElement firstAssignmentTooltipInWidget;

    // To fetch the first assignment's thumbnail icon from the Home page Assignment
    // widget

    @IFindBy ( how = How.CSS, using = "div.widget-height div.row:nth-of-type(1, AI=false) div.tile .tile__image", AI = false )
    public WebElement firstAssignmentInWidgetByThumbnail;

    // To fetch the Zero state text in Home page Assignment widget

    @IFindBy ( how = How.CSS, using = ".zero-state-placement div.zero-state-container div.zero-state-content .header", AI = false )
    public WebElement zeroStateTextAssignmentWidget;

    // To fetch the 'View All' link in Home page Assignment widget
    @IFindBy ( how = How.CSS, using = ".assignment-widget-view-all>.view-all-link", AI = false )
    public WebElement viewAllLinkInAssignmentWidget;

    // To get separator line in assignment widget
    @IFindBy ( how = How.CSS, using = "div.widget-height div.row:nth-of-type(1) hr.line-seperator", AI = false )
    public WebElement firstSeperatorLine;

    @IFindBy ( how = How.CSS, using = ".view-all-mastery-link", AI = false )
    public WebElement viewAllLinkMasteryWidget;

    @IFindBy ( how = How.CSS, using = "#mc-main-content > h1", AI = false )
    public WebElement coursesHelpPageHeader;

    @IFindBy ( how = How.CSS, using = "#mc-main-content > h1", AI = false )
    public WebElement masteryHelpPageHeader;

    @IFindBy ( how = How.CSS, using = "#mc-main-content > h1", AI = false )
    public WebElement assignementPageHelpPageHeader;

    @IFindBy ( how = How.CSS, using = "#mc-main-content > h1", AI = false )
    public WebElement groupsPageHelpPageHeader;

    @IFindBy ( how = How.CSS, using = "#mc-main-content > h1", AI = false )
    public WebElement studentsPageHelpPageHeader;

    @IFindBy ( how = How.CSS, using = "#mc-main-content > h1", AI = false )
    public WebElement homePageHelpPageHeader;

    @IFindBy ( how = How.CSS, using = "announcements-widget div a", AI = false )
    public WebElement announcementViewAllLink;

    @IFindBy ( how = How.CSS, using = "a[class='view-all-announcements-link']", AI = false )
    public WebElement announcementWidgetViewAllLink;

    @IFindBy ( how = How.CSS, using = "announcements-widget div.announcements-content", AI = false )
    public WebElement announcementWidgetContent;

    @FindBy ( css = "announcements-widget div.announcements-content p" )
    List<WebElement> announcementTextContent;

    @IFindBy ( how = How.CSS, using = "div.main-content h2", AI = false )
    public WebElement successmakerAnnouncementExternalPageHeader;

    @IFindBy ( how = How.CSS, using = "div.main-section P", AI = false )
    public WebElement successmakerAnnouncementExternalSiteContent;

    @IFindBy ( how = How.CSS, using = "div.main-section h4", AI = false )
    public WebElement successmakerAnnouncementExternalSiteContentHeader;

    @FindBy ( css = "div.main-section P" )
    List<WebElement> successmakerAnnouncementExternalSiteTextContent;

    @IFindBy ( how = How.CSS, using = "div.dialog-header h1 ", AI = false )
    public WebElement sessionEndPopupHeader;

    @IFindBy ( how = How.CSS, using = "div.content a", AI = false )
    public WebElement didYouKnowTextContentLink;

    @FindBy ( css = "div.content" )
    List<WebElement> didYouKnowTextContent;

    @IFindBy ( how = How.CSS, using = "div.cap-qtr img", AI = false )
    public WebElement didYouKNowMySavvasTraininglink;

    // Goals usage Elements.

    @FindBy ( css = "div[class='usage-title col-md-4']" )
    List<WebElement> golsHeaders;

    @IFindBy ( how = How.CSS, using = "div[class='usage-goals-note text-right']", AI = false )
    public WebElement goalsHint;

    @FindBy ( css = "cel-multi-part-progress-bar.hydrated" )
    List<WebElement> goalsBar;

    @FindBy ( css = "div.sub-section" )
    List<WebElement> goalsSubjectSection;

    @IFindBy ( how = How.CSS, using = ".usage-goals-wrapper h3", AI = false )
    public WebElement usageGoalsZeroState;

    @IFindBy ( how = How.CSS, using = ".usage-goals-wrapper span", AI = false )
    public WebElement usageGoalsZeroStateMessage;

    @IFindBy ( how = How.CSS, using = "cel-button[class='apply-button hydrated']", AI = false )
    public WebElement applyFilterHost;

    private static String goalsLegendValues = "div.legend-value";
    private static String goalsLegends = "div.legend-text";
    private static String goalsUsageTitles = "div[class = 'usage-title col-md-4']";
    private static String goalsColorRoot = "cel-multi-part-progress-bar.hydrated";
    private static String goalsColorChild = "div[class='multi-part-progress-bar'] button";
    private static String applyFilterRoot = "button.primary_button";
    private static String button = "button";
    // Filters
    @IFindBy ( how = How.CSS, using = "button[aria-expanded='false'] cel-icon", AI = false )
    public WebElement filtersShodowHost;

    // Filters child css
    public static String filtersCss = "img[alt='icon caret right']";

    public TeacherHomePage() {}

    public TeacherHomePage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
        topNavBar = new TopNavBar( driver );
    }

    @Override
    protected void isLoaded() {

        if ( !isPageLoaded ) {
            Assert.fail();
        }
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }

        if ( SMUtils.waitForElement( driver, topNavBarwithShadow, 30 ) ) {
            Log.message( "SM Teacher home page loaded successfully." );
        } else {
            Log.fail( "SM Teacher home page did not load." );
        }
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, topNavBarwithShadow );
    }

    /**
     * Checks and returns the visibility state of Courses Widget
     *
     * @return
     */
    public boolean isCoursesWidgetDisplayed() {
        //SMUtils.fluentWaitForElement( driver, coursesWidgetTitle );
        SMUtils.waitForElement(driver, coursesWidgetTitle, 30);
        return coursesWidgetTitle.isDisplayed();
    //	return coursesWidgetTitle.getText().trim().equals(HelpPage_AnnoucementPageTitles.COURSESHELPPAGETITLE);
    }

    /**
     * Checks and returns the visibility state of Announcement Widget
     *
     * @return
     */
    public boolean isAnnouncementWidgetDisplayed() {
        if ( announcementWidgetTitle.getText().trim().equals( Constants.HomePageWidgetConstants.ANNOUNCEMENT_HEADER ) ) {
            Log.message( "Announcement Widget Header" + announcementWidgetTitle.getText() );
            return announcementWidgetTitle.isDisplayed();
        } else {
            Log.message( "Announcement Header is incorrect" );
            return false;
        }
    }

    /**
     * Checks and returns the visibility state of Announcement Widget Content
     *
     * @return
     */
    public boolean isAnnouncementWidgetContentDisplayed() {
        return announcementWidgetContent.isDisplayed();

    }

    /**
     * Checks and returns the visibility state of Announcement Widget View All
     * link
     *
     * @return
     */
    public boolean isAnnouncementWidgetViewAllDisplayed() {
        return announcementViewAllLink.isDisplayed();

    }

    /**
     * Checks and returns the visibility state of Announcement Widget Content
     * date
     *
     * @return
     */
    public boolean isAnnouncementWidgetTextContentDisplayed() {
        for ( WebElement textContent : announcementTextContent ) {
            Log.message( "Announcement Widget Content is " + textContent.getText() );
        }
        return announcementWidgetContent.isDisplayed();
    }

    /**
     * To get announcement Content
     *
     * @return
     */
    public List<String> getAnnouncementWidgetTextContent() {
        List<String> textContents = new ArrayList<>();
        for ( WebElement textContent : announcementTextContent ) {
            textContents.add( textContent.getText().trim().replace( "  ", " " ) );
            Collections.sort( textContents );
            Log.message( "Announcement Widget Contents From Home tab are:" + textContents );
        }
        return textContents;
    }

    /**
     * To click View all Link
     *
     */
    public void clickViewALL() {
        SMUtils.waitForElement( driver, announcementViewAllLink );
        SMUtils.clickJS( driver, announcementViewAllLink );
        Log.message( "Clicked View all Link!" );
    }

    /**
     * To click View all Link in Announcement Widget
     *
     */
    public void clickViewALLInAnnouncementWidget() {
        SMUtils.waitForElement( driver, announcementWidgetViewAllLink );
        SMUtils.clickJS( driver, announcementWidgetViewAllLink );
        Log.message( "Clicked View all Link in Announcement Widget!" );
    }

    /**
     * Checks the visibility state of SuccessMaker Announcement help page
     *
     * @return
     */
    public boolean isSuccessmakerAnnouncementHelpPageDisplayed() {
        SMUtils.waitForElement( driver, successmakerAnnouncementExternalPageHeader );
        return successmakerAnnouncementExternalPageHeader.isDisplayed();
    }

    /**
     * Checks and returns the visibility state of SuccessMaker Announcement
     * External site Content
     *
     * @return
     */
    public List<String> getSuccessmakerAnnouncementExternalSiteTextContent() {
        SMUtils.waitForElement( driver, successmakerAnnouncementExternalSiteContent );
        List<String> accounmentContentFromHelp = new ArrayList<>();
        int iter = 0;
        while ( iter < 2 ) {
            accounmentContentFromHelp.add( successmakerAnnouncementExternalSiteTextContent.get( iter ).getText().trim() );
            iter++;
        }
        accounmentContentFromHelp.add( successmakerAnnouncementExternalSiteContentHeader.getText().trim().replace( "  ", " " ) );
        Collections.sort( accounmentContentFromHelp );
        Log.message( "Announcement Content From External Site are: " + accounmentContentFromHelp );
        return accounmentContentFromHelp;
    }

    /**
     * Checks the visibility state of Session End Popup
     *
     * @return
     */
    public boolean isSessionEndPopupDisplayed() {
        SMUtils.waitForElement( driver, sessionEndPopupHeader );
        return sessionEndPopupHeader.isDisplayed();
    }

    /**
     * Checks and returns the visibility state of Mastery Widget
     *
     * @return
     */
    public boolean isMasteryWidgetDisplayed() {
        return masteryWidgetTitle.isDisplayed();
    }

    /**
     * Checks and returns the visibility state of Assignment Widget
     *
     * @return
     */
    public boolean isAssignmentWidgetDisplayed() {
        return assignmentsWidgetTitle.isDisplayed();
    }

    /**
     * To click View all Link in Assignment Widget
     *
     */
    public void clickViewALLInAssignmentWidget() {
        SMUtils.waitForElement( driver, assignmentsWidgetViewAll );
        SMUtils.clickJS( driver, assignmentsWidgetViewAll );
        Log.message( "Clicked View all Link in Assignment Widget!" );
    }

    /**
     * Checks and returns the visibility state of Student Usage Widget
     *
     * @return
     */
    public boolean isStudentUsageWidgetDisplayed() {
        return studentUsageWidgetTitle.isDisplayed();
    }

    /**
     * Checks and returns the visibility state of Did you Know Widget
     *
     * @return
     */
    public boolean isDidYouKnowWidgetDisplayed() {
        return didYouknowWidgetTitle.isDisplayed();
    }

    /**
     * Checks and returns the visibility state of View All in Home Page Course
     * Widget
     *
     * @return
     */
    public boolean isViewAllDisplayed() {
        return viewAllTitle.isDisplayed();
    }

    /**
     * Get Did You Know Widget title web element
     *
     * @return
     */
    public WebElement getDidYouKnowTitle() {
        return didYouknowWidgetTitle;
    }

    /**
     * Checks and returns the visibility state of Did you know widget content
     * link
     *
     * @return
     */
    public boolean isDidYouKnowContentLinkDisplayed() {
        Log.message( "Checking visibility of Content Link is get displayed" );
        return didYouKnowTextContentLink.isDisplayed();

    }

    /**
     * Checks and returns the visibility state of Did you know widget Content
     * date
     *
     * @return
     */
    public boolean isDidYouKnowTextContentDisplayed() {
        for ( WebElement textContent : didYouKnowTextContent ) {
            Log.message( "Did You Know Widget Content is " + textContent.getText() );
        }
        return didYouKnowTextContent.get( 0 ).isDisplayed();
    }

    /**
     * To get Did you know text content
     *
     * @return
     */
    public List<String> getDidYouKnowTextContent() {
        List<String> textContents = new ArrayList<>();
        for ( WebElement textContent : didYouKnowTextContent ) {
            textContents.add( textContent.getText().trim().replace( "  ", " " ) );
        }
        return textContents;
    }

    /**
     * Get Did You Know Widget "My Savvas Training" link web element
     *
     * @return
     */
    public WebElement getDidYouKnowContentLink() {
        return didYouKnowTextContentLink;
    }

    /**
     * To click my Savvas Training link in Did you know widget
     *
     */
    public void clickDidYouKnowContentLink() {
        SMUtils.waitForElement( driver, didYouKnowTextContentLink );
        SMUtils.clickJS( driver, didYouKnowTextContentLink );
        Log.message( "Clicked my Savvas Training link!" );
    }

    /**
     * Checks the visibility state of My Savvas Training site
     * didYouKNowMySavvasTraininglink
     *
     * @return
     */
    public boolean isMySavvasTrainingPageDisplayed() {
        SMUtils.waitForElement( driver, didYouKNowMySavvasTraininglink );
        return didYouKNowMySavvasTraininglink.isDisplayed();
    }

    /**
     * Alternate method which check the visibility state of My Savvas Training
     * site
     *
     *
     * @return status
     */

    public Boolean isMySavvasTrainingPageGetDisplayed() throws Exception {
        boolean status = false;
        try {
            driver.getCurrentUrl().contains( HomePageWidgetConstants.MYSAVVASTRAININGURL );
            status = true;
            Log.message( "My Savvas Training Page is loaded successfully" );

        } catch ( Exception e ) {
            Log.message( "My Savvas Training Page is not loaded!!" );
            status = false;
        }
        return status;
    }

    /**
     * Assign course from Courses Widget
     */
    public AssignAssignmentPopup assignAnyCourseFromCoursesWidget() {

        WebElement courseParent = coursesParent.get( new Random().nextInt( 2 ) ); // random int is limited to 4

        WebElement courseAssignBtnShowdowElement = SMUtils.getChildWebElementFromParent( courseParent, courseAssignBtnCSSShadow );

        WebElement courseAssignBtn = SMUtils.getWebElement( driver, courseAssignBtnShowdowElement, courseAssignBtnCSS );
        SMUtils.clickJS( driver, courseAssignBtn );

        return new AssignAssignmentPopup( driver );
    }

    /**
     * Assign custom course from Courses Widget
     */
    public List<String> getCustomCoursesNameFromCoursesWidget() {
        List<String> customCourses = new ArrayList<>();
        for ( WebElement courseParent : coursesParent ) {
            WebElement courseTypeElement = SMUtils.getChildWebElementFromParent( courseParent, courseTypeCSS );
            if ( courseTypeElement.getText().trim().equals( "My Custom Course" ) ) {
                WebElement courseTitleElement = SMUtils.getChildWebElementFromParent( courseParent, courseTitleCSS );
                customCourses.add( courseTitleElement.getText().trim() );
                Log.message( "Getting custom CourseFrom Coursewidget" );
            }
        }

        return customCourses;
    }

    /**
     * Assign custom course from Courses Widget
     */
    public AssignAssignmentPopup assignCustomCourseFromCoursesWidget( String customCourseName ) {
        SMUtils.nap( 1 );// This need to load homepage
        for ( WebElement courseParent : coursesParent ) {
            WebElement courseTypeElement = SMUtils.getChildWebElementFromParent( courseParent, courseTypeCSS );
            if ( courseTypeElement.getText().equals( "My Custom Course" ) ) {
                WebElement courseTitleElement = SMUtils.getChildWebElementFromParent( courseParent, courseTitleCSS );
                if ( courseTitleElement.getText().trim().equals( customCourseName ) ) {
                    WebElement courseAssignBtnShowdowElement = SMUtils.getChildWebElementFromParent( courseParent, courseAssignBtnCSSShadow );

                    WebElement courseAssignBtn = SMUtils.getWebElement( driver, courseAssignBtnShowdowElement, courseAssignBtnCSS );
                    SMUtils.clickJS( driver, courseAssignBtn );
                    SMUtils.nap( 0.5 );
                    break;
                }
            }
        }

        return new AssignAssignmentPopup( driver );
    }

    /**
     * Gets and returns the Assign course btn from Courses Widget
     */
    public List<WebElement> getAssignBtnFromCoursesWidget() {
        List<WebElement> assignBtn = new ArrayList<>();
        for ( WebElement courseParent : coursesParent ) {
            WebElement courseAssignBtnShowdowElement = SMUtils.getChildWebElementFromParent( courseParent, courseAssignBtnCSSShadow );

            WebElement courseAssignBtn = SMUtils.getWebElement( driver, courseAssignBtnShowdowElement, courseAssignBtnCSS );
            assignBtn.add( courseAssignBtn );
        }

        return assignBtn;
    }

    /**
     * Gets and returns the available course titles
     *
     * @return
     */
    public List<String> getCourseTitleFromCoursesWidget() {
        SMUtils.nap( 0.5 );// This is required to load page
        List<String> courseTitles = new ArrayList<>();
        for ( WebElement courseParent : coursesParent ) {
            WebElement courseTitleElement = SMUtils.getChildWebElementFromParent( courseParent, courseTitleCSS );
            courseTitles.add( courseTitleElement.getText().trim() );
        }
        return courseTitles;
    }

    /**
     * Gets and returns the available course assigned date
     *
     * @return
     */
    public List<String> getCourseAssignedDateFromCoursesWidget() {
        List<String> courseAssignedDate = new ArrayList<>();
        for ( WebElement Course : CustomCourseWithDateAssigned ) {
            courseAssignedDate.add( Course.getText().replace( "Assigned on ", "" ) );
        }

        return courseAssignedDate;
    }

    /**
     * Gets and returns the available course types
     *
     * @return
     */
    public StudentsPage navigateToStudentTab() {
        WebElement masteryTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavStudentMenuCSSSelector );
        masteryTab.click();

        StudentsPage studentsPage = new StudentsPage( driver ).get();

        Log.message( "Navigated to Student Tab", driver, true );

        return studentsPage;

    }

    /***
     * Navigate to Groups Tab
     *
     * @return
     */
    public GroupPage navigateToGroupsMenu() {
        WebElement masteryTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavGroupMenuCSSSelector );
        masteryTab.click();

        GroupPage groupPage = new GroupPage( driver ).get();

        Log.message( "Navigated to Groups Tab", driver, true );

        return groupPage;

    }

    public CoursesPage navigateToCourseListingPage() {
        SMUtils.waitForElement( driver, topNavBarwithShadow );
        WebElement couserwareMenu = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavCoursewareMenuCSSSelector );
        SMUtils.click( driver, couserwareMenu );
        SMUtils.nap( 0.2 );

        WebElement coursesMenuItemsWithShadow = SMUtils.getWebElement( driver, topNavBarwithShadow, coursewareMenuItemsCSSSelectorwithShadow );
        WebElement coursesMenuItemToClick = SMUtils.getWebElement( driver, coursesMenuItemsWithShadow, coursesSubMenuItemCSSSelector );
        SMUtils.clickJS( driver, coursesMenuItemToClick );
        SMUtils.nap( 2 );

        CoursesPage CoursesPage = new CoursesPage( driver ).get();

        Log.message( "Navigated to course listing page", driver, true );

        return CoursesPage;

    }

    public void signOutfromSM() {
        WebElement userProfileMenuWithShadow = SMUtils.getWebElement( driver, topNavBarwithShadow, userProfileMenuCSSSelector );
        WebElement userProfileDropdownTrigger = SMUtils.getWebElement( driver, userProfileMenuWithShadow, userProfileDropdownTriggerCSSSelector );
        userProfileDropdownTrigger.click();
        SMUtils.nap( 0.5 );
        WebElement userProfileDropdownMenuItemsWithShadow = SMUtils.getWebElement( driver, userProfileMenuWithShadow, userProfileDropdownMenuItemsCSSSelector );
        WebElement signOutMenuItem = SMUtils.getWebElement( driver, userProfileDropdownMenuItemsWithShadow, signOutMenuItemCSSSelector );
        signOutMenuItem.click();

        Log.message( "Clicked sign out button" );
    }

    /**
     * CourseTypesFromCoursesWidget
     *
     * @return
     */
    public List<String> getCourseTypesFromCoursesWidget() {
        List<String> courseType = new ArrayList<>();
        for ( WebElement courseParent : coursesParent ) {
            WebElement courseTitleElement = SMUtils.getChildWebElementFromParent( courseParent, courseTypeCSS );
            courseType.add( courseTitleElement.getText().trim() );
        }
        return courseType;
    }

    /***
     *
     * @param imgRuleCourse
     * @param courseName
     * @return This method will return rule for course
     */
    public String getCourseRule( String imgRuleCourse, String courseName ) {

        if ( getCourseTitleFromCoursesWidget().equals( courseName ) ) {
            WebElement coureElement = driver.findElement( By.cssSelector( String.format( ruleforCourse, courseName ) ) );
            String ruleforCourse = coureElement.getAttribute( "src" );

            if ( ruleforCourse.contains( imgRuleCourse ) ) {
                Log.message( "Rule for course is available" );
            }

        }
        return imgRuleCourse;
    }

    /**
     * To Navigate Math Usage Goals Edit Page
     *
     * @return
     */
    public EditUsageGoalsPopupPage navigateToMathEditGoalsPopup() {
        WebElement usageGoals = SMUtils.getWebElement( driver, usageGoalsToggleRoot, usageGoalsChild );
        SMUtils.clickJS( driver, usageGoals );
        SMUtils.waitForElementToBeClickable( mathUsageGoals, driver );
        SMUtils.clickJS( driver, mathUsageGoals );
        SMUtils.waitForElementToBeClickable( goalsSelectAllCheckbox, driver );
        WebElement element = SMUtils.getWebElement( driver, goalsSelectAllCheckbox, selectAllCheckBoxChild );
        SMUtils.clickJS( driver, element );
        SMUtils.clickJS( driver, btnEditUsageGoals );
        SMUtils.nap( 1 ); // Wait for edit popup to load
        EditUsageGoalsPopupPage editGoals = new EditUsageGoalsPopupPage( driver ).get();
        Log.message( "Navigated to Math Edit Goals popup" );
        return editGoals;

    }

    /**
     * To Navigate Reading Usage goals Edit Page
     *
     * @return
     */
    public EditUsageGoalsPopupPage navigateToReadingEditGoalsPopup() {
        WebElement usageGoals = SMUtils.getWebElement( driver, usageGoalsToggleRoot, usageGoalsChild );
        SMUtils.clickJS( driver, usageGoals );
        SMUtils.waitForElementToBeClickable( readingUsageGoals, driver );
        SMUtils.clickJS( driver, readingUsageGoals );
        SMUtils.waitForElementToBeClickable( goalsSelectAllCheckbox, driver );
        WebElement element = SMUtils.getWebElement( driver, goalsSelectAllCheckbox, selectAllCheckBoxChild );
        SMUtils.clickJS( driver, element );
        SMUtils.clickJS( driver, btnEditUsageGoals );
        SMUtils.nap( 1 ); // Wait for edit popup to load
        EditUsageGoalsPopupPage editGoals = new EditUsageGoalsPopupPage( driver ).get();
        Log.message( "Navigated to Reading Edit Goals popup" );
        return editGoals;

    }

    /**
     * @return View all link course widget
     */
    public Boolean isViewAllLinkDisplayed() {
        SMUtils.waitForElement( driver, viewAllLink );

        Log.message( "View All link is displaying" );
        return viewAllLink.isDisplayed();

    }

    /**
     * click on mastery widget viewAll
     */
    public void clickMasteryViewALL() {
        SMUtils.waitForElement( driver, viewAllLinkMasteryWidget, 6 );
        SMUtils.clickJS( driver, viewAllLinkMasteryWidget );
        Log.message( "Clicked View all Link!" );
    }

    /**
     * @return Validate Edited date
     */
    public Boolean isUpdatedDateDisplayed( String lastEdited ) {
        SMUtils.waitForElement( driver, viewAllLink );
        for ( WebElement updatedate : createdUpdatedDate ) {
            if ( updatedate.getText().trim().contains( lastEdited ) ) {
                Log.message( "created or Updated date is displaying" );
                return true;
            }

        }
        return false;
    }

    /**
     * to click on assign button
     */
    public void clickAssignButton() {
        try {
            SMUtils.waitForElement( driver, viewAllLink );
            WebElement assignBtnParent = rootAsignBnt.get( 0 );
            WebElement assignBtn = SMUtils.getWebElement( driver, assignBtnParent, childAssignBtn );
            Log.message( "Click assign button" );
            SMUtils.click( driver, assignBtn );
            Log.message( "Assign course header is displaying" );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

    }

    /**
     * @return dailogue header
     */
    public Boolean isDialougeHeaderDisplayed() {
        SMUtils.waitForElement( driver, dialogHeader );
        Log.message( "Assignments window popup page is diaplaying" );
        return dialogHeader.isDisplayed();
    }

    public String toGetfirstAssignmentInWidget() throws InterruptedException {
        String title;
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, assignmentsWidgetTitle );
        title = listofAssignmentsInWidget.get( 0 ).getText().trim();
        Log.message( "Identified the element: " + title );

        if ( !title.isEmpty() ) {
            return title;
        } else {
            title = listofAssignmentsTootltipInWidget.get( 0 ).getText().trim();
            return title;
        }

    }

    /***
     * To navigate to first assignments details page by clicking Assignment name
     *
     * @return
     */

    public String toNavigateToFirstAssignmentDetails() {

        String title;
        SMUtils.waitForElement( driver, firstAssignmentInWidget );
        SMUtils.clickJS( driver, firstAssignmentInWidget );
        SMUtils.waitForElement( driver, assignmentTitleInDetailsPage );
        title = assignmentTooltipTitleInDetailsPage.getText().trim();

        if ( title.length() != 0 ) {
            return title;
        } else {
            title = assignmentTitleInDetailsPage.getText().trim();
            Log.message( "Assignment name in details page : " + assignmentTitleInDetailsPage.getText().trim() );

            return title;
        }
    }

    public String toNavigateToFirstAssignmentDetailsByStudentCount() {

        SMUtils.waitForElement( driver, firstAssignmentInWidget );
        firstAssignmentInWidgetByStudentCount.click();
        SMUtils.waitForElement( driver, assignmentTitleInDetailsPage );
        Log.message( assignmentTitleInDetailsPage.getText() );
        return assignmentTitleInDetailsPage.getText();
    }

    /***
     * To get the all the assignments list in the 'Assignments' widget
     *
     * @return
     */

    public int getAllAssignmentsCountIntheAssignmentWidget() {
        SMUtils.waitForElement( driver, firstAssignmentInWidget );
        int assiCount = assignmentsInWidget.size();
        Log.message( "Assignmnet count is : " + assiCount );
        return assiCount;
    }

    /***
     * To navigate to first assignments details page by clicking Assignment
     * thumbnail icon
     *
     * @return
     */

    public String toNavigateToFirstAssignmentDetailsByThumbnail() {

        SMUtils.waitForElement( driver, firstAssignmentInWidget );
        firstAssignmentInWidgetByThumbnail.click();
        SMUtils.waitForElement( driver, assignmentTitleInDetailsPage );
        Log.message( assignmentTitleInDetailsPage.getText() );
        return assignmentTitleInDetailsPage.getText();
    }

    /***
     * To get the zero state message in Assignments widget
     *
     * @return
     */

    public String toGetZeroStateMessageInAssignmentWidget() {

        SMUtils.waitForElement( driver, zeroStateTextAssignmentWidget );
        Log.message( zeroStateTextAssignmentWidget.getText() );
        return zeroStateTextAssignmentWidget.getText();
    }

    /***
     * To get the availability of 'View All' link in Assignments widget
     *
     * @return
     */

    public Boolean toGetViewAllLinkAvailability() {

        SMUtils.waitForElement( driver, viewAllLinkInAssignmentWidget );
        return viewAllLinkInAssignmentWidget.isDisplayed();
    }

    /***
     * To get the availability of 'View All' link in Assignments widget when no
     * Assignments assigned
     *
     * @return
     */

    public Boolean checkViewAllLinkAvailabilityEmpty() {
        boolean status = false;
        try {
            if ( SMUtils.isElementPresent( viewAllLinkInAssignmentWidget ) ) {
                Log.message( "Element Present in the Page" );
                return status = true;
            }
        } catch ( Exception NoSuchElementException ) {
            status = false;
            Log.message( "Element Not Present on the page" );
        }
        return status;

    }

    /***
     * To get the first assignment's student count from the 'Assignments' widget
     *
     * @return
     * @throws InterruptedException
     */

    public String toGetfirstAssignmentStudentCount() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, firstAssignmentInWidgetByStudentCount );
        Log.message( firstAssignmentInWidgetByStudentCount.getText().trim() );
        return firstAssignmentInWidgetByStudentCount.getText().trim();

    }

    /*
     * To verify zero state for student usage chart
     *
     * @return
     */
    public boolean verifyZeroStateForStudentUsageChart() {
        try {
            SMUtils.waitForElement( driver, lblstudentUsagechartForZeroState );
            WebElement lblheader = SMUtils.getWebElementDirect( driver, usageToggleBtnRoot, txtStudentUsageHeader );
            if ( lblheader.isEnabled() ) {
                if ( lblheader.getText().trim().equals( Constants.UsageChart.STUDENT_USAGE_HEADER ) ) {
                    Log.pass( "Student usage header " + "\"" + Constants.UsageChart.STUDENT_USAGE_HEADER + "\"" + " displayed successfully!" );
                } else {
                    Log.fail( "Student usage header is not displayed properly! - " + lblheader.getText(), driver );
                }
            } else {
                Log.fail( "Student usage header is not selected as default! - " + lblheader.getText(), driver );
            }
            String zeroStateFromUI = lblstudentUsagechartForZeroState.getText().trim();
            if ( zeroStateFromUI.contains( Constants.UsageChart.STUDENTUSAGE_ZEROSTATEMESSAGE.get( 0 ) ) && zeroStateFromUI.contains( Constants.UsageChart.STUDENTUSAGE_ZEROSTATEMESSAGE.get( 1 ) )
                    && zeroStateFromUI.contains( Constants.UsageChart.STUDENTUSAGE_ZEROSTATEMESSAGE.get( 2 ) ) ) {
                Log.pass( "Zero state message is displayed successfully! - " + lblstudentUsagechartForZeroState.getText().trim() );
                return true;
            } else {
                Log.fail( "Zero state message is not displayed successfully! - " + lblstudentUsagechartForZeroState.getText().trim() );
            }

            return false;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify Student usage toggle button is selected
     */
    public String isStudentUsageToggleButtonSelected() {
        List<WebElement> buttons = SMUtils.getAllWebElements( driver, usageGoalsToggleRoot, button );
        WebElement studentUsageToogle = buttons.stream().filter( element -> element.getText().trim().equals( "Student Usage" ) ).findFirst().orElse( null );
        if ( Objects.nonNull( studentUsageToogle ) ) {
            return studentUsageToogle.getAttribute( "aria-pressed" );
        } else {
            return "false";
        }
    }

    /**
     * To verify Math Bar is Displayed or not
     *
     * @return
     */
    public boolean isStudentUsageMathBarDisplayed() {
        SMUtils.waitForElement( driver, lblYaxis );
        return mathBars.stream().anyMatch( WebElement::isDisplayed );
    }

    /**
     * To verify Reading Bar is Displayed or not
     *
     * @return
     */
    public boolean isStudentUsageReadingBarDisplayed() {
        SMUtils.waitForElement( driver, lblYaxis );
        return readingBars.stream().anyMatch( WebElement::isDisplayed );
    }

    /**
     * To get the order of graph
     *
     * @return
     */
    public List<String> getOrderOfSubjectinUsageGraph() {
        List<String> subjectOrder = new ArrayList<>();
        mathandReadingBars.stream().forEach( element -> {
            if ( element.getAttribute( "fill" ).trim().equals( "#32325D" ) ) {
                subjectOrder.add( Constants.READING );
            }
            if ( element.getAttribute( "fill" ).trim().equals( "#9ECA47" ) ) {
                subjectOrder.add( Constants.MATH );
            }
        } );
        return subjectOrder;
    }

    /**
     * To get the Legends in usage chart
     *
     * @return
     */
    public List<String> getLegends() {
        return lblStudentUsageLegends.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To verify field under Student usage chart
     *
     * @return
     */
    public boolean verifyStudentUsageChart() {
        try {
            SMUtils.waitForElement( driver, lblstudentUsagechartForZeroState );
            WebElement lblheader = SMUtils.getWebElementDirect( driver, usageToggleBtnRoot, txtStudentUsageHeader );
            if ( lblheader.getText().trim().equals( Constants.UsageChart.STUDENT_USAGE_HEADER ) ) {
                Log.pass( "Student usage header " + "\"" + Constants.UsageChart.STUDENT_USAGE_HEADER + "\"" + " displayed successfully!" );
            } else {
                Log.fail( "Student usage header is not displayed properly! - " + lblheader.getText(), driver );
            }

            Constants.UsageChart.USAGE_FIELDS.forEach( usageField -> {
                String txtUsageField = lblUsageFields.stream().filter( lblUsageField -> lblUsageField.getText().trim().equals( usageField ) ).map( WebElement::getText ).findAny().orElse( null );
                if ( Objects.nonNull( txtUsageField ) ) {
                    Log.pass( txtUsageField + "  is displayed successfully!" );
                } else {
                    Log.fail( usageField + "  is not displayed properly!" );
                }
            } );

            Constants.UsageChart.LEGENDS.forEach( legend -> {
                String txtlegend = lblStudentUsageLegends.stream().filter( lbllegend -> lbllegend.getText().trim().equals( legend ) ).map( WebElement::getText ).findAny().orElse( null );
                if ( Objects.nonNull( txtlegend ) ) {
                    Log.pass( txtlegend + "  is displayed successfully!" );
                } else {
                    Log.fail( txtlegend + "  is not displayed properly!" );
                }
            } );

            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify data in student usage chart
     *
     * @return
     */
    public boolean verifyStudentUsageChartFieldsData( Map<String, Integer> individualFieldsFromAPI ) {
        try {
            SMUtils.waitForElement( driver, usageToggleBtnRoot );
            Constants.UsageChart.USAGE_FIELDS.forEach( usageField -> {
                WebElement lblUsageField = lblUsageFields.stream().filter( txtUsageField -> txtUsageField.getText().trim().equals( usageField ) ).findAny().get();
                if ( Objects.nonNull( lblUsageField ) ) {
                    WebElement parentElement = lblUsageField.findElement( By.xpath( "./.." ) );
                    WebElement lblValue = parentElement.findElement( By.cssSelector( txtindividualField ) );
                    String actualValueFromUI = lblValue.getText().trim().replace( "  ", " " );
                    int expectedMins = individualFieldsFromAPI.get( usageField );
                    String expectedValue;
                    if ( expectedMins == 0 ) {
                        expectedValue = Constants.UsageChart.ZERO_HOURS;
                    } else if ( expectedMins < 60 ) {
                        expectedValue = Constants.UsageChart.LESS_THAN_ONE_HOUR;
                    } else if ( expectedMins / 60 == 1 && expectedMins % 60 < 30 ) {
                        expectedValue = Constants.UsageChart.ONE_HOUR;
                    } else {
                        if ( expectedMins % 60 < 30 ) {
                            expectedValue = String.valueOf( expectedMins / 60 ) + " " + Constants.UsageChart.HOURS.toLowerCase();
                        } else {
                            expectedValue = String.valueOf( ( expectedMins / 60 ) + 1 ) + " " + Constants.UsageChart.HOURS.toLowerCase();
                        }
                    }
                    if ( actualValueFromUI.equals( expectedValue ) ) {
                        Log.pass( usageField + " - " + lblValue.getText().trim() + " value  is displayed successfully!" );
                    } else {
                        Log.pass( usageField + " - " + lblValue.getText().trim() + " value  is not displayed properly!.Actual - " + expectedValue );
                    }
                } else {
                    Log.fail( usageField + " value is not displayed properly!" );
                }
            } );
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify data in student usage bar
     *
     * @return
     */
    public boolean verifyStudentUsageGraph( Map<String, HashMap<String, Integer>> usageHours ) {
        List<String> xAxisIntervals = getEightWeeksMonday();
        List<Double> yAxisIntervals = getYaxisIntervals( usageHours );
        try {
            SMUtils.waitForElement( driver, lblYaxis );
            if ( lblYaxis.getText().trim().equals( Constants.UsageChart.HOURS ) ) {
                Log.pass( "Y axis label " + "\"" + Constants.UsageChart.HOURS + "\"" + " displayed successfully!" );
            } else {
                Log.fail( "Y axis label is not displayed properly! - " + lblYaxis.getText().trim(), driver );
            }

            if ( lblXaxis.getText().trim().equals( Constants.UsageChart.WEEKS ) ) {
                Log.pass( "X axis label " + "\"" + Constants.UsageChart.WEEKS + "\"" + " displayed successfully!" );
            } else {
                Log.fail( "X axis label is not displayed properly! - " + lblXaxis.getText().trim(), driver );
            }

            xAxisIntervals.forEach( xAxisInterval -> {
                String txtInterval = lblXaxisIntervals.stream().filter( lblXaxisInterval -> lblXaxisInterval.getText().equals( xAxisInterval ) ).map( WebElement::getText ).findAny().orElse( null );
                if ( Objects.nonNull( txtInterval ) ) {
                    Log.pass( txtInterval + "  is present in the x axis intervals!" );
                } else {
                    Log.fail( xAxisInterval + "  is not present in the x axis intervals!" );
                }
            } );

            yAxisIntervals.forEach( yAxisInterval -> {
                String txtInterval = lblYaxisIntervals.stream().filter( lblYaxisInterval -> Double.valueOf( lblYaxisInterval.getText().trim() ) >= yAxisInterval - 0.1 && Double.valueOf( lblYaxisInterval.getText().trim() ) <= yAxisInterval + 0.1 ).map(
                        WebElement::getText ).findAny().orElse( null );
                if ( Objects.nonNull( txtInterval ) ) {
                    Log.pass( txtInterval + "  is present in the y axis intervals!" );
                } else {
                    Log.fail( yAxisInterval + "  is not present in the y axis intervals!" );
                }
            } );

            if ( verifyStudentUsageBarMathData( usageHours ) ) {
                Log.pass( "All math usage hours are displayed properly." );
            } else {
                Log.fail( "Math usage hours are not displayed properly!" );
            }

            if ( verifyStudentUsageBarReadingData( usageHours ) ) {
                Log.pass( "All reading usage hours are displayed properly." );
            } else {
                Log.fail( "Reading usage hours are not displayed properly!" );
            }
            return true;
        } catch (

        Exception e ) {
            return false;
        }
    }

    /**
     * To verify data in student usage bar for math
     *
     * @return
     */
    public boolean verifyStudentUsageBarMathData( Map<String, HashMap<String, Integer>> usageHours ) {
        try {
            List<String> weeks = getEightWeeksMonday();
            Collections.reverse( weeks );
            Iterator<String> weeksList = weeks.iterator();
            Iterator<WebElement> mathBar = mathBars.iterator();
            while ( weeksList.hasNext() && mathBar.hasNext() ) {
                WebElement bar = mathBar.next();
                String week = weeksList.next();
                if ( bar.isDisplayed() ) {
                    SMUtils.moveToElementJS( driver, bar );
                    String actualHoursFromUI = toolTipUsageChart.getText().trim().replace( " Total", Constants.UsageChart.TOTAL );
                    String expectedHours = "Math : " + convertMinutesIntoHours( usageHours.get( week ).get( Constants.UsageChart.MATH ) );
                    expectedHours = expectedHours.trim() + "Total : " + convertMinutesIntoHours( usageHours.get( week ).get( "Total" ) );
                    if ( actualHoursFromUI.equals( expectedHours.trim() ) ) {
                        Log.pass( "Expected math usage hours - " + actualHoursFromUI + " is displayed properly for " + week + " week!", driver );
                    } else {
                        Log.fail( "Expected math usage hours - " + expectedHours + " is not displayed properly for " + week + " week!. Actual - " + actualHoursFromUI, driver );
                    }
                } else {
                    if ( usageHours.get( week ).get( Constants.UsageChart.MATH ) != 0 ) {
                        Log.fail( " Math usage hours is mismatched for " + week, driver );
                    } else {
                        Log.pass( week + " week don't have Math usage data! - Expected" );
                    }
                }
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify data in student usage bar for Reading
     *
     * @return
     */
    public boolean verifyStudentUsageBarReadingData( Map<String, HashMap<String, Integer>> usageHours ) {
        try {
            List<String> weeks = getEightWeeksMonday();
            Collections.reverse( weeks );
            Iterator<String> weeksList = weeks.iterator();
            Iterator<WebElement> readingBar = readingBars.iterator();
            while ( weeksList.hasNext() && readingBar.hasNext() ) {
                WebElement bar = readingBar.next();
                String week = weeksList.next().toString();
                if ( bar.isDisplayed() ) {
                    SMUtils.moveToElementJS( driver, bar );
                    String actualHoursFromUI = toolTipUsageChart.getText().trim().replace( " Total", Constants.UsageChart.TOTAL );
                    String expectedHours = "Reading : " + convertMinutesIntoHours( usageHours.get( week ).get( Constants.UsageChart.READING ) );
                    expectedHours = expectedHours.trim() + "Total : " + convertMinutesIntoHours( usageHours.get( week ).get( Constants.UsageChart.TOTAL ) );
                    if ( actualHoursFromUI.equals( expectedHours.trim() ) ) {
                        Log.pass( "Expected reading usage hours - " + actualHoursFromUI + " is displayed properly for " + week + " week!", driver );
                    } else {
                        Log.fail( "Expected reading usage hours - " + expectedHours + " is not displayed properly for " + week + " week!. Actual - " + actualHoursFromUI, driver );
                    }
                } else {
                    if ( usageHours.get( week ).get( Constants.UsageChart.READING ) != 0 ) {
                        Log.fail( "Reading usage hours is mismatched for " + week, driver );
                    } else {
                        Log.pass( week + " week don't have reading usage data! - Expected" );
                    }
                }
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To convert minutes into hours and minutes
     *
     * @return
     */
    public String convertMinutesIntoHours( int minutes ) {
        String result = "";
        if ( minutes == 60 || minutes / 60 == 1 ) {
            result = result + Constants.UsageChart.ONE_HOUR + " ";
        } else if ( minutes > 60 ) {
            result = result + String.valueOf( minutes / 60 ) + " " + Constants.UsageChart.HOURS.toLowerCase() + " ";
        }
        if ( minutes == 1 ) {
            result = result + Constants.UsageChart.ONE_MINUTE;
        } else if ( minutes % 60 != 0 ) {
            result = result + minutes % 60 + " " + Constants.UsageChart.MINUTES.toLowerCase();
        }

        return result;
    }

    /**
     * To get y axis intervals for student usage
     *
     * @return
     */
    public List<Double> getYaxisIntervals( Map<String, HashMap<String, Integer>> usageHours ) {
        List<String> weeks = getEightWeeksMonday();
        List<Double> yaxisInterval = new ArrayList<>();
        int highestWeekMinFromAPI = weeks.stream().mapToInt( week -> usageHours.get( week ).get( Constants.UsageChart.TOTAL ) ).max().orElse( 0 );
        double highestWeekHourFromAPI = (double) highestWeekMinFromAPI / 60;
        DecimalFormat decimalFormat = new DecimalFormat( "#.#" );
        double interval = 0;
        while ( interval < highestWeekHourFromAPI ) {
            interval = interval + highestWeekHourFromAPI / 4;
            double formattedInterval = Double.valueOf( decimalFormat.format( interval ) );
            yaxisInterval.add( formattedInterval );
        }
        return yaxisInterval;
    }

    /**
     * To get past four weeks Monday
     *
     * @return
     */
    public static List<String> getEightWeeksMonday() {
        List<String> eightWeeksMonday = new ArrayList<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd" );
        Calendar weekStartDate = Calendar.getInstance();
        weekStartDate.setTime( new Date() );
        int iter = 0;
        while ( iter < 8 ) {
            if ( weekStartDate.get( Calendar.DAY_OF_WEEK ) == Calendar.SUNDAY ) {
                weekStartDate.add( Calendar.DATE, -1 );
                weekStartDate.set( Calendar.DAY_OF_WEEK, Calendar.MONDAY );
                eightWeeksMonday.add( dateFormat.format( weekStartDate.getTime() ) );
            } else {
                weekStartDate.set( Calendar.DAY_OF_WEEK, Calendar.MONDAY );
                eightWeeksMonday.add( dateFormat.format( weekStartDate.getTime() ) );
            }
            weekStartDate.add( Calendar.DATE, -7 );
            iter++;
        }
        return eightWeeksMonday;
    }

    /**
     * To Load usage for particular assignments
     *
     */
    public void loadUsageForParticularAssignments( List<String> assignmentsName ) {
        SMUtils.waitForElement( driver, studentUsageAssignmentDropdownRoot );
        WebElement btnExpandDropdown = SMUtils.getWebElementDirect( driver, studentUsageAssignmentDropdownRoot, btnExpandAssignmentDropdownchild );
        // Expand Assignment Dropdown
        SMUtils.clickJS( driver, btnExpandDropdown );

        WebElement chbxSelectALL = SMUtils.getWebElementDirect( driver, studentUsageAssignmentDropdownRoot, chbxSelectALLAssignmentDropdownParentRoot, chbxAssignmentDropdownChild );
        // Clicking Select All Checkbox
        SMUtils.clickJS( driver, chbxSelectALL );

        List<WebElement> dropdownAssignmentsGrantRoot = SMUtils.getAllWebElements( driver, studentUsageAssignmentDropdownRoot, chbxAssignmentDropdownParentRoot );
        List<WebElement> txtAssignmentsName = dropdownAssignmentsGrantRoot.stream().filter(
                dropdownAssignmentGrantRoot -> assignmentsName.contains( SMUtils.getWebElementDirect( driver, dropdownAssignmentGrantRoot, lblAssignmentName ).getText().trim() ) ).map(
                        dropdownAssignmentGrantRoot -> SMUtils.getWebElementDirect( driver, dropdownAssignmentGrantRoot, lblAssignmentName ) ).collect( Collectors.toList() );
        txtAssignmentsName.forEach( txtAssignmentName -> {
            SMUtils.clickJS( driver, txtAssignmentName.findElement( By.cssSelector( chbxAssignmentDropdownChild ) ) );
            Log.message( txtAssignmentName.getText().trim() + " - Assignment Selected" );
        } );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnUsageApplyFilterRoot, btnUsageApplyFilterChild ) );
        Log.message( "Clicked Apply Filter!", driver, true );

    }

    /**
     * To get assignments from assignments dropdown in Student usage widget
     *
     */
    public List<String> getAssignmentsFromUsageWidget() {
        SMUtils.waitForElement( driver, studentUsageAssignmentDropdownRoot );
        WebElement btnExpandDropdown = SMUtils.getWebElementDirect( driver, studentUsageAssignmentDropdownRoot, btnExpandAssignmentDropdownchild );
        // Expand Assignment Dropdown
        SMUtils.clickJS( driver, btnExpandDropdown );

        WebElement chbxSelectALL = SMUtils.getWebElementDirect( driver, studentUsageAssignmentDropdownRoot, chbxSelectALLAssignmentDropdownParentRoot, chbxAssignmentDropdownChild );
        // Clicking Select All Checkbox
        SMUtils.clickJS( driver, chbxSelectALL );

        List<WebElement> dropdownAssignmentsGrantRoot = SMUtils.getAllWebElements( driver, studentUsageAssignmentDropdownRoot, chbxAssignmentDropdownParentRoot );
        return dropdownAssignmentsGrantRoot.stream().map( dropdownAssignmentGrantRoot -> SMUtils.getWebElementDirect( driver, dropdownAssignmentGrantRoot, lblAssignmentName ).getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To verify apply filter button in Student usage widget
     *
     */
    public boolean isApplyFilterDisplayed() {
        Log.message( "Verifying apply filter button" );
        return SMUtils.getWebElementDirect( driver, btnUsageApplyFilterRoot, btnUsageApplyFilterChild ).isDisplayed();
    }

    /**
     * Returns the Course Help Page title
     *
     * @return WebElement
     */
    public WebElement getCoursesHelpPageHeader() {
        return coursesHelpPageHeader;
    }

    /**
     * Returns the Mastery Help Page title
     *
     * @return WebElement
     */
    public WebElement getMasteryHelpPageHeader() {
        return masteryHelpPageHeader;
    }

    /**
     * Returns the Assignment Page Help title
     *
     * @return WebElement
     */
    public WebElement getAssignementPageHelpPageHeader() {
        return assignementPageHelpPageHeader;
    }

    /**
     * Returns the Group Help Page title
     *
     * @return WebElement
     */
    public WebElement getGroupsPageHelpPageHeader() {
        SMUtils.waitForElement( driver, groupsPageHelpPageHeader );
        return groupsPageHelpPageHeader;
    }

    /**
     * Returns the Student Help Page title
     *
     * @return WebElement
     */
    public WebElement getStudentsPageHelpPageHeader() {
        return studentsPageHelpPageHeader;
    }

    /**
     * Returns the Home Help Page title
     *
     * @return WebElement
     */
    public WebElement getHomePageHelpPageHeader() {
        return homePageHelpPageHeader;

    }

    /**
     * Click Course on homepage
     *
     */
    public void clickCourse() {
        SMUtils.waitForElement( driver, ruleforCourseicon );
        SMUtils.clickJS( driver, ruleforCourseicon );
        Log.message( "Clicking on course on homepage" );
    }

    /**
     *
     */
    public Boolean isCourseDisplayed() {
        Log.message( "Course detail are displaying after clicking on course" );
        SMUtils.waitForElement( driver, courseDetails );
        return courseDetails.isDisplayed();
    }

    /**
     * To Navigate Usage Goals Students List
     *
     * @param subjectType
     */
    public void navigateToUsageGoalsStudentsList( String subjectType ) {
        WebElement usageGoals = SMUtils.getWebElement( driver, usageGoalsToggleRoot, usageGoalsChild );
        SMUtils.scrollIntoView( driver, usageGoals );
        SMUtils.clickJS( driver, usageGoals );
        if ( subjectType.equals( Constants.MATH ) ) {
            SMUtils.waitForElementToBeClickable( mathUsageGoals, driver );
            SMUtils.clickJS( driver, mathUsageGoals );
            Log.message( "Navigated to Math usage goal student list page!" );
        } else {
            SMUtils.waitForElementToBeClickable( readingUsageGoals, driver );
            SMUtils.clickJS( driver, readingUsageGoals );
            Log.message( "Navigated to Reading usage goal student list page!" );
        }
    }

    /**
     * To verify Usage Goals Students List Header
     *
     * @param subjectType
     * @return
     */
    public boolean verifyUsageGoalStudentListHeader( String subjectType ) {
        SMUtils.waitForElement( driver, lblUsageGoalSubjectHeader );
        String headerFromUI = lblUsageGoalSubjectHeader.getText().trim() + " " + lblUsageGoalHeader.getText().trim();
        if ( subjectType.equals( Constants.MATH ) && headerFromUI.equals( UsageGoal.USAGE_GOAL_MATH_HEADER ) ) {
            Log.message( "Usage goal-student list header displayed properly for Math assignment - " + headerFromUI );
            return true;
        }
        if ( subjectType.equals( Constants.READING ) && headerFromUI.equals( UsageGoal.USAGE_GOAL_READING_HEADER ) ) {
            Log.message( "Usage goal-student list header displayed properly for Reading assignment - " + headerFromUI );
            return true;
        }
        Log.message( "Usage goal-student list header displayed properly for " + subjectType + " assignment - Actual : " + headerFromUI );
        return false;
    }

    /**
     * To click back icon in usage goal - student list
     *
     */
    public void clickBackIconInUsageGoalStudentListingPage() {
        SMUtils.clickJS( driver, btnBackIconInUsageGoalStudentPage );
        Log.message( "Clicked back icon in student lis" );
    }

    /**
     * To Verify columns name usage goal - student list
     *
     */
    public boolean verifyColumnsInUsageGoalStudentListingPage() {
        boolean isLabelsPresent = UsageGoal.USAG_EGOAL_COLUMNS_HEADER.stream().allMatch( header -> lblColumnHeaders.stream().anyMatch( lblHeader -> {
            if ( lblHeader.getText().trim().equalsIgnoreCase( header ) ) {
                Log.message( "Column header - " + lblHeader.getText().trim() + " displayed properly" );
                return true;
            }
            return false;
        } ) );
        if ( !isLabelsPresent ) {
            Log.message( "Usage goal-student Headers not displayed properly" );
            return false;
        }
        return true;
    }

    /**
     * To get all the Usage Goal - student names from UI
     *
     * @return
     */
    public List<String> getStudentNamesFromUI() {
        SMUtils.waitForLocator( driver, By.cssSelector( lblStudentName ), 5 );
        Log.message( "Getting student names from UI" );
        return lblstudentNames.stream().map( lblStudentName -> lblStudentName.getText().replace( ",  ", " " ).replace( ",", "" ).trim() ).collect( Collectors.toList() );
    }

    /**
     * To get all the Usage Goal status from UI
     *
     * @return
     */
    public Map<String, String> getGoalStatusFromUI() {
        SMUtils.waitForElement( driver, lblUsageGoalSubjectHeader );
        Log.message( "Getting goal status from UI" );
        Map<String, String> studentGoalstatus = new HashMap<>();
        SMUtils.nap( 3 ); // required for usage Goal table load
        tableRow.forEach( parentElement -> {
            studentGoalstatus.put( parentElement.findElement( By.cssSelector( lblStudentName ) ).getText().replace( ",  ", " " ).replace( ",", "" ).trim(),
                    parentElement.findElement( By.cssSelector( lblGoalStatus ) ).getText().trim().replace( "  ", " " ) );
        } );
        return studentGoalstatus;
    }

    /**
     * To get Total Time, Avg Time / Wk, Target Hours and Goal End Date from UI
     *
     * @return
     */
    public Map<String, String> getColumnValuesFromUI( String columnName ) {
        SMUtils.waitForLocator( driver, By.cssSelector( lblStudentName ), 5 );
        Map<String, Integer> columnIndex = new HashMap<>() {
            {
                put( "Total Time", 3 );
                put( "Avg Time / Wk", 4 );
                put( "Target Hours", 5 );
                put( "Goal End Date", 6 );
            }
        };
        Map<String, String> valuesFromUI = new HashMap<>();
        tableRow.forEach( parentElement -> {
            valuesFromUI.put( parentElement.findElement( By.cssSelector( lblStudentName ) ).getText().replace( ",  ", " " ).replace( ",", "" ).trim(),
                    parentElement.findElements( By.cssSelector( tableColumn ) ).get( columnIndex.get( columnName ) ).getText().trim() );
        } );
        return valuesFromUI;
    }

    /**
     * To click check box for student in Usage Goal
     *
     * @return
     */
    public void selectCheckForStudentsinUsageGoal( List<String> studentNames ) {
        SMUtils.waitForLocator( driver, By.cssSelector( lblStudentName ), 5 );
        tableRow.stream().filter( parentElement -> studentNames.contains( parentElement.findElement( By.cssSelector( lblStudentName ) ).getText().replace( ",  ", " " ).replace( ",", "" ).trim() ) ).forEach( parentElement -> {
            WebElement chbxForStudent = SMUtils.getWebElementDirect( driver, parentElement.findElement( By.cssSelector( chbxForStudentsInUsageGoal ) ), selectAllCheckBoxChild );
            SMUtils.clickJS( driver, chbxForStudent );
        } );
        Log.message( "Clicked checkboxes for given students!" );
    }

    /**
     * To verify Edit usage goal button enabled or not
     *
     * @return
     */
    public boolean isEditUsageGoalButtonEnabled() {
        SMUtils.waitForElement( driver, btnEditUsageGoals );
        return btnEditUsageGoals.isEnabled();
    }

    /**
     * To Change usage goal status for student
     */
    public void changeGoalstatusForStudent( String studentName, String status ) {
        int targetHrs = 0;
        Calendar oneMonthLater = Calendar.getInstance();
        oneMonthLater.add( Calendar.MONTH, 6 );
        SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/YY" );
        int expectedMins = 0;
        if ( status.equalsIgnoreCase( UsageGoal.FALLING_BEHIND ) ) {
            expectedMins = 25;
        } else if ( status.equalsIgnoreCase( UsageGoal.WATCH_CLOSELY ) ) {
            expectedMins = 3;
        }

        if ( !getGoalStatusFromUI().get( studentName ).equalsIgnoreCase( status ) ) {
            targetHrs = ( ( ( expectedMins + convertHoursIntoMinutes( getColumnValuesFromUI( "Avg Time / Wk" ).get( studentName ) ) ) * 26 ) + convertHoursIntoMinutes( getColumnValuesFromUI( "Total Time" ).get( studentName ) ) ) / 60;
            int remainderMins = ( ( ( expectedMins + convertHoursIntoMinutes( getColumnValuesFromUI( "Avg Time / Wk" ).get( studentName ) ) ) * 26 ) + convertHoursIntoMinutes( getColumnValuesFromUI( "Total Time" ).get( studentName ) ) ) % 60;
            if ( remainderMins > 30 ) {
                targetHrs += 1;
            }
        }

        if ( targetHrs != 0 ) {
            SMUtils.waitForElementToBeClickable( goalsSelectAllCheckbox, driver );
            WebElement element = SMUtils.getWebElement( driver, goalsSelectAllCheckbox, selectAllCheckBoxChild );
            SMUtils.clickJS( driver, element );
            SMUtils.waitForElementToBeClickable( btnEditUsageGoals, driver );
            SMUtils.clickJS( driver, btnEditUsageGoals );
            EditUsageGoalsPopupPage editGoals = new EditUsageGoalsPopupPage( driver ).get();
            Log.message( "Navigated to Edit Goals popup" );
            editGoals.moveSlider( String.valueOf( targetHrs ) );
            editGoals.setEndDate( dateFormat.format( oneMonthLater.getTime() ) );
            editGoals.clickOKButton();
            Log.message( "Changes the status to - " + status );
        }
    }

    /**
     * To convert hours into minutes
     *
     * @return
     */
    public Integer convertHoursIntoMinutes( String hrs ) {
        String[] hoursAndMinutes = hrs.split( ":" );
        return ( Integer.valueOf( hoursAndMinutes[0] ) * 60 ) + Integer.valueOf( hoursAndMinutes[1] );
    }

    /**
     * To convert minutes into hours
     *
     * @return
     */
    public String convertMinutesIntoHours( String minutes ) {
        int totalhour = Integer.valueOf( minutes ) / 60;
        int totalMinute = Integer.valueOf( minutes ) % 60;
        String hour = "";
        String minute = "";
        if ( totalhour < 10 ) {
            hour = "0" + String.valueOf( totalhour );
        } else {
            hour = String.valueOf( totalhour );
        }

        if ( totalMinute < 10 ) {
            minute = "0" + String.valueOf( totalMinute );
        } else {
            minute = String.valueOf( totalMinute );
        }
        return hour + ":" + minute;
    }

    /**
     * Returns the list from Subject dropdown under Master section of the home
     * page
     *
     * @return subjectNames
     */
    public List<String> getHomePageSubjectList() {
        List<String> subjectNames = new ArrayList<>();
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, masterySubjectDropDown, caretSymbol ) );
        subjectList.forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( subjectNames::add ) );
        return subjectNames;
    }

    /**
     * Returns the option from Subject dropdown under Master section of the home
     * page
     *
     * @return selectedDropdownOption
     */
    public String getHomePageSubjectDropdownOption() {
        Log.message( "Subject dropdown currently visible is " + SMUtils.getTextOfWebElement( masterySubjectDropdown, driver ) );
        return SMUtils.getTextOfWebElement( masterySubjectDropdown, driver );
    }

    /**
     * Select the Math/Reading from Subject dropdown under Master section of the
     * home page
     *
     * @return skillsList
     */
    public List<String> getSkillsList() {
        List<String> skillsList = new ArrayList<>();
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, masterySkillsDropDown, caretSymbol ) );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, masterySkillsDropDown, caretSymbol ) );
        Log.message( "Skill list size is " + skillList.size() );
        skillList.forEach( element -> Optional.ofNullable( SMUtils.getChildWebElementFromParent( element, txtDropDownValue ).getText().trim() ).ifPresent( elementText -> {
            Log.message( "Skill is " + elementText );
            skillsList.add( elementText );
        } ) );
        return skillsList;
    }

    /**
     * To get all the assignments from the dropdown
     *
     * @return assignmentList
     */
    public List<String> getAllAssignments() {
        List<String> assignmentList = new ArrayList<>();
        WebElement assignmentDropdown = SMUtils.getWebElementDirect( driver, assignmentDropdownBtn, btnExpandAssignmentDropdownchild );
        SMUtils.clickJS( driver, assignmentDropdown );
        WebElement assignmentDropdownLabel = SMUtils.getWebElementDirect( driver, assignmentDropdownBtn, assignmentLabel );
        SMUtils.waitForElement( driver, assignmentDropdownLabel, 10 );
        List<WebElement> assignmentParentList = SMUtils.getAllWebElements( driver, assignmentDropdownBtn, assignmentSubList );
        Log.message( "The number of assignments present are " + assignmentParentList.size() );
        assignmentParentList.forEach( element -> Optional.ofNullable( SMUtils.getWebElementDirect( driver, element, individualAssignmentLabel ).getText().trim() ).ifPresent( assignmentList::add ) );
        return assignmentList;
    }

    /**
     * To click on the assignments dropdown
     *
     * @return
     */
    public void clickAssignmentDropdown() {
        SMUtils.waitForElement( driver, assignmentDropdownBtn, 5 );
        WebElement assignmentDropdown = SMUtils.getWebElementDirect( driver, assignmentDropdownBtn, btnExpandAssignmentDropdownchild );
        SMUtils.clickJS( driver, assignmentDropdown );
    }

    /**
     * To click on the assignments within the assignment list
     *
     * @return
     */
    public void clickOnAssignmentCheckboxes() {
        WebElement assignmentDropdown = SMUtils.getWebElementDirect( driver, assignmentDropdownBtn, btnExpandAssignmentDropdownchild );
        SMUtils.clickJS( driver, assignmentDropdown );
        WebElement assignmentDropdownLabel = SMUtils.getWebElementDirect( driver, assignmentDropdownBtn, assignmentLabel );
        SMUtils.waitForElement( driver, assignmentDropdownLabel, 10 );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, assignmentDropdownBtn, checkBoxAssignment, inputTag ) );
        List<WebElement> assignmentParentList = SMUtils.getAllWebElements( driver, assignmentDropdownBtn, checkBoxAssignmentParent );
        Log.message( "The number of assignments present are " + assignmentParentList.size() );
        assignmentParentList.forEach( element -> Optional.ofNullable( SMUtils.getWebElementDirect( driver, element, inputTag ) ).ifPresent( individualElement -> SMUtils.clickJS( driver, individualElement ) ) );
    }

    /**
     * To get the list of numbers from the Top Performing and Low Performing
     * columns
     *
     * @param columnName
     * @return masteredPercentageList
     */
    public List<String> getPerformanceList( String columnName ) {
        List<String> masteredPercentageList = new ArrayList<>();
        performanceColumns.forEach( element -> {
            if ( element.findElement( By.cssSelector( performanceHeader ) ).getText().trim().equals( columnName ) ) {
                element.findElements( By.cssSelector( performanceBadge ) ).forEach( finalElement -> {
                    masteredPercentageList.add( SMUtils.getTextOfWebElement( SMUtils.getWebElementDirect( driver, finalElement, divTag ), driver ) );
                } );
            }
        } );
        return masteredPercentageList;
    }

    /**
     * To get Assignment label visible on the UI
     *
     * @return
     */
    public String getVisibleAssignmentName() {
        WebElement assignmentDropdownLabel = SMUtils.getWebElementDirect( driver, assignmentDropdownBtn, assignmentLabel );
        return SMUtils.getTextOfWebElement( assignmentDropdownLabel, driver );
    }

    /**
     * To get the zero state message depending on the column
     *
     * @param columnName
     * @return zeroStateMessage
     */
    public String getZeroStateMessage( String columnName ) {
        AtomicReference<String> zeroStateMessage = new AtomicReference<>();
        performanceColumns.forEach( element -> {
            if ( element.findElement( By.cssSelector( performanceHeader ) ).getText().trim().equals( columnName ) ) {
                zeroStateMessage.set( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( zeroStatePage ) ), driver ) );
            }
        } );
        return zeroStateMessage.get();
    }

    /**
     * To toggle the goals Icon
     *
     * @return
     */
    public boolean toggleToUsageGoals() {
        try {
            WebElement usageGoals = SMUtils.getWebElement( driver, usageGoalsToggleRoot, usageGoalsChild );
            SMUtils.scrollWebElementToView( driver, usageGoals );
            SMUtils.clickJS( driver, usageGoals );
            SMUtils.waitForElement( driver, mathUsageGoals );
            Log.message( "Toggled usage goals." );
            return mathUsageGoals.isDisplayed();
        } catch ( NoSuchElementException e ) {
            return false;
        }
    }

    /**
     * To get the goals usage text
     *
     * @return
     */
    public String getUsageGoalsText() {
        WebElement usageGoals = SMUtils.getWebElement( driver, usageGoalsToggleRoot, usageGoalsChild );
        SMUtils.scrollWebElementToView( driver, usageGoals );
        return SMUtils.getTextOfWebElement( usageGoals, driver );
    }

    /**
     * To verify the goals header
     *
     * @return
     */
    public boolean verifyGoalsHeader() {
        SMUtils.scrollWebElementToView( driver, usageGoalsToggleRoot );
        AtomicBoolean isDisplayed = new AtomicBoolean( false );
        golsHeaders.stream().forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( "Math Usage Goals" ) ) {
                Log.pass( "Math Usage Goals displayed successfully" );
                isDisplayed.set( true );
            } else if ( element.getText().trim().equalsIgnoreCase( "Reading Usage Goals" ) ) {
                Log.pass( "Reading Usage Goals displayed successfully" );
                isDisplayed.set( true );
            } else {
                Log.fail( "Issue in displaying usage goals headers!" );
                isDisplayed.set( false );
            }
        } );
        return isDisplayed.get();
    }

    /**
     * To verify the goals bar legends
     *
     * @param isMath
     * @return
     */
    public boolean verifyGoalsBarLegends( boolean isMath ) {
        AtomicBoolean isVerified = new AtomicBoolean( false );
        goalsSubjectSection.forEach( element -> {
            if ( isMath ) {
                if ( SMUtils.getChildWebElementFromParent( element, goalsUsageTitles ).getText().contains( "Math" ) ) {
                    List<WebElement> legends = SMUtils.getChildWebElementsFromParent( element, goalsLegends );
                    if ( SMUtils.sortList( Constants.HomePageWidgetConstants.GOALS_LEGENDS ).equals( SMUtils.sortList( SMUtils.getAllTextFromWebElementList( legends ) ) ) ) {
                        Log.pass( "Math Goals Legends are displayed successfully! Actual - " + SMUtils.getAllTextFromWebElementList( legends ), driver );
                        isVerified.set( true );
                    } else {
                        Log.fail( "Issue in displaying Math goals legends! Actual - " + SMUtils.getAllTextFromWebElementList( legends ), driver );
                    }
                }
            } else if ( SMUtils.getChildWebElementFromParent( element, goalsUsageTitles ).getText().contains( "Reading" ) ) {
                List<WebElement> legends = SMUtils.getChildWebElementsFromParent( element, goalsLegends );
                if ( SMUtils.sortList( Constants.HomePageWidgetConstants.GOALS_LEGENDS ).equals( SMUtils.sortList( SMUtils.getAllTextFromWebElementList( legends ) ) ) ) {
                    Log.pass( "Reading Goals Legends are displayed successfully! Actual - " + SMUtils.getAllTextFromWebElementList( legends ), driver );
                    isVerified.set( true );
                } else {
                    Log.fail( "Issue in displaying Reading goals legends! Actual - " + SMUtils.getAllTextFromWebElementList( legends ), driver );
                }
            }
        } );
        return isVerified.get();
    }

    /**
     * To verify the goals bar color,values.
     *
     * @param isMath
     * @param usgeGoalsData
     * @param browser
     * @return
     */
    public boolean verifyGoalsBarValues( boolean isMath, String usgeGoalsData, String browser ) {
        String mathUsageGoals;
        String readUsageGoals;
        String usageGoals;
        List<String> legendFromUI = new ArrayList<>();
        List<String> legendColorsFromUI = new ArrayList<>();
        AtomicBoolean isVerified = new AtomicBoolean( false );
        if ( isMath ) {
            mathUsageGoals = SMUtils.getKeyValueFromResponse( usgeGoalsData, "data,math" );
            usageGoals = mathUsageGoals;
        } else {
            readUsageGoals = SMUtils.getKeyValueFromResponse( usgeGoalsData, "data,reading" );
            usageGoals = readUsageGoals;
        }

        List<String> legendFromAPI = new ArrayList<>();
        legendFromAPI.add( String.valueOf( Math.round( Double.parseDouble( SMUtils.getKeyValueFromResponse( usageGoals, "totalStudentsOnTrackPercentage" ) ) ) ).concat( Constants.HomePageWidgetConstants.GOALS_STUDENT_LEGEND_UI ) );
        legendFromAPI.add( String.valueOf( Math.round( Double.parseDouble( SMUtils.getKeyValueFromResponse( usageGoals, "totalStudentsToWatchCloselyPercentage" ) ) ) ).concat( Constants.HomePageWidgetConstants.GOALS_STUDENT_LEGEND_UI ) );
        legendFromAPI.add( String.valueOf( Math.round( Double.parseDouble( SMUtils.getKeyValueFromResponse( usageGoals, "totalStudentsFallingBehindPercentage" ) ) ) ).concat( Constants.HomePageWidgetConstants.GOALS_STUDENT_LEGEND_UI ) );

        DecimalFormat df = new DecimalFormat( "#.####" );
        df.setRoundingMode( RoundingMode.CEILING );
        df.format( Double.parseDouble( SMUtils.getKeyValueFromResponse( usageGoals, "totalStudentsFallingBehindPercentage" ) ) );

        List<String> expectedColor = new ArrayList<>();
        if ( browser.toLowerCase().contains( "safari" ) ) {
            expectedColor.add( String.format( Constants.HomePageWidgetConstants.GOALS_COLOR_UI_ON_TRACK, Constants.HomePageWidgetConstants.SAFARI_GOALS_COLOR_CHANGE,
                    df.format( Double.parseDouble( SMUtils.getKeyValueFromResponse( usageGoals, "totalStudentsOnTrackPercentage" ) ) ).concat( "%;" ) ) );
            expectedColor.add( String.format( Constants.HomePageWidgetConstants.GOALS_COLOR_UI_WATCH_CLOSELY, Constants.HomePageWidgetConstants.SAFARI_GOALS_COLOR_CHANGE,
                    df.format( Double.parseDouble( SMUtils.getKeyValueFromResponse( usageGoals, "totalStudentsToWatchCloselyPercentage" ) ) ).concat( "%;" ) ) );
            expectedColor.add( String.format( Constants.HomePageWidgetConstants.GOALS_COLOR_UI_FALLING_BEHIND, Constants.HomePageWidgetConstants.SAFARI_GOALS_COLOR_CHANGE,
                    df.format( Double.parseDouble( SMUtils.getKeyValueFromResponse( usageGoals, "totalStudentsFallingBehindPercentage" ) ) ).concat( "%;" ) ) );
        } else {
            expectedColor.add( String.format( Constants.HomePageWidgetConstants.GOALS_COLOR_UI_ON_TRACK, ":", df.format( Double.parseDouble( SMUtils.getKeyValueFromResponse( usageGoals, "totalStudentsOnTrackPercentage" ) ) ).concat( "%;" ) ) );
            expectedColor.add( String.format( Constants.HomePageWidgetConstants.GOALS_COLOR_UI_WATCH_CLOSELY, ":", df.format( Double.parseDouble( SMUtils.getKeyValueFromResponse( usageGoals, "totalStudentsToWatchCloselyPercentage" ) ) ).concat( "%;" ) ) );
            expectedColor.add( String.format( Constants.HomePageWidgetConstants.GOALS_COLOR_UI_FALLING_BEHIND, ":", df.format( Double.parseDouble( SMUtils.getKeyValueFromResponse( usageGoals, "totalStudentsFallingBehindPercentage" ) ) ).concat( "%;" ) ) );

        }
        goalsSubjectSection.forEach( element -> {
            if ( isMath ) {
                if ( SMUtils.getChildWebElementFromParent( element, goalsUsageTitles ).getText().contains( "Math" ) ) {
                    List<WebElement> legendValues = SMUtils.getChildWebElementsFromParent( element, goalsLegendValues );
                    legendValues.stream().forEach( legendUIValue -> Optional.ofNullable( SMUtils.getTextOfWebElement( legendUIValue, driver ) ).ifPresent( legendFromUI::add ) );
                    List<WebElement> barColors = SMUtils.getWebElementsDirect( driver, element.findElement( By.cssSelector( goalsColorRoot ) ), goalsColorChild );
                    barColors.stream().forEach( legendColorValue -> Optional.ofNullable( SMUtils.getAttributeOfWebElement( legendColorValue, driver, "style" ) ).ifPresent( legendColorsFromUI::add ) );
                }
            } else if ( SMUtils.getChildWebElementFromParent( element, goalsUsageTitles ).getText().contains( "Reading" ) ) {
                List<WebElement> legendValues = SMUtils.getChildWebElementsFromParent( element, goalsLegendValues );
                legendValues.stream().forEach( legendUIValue -> Optional.ofNullable( SMUtils.getTextOfWebElement( legendUIValue, driver ) ).ifPresent( legendFromUI::add ) );
                List<WebElement> barColors = SMUtils.getWebElementsDirect( driver, element.findElement( By.cssSelector( goalsColorRoot ) ), goalsColorChild );
                barColors.stream().forEach( legendColorValue -> Optional.ofNullable( SMUtils.getAttributeOfWebElement( legendColorValue, driver, "style" ) ).ifPresent( legendColorsFromUI::add ) );
            }
        } );

        if ( legendFromAPI.equals( legendFromUI ) ) {
            Log.pass( "Goals % values matched successfully! Expected: " + legendFromAPI + "Actual :" + legendFromUI, driver );
            isVerified.set( true );
        } else {
            Log.fail( "Issue in goals % usage goals!. Expected: " + legendFromAPI + " Actual :" + legendFromUI, driver );
            isVerified.set( false );
        }

        if ( expectedColor.equals( legendColorsFromUI ) ) {
            Log.pass( "Goals Color legends values matched successfully! Expected: " + expectedColor + "Actual :" + legendColorsFromUI, driver );
            isVerified.set( true );
        } else {
            Log.fail( "Issue in goals Color legends in usage goals!. Expected: " + expectedColor + " Actual :" + legendColorsFromUI, driver );
            isVerified.set( false );
        }
        return isVerified.get();
    }

    /**
     * Verify the edit goals link and students count
     *
     * @param isMath
     * @param usgeGoalsData
     * @return
     */
    public boolean verifyStudentsTowardsGoalsLink( boolean isMath, String usgeGoalsData ) {
        boolean isVerified = false;
        String mathUsageGoalsAPI;
        String readUsageGoalsAPI;
        String usageGoals;
        String editGoalsLinkUI;
        if ( isMath ) {
            mathUsageGoalsAPI = SMUtils.getKeyValueFromResponse( usgeGoalsData, "data,math" );
            usageGoals = mathUsageGoalsAPI;
            editGoalsLinkUI = SMUtils.getTextOfWebElement( mathUsageGoals, driver );
        } else {
            readUsageGoalsAPI = SMUtils.getKeyValueFromResponse( usgeGoalsData, "data,reading" );
            usageGoals = readUsageGoalsAPI;
            editGoalsLinkUI = SMUtils.getTextOfWebElement( readingUsageGoals, driver );
        }
        String totalAssignedStudents = SMUtils.getKeyValueFromResponse( usageGoals, "totalAssignedStudents" );
        String numberOfStudentsTowardsGoals = SMUtils.getKeyValueFromResponse( usageGoals, "totalEligibleStudents" );

        String studentsTowardsGoalsExpected = "View " + numberOfStudentsTowardsGoals + "/" + totalAssignedStudents + " students working towards goal";
        if ( studentsTowardsGoalsExpected.equalsIgnoreCase( editGoalsLinkUI ) ) {
            Log.pass( editGoalsLinkUI + " Displayed successfully!", driver );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying students towards goals.(Edit goals). Actual - " + editGoalsLinkUI + "Expected - " + studentsTowardsGoalsExpected, driver );
            isVerified = false;
        }
        return isVerified;
    }

    /**
     * To Get the Hint of goals
     *
     * @return
     */
    public String getHintForGoals() {
        SMUtils.waitForElement( driver, goalsHint, 5 );
        return goalsHint.getText().trim();
    }

    /**
     * To verify the zero state usage
     *
     * @return
     */
    public boolean verifyZeroStateGoalsUsage() {
        boolean isVerified = false;
        if ( SMUtils.getTextOfWebElement( usageGoalsZeroState, driver ).equalsIgnoreCase( Constants.HomePageWidgetConstants.ZERO_STATE_GOALS_TITLE )
                && SMUtils.getTextOfWebElement( usageGoalsZeroStateMessage, driver ).equalsIgnoreCase( Constants.HomePageWidgetConstants.ZERO_STATE_GOALS_CONTENT ) ) {
            Log.pass( "Zero state title displayed successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying zero state", driver );
            isVerified = false;
        }
        return isVerified;
    }

    /**
     * To get the edit goals link.
     *
     * @param isMath
     * @return
     */
    public String getEditGoalsLink( boolean isMath ) {
        if ( isMath ) {
            return SMUtils.getTextOfWebElement( mathUsageGoals, driver );
        } else {
            return SMUtils.getTextOfWebElement( readingUsageGoals, driver );
        }
    }

    /**
     * To verify View All link present at mastery level when no data is
     * available
     *
     * @return
     */
    public boolean isMasteryViewAllLinkPresent() {

        return SMUtils.verifyElementDoesNotExist( By.cssSelector( ".view-all-mastery-link" ), driver );
    }

    /**
     * verify mastery data
     */

    public boolean verifyMasteryDetails() {

        List<String> lowPerformanceList = new ArrayList<>();
        List<String> highPerformanceList = new ArrayList<>();

        // To performing list
        highPerformanceList = getPerformanceList( Constants.TOP_PERFORMING );

        // Low performing list
        lowPerformanceList = getPerformanceList( Constants.LOW_PERFORMING );

        List<String> list = SMUtils.mergeList( highPerformanceList, lowPerformanceList );
        return list.size() > 0;

    }

    /**
     * To click filters
     */
    public void clickFilters() {
        WebElement actualFilterElement = SMUtils.getWebElementDirect( driver, filtersShodowHost, filtersCss );
        SMUtils.waitForElement( driver, actualFilterElement, 5 );
        SMUtils.clickJS( driver, actualFilterElement );
        Log.message( "clicked on Filters" );
    }

    /***
     * To check the availability of Assignment thumbnail icon
     *
     * @return
     */
    public Boolean toCheckTheAssignmentThumbnail() {
        SMUtils.waitForElement( driver, firstAssignmentInWidget );
        return firstAssignmentInWidget.isDisplayed();
    }

    /***
     * To check the availability of seperator line
     *
     * @return
     */
    public Boolean toCheckSeperatorLine() {
        SMUtils.waitForElement( driver, firstSeperatorLine );
        return firstSeperatorLine.isDisplayed();
    }

    /**
     * To click apply filter
     */
    public void clickApplyFilter() {
        WebElement applyFilterButton = SMUtils.getWebElementDirect( driver, applyFilterHost, applyFilterRoot );
        SMUtils.waitForElement( driver, applyFilterButton, 5 );
        SMUtils.clickJS( driver, applyFilterButton );
        Log.message( "Clicked on the apply filter button" );
    }

    /**********************************************************
     * Mastery card Elements
     **********************************************************/
    @IFindBy ( how = How.CSS, using = "div.layout-body-mastery", AI = false )
    public WebElement masteryBody;

    @IFindBy ( how = How.CSS, using = "mastery-filter-assignments  cel-multi-check-dropdown", AI = false )
    public WebElement masteryAssignentDropdown;

    @IFindBy ( how = How.CSS, using = "mastery-filter-skills button", AI = false )
    public WebElement masterySkilsDropdown;

    @FindBy ( css = "span.dropdown-option-label.sc-cel-dropdown-select" )
    List<WebElement> DropdownValues;

    @IFindBy ( how = How.CSS, using = "div cel-multi-check-dropdown ", AI = false )
    public WebElement dropdownGrandRoot;

    @IFindBy ( how = How.CSS, using = "a.view-all-mastery-link span", AI = false )
    public WebElement masteryViewAll;

    @FindBy ( css = "div.mastery-container.d-inline-flex div.mastered-text" )
    List<WebElement> masteredText;

    @FindBy ( css = "span.mastery-home-header" )
    List<WebElement> masteryPerformingHeader;

    @FindBy ( css = "span.mastery-home-header" )
    List<WebElement> masteryHeadingColumn;

    @FindBy ( css = "div.mastery-lo-data span" )
    List<WebElement> masteryLODetails;

    @FindBy ( css = "cel-badge.mastered-badge.hydrated" )
    List<WebElement> masteryBadgeRoot;

    @IFindBy ( how = How.CSS, using = "mastery-widget div.mastery-inner-container.row", AI = false )
    public WebElement masteryContainer;

    @FindBy ( css = "span.percent-symbol" )
    List<WebElement> masteryBadgePercentSymbol;

    @IFindBy ( how = How.CSS, using = "mastery-widget cel-button.apply-button.hydrated", AI = false )
    public WebElement applyFilterMastery;

    public static String masteryHeadingCSS = "div.layout-heading.border-0";
    public static String dropdownGrandRootCSS = "div div div div li";
    public static String dropdownParentRootCSS = "li[class*='dropdown-item'] div  cel-checkbox";
    public static String dropdownElementRoot = "label[class*='checkbox__label']";
    public static String selectAllParentCSS = "div [class*='dropdown-all-select'] cel-checkbox";
    public static String selectAllCSS = "label.checkbox__label";
    public static String percentNumberCSS = "div.badge.success span";
    public static String percentSymbolCSS = "span.percent-symbol";

    /**
     * Verify the mastery Heading is present or not
     */
    public void verifyMasteryHeadingPresent() {
        String text = SMUtils.getChildWebElementFromParent( masteryBody.findElement( By.xpath( "./.." ) ), masteryHeadingCSS ).getText().trim();
        if ( HomePageWidgetConstants.MASTERY.equals( text ) ) {
            Log.pass( "Heading Mastery is present!" );
        } else {
            Log.failsoft( "Heading not matching expected " + HomePageWidgetConstants.MASTERY + " actual " + text );
        }
    }

    /**
     * click Mastery card Assignment Dropdown
     */
    public void clickMasteryAssignmentDropdown() {
        SMUtils.click( driver, masteryAssignentDropdown );
    }

    /**
     * click Mastery card subject dropdown
     */
    public void clickMasterySubjectDropdown() {
        SMUtils.click( driver, masterySubjectDropdown );
    }

    /**
     * click Mastery card Skill Dropdown
     */
    public void clickMasterySkilsDropdown() {
        SMUtils.click( driver, masterySkilsDropdown );
    }

    public void clickDropdownValue( String valueName ) {
        DropdownValues.stream().filter( valueElement -> valueElement.getText().trim().equals( valueName ) ).forEach( Element -> SMUtils.click( driver, Element ) );
    }

    /**
     * This method will select the values in Mastery Assignment Check box
     * values. It do from clicking dropdown and select checkbox and click apply
     * filter
     *
     * @param List of checkBox items to select
     * @throws InterruptedException
     */
    public void selectAssignmentsinMasteryCard( List<String> checkboxItems ) throws InterruptedException {
        clickMasteryAssignmentDropdown();
        List<WebElement> listDropdown = SMUtils.getWebElementsDirect( driver, dropdownGrandRoot, dropdownGrandRootCSS );
        listDropdown.stream().forEach( element -> {
            WebElement root2 = element.findElement( By.cssSelector( dropdownParentRootCSS ) );
            WebElement dropdownElement = SMUtils.getWebElementDirect( driver, root2, dropdownElementRoot );
            String text = dropdownElement.getText().trim();
            if ( checkboxItems.contains( text ) ) {
                SMUtils.scrollWebElementToView( driver, dropdownElement );
                SMUtils.clickJS( driver, dropdownElement );
                Log.message( "checked the value: " + text );
            }
        } );
        clickApplyFilterinMasteryCard();
    }

    /**
     * This method will click Check box in Assignment Check box dropdown
     */
    public void clickSelectAllCheckbox() {
        SMUtils.click( driver, SMUtils.getWebElement( driver, SMUtils.getWebElement( driver, dropdownGrandRoot, selectAllParentCSS ), selectAllCSS ) );
    }

    public WebElement getMasteryCardContainerElement() {
        return masteryContainer;
    }

    public void verifyingMasteryCard() {
        SMUtils.waitForElement( driver, masteryContainer, 5 );

        // Mastery Heading checking
        Log.message( "Verifying  Mastery Heading is present" );
        verifyMasteryHeadingPresent();

        // All the dropdown checking
        Log.message( "Verifying all the dropdown is available" );
        if ( masteryViewAll.isDisplayed() && masterySubjectDropdown.isDisplayed() && masterySkilsDropdown.isDisplayed() && masteryAssignentDropdown.isDisplayed() ) {
            Log.pass( "Subject and Skills and Assignments Dropdowns is availabe!" );
        } else {
            Log.failsoft( "Subject and Skills and Assignments Dropdowns is not availabe!" );
        }

        if ( isMasterycardHasSkills() ) {
            // mastered text checking
            Log.message( "Verifying the Mastered text is present under the badge" );
            if ( masteredText.size() > 0 ) {
                masteredText.forEach( element -> {
                    if ( element.getText().trim().equals( HomePageWidgetConstants.MASTERED_TEXT ) ) {
                        Log.pass( "The mastered text is present for the Lo" );
                    } else {
                        Log.failsoft( "The mastered text is not present for all Lo's" );
                    }
                } );
            } else {
                Log.failsoft( "Mastery data  is not Present" );
            }

            // TOP performing or Low performing Heading checking
            Log.message( "Verifying the Mastered Headers" );
            if ( masteryPerformingHeader.size() == 2 ) {
                masteryPerformingHeader.forEach( element -> {
                    if ( element.getText().trim().equals( HomePageWidgetConstants.TOP_PERFORMING ) || element.getText().trim().equals( HomePageWidgetConstants.LOW_PERFORMING ) ) {
                        Log.pass( "Headers text is matching!" );
                    } else {
                        Log.failsoft( "Headers text is not matching!" );
                    }
                } );
            } else {
                Log.fail( "Error in displaing mastered column Heading" );
            }

            // Percentage value checking
            Log.message( "Verifying mastery percent values" );
            masteryBadgeRoot.forEach( element -> {
                int percentValue = Integer.parseInt( SMUtils.getWebElement( driver, element, percentNumberCSS ).getText().trim() );
                if ( percentValue <= 100 && percentValue >= 0 ) {
                    Log.pass( "The mastery percent values matches" );
                } else {
                    Log.pass( "The mastery percent values matches" );
                }
            } );

            // % symbol is present or not
            Log.message( "Verifying mastery symbol " );
            masteryBadgePercentSymbol.forEach( element -> {
                String symbol = element.getText().trim();
                if ( symbol.equals( "%" ) ) {
                    Log.pass( "The mastery percent symbols matches!" );
                } else {
                    Log.pass( "The mastery percent symbols is not matching" );
                }
            } );
            Log.message( "Verifying view all button will leads to mastery page" );

            // view all link is presnt or not
            if ( masteryViewAll.isDisplayed() ) {
                Log.pass( "View all link is displayed" );
            } else {
                Log.pass( "The view all link is present" );
            }
        } else {
            Log.message( "Mastery card has no skills listed" );
        }

        // Mastery column is 2 checking
        if ( masteryHeadingColumn.size() == 2 ) {
            Log.pass( "The column is two as expected!" );
        } else {
            Log.fail( "The column is not two as expected!" );
        }
    }

    /**
     * click View All link in Mastery card
     */
    public void clickViewAllinMasteryCard() {
        SMUtils.click( driver, masteryViewAll );

    }

    /**
     * Return true if Mastery ApplyFilter button is in disabled state
     *
     * @return
     */
    public boolean isMasteryApplyFilterdisabled() {
        String text = applyFilterMastery.getAttribute( "outerHTML" );
        if ( text.contains( "disabled" ) ) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * To click apply filter button in mastery card
     *
     * @throws InterruptedException
     */
    public void clickApplyFilterinMasteryCard() throws InterruptedException {
        SMUtils.click( driver, applyFilterMastery );
        SMUtils.waitForSpinnertoDisapper( driver );
    }

    /**
     * this method will return true if mastery card has skill
     *
     * @return
     */
    public boolean isMasterycardHasSkills() {
        if ( masteryLODetails.size() > 0 ) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * This method will return the skill Names of the Mastery cards
     *
     * @param colname - Top performing or Low Performing
     * @return list of Lo Details
     */
    public List<String> getMasteryLoDetails( String colname ) {
        List<String> skills = new ArrayList<>();
        masteryPerformingHeader.stream().forEach( element -> {
            if ( element.getText().trim().equals( colname ) ) {
                WebElement parent = element.findElement( By.xpath( "./.." ) );
                // skill names
                List<WebElement> skillNames = parent.findElements( By.cssSelector( ".mastery-lo-data span" ) );
                skillNames.stream().forEach( ele -> {
                    skills.add( ele.getText().trim() );
                } );
            }
        } );
        return skills;
    }

    /**
     * This method will return Percentage value of the Top performing or Low
     * performing
     *
     * @param colname - Top/Low performing
     * @return
     */
    public List<String> getMasteryPercentValues( String colName ) {
        List<String> percent = new ArrayList<>();
        masteryPerformingHeader.stream().forEach( element -> {
            if ( element.getText().trim().equals( colName ) ) {
                WebElement parent = element.findElement( By.xpath( "./.." ) );
                // percent
                List<WebElement> percentElements = parent.findElements( By.cssSelector( "cel-badge.mastered-badge.hydrated" ) );
                percentElements.stream().forEach( ele -> {
                    String percentValue = SMUtils.getWebElement( driver, ele, percentNumberCSS ).getText().trim();
                    percent.add( percentValue );
                } );
            }
        } );
        return percent;
    }

    /**
     * To get the LO name List
     *
     * @param performersJsonObj
     *
     * @return loFinalTitleList
     */
    public Set<String> getListOfAllTitles( JSONObject performersJsonObj ) {
        Set<String> loFinalTitleList = new HashSet<>();
        JSONArray topPerformers = performersJsonObj.getJSONArray( "topPerformers" );
        JSONArray lowPerformers = performersJsonObj.getJSONArray( "lowPerformers" );
        try {
            IntStream.range( 0, topPerformers.length() ).forEach( elementIndex -> {
                JSONObject jsonObjectFinalList = topPerformers.getJSONObject( elementIndex );
                String keyValue = jsonObjectFinalList.optString( "title" );
                if ( !keyValue.isEmpty() ) {
                    loFinalTitleList.add( keyValue );
                }
            } );
            IntStream.range( 0, lowPerformers.length() ).forEach( elementIndex -> {
                JSONObject jsonObjectFinalList = lowPerformers.getJSONObject( elementIndex );
                String keyValue = jsonObjectFinalList.optString( "title" );
                if ( !keyValue.isEmpty() ) {
                    loFinalTitleList.add( keyValue );
                }
            } );
            Log.message( "Fetched all the titles" );
        } catch ( Exception e ) {
            Log.message( "Error occured please check getListOfAllTitles method" );
        }
        return loFinalTitleList;
    }

    /**
     * This method is used to generate the request body.
     *
     * @param requestBodyTemplate
     * @param subjectId
     * @param limitId
     * @return requestBody
     */
    public String generateRequestBody( String requestBodyTemplate, String subjectId, String limitId ) {
        String requestBody = requestBodyTemplate;
        if ( requestBody.contains( Constants.SUBJECT_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.SUBJECT_ID_VALUE, subjectId );
        }
        if ( requestBody.contains( Constants.LIMIT_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.LIMIT_ID_VALUE, limitId );
        }

        return requestBody;
    }

    /**
     * This method is used to verify the zero state message in the homepage when
     * the teacher's org is not having any active licenses
     *
     * return zero state content message
     */

    public String getZeroStateContentMessage() {
        String zeroStateContentMessage = null;
        if ( SMUtils.isElementPresent( zeroStateWrapper ) ) {
            SMUtils.waitForElement( driver, zeroStateContent );
            zeroStateContentMessage = SMUtils.getTextOfWebElement( zeroStateContent, driver );
        }

        return zeroStateContentMessage;
    }

    public void clickAssignBtnMSDAPopup() {
        SMUtils.waitForElement( driver, continueToAssignMSDAPopup );
        SMUtils.clickJS( driver, continueToAssignMSDAPopup );
        Log.message( "Clicked continue to assign button in MSDA popup!" );

    }

    /**
     * to click on assign button
     */
    public void clickAssignButtonForReading() {
        try {
            SMUtils.waitForElement( driver, viewAllLink );
            WebElement assignBtnParent = rootAsignBnt.get( 1 );
            WebElement assignBtn = SMUtils.getWebElement( driver, assignBtnParent, childAssignBtn );
            Log.message( "Click assign button for Reading" );
            SMUtils.click( driver, assignBtn );
            Log.message( "Assign course header is displaying" );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

    }
    
    /**
     * To click the Assignment Widget
     *
     */
    public void clickAssignmentWidget() {
    	
        SMUtils.waitForElement( driver, AssignmentsWidgetList.get(1) );
        SMUtils.clickJS( driver, AssignmentsWidgetList.get(1) );
        Log.message( "Clicked Assignment Widget" );
    }

}
