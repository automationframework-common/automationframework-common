package com.savvas.sm.api.tests.smnew.students;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

import io.restassured.response.Response;

public class PUTAPIIPMCrossOver extends EnvProperties{
	
	private String smUrl;
    private String teacherDetails;
    private String teacherUsername;
    private String teacherUserId;
    private String orgId;
    private String studentDetails;
    private String studentUsername;
    private String studentUserId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private List<String> studentRumbaIds = new ArrayList<>();
    private Map<String, String> courseName = new HashMap<>();
    private Map<String, String> courseIds = new HashMap<>();
    private Map<String, String> assignmentIds = new HashMap<>();
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String assignmentUserId;
    String rewardLevel = "1.000";
    String rewardSelectionData = "item=1";
    List<String> rewardDetails;

    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {
        // Retrieving URL from Config.properites
        smUrl = configProperty.getProperty( "SMAppUrl" );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        studentDetails = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );

        //Math Course Names
        courseName.put( Constants.MATH, AssignmentAPIConstants.MATH_COURSE );
        courseName.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
        
        //Reading Course Names
        courseName.put( Constants.READING, AssignmentAPIConstants.READING_COURSE );
        courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );

        String teacherAccessToken = null;
        try {
            teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Issue in get the accces token - " + e.getMessage() );
            try {
                Log.message( "Retrying to get the access token!!!!" );
                teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            } catch ( Exception e1 ) {
                Log.fail( "Unable to create the access token for the teacher - " + teacherUsername );
            }
        }
        
        //Math course Ids
        courseIds.put( Constants.MATH, AssignmentAPIConstants.MATH );
        courseIds.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
        courseIds.put( Constants.CUSTOM_BY_SKILLS_MATH_COURSE,
                new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SKILL, courseName.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ) );

        courseIds.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE,
                new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ) );
        try {
            courseIds.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );

        } catch ( Exception e ) {
            Log.message( "Issue in Reading Custom course creation!! - " + e.getMessage() );
        }

        //Reading course Ids
        courseIds.put( Constants.READING, AssignmentAPIConstants.READING );
        courseIds.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        courseIds.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE,
                new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SKILL, courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );

        courseIds.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE,
                new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
        try {
            courseIds.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );

        } catch ( Exception e ) {
            Log.message( "Issue in Reading Custom course creation!! - " + e.getMessage() );
        }

        Log.message( "Course Ids for " + school + ": " + courseIds );

        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        staffDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        try {
            //Assigning Assignment
            Log.message( "Assigning assignment..." );

            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, studentRumbaIds, new ArrayList<>( courseIds.values() ) );
            Log.message( "Assignment Response : " + assignmentResponse );

            JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
            JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

            for ( Object assignment : assignmentList ) {
                JSONObject assignmentInfo = new JSONObject( assignment.toString() );
                assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
            }
            Log.message( "Assignment IDs - " + assignmentIds );
        } catch ( Exception e ) {
            Log.fail( "Issue in Assigning the assignment to the student!! - " + e.getMessage() );
        }
    }

    @Test ( priority = 1, dataProvider = "updateIPMCrossOver", groups = { "smoke_test_case", "SMK-66844", "Students", "IPM Crossover", "P1", "API" } )
    public void tcPositiveTestcases( String tcId, String description, String scenario, String statusCode ) throws Throwable {
        Log.testCaseInfo( tcId + ":-" + description );
        
        Map<String, String> response = new HashMap<>();
        String sessionId;
        
        switch ( scenario ) {
        case "VALID__DEFAULTMATH":

            assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.MATH ) ) );
            sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
            response = putUpdateIPMCrossOver( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
            new RBSUtils().getAccessToken( studentUsername, password );
            Log.message( "Status Code: "+response.get( Constants.STATUS_CODE ) );
            Log.message( "Response Body: "+response.get( Constants.REPORT_BODY ) );
            //TO DO since there is no Response body for this API only Status Code Validation is done for now
            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
            break;
               
        case "VALID__SETTINGSMATH":

            assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );
            sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
            response = putUpdateIPMCrossOver( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
            Log.message( "Status Code: "+response.get( Constants.STATUS_CODE ) );
            Log.message( "Response Body: "+response.get( Constants.REPORT_BODY ) );
            //TO DO since there is no Response body for this API only Status Code Validation is done for now
            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
            break;

        case "VALID__SKILLMATH":

            assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SKILLS_MATH_COURSE ) ) );
            sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
            response = putUpdateIPMCrossOver( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
            Log.message( "Status Code: "+response.get( Constants.STATUS_CODE ) );
            Log.message( "Response Body: "+response.get( Constants.REPORT_BODY ) );
            //TO DO since there is no Response body for this API only Status Code Validation is done for now
            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
            break;

        case "VALID__STANDARDSMATH":

            assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ) );
            sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
            response = putUpdateIPMCrossOver( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
            Log.message( "Status Code: "+response.get( Constants.STATUS_CODE ) );
            Log.message( "Response Body: "+response.get( Constants.REPORT_BODY ) );
            //TO DO since there is no Response body for this API only Status Code Validation is done for now
            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
            break;
            
        case "VALID__DEFAULTREADING":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.READING ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = putUpdateIPMCrossOver( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                new RBSUtils().getAccessToken( studentUsername, password );
                Log.message( "Status Code: "+response.get( Constants.STATUS_CODE ) );
                Log.message( "Response Body: "+response.get( Constants.REPORT_BODY ) );
                //TO DO since there is no Response body for this API only Status Code Validation is done for now
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                break;
                   
         case "VALID__SETTINGSREADING":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = putUpdateIPMCrossOver( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                Log.message( "Status Code: "+response.get( Constants.STATUS_CODE ) );
                Log.message( "Response Body: "+response.get( Constants.REPORT_BODY ) );
                //TO DO since there is no Response body for this API only Status Code Validation is done for now
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                break;

            case "VALID__SKILLREADING":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = putUpdateIPMCrossOver( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                Log.message( "Status Code: "+response.get( Constants.STATUS_CODE ) );
                Log.message( "Response Body: "+response.get( Constants.REPORT_BODY ) );
                //TO DO since there is no Response body for this API only Status Code Validation is done for now
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                break;

            case "VALID__STANDARDSREADING":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = putUpdateIPMCrossOver( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                Log.message( "Status Code: "+response.get( Constants.STATUS_CODE ) );
                Log.message( "Response Body: "+response.get( Constants.REPORT_BODY ) );
                //TO DO since there is no Response body for this API only Status Code Validation is done for now
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                break;
                 
        }

    }

    @DataProvider ( name = "updateIPMCrossOver" )
    public Object[][] ipmCrossOverPositive() {

        Object[][] inputData = {
        		{ "TC_001PUTIPMCrossOver", "TC01_Verify the status code is 200 when valid data is given for assignment which has been created from Deafult Math for PUT Method.", "VALID__DEFAULTMATH", CommonAPIConstants.STATUS_CODE_OK },
                { "TC_002PUTIPMCrossOver", "TC02_Verify the status code is 200 when valid data is given for assignment which has been created from Custom Math(custom by setting) for PUT Method.", "VALID__SETTINGSMATH", CommonAPIConstants.STATUS_CODE_OK },
                { "TC_003PUTIPMCrossOver", "TC03_Verify the status code is 200 when valid data is given for assignment which has been created from Custom Math(custom by skills) for PUT Method.", "VALID__SKILLMATH", CommonAPIConstants.STATUS_CODE_OK },
                { "TC_004PUTIPMCrossOver", "TC04_Verify the status code is 200 when valid data is given for assignment which has been created from Custom Math(custom by standard) for PUT Method.", "VALID__STANDARDSMATH",
                        CommonAPIConstants.STATUS_CODE_OK },
                { "TC_005PUTIPMCrossOver", "TC06_Verify the status code is 200 when valid data is given for assignment which has been created from Deafult Reading for PUT Method.", "VALID__DEFAULTREADING", CommonAPIConstants.STATUS_CODE_OK },
                { "TC_006PUTIPMCrossOver", "TC07_Verify the status code is 200 when valid data is given for assignment which has been created from Custom Reading(custom by setting) for PUT Method.", "VALID__SETTINGSREADING", CommonAPIConstants.STATUS_CODE_OK },
                { "TC_007PUTIPMCrossOver", "TC08_Verify the status code is 200 when valid data is given for assignment which has been created from Custom Reading(custom by skills) for PUT Method.", "VALID__SKILLREADING", CommonAPIConstants.STATUS_CODE_OK },
                { "TC_008PUTIPMCrossOver", "TC09_Verify the status code is 200 when valid data is given for assignment which has been created from Custom Reading(custom by standard) for PUT Method.", "VALID__STANDARDSREADING",
                        CommonAPIConstants.STATUS_CODE_OK }
                };

        return inputData;
    }

    /**
     * To Create and get the session Id for given student
     *
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @return
     */
    public String getSessionId( String smUrl, String userId, String orgId, String studentUsername, String password, String assignmentUserId ) {
        String endPoint1 = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        List<String> pathParamsList = new ArrayList<>();
        HashMap<String, String> header = new HashMap<>();
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( LicenseAPIConstants.USERID, userId );
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        pathParamsList.add( assignmentUserId );
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint1, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, header, endPoint1, pathParams );
        Log.message( response.getBody().asString() );
        String sessionId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "sessionId" );
        Log.message( "Session ID  - " + sessionId );
        return sessionId;
    }
    
    /**
     * To update rewards in student login
     * 
     * @param smUrl
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @param sessionId
     * @return
     * @throws Throwable 
     */
    public HashMap<String, String> putUpdateIPMCrossOver( String smUrl, String userId, String orgId, String studentUsername, String password, String assignemntUserId, String sessionId ) throws Throwable {
        String endPoint = "/lms/web/assignments/ipm/crossover/{auId}".replace( "{auId}", assignemntUserId );
        String payload = "";
        payload = SMUtils.convertFileToString( new EnvProperties().configProperty.getProperty( "putUpdateIPMCrossOver" ) );
        //Parameters
        HashMap<String, String> params = new HashMap<>();
        Map<String, String> header = new HashMap<>();
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + "" + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            Log.fail( "Issue in getting the accesstoken for student - " + studentUsername );
        }
        header.put( LicenseAPIConstants.USERID, userId );
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( "session-id", sessionId );
        header.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        
        payload = payload.replace("{assignemntUserId}", assignemntUserId);
        Log.message("Endpoint: "+ endPoint);
        Log.message("Payload: "+ payload);
        
        return RestHttpClientUtil.PUT( smUrl, header, params, endPoint, payload );
       
    }

}
