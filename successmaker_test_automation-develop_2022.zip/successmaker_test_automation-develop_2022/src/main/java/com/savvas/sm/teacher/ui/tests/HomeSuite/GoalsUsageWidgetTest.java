package com.savvas.sm.teacher.ui.tests.HomeSuite;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.SqlHelperUsage;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This class ued to test the home page usage goals widget.
 *
 * @author ajith.mohan
 *
 */
@Listeners ( EmailReport.class )
public class GoalsUsageWidgetTest extends BaseTest {
    private String browser;
    private static String sessionCookie;
    private String teacherDetails;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String smUrl;
    private String goalsUsage;
    private String studentDetails;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
    }

    @Test ( priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )
    public void tcUsageGoalsWidget01() throws Exception {

        Log.testCaseInfo( "Verify the teacher can not see any goals bar when there is no default courses assigned to students.<small><b><i>[" + browser + "]</b></i></small>" );

        sessionCookie = new BaseAPITest().getJessionCookie( smUrl, password, password );
        goalsUsage = new BaseAPITest().getUsageGoal( smUrl, sessionCookie, DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ) );

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            //Logging in as a teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Toggling to usage goals
            SMUtils.logDescriptionTC( "Verify the user can switch the  usage goals toggle bar." );
            tHomePage.toggleToUsageGoals();

            //Verifying the hint for usage goals
            SMUtils.logDescriptionTC( "Verify whether the text (hint) is displayed properly after switching to usage goals section" );
            Log.assertThat( tHomePage.getHintForGoals().equalsIgnoreCase( Constants.HomePageWidgetConstants.GOALS_HINT ), "Hint displayed successfully!", "Goals hint not displayed." );

            //Verifying the zero state.
            SMUtils.logDescriptionTC( "Verify the teacher can not see any goals bar when there is no default courses assigned to students." );
            Log.assertThat( tHomePage.verifyZeroStateGoalsUsage(), "Zero state message displayed successfully!", "Issue in displaying zero state", driver );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )
    public void tcUsageGoalsWidget02() throws Exception {

        Log.testCaseInfo( "Reading Goals widget Test<small><b><i>[" + browser + "]</b></i></small>" );

        List<String> studentId = new ArrayList();
        IntStream.rangeClosed( 1, DataSetup.teacherStudentMap.get( username ).size() - 1 ).forEach( studentCount -> {
            studentId.add( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,personId" ) );
        } );

        //Asigning default course
        sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
        new BaseAPITest().assignCourse( smUrl, sessionCookie, "Reading", DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "2", studentId );
        createData( "Reading", 2 );

        new BaseAPITest().assignCourse( smUrl, sessionCookie, "Math", DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "1", studentId );
        createData( "Math", 2 );

        //Getting goals info
        goalsUsage = new BaseAPITest().getUsageGoal( smUrl, sessionCookie, DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ) );

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Toggling to usage goals
            Log.assertThat( tHomePage.toggleToUsageGoals(), "Goals widget switched successfully!", "Issue in switching goals widget", driver );

            //Verifying the hint
            Log.assertThat( tHomePage.getHintForGoals().equalsIgnoreCase( Constants.HomePageWidgetConstants.GOALS_HINT ), "Hint displayed successfully!", "Goals hint not displayed." );

            //Verifying goals legend and headers
            SMUtils.logDescriptionTC( "Verify the teacher can able to see only Math usage goals bar in goals window." );
            SMUtils.logDescriptionTC( "Verify the legends displayed for math course in usage goals section" );
            Log.assertThat( tHomePage.verifyGoalsBarLegends( true ), "All the Goals legends for Math are displayed successfully!", "Goals legends not displayed properly!", driver );
            Log.assertThat( tHomePage.verifyGoalsHeader(), "All the Goals Headers are displayed successfully!", "Goals headers not displayed properly!", driver );

            //Vereifying the goals bar data and color information
            SMUtils.logDescriptionTC( "Verify whether the bar chart is displayed properly to the user ( Math Course )" );
            SMUtils.logDescriptionTC( "Verify the % values are displayed properly in Math Usage Goals Section" );
            SMUtils.logDescriptionTC( "Verify whether the bar chart is showing appropriate progress based on legend values % ( Math Course )" );

            Log.assertThat( tHomePage.verifyGoalsBarValues( true, goalsUsage, browser ), "Verified the goals usage chart successfully!", "Issue in goals usage chart!", driver );

            //Verifying the edit usage goals and students towards goals.
            SMUtils.logDescriptionTC( "Verify the edit hyperlink in Math Usage goals section" );
            SMUtils.logDescriptionTC( "Verify whether the teacher able to see how many students are working towards the goals ( Math Course )" );
            Log.assertThat( tHomePage.verifyStudentsTowardsGoalsLink( true, goalsUsage ), "Goals edit link and students towards goals displayed successfully!", "Issue in displaying edit goals link!", driver );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )
    public void tcUsageGoalsWidget03() throws Exception {

        Log.testCaseInfo( "Reading Goals widget Test<small><b><i>[" + browser + "]</b></i></small>" );

        sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );

        //Getting goals details
        goalsUsage = new BaseAPITest().getUsageGoal( smUrl, sessionCookie, DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ) );

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Toggling to usage goals
            Log.assertThat( tHomePage.toggleToUsageGoals(), "Goals widget switched successfully!", "Issue in switching goals widget", driver );

            //Verifying the legends and headers for reading goals
            SMUtils.logDescriptionTC( "Verify the teacher can able to see only Reading usage goals bar in goals window." );
            Log.assertThat( tHomePage.verifyGoalsBarLegends( false ), "All the Goals legends for Math are displayed successfully!", "Goals legends not displayed properly!", driver );
            Log.assertThat( tHomePage.verifyGoalsHeader(), "All the Goals Headers are displayed successfully!", "Goals headers not displayed properly!", driver );

            //Verifying the usage goals bar, color and percentage value for reading usage goals.
            SMUtils.logDescriptionTC( "Verify whether the bar chart is displayed properly to the user ( Reading Course )" );
            SMUtils.logDescriptionTC( "Verify the % values are displayed properly in Reading Usage Goals Section" );
            SMUtils.logDescriptionTC( "Verify bar color appears based on the active student count." );
            SMUtils.logDescriptionTC( "Verify the Bar chart alligned to the student count." );
            Log.assertThat( tHomePage.verifyGoalsBarValues( false, goalsUsage, browser ), "Verified the goals usage chart successfully!", "Issue in goals usage chart!", driver );

            //Verifying the edit goals link for reading usage goals
            SMUtils.logDescriptionTC( "Verify whether the teacher able to see how many students are working towards the goals ( Reading Course )" );
            Log.assertThat( tHomePage.verifyStudentsTowardsGoalsLink( false, goalsUsage ), "Goals edit link and students towards goals displayed successfully!", "Issue in displaying edit goals link!", driver );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )
    public void tcUsageGoalsWidget04() throws Exception {

        Log.testCaseInfo( "Verify the student count is increased when the Math course assigned to additional students.<small><b><i>[" + browser + "]</b></i></small>" );

        sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
        String newTeacherName = "AutoMationTeacher" + System.nanoTime();
        goalsUsage = new BaseAPITest().getUsageGoal( smUrl, sessionCookie, DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ) );

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Toggling to usage goals
            tHomePage.toggleToUsageGoals();
            String studentCountBeforeAdditionMath = tHomePage.getEditGoalsLink( true );
            String studentCountBeforeAdditionReading = tHomePage.getEditGoalsLink( false );

            // navigate to Course Listing Page
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to student
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();

            // Selecting Reading Course and assigning to student
            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            tHomePage.topNavBar.navigateToHomeTab();

            //Toggling to usage goals and getting the values of student count and verifying with previous values
            tHomePage.toggleToUsageGoals();
            String studentCountAfterAdditionMath = tHomePage.getEditGoalsLink( true );
            String studentCountAfterAdditionReading = tHomePage.getEditGoalsLink( false );

            SMUtils.logDescriptionTC( "Verify the student count is increased when the Math course assigned to additional students." );
            Log.assertThat( !studentCountBeforeAdditionMath.equalsIgnoreCase( studentCountAfterAdditionMath ), "Student count alligned to active students in assignment", "Student count not changed after adding new student.", driver );

            SMUtils.logDescriptionTC( "Verify the student count is increased when the Reading course assigned to additional students." );
            Log.assertThat( !studentCountBeforeAdditionReading.equalsIgnoreCase( studentCountAfterAdditionReading ), "Student count alligned to active students in assignment", "Student count not changed after adding new student.", driver );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            //Creating new teacher for shring the teacher
            Integer newTeacherID = new UserSqlHelper().createTeacher( newTeacherName, newTeacherName, newTeacherName, Constants.PASSWORD_HASH, DataSetup.organizationId );
            Log.message( "Signed out from Successmaker!" );

            //Logging in as teacher 2
            smLoginPage.enterCredentialsAndLogIn( newTeacherName, password );

            //Navigating to groups tab and adding shared student
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            String groupName = "AutoMation_Usage_" + System.nanoTime();
            groupsTab.createGroupWithSchoolStudents( groupName, SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,userName" ), "All Grades" );

            //Getting usage goals for new teacher after adding shared student
            sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
            goalsUsage = new BaseAPITest().getUsageGoal( smUrl, sessionCookie, DataSetup.organizationId.toString(), newTeacherID.toString() );

            tHomePage.topNavBar.navigateToHomeTab();

            //Verifying the edit usage goals and student count
            tHomePage.toggleToUsageGoals();
            Log.assertThat( tHomePage.verifyStudentsTowardsGoalsLink( false, goalsUsage ), "Goals edit link and students towards goals displayed successfully!", "Issue in displaying edit goals link!", driver );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )
    public void tcUsageGoalsWidget05() throws Exception {

        Log.testCaseInfo( "Verify the student count decreased in goals usage when the student transfered to another school.<small><b><i>[" + browser + "]</b></i></small>" );

        sessionCookie = new BaseAPITest().getJessionCookie( smUrl, password, password );
        goalsUsage = new BaseAPITest().getUsageGoal( smUrl, sessionCookie, DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ) );

        String newOrgName = "Automation_Transfer_Org";

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            tHomePage.toggleToUsageGoals();
            String studentCountBeforeTransferMath = tHomePage.getEditGoalsLink( true );
            String studentCountBeforeTransferReading = tHomePage.getEditGoalsLink( false );

            //Logout the teacher
            tHomePage.topNavBar.signOutfromSM();

            //Creating new school for transfer
            String studentId = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,personId" );
            new SqlHelperOrganization().deleteOrganization( newOrgName );
            Integer newOrgId = new SqlHelperOrganization().createOrganization( newOrgName, newOrgName );

            //Transfer the student
            sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
            new BaseAPITest().transferUser( smUrl, sessionCookie, DataSetup.organizationId.toString(), newOrgId.toString(), "student", studentId );

            //Login as new teacher
            smLoginPage.enterCredentialsAndLogIn( username, password );

            //Navigating to home page and verifying the usage goals after transfering the student.
            tHomePage.topNavBar.navigateToHomeTab();
            tHomePage.toggleToUsageGoals();

            String studentCountAfterTransferMath = tHomePage.getEditGoalsLink( true );
            String studentCountAfterTransferReading = tHomePage.getEditGoalsLink( false );

            Log.assertThat( !studentCountAfterTransferReading.equalsIgnoreCase( studentCountBeforeTransferReading ), "After transfered the student goals count updated.", "After transfered the student goals count is not updated" );
            Log.assertThat( !studentCountAfterTransferMath.equalsIgnoreCase( studentCountBeforeTransferMath ), "After transfered the student goals count updated.", "After transfered the student goals count is not updated" );

            tHomePage.topNavBar.signOutfromSM();

            //Transferring teacher
            sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
            String teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" );
            new BaseAPITest().transferUser( smUrl, sessionCookie, DataSetup.organizationId.toString(), newOrgId.toString(), "teacher", teacherId );
            Log.message( "Teacher Transferred!" );
            new BaseAPITest().invalidateSession( smUrl, sessionCookie );

            //Creating one student for the transferred teacher without default course.
            String newStudentName = "Transfered_School_St_" + System.nanoTime();
            sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
            new BaseAPITest().createStudent( smUrl, sessionCookie, newStudentName, newStudentName, newStudentName, newStudentName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), newOrgId.toString(), "5" );

            //Login as transfered teacher
            smLoginPage.enterCredentialsAndLogIn( username, password );

            //Navigating to home page and verifying zero state
            tHomePage.topNavBar.navigateToHomeTab();
            tHomePage.toggleToUsageGoals();

            SMUtils.logDescriptionTC( "Verify the goals usage displayes zero state page when the teacher transfered to another school." );
            Log.assertThat( tHomePage.verifyZeroStateGoalsUsage(), "Zero state message displayed successfully!", "Issue in displaying zero state", driver );

            SMUtils.logDescriptionTC( "Verify the goals usage displayes zero state page when the teacher transfered to other school and associated with students without default course assignment. " );
            Log.assertThat( tHomePage.verifyZeroStateGoalsUsage(), "Zero state message displayed successfully!", "Issue in displaying zero state", driver );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            new SqlHelperOrganization().deleteOrganization( newOrgName );
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * Creating the test data.
     *
     * @param subject
     * @param studentCount
     * @throws Exception
     */
    private void createData( String subject, int studentCount ) throws Exception {
		EventFiringWebDriver driver = null;
        for ( int student = 1; student <= studentCount; student++ ) {
    		// Get driver
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		EventListener eventListner = new EventListener();
    		driver.register(eventListner);

            studentDetails = DataSetup.teacherStudentMap.get( username ).get( "Student" + student );
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, "data,userName" );
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
            if ( subject.equalsIgnoreCase( "math" ) ) {
                studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "Math", "80", "6", "30" );
                driver.quit();
                new SqlHelperUsage();
                SqlHelperUsage.shareUsageData( DataSetupConstants.BVT_SCHOOL );
            } else {
                studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "Reading", "80", "3", "15" );
                driver.quit();
                new SqlHelperUsage();
                SqlHelperUsage.shareUsageData( DataSetupConstants.BVT_SCHOOL );
            }
        }
    }
}
