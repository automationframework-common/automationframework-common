package com.savvas.sm.teacher.ui.tests.HomeSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;

/**
 * This java class file contains test cases for jira user story SMK-43632.
 *
 * @author baskar.panchavarnam
 *
 */

import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.teacher.ui.pages.TopNavBar;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

public class AssignmentWidgetTest extends BaseTest {
    private String browser;
    private static String username, usernameTeacher2 = null;
    private static String password;
    private String teacherID;
    private String smUrl;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String token = null;
    String studentSMDetails;
    private static String teacherTwoDetails;
    String orgId;
    String studentDetail, studentDetailsSecond, studentDetailsThree, studentDetailsFour;
    String stuOneFName, stuOneLName, stuTwoFName, stuTwoLName, stuThrFName, stuThrLName, stuFouFName, stuFouLName;
    private HashMap<String, String> groupDetails = new HashMap<>();

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        orgId = RBSDataSetup.organizationIDs.get( school );

        teacherTwoDetails = RBSDataSetup.getMyTeacher( school );
        usernameTeacher2 = SMUtils.getKeyValueFromResponse( teacherTwoDetails, RBSDataSetupConstants.USERNAME );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );

        studentDetail = RBSDataSetup.getMyStudent( school, username );
        studentDetailsSecond = RBSDataSetup.getMyStudent( school, username );
        studentDetailsThree = RBSDataSetup.getMyStudent( school, username );
        studentDetailsFour = RBSDataSetup.getMyStudent( school, username );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetail, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsThree, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsFour, "userId" ) );

        stuOneFName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" );
        stuOneLName = SMUtils.getKeyValueFromResponse( studentDetail, "lastName" );

        stuTwoFName = SMUtils.getKeyValueFromResponse( studentDetailsSecond, "firstName" );
        stuTwoLName = SMUtils.getKeyValueFromResponse( studentDetailsSecond, "lastName" );

        stuThrFName = SMUtils.getKeyValueFromResponse( studentDetailsThree, "firstName" );
        stuThrLName = SMUtils.getKeyValueFromResponse( studentDetailsThree, "lastName" );

        stuFouFName = SMUtils.getKeyValueFromResponse( studentDetailsThree, "firstName" );
        stuFouLName = SMUtils.getKeyValueFromResponse( studentDetailsThree, "lastName" );

        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

    }

    @Test ( description = "Verify the page navigates to corresponding assignment details page on clicking 'Assignment Title' from 'Assignment' widget ", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "SMK-10944 : Verify the page navigates to corresponding assignment details page on clicking 'Assignment Title' from 'Assignment' widget<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneStudent( stuOneFName + "," + stuOneLName );

            TopNavBar topNavBar = tHomePage.topNavBar;

            topNavBar.navigateToHomeTab();

            String assignName = tHomePage.toGetfirstAssignmentInWidget();

            String assignmentNameInDetailsPage = tHomePage.toNavigateToFirstAssignmentDetails();

            Log.assertThat( assignName.contains( assignmentNameInDetailsPage ), "Assignment " + assignName + " is displaying correctly in details page", "Corresponding Assignment details page is not displaying" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the page navigates to corresponding assignment details page on clicking '# of Students Assigned' link from 'Assignment' widget", priority = 2, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "SMK-10945 : Verify the page navigates to corresponding assignment details page on clicking '# of Students Assigned' link from 'Assignment' widget<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneStudent( stuOneFName + "," + stuOneLName );

            TopNavBar topNavBar = tHomePage.topNavBar;

            topNavBar.navigateToHomeTab();

            String assignName = tHomePage.toGetfirstAssignmentInWidget();

            String assignmentNameInDetailsPage = tHomePage.toNavigateToFirstAssignmentDetailsByStudentCount();

            Log.assertThat( assignmentNameInDetailsPage.contains( assignName ), "Assignment " + assignName + " is displaying as " + assignmentNameInDetailsPage + " in details page", "Corresponding Assignment details page is not displaying" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher user able to view 'Assignments' widget in Home page", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "SMK-10928 : Verify the teacher user able to view 'Assignments' widget in Home page<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            SMUtils.isElementPresent( tHomePage.assignmentsWidgetTitleName );

            Log.assertThat( tHomePage.assignmentsWidgetTitleName.getText().trim().equals( Constants.ASSIGNMENTS ), "Assignment widget is present on the Home page", "Assignment widget is not present on the Home page" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Assignment widget Tab after navigated from other tab", priority = 2, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "SMK-10929 : Verify the teacher user able to view 'Assignments' widget in Home page after navigating from other tabs<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            tHomePage.topNavBar.navigateToCourseListingPage();

            TopNavBar topNavBar = tHomePage.topNavBar;

            topNavBar.navigateToHomeTab();
            SMUtils.waitForElement(driver, tHomePage.assignmentsWidgetTitleName , 10 );

            SMUtils.isElementPresent( tHomePage.assignmentsWidgetTitleName );

            Log.assertThat( tHomePage.assignmentsWidgetTitleName.getText().trim().equals( Constants.ASSIGNMENTS ), "Assignment widget is present on the Home page", "Assignment widget is not present on the Home page" );

            // Sign out from the SM_Application

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = " Verify the page navigates to corresponding assignment details page on clicking 'Assignment Thumbnail' icon from 'Assignment' widget", priority = 2, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        String studentFirstNameAndLastName = stuTwoFName + "," + stuTwoLName;

        Log.testCaseInfo( "SMK-10946 : Verify the page navigates to corresponding assignment details page on clicking 'Assignment Thumbnail' icon from 'Assignment' widget<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );

            TopNavBar topNavBar = tHomePage.topNavBar;

            topNavBar.navigateToHomeTab();

            String assignName = tHomePage.toGetfirstAssignmentInWidget();

            String assignmentNameInDetailsPage = tHomePage.toNavigateToFirstAssignmentDetailsByThumbnail();

            Log.assertThat( assignmentNameInDetailsPage.contains( assignName ), "Assignment " + assignName + " is displaying as " + assignmentNameInDetailsPage + " in details page", "Corresponding Assignment details page is not displaying" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'View All >' link displays in Assignments widget even if the teacher has less than 4 courses assigned ", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        String studentFirstNameAndLastName = stuThrFName + "," + stuThrLName;

        Log.testCaseInfo( "SMK-10947 : Verify the 'View All >' link displays in Assignments widget even if the teacher has less than 4 courses assigned <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );

            TopNavBar topNavBar = tHomePage.topNavBar;

            topNavBar.navigateToHomeTab();

            Boolean viewAllLinkStatus = tHomePage.toGetViewAllLinkAvailability();
            Log.assertThat( viewAllLinkStatus.equals( Constants.STATUSTRUE ), "View All link is displaying correctly in Assignments widget", "View All link is not displaying" );

            // Sign out from the SM_Application

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the recently assigned assignments are displaying on top in the widget (AC04)", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        String studentFirstNameAndLastName = stuThrFName + stuThrLName;

        Log.testCaseInfo( "SMK-10931 : Verify the recently assigned assignments are displaying on top in the widget<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            String customCourse = "AAA Custom Reading" + System.nanoTime();

            coursePage.copyOfCourse( customCourse, Constants.STANDARDS, Constants.READING );

            tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( customCourse );

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );

            TopNavBar topNavBar = tHomePage.topNavBar;

            topNavBar.navigateToHomeTab();

            String firstAssignmentName = tHomePage.toGetfirstAssignmentInWidget();
            Log.message( "Created Course Name : " + customCourse );
            Log.message( "First Assignment Displayed in Assignment widget : " + firstAssignmentName );

            Log.assertThat( customCourse.equals( firstAssignmentName ), "Assignment " + firstAssignmentName + " is displaying correctly as first assignment in widget", firstAssignmentName + " Corresponding Assignment is not displaying as first" );
            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the text '1 Student Assigned' displayed when single student assigned to an assignment", priority = 1, groups =

    { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget008() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        String studentFirstNameAndLastName = stuTwoFName + "," + stuTwoLName;

        Log.testCaseInfo( "SMK-10941 : Verify the text '1 Student Assigned' displayed when single student assigned to an assignment<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            TopNavBar topNavBar = tHomePage.topNavBar;

            String customCourse = "AAA Custom Reading" + System.nanoTime();

            coursePage.copyOfCourse( customCourse, Constants.STANDARDS, Constants.READING );

            tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( customCourse );

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );
            topNavBar.navigateToHomeTab();

            String assignmentStudentCount = tHomePage.toGetfirstAssignmentStudentCount();
            Log.assertThat( assignmentStudentCount.equals( Constants.ONESTUDENTASSIGNED ), "Assigned student count displays correctly", "Student count is incorrect" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the students count in 'Assignment' widget when the students are added from groups", priority = 1, groups =

    { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        CoursesPage customCourses = new CoursesPage( driver );

        Log.testCaseInfo( "SMK-10943 : Verify the students count in 'Assignment' widget when the students are added from groups<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            String customCourse = "AAA Custom Group Assignment" + System.nanoTime();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( customCourse, Constants.STANDARDS, Constants.READING );

            tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( customCourse );

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneGroup();

            TopNavBar topNavBar = tHomePage.topNavBar;

            topNavBar.navigateToHomeTab();

            String assignmentStudentCount = tHomePage.toGetfirstAssignmentStudentCount();

            Log.message( "Assigned custom course : " + assignmentStudentCount );

            Log.assertThat( !assignmentStudentCount.equals( Constants.THREESTUDENTSASSIGNED ), "Assigned student count displays correctly", "Student count is incorrect" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify both the Default and custom course assignments are displaying in 'Assignments' widget", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget010() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        CoursesPage customCourses = new CoursesPage( driver );

        String staticCourseName = customCourses.generateRandomCourseName() + System.nanoTime();

        String studentFirstNameAndLastName = stuThrFName + stuThrLName;

        Log.testCaseInfo( "SMK-10948 : Verify both the Default and custom course assignments are displaying in 'Assignments' widget<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            TopNavBar topNavBar = tHomePage.topNavBar;

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Sort by date descending

            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course

            customCourses.clickFromCourseListingPage( staticCourseName );

            // Click on Assign button

            coursePage.clickAssignBtn();

            //Add one student to assignment

            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );

            topNavBar.navigateToHomeTab();

            String firstCustomAssignmentName = tHomePage.toGetfirstAssignmentInWidget();

            Log.assertThat( firstCustomAssignmentName.contains( staticCourseName ), "Custom Assignment '" + staticCourseName + "' is displaying correctly as first assignment in widget", "Corresponding Assignment is not displaying as first" );

            // Sign out from the SM_Application

            topNavBar.navigateToCourseListingPage();

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );

            topNavBar.navigateToHomeTab();

            String firstDefaultAssignmentName = tHomePage.toGetfirstAssignmentInWidget();

            Log.assertThat( firstDefaultAssignmentName.contains( Constants.MATH ), "Default Assignment '" + firstDefaultAssignmentName + "' is displaying correctly as first assignment in widget",
                    "Corresponding Assignment is not displaying as first, Actual result " );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify only 4 assignments are displaying in the 'Assignment' widget even more than 4 assigned to the corresponding teacher", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "SMK-10930 : Verify only 4 assignments are displaying in the 'Assignment' widget even more than 4 assigned to the corresponding teacher<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            int noOfAssignments = tHomePage.getAllAssignmentsCountIntheAssignmentWidget();

            Log.assertThat( noOfAssignments == Constants.MAXASSIGNMENTCOUNT, "No of assignments displayed correctly as : " + noOfAssignments, "Assignment count is incorrect" );

            // Sign out from the SM_Application

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the removed assignments are not available in the 'Assignments' widget", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget", "P3 & P4" } )

    public void tcSMAssignmentsWidget012() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        CoursesPage customCourses = new CoursesPage( driver );

        String staticCourseName = customCourses.generateRandomCourseName() +System.nanoTime();

        String studentFirstNameAndLastName = stuFouFName + stuFouLName;

        Log.testCaseInfo( "SMK-10932 : Verify the removed assignments are not available in the 'Assignments' widget <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            TopNavBar topNavBar = tHomePage.topNavBar;

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down

            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //  Click on the course

            customCourses.clickFromCourseListingPage( staticCourseName );

            // Click on Assign button

            coursePage.clickAssignBtn();

            //Add one student to assignment

            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );

            // Navigate 'CourseWare' tab and select the 'Assignments' option
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment

            assignmentsPage.clickAssignmentSubMenu();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( staticCourseName );

            // Closing the Ellipsis icon at the student level
            assignmentDetailsPage.clickDotEllipsisButton();

            // Clicking on the Assignment_Settings option in the Ellipsis
            assignmentDetailsPage.assignmentSettingInEllipsis();

            SMUtils.logDescriptionTC( "SMK-7241 - Delete Assignment settings in the view assignmnet details page." );

            // Delete Assignment
            assignmentDetailsPage.deleteAssignmenttab();
            assignmentDetailsPage.deleteAssignmentButton();
            Log.assertThat( assignmentDetailsPage.AssignmentDeleted(), "Assignment has deleted successfully", "Assignment has not deleted successfully" );

            topNavBar.navigateToHomeTab();

            Log.assertThat( !tHomePage.toGetfirstAssignmentInWidget().contains( staticCourseName ), "Deleted Assignment is not displaying in widget", "Deleted Assignment is displaying as first" );

            // Sign out from the SM_Application

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Assign few courses with almost similar name and almost same time then verify the recent assignments are available on top of the widget", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget013() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        CoursesPage customCourses = new CoursesPage( driver );

        String staticCourseName = "Custom Reading" + System.nanoTime();

        String studentFirstNameAndLastName = stuFouFName + stuFouLName;

        Log.testCaseInfo( "SMK-10933 : Assign few courses with almost similiar name and almost same time then verify the recent assignments are available on top of the widget<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            TopNavBar topNavBar = tHomePage.topNavBar;

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Sort by date descending

            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course

            customCourses.clickFromCourseListingPage( staticCourseName );

            // Click on Assign button

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );

            staticCourseName = "AAa Custom Reading" + System.nanoTime();

            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            // Click on Assign button

            coursePage.clickAssignBtn();

            //Add one student to assignment
            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );

            topNavBar.navigateToHomeTab();

            String firstCustomAssignmentName = tHomePage.toGetfirstAssignmentInWidget();

            Log.assertThat( firstCustomAssignmentName.contains( staticCourseName ), "Recent Custom Assignment '" + staticCourseName + "' is displaying correctly as first assignment in widget", "Corresponding Assignment is not displaying as first" );

            topNavBar.navigateToCourseListingPage();

            // Sign out from the SM_Application

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        }

        catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Create few assignments with long name and verify its displaying correctly", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget014() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        CoursesPage customCourses = new CoursesPage( driver );

        String staticCourseName = "AAa Custom Reading Course contains long name Long _ " + System.nanoTime();

        String studentFirstNameAndLastName = stuOneFName + stuOneLName;

        Log.testCaseInfo( "SMK-10934 : Create few assignments with long name and verify its displaying correctly<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            TopNavBar topNavBar = tHomePage.topNavBar;

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            // Click on Assign button

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );

            topNavBar.navigateToHomeTab();

            String firstCustomAssignmentName = tHomePage.toGetfirstAssignmentInWidget();

            Log.assertThat( firstCustomAssignmentName.contains( staticCourseName ), "Long Custom course name '" + staticCourseName + "' is displaying correctly as first assignment in widget", "Corresponding Assignment is not displaying as first" );
            // Sign out from  the SM_Application

            topNavBar.navigateToCourseListingPage();

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Create an assignment with special characters and digits and verify its displaying correctly", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget015() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        CoursesPage customCourses = new CoursesPage( driver );

        String staticCourseName = "AAa Custom Reading Special char !# $%^&(3455 <?:{}_+MN,._ " + System.nanoTime();

        String studentFirstNameAndLastName = stuTwoFName + stuTwoLName;

        Log.testCaseInfo( "SMK-10935 : Create an assignment with special characters and digits and verify its displaying correctly <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            TopNavBar topNavBar = tHomePage.topNavBar;

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            // Click on Assign button

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );

            topNavBar.navigateToHomeTab();

            String firstCustomAssignmentName = tHomePage.toGetfirstAssignmentInWidget();

            Log.assertThat( firstCustomAssignmentName.contains( staticCourseName ), "Long Custom course name '" + staticCourseName + "' is displaying correctly as first assignment in widget", "Corresponding Assignment is not displaying as first" );
            // Sign out from the SM_Application

            topNavBar.navigateToCourseListingPage();

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the icons are displaying correctly for each Assignments", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget016() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        CoursesPage customCourses = new CoursesPage( driver );

        String staticCourseName = "AAa Special Custom Reading  char !# $%^&(3455 <?:{}_+MN,._ " + System.nanoTime();

        String studentFirstNameAndLastName = stuThrFName + stuThrLName;

        Log.testCaseInfo( "SMK-10936 : Verify the icons are displaying correctly for each Assignments <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            TopNavBar topNavBar = tHomePage.topNavBar;

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectMyCustomCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Click on the course

            customCourses.clickFromCourseListingPage( staticCourseName );

            // Click on Assign button

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneStudent( studentFirstNameAndLastName );

            topNavBar.navigateToHomeTab();

            Log.assertThat( tHomePage.toCheckTheAssignmentThumbnail().equals( Constants.STATUSTRUE ), "Assignment thumbnail icon displaying correctly", "Thumbnail icons is not displaying for an assignment" );

            SMUtils.logDescriptionTC( "SMK-10937 - Verify the horizondal seperator line displays between each assignments in widget." );

            Log.assertThat( tHomePage.toCheckSeperatorLine().equals( Constants.STATUSTRUE ), "Separator Line displays correctly in between assignments", "No Separator line displays in Assignment widget" );

            // Sign out from the SM_Application

            topNavBar.navigateToCourseListingPage();

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the text '# Students Assigned' displayed when more than one students assigned to an assignment", priority = 1, groups =

    { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget018() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "SMK-10942 : Verify the text '# Students Assigned' displayed when more than one students assigned to an assignment <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            String customCourse = "AAA Students_Custom Reading" + System.nanoTime();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( customCourse, Constants.STANDARDS, Constants.READING );

            tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( customCourse );

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneGroup();

            TopNavBar topNavBar = tHomePage.topNavBar;

            topNavBar.navigateToHomeTab();

            Log.assertThat( !tHomePage.toGetfirstAssignmentStudentCount().equals( Constants.ONESTUDENTASSIGNED ), "Student count displays correctly as '3 Students Assigned'", "Student count is incorrect" ); // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if the user has no assigned assignments", priority = 1, groups = { "SMK-43632", "homePage", "assignmentsWidget" } )

    public void tcSMAssignmentsWidget019() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        CoursesPage customCourses = new CoursesPage( driver );
        String newTeacherUname = "tempteacheruname";

        //Creating teacher for Zero state test new

        new UserAPI().createUserWithCustomization( newTeacherUname, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );

        Log.testCaseInfo( "SMK-10938 : Verify the message when the user has no assigned assignments <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, newTeacherUname, RBSDataSetupConstants.DEFAULT_PASSWORD );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            TopNavBar topNavBar = tHomePage.topNavBar;

            topNavBar.navigateToHomeTab();

            Log.assertThat( tHomePage.toGetZeroStateMessageInAssignmentWidget().equals( "NO ASSIGNMENTS" ), "Zero state text appears in Assignment widget", "Zero state text is not getting appeared" );

            SMUtils.logDescriptionTC( "SMK-10939 : Verify 'View All' link is not available when the user has no assigned assignments" );

            Log.assertThat( !tHomePage.checkViewAllLinkAvailabilityEmpty(), "View All link is not getting appeared as expected", "View All link appears" );

            SMUtils.logDescriptionTC( "SMK-10949 : Verify the assignment of other teacher(without a common teacher) from the same org is not shown (AC02)" );

            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            Log.assertThat( assignmentsPage.getZeroStateMessage().equals( Constants.Assignments.ZERO_MESSAGE ), "Zero state text appears in Assignment details page", "Zero state text is not getting appeared" );

            // Sign out from the SM_Application

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}