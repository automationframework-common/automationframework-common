package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Reports;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class ReportComponent {

    private WebDriver driver;
    WebElement shadowTree = null;
    WebElement staticDropdown = null;
    String staticDropdownList = null;
    
    public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();

    // ********* SuccessMaker Report Page Elements ***************
    @IFindBy(how = How.CSS, using=  "section.page-title div h1",AI = false)
    public WebElement reportHeader;

    @FindBy ( css = "div.form-section div div.form-group label" )
    List<WebElement> lblStaticDropdownHeading;

    @IFindBy(how = How.CSS, using=  "p.description",AI = false)
    public WebElement txtReportDescription;

    @IFindBy(how = How.CSS, using=  ".col-md-2 cel-multi-check-dropdown.ng-cel-multi-check-dropdown",AI = false)
    public WebElement lblSubjectDropdown;

    @IFindBy(how = How.CSS, using=  "div.step2 .pr-md-5 label",AI = false)
    public WebElement lblAssignemntDropdownHeader;

    @IFindBy(how = How.CSS, using=  ".col-md-6 cel-multi-check-dropdown.ng-cel-multi-check-dropdown",AI = false)
    public WebElement lblAssignemntDropdown;

    @IFindBy(how = How.CSS, using=  "report-filters cel-accordion-grid div button[aria-expanded='false']",AI = false)
    public WebElement btnExpandFilter;

    @IFindBy(how = How.CSS, using=  "report-filters cel-accordion-grid div button[aria-expanded='true']",AI = false)
    public WebElement btnCollapseFilter;

    @FindBy ( css = "div.row  div.d-flex" )
    List<WebElement> rbGroupAndStudentDropdownParent;

    @IFindBy(how = How.CSS, using=  "save-report-options cel-radio-button div input[value='new']",AI = false)
    public WebElement rbNewSaveReportOption;

    @IFindBy(how = How.CSS, using=  "save-report-options cel-radio-button div input[value='update']",AI = false)
    public WebElement rbReplaceReportOption;

    @IFindBy(how = How.CSS, using=  "form div >div > input",AI = false)
    public WebElement txtFilterName;

    @IFindBy(how = How.CSS, using=  "#existingReportName div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon",AI = false)
    public WebElement expandFilterOption;

    @FindBy ( css = "div.d-block" )
    List<WebElement> lblGroupAndStudentsDropdown;

    @IFindBy(how = How.CSS, using=  ".col-md-2 div.assignments-select cel-multi-check-dropdown",AI = false)
    public WebElement shadowRootSubjectsDropdown;

    @IFindBy(how = How.CSS, using=  ".col-md-6 cel-multi-check-dropdown.ng-cel-multi-check-dropdown",AI = false)
    public WebElement shadowRootAssignmentsDropdown;

    @IFindBy(how = How.CSS, using=  "#savedOptions",AI = false)
    public WebElement msSaveOptionDropdown;

    @IFindBy(how = How.CSS, using=  "#additionalGrouping",AI = false)
    public WebElement msAdditionalGroupingDropdown;

    @IFindBy(how = How.CSS, using=  "#display",AI = false)
    public WebElement msDisplayDropdown;

    @IFindBy(how = How.CSS, using=  "#existingReportName button",AI = false)
    public WebElement existingReportDropdown;

    @IFindBy(how = How.CSS, using=  "#sort",AI = false)
    public WebElement msSortDropdown;

    @IFindBy(how = How.CSS, using=  "#dateAtRisk",AI = false)
    public WebElement msDateAtRiskDropdown;

    @FindBy ( css = " div cel-checkbox" )
    List<WebElement> chbxMaskStudentDisplayAndRemovePageBreaksRoot;

    @IFindBy(how = How.CSS, using=  "div.form-actions cel-button.run-button.hydrated",AI = false)
    public WebElement btnRunReportRoot;

    @IFindBy(how = How.CSS, using=  "div.form-actions cel-button.save-button.hydrated",AI = false)
    public WebElement btnSaveReportRoot;

    @IFindBy(how = How.CSS, using=  "#savedOptions div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon",AI = false)
    public WebElement expandSaveOptionDropdown;

    @IFindBy(how = How.CSS, using=  "#additionalGrouping div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon",AI = false)
    public WebElement expandAdditionalGroupingDropdown;

    @IFindBy(how = How.CSS, using=  "#display div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon",AI = false)
    public WebElement expandDisplayDropdown;

    @IFindBy(how = How.CSS, using=  "#sort div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon",AI = false)
    public WebElement expandSortDropdown;

    @IFindBy(how = How.CSS, using=  "#dateAtRisk div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon",AI = false)
    public WebElement expandDateAtRiskDropdown;

    @IFindBy(how = How.CSS, using=  "#savedOptions div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon[aria-hidden='true']",AI = false)
    public WebElement collapseSaveOptionDropdown;

    @IFindBy(how = How.CSS, using=  "#additionalGrouping div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon[aria-hidden='true']",AI = false)
    public WebElement collapseAdditionalGroupingDropdown;

    @IFindBy(how = How.CSS, using=  "#display div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon[aria-hidden='true']",AI = false)
    public WebElement collapseDisplayDropdown;

    @IFindBy(how = How.CSS, using=  "#sort div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon[aria-hidden='true']",AI = false)
    public WebElement collapseSortDropdown;

    @FindBy ( css = "#additionalGrouping div div ul li" )
    List<WebElement> listAdditionalGrouping;

    @FindBy ( css = "#display div div li" )
    List<WebElement> listdisplay;

    @FindBy ( css = "#sort div div ul li" )
    List<WebElement> listSort;

    @FindBy ( css = "#dateAtRisk div ul li" )
    List<WebElement> listDateAtRisk;

    @FindBy ( css = "#savedOptions div div ul li" )
    List<WebElement> listSavedOptions;

    @IFindBy(how = How.CSS, using=  "#existingReportName div div ul",AI = false)
    public WebElement listFilterOptions;

    @IFindBy(how = How.CSS, using=  "#existingReportName div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon",AI = false)
    public WebElement expandReplaceExistingDropdown;

    @IFindBy(how = How.CSS, using=  "cel-button.button.save-button.hydrated",AI = false)
    public WebElement btnSavereportPopupOptionRoot;

    @IFindBy(how = How.CSS, using=  "span.error-message span",AI = false)
    public WebElement errorMessage;

    @FindBy ( css = "#language div div ul li" )
    List<WebElement> listLanguage;

    @IFindBy(how = How.CSS, using=  "#dateAtRisk div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon",AI = false)
    public WebElement expanddateAtRiskDropdown;

    @IFindBy(how = How.CSS, using=  "#language div button span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon",AI = false)
    public WebElement expandlanguageDropdown;

    @FindBy ( css = "h2.title" )
    List<WebElement> lblFilterAndReportOptionsHeading;

    @FindBy ( css = "h3.title2" )
    List<WebElement> lblRefineSearchAndGroupOrStudentHeading;

    @FindBy ( css = "label.title-label" )
    List<WebElement> lblMSDropdownHeader;

    @IFindBy(how = How.CSS, using=  "report-options div.form-group div.col-md-3 label",AI = false)
    public WebElement lblSavedOptionHeading;

    @IFindBy(how = How.CSS, using=  "#additionalGrouping span.dropdown-select-label",AI = false)
    public WebElement lblSelectedOptionForAdditionalGrouping;

    @IFindBy(how = How.CSS, using=  "#display span.dropdown-select-label",AI = false)
    public WebElement lblSelectedOptionForDisplay;

    @IFindBy(how = How.CSS, using=  "#sort span.dropdown-select-label",AI = false)
    public WebElement lblSelectedOptionForSort;

    @IFindBy(how = How.CSS, using=  "#dateAtRisk span.dropdown-select-label",AI = false)
    public WebElement lblSelectedOptionForDateAtRiskt;

    @IFindBy(how = How.CSS, using=  "#language span.dropdown-select-label",AI = false)
    public WebElement lblSelectedOptionForLanguage;

    @FindBy ( css = "div.d-flex span span" )
    List<WebElement> countOfSelectedFilters;

    @IFindBy(how = How.CSS, using=  "div.dialog-header h1",AI = false)
    public WebElement saveReportPopUpTextHeader;

    @FindBy ( css = "div.radio-btn-group label" )
    List<WebElement> saveReportPopupDropdownHeaders;

    @IFindBy(how = How.CSS, using=  "cel-button.cancel-button",AI = false)
    public WebElement cancelBtnSaveReportPopUpRoot;

    @IFindBy(how = How.CSS, using=  "cel-button.button.save-button.hydrated",AI = false)
    public WebElement saveBtnOnSaveReportPopUpRoot;

    @IFindBy(how = How.CSS, using=  ".ml-1",AI = false)
    public WebElement errorMsgSaveReport;

    @IFindBy(how = How.CSS, using=  "#savedOptions span span",AI = false)
    public WebElement savedOptionSelectedValue;

    @FindBy ( css = "#existingReportName ul li span" )
    List<WebElement> existingReportValues;

    @IFindBy(how = How.CSS, using=  "save-report-options cel-radio-button div input[value='update']",AI = false)
    public WebElement rbLoadReportOption;

    @FindBy ( css = "#additionalGrouping a.dropdown-option-link" )
    List<WebElement> additionalGroupingDropdownValues;

    @FindBy ( css = "#display a.dropdown-option-link" )
    List<WebElement> displayDropdownValues;

    @FindBy ( css = "#sort a.dropdown-option-link" )
    List<WebElement> sortDropdownValues;

    @FindBy ( css = "#dateAtRisk > div > div > ul > li > a" )
    List<WebElement> dateAtRiskDropdownValues;

    @FindBy ( css = "#language > div > div > ul > li > a" )
    List<WebElement> languagekDropdownValues;

    @IFindBy(how = How.CSS, using=  "cel-multi-check-dropdown.disabled",AI = false)
    public WebElement zeroStateRoot;

    @IFindBy(how = How.CSS, using=  "h3.header",AI = false)
    public WebElement headerTextZeroState;

    @IFindBy(how = How.CSS, using=  "span.message",AI = false)
    public WebElement zeroStateDescription;

    @IFindBy(how = How.CSS, using=  "span.pad-left",AI = false)
    public WebElement collapsedFiltertext;

    @IFindBy(how = How.CSS, using=  "cel-dialog-header cel-icon",AI = false)
    public WebElement popupHelpIconRoot;

    @IFindBy(how = How.CSS, using=  "div#contentBody h1",AI = false)
    public WebElement headerForHelpContent;

    @IFindBy(how = How.CSS, using=  "button[class='accordion-header clickable']",AI = false)
    public WebElement btnFilter;

    // Child elements for shadow root
    String popupHelpIconChild = "img";

    String collapseMsDropdown = "span.head-icons cel-icon[aria-pressed='true']";

    String expandMsDropdown = "span.head-icons cel-icon[aria-pressed='false']";

    String shadowRootSelectDropDownMS = ".multi-check-dropdown-container .dropdown-list .dropdown-scroll .dropdown-list-items .dropdown-single-select cel-checkbox";// List<WebElement>

    String txtDropDownMSValue = ".primary__checkbox span";

    String valuesFromMSDropdown = ".checkbox__label";

    String primary_button = ".primary_button";

    String secondary_button = ".secondary_button";

    String reportOption = "li:nth-child(%s)";

    String chbxSelectALLParentRoot = "cel-checkbox.hydrated";

    String chbxDropdownMS = "label.checkbox__container input[type='checkbox']";

    String txtInsideMsDropdown = "span.head-label";

    String chbxSelectALL = "input[type=checkbox]";

    String dropdownBtnChild = "button.dropdown-head";

    String lblRemovePageBreakAndMaskStudentDiplayText = "label.checkbox__label";

    String chbxRemovePageBreakAndMaskStudentDiplay = "label.checkbox__container input[type='checkbox']";

    String shadowRootGroupAndStudentsDropdown = "cel-multi-check-dropdown.hydrated";

    String txtGroupAndStudentDropdown = "div.d-block label";

    String rbGroupAndStudentDropdown = "cel-radio-button input[type='radio']";

    String zeroStateChild = "button.dropdown-no-data span span";

    String assignmentszeroState = "span.head-label";

    String rbGroupAndStudentDropDownDisplay = "cel-multi-check-dropdown";

    String subjectDropdownValues = "label.checkbox__label";

    public ReportComponent() {}
    /**
     * Constructor to invoke the report component
     *
     * @param driver
     */
    public ReportComponent( WebDriver driver ) {
        this.driver = driver;
        // Have Topbar here and init
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
    	PageFactory.initElements(finder, this);
    	elementLayer = new ElementLayer(driver);


    }

    /**
     * get the report header
     *
     * @return
     */
    public String getReportPageHeader() {
        SMUtils.waitForElement( driver, reportHeader );
        return reportHeader.getText().trim();
    }

    /***
     * Checks and return the boolean for Report Description
     *
     * @return
     * @throws InterruptedException
     */
    public String getReportDescription() throws InterruptedException {
        SMUtils.waitForElement( driver, txtReportDescription );
        return txtReportDescription.getText().trim();
    }

    /**
     * Get Save Report option Window pop up new header Text
     */
    public String saveReportOptionReplaceExistingFieldHeader() {
        Log.message( "Returning Replace Existing Report header " );
        return saveReportPopupDropdownHeaders.get( 1 ).getText();
    }

    /**
     * Click select all checkbox for Multi-Select Dropdown
     *
     * @param dropdownName
     */
    public void clickSelectALLFromMSDropdownwithJS( String dropdownName ) throws InterruptedException {
        setDropDownMS( dropdownName );
        // Expand multi-select Dropdown Expanded
        if ( isDropDownMSCollapsed() )
            expandDropDownMSWithJS();
        WebElement chbxSelectAllRoot = SMUtils.getWebElement( driver, shadowTree, chbxSelectALLParentRoot );
        WebElement chbxSelectAll = SMUtils.getWebElement( driver, chbxSelectAllRoot, txtDropDownMSValue );
        SMUtils.waitForElement( driver, chbxSelectAll );
        chbxSelectAll.click();
        Log.message( "SELECT ALL check box clicked successfully" );
    }

    /***
     * Get values from Multi-Select drop down
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getValuesFromStaticDropDown( String dropDownName ) throws Exception {
        List<String> msDropDownValues = new ArrayList<>();
        do {
            expandStaticDropDownMS( dropDownName );
            // get values from ms drop down
            List<WebElement> msValuesList = selectStaticDropDown( dropDownName );
            for ( WebElement value : msValuesList ) {
                msDropDownValues.add( value.getText().toLowerCase().trim() );
            }
            expandStaticDropDownMS( dropDownName );
        } while ( msDropDownValues.isEmpty() );
        Log.message( "Got all options from " + dropDownName + " Dropdown!" );
        return msDropDownValues;
    }

    /**
     * Expand Filters with Js
     *
     */
    public void expandFilterButtonWithJS() {
        SMUtils.clickJS( driver, btnExpandFilter );
        Log.message( "Filter expanded successfully" );
    }

    /**
     * Get Save Report option Window pop up new header Text
     */
    public String saveReportOptionNewFieldHeader() {
        Log.message( "Returning New text header on Save Report option " );
        return saveReportPopupDropdownHeaders.get( 0 ).getText();
    }

    /***
     * Get values from Multi-Select drop down For Clicking Using ClickJS
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getValuesFromDropDownMultiSelect() throws Exception {
        List<String> msDropDownValues = new ArrayList<>();
        if ( Objects.isNull( shadowTree ) )
            throw new Exception( "Set DropdownMS value first" ); // expand ms drop
        // down
        expandDropDownMSWithJS(); // get values from ms drop down
        List<WebElement> msValuesList = SMUtils.getWebElements( driver, shadowTree, shadowRootSelectDropDownMS );
        for ( WebElement value : msValuesList ) {
            WebElement txtGroupStudents = SMUtils.getWebElement( driver, value, valuesFromMSDropdown );

            msDropDownValues.add( txtGroupStudents.getText() );

        }
        Log.message( "Got all options from MS Dropdown!" );
        return msDropDownValues;
    }

    /***
     * expand multi-select drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void expandDropDownMSWithJS() throws InterruptedException {
        if ( isDropDownMSCollapsed() ) {
            WebElement btnDropDownExpand = SMUtils.getWebElement( driver, shadowTree, expandMsDropdown );
            SMUtils.clickJS( driver, btnDropDownExpand );
            Log.message( "Expands Multi select dropdown" );
        }
        Log.assertThat( isDropDownMSExpanded(), "DropDown Expanded-Successful", "DropDown Expanded-Not Successful" );
    }

    /**
     * Loading the saved report options.
     *
     * @param reportName
     * @return
     */
    public String replaceExistingReport( String reportName ) {
        try {
            expandReplaceExistingDropdown.click();
            String reportOptionCount = listFilterOptions.getAttribute( "childElementCount" );
            String reportNameUI = null;
            for ( int i = 1; i <= Integer.parseInt( reportOptionCount ); i++ ) {
                reportNameUI = driver.findElement( By.cssSelector( String.format( reportOption, i ) ) ).getText();
                if ( reportNameUI.toLowerCase().equals( reportName.toLowerCase() ) ) {
                    SMUtils.clickJS( driver, driver.findElement( By.cssSelector( String.format( reportOption, i ) ) ) );
                    Log.message( "Replace Existing report option - " + reportName );
                    break;
                }
            }
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.fail( "Error in loading the report option!", driver );
        }
        return reportName;
    }

    /**
     * Click Save Button on Save Report option window pop up
     */
    public boolean isSaveBtnDisplayedOnSaveReportPopUp() {
        SMUtils.waitForElement( driver, btnSavereportPopupOptionRoot );
        Log.message( "Validate save button is displaying" );
        return btnSavereportPopupOptionRoot.isDisplayed();

    }

    /**
     * Click Save Button on Save Report option window pop up
     */
    public void clickSaveOnSaveReportPopUp() {
        WebElement saveReportPopup = SMUtils.getWebElementDirect( driver, btnSavereportPopupOptionRoot, primary_button );
        SMUtils.waitForElementToBeClickable( saveReportPopup, driver );
        SMUtils.clickJS( driver, saveReportPopup );
        Log.message( "Save Report button click successfully" );
    }

    /**
     * Enter the report option name for more than 50 char.
     *
     *
     */
    public void typeReportName( String reportName ) {
        try {
            SMUtils.waitForElement( driver, rbNewSaveReportOption );
            SMUtils.clickJS( driver, rbNewSaveReportOption );
            txtFilterName.sendKeys( reportName );
            Log.message( "Enter New Report name" );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * Click on Cancel button on save report option pop up
     *
     */
    public boolean isCancelBtnDisplayedOnSaveReport() {
        SMUtils.waitForElement( driver, cancelBtnSaveReportPopUpRoot );
        Log.message( "Validate cancel button is displaying" );
        return cancelBtnSaveReportPopUpRoot.isDisplayed();
    }

    /**
     * Replace the report option.
     *
     * @param reportName
     * @return
     */
    public String replaceReportOption( String reportName ) {
        try {
            SMUtils.waitForElement( driver, rbReplaceReportOption );
            SMUtils.clickJS( driver, rbReplaceReportOption );
            WebElement saveReportPopup = SMUtils.getWebElementDirect( driver, btnSavereportPopupOptionRoot, primary_button );
            SMUtils.waitForElementToBeClickable( saveReportPopup, driver );
            SMUtils.clickJS( driver, saveReportPopup );
            Log.message( "Replaced Existing Report option - " + reportName );

        } catch ( ElementClickInterceptedException e ) {
            Log.message( "Error in clicking the save button." );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return reportName;
    }

    /**
     * get error message for exceed maximum length.
     *
     * @param
     * @return
     */
    public String getErrorMessageForExceedMaximumLength() {
        String errorMessageForExceedMaximumLength = null;
        try {
            errorMessageForExceedMaximumLength = errorMessage.getText();
        } catch ( Exception e ) {
            Log.message( "Error message is not Display" );
        }
        return errorMessageForExceedMaximumLength;
    }

    /**
     * Clicking the cancel report option.
     */
    public void clickCancelButtonFromPopup() {
        WebElement cancelButton = SMUtils.getWebElement( driver, cancelBtnSaveReportPopUpRoot, secondary_button );
        SMUtils.clickJS( driver, cancelButton );
        SMUtils.nap( 0.5 );// After cancel save report, it will take time to load
                           // page
    }

    /***
     * Checks and return the boolean for Select All Checkbox checked or not.
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isSelectALLChecked( String dropdownName ) throws InterruptedException {
        setDropDownMS( dropdownName );
        expandDropDownMS();
        WebElement chbxSelectAllRoot = SMUtils.getWebElementDirect( driver, shadowTree, chbxSelectALLParentRoot );
        Log.message( "Verified select all check box in " + dropdownName + " dropdown!" );
        return SMUtils.getWebElement( driver, chbxSelectAllRoot, chbxSelectALL ).isSelected();
    }

    /***
     * Checks and return the boolean for Select All Checkbox checked or not.
     *
     * @return
     * @throws InterruptedException
     */
    public boolean verifySelectALLCheckBox( String dropdownName ) throws InterruptedException {
        setDropDownMS( dropdownName );
        expandDropDownMS();
        WebElement chbxSelectAllRoot = SMUtils.getWebElementDirect( driver, shadowTree, chbxSelectALLParentRoot, valuesFromMSDropdown );
        Log.message( "Verified select all check box in " + dropdownName + " dropdown!" );
        return chbxSelectAllRoot.getText().trim().equalsIgnoreCase( Reports.SELECT_ALL );
    }

    /***
     * Set the multi-select dropdown
     *
     * @param ms_dropdown
     */
    public void setDropDownMS( String ms_dropdown ) {
        if ( ms_dropdown.equalsIgnoreCase( "groups" ) || ms_dropdown.toLowerCase().equalsIgnoreCase( "students" ) ) {
            for ( WebElement lblDropdown : lblGroupAndStudentsDropdown ) {
                if ( lblDropdown.getText().trim().contains( ms_dropdown ) ) {
                    shadowTree = lblDropdown.findElement( By.cssSelector( shadowRootGroupAndStudentsDropdown ) );
                }
            }
            // select group radio button
            checkGroupsOrStudentRB( ms_dropdown );
        } else if ( ms_dropdown.toLowerCase().equals( "assignments" ) ) {
            shadowTree = shadowRootAssignmentsDropdown;
        } else if ( ms_dropdown.toLowerCase().equals( "subject" ) )
            shadowTree = shadowRootSubjectsDropdown;
        // scroll the respective drop down into the view
        // SMUtils.scrollWebElementToView( driver, shadowTree );
    }

    /**
     * To verify radio buttons for Group and students
     *
     */
    public boolean isGroupAndStudentRadioButtonDisplayed() {
        SMUtils.waitForElement( driver, txtReportDescription );
        return rbGroupAndStudentDropdownParent.stream().anyMatch( element -> {
            WebElement rbGroupOrStudent = element.findElement( By.cssSelector( rbGroupAndStudentDropdown ) );
            return rbGroupOrStudent.isSelected();
        } );
    }

    /***
     * Checks the Students Radio button
     *
     * @param dropdownName
     */
    public void checkGroupsOrStudentRB( String dropdownName ) {
        if ( !isGroupsOrStudentRBChecked( dropdownName ) ) {
            for ( WebElement rbRoot : rbGroupAndStudentDropdownParent ) {
                WebElement lblDropdown = rbRoot.findElement( By.cssSelector( txtGroupAndStudentDropdown ) );
                if ( lblDropdown.getText().trim().contains( dropdownName ) ) {
                    WebElement rbGroupOrStudent = rbRoot.findElement( By.cssSelector( rbGroupAndStudentDropdown ) );
                    rbGroupOrStudent.click();
                    Log.message( "Clicked " + dropdownName + " radio button." );
                    break;
                }
            }
        }
    }

    /***
     * Checks whether students radio button is selected or not
     *
     * @param dropdownName
     * @return
     */
    public boolean isGroupsOrStudentRBChecked( String dropdownName ) {
        boolean isChecked = false;
        try {
            for ( WebElement rbRoot : rbGroupAndStudentDropdownParent ) {
                WebElement lblDropdown = rbRoot.findElement( By.cssSelector( txtGroupAndStudentDropdown ) );
                if ( lblDropdown.getText().trim().equals( dropdownName ) ) {
                    WebElement rbGroupOrStudent = rbRoot.findElement( By.cssSelector( rbGroupAndStudentDropdown ) );
                    isChecked = rbGroupOrStudent.isSelected();
                    Log.message( "Verified radio button for " + dropdownName );
                    break;
                }
            }
        } catch ( Exception e ) {
            Log.message( "Getting error while verifying student radio button!" );
        }
        return isChecked;
    }

    /***
     * Get values from Multi-Select drop down
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getValuesFromDropDownMS() throws Exception {
        List<String> msDropDownValues = new ArrayList<>();
        if ( Objects.isNull( shadowTree ) ) {
            throw new Exception( "Set DropdownMS value first" );
        }
        // expand ms drop down
        expandDropDownMS();
        // get values from ms drop down
        List<WebElement> msValuesList = SMUtils.getWebElements( driver, shadowTree, shadowRootSelectDropDownMS );
        for ( WebElement value : msValuesList ) {
            WebElement txtGroupStudents = SMUtils.getWebElement( driver, value, valuesFromMSDropdown );
            msDropDownValues.add( txtGroupStudents.getText() );
        }
        Log.message( "Got all options from MS Dropdown!" );
        return msDropDownValues;
    }

    /***
     * Get values from Multi-Select drop down
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getValuesFromStaticDropDownMS( String dropDownName ) throws Exception {
        List<String> msDropDownValues = new ArrayList<>();
        do {
            expandStaticDropDownMS( dropDownName );
            // Get values from ms drop down
            List<WebElement> msValuesList = selectStaticDropDown( dropDownName );
            for ( WebElement value : msValuesList ) {
                msDropDownValues.add( value.getText() );
            }
        } while ( msDropDownValues.isEmpty() );
        Log.message( "Got all options from " + dropDownName + " Dropdown!" );
        return msDropDownValues;
    }

    /**
     * Saving the report option.
     *
     * @param reportName
     * @return
     */
    public String saveReportOption( String reportName ) {
        SMUtils.nap( 4 ); // This nap is included to wait for the save report pop up. There will be a bit lag in MAC OS
        try {
            SMUtils.waitForElement( driver, rbNewSaveReportOption );
            SMUtils.clickJS( driver, rbNewSaveReportOption );
            txtFilterName.sendKeys( reportName );
            WebElement saveReportPopup = SMUtils.getWebElementDirect( driver, btnSavereportPopupOptionRoot, primary_button );
            SMUtils.nap( 3 ); // This nap is included to wait for the save button in save report pop up. There will be a bit lag in MAC OS
            SMUtils.clickJS( driver, saveReportPopup );
            Log.message( "Saved report option - " + reportName );
            // It Will take time to save report and load the page after saving
            SMUtils.nap( 2 );
        } catch ( ElementClickInterceptedException e ) {
            Log.message( "Error in clicking the save button." );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return reportName;
    }

    /**
     * Verifying the report option is saved.
     *
     * @param reportOptionName
     * @return
     */
    public boolean isReportOptionSaved( String reportOptionName ) {
        SMUtils.waitForElement( driver, expandSaveOptionDropdown );
        SMUtils.clickJS( driver, expandSaveOptionDropdown );
        //expandSaveOptionDropdown.click();
        String reportNameUI = null;
        boolean isReportPresent = false;
        for ( WebElement reportOption : listSavedOptions ) {
            reportNameUI = reportOption.getText().trim();
            if ( reportNameUI.toLowerCase().equals( reportOptionName.toLowerCase() ) ) {
                SMUtils.waitForElement( driver, reportOption );
                SMUtils.clickJS( driver, reportOption );
                isReportPresent = true;
                break;
            }
        }
        Log.message( "Verified saved Report option - " + reportOptionName );
        return isReportPresent;
    }

    /**
     * Loading the saved report options.
     *
     * @param reportName
     * @return
     */
    public String loadReportOption( String reportName ) {
        try {
            SMUtils.nap( 3 ); // Required for loading saved report options.
            SMUtils.clickJS( driver, expandSaveOptionDropdown );
            String reportNameUI = null;
            for ( WebElement reportOption : listSavedOptions ) {
                reportNameUI = reportOption.getText().trim();
                if ( reportNameUI.toLowerCase().equals( reportName.toLowerCase() ) ) {
                    SMUtils.clickJS( driver, reportOption );
                    Log.message( "Report option loaded! - " + reportName );
                    break;
                }
            }
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.fail( "Error in loading the report option!", driver );
        }
        return reportName;
    }

    /**
     * Clicking the save report option.
     */
    public void clickSaveReportOption() {
        SMUtils.nap( 3 );//It Will take time to load page for Report saving link
        WebElement clickSaveReport = SMUtils.getWebElement( driver, btnSaveReportRoot, secondary_button );
        try {
            SMUtils.clickJS( driver, clickSaveReport );
        } catch ( Exception e ) {
            clickSaveReport.click();
        }
        Log.message( "Clicked Save Report option button!" );
        SMUtils.nap( 3 );// After Saving report, It will take time to load
    }

    /**
     * Clicking the run report option.
     */
    public void clickRunReportOption() {
        WebElement clickRunReport = SMUtils.getWebElement( driver, btnRunReportRoot, primary_button );
        SMUtils.clickJS( driver, clickRunReport );
        Log.message( "Clicked Run Report!" );
        SMUtils.nap( 0.5 );// This will take time to load the report
    }

    /**
     * get run report button
     *
     * @return
     */
    public WebElement getRunReportOption() {
        Log.message( "Getting Run Report button!" );
        WebElement clickRunReport = SMUtils.getWebElement( driver, btnRunReportRoot, primary_button );
        return clickRunReport;
    }

    /**
     * Selecting the static dropdown
     *
     * @param dropDownName
     * @return
     */
    public List<WebElement> selectStaticDropDown( String dropDownName ) {
        List<WebElement> values = null;
        Log.message( "Getting Parent root for " + dropDownName + " Dropdown!" );
        if ( dropDownName.toLowerCase().equals( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN.toLowerCase() ) ) {
            values = listAdditionalGrouping;
        } else if ( dropDownName.toLowerCase().equals( Constants.Reports.DISPLAY_DROPDOWN.toLowerCase() ) ) {
            values = listdisplay;
        } else if ( dropDownName.toLowerCase().equals( Constants.Reports.SORT_DROPDOWN.toLowerCase() ) ) {
            values = listSort;
        } else if ( dropDownName.toLowerCase().equals( Constants.Reports.DATE_AT_RISK_DROPDOWN.toLowerCase() ) ) {
            values = listDateAtRisk;
        } else if ( dropDownName.toLowerCase().equals( Constants.Reports.SPR_LANGUAGE_DROPDOWN.toLowerCase() ) ) {
            values = listLanguage;
        }
        return values;
    }

    /***
     * Checks and return the Collapsed state as boolean for Multi-Select drop
     * down
     *
     * @return
     */
    public boolean isDropDownMSCollapsed() {
        Log.message( "Verifying MS dropdown collapsed or not!" );
        boolean isDropDownMSCollapsed = false;
        List<WebElement> dropDownMS_Expanded = SMUtils.getWebElements( driver, shadowTree, expandMsDropdown );
        isDropDownMSCollapsed = dropDownMS_Expanded.size() > 0;
        return isDropDownMSCollapsed;
    }

    /***
     * expand multi-select drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void expandDropDownMS() throws InterruptedException {
        SMUtils.nap( 0.5 );// It Is required because after saving the report,need
                           // time to load all dropdwon
        if ( isDropDownMSCollapsed() ) {
            WebElement btnDropDownExpand = SMUtils.getWebElement( driver, shadowTree, expandMsDropdown );
            try {
                SMUtils.clickJS( driver, btnDropDownExpand );
            } catch ( Exception e ) {
                btnDropDownExpand.click();
            }
        }
        Log.assertThat( isDropDownMSExpanded(), "DropDown Expanded-Successful", "DropDown Expanded-Not Successful" );
    }

    /***
     * expand multi-select drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void expandStaticDropDownMS( String dropDownName ) throws InterruptedException {
        if ( dropDownName.toLowerCase().equals( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN.toLowerCase() ) ) {
            SMUtils.clickJS( driver, expandAdditionalGroupingDropdown );
            Log.message( "Expanded additional grouping dropdown" );
        } else if ( dropDownName.toLowerCase().equals( Constants.Reports.SORT_DROPDOWN.toLowerCase() ) ) {
            SMUtils.clickJS( driver, expandSortDropdown );
            Log.message( "Expanded Sort dropdown" );
        } else if ( dropDownName.toLowerCase().equals( Constants.Reports.DISPLAY_DROPDOWN.toLowerCase() ) ) {
            SMUtils.clickJS( driver, expandDisplayDropdown );
            Log.message( "Expanded Display dropdown" );
        } else if ( dropDownName.toLowerCase().equals( Constants.Reports.DATE_AT_RISK_DROPDOWN.toLowerCase() ) ) {
            SMUtils.clickJS( driver, expandDateAtRiskDropdown );
            Log.message( "Expanded Date at Risk dropdown" );
        } else if ( dropDownName.toLowerCase().equals( Constants.Reports.SPR_LANGUAGE_DROPDOWN.toLowerCase() ) ) {
            SMUtils.clickJS( driver, expandlanguageDropdown );
            Log.message( "Expanded Language dropdown" );
        }
    }

    /***
     * Checks and return the Expanded state as boolean for Multi-Select drop
     * down
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isDropDownMSExpanded() throws InterruptedException {
        SMUtils.nap( 0.2 );//This will neeed to load filter after save report
        Log.message( "Verifying MS dropdown Expanded or not!" );
        boolean isDropDownMSExpanded = false;
        List<WebElement> dropDownMS_Collapsed = SMUtils.getWebElements( driver, shadowTree, collapseMsDropdown );
        isDropDownMSExpanded = dropDownMS_Collapsed.size() > 0;
        return isDropDownMSExpanded;
    }

    /***
     * Checks and return the boolean for Report Description
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isReportDescriptionPresent() throws InterruptedException {
        Log.message( "Verifying Report description!" );
        // There is Question mark available on text to avoid error in jenkins
        return txtReportDescription.getText().trim().replaceAll( "[^a-zA-Z0-9]", " " ).equals( Constants.Reports.CPR_DESCRIPTION.replaceAll( "[^a-zA-Z0-9]", " " ) );
    }

    /**
     * Validate student dropdown heading
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isMSDropdownHeadingPresent( String dropdownName ) throws InterruptedException {
        boolean isHeaderPresent = false;
        for ( WebElement lbldropdownHeader : lblMSDropdownHeader ) {
            if ( lbldropdownHeader.getText().trim().equals( dropdownName ) ) {
                isHeaderPresent = true;
                break;
            }
        }
        Log.message( "Verified " + dropdownName + " dropdown header" );
        return isHeaderPresent;
    }

    /**
     * Validate Saved Option dropdown heading
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isSavedOptionDropdownHeadingPresent() throws InterruptedException {
        Log.message( "Verifying saved option dropdown heading!" );
        return lblSavedOptionHeading.getText().trim().equals( Constants.Reports.SAVED_OPTIONS_DROPDOWN );
    }

    /**
     * Validate Filter heading in CPR Page
     *
     * @param title
     * @return
     * @throws InterruptedException
     */
    public boolean isFilterAndReportOptionsHeadingPresent( String title ) throws InterruptedException {
        Log.message( "Verifying " + title + " heading!" );
        for ( WebElement lblTitle : lblFilterAndReportOptionsHeading ) {
            if ( lblTitle.getText().trim().toLowerCase().equals( title.toLowerCase() ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Validate "Select Student or Group" heading in CPR Page
     *
     * @param title
     * @return
     * @throws InterruptedException
     */
    public boolean isRefineSearchAndGroupsOrStudentsHeadingPresent( String title ) throws InterruptedException {
        Log.message( "Verifying " + title + " heading!" );
        for ( WebElement lblTitle : lblRefineSearchAndGroupOrStudentHeading ) {
            if ( lblTitle.getText().trim().equals( title ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * get Save Report Option button
     *
     * @return
     */
    public WebElement getSaveReportOptionButton() {
        Log.message( "getting Save Report option button." );
        WebElement saveReportOptionButton = SMUtils.getWebElement( driver, btnSaveReportRoot, secondary_button );
        return saveReportOptionButton;
    }

    /**
     * Expand Filters
     *
     */
    public void expandFilterButton() {
        SMUtils.waitForElement( driver, btnExpandFilter );
        SMUtils.click( driver, btnExpandFilter );
        SMUtils.waitForElement( driver, btnCollapseFilter );
        Log.message( "Expanded Filter icon!" );
    }

    /**
     * Collapse Filters
     *
     */
    public void collapseFilterButton() {
        SMUtils.waitForElement( driver, btnCollapseFilter );
        SMUtils.click( driver, btnCollapseFilter );
        SMUtils.waitForElement( driver, btnExpandFilter );
        Log.message( "Collapsed Filter icon!" );
    }

    /**
     * Get Check boxes for Multi-Select Dropdown
     *
     * @param dropdownName
     * @return
     */
    public List<WebElement> getWebElementsForMSDropdownOptions( String dropdownName ) throws InterruptedException {
        Log.message( "getting elements for " + dropdownName + " dropdown" );
        setDropDownMS( dropdownName );
        expandDropDownMS();
        List<WebElement> chbxMSDropdownsRoot = SMUtils.getWebElements( driver, shadowTree, shadowRootSelectDropDownMS );
        List<WebElement> chbxMSDropdown = new ArrayList<>();
        // get values from ms drop down
        for ( WebElement chbxMSDropdownRoot : chbxMSDropdownsRoot ) {
            chbxMSDropdown.add( SMUtils.getWebElement( driver, chbxMSDropdownRoot, txtDropDownMSValue ) );
        }
        return chbxMSDropdown;
    }

    /**
     * Click select all checkbox for Multi-Select Dropdown
     *
     * @param dropdownName
     */
    public void clickSelectALLFromMSDropdown( String dropdownName ) throws InterruptedException {
        setDropDownMS( dropdownName );
        // Expand multi-select Dropdown Expanded
        if ( isDropDownMSCollapsed() ) {
            expandDropDownMS();
        }
        WebElement chbxSelectAllRoot = SMUtils.getWebElement( driver, shadowTree, chbxSelectALLParentRoot );
        WebElement chbxSelectAll = SMUtils.getWebElement( driver, chbxSelectAllRoot, txtDropDownMSValue );
        SMUtils.waitForElement( driver, chbxSelectAll );
        SMUtils.clickJS( driver, chbxSelectAll );

        Log.message( "Clicked select all check box for " + dropdownName + " Dropdown" );
    }

    /**
     * get text from inside the Multi-Select Dropdown
     *
     * @param dropdownName
     * @return
     */
    public String getTextFromInsideMSDropdown( String dropdownName ) throws InterruptedException {
        Log.message( "getting selected count for " + dropdownName + " Dropdown" );
        setDropDownMS( dropdownName );
        WebElement txtInsideDropdown = SMUtils.getWebElement( driver, shadowTree, txtInsideMsDropdown );
        return txtInsideDropdown.getText().trim();
    }

    /**
     * Validate Additional Grouping dropdown heading
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isStaticDropdownHeadingPresent( String dropdownName ) throws InterruptedException {
        Log.message( "Verifying " + dropdownName + " Dropdown header!" );
        for ( WebElement staticDropdownHeader : lblStaticDropdownHeading ) {
            if ( staticDropdownHeader.getText().trim().equals( dropdownName ) )
                return true;
        }
        return false;
    }

    /**
     * Validate Mask Student Display in CPR Page
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isMaskStudentDisplayAndRemovePageBreakFieldDisplayed( String field ) throws InterruptedException {
        Log.message( "Verifying -" + field );
        for ( WebElement lblfield : chbxMaskStudentDisplayAndRemovePageBreaksRoot ) {
            WebElement lblRemovePageBreaksAndMaskStudentDiplay = SMUtils.getWebElement( driver, lblfield, lblRemovePageBreakAndMaskStudentDiplayText );
            if ( lblRemovePageBreaksAndMaskStudentDiplay.getText().trim().equals( field ) ) {
                return true;
            }
        }
        return false;
    }

    /***
     * Get Selected values from Multi-Select drop down
     *
     * @return List<String>
     * @throws Exception
     */
    public String getSelectedValuesFromDropDownMS( String dropdownName ) throws Exception {
        String msDropDownValues = " ";
        setDropDownMS( dropdownName );
        // expand ms drop down
        SMUtils.nap( 1 );// It will required to dropdwon load
        expandDropDownMS();
        // get values from ms drop down
        List<WebElement> msValuesList = SMUtils.getWebElements( driver, shadowTree, shadowRootSelectDropDownMS );
        for ( WebElement value : msValuesList ) {
            WebElement chbxGroupStudents = SMUtils.getWebElement( driver, value, chbxDropdownMS );
            if ( chbxGroupStudents.isSelected() ) {
                WebElement txtGroupStudents = SMUtils.getWebElement( driver, value, valuesFromMSDropdown );
                if ( msDropDownValues.equals( " " ) )
                    msDropDownValues = txtGroupStudents.getText().trim();
                else
                    msDropDownValues = msDropDownValues + "\n" + txtGroupStudents.getText().trim();
            }
        }
        Log.message( "Got Selected Option from " + dropdownName + " Dropdown" );
        return msDropDownValues;
    }

    /**
     * get text from inside the Multi-Select Dropdown
     *
     * @param dropdownName
     * @return
     */
    public String getSelectedOptionFromMSDropdown( String dropdownName ) throws InterruptedException {
        setDropDownMS( dropdownName );
        WebElement txtInsideDropdown = SMUtils.getWebElement( driver, shadowTree, txtInsideMsDropdown );
        Log.message( "Got Selected Option from " + dropdownName + " Dropdown" );
        return txtInsideDropdown.getText().trim();
    }

    /**
     * get text from inside the Static Dropdown
     *
     * @param dropdownName
     * @return
     */
    public String getSelectedOptionFromStaticDropdown( String dropdownName ) throws InterruptedException {
        String selectedOption = null;
        if ( dropdownName.equals( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ) )
            selectedOption = lblSelectedOptionForAdditionalGrouping.getText().trim();
        else if ( dropdownName.equals( Constants.Reports.DISPLAY_DROPDOWN ) )
            selectedOption = lblSelectedOptionForDisplay.getText().trim();
        else if ( dropdownName.equals( Constants.Reports.SORT_DROPDOWN ) )
            selectedOption = lblSelectedOptionForSort.getText().trim();
        else if ( dropdownName.equals( Constants.Reports.DATEATRISK_DROPDOWN ) )
            selectedOption = lblSelectedOptionForDateAtRiskt.getText().trim();
        else if ( dropdownName.equals( Constants.Reports.SPR_LANGUAGE_DROPDOWN ) )
            selectedOption = lblSelectedOptionForLanguage.getText().trim();
        Log.message( "Got Selected Option from " + dropdownName + " Dropdown" );
        return selectedOption;
    }

    /**
     * Check or uncheck the Mask Student Display
     *
     */
    public void checkOrUncheckMaskStudentDisplay() throws InterruptedException {
        for ( WebElement parentRoot : chbxMaskStudentDisplayAndRemovePageBreaksRoot ) {
            WebElement lblMaskStudentDiplay = SMUtils.getWebElement( driver, parentRoot, lblRemovePageBreakAndMaskStudentDiplayText );
            if ( lblMaskStudentDiplay.getText().trim().equals( Constants.Reports.MASK_STUDENT_DISPLAY ) ) {
                WebElement chbxMaskStudentDiplay = SMUtils.getWebElement( driver, parentRoot, chbxRemovePageBreakAndMaskStudentDiplay );
                SMUtils.clickJS( driver, chbxMaskStudentDiplay );
            }
        }
        Log.message( "clicked Mask student display checkbox!" );
    }

    /**
     * Check or uncheck the Mask Student Display
     *
     */
    public void checkOrUncheckRemovePageBreak() throws InterruptedException {
        for ( WebElement parentRoot : chbxMaskStudentDisplayAndRemovePageBreaksRoot ) {
            WebElement lblRemovePageBreak = SMUtils.getWebElement( driver, parentRoot, lblRemovePageBreakAndMaskStudentDiplayText );
            if ( lblRemovePageBreak.getText().trim().equals( Constants.Reports.REMOVE_PAGE_BREAKS ) ) {
                WebElement chbxRemovePageBreak = SMUtils.getWebElement( driver, parentRoot, chbxRemovePageBreakAndMaskStudentDiplay );
                SMUtils.clickJS( driver, chbxRemovePageBreak );
            }
        }
        Log.message( "clicked Remove page breaks checkbox!" );
    }

    /**
     * Verify the Mask Student Display is checked or not
     *
     * @return
     */
    public boolean isMaskStudentDisplayChecked() throws InterruptedException {
        Log.message( "Verifying Mask Student Display check box is checked or not." );
        boolean isChecked = false;
        for ( WebElement parentRoot : chbxMaskStudentDisplayAndRemovePageBreaksRoot ) {
            WebElement lblMaskStudentDiplay = SMUtils.getWebElement( driver, parentRoot, lblRemovePageBreakAndMaskStudentDiplayText );
            if ( lblMaskStudentDiplay.getText().trim().equals( Constants.Reports.MASK_STUDENT_DISPLAY ) ) {
                WebElement chbxMaskStudentDiplay = SMUtils.getWebElement( driver, parentRoot, chbxRemovePageBreakAndMaskStudentDiplay );
                isChecked = chbxMaskStudentDiplay.isSelected();
                break;
            }
        }
        return isChecked;
    }

    /**
     * Verify the Remove Page Breaks is checked or not
     *
     * @return
     */
    public boolean isRemovePageBreakChecked() throws InterruptedException {
        Log.message( "Verifying Remove page break check box is checked or not." );
        boolean isChecked = false;
        for ( WebElement parentRoot : chbxMaskStudentDisplayAndRemovePageBreaksRoot ) {
            WebElement lblRemovePageBreak = SMUtils.getWebElement( driver, parentRoot, lblRemovePageBreakAndMaskStudentDiplayText );
            if ( lblRemovePageBreak.getText().trim().equals( Constants.Reports.REMOVE_PAGE_BREAKS ) ) {
                WebElement chbxRemovePageBreak = SMUtils.getWebElement( driver, parentRoot, chbxRemovePageBreakAndMaskStudentDiplay );
                isChecked = chbxRemovePageBreak.isSelected();
                break;
            }
        }
        return isChecked;
    }

    /**
     * To Select DropdownMs Options
     *
     * @param optionNames
     * @throws Exception
     */
    public void selectDropdownMSOptions( String dropdownName, List<String> optionNames ) throws Exception {
        setDropDownMS( dropdownName );
        SMUtils.nap( 1 ); // required for option selection
        List<WebElement> chbxForDropdownMS = getWebElementsForMSDropdownOptions( dropdownName );
        List<String> optionsFromDropdownMS = getValuesFromDropDownMS();
        for ( int optionCount = 0; optionCount < optionsFromDropdownMS.size(); optionCount++ ) {
            if ( optionNames.contains( optionsFromDropdownMS.get( optionCount ) ) ) {
                WebElement checkedElement = chbxForDropdownMS.get( optionCount );
                SMUtils.clickJS( driver, checkedElement );
            }
        }
        SMUtils.nap( 1 ); // Required for dorpdown option loading
        Log.message( "List of options are selected in " + dropdownName + " Dropdown" );
    }

    /**
     * To get the count of Groups/Students, Subject and Assignments
     *
     * @return
     * @throws Exception
     */
    public String getCountOfSelectedFilter( String dropdownName ) throws InterruptedException {
        String selectedFilter = null;
        if ( dropdownName.equals( Constants.Reports.GROUP_DROPDOWN ) || dropdownName.equals( Constants.Reports.STUDENTS_DROPDOWN ) ) {
            SMUtils.waitForElement( driver, countOfSelectedFilters.get( 0 ) );
            selectedFilter = countOfSelectedFilters.get( 0 ).getText().replace( ",", "" ).trim();
        } else if ( dropdownName.equals( Constants.Reports.SUBJECT_DROPDOWN ) ) {
            SMUtils.waitForElement( driver, countOfSelectedFilters.get( 1 ) );
            selectedFilter = countOfSelectedFilters.get( 1 ).getText().replace( ",", "" ).trim();
        } else if ( dropdownName.equals( Constants.Reports.ASSIGNMENTS_DROPDOWN ) ) {
            SMUtils.waitForElement( driver, countOfSelectedFilters.get( 2 ) );
            selectedFilter = countOfSelectedFilters.get( 2 ).getText().trim();
        }
        Log.message( "got the selected filter from " + dropdownName + "dropdown" );
        return selectedFilter;
    }

    /**
     * Verify the save report option .
     *
     * @return boolean
     */
    public boolean isPopupSaveButtonEnable() {
        Log.message( "Verifying Save Button is Enabled or not in save report option popup." );
        SMUtils.waitForElement( driver, btnSavereportPopupOptionRoot );
        WebElement saveReportPopup = SMUtils.getWebElementDirect( driver, btnSavereportPopupOptionRoot, primary_button );
        return saveReportPopup.isEnabled();
    }

    /**
     * to enter the filter name in the save report option Popup
     *
     */
    public void setReportFilterName( String filterName ) {
        SMUtils.waitForElement( driver, txtFilterName );
        txtFilterName.sendKeys( filterName );
        Log.message( "Filter name entered Successfully" );
    }

    /**
     * Get Save Report option Window pop up header Text
     *
     * @Return
     */
    public String getSaveReportPopUpTextHeader() {
        Log.message( "getting Save Report Popup header." );
        SMUtils.waitForElement( driver, saveReportPopUpTextHeader );
        return saveReportPopUpTextHeader.getText();
    }

    /**
     * Get Cancel Button on Save report window popup
     */
    public String cancelBtnOnSaveReportPopUp() {
        Log.message( "getting cancel button text from Save Report Popup." );
        SMUtils.waitForElement( driver, cancelBtnSaveReportPopUpRoot );
        //        WebElement cancelBtnSaveReportOnPopUp = SMUtils.getWebElement( driver, cancelBtnSaveReportPopUpRoot, secondary_button );
        return cancelBtnSaveReportPopUpRoot.getText().trim();
    }

    /**
     * Get Cancel Button on Save report window popup
     */
    public String saveBtnOnSaveReportPopUp() {
        Log.message( "getting Save button text from Save Report Popup." );
        SMUtils.waitForElement( driver, saveBtnOnSaveReportPopUpRoot );
        //WebElement saveBtnSaveReportOnPopUp = SMUtils.getWebElement( driver, saveBtnOnSaveReportPopUpRoot, primary_button );
        return saveBtnOnSaveReportPopUpRoot.getText().trim();
    }

    /**
     * To click cancel in Save Report popup
     */
    public void clickcancelButtoninSaveReportPopup() {
        WebElement cancelButton = SMUtils.getWebElement( driver, cancelBtnSaveReportPopUpRoot, secondary_button );
        SMUtils.waitForElement( driver, cancelButton );
        SMUtils.clickJS( driver, cancelButton );
        Log.message( "Cancel button in Save Report Pop-up is clicked successfully" );
    }

    /**
     * To get error message in Save Report Option
     *
     * @return
     */
    public String getSaveReportOptionErrorMsg() {
        Log.message( "Getting the error message displaying in the save report option popup!" );
        SMUtils.waitForElement( driver, errorMsgSaveReport );
        return errorMsgSaveReport.getText();
    }

    /**
     * Get Save Report option Window pop up new header Text
     *
     * @Param header
     * @return
     */
    public boolean saveReportOptionPopupHeader( String header ) {
        boolean isHeaderPresent = false;
        for ( WebElement txtheader : saveReportPopupDropdownHeaders ) {
            if ( txtheader.getText().equals( header ) ) {
                isHeaderPresent = true;
                break;
            }
        }
        Log.message( "Verified save report option popup header - " + header );
        return isHeaderPresent;
    }

    /**
     * Enter the filter name in the Save Report option popup
     *
     * @return
     */
    public void setFilterName( String reportName ) {
        SMUtils.waitForElement( driver, txtFilterName );
        txtFilterName.sendKeys( reportName );
        Log.message( "Entered Filter name in the save report option popup." );
    }

    /***
     * Get values from Multi-Select drop down
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getValuesFromStaticDropDownMSWithLowerCase( String dropDownName ) throws Exception {

        List<String> msDropDownValues = new ArrayList<>();
        do {
            expandStaticDropDownMS( dropDownName );
            // get values from ms drop down
            List<WebElement> msValuesList = selectStaticDropDown( dropDownName );
            for ( WebElement value : msValuesList ) {
                msDropDownValues.add( value.getText().toLowerCase().trim() );
            }
            expandStaticDropDownMS( dropDownName );
        } while ( msDropDownValues.isEmpty() );
        Log.message( "Got all options from " + dropDownName + " Dropdown!" );
        return msDropDownValues;
    }

    /**
     * Validate Filter heading in CPR Page
     *
     * @return
     * @throws InterruptedException
     */
    public String getSavedOptionSelectedValue() throws InterruptedException {
        return savedOptionSelectedValue.getText();
    }

    /**
     * To click value from Existing Report drop-down in Save Report Option
     *
     * @return
     * @return
     * @throws Exception
     */
    public void clickExistingReportValue( String valueToBeClicked ) throws Exception {
        SMUtils.waitForElement( driver, existingReportDropdown );
        SMUtils.clickJS( driver, existingReportDropdown );

        List<WebElement> listOfValues = existingReportValues;
        for ( WebElement value : listOfValues ) {
            if ( value.equals( valueToBeClicked ) )
                value.click();
        }
        WebElement saveReportPopup = SMUtils.getWebElementDirect( driver, btnSavereportPopupOptionRoot, primary_button );
        SMUtils.clickJS( driver, saveReportPopup );
        Log.message( valueToBeClicked + " is clicked from Existing Report dropdown" );
    }

    /**
     * To click New radio button in Save Report Option
     *
     * @throws Exception
     */
    public void clickReplaceExistingReportRadioBtn() throws Exception {
        SMUtils.waitForElement( driver, rbLoadReportOption );
        SMUtils.clickJS( driver, rbLoadReportOption );
        Log.message( "Replace Existing Report Radio button is selected in the Save Report Pop-up" );
    }

    /**
     * To select the value from static dropdown
     *
     * @param dropdownName
     * @param value
     * @return
     * @throws Exception
     */
    public boolean selectValueFromStaticDropdown( String dropdownName, String value ) throws Exception {
        List<String> valuesFromStaticDropDownMS = getValuesFromStaticDropDownMS( dropdownName );
        List<String> valueList = Arrays.asList( valuesFromStaticDropDownMS.toString().replace( '[', '\u0000' ).replace( ']', '\u0000' ).trim().split( ", " ) );

        Map<String, Integer> mapValuse = new LinkedHashMap<>();
        for ( int i = 0; i < valueList.size(); i++ ) {
            mapValuse.put( valueList.get( i ).toLowerCase(), i );
        }

        if ( dropdownName.equals( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ) ) {
            int txtDropdown = mapValuse.get( value.toLowerCase() );
            SMUtils.clickJS( driver, additionalGroupingDropdownValues.get( txtDropdown ) );
            Log.message( "The option " + value + " is selected in Additional Grouping Drop down" );
            return true;
        } else if ( dropdownName.equals( Constants.Reports.DISPLAY_DROPDOWN ) ) {
            int txtDropdown = mapValuse.get( value.toLowerCase() );
            SMUtils.clickJS( driver, displayDropdownValues.get( txtDropdown ) );
            Log.message( "The option " + value + " is selected in Display Drop down" );
            return true;
        } else if ( dropdownName.equals( Constants.Reports.SORT_DROPDOWN ) ) {
            int txtDropdown = mapValuse.get( value.toLowerCase() );
            SMUtils.clickJS( driver, sortDropdownValues.get( txtDropdown ) );
            Log.message( "The option " + value + " is selected in Sort Drop down" );
            return true;
        } else if ( dropdownName.equals( Constants.Reports.DATE_AT_RISK_DROPDOWN ) ) {
            int txtDropdown = mapValuse.get( value.toLowerCase() );
            SMUtils.clickJS( driver, dateAtRiskDropdownValues.get( txtDropdown ) );
            Log.message( "The option " + value + " is selected in Date At Risk Drop down" );
            return true;
        } else if ( dropdownName.equals( Constants.Reports.SPR_LANGUAGE_DROPDOWN ) ) {
            int txtDropdown = mapValuse.get( value.toLowerCase() );
            SMUtils.clickJS( driver, languagekDropdownValues.get( txtDropdown ) );
            Log.message( "The option " + value + " is selected in Language Drop down" );
            return true;
        }
        Log.message( "Given dropdown or value is not present" );
        return false;
    }

    /**
     * Get Save Report option Window pop up new header Text
     */
    public String getSaveReportOptionFieldHeaders( String header ) {
        for ( WebElement eachHeader : saveReportPopupDropdownHeaders ) {
            if ( eachHeader.getText().trim().equals( header ) ) {
                Log.message( "Getting Save Report Option Field Headers" );
                return eachHeader.getText().trim();
            }
        }
        Log.message( "Unable to get Save Report Option Field Headers" );
        return null;
    }

    /**
     * To check name text box is enabled or not in Save Report Option
     *
     * @return
     * @return
     */
    public boolean isSaveReportOptionNewRadioSelected() {
        if ( rbNewSaveReportOption.isSelected() ) {
            return true;
        }
        return false;
    }

    /**
     * To check name text box is enabled or not in Save Report Option
     *
     * @return
     * @return
     */
    public boolean isReplaceExistingReportDropdownPresent() {
        if ( expandFilterOption.isDisplayed() ) {
            return true;
        }
        return false;
    }

    /**
     * To check Sort drop down is present or not
     *
     * @return - boolean true - if sort drop down is present false - if sort
     *         drop down is not present
     */
    public boolean isSortDropdownPresent() {
        return ( SMUtils.isElementPresent( msSortDropdown ) ? true : false );
    }

    /**
     * To check Display drop down is present or not
     *
     * @return - boolean true - if display drop down is present false - if
     *         display drop down is not present
     */
    public boolean isDisplayDropdownPresent() {
        return ( SMUtils.isElementPresent( msDisplayDropdown ) ? true : false );
    }

    /**
     * To check Additional Grouping drop down is present or not
     *
     * @return - boolean true - if additional grouping drop down is present
     *         false - if additional grouping drop down is not present
     */
    public boolean isAdditionalGroupingDropdownPresent() {
        return ( SMUtils.isElementPresent( msAdditionalGroupingDropdown ) ? true : false );
    }

    /**
     * To check Additional Grouping drop down is present or not
     *
     * @return - boolean true - if additional grouping drop down is present
     *         false - if additional grouping drop down is not present
     */
    public boolean isDateAtRiskDropdownPresent() {
        SMUtils.waitForElement( driver, msDateAtRiskDropdown );
        return ( SMUtils.isElementPresent( msDateAtRiskDropdown ) ? true : false );
    }

    /***
     * To Click the Save button in the Save Report pop up
     *
     * @return - void
     */
    public void clickSaveButtoninSavedOptionPopup() {
        WebElement saveReportPopup = SMUtils.getWebElementDirect( driver, btnSavereportPopupOptionRoot, primary_button );
        SMUtils.waitForElementToBeClickable( saveReportPopup, driver );
        SMUtils.clickJS( driver, saveReportPopup );
        Log.message( "Save Button in Save Option Pop-up is clicked" );
    }

    /**
     * To click New radio button in Save Report Option
     *
     * @throws Exception
     */
    public void clcikReplaceExistingReportRadioBtn() throws Exception {
        SMUtils.waitForElement( driver, rbLoadReportOption );
        SMUtils.clickJS( driver, rbLoadReportOption );
        Log.message( "Clicked Replace Existing radio button" );
    }

    /**
     * Zero state text for groups
     *
     * @return
     */
    public String getZeroStateTextGroups() {
        SMUtils.waitForElement( driver, zeroStateRoot );
        WebElement element = SMUtils.getWebElement( driver, zeroStateRoot, zeroStateChild );
        return element.getText().trim();
    }

    /**
     * Zero state text for Assignments
     *
     * @return
     */
    public String getZeroStateTextAssignments() {
        SMUtils.waitForElement( driver, shadowRootAssignmentsDropdown );
        WebElement element = SMUtils.getWebElement( driver, shadowRootAssignmentsDropdown, assignmentszeroState );
        return element.getText().trim();
    }

    /**
     * It will return status of Run report button as enabled or disabled
     *
     * @return
     */
    public Boolean isRunReportButtonEnabled() {
        SMUtils.waitForElement( driver, btnRunReportRoot );
        WebElement actaulRunReport = SMUtils.getWebElement( driver, btnRunReportRoot, primary_button );

        return actaulRunReport.isEnabled();
    }

    /**
     * Verify zero state message for reports
     *
     * @author vikas.pandey
     * @return
     */
    public Boolean isZeroStateMessageDisplayed() {
        SMUtils.waitForElement( driver, headerTextZeroState );
        Log.message( "Validate zero state message if teacher does not student" );
        return ( headerTextZeroState.getText().trim().equalsIgnoreCase( Constants.Reports.ZERO_STATE_MESSAGE_HEADER ) && zeroStateDescription.getText().trim().equalsIgnoreCase( Constants.Reports.ZERO_STATE_MESSAGE_DESCRIPTION ) );
    }

    /**
     * To verify whether name text box is present or not in Save Report pop-up
     *
     * @Karthigeyan bala
     * @return
     */
    public Boolean isNameTextBoxDisplayed() {
        try {
            SMUtils.waitForElement( driver, txtFilterName );
            SMUtils.isElementPresent( txtFilterName );
            Log.message( "Name text box is displayed in Save Report pop-up" );
            return true;
        } catch ( Exception e ) {
            Log.message( "Name text box is not displayed in Save Report pop-up" );
            return false;
        }
    }

    /*
     * To get values from collapsed filter
     *
     * @return
     */
    public String getvaluesFromCollapsedFilter() {
        SMUtils.waitForElement( driver, collapsedFiltertext );
        return collapsedFiltertext.getText().trim();

    }

    /**
     * To click help icon in save report popup
     *
     */
    public void clickHelpInSaveReportOptionPopup() {
        SMUtils.waitForElement( driver, popupHelpIconRoot );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, popupHelpIconRoot, popupHelpIconChild ) );
    }

    public String getHelpContentHeader() {
        SMUtils.waitForElement( driver, headerForHelpContent );
        return SMUtils.getTextOfWebElement( headerForHelpContent, driver );
    }

    /***
     * To verify the group or student drop down is displayed
     *
     * @author balaji.chandra
     */
    public boolean verifyGroupsorStudentsDropdownPresent( String dropdown ) {
        boolean isDisplayed = false;
        try {
            for ( WebElement rbRoot : rbGroupAndStudentDropdownParent ) {
                WebElement lblDropdown = rbRoot.findElement( By.cssSelector( txtGroupAndStudentDropdown ) );
                if ( lblDropdown.getText().trim().equals( dropdown ) ) {
                    WebElement rbGroupOrStudent = rbRoot.findElement( By.cssSelector( rbGroupAndStudentDropDownDisplay ) );
                    isDisplayed = rbGroupOrStudent.isDisplayed();
                    Log.message( "Verified radio button for " + dropdown );
                    break;
                }
            }
        } catch ( Exception e ) {
            Log.message( "Getting error while verifying student radio button!" );
        }
        return isDisplayed;
    }

    /***
     * This method verify the presence of subject drop down
     *
     * @author balaji.chandra
     * @return
     */

    public boolean verifySubjectDropdownPresent() {
        SMUtils.waitForElement( driver, lblSubjectDropdown );
        if ( lblSubjectDropdown.isDisplayed() ) {
            Log.message( "Subject Drop down is displayed" );
            return true;
        } else {
            Log.message( "Subject Drop down is not displayed" );
            return false;
        }
    }

    /***
     * This method retrieves Subject drop down values
     *
     * @author balaji.chandra
     * @return
     */
    public List<String> getSubjectDropDownValues() {
        SMUtils.waitForElement( driver, lblSubjectDropdown );
        List<WebElement> allElements = SMUtils.getWebElements( driver, lblSubjectDropdown, chbxSelectALLParentRoot );
        List<String> elements = new ArrayList<>();
        for ( WebElement eachElement : allElements ) {
            elements.add( SMUtils.getWebElement( driver, eachElement, subjectDropdownValues ).getText().trim() );
        }
        return elements;
    }

    /***
     * To retrieve the Save report option list - already saved
     *
     * @author balaji.chandra
     * @return
     */
    public List<String> getSavedReportOptionList() {
        List<String> options = new ArrayList<>();
        try {
            SMUtils.nap( 3 ); // Required for loading saved report options.
            SMUtils.clickJS( driver, expandSaveOptionDropdown );
            String reportNameUI = null;
            for ( WebElement reportOption : listSavedOptions ) {
                reportNameUI = reportOption.getText().trim();
                options.add( reportNameUI );
            }
            SMUtils.clickJS( driver, collapseSaveOptionDropdown );

        } catch ( Exception e ) {
            e.printStackTrace();
            Log.fail( "Error in loading the report option!", driver );
        }
        return options;
    }

    /***
     * To Check the replace existing option is selected in the pop up
     *
     * @author balaji.chandra
     */
    public void checkReplaceExistingReportOption() {
        SMUtils.waitForElement( driver, rbReplaceReportOption );
        SMUtils.clickJS( driver, rbReplaceReportOption );
        if ( rbReplaceReportOption.isSelected() )
            Log.message( "Replace Existing Report Option is selected" );
        else
            Log.message( "Replace Exisiting Report Option is not selected" );
    }

    /***
     * To verify the New option is selected in the pop up
     *
     * @author balaji.chandra
     * @return
     */
    public boolean verifyNewOptionisSelected() {
        if ( rbNewSaveReportOption.isSelected() ) {
            Log.message( "New Save Report option is Selected" );
            return true;
        } else {
            Log.message( "New Save Report option is not Selected" );
            return false;
        }
    }

    /***
     * To verify the Replace existing report option is selected in the pop up
     *
     * @author balaji.chandra
     * @return
     */

    public boolean verifyReplaceExisitngReportOptionisSelected() {
        if ( rbReplaceReportOption.isSelected() ) {
            Log.message( "Replace Exisitng Report option is Selected" );
            return true;
        } else {
            Log.message( "Replace Exisitng Save Report option is not Selected" );
            return false;
        }
    }

    /***
     * Verify the Filter is expanded
     *
     * @author balaji.chandra return -> boolean
     */

    public boolean verifyFilterButtonisExpanded() {
        SMUtils.waitForElement( driver, btnFilter );
        String attribute = btnFilter.getAttribute( "aria-expanded" ).trim();
        if ( attribute.equalsIgnoreCase( "true" ) ) {
            Log.message( "The filter is expanded" );
            return true;
        } else {
            Log.message( "The filter is collapsed" );
            return false;
        }
    }

    /***
     * This methods helps the user to save report with negative values and get
     * error message
     */
    public String saveReportOptionNegative( String reportName ) {
        SMUtils.nap( 4 ); // This nap is included to wait for the save report pop up. There will be a bit lag in MAC OS
        try {
            SMUtils.clickJS( driver, rbNewSaveReportOption );
            txtFilterName.sendKeys( reportName, Keys.TAB );
            // It Will take time to save report and load the page after saving
            SMUtils.nap( 2 );
        } catch ( ElementClickInterceptedException e ) {
            Log.message( "Error in clicking the save button." );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return reportName;
    }

}