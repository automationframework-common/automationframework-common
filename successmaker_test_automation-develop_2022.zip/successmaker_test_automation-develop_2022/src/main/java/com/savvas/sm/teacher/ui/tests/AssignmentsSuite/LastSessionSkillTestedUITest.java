package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperUsage;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * This class used to test the last session skill tested UI verification.
 * 
 * @author ajith.mohan
 *
 */
public class LastSessionSkillTestedUITest extends BaseTest {

	private String smUrl;
	private String browser;
	private String username = null;
	private String password = DataSetupConstants.DEFAULT_PASSWORD;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String teacherDetails;
	private String studentDetailsOne;
	private String studentDetailsTwo;
	private String studentLastName;
	private String studentMiddleName;
	private String studentFirstName;
	private String schoolID;
	private String teacherID;
	private HashMap<String, String> groupDetails = new HashMap<>();
	private static List<String> studentRumbaIds = new ArrayList<>();
	private static HashMap<String, String> mathAssignmentDetails = new HashMap<>();
	AssignmentAPI assign = new AssignmentAPI();
	private String token = null;
	String studentUserName1;
	String studentUserName2;

	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		
		
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		schoolID = RBSDataSetup.organizationIDs.get(school);
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		
		 
		studentDetailsOne = RBSDataSetup.getMyStudent(school, username);
		studentDetailsTwo = RBSDataSetup.getMyStudent(school, username);
		
	    studentUserName1 = SMUtils.getKeyValueFromResponse( studentDetailsOne, "userName" );
	    studentUserName2 = SMUtils.getKeyValueFromResponse( studentDetailsTwo, "userName" );

		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));

		// token creation
		token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(teacherDetails, "userName"),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		// Group
		String groupName = "GroupNo_" + System.nanoTime();
		groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		groupDetails.put(GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetails.put(GroupConstants.GROUP_NAME, groupName);
		String groupId = SMUtils.getKeyValueFromResponse(
				new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds).get(Constants.REPORT_BODY),
				"data,groupId");
		
		// Assigning Math assignment
        mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, schoolID );
        mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
        mathAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        HashMap<String, String> mathRssignmentResponse = assign.assignMultipleAssignments( smUrl, mathAssignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );
        Log.message( mathRssignmentResponse.toString() );
        
        executeSimulator( studentUserName1, Constants.MATH, Constants.MATH );

	}

	@Test(priority = 1, groups = { "SMK-41438", "Assignments, Last_session_skill_tested" })
	public void tcSkillTested001(ITestContext context) throws Exception {
		
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		

		Log.testCaseInfo("Validate the Assignment skill tested UI" + "<small><b><i>[" + browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			// navigate to CourseListing Page
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			// Math Course and assigning to student
			coursePage.clickMathCourse();
			coursePage.mathCourseName();
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			coursePage.clickBackIcon();
			driver.quit();

			// Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);


			String studentUsername = SMUtils.getKeyValueFromResponse(studentDetailsOne, "userName");
			
			LoginWrapper.loginToSuccessMakerAsStudent(driver, smUrl, UserType.BASIC, null, studentUsername, password);
			StudentDashboardPage studentDashboardPage = new StudentDashboardPage(driver);

			studentDashboardPage.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),
					Constants.MATH, "80", "5", "5");
		
			driver.quit();
			
//			new SqlHelperUsage().shareUsageData(DataSetupConstants.BVT_SCHOOL);

			// Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			studentLastName = SMUtils.getKeyValueFromResponse(studentDetailsOne, "lastName");
			studentMiddleName = SMUtils.getKeyValueFromResponse(studentDetailsOne, "middleName");
			studentFirstName = SMUtils.getKeyValueFromResponse(studentDetailsOne, "firstName");

			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName("Math");

			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);

			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),
					"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");

			assignmentDetailsPage.collapseSkillTested();

			SMUtils.logDescriptionTC("Validate the functionality of collapse (-) icon screen");
			Log.assertThat(!assignmentDetailsPage.isSkillTestedExpanded(),
					"Skill tested Collapsed for the student successfully!", "Issue in collapsed skill tested dropdown");

			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);

			SMUtils.logDescriptionTC("Validate the Skills Tested Label in the Expanded Skills Tested");
			Log.assertThat(assignmentDetailsPage.getSkillTestedHeader().equals(Constants.SKILL_TESTED_HEADER),
					"Skill tested header displayed for the student successfully!",
					"Skill tested header not displayed!");

			assignmentDetailsPage.clickLastSession();

			SMUtils.logDescriptionTC(
					"Validate the date drop down is displayed in the Skills Tested and default text is displayed");
			SMUtils.logDescriptionTC(
					"Validate the options in the date drop down in the Skills Tested expanded view for Last Session selection");

			SMUtils.logDescriptionTC(
					"Validate the options in the date drop down in the Skills Tested expanded view options in the date drop down");

			Log.assertThat(!assignmentDetailsPage.getLastSessionDropdownValues().toString().isEmpty(),
					"Last session drop down expanded successfully!", "Issue in expanding last session dropdown");

			SMUtils.logDescriptionTC("Verify the default session of skills tested should be displayed");
			assignmentDetailsPage.clickSelectAll();

			assignmentDetailsPage.clickApplyFilter();

			Log.assertThat(!assignmentDetailsPage.getSkillsTestedValues().toString().isEmpty(),
					"Skill tested values displayed successfully!", "Skill tested values are not displayed properly.");

			assignmentDetailsPage.collapseSkillTested();

			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);

			Log.assertThat(!assignmentDetailsPage.getSkillsListFromMap(assignmentDetailsPage.getSkillsTestedValues())
					.toString().isEmpty(), "Skill list displayed successfully", "Skills list not displayed!");

			SMUtils.logDescriptionTC("Verify the details displayed about the skills tested and LO link displayed.");
			Log.assertThat(
					assignmentDetailsPage.isSkillNameLinkDisplayed(assignmentDetailsPage
							.getSkillsListFromMap(assignmentDetailsPage.getSkillsTestedValues()).get(0)),
					"Skill link displayed successfully!", "Skill link not displayed!");

			assignmentDetailsPage.collapseSkillTested();

			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);

			assignmentDetailsPage.clickLastSession();

			assignmentDetailsPage
					.clickCheckBoxinLastSessionDropdown(assignmentDetailsPage.getExpectedDatesinLastSession());

			SMUtils.logDescriptionTC("Validate the functionality of Apply filter in the Skills Tested expanded view.");

			assignmentDetailsPage.clickApplyFilter();

			Log.assertThat(!assignmentDetailsPage.getSkillsTestedValues().isEmpty(),
					"Skill Tested is present when other dates along with  Last Session date is selected!",
					"Skill Tested is Not present when other dates along with  Last Session date is  selected!");

			SMUtils.logDescriptionTC(
					"Validate the options in the date drop down in the Skills Tested expanded view Last session is displayed");
			SMUtils.logDescriptionTC("Verify the skills tested is displaying as per the session(s) selected");

			assignmentDetailsPage.clickLastSession();

			assignmentDetailsPage.clickCheckBoxinLastSessionDropdown(
					assignmentDetailsPage.getExpectedDatesinLastSession().subList(0, 1));

			assignmentDetailsPage.clickApplyFilter();

			Log.assertThat(!assignmentDetailsPage.getSkillsTestedValues().isEmpty(),
					"Skill Tested is present when Last Session is selected!",
					"Skill Tested is Not present when Session is  selected!");

			assignmentDetailsPage.clickLastSession();

			SMUtils.logDescriptionTC(
					"Validate the options in the date drop down in the Skills Tested expanded view with multiple date selection.");
			SMUtils.logDescriptionTC(
					"Verify the skills tested is displaying as per the session(s) selected with multiple dates.");

			assignmentDetailsPage.clickCheckBoxinLastSessionDropdown(
					assignmentDetailsPage.getExpectedDatesinLastSession().subList(7, 14));

			assignmentDetailsPage.clickApplyFilter();

			Log.assertThat(!assignmentDetailsPage.getSkillsTestedValues().isEmpty(),
					"Skill Tested is present when all dates without Last Session is selected!",
					"Skill Tested is Not present when all dates without Session is  selected!");

			assignmentDetailsPage.clickLastSession();

			SMUtils.logDescriptionTC(
					"Validate the options in the date drop down in the Skills Tested expanded view Uncheck all options");
			SMUtils.logDescriptionTC(
					"Validate the options in the date drop down in the Skills Tested expanded view with No date selection");

			assignmentDetailsPage
					.clickCheckBoxinLastSessionDropdown(assignmentDetailsPage.getExpectedDatesinLastSession());

			assignmentDetailsPage
					.clickCheckBoxinLastSessionDropdown(assignmentDetailsPage.getExpectedDatesinLastSession());

			Log.testCaseResult();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(priority = 1, groups = { "SMK-41438", "Assignments, Last_session_skill_tested" })
	public void tcSkillTested002(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Verify the Zero state is displayed by default if there is no session for the student"
				+ "<small><b><i>[" + browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			studentLastName = SMUtils.getKeyValueFromResponse(studentDetailsTwo, "lastName");
			studentMiddleName = SMUtils.getKeyValueFromResponse(studentDetailsTwo, "middleName");
			studentFirstName = SMUtils.getKeyValueFromResponse(studentDetailsTwo, "firstName");

			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage
					.viewAssignmentDetailsByAssignmentName(Constants.MATH);

			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);

			Log.assertThat(assignmentDetailsPage.isZeroStatePresentforSkillTested(),
					"Zero state displayed successfully!", "Zero state message not displayed!");

			assignmentDetailsPage.collapseSkillTested();
			Log.testCaseResult();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}
	 public void executeSimulator( String studentUsername, String assignmentName, String assignmentType ) throws Exception {
	        WebDriver studentDriver = WebDriverFactory.get( browser );
	        LoginPage smStudentLoginPage = new LoginPage( studentDriver, smUrl ).get();
	        StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
	        try {
	            if ( assignmentType.equals( Constants.MATH ) ) {
	                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
	                    Log.message( "Math Course Execution" );
	                    try {
	                        studentDashboardPage.executeMathCourse( username, assignmentName, "100", "1", "30" );
	                    } catch ( IOException e ) {
	                        Log.message( "Error occurred while running the simulator for Math" );
	                    }

	                } );

	            } else {
	                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
	                    Log.message( "Reading Course Execution" );
	                    try {
	                        studentDashboardPage.executeReadingCourse( username, assignmentName, "100", "2", "15" );
	                    } catch ( IOException e ) {
	                        Log.message( "Error occurred while running the simulator Reading" );
	                    }

	                } );

	            }
	        } catch ( Exception e ) {

	            Log.message( "Error occurred while running the simulator" );
	        }
	        studentDriver.quit();
	    }

}
