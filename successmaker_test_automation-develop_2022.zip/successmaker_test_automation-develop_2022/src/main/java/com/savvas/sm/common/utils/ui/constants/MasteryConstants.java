package com.savvas.sm.common.utils.ui.constants;

public interface MasteryConstants {
    interface UserRole {
        public static String TEACHER = "teacher";
        public static String ADMIN_SINGLE = "admin_single";
        public static String ADMIN_MULTI = "admin_multi";
    }

    interface Labels {
        public static String MASTERY_HEADING = "Mastery";
        public static String STUDENT_MASTERY_HEADING = "Student Details - Mastery";
        public static String GROUP_MASTERY_HEADING = "Group Details - Mastery";
        public static String GROUP_MASTERY_ASSESSMENT = "Mastery Assessment Details";
    }

    interface Graphql {
        public static String BASE_URL = "http://successmaker-mastery-bff-service-nightly.eba-9hf3rzvb.us-east-1.elasticbeanstalk.com";
        public static String ENDPOINT = "/graphql";

        interface Get3SixtyId {
            public static String DESCRIPTION = "description";
            public static String DISPLAYNAME = "displayName";
            public static String ADDRESS1 = "address1";
            public static String ADDRESS2 = "address2";
            public static String CITY = "city";
            public static String STATE = "state";
            public static String ZIPCODE = "zipcode";
            public static String COUNTRY = "country";
            public static String NAME = "name";
            public static String ORGANIZATIONID = "organizationId";
            public static String STATUS = "status";
            public static String ORGANIZATIONTYPE = "organizationType";
            public static String SOURCESYSTEM = "sourceSystem";
            public static String LASTUPDATEDDATE = "lastUpdatedDate";
            public static String CREATEDDATE = "createdDate";
            public static String LASTUPDATEDBY = "lastUpdatedBy";
            public static String CREATEDBY = "createdBy";
            public static String DISPLAYGROUP = "displayGroup";
            public static String ATTRIBUTES = "attributes";
            public static String THREESIXTYID = "threeSixtyId";

            //public static String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getThreeSixtyId(organizationId: \\\"8a7200f77de565ac017e2484aff10660\\\") {\\n    threeSixtyId\\n    zipcode\\n  }\\n}\\n\"}";
            public static String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getThreeSixtyId(organizationId: %s) %s\\n}\\n\"}";
            public static String EXPECTED_3SIXTYID_VALUE = "https://nightly-next-auto.smdemo.info";
            public static String UNAUTHORIZED_MESSAGE = "UNAUTHORIZED";
        }

        interface skillsandStandards {
            public static String STANDARDS_NAME = "standardsName";
            public static String STANDARDS_ID = "standardsId";
            public static String BASE_URL = "https://successmaker-mastery-bff-dev.smdemo.info";
            public static String ENDPOINT = "/graphql";
            public static String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  skillsAndStandards(\\n    orgId: %s\\n    userId: %s\\n    subjectId: %s\\n  ) %s\\n}\\n\"}";
            public static String UNAUTHORIZED_MESSAGE = "UNAUTHORIZED";
            public static String ACCESS_DENIED = "Access denied! You don't have permission for this action!";
            public static String SYNTAX_ERROR = "Syntax Error";
            public static String INVALID_SUBJECT_ID_ERROR = "Invalid value passed for subjectId";
            String SKILLORSTANDARD_TITLE = "Skill or Standard";
            String MASTERYSTATUS_TITLE = "Mastery Status";
            String SKILLSCOMPLETED_TITLE = "# of Skills Completed/Judged";
            String NOOFATTEMPTS_TITLE = "# of Attempts";
        }
    }

}
