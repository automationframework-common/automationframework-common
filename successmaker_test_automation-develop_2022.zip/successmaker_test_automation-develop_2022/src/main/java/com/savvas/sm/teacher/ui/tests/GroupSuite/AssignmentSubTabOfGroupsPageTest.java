
package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EditAssignmentSettingsPopUp;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class AssignmentSubTabOfGroupsPageTest extends BaseTest {

    private String smUrl;
    private String browser;
    List<String> expectedCourseTypesInDropdown = Arrays.asList( "Focus Courses", "Default Courses", "Custom Courses", "All Courses" );
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String teacherDetails;

    public static int counter = 1;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
    }

    @Test ( description = "Verify the teacher can able to view Math assignment Settings Popup", priority = 1 )
    public void tcSMGroupsAssignmentsSettingsPopup001() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data
        Log.testCaseInfo( "tcSMAssignmentListing001: Verify the list of assignments columns avaialble in the assignment details <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupPage.obtainingMathSettings( tHomePage );
            SMUtils.waitForElement( driver, groupPage.editAssignmentSettingtitle );
            EditAssignmentSettingsPopUp editAssignmentSettingsPopUp = new EditAssignmentSettingsPopUp( driver ).get();
            Log.assertThat( SMUtils.isElementPresent( editAssignmentSettingsPopUp.editAssigmentSettingPopup ), "Edit Assignment Settings Pop up is dispalyed", "Edit Assignment Settings Pop up is not dispalyed" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher can able to see the Session Length, Idle time, Show/limit progress, Initial Placement, Calculator, Translate, Display Lo Information, ScratchPad, Show Answer, Exit Course, Share at District Level, Speed Games, Manually set Course Level components for Math Assignments", priority = 2 )
    public void tcSMGroupsAssignmentsSettingsPopup002() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        HashMap<String, String> testData = SMUtils.getTestData( "tcSMCourseListing001", "UI_Courseware" );
        Log.testCaseInfo(
                "tcSMAssignmentListing002: Verify the teacher can able to see the Session Length, Idle time, Show/limit progress, Initial Placement, Calculator, Translate, Display Lo Information, ScratchPad, Show Answer, Exit Course, Share at District Level, Speed Games, Manually set Course Level components for Math Assignments <small><b><i>["
                        + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupPage.obtainingMathSettings( tHomePage );
            SMUtils.waitForElement( driver, groupPage.editAssignmentSettingtitle );
            EditAssignmentSettingsPopUp editAssignmentSettingsPopUp = new EditAssignmentSettingsPopUp( driver ).get();
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForFirstColumn( Constants.EditAssignments.SESSION_LENGTH_HEADER ), "Session Length Element is Present", "Session Length Element is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForFirstColumn( Constants.EditAssignments.IDEAL_TIME_HEADER ), "Idle Time Element is Present", " Idle Time Element is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForFirstColumn( Constants.EditAssignments.PROGRESS_LIMIT_HEADER ), "Show Limt Progress Element is Present", " Show Limit Progres Element is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForFirstColumn( Constants.EditAssignments.INITIAL_PLACEMENT ), "Initial Placement Element is Present", " Initial Placement Element is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForFirstColumn( Constants.EditAssignments.DISPLAY_LO_INFORMATION ), "Display Lo information is Present", "Display Lo Information is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForFirstColumn( Constants.EditAssignments.HELP_ICON_ACTIVE ), "Help Icon Active is Present", "Help Icon Active is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForFirstColumn( Constants.EditAssignments.EXIT_COURSE_BUTTON ), "Help Icon Active is Present", "Help Icon Active is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForSecondColumn( Constants.EditAssignments.SPANISH_GLOSSARY ), "Spanish Glossary is Present", "Spanish Glossary is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForSecondColumn( Constants.EditAssignments.GRAMMAR_STRAND ), "Grammar Strand is Present", "Grammar Strand is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForSecondColumn( Constants.EditAssignments.READ_TO_ME ), "Read to me is present", "Read to me is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForSecondColumn( Constants.EditAssignments.TRANSLATE ), "Translate is Present", "Translate is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForSecondColumn( Constants.SHARE_AT_DISTRICT_LABEL ), "Share at the District Level is Present", "Share at the District Level is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForSecondColumn( Constants.EditAssignments.FLUENCY ), "Fluency is Present", "Fluency is not Present" );
            Log.assertThat( editAssignmentSettingsPopUp.verifyAssignmentSettingsLabelForSecondColumn( Constants.MANUALLY_SET_COURSE_LEVEL ), "Manual Course Level is Set", "Manual Course Level is  not Set" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
