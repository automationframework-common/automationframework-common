package com.savvas.sm.teacher.ui.pages;

import java.time.LocalDate;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

/**
 * @author pooja.perumal
 *
 */
public class CoursesPage extends LoadableComponent<CoursesPage> {

	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

	private String browser;
	private WebDriver driver;
	boolean isPageLoaded;
	public String RANDOM_STRING_CHAR = "AAa";

	public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();

	// ********* SuccessMaker Courses Page Elements ***************

	@IFindBy ( how = How.CSS, using = "cel-platform-navbar.hydrated", AI = false )
	public WebElement courseWareBtnRoot;

	@IFindBy ( how = How.CSS, using = "cel-icon[name='icon_error']", AI = false )
	public WebElement errorIconSymbol;

	@IFindBy ( how = How.CSS, using = "cel-platform-navbar.hydrated", AI = false )
	public WebElement coursesBtnGrandRoot;
	// Grand Parent For Courses Dropdown Lists
	@IFindBy ( how = How.CSS, using = "cel-dropdown-menu.course-custom-select-type", AI = false )
	public WebElement coursesDropdownBtnRoot;
	// Grand Parent For Sort By Dropdown Lists
	@IFindBy ( how = How.CSS, using = "cel-dropdown-menu.course-custom-select-order", AI = false )
	public WebElement sortByDropdownBtnRoot;

	@FindBy ( css = "span.tile__title" )
	List<WebElement> courseName;

	@FindBy ( css = ".tile__tooltiptext" )
	List<WebElement> toolTipCourseName;

	@IFindBy ( how = How.CSS, using = "cel-icon#dialogHeaderClose", AI = false )
	public WebElement btnClosePopupRoot;

	@IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
	public WebElement assignPopupHeader;

	@IFindBy ( how = How.NAME, using = "filterText", AI = false )
	public WebElement assignPopupTextBox;

	@IFindBy ( how = How.CSS, using = "div.name", AI = false )
	public WebElement assignPopupGroupName;

	@IFindBy ( how = How.CSS, using = "div.user-grade", AI = false )
	public WebElement assignPopupFotterText;

	@IFindBy ( how = How.CSS, using = "div.add-btn > cel-button[color='secondary']", AI = false )
	public WebElement assignPopupAddBtnRoot;

	@IFindBy ( how = How.CSS, using = "div.footer > cel-button[color='secondary']", AI = false )
	public WebElement assignPopupCancelBtnRoot;

	@IFindBy ( how = How.CSS, using = "cel-button.assign-button.hydrated", AI = false )
	public WebElement assignPopupAssignBtnRoot;

	@IFindBy ( how = How.CSS, using = "cel-button[class='cel-button-assign hydrated']", AI = false )
	public WebElement assignPopupAssignButtonRoot;

	/*
	 * @FindBy(css = "div.footer > cel-button[color='primary']") WebElement
	 * assignPopupAssignBtnRoot;
	 */

	@IFindBy ( how = How.XPATH, using = "//span[text()=' Initial Placement (IP) ']/following-sibling::span", AI = false )
	public WebElement IPStatus;

	@IFindBy ( how = How.CSS, using = "cel-button.cel-button-assign", AI = false )
	public WebElement assignBtnRoot;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "(//span[text()='Math'])[1]", AI = false )
	public WebElement mathCourse;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "(//span[text()='Reading'])[1]//child::span", AI = false )
	public WebElement readingCourse;

	@IFindBy ( how = How.CSS, using = "div.row:nth-child(2)>div:nth-child(2) span.tile__title", AI = false )
	public WebElement defaultReadingCourse;

	@IFindBy ( how = How.CSS, using = "cel-dropdown-menu.standard-Dropdown", AI = false )
	public WebElement skillsDropdownRoot;

	@IFindBy ( how = How.CSS, using = "cel-dropdown-menu.skill-Dropdown", AI = false )
	public WebElement gradeDropdownRoot;

	@IFindBy ( how = How.CSS, using = "cel-button.edit-btn", AI = false )
	public WebElement editBtnRoot;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//span[text()=' Initial Placement (IP) ']/following-sibling::span", AI = false )
	public WebElement iPStatus;

	@IFindBy ( how = How.CSS, using = "cel-button.remove-course", AI = false )
	public WebElement removeCourseBtnRoot;

	@IFindBy ( how = How.CSS, using = "div.dialog-wrapper", AI = false )
	public WebElement removeCourseDialogBox;

	@IFindBy ( how = How.CSS, using = "div.confirm-modal-footer > cel-button:not([color='secondary'])", AI = false )
	public WebElement removeCourseDialogBoxRemoveBtnRoot;

	@FindBy ( css = "span.side-nav-item" )
	List<WebElement> leftStrandMathCourses;

	@IFindBy ( how = How.CSS, using = "div.hierarchy-body", AI = false )
	public WebElement middleHierarchyForMathCourses;

	@IFindBy ( how = How.XPATH, using = "//span[text()=' Settings ']", AI = false )
	public WebElement settingsTextForMathCourses;

	@FindBy ( css = ".margin-top  .tile,.course-row .tile" )
	List<WebElement> coursesParent;

	@IFindBy ( how = How.CSS, using = "span.side-nav-placeholder-1", AI = false )
	public WebElement strandStatus;

	// ********* SuccessMaker Make a copy Page Elements ***************
	@IFindBy ( how = How.CSS, using = "div.student-info div.name", AI = false )
	public WebElement groupsList;

	@FindBy ( css = "div.student-info div.name" )
	List<WebElement> studentList;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "(//label[@class='radio__label sc-cel-radio-button'])[2]", AI = false )
	public WebElement studentRadioBtn;

	@IFindBy ( how = How.CSS, using = "cel-radio-button:nth-of-type(2) .radio__label.sc-cel-radio-button", AI = false )
	public WebElement studentRadioButton;

	@IFindBy ( how = How.CSS, using = "#cel-rb-1", AI = false )
	public WebElement studentRadioButtonRead;

	@IFindBy ( how = How.CSS, using = "cel-radio-button:nth-of-type(1) .radio__label.sc-cel-radio-button", AI = false )
	public WebElement groupRadioButton;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "(//label[@class='radio__label sc-cel-radio-button'])[1]", AI = false )
	public WebElement groupsradioBtn;

	@IFindBy ( how = How.CSS, using = "cel-platform-navbar.hydrated", AI = false )
	public WebElement assignmentsubMenuGrandRoot;

	@FindBy ( css = "cel-tile span.tile__tag" )
	List<WebElement> courseTitleParentElement;

	@IFindBy ( how = How.CSS, using = "cel-button-menu.tile-ellipsis-btn", AI = false )
	public WebElement viewAssignedEllipsisSymbol;

	@IFindBy ( how = How.CSS, using = "div.dialog-wrapper div.dialog-wrapper__content div.dialog-footer cel-button.ok-button-wrapper", AI = false )
	public WebElement parentElementViewAssignedByOkBtn;

	@IFindBy ( how = How.CSS, using = ".dialog-wrapper__content", AI = false )
	public WebElement assignedByPopupDialog;

	@FindBy ( css = ".dialog-wrapper .dialog-body tbody>tr>td:nth-of-type(1)" )
	List<WebElement> teachertNameListViewAssignedBypopupTable;

	@FindBy ( css = ".dialog-wrapper .dialog-body tbody>tr" )
	List<WebElement> teachertDateListViewAssignedBypopupTable;

	@IFindBy ( how = How.CSS, using = "div.popup-dialog-header .heading-wrapper span.heading-text", AI = false )
	public WebElement viewAssignedByPopupTitle;

	@IFindBy ( how = How.CSS, using = ".dialog-wrapper .table-container th:nth-of-type(1) .d-flex span:not(.sort-icon)", AI = false )
	public WebElement assignedByPopupNameHeading;

	@IFindBy ( how = How.CSS, using = ".dialog-wrapper .table-container th:nth-of-type(2) .d-flex span:not(.sort-icon)", AI = false )
	public WebElement assignedByPopupCourseLastAssignedHeading;

	@IFindBy ( how = How.CSS, using = ".dialog-wrapper .table-container th:nth-of-type(1) .d-inline-flex span:not(.sort-icon)", AI = false )
	public WebElement assignedByPopupNameHeadingSort;

	@IFindBy ( how = How.CSS, using = ".dialog-wrapper .table-container th:nth-of-type(2) .d-inline-flex span:not(.sort-icon)", AI = false )
	public WebElement assignedByPopupCourseLastAssignedHeadingSort;

	@IFindBy ( how = How.CSS, using = "cel-tile .tile__title", AI = false )
	public WebElement courseTitle;

	@IFindBy ( how = How.CSS, using = "cel-button.cel-button-edit", AI = false )
	public WebElement topEditButton;

	@FindBy ( css = ".sidenav-parent .side-nav-wrapper-inactive .side-nav-item" )
	List<WebElement> sideBarNav;

	@IFindBy ( how = How.CSS, using = ".sidenav-parent .side-nav-wrapper-active .side-nav-item", AI = false )
	public WebElement sideBarNavActiveElement;

	@FindBy ( css = ".centerpiece .outer-header-title span.outer-data" )
	List<WebElement> topicListOfEachStandard;

	@FindBy ( css = ".centerpiece .inner-header-title .outer-data" )
	List<WebElement> subTopic;

	@FindBy ( css = ".centerpiece app-accordion-item[header='inner-header'] app-accordion-item[header='inner-header'] .inner-header-title .outer-data" )
	List<WebElement> subTopicOfTopics;

	@FindBy ( css = ".content-block a" )
	List<WebElement> loText;

	@FindBy ( css = "th.th-text" )
	List<WebElement> viewAssignedByPopupHeading;

	@IFindBy ( how = How.CSS, using = ".popup-dialog-header cel-icon[class='contextual-help-icon hydrated']", AI = false )
	public WebElement helpIconSubContainer;

	@IFindBy ( how = How.CSS, using = ".dialog-body .table-row", AI = false )
	public WebElement viewAssignedByTableRowHeader;

	@IFindBy ( how = How.CSS, using = ".dialog-body .th-text", AI = false )
	public WebElement viewAssignedByTableRowHeaderTitle;

	@IFindBy ( how = How.CSS, using = ".dialog-body .table-body td", AI = false )
	public WebElement viewAssignedByTableCell;

	@IFindBy ( how = How.CSS, using = ".dialog-body tbody>tr", AI = false )
	public WebElement viewAssignedByPopupTableRow;

	@IFindBy ( how = How.CSS, using = "cel-button-menu", AI = false )
	public WebElement viewAssignedByHostButton;

	// ********* SuccessMaker Make a copy Page Elements ***************

	@IFindBy ( how = How.CSS, using = "cel-button.cel-button-copy", AI = false )
	public WebElement btnMakeCopyRoot;

	@IFindBy ( how = How.CSS, using = "div.col-md-1 > div", AI = false )
	public WebElement pageTitle;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//label[text()='Settings']", AI = false )
	public WebElement customBySettings;

	@IFindBy ( how = How.CSS, using = "input#cel-rb-0", AI = false )
	public WebElement settingsRadioBtn;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//label[text()='Skills']", AI = false )
	public WebElement customBySkills;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//label[text()='Standards']", AI = false )
	public WebElement customByStandards;

	@IFindBy ( how = How.CSS, using = "form.container div.form-group:last-child input", AI = false )
	public WebElement customByStandardsRadioBtn;

	@FindBy ( css = "span [Class='tile__tooltiptext']" )
	List<WebElement> listOfCoursesSafari;

	@IFindBy ( how = How.CSS, using = ".dialog-wrapper__content form label[for='cel-rb-0']", AI = false )
	public WebElement customByStandardsFocusRadioBtn;

	@IFindBy ( how = How.CSS, using = "input.slider", AI = false )
	public WebElement slider;

	@IFindBy ( how = How.CSS, using = "tbody.table-body tr td span+span", AI = false )
	public WebElement assignmentPageList;

	@IFindBy ( how = How.CSS, using = "input#newCourseName", AI = false )
	public WebElement courseNameTextBox;

	@IFindBy ( how = How.CSS, using = "span.slider-value span", AI = false )
	public WebElement sliderValue;

	@IFindBy ( how = How.CSS, using = "tbody.table-body tr td span+span", AI = false )
	public WebElement AssignmentPageList;

	@IFindBy ( how = How.CSS, using = "tbody.table-body tr td cel-button", AI = false )
	public WebElement viewAssignmentBtnRoot;


	@IFindBy ( how = How.CSS, using = "cel-button.next-button-wrapper", AI = false )
	public WebElement customNextBtnRoot;

	@IFindBy ( how = How.CSS, using = "setting-control>div:first-of-type+div>div", AI = false )
	public WebElement speedGamesBtnOFFInViewStudentSettings;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Initial')]/parent::setting-control//child::button[contains(@class, 'toggle-on')]", AI = false )
	public WebElement initialPlacementBtnON;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Initial')]/parent::setting-control//child::button[contains(@class, 'toggle-off')]", AI = false )
	public WebElement initialPlacementBtnOFF;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Calculator')]/parent::setting-control//child::button[contains(@class, 'toggle-on')]", AI = false )
	public WebElement calculatorBtnON;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Calculator')]/parent::setting-control//child::button[contains(@class, 'toggle-off')]", AI = false )
	public WebElement calculatorBtnOFF;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Translate')]/parent::setting-control//child::button[contains(@class, 'toggle-off')]", AI = false )
	public WebElement translateBtnOFF;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Translate')]/parent::setting-control//child::button[contains(@class, 'toggle-on')]", AI = false )
	public WebElement translateBtnON;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Display')]/parent::setting-control//child::button[contains(@class, 'toggle-on')]", AI = false )
	public WebElement displayInfoBtnON;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Display')]/parent::setting-control//child::button[contains(@class, 'toggle-off')]", AI = false )
	public WebElement displayInfoBtnOFF;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Scratchpad')]/parent::setting-control//child::button[contains(@class, 'toggle-on')]", AI = false )
	public WebElement scratchPadBtnON;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Scratchpad')]/parent::setting-control//child::button[@class='switch-button toggle-off']", AI = false )
	public WebElement scratchPadBtnOFF;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'answer')]/parent::setting-control//child::button[contains(@class, 'toggle-on')]", AI = false )
	public WebElement showAnswerBtnON;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'answer')]/parent::setting-control//child::button[contains(@class, 'toggle-off')]", AI = false )
	public WebElement showAnswerBtnOFF;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Exit')]/parent::setting-control//child::button[contains(@class, 'toggle-on')]", AI = false )
	public WebElement exitCourseBtnON;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Exit')]/parent::setting-control//child::button[contains(@class, 'toggle-off')]", AI = false )
	public WebElement exitCourseBtnOFF;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'District')]/parent::setting-control//child::button[contains(@class, 'toggle-on')]", AI = false )
	public WebElement shareDistrictLevelBtnON;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'District')]/parent::setting-control//child::button[contains(@class, 'toggle-off')]", AI = false )
	public WebElement shareDistrictLevelBtnOFF;

	//TODO: Replace the xpath with css locator    
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Speed')]/parent::setting-control//child::button[contains(@class, 'toggle-on')]", AI = false )
	public WebElement speedGamesBtnON;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Speed')]/parent::setting-control//child::button[contains(@class, 'toggle-off')]", AI = false )
	public WebElement speedGamesBtnOFF;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Manually')]/parent::setting-control//child::button[contains(@class, 'toggle-off')]", AI = false )
	public WebElement courseLevelBtnOFF;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Manually')]/parent::setting-control//child::button[contains(@class, 'toggle-on')]", AI = false )
	public WebElement courseLevelBtnON;

	@FindBy ( css = ".cell-group.cell-tooltip" )
	List<WebElement> studentNameListForAssignment;

	@FindBy ( css = ".setting-wrapper.dropdown-control-wrapper ul.dropdown-select-options>li>a" )
	List<WebElement> dropdownFirstColumnList;

	@FindBy ( css = "div [class='first column'] .dropdown-control-wrapper" )
	List<WebElement> dropdownFirstColumn;

	@FindBy ( css = "div [class='second column'] .toggle-control-wrapper" )
	List<WebElement> editCourseSecondColumnElements;

	@FindBy ( css = "div [class='first column'] .toggle-control-wrapper" )
	List<WebElement> editCourseFirstColumnElements;

	@IFindBy ( how = How.CSS, using = ".dropdown-select-label .sc-cel-dropdown-select" )
	public WebElement dropdownValue;

	@FindBy ( css = ".course-settings .setting-block .setting-div" )
	List<WebElement> courseSettingList;

	@FindBy ( css = ".dialog-wrapper__content cel-radio-button .radio__wrapper" )
	List<WebElement> courseAssignParentRadioBtn;

	@IFindBy (how = How.CSS, using = "span.error-text", AI = false )
	public WebElement makeACopyErrorMessage;

	@IFindBy (how = How.CSS, using = "span.heading-text.heading-text-settings", AI = false )
	public WebElement makeACopyDialogHeader;

	@IFindBy (how = How.CSS, using = "span.cancel-button-wrapper .hydrated", AI = false )
	public WebElement makeACopyDialogCancelButton;

	// --------ShadowHost Elements------------

	@IFindBy ( how = How.CSS, using = "div.first > div:nth-child(1) setting-control div.dropdown-select cel-icon", AI = false )
	public WebElement sessionLenghtDropDownRoot;

	@IFindBy ( how = How.CSS, using = "div.first > div:nth-child(2) setting-control div.dropdown-select cel-icon", AI = false )
	public WebElement idleTimeDropDownRoot;

	@IFindBy ( how = How.CSS, using = "div.first > div:nth-child(3) setting-control div.dropdown-select cel-icon", AI = false )
	public WebElement showProgressReportDropDownRoot;

	@IFindBy ( how = How.CSS, using = "div.second > div:nth-child(5) div.w-100 div.multi-dropdown-control-wrapper:nth-child(1) div.dropdown-select cel-icon", AI = false )
	public WebElement speedGamesTimePerQuesRoot;

	@IFindBy ( how = How.CSS, using = "div.second > div:nth-child(5) div.w-100 div.multi-dropdown-control-wrapper:nth-child(1) div.dropdown-select cel-icon", AI = false )
	public WebElement speedGamesTotalTimeRoot;

	@IFindBy ( how = How.CSS, using = "cel-button[color='primary']", AI = false )
	public WebElement createBtnRoot;

	@IFindBy ( how = How.CSS, using = "div.dialog-footer div.back-btn-wrapper cel-button", AI = false )
	public WebElement backBtnRoot;

	@IFindBy ( how = How.CSS, using = "span.cancel-button-wrapper cel-button", AI = false )
	public WebElement cancelBtnRoot;

	@IFindBy ( how = How.CSS, using = "cel-button:not([class=cancel-button])[class=hydrated]", AI = false )
	public WebElement btnSaveRoot;

	@IFindBy ( how = How.CSS, using = "div[class='footer-button-wrapper']>cel-button:nth-child(2)", AI = false )
	public WebElement btnNewSaveRoot;

	@IFindBy ( how = How.CSS, using = ".dialog-footer .action-btn-wrapper cel-button.hydrated", AI = false )
	public WebElement btnCancelHost;

	@IFindBy ( how = How.CSS, using = "cel-button.create-button-wrapper", AI = false )
	public WebElement btnCreateRoot;

	@IFindBy ( how = How.CSS, using = "div.add-btn cel-button", AI = false )
	public WebElement addBtnRoot;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "(//button[@class='switch-button toggle-off'])[1]", AI = false )
	public WebElement strandToggleBtn1;

	@IFindBy ( how = How.CSS, using = ".side-nav-wrapper-active button[class='switch-button toggle-off']", AI = false )
	public WebElement strandToggleBtnOff;

	@IFindBy ( how = How.CSS, using = "span.slider-acc.round.toggle-acc.ng-tns-c71-18", AI = false )
	public WebElement subStrandToggleBtnOn;

	@IFindBy ( how = How.CSS, using = ".side-nav-wrapper-active button[class='switch-button toggle-on']", AI = false )
	public WebElement strandToggleBtnOn;

	//TODO: Replace the xpath with css locator
	@IFindBy ( how = How.XPATH, using = "//div[contains(text(),'Comprehension')]/parent::setting-control//child::button[contains(@class, 'toggle-off')]", AI = false )
	public WebElement strandToggleBtnForSkillCourse;

	@IFindBy ( how = How.CSS, using = "div.side-nav div:nth-child(1)  span.side-nav-item", AI = false )
	public WebElement leftPanelFirstCourseStrand;

	@IFindBy ( how = How.CSS, using = "div.popup-dialog-header .close-button-wrapper .hydrated", AI = false )
	public WebElement viewAssignedByPopupCloseParent;

	@IFindBy ( how = How.CSS, using = "#report tr:nth-of-type(1) td:nth-of-type(1) cel-icon[name='addition']", AI = false )
	public WebElement expandForSkillDeatils;

	@IFindBy ( how = How.CSS, using = "#report tr:nth-of-type(1) td:nth-of-type(1) cel-icon[name='subtraction']", AI = false )
	public WebElement shrinkForSkillDeatils;

	@FindBy ( css = ".list-assignment .table-container td:nth-of-type(1) .text-overflow-nowrap" )
	List<WebElement> assignmentTitle;

	@IFindBy ( how = How.CSS, using = "div.table-container>table>tbody>tr", AI = false )
	public WebElement studentListAssignmentTable;

	@IFindBy ( how = How.CSS, using = "div.course-tile-section img.course-back-icon", AI = false )
	public WebElement backIcon;

	@FindBy ( css = "setting-control.toggle-control-wrapper div.setting-label" )
	List<WebElement> buttonLabelinCourseSettings;

	@IFindBy ( how = How.CSS, using = ".filter-title .title-txt", AI = false )
	public WebElement assignToModal;

	@IFindBy ( how = How.CSS, using = "cel-button.save-button-wrapper", AI = false )
	public WebElement saveButton;

	@FindBy ( css = ".student-name div[class='name']" )
	List<WebElement> groupNameListFromAssignPopup;

	@IFindBy ( how = How.CSS, using = ".standard-Dropdown", AI = false )
	public WebElement standardDropdownBtnHost;

	@IFindBy ( how = How.CSS, using = ".skill-Dropdown", AI = false )
	public WebElement skillDropdownBtnHost;

	@IFindBy ( how = How.CSS, using = "div.confirm-modal-footer > cel-button[color=secondary]", AI = false )
	public WebElement removeCoursePopupCancelBtnRoot;

	@IFindBy ( how = How.CSS, using = "h4.course-type-title", AI = false )
	public WebElement courseTypeTitle;

	@IFindBy ( how = How.CSS, using = "div.outer-header-title", AI = false )
	public WebElement tierNodeTitle;

	@IFindBy ( how = How.CSS, using = "cel-icon.icon-caret", AI = false )
	public WebElement tierNodeExpandIcon;

	@IFindBy ( how = How.CSS, using = "cel-icon.status-icon", AI = false )
	public WebElement loStatusIcon;

	@IFindBy ( how = How.CSS, using = "span.lo-color > a", AI = false )
	public WebElement loLink;

	@IFindBy ( how = How.CSS, using = "div.inner-header-title > span.outer-data", AI = false )
	public WebElement innerTierNodeTitle;

	@IFindBy ( how = How.CSS, using = "cel-icon[aria-label='file-pdf']", AI = false )
	public WebElement pdfIcon;

	@IFindBy ( how = How.CSS, using = "span.course-lo-info > span.lo-text", AI = false )
	public WebElement loDetail;

	@IFindBy ( how = How.CSS, using = "h1[title='Remove Course']", AI = false )
	public WebElement removeCourseDialogTitle;

	@IFindBy ( how = How.CSS, using = "span.course-lo-status > span.status", AI = false )
	public WebElement loStatus;

	@FindBy ( css = "div.margin-top div cel-tile span.tile__tooltip" )
	List<WebElement> listOfCourses;

	@IFindBy ( how = How.CSS, using = "course-details >section>div.course-division>div>cel-tile >div>div >span.tile__title.tile__tooltip", AI = false )
	public WebElement courseHeader;

	@IFindBy ( how = How.CSS, using = ".dialog-hierarcy .standard-Dropdown", AI = false )
	public WebElement standardPopupDropdownBtnHost;

	@IFindBy ( how = How.CSS, using = ".dialog-hierarcy .skill-Dropdown", AI = false )
	public WebElement skillPopupDropdownBtnHost;

	@IFindBy ( how = How.CSS, using = "cel-multi-check-dropdown.hydrated", AI = false )
	public WebElement languageDropdownHost;

	@IFindBy ( how = How.CSS, using = "cel-tile img.tile__image", AI = false )
	public WebElement courseTileImage;

	@IFindBy ( how = How.CSS, using = "cel-multi-check-dropdown", AI = false )
	public WebElement selectAllCheckBoxHost;

	@IFindBy ( how = How.CSS, using = "cel-dialog div.dialog-wrapper", AI = false )
	public WebElement msdaAutoAssignDialogBox;

	@IFindBy ( how = How.CSS, using = "div.confirm-msda-modal-footer cel-button.secondary-button", AI = false )
	public WebElement msdaContinueToAssignButtonHost;

	@IFindBy ( how = How.CSS, using = "div.dialog-header h1.dialog-header__message", AI = false )
	public WebElement msdaTitleElement;

	@FindBy ( css = "course-widget cel-tile" )
	List<WebElement> courseWidgetList;

	@IFindBy ( how = How.CSS, using = "chip-search-area full-width-filter ng-pristine ng-valid ng-touched", AI = false )
	public WebElement Searchfieldbutton;

	@IFindBy ( how = How.CSS, using = "chip-search-area full-width-filter ng-valid ng-touched ng-dirty", AI = false )
	public WebElement SearchfieldStudent;

	@IFindBy ( how = How.ID, using = "userName", AI = false )
	public WebElement txtboxUserName;

	@FindBy ( css  = ".side-nav .side-nav-placeholder button" )
	List<WebElement> allStrands;

	// Root Child Elements
	private static String courseWareBtn = "span[aria-label='Courseware']";
	private static String coursesBtnParent = "cel-dropdown-menu-box.box";
	private static String coursesBtnChild = "span[aria-label='Assignments']";
	private static String btnCloseIcon = "img.icon-inner";
	private static String btnPrimary = ".primary_button";
	private static String btnSecondary = ".secondary_button";
	private static String iconInner = ".icon-inner";
	private static String cancelBtnChild = "button.secondary_button";
	private static String dropdownMenuBox = "cel-dropdown-menu-box";
	private static String listItem = "li.menu-item";
	private static String childNodeIds = "childNodeIds";
	private static String id = "id";

	private static String dropdownBtn = ".dropdown-trigger__label";
	private static String dropdownBtnParent = "cel-dropdown-menu-box.hydrated";
	private static String dropdownBtnChild = ".menu-item";
	private static String clickDropdownBtnParent = ".hydrated";
	private static String clickDropdownBtnChild = ".icon-inner";

	private static String assignmentssubMenuParent = "cel-dropdown-menu-box.box";
	private static String assignmentsubMenuChild = "span[aria-label='Assignments']";
	private static String courseTitleCSS = ".tile__body .tile__tooltip";
	private static String courseAssignBtnCSSShadow = ".tile__button>.cel-button-assign";
	private static String courseAssignBtnCSS = ".primary_button";
	// Courses Dropdown Lists
	private static String focusCoursesChild = "span[aria-label='Focus Courses']";
	private static String defaultCoursesChild = "span[aria-label='Default Courses']";
	private static String customCoursesChild = "span[aria-label='Custom Courses']";
	private static String allCoursesChild = "span[aria-label='All Courses']";
	// Sort By Dropdown Lists
	private static String courseTitleAscChild = "span[aria-label='Course Title (Ascending)']";
	private static String courseTitleDscChild = "span[aria-label='Course Title (Descending)']";
	private static String courseDateAscChild = "span[aria-label='Course Date (Ascending)']";
	private static String courseDateDscChild = "span[aria-label='Course Date (Descending)']";
	private static String dropDownIconBtn = ".icon-inner";
	private static String courseTypeCSS = ".tile__tag";
	private static String coursDateCSS = "span[class='tile__info']";
	private static String commonCssForSkillDetailsIcon = "img.icon-inner";
	private static String commonCssTitle = "span.tile__title";
	private static String commonCssStudentTitle = ".cell-tooltiptext";
	//View Assigned By pop up
	private static String viewAssignedEllipsisMenuParent = "cel-dropdown-menu-box.menu-position-left.hydrated";
	private static String viewAssignedEllipsisMenuChild = "span.menu-item__label";
	private static String viewAssignedByOkButton = "button.secondary_button";
	private static String commonCssForTooltip = ".cell-group.cell-tooltip";
	private static String commonViewAssignedByPopup = "td:nth-of-type(1) span[class='text-overflow-nowrap']:nth-of-type(1)";
	private static String commonViewAssignedByLastAssignedPopup = "td:nth-of-type(2) span[class='text-overflow-nowrap']:nth-of-type(1)";
	private static String addButtonRoot = "div.add-btn cel-button";
	private String sharedAtDistrictLevel = null;
	private String displayLoInformation = null;
	private String displayLoInformationCourseSetting = null;
	private String courseSettingStatus = null;
	private static String settingLabel = ".setting-label";
	private static String settingData = ".setting-data";
	private static String toggleOffButton = "button.switch-button.toggle-off";
	private static String toggleOnButton = "button.switch-button.toggle-on";
	private static String courseTypeData = ".course-type-data";
	private static String viewAssignedEllipsisMenu = ".buttonmenu";
	//Course creation settings
	private static String buttonToggleOn = "button.toggle-on";
	private static String childeditbutton = ".secondary_button";
	//Default Courses dropdown
	private static String standardDropdownBtn = "button.dropdown-trigger";
	private static String languageDropdownBtn = "button.dropdown-head";
	private static String selectAllCheckBoxRoot = "div > div > div > ul > li > div > cel-checkbox";
	private static String selectAllCheckBox = "div > label.checkbox__container > span";
	private String calculatorToggleStatus = null;
	private String translateToggleStatus = null;
	private String scratchpadToggleStatus = null;
	private String showAnswerToggleStatus = null;
	private String exitCourseToggleStatus = null;
	private String spanishGlossaryToggleStatus = null;
	private String readToMeToggleStatus = null;
	private String fluencyToggleStatus = null;
	private String fieldValue = null;

	public CoursesPage() {}

	/**
	 * 
	 * Constructor class for Courses page and initializing the driver for page
	 * factory objects.
	 * 
	 * @param driver
	 * @throws InterruptedException
	 */

	public CoursesPage( WebDriver driver ) {
		this.driver = driver;
		ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
		PageFactory.initElements( finder, this );
		elementLayer = new ElementLayer( driver );
	}

	@Override
	protected void load() {
		isPageLoaded = true;
		SMUtils.waitForElement( driver, pageTitle );
	}

	@Override
	protected void isLoaded() throws Error {
		if ( !isPageLoaded ) {
			Assert.fail();
		}
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( InterruptedException e ) {
			Log.message( "Issue in Spinner Loading" );
		}
		if ( SMUtils.waitForElement( driver, pageTitle ) ) {
			Log.message( "SM Courses Page loaded successfully." );
		} else {
			Log.fail( "SM Courses Page did not load." );
		}
	}

	/**
	 * To turn off the Strand
	 */

	public void clickStrandBtn() {
		SMUtils.waitForElement( driver, strandToggleBtn1, 8 );
		SMUtils.clickJS( driver, strandToggleBtn1 );

	}

	public void clickDefualtBtnOff() {
		SMUtils.waitForElement( driver, strandToggleBtnOn, 5 );
		SMUtils.clickJS( driver, strandToggleBtnOn );
		Log.message( "First toggle button is Selected" );
	}

	/**
	 * To turn on the Strand
	 */

	public void clickDefualtBtnOn() {
		SMUtils.waitForElement( driver, strandToggleBtnOff, 5 );
		SMUtils.clickJS( driver, strandToggleBtnOff );

		Log.message( "First toggle button is Selected" );
	}

	/**
	 * To turn on the first strand under first skill strand
	 */

	public void clickSubStrandBtnOn() {
		SMUtils.waitForElement( driver, subStrandToggleBtnOn, 5 );
		SMUtils.clickJS( driver, subStrandToggleBtnOn );

		Log.message( "First toggle button is Selected" );
	}

	/**
	 * To click radio button
	 * 
	 * @param courseType
	 */

	public void coursesRadioBtn( String courseType, String courseName ) {
		if ( courseType.equals( Constants.STANDARDS ) ) {
			if ( courseName.equals( Constants.SM_FOCUS_READING_GRADE1 ) || courseName.equals( Constants.SM_FOCUS_MATH_GRADE1 ) ) {
				clickStandardsRadioBtnForFocusCourse();
			} else {
				clickStandardsRadioBtn();
			}
		}
		if ( courseType.equals( Constants.SKILLS ) ) {
			clickSkillsRadioBtn();
		}
		if ( courseType.equals( Constants.SETTINGS ) ) {
			clickSettingsRadioBtn();
		}
	}

	/**
	 * To generate random course name
	 *
	 * @return coureName
	 */
	public String generateRandomCourseName() {
		return String.join( "", Constants.RANDOM_STRING_CHAR, RandomStringUtils.randomAlphabetic( 10 ) ).trim().replaceAll( "\\s{2,}", " " );
	}

	/**
	 * To create new course using Default or Focus Courses
	 * 
	 * @param courseName
	 * @param courseType
	 * @param courseNameToCopy
	 * @throws Exception
	 */
	public void copyOfCourse( String courseName, String courseType, String courseNameToCopy ) throws Exception {
		clickFromCourseListingPage( courseNameToCopy );
		clickMakeCopyBtn();
		enterCourseName( courseName );
		coursesRadioBtn( courseType, courseNameToCopy );
		radioButtonSelection( courseType, courseNameToCopy );
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Please check logs for copyOfCourse spinner issues" );
		}
	}

	/**
	 * 
	 * To select radio button from for "Create a course on this course's"
	 * 
	 * @param courseType
	 * @param courseNameToCopy
	 */

	public void radioButtonSelection( String courseType, String courseNameToCopy ) {
		if ( courseType.equals( Constants.SETTINGS ) ) {
			clickNextBtn();
			try {
				SMUtils.waitForSpinnertoDisapper( driver, 60 );
			} catch ( Exception e ) {
				Log.message( "Spinner not loaded for the second popup of custom course creation" );
			}
			clickCreateBtn();
		} else if ( courseType.equals( Constants.STANDARDS ) ) {
			courseBasedOnStandards( Constants.STANDARDS, courseNameToCopy );
		} else if ( courseType.equals( Constants.SKILLS ) ) {
			courseBasedOnSkills( Constants.SKILLS, courseNameToCopy );
		}
	}

	/**
	 * 
	 * To create a copy from course based on Standards
	 * 
	 * @param courseType
	 * @param courseNameToCopy
	 */
	public void courseBasedOnStandards( String courseType, String courseNameToCopy ) {
		if ( courseNameToCopy.equals( Constants.MATH ) || courseNameToCopy.equals( Constants.SM_FOCUS_MATH_GRADE1 ) ) {
			courseBasedOnDefaultOrFocusMathStandards( courseType, courseNameToCopy );
		} else if ( courseNameToCopy.equals( Constants.READING ) || courseNameToCopy.equals( Constants.SM_FOCUS_READING_GRADE1 ) ) {
			courseBasedOnDefaultOrFocusReadingStandards( courseType, courseNameToCopy );
		}
	}

	/**
	 * 
	 * To create a copy from course based on Default or Focus Math Standards
	 * 
	 * @param courseType
	 * @param courseNameToCopy
	 */
	public void courseBasedOnDefaultOrFocusMathStandards( String courseType, String courseNameToCopy ) {
		if ( courseType.equals( Constants.STANDARDS ) ) {
			if ( courseNameToCopy.equals( Constants.MATH ) || courseNameToCopy.equals( Constants.SM_FOCUS_MATH_GRADE1 ) ) {
				clickNextBtn();
				try {
					SMUtils.waitForSpinnertoDisapper( driver, 60 );
				} catch ( Exception e ) {
					Log.message( "Spinner not loaded for the second popup of custom course creation" );
				}
				if ( getTheStatusOfTheSharedAtDistrictLevel( Constants.OFF_CAPS ).equals( Constants.OFF_CAPS ) ) {
					changeStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
				}
				getTheStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
				clickNextBtn();
				try {
					SMUtils.waitForSpinnertoDisapper( driver, 60 );
				} catch ( Exception e ) {
					Log.message( "Spinner not loaded for the third popup of custom course creation" );
				}
				if ( courseNameToCopy.equals( Constants.SM_FOCUS_MATH_GRADE1 ) ) {
					clickDefualtBtnOff();
				} else {
					clickDefualtBtnOn();
				}
				clickCreateBtn();
			}
		}
	}

	/**
	 * 
	 * To create a copy from course based on Default or Focus Reading Standards
	 * 
	 * @param courseType
	 * @param courseNameToCopy
	 */
	public void courseBasedOnDefaultOrFocusReadingStandards( String courseType, String courseNameToCopy ) {
		if ( courseType.equals( Constants.STANDARDS ) ) {
			if ( courseNameToCopy.equals( Constants.READING ) || courseNameToCopy.equals( Constants.SM_FOCUS_READING_GRADE1 ) ) {
				clickNextBtn();
				try {
					SMUtils.waitForSpinnertoDisapper( driver, 60 );
				} catch ( Exception e ) {
					Log.message( "Spinner not loaded for the second popup of custom course creation" );
				}
				if ( getTheStatusOfTheSharedAtDistrictLevel( Constants.OFF_CAPS ).equals( Constants.OFF_CAPS ) ) {
					changeStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
				} else {
					getTheStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
				}
				clickNextBtn();
				try {
					SMUtils.waitForSpinnertoDisapper( driver, 60 );
				} catch ( Exception e ) {
					Log.message( "Spinner not loaded for the third popup of custom course creation" );
				}
				if ( courseNameToCopy.equals( Constants.SM_FOCUS_READING_GRADE1 ) ) {
					clickDefualtBtnOff();
				} else {
					clickDefualtBtnOn();
				}
				clickCreateBtn();
			}
		}
	}

	/**
	 * 
	 * To create a copy from course based on Skills
	 * 
	 * @param courseType
	 * @param courseNameToCopy
	 */
	public void courseBasedOnSkills( String courseType, String courseNameToCopy ) {
		if ( courseType.equals( Constants.SKILLS ) ) {
			if ( courseNameToCopy.equals( Constants.MATH ) ) {
				clickNextBtn();
				try {
					SMUtils.waitForSpinnertoDisapper( driver, 60 );
				} catch ( Exception e ) {
					Log.message( "Spinner not loaded for the second popup of custom course creation" );
				}
				if ( getTheStatusOfTheSharedAtDistrictLevel( Constants.OFF_CAPS ).equals( Constants.OFF_CAPS ) ) {
					changeStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
				}
				getTheStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
				clickNextBtn();
				try {
					SMUtils.waitForSpinnertoDisapper( driver, 60 );
				} catch ( Exception e ) {
					Log.message( "Spinner not loaded for the third popup of custom course creation" );
				}
				clickDefualtBtnOn();
				clickCreateBtn();
			} else if ( courseNameToCopy.equals( Constants.READING ) ) {
				clickNextBtn();
				try {
					SMUtils.waitForSpinnertoDisapper( driver, 60 );
				} catch ( Exception e ) {
					Log.message( "Spinner not loaded for the second popup of custom course creation" );
				}
				if ( getTheStatusOfTheSharedAtDistrictLevel( Constants.OFF_CAPS ).equals( Constants.OFF_CAPS ) ) {
					changeStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
				} else {
					getTheStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
				}
				clickNextBtn();
				try {
					SMUtils.waitForSpinnertoDisapper( driver, 60 );
				} catch ( Exception e ) {
					Log.message( "Spinner not loaded for the third popup of custom course creation" );
				}
				clickDefualtBtnOn();
				clickCreateBtn();
			}
		}
	}

	//TODO - Comment by reviewer - "Replace with IntSream.range, what is 36 here?"
	/**
	 * To move the slider
	 * 
	 * @param courseLevel
	 */
	public void moveSliderTo( String courseLevel ) {
		String valueOfSlider = null;
		for ( int i = 1; i <= 36; i++ ) {
			slider.sendKeys( Keys.ARROW_RIGHT );
			valueOfSlider = sliderValue.getText().trim();
			if ( valueOfSlider.equals( courseLevel ) ) {
				break;
			}
		}
		Log.message( "The course level is setted as " + valueOfSlider );
	}

	/**
	 * To get course level
	 * 
	 * @return
	 */
	public String getCourseLevel() {
		SMUtils.waitForElement( driver, sliderValue );
		String valueOfSlider = sliderValue.getText();
		Log.message( "Course Level is setted as " + valueOfSlider );
		return valueOfSlider;
	}

	/**
	 * Click Math course
	 */
	public void clickMathCourse() {
		SMUtils.waitForElement( driver, mathCourse );
		SMUtils.clickJS( driver, mathCourse );
		Log.message( "Clicked Math Course" );
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Please check logs for issue in clickMathCourse" );
		}
	}
	
	  public String mathCourseName() {
	    	String text = mathCourse.getText();
	        Log.message(text);
	        return text;
		}

	/**
	 * Click course
	 * 
	 * @throws Exception
	 */
	public void clickCourseFromTheListing( String course ) throws Exception {
		SMUtils.nap( 2 );//this wait require to load the course page
		clickCourseName( course );
		Log.message( "Clicked " + course );
	}

	/**
	 *
	 * Click reading course
	 */
	public void clickReadingCourse() {
		SMUtils.waitForElement( driver, readingCourse, 30 );
		SMUtils.clickJS( driver, readingCourse );
		Log.message( "Clicked Reading Course" );
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Please check logs for issue in clickReadingCourse!!" );
		}
	}

	/**
	 * Click Make A Copy button
	 */
	public void clickMakeCopyBtn() {
		//Here we are using nap for stability in the Safari browser. Tried with the WebDriver waits but is fails in some cases.
		SMUtils.nap( 8 );

		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Spinner loading not completed for 'Make a copy' button" );
		}
		WebElement makeCopyBtn = SMUtils.getWebElementDirect( driver, btnMakeCopyRoot, btnSecondary );
		SMUtils.clickJS( driver, makeCopyBtn );
		Log.message( "Clicked Make A Copy Button" );
	}

	/**
	 * To Click Next button
	 */
	public void clickNextBtn() {
		SMUtils.waitForElement( driver, customNextBtnRoot, 5 );
		WebElement nextBtn = SMUtils.getWebElementDirect( driver, customNextBtnRoot, btnPrimary );
		SMUtils.waitForElement( driver, nextBtn );
		SMUtils.clickJS( driver, nextBtn );
		// Here we are using nap for page to load. Tried with the WebDriver waits but is fails in some cases.
		SMUtils.nap( 3 );
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Spinner loading not complete for clickNextBtn" );
		}
		Log.message( "Clicked Next Button" );
	}

	/**
	 * To Click Create button
	 */
	public void clickCreateBtn() {
		SMUtils.waitForElement( driver, createBtnRoot, 10 );
		WebElement createBtn = SMUtils.getWebElementDirect( driver, createBtnRoot, btnPrimary );
		SMUtils.clickJS( driver, createBtn );
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Please check logs for issue in clickCreateBtn" );
		}
		Log.message( "Clicked Create Button" );
	}

	/**
	 * To Click Cancel button
	 */
	public void clickCancelBtn() {
		SMUtils.waitForElement( driver, makeACopyDialogCancelButton, 5 );
		WebElement cancelBtn = SMUtils.getWebElementDirect( driver, makeACopyDialogCancelButton, btnSecondary );
		SMUtils.waitForElement( driver, cancelBtn );
		SMUtils.clickJS( driver, cancelBtn );
		// Here we are using nap for page to load. Tried with the WebDriver waits but is fails in some cases.
		SMUtils.nap( 3 );
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Spinner loading not complete for clickCancelBtn" );
		}
		Log.message( "Clicked Cancel Button" );
	}

	/**
	 * To create new course using Default Math
	 * 
	 * @param courseName
	 * @param courseType
	 * @throws Exception
	 */
	public void copyOfMathCourse( String courseName, String courseType, String courseNameToCopy ) throws Exception {
		clickCourseFromTheListing( courseNameToCopy );
		clickMakeCopyBtn();
		enterCourseName( courseName );
		coursesRadioBtn( courseType, courseNameToCopy );
		clickNextBtn();
		if ( getTheStatusOfTheSharedAtDistrictLevel( Constants.OFF_CAPS ).equals( Constants.OFF_CAPS ) ) {
			changeStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
		}
		getTheStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
		clickNextBtn();
		clickDefualtBtnOn();
		clickCreateBtn();
	}

	/**
	 * To create new course using focus Math
	 * 
	 * @param courseName
	 * @param courseType
	 * @throws Exception
	 */
	public void copyOfMathCourseFocus( String courseName, String courseType, String courseNameToCopy ) throws Exception {
		clickCourseName( courseNameToCopy );
		clickMakeCopyBtn();
		enterCourseName( courseName );
		coursesRadioBtn( courseType, courseNameToCopy );
		clickNextBtn();
		if ( getTheStatusOfTheSharedAtDistrictLevel( Constants.OFF_CAPS ).equals( Constants.OFF_CAPS ) ) {
			changeStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
		}
		getTheStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
		clickNextBtn();
		clickCreateBtn();
	}

	/**
	 * To enter course name
	 * 
	 * @param courseName
	 */
	public void enterCourseName( String courseName ) {
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Spinner not loaded for the first popup of custom course creation" );
		}
		SMUtils.waitForElement( driver, courseNameTextBox, 8 );
		courseNameTextBox.clear();
		courseNameTextBox.sendKeys( courseName );
		Log.message( courseName + " is entered." );
	}

	/**
	 * To Click course name
	 * 
	 * @param courseName
	 */
	public void clickCustomCourseName( String coursesName ) {
		for ( WebElement element : courseName ) {
			if ( element.getText().equals( coursesName ) ) {
				SMUtils.clickJS( driver, element );
				break;
			}
		}
		Log.message( "Clicked course: " + coursesName );
	}

	/**
	 * To Click course name
	 *
	 * @param courseName
	 * @throws Exception
	 */

	public void clickCourseName( String courseName ) throws Exception {
		SMUtils.nap( 3 );
		boolean isClicked = false;
		try {
			for ( WebElement eachCourse : listOfCourses ) {
				String courseNameFromUI = eachCourse.getText().trim();
				if ( courseNameFromUI.equals( courseName ) ) {
					SMUtils.clickJS( driver, eachCourse );
					SMUtils.waitForElement( driver, skillsDropdownRoot, 10 );
					Log.message( courseNameFromUI + " is clicked" );
					isClicked = true;
					break;
				}
			}
			if ( !isClicked ) {
				for ( WebElement eachCourse : listOfCoursesSafari ) {
					String courseNameFromUI = eachCourse.getText().trim();
					if ( courseNameFromUI.equals( courseName ) ) {
						SMUtils.clickJS( driver, eachCourse );
						SMUtils.waitForElement( driver, skillsDropdownRoot, 10 );
						Log.message( courseNameFromUI + " is clicked" );
						break;
					}
				}
			}
		} catch ( Exception e ) {
			Log.exception( e );
		}
	}

	/**
	 * To Click Skills radio button
	 */
	public void clickSkillsRadioBtn() {
		SMUtils.waitForElement( driver, customBySkills, 5 );
		SMUtils.clickJS( driver, customBySkills );
		Log.message( "Clicked Skills Radio Button" );
	}

	/**
	 * To Click Settings radio button
	 */
	public void clickSettingsRadioBtn() {

		SMUtils.waitForElement( driver, customBySettings, 5 );
		SMUtils.clickJS( driver, customBySettings );

		Log.message( "Clicked Settings Radio Button" );
	}

	/**
	 * Click Standards radio button
	 */
	public void clickStandardsRadioBtn() {
		SMUtils.waitForElement( driver, customByStandardsRadioBtn, 10 );
		SMUtils.clickJS( driver, customByStandardsRadioBtn );
		Log.message( "Clicked Standards Radio Button" );
	}

	/**
	 * Click Standards radio button for Focus Courses
	 */
	public void clickStandardsRadioBtnForFocusCourse() {
		SMUtils.waitForElement( driver, customByStandardsFocusRadioBtn, 5 );
		SMUtils.clickJS( driver, customByStandardsFocusRadioBtn );
		Log.message( "Clicked Standards Radio Button" );
	}

	/**
	 * To get Skills dropdown values
	 * 
	 */

	public List<WebElement> getSkillsDroppdownvalues() {
		SMUtils.waitForElement( driver, skillsDropdownRoot );
		WebElement dropDownRoot = SMUtils.getWebElementDirect( driver, skillsDropdownRoot, dropdownBtnParent );
		return SMUtils.getAllWebElements( driver, dropDownRoot, dropdownBtnChild );
	}

	/**
	 * To get Grade dropdown values
	 * 
	 * @return
	 */
	public List<WebElement> getGradeDroppdownvalues() {
		SMUtils.waitForElement( driver, gradeDropdownRoot );
		WebElement dropDownRoot = SMUtils.getWebElementDirect( driver, gradeDropdownRoot, dropdownBtnParent );
		return SMUtils.getAllWebElements( driver, dropDownRoot, dropdownBtnChild );
	}

	/**
	 * To get course names
	 * 
	 * @return
	 */
	public List<String> getCourseNameList() {
		List<String> courseNameList = new ArrayList<>();
		courseName.forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( courseNameList::add ) );
		return courseNameList;
	}

	/**
	 * This method verifies the sorting order based on the course names
	 * 
	 * @param courseList
	 * @param sortingOrder
	 * @return
	 */
	public List<String> sortTheList( List<String> courseList, String sortingOrder ) {

		switch ( sortingOrder ) {
		case Constants.CHECK_ASCENDING_ORDER:
			//Sorting in Ascending Order
			Collections.sort( courseList );
			break;

		case Constants.CHECK_DESCENDING_ORDER:
			//Sorting in Ascending Order
			Collections.sort( courseList, String.CASE_INSENSITIVE_ORDER.reversed() );
			break;

		default:
			Log.getLatestErrorDetails();
			break;

		}
		return courseList;
	}

	/**
	 * This method verifies the sorting order based on the date
	 * 
	 * @param dateList
	 * @param sortingOrderToCheck
	 * @return sortedCourseListDates
	 */
	public List<LocalDate> verifySortingOfCoursesBasedOnCourseDate( List<LocalDate> dateList, String sortingOrderToCheck ) {

		List<LocalDate> obtainedCourseListDates;
		List<LocalDate> sortedCourseListDates = new ArrayList<>();
		String sortingOrderUnderVerification = sortingOrderToCheck;

		//Unsorted List
		obtainedCourseListDates = dateList;
		for ( LocalDate dates : obtainedCourseListDates ) {
			sortedCourseListDates.add( dates );
		}

		switch ( sortingOrderUnderVerification ) {
		case Constants.CHECK_DATE_DESCENDING_ORDER:
			//Sorting in Descending Order
			Collections.sort( sortedCourseListDates, Collections.reverseOrder() );
			break;

		case Constants.CHECK_DATE_ASCENDING_ORDER:
			//Sorting in Ascending Order
			Collections.sort( sortedCourseListDates );
			break;

		default:
			Log.getLatestErrorDetails();
			break;
		}
		return sortedCourseListDates;
	}

	//TODO - Null check required. Will do it in upcoming PR for the next story.
	/**
	 * This method converts the date String to LocalDate. The Locale used is of
	 * US.
	 * 
	 * @param unsortedDateList
	 * @return dateListInEnglishLocale
	 */
	public List<LocalDate> convertCourseDateToDesiredLocalDate( List<String> unsortedDateList ) {

		DateTimeFormatterBuilder builder = new DateTimeFormatterBuilder().parseCaseInsensitive().parseLenient().appendPattern( "[MMM dd, yyyy]" ).appendPattern( "[MMM d, yyyy]" );
		List<LocalDate> dateListInEnglishLocale = new ArrayList<>();
		DateTimeFormatter formatterForEnglishLocal = builder.toFormatter( Locale.ENGLISH );
		for ( String date : unsortedDateList ) {
			try {
				LocalDate dateInEnglishLocale = LocalDate.parse( date, formatterForEnglishLocal );
				dateListInEnglishLocale.add( dateInEnglishLocale );
			} catch ( DateTimeParseException e ) {
				Log.fail( "Date format is not as expected" );
			}
		}
		return dateListInEnglishLocale;
	}

	//TODO - Need to do null check. Will do it in the next story PR
	/**
	 * This method returns the courses label List
	 *
	 * @return courseList
	 */
	public List<String> getCourseTypesFromCoursesWidget() {
		List<String> courseList = new ArrayList<>();
		for ( WebElement courseParent : courseTitleParentElement ) {
			courseList.add( SMUtils.getTextOfWebElement( courseParent, driver ) );
		}
		return courseList;
	}

	/**
	 * This method compares a single word with all the words in array
	 * 
	 * @param courseList
	 * @param courseName
	 * @return boolean
	 */
	public boolean compareNameWithList( List<String> courseList, String courseName ) {

		return courseList.stream().allMatch( s -> s.equals( courseName ) );
	}

	//TODO - Need to do null check. Will do it in the next story PR
	/**
	 * This method returns the course dates
	 * 
	 * @return
	 */
	public List<String> getCourseAssignedDateFromCoursesWidget() {
		ArrayList<String> courseAssignedDate = new ArrayList<>();
		courseTitleParentElement.forEach(
				element -> Optional.ofNullable( SMUtils.getTextOfWebElement( SMUtils.getChildWebElementFromParent( element, coursDateCSS ), driver ) ).ifPresent( elementText -> courseAssignedDate.add( elementText.replaceAll( "^(.*?)on\\s", "" ) ) ) );
		return courseAssignedDate;
	}

	/**
	 * To verify Initial Placement is ON
	 */
	public void verifyInitialPlacementIsON() {
		SMUtils.waitForElement( driver, initialPlacementBtnON );
		if ( SMUtils.isElementPresent( initialPlacementBtnON ) ) {
			Log.message( "Initial Placement is in On as excepted" );
		} else {
			Log.fail( "Initial Placement is in OFF/NoSuchElementException" );
		}
	}

	/**
	 * To verify Initial Placement is OFF
	 */
	public void verifyInitialPlacementIsOff() {
		SMUtils.waitForElement( driver, initialPlacementBtnOFF );
		if ( SMUtils.isElementPresent( initialPlacementBtnOFF ) ) {
			Log.message( "Initial Placement is in OFF as excepted" );
		} else {
			Log.fail( "Initial Placement is in ON/NoSuchElementException" );
		}
	}

	/**
	 * To turn OFF Initial Placement
	 */
	public void turnOffInitialPlacement() {
		SMUtils.waitForElement( driver, initialPlacementBtnON, 10 );
		if ( SMUtils.isElementPresent( initialPlacementBtnON ) ) {
			SMUtils.clickJS( driver, initialPlacementBtnON );
			Log.message( "InitialPlacement is turned OFF" );
		} else {
			Log.fail( "NoSuchElementException" );
		}
	}

	/**
	 * To turn ON Initial Placement
	 */
	public void turnONInitialPlacement() {
		SMUtils.waitForElement( driver, initialPlacementBtnOFF, 3 );
		if ( SMUtils.isElementPresent( initialPlacementBtnOFF ) ) {
			SMUtils.clickJS( driver, initialPlacementBtnOFF );
			Log.message( "InitialPlacement is turned ON" );
		} else {
			Log.fail( "NoSuchElementException" );
		}
	}

	/**
	 * To verify Initial Placement status
	 * 
	 * @return
	 */
	public String verifyInitialPlacementStatus() {
		SMUtils.waitForElement( driver, IPStatus );
		String IPstatus = IPStatus.getText();
		Log.message( "Initial Placement Status is " + IPstatus );
		return IPstatus;
	}

	/**
	 * To verify Initial placement is ON
	 */

	public void verifyManuallySetCourselevelIsOFF() {
		SMUtils.waitForElement( driver, courseLevelBtnOFF );
		if ( SMUtils.isElementPresent( courseLevelBtnOFF ) ) {
			Log.message( "Manually Set Courselevel is OFF as excepted" );
		} else {
			Log.fail( "Manually Set Courselevel Is ON/NoSuchElementException" );
		}
	}

	/**
	 * To verify Manually Set Course level is ON
	 */
	public void verifyManuallySetCourselevelIsON() {
		SMUtils.waitForElement( driver, courseLevelBtnON );
		if ( SMUtils.isElementPresent( courseLevelBtnON ) ) {
			Log.message( "Manually Set Courselevel Is ON" );
		} else {
			Log.fail( "Manually Set Courselevel Is OFF/NoSuchElementException" );
		}
	}

	/**
	 * To turn ON Manually Set Course level
	 */
	public void turnOnManuallySetCourseLevel() {
		SMUtils.waitForElement( driver, courseLevelBtnOFF );
		if ( SMUtils.isElementPresent( courseLevelBtnOFF ) ) {
			SMUtils.clickJS( driver, courseLevelBtnOFF );
			Log.message( "Manually Set CourseLevel is turned ON" );
		} else {
			Log.fail( "No SuchElementException" );
		}
	}

	/**
	 * To verify Speed Games is ON
	 */
	public void verifySpeedGamesIsON() {
		SMUtils.waitForElement( driver, speedGamesBtnON );
		if ( SMUtils.isElementPresent( speedGamesBtnON ) ) {
			Log.message( "Speed Games is on by default" );
		} else {
			Log.fail( "SpeedGames is OFF/NoSuchElementException" );
		}
	}

	/**
	 * To verify Speed Games is OFF
	 */
	public void verifySpeedGamesIsOFF() {
		SMUtils.waitForElement( driver, speedGamesBtnOFF );
		if ( SMUtils.isElementPresent( speedGamesBtnOFF ) ) {
			Log.message( "Speed Games is ON" );
		} else {
			Log.fail( "Speed Games is OFF/NoSuchElementException" );
		}
	}

	/**
	 * To turn OFF Speed Games
	 */
	public void turnOffSpeedGames() {
		if ( SMUtils.waitForElement( driver, speedGamesBtnON ) ) {
			SMUtils.clickJS( driver, speedGamesBtnON );
			Log.message( "SpeedGames is turned OFF" );
		} else {
			Log.fail( "No Such ElementException" );
		}
	}

	/**
	 * To Turn on Calculator
	 */
	public void turnONCalculator() {
		SMUtils.waitForElement( driver, calculatorBtnOFF );
		if ( SMUtils.isElementPresent( calculatorBtnOFF ) ) {
			SMUtils.clickJS( driver, calculatorBtnOFF );
			Log.message( "Calculator is on by default" );
		} else {
			Log.fail( "calculatorBtnOFF is OFF/NoSuchElementException" );
		}
	}

	/**
	 * To verify Calculator is ON
	 */
	public boolean verifyCalculatorIsON() {
		if ( SMUtils.waitForElement( driver, calculatorBtnON ) ) {
			Log.message( "Calculator is on." );
		} else {
			Log.message( "Calculator is off." );
		}
		return SMUtils.isElementPresent( calculatorBtnON );
	}

	/**
	 * To Turn on Translate
	 */
	public void turnONTranslate() {
		SMUtils.waitForElement( driver, translateBtnOFF );
		if ( SMUtils.isElementPresent( translateBtnOFF ) ) {
			SMUtils.clickJS( driver, translateBtnOFF );
			Log.message( "Translate is on by default" );
		} else {
			Log.fail( "Translate is OFF/NoSuchElementException" );
		}
	}

	/**
	 * To verify Translate is ON
	 */
	public boolean verifyTranslateIsON() {
		if ( SMUtils.waitForElement( driver, translateBtnON ) ) {
			Log.message( "Translate is on" );
		} else {
			Log.message( "Translate is off." );
		}
		return SMUtils.isElementPresent( translateBtnON );
	}

	/**
	 * To Turn on shared at district level
	 */
	public void turnONSharedAtDistrictLevel() {
		SMUtils.waitForElement( driver, shareDistrictLevelBtnOFF );
		if ( SMUtils.isElementPresent( shareDistrictLevelBtnOFF ) ) {
			SMUtils.clickJS( driver, shareDistrictLevelBtnOFF );
			Log.message( "shared at district level is on by default" );
		} else {
			Log.fail( "shared at district level is OFF/NoSuchElementException" );
		}
	}

	/**
	 * To verify shared at district level is ON
	 */
	public boolean verifySharedAtDistrictLevelIsON() {
		if ( SMUtils.waitForElement( driver, shareDistrictLevelBtnON ) ) {
			Log.message( "shared at district level is ON" );
		} else {
			Log.message( "shared at district level is Off." );
		}
		return SMUtils.isElementPresent( shareDistrictLevelBtnON );
	}

	/**
	 * Click Strand toggle button for Skill
	 */
	public void clickStrandToggleBtnForSkill() {
		SMUtils.waitForElement( driver, strandToggleBtnForSkillCourse );
		SMUtils.clickJS( driver, strandToggleBtnForSkillCourse );
		Log.message( "First Strand Is Selected" );
	}

	/**
	 * To verify Speed Games is OFF
	 */
	public boolean verifySpeedGamesIsOff() {
		if ( SMUtils.waitForElement( driver, speedGamesBtnOFF ) ) {
			Log.message( "speed Games is off" );
		} else {
			Log.message( "speed Games is on" );
		}
		return SMUtils.isElementPresent( speedGamesBtnOFF );
	}

	/**
	 * To verify Speed Games is OFF at studentLevel
	 */
	public boolean verifySpeedGamesIsOffAtStudentLevel() {
		if ( SMUtils.waitForElement( driver, speedGamesBtnOFFInViewStudentSettings ) ) {
			Log.message( "speed Games is off" );
		} else {
			Log.message( "speed Games is on" );
		}
		return SMUtils.isElementPresent( speedGamesBtnOFFInViewStudentSettings );
	}

	/**
	 * To generate group name return RandomStringUtils
	 */
	public String generteGroupName() {
		String courseName = RandomStringUtils.randomAlphabetic( 12 );
		return RandomStringUtils.randomAlphabetic( 12 );
	}

	/**
	 * To verify Course is created
	 * 
	 * @param courseName
	 * @return
	 */
	public Boolean verifyCoursecreated( String courseName ) {
		SMUtils.nap( 10 ); // wait for page to refresh\
		Boolean status = false;
		WebElement courseVerification = null;
		String customlyCreatedCourse = null;
		browser = configProperty.getProperty( "BrowserPlatformToRun" );
		Log.message( "browser: " + browser );
		if ( browser.toLowerCase().contains( "safari" ) ) {
			courseVerification = driver.findElement( By.xpath( "(//span[contains(text(),'" + courseName + "')])[1]" ) );
			customlyCreatedCourse = courseVerification.getText().trim();
		} else {

			String xpath = "(//span[contains(text(),'" + courseName + "')])[1]";
			customlyCreatedCourse = driver.findElement( By.xpath( xpath ) ).getText().trim();
		}
		Log.message( "From UI: " + customlyCreatedCourse );
		Log.message( "From Automation: " + courseName );
		if ( customlyCreatedCourse.equals( courseName ) ) {
			Log.message( "Course Created Successfully" );
			status = true;
		}
		return status;
	}

	/**
	 * To click Save button
	 */
	public void clickSaveBtn() {
		SMUtils.waitForElement( driver, btnSaveRoot, 5 );
		WebElement saveBtn = SMUtils.getWebElementDirect( driver, btnSaveRoot, btnPrimary );
		SMUtils.clickJS( driver, saveBtn );
		// Here we are using nap for page to load. Tried with the WebDriver waits but is fails in some cases.
		SMUtils.nap( 3 );
		Log.message( "Clicked Save Button" );
	}

	/**
	 * To verify Left Strands is displayed for Math Courses
	 */
	public void verifyLeftStrandsDisplayedForMathCourses() {
		//Here we are using nap for page to load. Tried with the WebDriver waits but is fails in some cases.
		SMUtils.nap( 3 );
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Please check logs for issue in verifyLeftStrandsDisplayedForMathCourses" );
		}
		if ( CollectionUtils.isNotEmpty( leftStrandMathCourses ) ) {
			Log.message( "LeftSide StrandCourses are available" );
		} else {
			Log.fail( "LeftSide StrandCourses are not available" );
		}
	}

	/**
	 * To click Save button
	 */
	public void clickSaveBtnForEdit() {
		SMUtils.waitForElement( driver, btnSaveRoot, 5 );
		WebElement saveBtn = SMUtils.getWebElement( driver, saveButton, btnPrimary );
		SMUtils.clickJS( driver, saveBtn );
		Log.message( "Clicked Save Button" );
	}

	/**
	 * To verify middle Hierarchy is displayed for Math Courses
	 */
	public void verifyMiddleHierarchyDisplayedForMathCourses() {
		SMUtils.waitForElement( driver, settingsTextForMathCourses );
		if ( SMUtils.isElementPresent( middleHierarchyForMathCourses ) ) {
			Log.message( "Middle Hierarchy For Math Courses is Visible" );
		} else {
			Log.fail( "Middle Hierarchy For MathCourses is not Visible" );
		}
	}

	/**
	 * To verify Settings is displayed for Math Courses
	 */
	public void verifySettingsDisplayedForMathCourses() {
		SMUtils.waitForElement( driver, settingsTextForMathCourses );
		if ( SMUtils.isElementPresent( settingsTextForMathCourses ) ) {
			Log.message( "In Right Side panel Settings is Visible" );
		} else {
			Log.fail( "In Right Side panel Settings is not Visible" );
		}
	}

	/**
	 * To click Grade drop down
	 */
	public void clickGradeDropDown() {
		WebElement dropDownRoot = SMUtils.getWebElementDirect( driver, gradeDropdownRoot, clickDropdownBtnParent );
		WebElement clickGradeDropDown = SMUtils.getWebElementDirect( driver, dropDownRoot, clickDropdownBtnChild );
		SMUtils.clickJS( driver, clickGradeDropDown );
	}

	/**
	 * To click Skills drop down
	 */
	public void clickSkillsDropDown() {
		WebElement dropDownRoot = SMUtils.getWebElementDirect( driver, skillsDropdownRoot, clickDropdownBtnParent );
		WebElement clickSkillsDropDown = SMUtils.getWebElementDirect( driver, dropDownRoot, clickDropdownBtnChild );
		SMUtils.clickJS( driver, clickSkillsDropDown );
	}

	/**
	 * To get default first Strand value before clicking
	 * 
	 * @return
	 */
	public String getDefaultFirstStrandValueBeforeClicking() {
		SMUtils.waitForElement( driver, leftPanelFirstCourseStrand );

		return leftPanelFirstCourseStrand.getText();
	}

	//TODO - Update this method so that its not a duplicate of getDefaultFirstStrandValueBeforeClicking()
	/**
	 * To get first strand value after clicking
	 * 
	 * @return
	 */
	public String getFirstStrandValueAfterClicking() {
		SMUtils.nap( 5 );
		SMUtils.waitForElement( driver, leftPanelFirstCourseStrand );

		return leftPanelFirstCourseStrand.getText();
	}

	//TODO - Comment from Reviewer : Use IntStream.range
	/**
	 * To select Grades drop down value
	 * 
	 * @throws Exception
	 */
	public void selectGradeDropDownvalue() throws Exception {
		try {
			SMUtils.waitForElement( driver, gradeDropdownRoot );
			for ( int i = 0; i < getGradeDroppdownvalues().size(); i++ ) {
				if ( i == 4 ) {
					getGradeDroppdownvalues().get( i ).click();
					break;
				}
			}
		} catch ( Exception e ) {
			Log.exception( e, driver );
		}

	}

	//TODO - Comment from Reviewer : Use IntStream.range
	/**
	 * To select Skills dropDown value
	 * 
	 * @throws Exception
	 */
	public void selectSkillsDropDownvalue() throws Exception {
		try {
			SMUtils.waitForElement( driver, skillsDropdownRoot );
			clickSkillsDropDown();
			for ( int i = 0; i < getSkillsDroppdownvalues().size(); i++ ) {
				if ( i == 2 ) {
					getSkillsDroppdownvalues().get( i ).click();
					break;
				}
			}
		} catch ( Exception e ) {
			Log.exception( e, driver );
		}
	}

	/**
	 * To get Edit button
	 * 
	 * @return
	 */
	public WebElement getEditBtn() {
		SMUtils.waitForElement( driver, editBtnRoot, 5 );
		return SMUtils.getWebElementDirect( driver, editBtnRoot, btnSecondary );
	}

	/**
	 * To click Edit button
	 */
	public void clickEditBtn() {
		WebElement clickEditSettingBtn = SMUtils.getWebElement( driver, editBtnRoot, btnSecondary );
		SMUtils.waitForElementToBeClickable( clickEditSettingBtn, driver );
		SMUtils.clickJS( driver, clickEditSettingBtn );
		Log.message( "Edit button is clicked" );
	}

	/**
	 * To click Edit button
	 */
	public boolean isEditBtnDisplayed() {
		return editBtnRoot.isDisplayed();
	}

	/**
	 * To click Edit button on course level
	 */
	public void clickEditBtnCourseLevel() {
		SMUtils.waitForElement( driver, topEditButton );
		WebElement actualEditbutton = SMUtils.getWebElement( driver, topEditButton, childeditbutton );
		SMUtils.clickJS( driver, actualEditbutton );
		SMUtils.nap( 3 );
		Log.message( "Edit button is clicked on course level" );
	}

	/**
	 * To get Remove button
	 * 
	 * @return
	 */
	public WebElement getRemoveBtn() {
		SMUtils.waitForElement( driver, removeCourseBtnRoot, 5 );
		return SMUtils.getWebElementDirect( driver, removeCourseBtnRoot, btnSecondary );
	}

	/**
	 * To verify Edit and Remove button is present
	 */
	public void verifyEditAndRemoveBtnPresent() {

		if ( SMUtils.isElementPresent( getEditBtn() ) ) {
			Log.message( "Edit Button is Present" );
		} else {
			Log.fail( "Edit Button is not Present" );
		}
		if ( SMUtils.isElementPresent( getRemoveBtn() ) ) {
			Log.message( "Remove Button is Present" );
		} else {
			Log.fail( "Remove Button is not Present" );
		}
	}

	/**
	 * To verify Edit and Remove button is not present
	 */
	public void verifyEditAndRemoveBtnNotPresent() {
		try {
			if ( Boolean.FALSE.equals( SMUtils.isElementPresent( getEditBtn() ) ) ) {
				Log.message( "Edit Button is not Present" );
			} else {
				Log.fail( "Edit Button is Present" );
			}
		} catch ( Exception NoSuchElementException ) {
			Log.pass( "Edit Button is not Present" );
		}
		try {
			if ( Boolean.FALSE.equals( SMUtils.isElementPresent( getRemoveBtn() ) ) ) {
				Log.message( "Remove Button is not Present" );
			} else {
				Log.fail( "Remove Button is Present" );
			}
		} catch ( Exception NoSuchElementException ) {
			Log.pass( "Remove Button is not Present" );
		}

	}

	/**
	 * To remove the Course
	 *
	 * @throws Exception
	 */
	public void removeCourse() throws Exception {
		try {
			WebElement removeBtnFirst = getRemoveBtn();
			SMUtils.clickJS( driver, removeBtnFirst );
			SMUtils.waitForSpinnertoDisapper( driver );
			SMUtils.waitForElement( driver, removeCourseDialogBoxRemoveBtnRoot, 8 );
			WebElement removeBtnMain = SMUtils.getWebElementDirect( driver, removeCourseDialogBoxRemoveBtnRoot, btnPrimary );
			SMUtils.checkBackgroundColor( removeBtnMain, Constants.BUTTON_COLOR_CODE );
			Log.event( "Verified the remove button color code" );
			SMUtils.clickJS( driver, removeBtnMain );
			SMUtils.waitForSpinnertoDisapper( driver );
			Log.message( "Remove Button is Clicked" );
		} catch ( Exception e ) {
			Log.message( "Some issue occured. Please check!!" );
		}

	}

	/**
	 * To verify Course is removed successfully
	 * 
	 * @param customCourseName
	 */

	public boolean verifyCourseRemovedSuccessfully( String customCourseName ) {
		SMUtils.nap( 5 );
		JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) driver;
		//Used JS Executor to reduce the overall time of execution
		String js = "function getCourseList() { var finalCourseList = []; var courseList = document.querySelectorAll('span.tile__title'); courseList.forEach(el => { if (typeof(el) !== \"undefined\") { if (el !== null) { finalCourseList.push(el.innerText.trim()); } } }); return finalCourseList; };return getCourseList();";
		String jsResponse = javaScriptExecutor.executeScript( js ).toString();
		return jsResponse.contains( customCourseName );
	}

	/**
	 * To click Assign button
	 * 
	 * @throws InterruptedException
	 */
	public void clickAssignBtn() throws InterruptedException {
		SMUtils.waitForSpinnertoDisapper( driver );
		SMUtils.waitForElement( driver, assignBtnRoot, 5 );
		WebElement assignBtn = SMUtils.getWebElementDirect( driver, assignBtnRoot, btnPrimary );
		SMUtils.waitForElement( driver, assignBtn, 5 );
		SMUtils.clickJS( driver, assignBtn );
		clickMSDAPopup();
		SMUtils.waitForElement( driver, cancelBtnRoot, 5 );
		Log.message( "Assign Button is Clicked" );
	}

	/**
	 * To add Course to groups
	 */
	public void addCourseToGroups() {
		SMUtils.waitForElement( driver, groupsradioBtn );
		SMUtils.clickJS( driver, groupsradioBtn );
		SMUtils.waitForElement( driver, addBtnRoot );
		List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );
		IntStream.range( 0, addBtns.size() ).forEach( element -> {
			WebElement addBtn = SMUtils.getWebElementDirect( driver, addBtns.get( element ), btnSecondary );
			SMUtils.clickJS( driver, addBtn );
		} );
		WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignBtnRoot, btnPrimary );
		SMUtils.clickJS( driver, assignPopUpBtn );
		Log.message( "Course added to Groups" );
	}

	/**
	 * To add Course to students
	 */
	public void addCourseToStudents() {
		SMUtils.waitForElement( driver, studentRadioButton );
		SMUtils.clickJS( driver, studentRadioButton );
		SMUtils.waitForElement( driver, addBtnRoot );
		List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );
		addBtns.forEach( element -> {
			WebElement addBtn = SMUtils.getWebElementDirect( driver, element, btnSecondary );
			SMUtils.clickJS( driver, addBtn );
		} );
		WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignBtnRoot, btnPrimary );
		SMUtils.waitForElement( driver, assignPopUpBtn );
		SMUtils.clickJS( driver, assignPopUpBtn );
		SMUtils.waitForElement( driver, assignBtnRoot );
		Log.message( "Course added to Students" );
	}

	/**
	 * To click Assignments Sub Menu
	 */

	public void clickAssignmentSubMenu() {
		SMUtils.waitForElement( driver, assignmentsubMenuGrandRoot );
		WebElement assignmentSubMenuParent = SMUtils.getWebElement( driver, assignmentsubMenuGrandRoot, assignmentssubMenuParent );
		WebElement assignmentSubMenu = SMUtils.getWebElement( driver, assignmentSubMenuParent, assignmentsubMenuChild );
		SMUtils.clickJS( driver, assignmentSubMenu );
		Log.message( "Clicked Assignments sub menu" );
	}

	/**
	 * To click View Assignment button
	 * 
	 * @param courseName
	 */
	public void clickViewAssignment( String courseName ) {
		SMUtils.nap( 3 );
		WebElement viewBtnRoot = driver.findElement( By.xpath( "(//span[text()=' " + courseName + " ']/parent::td/following::cel-button)[1]" ) );
		WebElement viewAssignmentBtn = SMUtils.getWebElementDirect( driver, viewBtnRoot, btnSecondary );
		SMUtils.clickJS( driver, viewAssignmentBtn );

	}

	/**
	 * To click View Assignment button using CSS selector
	 * 
	 * @param assignmentName
	 */
	public void clickViewAssignments( String assignmentName ) {
		Log.message( "Assignement name is " + assignmentName );
		//Here we are using nap for stability in Safari browser.
		SMUtils.nap( 8 );
		WebElement assignmentNameToClick = driver.findElement( By.cssSelector( ".list-assignment tr span[title='" + assignmentName + "']" ) );
		SMUtils.waitForElement( driver, assignmentNameToClick, 8 );
		SMUtils.clickJS( driver, assignmentNameToClick );
		SMUtils.clickJS( driver, assignmentNameToClick );
		SMUtils.nap( 10 );
	}

	/**
	 * To get Student list from Assignment details table
	 * 
	 * @return
	 */
	public List<String> getStudentListfromAssignementDetailsTable() {
		//This nap is required for the student list to load
		SMUtils.nap( 5 );
		List<String> assignementDetailsTableStudentList = new ArrayList<>();
		studentNameListForAssignment.stream().forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( assignementDetailsTableStudentList::add ) );
		Collections.sort( assignementDetailsTableStudentList );
		assignementDetailsTableStudentList.stream().forEach( studentName -> Log.message( "Student in assigned the assignment " + studentName ) );
		return assignementDetailsTableStudentList;
	}

	/**
	 * To get Assignment list from Assignment details table
	 * 
	 * @return
	 */
	public List<String> getAssignementListfromAssignementDetailsTable() {
		SMUtils.nap( 3 );
		List<String> assignementDetailsTableAssignmentList = new ArrayList<>();
		List<WebElement> studentsListInsideAssignment = driver.findElements( By.cssSelector( "div.table-container>table>tbody>tr" ) );
		IntStream.rangeClosed( 1, studentsListInsideAssignment.size() ).forEach(
				element -> assignementDetailsTableAssignmentList.add( driver.findElement( By.cssSelector( "div.table-container>table>tbody>tr:nth-of-type(" + element + ") >td:nth-of-type(1)>div>span:nth-of-type(1)" ) ).getText() ) );
		Collections.sort( assignementDetailsTableAssignmentList );
		return assignementDetailsTableAssignmentList;
	}

	/**
	 * To get all Student name from Assign pop-Up
	 * 
	 * @return
	 */
	public List<String> getAllStudentNameFromAssignPopUp() {
		SMUtils.waitForElement( driver, studentRadioButton, 6 );
		SMUtils.clickJS( driver, studentRadioButton );
		List<String> studentLists = new ArrayList<>();
		studentList.forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( studentLists::add ) );
		Collections.sort( studentLists );
		return studentLists;
	}

	/**
	 * To Create Custom by setting math and Reading course with IP off
	 * 
	 * @return
	 */

	public String createCustomBySettingCourseWithIPOff( String CourseName, String subject ) {
		if ( subject.equals( "Math" ) ) {
			clickMathCourse();
		} else {
			clickReadingCourse();
		}

		clickMakeCopyBtn();
		enterCourseName( CourseName );
		clickSettingsRadioBtn();
		clickNextBtn();
		// Turn OFF Initial placement
		turnOffInitialPlacement();
		// Verify Manually set course level is OFF by default
		verifyManuallySetCourselevelIsOFF();
		turnOnManuallySetCourseLevel();
		// Set course level to 1.75
		moveSliderTo( Constants.COURSELEVEL_1_75 );
		clickCreateBtn();
		Log.message( "Course created successfully" );
		return CourseName;
	}

	/**
	 * To click Ellipsis icon
	 * 
	 */

	public void clickEllipsisIcon() {
		SMUtils.waitForElement( driver, viewAssignedEllipsisSymbol, 5 );
		WebElement assignmentSubMenuParent = SMUtils.getWebElement( driver, viewAssignedEllipsisSymbol, viewAssignedEllipsisMenuParent );
		WebElement assignmentSubMenu = SMUtils.getWebElement( driver, assignmentSubMenuParent, viewAssignedEllipsisMenuChild );
		SMUtils.waitForElement( driver, assignmentSubMenu );
		SMUtils.clickJS( driver, assignmentSubMenu );
	}

	/**
	 * To click View Assigned By button
	 */

	public void clickViewAssignedByButton() {
		SMUtils.waitForElement( driver, viewAssignedEllipsisSymbol );
		WebElement assignmentSubMenuParent = SMUtils.getWebElement( driver, viewAssignedEllipsisSymbol, viewAssignedEllipsisMenuParent );
		WebElement assignmentSubMenu = SMUtils.getWebElement( driver, assignmentSubMenuParent, viewAssignedEllipsisMenuChild );
		SMUtils.waitForElement( driver, assignmentSubMenu );
		SMUtils.clickJS( driver, assignmentSubMenu );
	}

	/**
	 * To click Ok button of View Assigned By pop up
	 */

	public void clickViewAssignedByPopupOkBtn() {
		SMUtils.waitForElement( driver, assignedByPopupDialog, 5 );

		// Please note that the common methods within the SMUtils were not able to scroll the pop window down hence went with the JavaSript executor here.
		JavascriptExecutor js = (JavascriptExecutor) driver;

		// Scroll inside web element vertically (e.g. 100 pixel)
		js.executeScript( "arguments[0].scrollTop = arguments[1];", assignedByPopupDialog, 100 );

		WebElement viewAssignedByOkBtn = SMUtils.getWebElement( driver, parentElementViewAssignedByOkBtn, viewAssignedByOkButton );
		//Work around to click OK button
		SMUtils.clickJS( driver, viewAssignedByOkBtn );
		SMUtils.clickJS( driver, viewAssignedByOkBtn );
	}

	/**
	 * To click close button of View Assigned By pop up
	 */

	public void clickViewAssignedByPopupCloseBtn() {
		SMUtils.waitForElement( driver, parentElementViewAssignedByOkBtn );
		WebElement viewAssignedByOkBtn = SMUtils.getWebElement( driver, parentElementViewAssignedByOkBtn, viewAssignedByOkButton );
		//Work around to click OK button
		SMUtils.clickJS( driver, viewAssignedByOkBtn );
		SMUtils.clickJS( driver, viewAssignedByOkBtn );
	}

	/**
	 * To Click course name
	 *
	 */
	public void clickOnCourseNameFromList( String courseNameToClick ) {
		//This nap is required for Safari execution
		SMUtils.nap( 5 );
		try {
			courseName.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( filteredValues -> {
				String[] courseNames = filteredValues.split( "(?<=\\G.{" + courseNameToClick.trim().length() + "})" );
				if ( courseNames[0].equalsIgnoreCase( courseNameToClick ) ) {
					SMUtils.waitForElement( driver, element, 5 );
					SMUtils.clickJS( driver, element );
				}
			} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected" );
		}
	}

	/**
	 * To Click course name - New
	 *
	 */
	public void clickFromCourseListingPage( String courseNameToClick ) {
		//This nap is required for Safari execution
		SMUtils.nap( 5 );
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
			Optional<WebElement> courseNameToBeClicked = courseName.stream().filter( element -> Boolean.TRUE.equals( splitAndCompareName( SMUtils.getTextOfWebElement( element, driver ), courseNameToClick ) ) ).findFirst();
			courseNameToBeClicked.ifPresent( elementToBeClicked -> SMUtils.clickJS( driver, elementToBeClicked ) );
			Log.message( "courseNameToClick: " + courseNameToClick );
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected" );
		}
	}

	/**
	 * Split the name and compare
	 *
	 */
	public boolean splitAndCompareName( String courseNameFetched, String courseNameToClick ) {
		String[] courseNames = courseNameFetched.split( "(?<=\\G.{" + courseNameToClick.trim().length() + "})" );
		return courseNames[0].equalsIgnoreCase( courseNameToClick );
	}

	/**
	 * To Click assignment name
	 *
	 */
	//TODO - Check null safe before the next story PR
	public void clickOnAssignmentNameFromList( String courseNameToClick ) {
		IntStream.rangeClosed( 1, toolTipCourseName.size() ).forEach( element -> {
			if ( toolTipCourseName.get( element ).getText().equals( courseNameToClick ) ) {
				toolTipCourseName.get( element ).click();
				SMUtils.waitForElement( driver, skillsDropdownRoot );
			}
		} );
	}

	/**
	 * Get Teacher name from the Assigned By pop up
	 * 
	 * @return
	 */

	public List<String> getTeacherListFromViewAssignedByPopup() {
		List<String> teacherNamesList = new ArrayList<>();
		List<String> teachersName = new ArrayList<>();
		SMUtils.waitForElement( driver, viewAssignedByPopupTitle, 10 );
		//TODO - Here we are using nth-of-type. Tried with some other options but this is a stable one.
		By byNameColumn = By.cssSelector( commonViewAssignedByPopup );
		List<WebElement> teacherName = driver.findElements( byNameColumn );
		Log.message( "Size of Teachers list is " + teacherName.size() );
		teacherName.stream().forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( teacherNamesList::add ) );
		teacherNamesList.stream().distinct().forEach( teachersName::add );
		return teachersName;
	}

	/**
	 * To verify whether the Assigned By pop up title is bold & Left aligned as
	 * expected
	 * 
	 * @return boolean
	 */
	public boolean isViewAssignedByPopupTitleBoldAndLeftAligned() {
		Log.message( "CSS properties of title for Assigned By pop up validated" );
		return SMUtils.verifyCssPropertyForElement( viewAssignedByPopupTitle, Constants.FONT_FAMILY, Constants.POPPINS_SEMI_BOLD ) && SMUtils.verifyCssPropertyForElement( viewAssignedByPopupTitle, Constants.TEXT_ALIGN, Constants.LEFT );
	}

	/**
	 * To verify whether the help icon is having the expected CSS properties
	 * 
	 * @return boolean
	 */
	public boolean isHelpIconHavingExpectedCssProperty() {
		WebElement isHelpIcon = SMUtils.getWebElementDirect( driver, helpIconSubContainer, dropDownIconBtn );
		String helpIconSvg = isHelpIcon.getAttribute( "src" );
		Log.message( "Help icon CSS properties validated" );
		return SMUtils.verifyCssPropertyForElement( isHelpIcon, Constants.HEIGHT, "14px" ) && SMUtils.verifyCssPropertyForElement( isHelpIcon, Constants.WIDTH, "14px" ) && helpIconSvg.contains( "question-circle.svg" );
	}

	/**
	 * To verify whether the 'Name' & 'Course Last Assigned' column are in the
	 * same row and bold
	 * 
	 * @return boolean
	 */
	public boolean isHeaderAndIndividualRowHavingExpectedCssProperty() {
		Log.message( "CSS properties of 'Name' & 'Course Last Assigned' column of 'View Assigned By popup' validated" );
		return SMUtils.verifyCssPropertyForElement( viewAssignedByTableRowHeader, Constants.DISPLAY, "table-row" ) && SMUtils.verifyCssPropertyForElement( viewAssignedByTableRowHeaderTitle, Constants.FONT_FAMILY, Constants.POPPINS_SEMI_BOLD )
				&& SMUtils.verifyCssPropertyForElement( viewAssignedByTableCell, Constants.DISPLAY, "table-cell" );
	}

	/**
	 * To verify whether the horizontal line is present between the names
	 * 
	 * @return boolean
	 */

	public boolean isHorizonalLinePresent( String browser ) {
		Log.message( "Presence of horizantal line in 'View Assigned By' popup validated" );
		Log.message( "Border bottom color is " + viewAssignedByPopupTableRow.getCssValue( "border-bottom-color" ) );
		Boolean isHorizonalLinePresent;
		if ( browser.toLowerCase().contains( "safari" ) ) {
			isHorizonalLinePresent = viewAssignedByPopupTableRow.getCssValue( "border-bottom-color" ).equalsIgnoreCase( Constants.GREY_COLOR_MAC )
					&& viewAssignedByPopupTableRow.getCssValue( "border-top-color" ).equalsIgnoreCase( Constants.GREY_COLOR_MAC );
		} else {
			isHorizonalLinePresent = viewAssignedByPopupTableRow.getCssValue( "border-bottom-color" ).equalsIgnoreCase( Constants.GREY_COLOR ) && viewAssignedByPopupTableRow.getCssValue( "border-top-color" ).equalsIgnoreCase( Constants.GREY_COLOR );
		}
		return isHorizonalLinePresent;
	}

	/**
	 * To verify if the ellipsis shows grey color
	 * 
	 * @param browser
	 * 
	 * @return
	 */
	public boolean verifyTheHoveredColorOfEllipsis( String browser ) {
		WebElement ellipsisButton = SMUtils.getWebElementDirect( driver, viewAssignedByHostButton, ".buttonmenu" );
		SMUtils.waitForElement( driver, ellipsisButton );
		SMUtils.moveToElementSelenium( driver, ellipsisButton );
		Log.message( "Background color of ellipsis is " + ellipsisButton.getCssValue( Constants.VIEW_ASSIGNED_BY_TABLE_HEADER_BG_COLOR ) );
		Boolean isHoveredColorOfEllipsisAsExpected;
		if ( browser.toLowerCase().contains( "safari" ) ) {
			isHoveredColorOfEllipsisAsExpected = ellipsisButton.getCssValue( Constants.VIEW_ASSIGNED_BY_TABLE_HEADER_BG_COLOR ).equalsIgnoreCase( Constants.LIGHT_GREY_COLOR_MAC );
		} else {
			isHoveredColorOfEllipsisAsExpected = ellipsisButton.getCssValue( Constants.VIEW_ASSIGNED_BY_TABLE_HEADER_BG_COLOR ).equalsIgnoreCase( Constants.LIGHT_GREY_COLOR );
		}
		return isHoveredColorOfEllipsisAsExpected;
	}

	/**
	 * Get Teacher last name from the Assigned By pop up
	 * 
	 * @return
	 */

	public List<String> returnLastNames( List<String> listFullName ) {
		List<String> listWithLastNames = new ArrayList<>();
		listFullName.stream().forEach( element -> listWithLastNames.add( element.replaceAll( "^.*?(\\w+)\\W*$", "$1" ) ) );
		return listWithLastNames;
	}

	//TODO - Null safe check
	/**
	 * Get Course Last Assigned Date from the Assigned By pop up
	 * 
	 * @return
	 */
	public List<String> getCourseLastAssignedDatesFromViewAssignedByPopup() {
		List<String> datesList = new ArrayList<>();
		List<String> dates = new ArrayList<>();
		SMUtils.waitForElement( driver, viewAssignedByPopupTitle, 10 );
		//TODO - Here we are using nth-of-type. Tried with some other options but this is a stable one.
		By byNameColumn = By.cssSelector( commonViewAssignedByLastAssignedPopup );
		List<WebElement> teacherName = driver.findElements( byNameColumn );
		Log.message( "Size of Teachers list is " + teacherName.size() );
		teacherName.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( datesList::add ) );
		datesList.stream().distinct().forEach( dates::add );
		return dates;
	}

	/**
	 * To verify whether the View Assigned By pop up title is as present
	 */
	public void viewAssignedByPopupTitle() {
		if ( SMUtils.waitForElement( driver, viewAssignedByPopupTitle, 5 ) ) {
			SMUtils.getTextOfWebElement( viewAssignedByPopupTitle, driver );
			if ( SMUtils.getTextOfWebElement( viewAssignedByPopupTitle, driver ).equals( Constants.ASSIGNED_BY_POPOUP_TITLE ) ) {
				Log.message( "View Assigned By Popup Title is as expected" );
			} else {
				Log.message( "View Assigned By Popup Title is not as expected" );
			}
		} else {
			Log.message( "View Assigned By pop up is absent" );
		}
	}

	/**
	 * To verify & close the View Assigned By pop up close button is present
	 */
	public void viewAssignedByPopupCloseButton() {
		if ( SMUtils.waitForElement( driver, viewAssignedByPopupCloseParent, 5 ) ) {
			WebElement closeBtnOfViewAssignedByPopup = SMUtils.getWebElementDirect( driver, viewAssignedByPopupCloseParent, iconInner );
			closeBtnOfViewAssignedByPopup.isDisplayed();
			Log.message( "Close button in the View Assigned By pop up as expected" );
		} else {
			Log.fail( "View Assigned By pop up is absent" );
		}
	}

	/**
	 * Click Name column
	 */
	public void clickNameColumnHeader() {
		SMUtils.waitForElement( driver, assignedByPopupNameHeadingSort, 8 );
		SMUtils.clickJS( driver, assignedByPopupNameHeadingSort );
		Log.message( "Clicked Name column of View Assigned By Popup" );
	}

	/**
	 * Click Course Last Assigned column
	 */
	public void clickCourseLastAssignedDateColumn() {
		SMUtils.waitForElement( driver, assignedByPopupCourseLastAssignedHeadingSort, 5 );
		SMUtils.clickJS( driver, assignedByPopupCourseLastAssignedHeadingSort );
		Log.message( "Clicked Last Assigned column of View Assigned By Popup" );
	}

	/**
	 * This method verifies the date format in MM/DD/YYYY
	 * 
	 * @return boolean
	 */
	public boolean isValidDateFormat( List<String> unsortedDateList ) {

		DateTimeFormatterBuilder builder = new DateTimeFormatterBuilder().parseCaseInsensitive().parseLenient().appendPattern( "[MM/dd/yyyy]" );
		List<LocalDate> dateListInEnglishLocale = new ArrayList<>();
		DateTimeFormatter formatterForEnglishLocal = builder.toFormatter( Locale.ENGLISH );
		for ( String date : unsortedDateList ) {
			try {
				LocalDate dateInEnglishLocale = LocalDate.parse( date, formatterForEnglishLocal );
				dateListInEnglishLocale.add( dateInEnglishLocale );
				Log.message( "Date is in the expected format" );
			} catch ( DateTimeParseException e ) {
				Log.message( "Date is not in the expected format" );
			}
		}
		return true;
	}

	/**
	 * This method will return concatenated name of the Teacher
	 * 
	 * @param title
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * 
	 * @return String
	 */
	public String completeTeacherName( String title, String firstName, String middleName, String lastName ) {

		String courseCreatorName = "";

		if ( title.equals( Constants.MISS ) ) {
			courseCreatorName = String.join( " ", title, firstName, middleName, lastName );

		} else if ( title.equals( Constants.SELECT_TITLE ) ) {
			courseCreatorName = String.join( " ", firstName, middleName, lastName );
		} else {
			courseCreatorName = String.join( " ", title + ". ", firstName, middleName, lastName );
		}
		return courseCreatorName.trim().replaceAll( "\\s{2,}", " " );
	}

	/**
	 * This method will return concatenated name of the Student
	 * 
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * 
	 * @return String
	 */
	public String completeStudentName( String firstName, String middleName, String lastName ) {

		String studentFullName = "";

		if ( middleName.isEmpty() ) {
			studentFullName = String.join( " ", firstName, lastName );

		} else {
			studentFullName = String.join( " ", firstName, middleName, lastName );
		}
		return studentFullName.trim().replaceAll( "\\s{2,}", " " );
	}

	/**
	 * To click on the hovered assignment
	 * 
	 * @param assignmentName
	 * @return
	 */
	public void clickOnTheHoveredAssignment( String assignmentName ) {
		//This is required for running in the Safari browser
		SMUtils.nap( 5 );

		try {
			assignmentTitle.stream().forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( studentIdDetail -> {
				String[] assignmentNameFinal = studentIdDetail.split( "(?<=\\G.{" + assignmentName.trim().length() + "})" );
				if ( assignmentNameFinal[0].equalsIgnoreCase( assignmentName ) ) {
					SMUtils.moveToElementSelenium( driver, element );
					SMUtils.clickJS( driver, element );
					Log.message( "Assignment selected is " + assignmentName );
				}
			} ) );
		} catch ( StaleElementReferenceException | NoSuchElementException e ) {
			Log.message( "Hidden row detected" );
		}
	}

	/**
	 * To get the assignment title
	 *
	 * @return
	 */
	public String getAssignmentTitle() {
		SMUtils.waitForElement( driver, courseTitle, 5 );
		Log.message( "Assignment name is " + SMUtils.getTextOfWebElement( courseTitle, driver ) );
		return SMUtils.getTextOfWebElement( courseTitle, driver );
	}

	/**
	 * To get the assignment title. This is created to target safari browsers
	 *
	 * @return
	 */
	public String getAssignmentTitle( String assignmentName ) {
		SMUtils.waitForElement( driver, courseTitle, 5 );
		String[] assignmentNameFinal = SMUtils.getTextOfWebElement( courseTitle, driver ).split( "(?<=\\G.{" + assignmentName.trim().length() + "})" );
		Log.message( "Assignment name is " + assignmentNameFinal[0] );
		return assignmentNameFinal[0];
	}

	/**
	 * To click on the student plus sign to see the skill details
	 * 
	 * @return
	 */
	public boolean expandForSkillDetails() {
		SMUtils.waitForElement( driver, expandForSkillDeatils );
		WebElement plusSign = SMUtils.getWebElementDirect( driver, expandForSkillDeatils, commonCssForSkillDetailsIcon );
		WebElement minusSign = SMUtils.getWebElementDirect( driver, shrinkForSkillDeatils, commonCssForSkillDetailsIcon );
		SMUtils.clickJS( driver, plusSign );
		SMUtils.waitForElement( driver, minusSign, 5 );
		Log.message( "Clicked on the plus sign to view the Student details" );
		return true;
	}

	/**
	 * To click on the student minus sign to hide the skill details
	 * 
	 * @return
	 */
	public boolean shrinkForSkillDetails() {
		SMUtils.waitForElement( driver, shrinkForSkillDeatils );
		WebElement minusSign = SMUtils.getWebElementDirect( driver, shrinkForSkillDeatils, commonCssForSkillDetailsIcon );
		WebElement plusSign = SMUtils.getWebElementDirect( driver, expandForSkillDeatils, commonCssForSkillDetailsIcon );
		SMUtils.clickJS( driver, minusSign );
		SMUtils.waitForElement( driver, plusSign, 5 );
		Log.message( "Clicked on the minus sign to view the Student details" );
		return true;
	}

	/**
	 * This method is to turn the status of the 'Shared At District Level' as
	 * ON/OFF based on the status being passed to the method
	 * 
	 * @param status
	 */
	public void changeStatusOfTheSharedAtDistrictLevel( String status ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			editCourseSecondColumnElements.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.SHARE_AT_DISTRICT_LABEL ) ).ifPresent(
							elementFinalText -> {
								if ( elementFinalText.equalsIgnoreCase( Constants.SHARE_AT_DISTRICT_LABEL ) ) {
									if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
										SMUtils.clickJS( driver, element.findElement( By.cssSelector( toggleOffButton ) ) );
										Log.message( "Button clicked" );
									} else {
										SMUtils.clickJS( driver, element.findElement( By.cssSelector( toggleOnButton ) ) );
										Log.message( "Button clicked" );
									}
								}
							} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
	}

	/**
	 * Common method to click on the dropdown value of session length/idle time
	 * 
	 * @param dropdownFieldName
	 * @param dropdownFieldNameValue
	 * 
	 */
	public void selectTheDropdownValue( String dropdownFieldName, String dropdownFieldNameValue ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			dropdownFirstColumn.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( dropdownFieldName ) ).ifPresent( elementFinalText -> {
						if ( elementFinalText.equalsIgnoreCase( dropdownFieldName ) ) {
							Log.message( "Element is " + element );
							SMUtils.clickJS( driver, element.findElement( By.cssSelector( "button.dropdown-select-trigger" ) ) );
							Optional<WebElement> dropdownColumnValuesToBeClicked = dropdownFirstColumnList.stream().filter(
									dropdownFirstColumnListValueText -> SMUtils.getTextOfWebElement( dropdownFirstColumnListValueText, driver ).equalsIgnoreCase( dropdownFieldNameValue ) ).findFirst();
							dropdownColumnValuesToBeClicked.ifPresent( elementToBeClicked -> SMUtils.clickJS( driver, elementToBeClicked ) );
							Log.message( "Dropdown value clicked is" + dropdownFieldNameValue );
						}
					} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
	}

	/**
	 * Common method to get the dropdown value of session length/idle time
	 * 
	 * @param dropdownFieldName
	 * 
	 */
	public String getTheDropdownValue( String dropdownFieldName ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			dropdownFirstColumn.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( dropdownFieldName ) ).ifPresent( elementFinalText -> {
						if ( elementFinalText.equalsIgnoreCase( dropdownFieldName ) ) {
							Log.message( "Element is " + element );
							fieldValue = SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( ".dropdown-select-label" ) ), driver ).trim();
							Log.message( "Dropdown value is" + fieldValue );
						}
					} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return fieldValue;
	}

	/**
	 * This is generic method to turn ON/OFF the radio button based on the
	 * column
	 * 
	 * @param column
	 * @param status
	 * @param fieldName
	 */
	public void changeStatusOfTheRadioButton( String column, String status, String fieldName ) {
		List<WebElement> columnNumber;
		if ( column.equalsIgnoreCase( Constants.FIRST_COLUMN ) ) {
			columnNumber = editCourseFirstColumnElements;
		} else {
			columnNumber = editCourseSecondColumnElements;
		}

		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			columnNumber.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( fieldName ) ).ifPresent( elementFinalText -> {
						if ( elementFinalText.equalsIgnoreCase( fieldName ) ) {
							if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
								SMUtils.clickJS( driver, element.findElement( By.cssSelector( toggleOffButton ) ) );
								Log.message( "Button clicked" );
							} else {
								SMUtils.clickJS( driver, element.findElement( By.cssSelector( toggleOnButton ) ) );
								Log.message( "Button clicked" );
							}
						}
					} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
	}

	/**
	 * This is generic method to get the radio button status based on the column
	 * 
	 * @param column
	 * @param statusToCheck
	 * @param fieldName
	 */
	public boolean getStatusOfTheRadioButton( String column, String statusToCheck, String fieldName ) {
		List<WebElement> columnNumber;
		AtomicReference<Boolean> fieldStatus = new AtomicReference<>();
		if ( column.equalsIgnoreCase( Constants.FIRST_COLUMN ) ) {
			columnNumber = editCourseFirstColumnElements;
		} else {
			columnNumber = editCourseSecondColumnElements;
		}

		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			columnNumber.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ).trim() ).filter( elementText -> elementText.equalsIgnoreCase( fieldName ) ).ifPresent( elementFinalText -> {
						if ( elementFinalText.equalsIgnoreCase( fieldName ) ) {
							if ( statusToCheck.equalsIgnoreCase( Constants.ON_CAPS ) && element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed() ) {
								fieldStatus.set( true );
							} else if ( statusToCheck.equalsIgnoreCase( Constants.OFF_CAPS ) && element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed() ) {
								fieldStatus.set( true );
							} else {
								fieldStatus.set( false );
							}
						}
					} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return fieldStatus.get();
	}

	/**
	 * To verify 'Shared At District Level' is ON/OFF
	 * 
	 * @param status
	 */
	public String getTheStatusOfTheSharedAtDistrictLevel( String status ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			editCourseSecondColumnElements.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.SHARE_AT_DISTRICT_LABEL ) ).ifPresent(
							elementFinalText -> {
								if ( elementFinalText.equalsIgnoreCase( Constants.SHARE_AT_DISTRICT_LABEL ) ) {
									Log.message( "Element text is " + elementFinalText );
									if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
										element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
										Log.message( "Share at District level is visible as ON" );
										sharedAtDistrictLevel = Constants.ON_CAPS;
									} else {
										element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
										Log.message( "Share at District level is visible as OFF" );
										sharedAtDistrictLevel = Constants.OFF_CAPS;
									}
								}
							} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return sharedAtDistrictLevel;
	}

	/**
	 * This method is to turn the status of the 'Display LO Information' as
	 * ON/OFF based on the status being passed to the method
	 * 
	 * @param status
	 */
	public void changeStatusOfTheDisplayLoInformation( String status ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			editCourseFirstColumnElements.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.DISPLAY_LO_INFORMATION ) ).ifPresent(
							elementFinalText -> {
								if ( elementFinalText.equalsIgnoreCase( Constants.DISPLAY_LO_INFORMATION ) ) {
									if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
										SMUtils.clickJS( driver, element.findElement( By.cssSelector( toggleOffButton ) ) );
										Log.message( "Button clicked LO displayed as ON " );
									} else {
										SMUtils.clickJS( driver, element.findElement( By.cssSelector( toggleOffButton ) ) );
										Log.message( "Button clicked" );
									}
								}
							} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
	}

	/**
	 * To verify 'Display LO Information' is ON/OFF
	 * 
	 * @param status
	 */
	public String getTheStatusOfTheDisplayLoInformation( String status ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			editCourseFirstColumnElements.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.DISPLAY_LO_INFORMATION ) ).ifPresent(
							elementFinalText -> {
								if ( elementFinalText.equalsIgnoreCase( Constants.DISPLAY_LO_INFORMATION ) ) {
									if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
										element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
										Log.message( "Display LO Information is visiable as ON" );
										displayLoInformation = Constants.ON_CAPS;
									} else {
										element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
										Log.message( "Display LO Information is visible as OFF" );
										displayLoInformation = Constants.OFF_CAPS;
									}
								}
							} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return displayLoInformation;
	}

	/**
	 * To verify 'Display LO Information' is ON/OFF in the course Setting
	 * section of the course
	 * 
	 * @param status
	 */
	public String getTheStatusOfTheDisplayLoInformationFromCourseSettings( String status ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			courseSettingList.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.DISPLAY_LO_INFORMATION ) ).ifPresent(
							elementFinalText -> {
								if ( elementFinalText.equalsIgnoreCase( Constants.DISPLAY_LO_INFORMATION ) ) {
									if ( status.equalsIgnoreCase( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( courseTypeData ) ), driver ) ) ) {
										Log.message( "Display LO Information is ON" );
										displayLoInformationCourseSetting = Constants.ON_CAPS;
									} else {
										Log.message( "Display LO Information is OFF" );
										displayLoInformationCourseSetting = Constants.OFF_CAPS;
									}
								}
							} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return displayLoInformationCourseSetting;
	}

	/**
	 * Generic method to check the status of the Setting values present at the
	 * right-hand side when we click any course
	 * 
	 * @param fieldName
	 */
	public String getTheSettingsOfTheCourse( String fieldName ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			courseSettingList.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( fieldName ) ).ifPresent( elementFinalText -> {
						if ( elementFinalText.equalsIgnoreCase( fieldName ) ) {
							Log.message( "Element is " + element );
							if ( !SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( courseTypeData ) ), driver ).isEmpty() ) {
								courseSettingStatus = SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( courseTypeData ) ), driver );
								Log.message( fieldName + " value is " + courseSettingStatus );
							}
						}
					} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return courseSettingStatus;
	}

	/**
	 * To click back icon
	 * 
	 * @return
	 */
	public void clickBackIcon() {
		SMUtils.waitForElementToBeClickable( backIcon, driver );
		SMUtils.clickJS( driver, backIcon );
		Log.message( "Clicked back icon!" );
	}

	/**
	 * To get Group list from Assignment details table
	 * 
	 * @return
	 */
	public List<String> getGroupListfromAssignementDetailsTable() {
		//This nap is required for the Group list to load
		SMUtils.nap( 5 );
		List<String> assignementDetailsTableGroupList = new ArrayList<>();
		groupNameListFromAssignPopup.stream().forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( assignementDetailsTableGroupList::add ) );
		Collections.sort( assignementDetailsTableGroupList );
		assignementDetailsTableGroupList.stream().forEach( studentName -> Log.message( "Student in assigned the assignment " + studentName ) );
		return assignementDetailsTableGroupList;
	}

	/**
	 * To add particular one student to course
	 */
	public void addCourseToOneStudent( String studentName ) {
		SMUtils.waitForElement( driver, studentRadioBtn, 8 );
		SMUtils.clickJS( driver, studentRadioBtn );
		SMUtils.waitForElement( driver, addBtnRoot );
		List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );

		IntStream.range( 0, studentList.size() ).forEach( index -> {

			if ( SMUtils.getTextOfWebElement( studentList.get( index ), driver ).contains( studentName ) ) {
				WebElement addBtn = SMUtils.getWebElementDirect( driver, addBtns.get( index ), btnSecondary );
				SMUtils.clickJS( driver, addBtn );

				Log.message( "Add Button Clicked Successfully " );
			}
		} );
		WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignBtnRoot, btnPrimary );
		SMUtils.clickJS( driver, assignPopUpBtn );

	}

	/**
	 * To add Course to one group
	 */
	public void addCourseToOneGroup() {
		SMUtils.waitForElement( driver, groupsradioBtn );
		SMUtils.clickJS( driver, groupsradioBtn );
		SMUtils.waitForElement( driver, addBtnRoot );

		List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );
		if ( !addBtns.isEmpty() ) {
			WebElement addBtn = SMUtils.getWebElementDirect( driver, addBtns.get( 0 ), btnSecondary );
			SMUtils.clickJS( driver, addBtn );
		}
		WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignBtnRoot, btnPrimary );
		SMUtils.clickJS( driver, assignPopUpBtn );
		Log.message( "Course added to Groups" );
	}

	/**
	 * To toggle IPM setting as Off
	 * 
	 * @return
	 */
	public void toggleIPMOff() {
		SMUtils.waitForElement( driver, createBtnRoot );
		boolean isClicked = buttonLabelinCourseSettings.stream().anyMatch( ipLabel -> {
			if ( ipLabel.getText().trim().equalsIgnoreCase( Constants.Course_Creation.IPMLABEL.trim() ) ) {
				WebElement parentElement = ipLabel.findElement( By.xpath( "./.." ) );
				SMUtils.clickJS( driver, parentElement.findElement( By.cssSelector( buttonToggleOn ) ) );
				Log.message( "Clicked toggle off-IPM" );
				return true;
			}
			return false;
		} );
		if ( !isClicked ) {
			Log.message( "Error occured while toggle IPM-off" );
		}
	}

	/**
	 * To verify 'Assign To' modal
	 * 
	 * @return
	 */
	public boolean verifyAssignTo() {
		SMUtils.waitForElement( driver, assignToModal, 8 );
		try {
			return SMUtils.isElementPresent( assignToModal );
		} catch ( Exception e ) {
			return false;
		}
	}

	/**
	 * To verify the groups checkbox is selected state
	 * 
	 * @return
	 */
	private boolean isGroupsChecked() {
		return groupsradioBtn.isSelected();
	}

	/**
	 * To add "N" of students to Course (eg. 5 students or 8 students,etc..,)
	 */
	public void addCourseToStudents( int... studentCount ) {
		int studentsToSelect;

		SMUtils.waitForElement( driver, studentRadioBtn );
		SMUtils.clickJS( driver, studentRadioBtn );
		SMUtils.waitForElement( driver, addBtnRoot );
		List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );

		if ( studentCount.length > 0 ) {
			studentsToSelect = studentCount[0];
		} else {
			studentsToSelect = addBtns.size();
		}

		addBtns.forEach( elementIndex -> {
			WebElement addBtn = SMUtils.getWebElementDirect( driver, elementIndex, btnSecondary );
			SMUtils.clickJS( driver, addBtn );
		} );

		WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignBtnRoot, btnPrimary );
		SMUtils.clickJS( driver, assignPopUpBtn );
		Log.message( "Course added to Students" );
	}

	/**
	 * To add Course to multiple students
	 */
	public void addCourseToMultipleStudents() {
		SMUtils.waitForElement( driver, studentRadioButton );
		SMUtils.clickJS( driver, studentRadioButton );
		SMUtils.waitForElement( driver, addBtnRoot );
		List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );
		addBtns.stream().forEach( element -> {
			WebElement addBtn = SMUtils.getWebElementDirect( driver, element, btnSecondary );
			SMUtils.clickJS( driver, addBtn );
			Log.message( "Multiple student added to selected course" );
		} );

	}

	/**
	 * Click assign button on edit page
	 */
	public void clickAssignButton() {
		try {
			WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignBtnRoot, btnPrimary );
			SMUtils.waitForElement( driver, assignPopUpBtn );
			SMUtils.clickJS( driver, assignPopUpBtn );
			Log.message( "Assign button clicked successfully" );
		} catch ( Exception e ) {
			WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignButtonRoot, btnPrimary );
			SMUtils.waitForElement( driver, assignPopUpBtn );
			SMUtils.clickJS( driver, assignPopUpBtn );
			Log.message( "Assign button clicked successfully" );
		}
	}

	/*
	 * 
	 * Click Close button
	 */
	public void clickCloseBtn() {
		SMUtils.nap( 10 );
		SMUtils.waitForElement( driver, btnClosePopupRoot );
		WebElement closeBtn = SMUtils.getWebElementDirect( driver, btnClosePopupRoot, btnCloseIcon );
		SMUtils.clickJS( driver, closeBtn );
		Log.message( "Clicked Close Button" );
	}

	/**
	 * Assign Default course from Courses Widget
	 * 
	 * @throws InterruptedException
	 */
	public AssignAssignmentPopup assignDefaultCourseFromCoursesWidget( String customCourseName ) throws InterruptedException {
		for ( WebElement courseParent : coursesParent ) {
			WebElement courseTypeElement = SMUtils.getChildWebElementFromParent( courseParent, courseTypeCSS );
			if ( courseTypeElement.getText().equals( "Full Course" ) ) {
				WebElement courseTitleElement = SMUtils.getChildWebElementFromParent( courseParent, courseTitleCSS );
				if ( courseTitleElement.getText().trim().equals( customCourseName ) ) {
					WebElement courseAssignBtnShowdowElement = SMUtils.getChildWebElementFromParent( courseParent, courseAssignBtnCSSShadow );

					WebElement courseAssignBtn = SMUtils.getWebElement( driver, courseAssignBtnShowdowElement, courseAssignBtnCSS );
					SMUtils.clickJS( driver, courseAssignBtn );
					clickMSDAPopup();
					SMUtils.waitForElement( driver, assignPopupHeader );
					break;
				}
			}
		}
		return new AssignAssignmentPopup( driver );
	}

	/**
	 * Assign Default course from Courses Widget
	 */
	public List<String> getDefaultCoursesNameFromCoursesWidget() {
		List<String> customCourses = new ArrayList<String>();
		for ( WebElement courseParent : coursesParent ) {
			WebElement courseTypeElement = SMUtils.getChildWebElementFromParent( courseParent, courseTypeCSS );
			if ( courseTypeElement.getText().equals( "Full Course" ) ) {
				WebElement courseTitleElement = SMUtils.getChildWebElementFromParent( courseParent, courseTitleCSS );
				customCourses.add( courseTitleElement.getText() );
			}
		}
		return customCourses;
	}

	/**
	 * Enable the status of fluency file
	 * 
	 * @param status
	 */
	public void changeStatusOfTheFluency( String status ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			editCourseSecondColumnElements.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.FLUENCY ) ).ifPresent( elementFinalText -> {
						if ( elementFinalText.equalsIgnoreCase( Constants.FLUENCY ) ) {
							if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
								SMUtils.clickJS( driver, element.findElement( By.cssSelector( toggleOffButton ) ) );
								Log.message( "Button clicked" );
							} else {
								SMUtils.clickJS( driver, element.findElement( By.cssSelector( toggleOnButton ) ) );
								Log.message( "Button clicked" );
							}
						}
					} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
	}

	/**
	 * To select one group from Assign to modal
	 */
	public void selectOneGroup() {
		SMUtils.waitForElement( driver, groupsradioBtn );
		SMUtils.clickJS( driver, groupsradioBtn );
		SMUtils.waitForElement( driver, addBtnRoot );

		List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );
		if ( CollectionUtils.isNotEmpty( addBtns ) ) {
			WebElement addBtn = SMUtils.getWebElementDirect( driver, addBtns.get( 0 ), btnSecondary );
			SMUtils.clickJS( driver, addBtn );
		}
	}

	/**
	 * To click on the cancel button of the 'Make a copy' dialog box
	 * 
	 */
	public void clickOnCancelBtn() {
		SMUtils.waitForElement( driver, btnCancelHost, 8 );
		WebElement cancelButton = SMUtils.getWebElementDirect( driver, btnCancelHost, cancelBtnChild );
		SMUtils.clickJS( driver, cancelButton );
		Log.message( "Clicked the Cancel button" );
	}

	/**
	 * To click on the Standard dropdown of the default course
	 * 
	 */
	public void clickStandardDropdownBtn() {
		SMUtils.waitForElement( driver, standardDropdownBtnHost, 5 );
		WebElement standardDropdownButtton = SMUtils.getWebElementDirect( driver, standardDropdownBtnHost, standardDropdownBtn );
		SMUtils.click( driver, standardDropdownButtton );
		Log.message( "Clicked the Standard dropdown" );
	}

	/**
	 * To click on the Grade dropdown of the default course
	 * 
	 */
	public void clickGradeDropdownBtn() {
		SMUtils.waitForElement( driver, skillDropdownBtnHost, 5 );
		WebElement gradeDropdownButtton = SMUtils.getWebElementDirect( driver, skillDropdownBtnHost, standardDropdownBtn );
		SMUtils.click( driver, gradeDropdownButtton );
		Log.message( "Clicked the Grade dropdown" );
	}

	/**
	 * To click on the desired Standard/Grade dropdown of the default course
	 * 
	 * @param nameToClick
	 * @param dropdownType
	 */
	public void clickStandardOrGradesInDropdown( String nameToClick, String dropdownType ) {
		WebElement parentList;
		SMUtils.waitForElement( driver, standardDropdownBtnHost, 5 );
		if ( dropdownType.equalsIgnoreCase( Constants.STANDARDS ) ) {
			parentList = SMUtils.getWebElement( driver, standardDropdownBtnHost, dropdownMenuBox );
		} else {
			parentList = SMUtils.getWebElement( driver, skillDropdownBtnHost, dropdownMenuBox );
		}
		List<WebElement> selectedMasterList = SMUtils.getAllWebElements( driver, parentList, listItem );
		selectedMasterList.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( elementText -> {
			if ( elementText.equalsIgnoreCase( nameToClick ) ) {
				SMUtils.clickJS( driver, element );
				Log.message( "Clicked :" + elementText );
			}
		} ) );
	}

	/**
	 * To get the list of the side nav of the course
	 * 
	 * @return sideNavTitle
	 */
	public List<String> getSideNavOfCourse() {
		List<String> sideNavTitle = new ArrayList<>();
		sideBarNav.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( sideNavTitle::add ) );
		sideNavTitle.add( SMUtils.getTextOfWebElement( sideBarNavActiveElement, driver ) );
		Log.message( "Fetched all the side nav titles" );
		return sideNavTitle;
	}

	/**
	 * To click on any one of the element in the side nav of the course
	 * 
	 * @param sideNavTitle
	 */
	public void clickOnTheSideNav( String sideNavTitle ) {
		sideBarNav.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( elementText -> {
			if ( elementText.equals( sideNavTitle ) ) {
				SMUtils.clickJS( driver, element );
				Log.message( "Clicked Side Nav with Title : " + elementText );
			}
		} ) );
	}

	/**
	 * To get all the LO's of the topics
	 * 
	 * @return losOfTopics
	 */
	public Set<String> getAllTheLosOfThetopic() {
		Set<String> losOfTopics = new HashSet<>();
		JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) driver;
		//Tried using the WebDriver code but each test method was taking 14 to 20 minutes so I decided to go with JS Executor which brought the overall time to 5-7 minutes per test method.
		String js = "function getLoList() { var finalLoList = []; var loList = document.querySelectorAll('.content-block a'); loList.forEach(el => { if (typeof(el) !== \"undefined\") { if (el !== null) { finalLoList.push(el.innerText.trim()); } } }); return finalLoList; };return getLoList();";
		String jsResponse = javaScriptExecutor.executeScript( js ).toString();
		JSONArray jsonArr = new JSONArray( jsResponse );
		jsonArr.forEach( elementFinalText -> {
			if ( Boolean.TRUE.equals( elementFinalText != null && !elementFinalText.toString().isEmpty() ) ) {
				losOfTopics.add( elementFinalText.toString().toLowerCase().trim() );
			}
		} );
		losOfTopics.remove( "null" );
		Log.message( "Fetched all the LO's" );
		return losOfTopics;
	}

	/**
	 * To get the complete Custom course List
	 *
	 * @return courseList
	 */

	public Set<String> getCourseListForCustomCourse() {
		SMUtils.nap( 5 );
		Set<String> courseList = new HashSet<>();
		JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) driver;
		//Used JS Executor to reduce the overall time of execution as by using WebDriver code it was taking more time and increasing the overall execution time of the automation suite
		String js = "function getCourseList() { var finalCourseList = []; var courseList = document.querySelectorAll('span.tile__title'); courseList.forEach(el => { if (typeof(el) !== \"undefined\") { if (el !== null) { finalCourseList.push(el.innerText.trim()); } } }); return finalCourseList; };return getCourseList();";
		String jsResponse = javaScriptExecutor.executeScript( js ).toString().replace( ":", "-" );
		JSONArray jsonArr = new JSONArray( jsResponse );
		jsonArr.forEach( elementFinalText -> {
			if ( Boolean.TRUE.equals( elementFinalText != null && !elementFinalText.toString().isEmpty() ) ) {
				courseList.add( elementFinalText.toString().toLowerCase().trim() );
			}
		} );
		courseList.remove( "null" );
		Log.message( "Fetched all the Course name" );
		return courseList;
	}

	/**
	 * To get the complete Custom course List
	 *
	 * @return courseList
	 */

	public List<String> getCourseTypesFromCoursesWidgetFromCourses() {
		SMUtils.nap( 5 );
		List<String> courseList = new ArrayList<>();
		JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) driver;
		//Used JS Executor to reduce the overall time of execution as by using WebDriver code it was taking more time and increasing the overall execution time of the automation suite
		String js = "function getCourseList() { var finalCourseList = []; var courseList = document.querySelectorAll('cel-tile span.tile__tag'); courseList.forEach(el => { if (typeof(el) !== \"undefined\") { if (el !== null) { finalCourseList.push(el.innerText.trim()); } } }); return finalCourseList; };return getCourseList();";
		String jsResponse = javaScriptExecutor.executeScript( js ).toString().replace( ":", "-" );
		JSONArray jsonArr = new JSONArray( jsResponse );
		jsonArr.forEach( elementFinalText -> {
			if ( Boolean.TRUE.equals( elementFinalText != null && !elementFinalText.toString().isEmpty() ) ) {
				courseList.add( elementFinalText.toString().toLowerCase().trim() );
			}
		} );
		Log.message( "Fetched all the Course widgets names" );
		return courseList;
	}

	/**
	 * To get the complete Custom Date course List
	 *
	 * @return courseList
	 */
	public List<String> getCourseDateListForCustomCourse() {
		SMUtils.nap( 5 );
		List<String> courseList = new ArrayList<>();
		LocalDate currentdate = LocalDate.now();
		int year = currentdate.getYear();
		JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) driver;
		//Used JS Executor to reduce the overall time of execution as by using WebDriver code it was taking more time and increasing the overall execution time of the automation suite
		String js = "function getCustomCourseDateList() { var finalCustomCourseDateList = []; var customCourseDateList = document.querySelectorAll('cel-tile .tile__info'); customCourseDateList.forEach(el => { if (typeof(el) !== 'undefined') { if (el !== null) { finalCustomCourseDateList.push(el.innerHTML.trim()); } } }); return finalCustomCourseDateList; };return getCustomCourseDateList();";
		String jsResponse = javaScriptExecutor.executeScript( js ).toString().replace( ":", "-" );
		JSONArray jsonArr = new JSONArray( jsResponse );
		IntStream.range( 0, jsonArr.length() ).forEach( elementIndex -> {
			if ( Boolean.TRUE.equals( jsonArr.get( elementIndex ) != null && !jsonArr.get( elementIndex ).toString().isEmpty() ) ) {
				String date = jsonArr.get( elementIndex ).toString().trim().replaceAll( "^(.*?)on\\s", "" );
				if ( date.length() > 4 && jsResponse.contains( String.valueOf( year ) ) ) {
					courseList.add( String.join( ", ", date, String.valueOf( year ) ) );
				}
			}
		} );
		Log.message( "Fetched all the Course dates" );
		return courseList;
	}

	/**
	 * To click all the topics for particular Standard
	 * 
	 */
	public void clickAllTheTopicForEachStandard() {
		topicListOfEachStandard.stream().distinct().forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( elementText -> {
			if ( element.isDisplayed() ) {
				SMUtils.clickJS( driver, element );
				Log.message( "Clicked on topic with title: " + elementText );
			}
		} ) );
	}

	/**
	 * To click all the sub-topics of the standards
	 * 
	 */
	public void clickAllTheSubTopicsForEachStandard() {
		subTopic.stream().distinct().forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( elementText -> {
			if ( element.isDisplayed() ) {
				SMUtils.clickJS( driver, element );
				Log.message( "Clicked on sub-topic with title: " + elementText );
			}
		} ) );
	}

	/**
	 * To click all the sub-topic topics of the standards
	 * 
	 * @param
	 */
	public void clickAllTheSubTopicsOfTopics() {
		subTopicOfTopics.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( elementText -> {
			if ( element.isDisplayed() ) {
				SMUtils.clickJS( driver, element );
				Log.message( "Clicked on sub-topic of topic with title: " + elementText );
			}
		} ) );
	}

	/**
	 * To get the LO name List
	 * 
	 * @param coursesJsonObj
	 * 
	 * @return loFinalNameList
	 */
	public Set<String> getLoNamesList( JSONObject coursesJsonObj ) {
		Set<String> valueList = new HashSet<>();
		Set<String> childNodeList = new HashSet<>();
		Set<String> loMainList = new HashSet<>();
		Set<String> loFinalNameList = new HashSet<>();
		try {
			coursesJsonObj.keySet().forEach( keyStr -> {
				Object keyvalue = coursesJsonObj.get( keyStr );
				valueList.add( keyvalue.toString() );
			} );
			valueList.forEach( element -> {
				JSONObject obj = new JSONObject( element );
				JSONArray childNodes = obj.getJSONArray( childNodeIds );
				childNodeList.add( childNodes.toString() );
			} );
			childNodeList.forEach( element -> {
				JSONArray jsonArray = new JSONArray( element );
				IntStream.range( 0, jsonArray.length() ).forEach( elementIndex -> {
					JSONObject jsonObjectFinalList = jsonArray.getJSONObject( elementIndex );
					String keyValue = jsonObjectFinalList.optString( id );
					if ( Boolean.FALSE.equals( keyValue.isEmpty() ) ) {
						loMainList.add( keyValue.toLowerCase() );
					}
				} );
			} );
			loFinalNameList = loNameSplitAndMerge( loMainList );
			Log.message( "Fetched all the LO's details" );
		} catch ( Exception e ) {
			Log.message( "Error occured please check getLoNamesList method" );
		}
		return loFinalNameList;
	}

	/**
	 * To get all the LO name as per the UI
	 * 
	 * @param loList
	 * 
	 * @return loFinalName
	 */
	public Set<String> loNameSplitAndMerge( Set<String> loList ) {
		Set<String> loFinalName = new HashSet<>();
		loList.forEach( element -> {
			String[] loNames = element.split( "_" );
			if ( loNames.length > 2 ) {
				loFinalName.add( String.join( "_", loNames[0], loNames[1], loNames[2] ) );
			} else {
				loFinalName.add( element );
			}
		} );
		Log.message( "Split and merge of all LO's completed" );
		return loFinalName;
	}

	/**
	 * To verify remove Course Dialog Opens Up
	 * 
	 */
	public void verifyRemoveCourseDialogOpensUp() {
		WebElement removeBtnFirst = getRemoveBtn();
		SMUtils.clickJS( driver, removeBtnFirst );
		Log.message( "Remove Course Dialog is Opened" );
	}

	/**
	 * To close Dialog
	 */
	public void closeDialog() {
		SMUtils.waitForElement( driver, btnClosePopupRoot );
		SMUtils.clickJS( driver, btnClosePopupRoot );
	}

	/**
	 * To click cancel button in the Remove Course Dialog
	 */
	public void clickCancelInRemoveCourseDialog() {
		WebElement removeBtnFirst = getRemoveBtn();
		SMUtils.clickJS( driver, removeBtnFirst );
		SMUtils.waitForElement( driver, removeCourseDialogBoxRemoveBtnRoot );
		WebElement cancelBtnMain = SMUtils.getWebElementDirect( driver, removeCoursePopupCancelBtnRoot, btnSecondary );
		SMUtils.clickJS( driver, cancelBtnMain );
		Log.message( "Cancel Button is Clicked in the Remove Course Dialog" );
	}

	/**
	 * To get course type title
	 * 
	 */
	public String getCourseTypeTitle() {
		return SMUtils.getTextOfWebElement( courseTypeTitle, driver );
	}

	/**
	 * To get Skills drop down text
	 * 
	 */
	public List<String> getSkillsDropdownTextforFocusCourse() {
		SMUtils.waitForElement( driver, skillsDropdownRoot );
		WebElement dropDownRoot = SMUtils.getWebElementDirect( driver, skillsDropdownRoot, dropdownBtnParent );
		List<WebElement> skillDropDownValues = SMUtils.getAllWebElements( driver, dropDownRoot, dropdownBtnChild );
		List<String> texts = new ArrayList<>();
		skillDropDownValues.forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( texts::add ) );
		return texts;
	}

	/**
	 * To select Left Strand
	 */

	public void selectLeftStrandForCourses() {
		//Here we are using nap for stability in the Safari browser. Tried with the WebDriver waits but is fails in some cases.
		SMUtils.nap( 3 );
		if ( Boolean.FALSE.equals( leftStrandMathCourses.isEmpty() ) ) {
			Log.message( "LeftSide StrandCourses are available" );
			SMUtils.clickJS( driver, leftStrandMathCourses.get( 2 ) );
			try {
				SMUtils.waitForSpinnertoDisapper( driver, 60 );
			} catch ( Exception e ) {
				Log.message( "Spinner loading not complete for selectLeftStrandForCourses" );
			}
		} else {
			Log.fail( "LeftSide StrandCourses are not available" );
		}
	}

	/**
	 * To expand Tier Node
	 * 
	 */
	public void expandTierNode() {
		SMUtils.waitForElement( driver, tierNodeTitle );
		WebElement tierNodeButton = SMUtils.getWebElement( driver, tierNodeExpandIcon, btnCloseIcon );
		SMUtils.clickJS( driver, tierNodeButton );
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Spinner loading not complete for expandTierNode" );
		}
		Log.message( "Tier node expanded" );
	}

	/**
	 * To click LO Link
	 * 
	 */
	public void clickLO() {
		SMUtils.waitForElement( driver, loLink );
		SMUtils.clickJS( driver, loLink );
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Spinner loading not complete for clickLO" );
		}
		Log.message( "LO link clicked" );
	}

	/**
	 * To verify Print PDF icon is displayed
	 * 
	 */
	public Boolean verifyPrintIconIsDisplayed() {
		SMUtils.waitForElement( driver, innerTierNodeTitle );
		SMUtils.clickJS( driver, innerTierNodeTitle );
		SMUtils.waitForElement( driver, pdfIcon );
		WebElement pdfImage = SMUtils.getWebElement( driver, pdfIcon, btnCloseIcon );
		return ( SMUtils.isElementPresent( pdfImage ) );
	}

	/**
	 * To get LO Details
	 * 
	 */
	public String getLODetails() {
		SMUtils.waitForElement( driver, loLink );
		return SMUtils.getTextOfWebElement( loDetail, driver );

	}

	/**
	 * To verify Remove button is present
	 */
	public boolean verifyRemoveBtnIsPresent() {
		try {
			if ( SMUtils.isElementPresent( getRemoveBtn() ) ) {
				return true;
			} else {
				return false;
			}
		} catch ( Exception e ) {
			return false;
		}
	}

	/**
	 * To verify Edit button is present
	 */
	public boolean verifyEditBtnIsPresent() {
		try {
			if ( SMUtils.isElementPresent( getEditBtn() ) ) {
				return true;
			} else {
				return false;
			}
		} catch ( Exception e ) {
			return false;
		}
	}

	/**
	 * Checks Remove Course Dialog closed or not
	 */
	public boolean isRemoveCourseDialogClosed() {
		try {
			if ( SMUtils.isElementPresent( removeCourseDialogTitle ) ) {
				return true;
			} else {
				return false;
			}
		} catch ( Exception e ) {
			return false;
		}

	}

	/**
	 * To create Custom by standard course
	 * 
	 * @param CourseName
	 * @param subject
	 * @return
	 */
	public String createCustomByStandardCourse( String CourseName, String subject ) {
		if ( subject.equals( Constants.MATH ) ) {
			clickMathCourse();
		} else {
			clickReadingCourse();
		}

		clickMakeCopyBtn();
		enterCourseName( CourseName );
		clickStandardsRadioBtn();
		clickNextBtn();
		if ( getTheStatusOfTheSharedAtDistrictLevel( Constants.OFF_CAPS ).equals( Constants.OFF_CAPS ) ) {
			changeStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
		}
		getTheStatusOfTheSharedAtDistrictLevel( Constants.ON_CAPS );
		clickNextBtn();
		if ( subject.equals( Constants.SM_FOCUS_MATH_GRADE1 ) ) {
			clickDefualtBtnOff();
		} else {
			clickDefualtBtnOn();
		}
		clickCreateBtn();
		Log.message( "Course created successfully" );
		return CourseName;
	}

	/**
	 * To get the strand status
	 * 
	 */
	public String getStrandStatus() {
		SMUtils.waitForElement( driver, strandStatus );
		return SMUtils.getTextOfWebElement( strandStatus, driver );
	}

	/**
	 * To get the LO status
	 * 
	 */
	public String getLOStatus() {
		SMUtils.waitForElement( driver, loLink );
		return SMUtils.getTextOfWebElement( loStatus, driver );
	}

	/**
	 * To add Course to group
	 */
	public void addCourseToGroup() {
		SMUtils.waitForElement( driver, groupRadioButton );
		SMUtils.clickJS( driver, groupRadioButton );
		SMUtils.waitForElement( driver, addBtnRoot );
		List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );
		addBtns.forEach( element -> {
			WebElement addBtn = SMUtils.getWebElementDirect( driver, element, btnSecondary );
			SMUtils.clickJS( driver, addBtn );
		} );
		WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignBtnRoot, btnPrimary );
		SMUtils.waitForElement( driver, assignPopUpBtn );
		SMUtils.clickJS( driver, assignPopUpBtn );
		SMUtils.waitForElement( driver, assignBtnRoot );
		Log.message( "Course added to group" );
	}

	/**
	 * To verify selected standard is displayed.
	 */
	public boolean isDisplayedSelectedStandardFromDropdown() {
		WebElement e = SMUtils.getWebElementDirect( driver, standardPopupDropdownBtnHost, standardDropdownBtn );
		return e.getText().trim().equals( Constants.STANDARDS_LIST.get( 3 ) );

	}

	/**
	 * To verify selected grade is displayed.
	 */
	public boolean isDisplayedSelectedGardeFromDropdown() {
		WebElement e = SMUtils.getWebElementDirect( driver, skillPopupDropdownBtnHost, standardDropdownBtn );
		return e.getText().trim().equals( Constants.Students.ALL_GRADES.get( 0 ) );
	}

	/**
	 * To verify course name is updated
	 */
	public boolean isCourseNameUpdated() {
		SMUtils.waitForElement( driver, courseHeader, 10 );
		Log.message( "Upadted course name is" + courseHeader.getText().trim() );
		return courseHeader.getText().trim().contains( Constants.CUSTOM_BY_SETTINGS_COURSE );

	}

	/**
	 * To click on the popup Standard dropdown of the default course
	 *
	 */
	public void clickPopupStandardDropdownBtn() {
		SMUtils.waitForElement( driver, standardPopupDropdownBtnHost, 5 );
		WebElement standardPopupDropdownButtton = SMUtils.getWebElementDirect( driver, standardPopupDropdownBtnHost, standardDropdownBtn );
		SMUtils.click( driver, standardPopupDropdownButtton );
		Log.message( "Clicked the Standard dropdown" );
	}

	/**
	 * To click on the popup Grade dropdown of the default course
	 *
	 */
	public void clickPopupGradeDropdownBtn() {
		SMUtils.waitForElement( driver, skillPopupDropdownBtnHost, 5 );
		WebElement gradePopupDropdownButtton = SMUtils.getWebElementDirect( driver, skillPopupDropdownBtnHost, standardDropdownBtn );
		SMUtils.click( driver, gradePopupDropdownButtton );
		Log.message( "Clicked the Grade dropdown" );
	}

	/**
	 * To click on the desired Standard/Grade dropdown of the default course
	 *
	 * @param nameToClick
	 * @param dropdownType
	 */
	public void clickPopupStandardOrGradesInDropdown( String nameToClick, String dropdownType ) {
		WebElement parentList;
		SMUtils.waitForElement( driver, standardPopupDropdownBtnHost, 5 );
		if ( dropdownType.equalsIgnoreCase( Constants.STANDARDS ) ) {
			parentList = SMUtils.getWebElement( driver, standardPopupDropdownBtnHost, dropdownMenuBox );
		} else {
			parentList = SMUtils.getWebElement( driver, skillPopupDropdownBtnHost, dropdownMenuBox );
		}
		List<WebElement> selectedMasterList = SMUtils.getAllWebElements( driver, parentList, listItem );
		selectedMasterList.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( elementText -> {
			if ( elementText.equalsIgnoreCase( nameToClick ) ) {
				SMUtils.clickJS( driver, element );
				Log.message( "Clicked :" + elementText );
			}
		} ) );
	}

	/**
	 * To verify spacing of View Assigned table headers Name & Course Last
	 * Assigned
	 */
	public boolean isTheSpacingOfHeadingIsAsExpected() {
		return ( SMUtils.verifyCssPropertyForElement( viewAssignedByPopupHeading.stream().findFirst().get(), Constants.PADDING_TOP, Constants.NAME_TOP_SPACING_VALUE )
				&& SMUtils.verifyCssPropertyForElement( viewAssignedByPopupHeading.stream().skip( 1 ).findFirst().get(), Constants.PADDING_TOP, Constants.COURSES_LAST_ASSIGNED_TOP_SPACING_VALUE )
				&& SMUtils.verifyCssPropertyForElement( viewAssignedByPopupHeading.stream().findFirst().get(), Constants.PADDING_BOTTOM, Constants.NAME_COURSES_BOTTOM_SPACING_VALUE )
				&& SMUtils.verifyCssPropertyForElement( viewAssignedByPopupHeading.stream().skip( 1 ).findFirst().get(), Constants.PADDING_BOTTOM, Constants.NAME_COURSES_BOTTOM_SPACING_VALUE ) );
	}

	/**
	 * To verify the color of Names and Course Last Assigned cells of View
	 * Assigned table
	 */
	public boolean isTheHeaderRowGrayColor() {
		return ( Color.fromString( viewAssignedByPopupHeading.stream().findFirst().get().getCssValue( Constants.VIEW_ASSIGNED_BY_TABLE_HEADER_BG_COLOR ) ).asHex().equals( Constants.GRAY_HEX_VALUE )
				&& Color.fromString( viewAssignedByPopupHeading.stream().skip( 1 ).findFirst().get().getCssValue( Constants.VIEW_ASSIGNED_BY_TABLE_HEADER_BG_COLOR ) ).asHex().equals( Constants.GRAY_HEX_VALUE ) );
	}

	/**
	 * To verify there is no spacing between Make a copy and ellipsis
	 */
	public boolean isMarginLeftisZero() {
		SMUtils.waitForElement( driver, viewAssignedEllipsisSymbol, 5 );
		return ( SMUtils.verifyCssPropertyForElement( viewAssignedEllipsisSymbol, Constants.MARGIN_LEFT, Constants.ELLIPSIS_MARGIN_LEFT_VALUE ) );
	}

	/**
	 * To verify Center alignment of OK text in View Assigned by table
	 */
	public boolean isOKTextCenterAligned() {
		return ( SMUtils.verifyCssPropertyForElement( SMUtils.getWebElement( driver, parentElementViewAssignedByOkBtn, viewAssignedByOkButton ), Constants.TEXT_ALIGN, Constants.CENTER ) );
	}

	/**
	 * To verify the UX related to the scroll bar
	 * 
	 * @return
	 */
	public boolean scrollTheVerticalScrollBar() {
		SMUtils.waitForElement( driver, assignedByPopupDialog, 5 );
		boolean scrolled = false;
		boolean stickyHeaders = false;
		boolean okButtonDisplayed = false;
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			// Scroll inside web element vertically (e.g. 100 pixel)
			js.executeScript( "arguments[0].scrollTop = arguments[1];", assignedByPopupDialog, 100 );
			Log.message( "Scroll bar is present" );
			if ( assignedByPopupCourseLastAssignedHeadingSort.isDisplayed() && assignedByPopupNameHeadingSort.isDisplayed() ) {
				scrolled = true;
				stickyHeaders = true;
				Log.message( "The headers are appearing even after scrolling as expected" );
			}
			WebElement viewAssignedByOkBtn = SMUtils.getWebElement( driver, parentElementViewAssignedByOkBtn, viewAssignedByOkButton );
			//To click OK button
			if ( assignedByPopupDialog.isDisplayed() ) {
				SMUtils.clickJS( driver, viewAssignedByOkBtn );
				if ( assignedByPopupDialog.isDisplayed() ) {
					SMUtils.clickJS( driver, viewAssignedByOkBtn );
					okButtonDisplayed = true;
				}
				Log.message( "OK button clicked" );
			}
		} catch ( Exception e ) {
			Log.message( "Issue occured. Please check logs." );
		}
		return Boolean.TRUE.equals( scrolled && stickyHeaders && okButtonDisplayed );
	}

	/**
	 * To verify Add button is enabled in Assign To modal popup
	 */
	public boolean isAddButtonEnabled() {
		SMUtils.waitForElement( driver, addBtnRoot );
		return addBtnRoot.isEnabled();
	}

	/**
	 * To verify assign button is enabled
	 */
	public Boolean assignButtonEnabled() {
		SMUtils.waitForElement( driver, studentRadioButton );
		SMUtils.clickJS( driver, studentRadioButton );
		SMUtils.waitForElement( driver, addBtnRoot );
		WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignBtnRoot, btnPrimary );
		return assignPopUpBtn.isEnabled();
	}

	/**
	 * To verify add button is enabled
	 */
	public Boolean clickAddButtonforOneGroup() {
		SMUtils.waitForElement( driver, groupsradioBtn );
		SMUtils.clickJS( driver, groupsradioBtn );
		SMUtils.waitForElement( driver, addBtnRoot );

		List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );
		if ( !addBtns.isEmpty() ) {
			WebElement addBtn = SMUtils.getWebElementDirect( driver, addBtns.get( 0 ), btnSecondary );
			SMUtils.clickJS( driver, addBtn );
		}
		WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignBtnRoot, btnPrimary );
		return assignPopUpBtn.isEnabled();
	}

	/**
	 * To click on languge dropdown
	 */
	public void clickLanguageDropdown() {
		WebElement clickLanguageDropdown = SMUtils.getWebElementDirect( driver, languageDropdownHost, languageDropdownBtn );
		SMUtils.waitForElement( driver, clickLanguageDropdown, 7 );
		SMUtils.clickJS( driver, clickLanguageDropdown );

	}

	/**
	 * To click on Select All language checkbox
	 */
	public void clickSelectAllCheckbox() {
		WebElement clickSelectAllCheckboxInLanguageDropdown = SMUtils.getWebElementDirect( driver, selectAllCheckBoxHost, selectAllCheckBoxRoot, selectAllCheckBox );
		SMUtils.waitForElement( driver, clickSelectAllCheckboxInLanguageDropdown, 5 );
		SMUtils.clickJS( driver, clickSelectAllCheckboxInLanguageDropdown );
	}

	/**
	 * To verify save is disabled
	 */
	public boolean isSaveBtnDisabled() {
		SMUtils.waitForElement( driver, btnSaveRoot, 5 );
		WebElement saveBtn = SMUtils.getWebElementDirect( driver, btnSaveRoot, btnPrimary );
		return !saveBtn.isEnabled();
	}

	/**
	 * To verify save is disabled
	 */
	public void nap( String browser ) {
		if ( browser.equalsIgnoreCase( Constants.SAFARI ) ) {
			SMUtils.nap( 8 );

		}
	}

	/**
	 * To verify 'Calculator' is ON/OFF
	 *
	 * @param status
	 */
	public String getTheStatusOfTheCalculator( String status ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			editCourseFirstColumnElements.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.CALCULATOR ) ).ifPresent(
							elementFinalText -> {
								if ( elementFinalText.equalsIgnoreCase( Constants.CALCULATOR ) ) {
									if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
										element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
										Log.message( "Calculator is visiable as ON" );
										calculatorToggleStatus = Constants.ON_CAPS;
									} else {
										element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
										Log.message( "Calculator is visible as OFF" );
										calculatorToggleStatus = Constants.OFF_CAPS;
									}
								}
							} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return calculatorToggleStatus;
	}

	/**
	 * To verify 'Translate' is ON/OFF
	 *
	 * @param status
	 */
	public String getTheStatusOfTheTranslate( String status ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			editCourseFirstColumnElements.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.TRANSLATE ) ).ifPresent( elementFinalText -> {
						if ( elementFinalText.equalsIgnoreCase( Constants.TRANSLATE ) ) {
							if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
								element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
								Log.message( "Translate is visiable as ON" );
								translateToggleStatus = Constants.ON_CAPS;
							} else {
								element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
								Log.message( "Translate is visible as OFF" );
								translateToggleStatus = Constants.OFF_CAPS;
							}
						}
					} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return translateToggleStatus;
	}

	/**
	 * To verify 'ScratchPad' is ON/OFF
	 *
	 * @param status
	 */
	public String getTheStatusOfTheScratchPad( String status ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			editCourseSecondColumnElements.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.SCRATCHPAD ) ).ifPresent(
							elementFinalText -> {
								if ( elementFinalText.equalsIgnoreCase( Constants.SCRATCHPAD ) ) {
									if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
										element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
										Log.message( "ScratchPad is visiable as ON" );
										scratchpadToggleStatus = Constants.ON_CAPS;
									} else {
										element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
										Log.message( "ScratchPad is visible as OFF" );
										scratchpadToggleStatus = Constants.OFF_CAPS;
									}
								}
							} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return scratchpadToggleStatus;
	}

	/**
	 * To verify 'Show Answer' is ON/OFF
	 *
	 * @param status
	 */
	public String getTheStatusOfTheShowAnswer( String status ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			editCourseSecondColumnElements.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.SHOW_ANSWER ) ).ifPresent(
							elementFinalText -> {
								if ( elementFinalText.equalsIgnoreCase( Constants.SHOW_ANSWER ) ) {
									if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
										element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
										Log.message( "Show Answer is visiable as ON" );
										showAnswerToggleStatus = Constants.ON_CAPS;
									} else {
										element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
										Log.message( "Show Answer is visible as OFF" );
										showAnswerToggleStatus = Constants.OFF_CAPS;
									}
								}
							} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return showAnswerToggleStatus;
	}

	/**
	 * To verify 'Exit Course Button' is ON/OFF
	 *
	 * @param status
	 */
	public String getTheStatusOfTheExitCourse( String status ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			editCourseSecondColumnElements.stream().distinct().forEach(
					element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.EXIT_COURSE_BUTTON ) ).ifPresent(
							elementFinalText -> {
								if ( elementFinalText.equalsIgnoreCase( Constants.EXIT_COURSE_BUTTON ) ) {
									if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
										element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
										Log.message( "Exit Course Button is visiable as ON" );
										exitCourseToggleStatus = Constants.ON_CAPS;
									} else {
										element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
										Log.message( "Exit Course Button is visible as OFF" );
										exitCourseToggleStatus = Constants.OFF_CAPS;
									}
								}
							} ) );
		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return exitCourseToggleStatus;
	}

	/**
	 * To verify 'Spanish Glossary Button' is ON/OFF
	 *
	 * @param status, Course Name
	 */
	public String getTheStatusOfTheSpanishGlossary( String status, String courseName ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			if ( courseName.equals( Constants.READING ) ) {
				editCourseSecondColumnElements.stream().distinct().forEach(
						element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.SPANISH_GLOSSARY ) ).ifPresent(
								elementFinalText -> {
									if ( elementFinalText.equalsIgnoreCase( Constants.SPANISH_GLOSSARY ) ) {
										if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
											element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
											Log.message( "Spanish Glossary Button is visiable as ON" );
											spanishGlossaryToggleStatus = Constants.ON_CAPS;
										} else {
											element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
											Log.message( "Spanish Glossary Button is visible as OFF" );
											spanishGlossaryToggleStatus = Constants.OFF_CAPS;
										}
									}
								} ) );
			}

		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return spanishGlossaryToggleStatus;
	}

	/**
	 * To verify 'Read To Me Button' is ON/OFF
	 *
	 * @param status, Course Name
	 */
	public String getTheStatusOfTheReadToMe( String status, String courseName ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			if ( courseName.equals( Constants.READING ) ) {
				editCourseSecondColumnElements.stream().distinct().forEach(
						element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.READ_TO_ME ) ).ifPresent(
								elementFinalText -> {
									if ( elementFinalText.equalsIgnoreCase( Constants.READ_TO_ME ) ) {
										if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
											element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
											Log.message( "Read To Me Button is visiable as ON" );
											readToMeToggleStatus = Constants.ON_CAPS;
										} else {
											element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
											Log.message( "Read To Me Button is visible as OFF" );
											readToMeToggleStatus = Constants.OFF_CAPS;
										}
									}
								} ) );
			}

		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return readToMeToggleStatus;
	}

	/**
	 * To verify 'Translate Button' is ON/OFF
	 *
	 * @param status, Course Name
	 */
	public String getTheStatusOfTheTranslate( String status, String courseName ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			if ( courseName.equals( Constants.READING ) ) {
				editCourseSecondColumnElements.stream().distinct().forEach(
						element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.TRANSLATE ) ).ifPresent(
								elementFinalText -> {
									if ( elementFinalText.equalsIgnoreCase( Constants.TRANSLATE ) ) {
										if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
											element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
											Log.message( "Translate Button is visiable as ON" );
											translateToggleStatus = Constants.ON_CAPS;
										} else {
											element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
											Log.message( "Translate Button is visible as OFF" );
											translateToggleStatus = Constants.OFF_CAPS;
										}
									}
								} ) );
			}

		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return translateToggleStatus;
	}

	/**
	 * To verify 'Share At District Level Button' is ON/OFF
	 *
	 * @param status, Course Name
	 */
	public String getTheStatusOfTheShareAtDistrictLevel( String status, String courseName ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			if ( courseName.equals( Constants.READING ) ) {
				editCourseSecondColumnElements.stream().distinct().forEach(
						element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.SHARE_AT_DISTRICT_LEVEL ) ).ifPresent(
								elementFinalText -> {
									if ( elementFinalText.equalsIgnoreCase( Constants.SHARE_AT_DISTRICT_LEVEL ) ) {
										if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
											element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
											Log.message( "Share At District Level Button is visiable as ON" );
											sharedAtDistrictLevel = Constants.ON_CAPS;
										} else {
											element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
											Log.message( "Share At District Level Button is visible as OFF" );
											sharedAtDistrictLevel = Constants.OFF_CAPS;
										}
									}
								} ) );
			}

		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return sharedAtDistrictLevel;
	}

	/**
	 * To verify 'Fluency Button' is ON/OFF
	 *
	 * @param status, Course Name
	 */
	public String getTheStatusOfTheFluency( String status, String courseName ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			if ( courseName.equals( Constants.READING ) ) {
				editCourseSecondColumnElements.stream().distinct().forEach(
						element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.FLUENCY ) ).ifPresent(
								elementFinalText -> {
									if ( elementFinalText.equalsIgnoreCase( Constants.FLUENCY ) ) {
										if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
											element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
											Log.message( "Fluency Button is visiable as ON" );
											fluencyToggleStatus = Constants.ON_CAPS;
										} else {
											element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
											Log.message( "Fluency Button is visible as OFF" );
											fluencyToggleStatus = Constants.OFF_CAPS;
										}
									}
								} ) );
			}

		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return fluencyToggleStatus;
	}

	/**
	 * Generic method to verify the setting values
	 *
	 * @param status
	 * @param courseName
	 * @param fieldName
	 */
	public String getTheStatusOfTheFluency( String status, String courseName, String filedName ) {
		SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
		try {
			if ( courseName.equals( Constants.READING ) ) {
				editCourseSecondColumnElements.stream().distinct().forEach(
						element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( Constants.FLUENCY ) ).ifPresent(
								elementFinalText -> {
									if ( elementFinalText.equalsIgnoreCase( Constants.FLUENCY ) ) {
										if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
											element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
											Log.message( "Fluency Button is visiable as ON" );
											fluencyToggleStatus = Constants.ON_CAPS;
										} else {
											element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
											Log.message( "Fluency Button is visible as OFF" );
											fluencyToggleStatus = Constants.OFF_CAPS;
										}
									}
								} ) );
			}

		} catch ( Exception e ) {
			Log.message( "Hidden row detected." );
		}
		return fluencyToggleStatus;
	}

	/**
	 * Click on MSDA popup
	 */
	public void clickMSDAPopup() {
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Please check logs for issue!!" );
		}
		if ( verifyMSDADialogBoxAppear() ) {
			Log.message( "MSDA dialog box is displayed!!" );
			clickContinueToAssignButtonMSDA();
		} else {
			Log.message( "MSDA dialog box is not displayed!!" );
		}
	}

	/**
	 * Verify whether MSDA dialogBox appear
	 */
	public boolean verifyMSDADialogBoxAppear() {
		try {
			Log.message( "Text is " + SMUtils.getTextOfWebElement( msdaTitleElement, driver ) );
			return SMUtils.getTextOfWebElement( msdaTitleElement, driver ).trim().equalsIgnoreCase( "MSDA Auto-Assign Course Conflict" );

		} catch ( Exception e ) {
			Log.message( "The required WebElement not found for MSDA popup" );
			return false;
		}
	}

	/**
	 * Click on the 'Continue to Assign' button of MSDA
	 */
	public void clickContinueToAssignButtonMSDA() {
		SMUtils.fluentWaitForElement( driver, msdaContinueToAssignButtonHost );
		try {
		SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, msdaContinueToAssignButtonHost, "button.primary_button" ) );
		}catch (Exception e) {
			Log.message("continue msda");
		}
	}

	/**
	 * Click on the courses at the home page
	 * 
	 * @param courseName
	 * 
	 */
	public void clickOnTheCourseAtTheHomePage( String courseName ) {
		SMUtils.nap( 20 );
		courseWidgetList.stream().distinct().forEach(
				element -> Optional.ofNullable( element.findElement( By.tagName( "img" ) ).getAttribute( "alt" ).trim() ).filter( elementText -> elementText.equalsIgnoreCase( courseName ) ).ifPresent( elementFinalText -> {
					if ( elementFinalText.equalsIgnoreCase( courseName ) ) {
						Log.message( "WebElement is " + elementFinalText );
						WebElement assignBtn = SMUtils.getWebElementDirect( driver, element.findElement( By.cssSelector( "cel-button.cel-button-assign" ) ), btnPrimary );
						SMUtils.waitForElement( driver, assignBtn, 5 );
						SMUtils.clickJS( driver, assignBtn );

						try {
							SMUtils.waitForSpinnertoDisapper( driver, 60 );
						} catch ( Exception e ) {
							Log.message( "Please check logs for issue!!" );
						}
						if ( verifyMSDADialogBoxAppear() ) {
							Log.message( "MSDA dialog box is displayed!!" );
							clickContinueToAssignButtonMSDA();
						} else {
							Log.message( "MSDA dialog box is not displayed!!" );
						}
						SMUtils.waitForElement( driver, cancelBtnRoot, 5 );
						Log.message( "Assign Button is Clicked" );
					}
				} ) );
	}

	/**
	 * To verify searchtext box
	 * 
	 * @param studentname
	 */
	public void enterStudentNameinSearchField( String studentname ) {
		SMUtils.waitForElement( driver, studentRadioButton, 6 );
		SMUtils.clickJS( driver, studentRadioButton );
		assignPopupTextBox.clear();
		assignPopupTextBox.sendKeys( studentname );
	}

	/**
	 * To Verify Duplicate Course name error message for Default or Focus Courses
	 * 
	 * @param courseName
	 * @param courseType
	 * @param courseNameToCopy
	 * @throws Exception
	 */
	public boolean verifyCourseAlreadyExistsError( String courseNameToCopy ) throws Exception {
		clickFromCourseListingPage( courseNameToCopy );
		clickMakeCopyBtn();
		SMUtils.waitForSpinnertoDisapper(driver, 10);
		SMUtils.nap( 5 );
		enterCourseName( courseNameToCopy );
		SMUtils.waitForElement(driver, makeACopyErrorMessage);
		String error = SMUtils.getTextOfWebElement( makeACopyErrorMessage, driver );
		SMUtils.waitForElement( driver, customNextBtnRoot, 5 );
		WebElement nextBtn = SMUtils.getWebElementDirect( driver, customNextBtnRoot, btnPrimary );
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Please check logs for copyOfCourse spinner issues" );
		}
		if(error.equalsIgnoreCase(Constants.COURSE_NAME_EXISTS_ERROR) && !nextBtn.isEnabled()) {
			Log.message("Course Name Already Exists. Please Choose new course name");
			SMUtils.waitForElement( driver, makeACopyDialogCancelButton );
			clickCancelBtn();
			return true;
		}else {
			Log.message("Course Name is unqiue");
			SMUtils.waitForElement( driver, makeACopyDialogCancelButton );
			clickCancelBtn();
			return false;
		}

	}

	/**
	 * To Verify Make a Copy Dialog Header Text
	 * 
	 * @param courseName
	 * @param courseType
	 * @param courseNameToCopy
	 * @throws Exception
	 */
	public boolean verifyMakeACopyOfCourseHeader( String courseName, String courseType, String courseNameToCopy ) throws Exception {
		clickFromCourseListingPage( courseNameToCopy );
		clickMakeCopyBtn();
		SMUtils.waitForSpinnertoDisapper(driver, 10);
		SMUtils.nap( 5 );
		enterCourseName( courseName );
		coursesRadioBtn( courseType, courseNameToCopy );
		clickNextBtn();
		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( Exception e ) {
			Log.message( "Please check logs for copyOfCourse spinner issues" );
		}
		SMUtils.waitForElement(driver, makeACopyDialogHeader);
		String header = SMUtils.getTextOfWebElement(makeACopyDialogHeader, driver);
		SMUtils.waitForElement( driver, makeACopyDialogCancelButton );
		clickCancelBtn();
		return header.contains(courseName);

	}

	/**
	 * This method is used to create a Reading SM Skill Course with All LOs
	 * 
	 * @param courseName
	 * @param teacherUserName
	 * @param smUrl
	 */
	public void createReadingCustomCourseWithAllSkills(String courseName, String teacherUserName, String smUrl) throws Exception {
		clickFromCourseListingPage( Constants.READING );
		try {
			clickMakeCopyBtn();
			SMUtils.waitForSpinnertoDisapper(driver, 10);
			enterCourseName( courseName );
			clickSkillsRadioBtn();
			SMUtils.waitForSpinnertoDisapper(driver, 10);
			clickNextBtn();
			clickNextBtn();
			Log.message("WebElement List Size  " + allStrands.size());
			try {
				IntStream.range(0,  allStrands.size()).forEach(itr -> SMUtils.clickJS(driver, allStrands.get(itr)) );
				Log.message("All Skills Strands is clicked!!!");
				clickCreateBtn();
				Log.message("Create Course button is clicked!!!");
				SMUtils.waitForSpinnertoDisapper(driver, 10);
				SMUtils.nap( 5 );

			} catch (Exception e) {
				Log.message("Skills Strands is clicked!!!");
				clickCreateBtn();
				Log.message("Create Course button is clicked!!!");
				SMUtils.waitForSpinnertoDisapper(driver, 10);
				SMUtils.nap( 5 );
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

	}


	/**
	 * This method is used to create a Reading AimswebPlus Standard Course with All LOs
	 * 
	 * @param courseName
	 * @param teacherUserName
	 * @param smUrl
	 */
	public void createReadingCustomCourseWithAllStandards(String courseName, String teacherUserName, String smUrl) throws Exception {
		clickFromCourseListingPage( Constants.READING );
		try {
			clickMakeCopyBtn();
			SMUtils.waitForSpinnertoDisapper(driver, 10);
			enterCourseName( courseName );
			clickStandardsRadioBtn();
			SMUtils.waitForSpinnertoDisapper(driver, 10);
			clickNextBtn();
			clickNextBtn();
			Log.message("WebElement List Size  " + allStrands.size());
			try {
				IntStream.range(0,  allStrands.size()).forEach(itr -> SMUtils.clickJS(driver, allStrands.get(itr)) );
				Log.message("All Skills Strands is clicked!!!");
				clickCreateBtn();
				Log.message("Create Course button is clicked!!!");
				SMUtils.waitForSpinnertoDisapper(driver, 10);
				SMUtils.nap( 5 );

			} catch (Exception e) {
				Log.message("Skills Strands is clicked!!!");
				clickCreateBtn();
				Log.message("Create Course button is clicked!!!");
				SMUtils.waitForSpinnertoDisapper(driver, 10);
				SMUtils.nap( 5 );
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

	}
	
	/**
	 * To verify course presence
	 *
	 * @param courseName
	 * @throws Exception
	 */

	public boolean verifyCoursePresence( String courseName ) throws Exception {
		SMUtils.nap( 5 );
		boolean isCoursePresent = false;
		try {
			for ( WebElement eachCourse : listOfCourses ) {
				String courseNameFromUI = eachCourse.getText().trim();
				if ( courseNameFromUI.equals( courseName ) ) {
					isCoursePresent = true;
					break;
				}
			}
		} catch ( Exception e ) {
			Log.exception( e );
		}
		
		return isCoursePresent;
	}


}