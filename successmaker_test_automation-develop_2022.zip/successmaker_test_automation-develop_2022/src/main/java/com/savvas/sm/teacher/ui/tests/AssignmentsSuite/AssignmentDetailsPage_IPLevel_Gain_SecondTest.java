package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners(EmailReport.class)
public class AssignmentDetailsPage_IPLevel_Gain_SecondTest extends BaseTest {
	private String smUrl;
	private String browser;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private static String username = null;
	private static String password = null;
	String teacherDetails;
	String studentDetails;
	String studentDetails1;
	private String chromePlatform = "Windows_10_Chrome_latest"; // for Simulator Execution
	String staticCourseName = null;
	TeacherHomePage tHomePage;
	LoginPage smLoginPage;
	private String stuFName;
	private String stuUserName;
	private String stuUserName1;
	private String completeStudentName;
	private String teacherID;
	private HashMap<String, String> groupDetails = new HashMap<>();
	private static List<String> studentRumbaIds = new ArrayList<>();
	private String token = null;
	String CUSTOM_BY_SETTINGS_MATH_COURSE = Constants.CUSTOM_BY_SETTINGS_MATH_COURSE + System.nanoTime();

	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		studentDetails = RBSDataSetup.getMyStudent(school, username);
		stuUserName = SMUtils.getKeyValueFromResponse(studentDetails, "userName");
		studentDetails1 = RBSDataSetup.getMyStudent(school, username);
		stuUserName1 = SMUtils.getKeyValueFromResponse(studentDetails1, "userName");
		stuFName = SMUtils.getKeyValueFromResponse(studentDetails, "firstName");

		// token creation
		token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(teacherDetails, "userName"),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		// Group
		String groupName = "GroupNo_" + System.nanoTime();
		groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		groupDetails.put(GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetails.put(GroupConstants.GROUP_NAME, groupName);
		String groupId = SMUtils.getKeyValueFromResponse(
				new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds).get(Constants.REPORT_BODY),
				"data,groupId");
	}

	@Test(description = "Verify that %Correct is -- when the student has not started working on an assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 2)
	public void tcAssignmentDetailsIPGain021() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		SMUtils.logDescriptionTC(
				"SMK-11046: Verify that %Correct is -- when the student has not started working on an assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get CourseLising Page
			CourseListingPage courseListingPage = new CourseListingPage(driver);
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName() + System.nanoTime();

			// navigate to Course Listing Page
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Create Reading custom setting course
			coursePage.clickReadingCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(staticCourseName);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();
			coursePage.clickCreateBtn();

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),
					"Assignment Title is displayed", "Assignment Title is not displayed");
			Log.assertThat(
					assignmentDetailsPage.percentCorrectValueChecking(firstStudentName)
							.equals(Constants.NOT_STARTED_VALUE),
					"%Correct is -- when the student has not started working on the assignment",
					"%Correct is not -- when the student has not started working on the assignment");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the values displayed in assignment details page when a student has started working on an assignment for Default Reading course", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 2)
	public void tcAssignmentDetailsIPGain022() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
		// Get Test Data
		SMUtils.logDescriptionTC(
				"SMK-11011: Verify that when a student has started working on an assignment but does not have any fluency files generated, Fluency Files option is displaying Fluency Files(0)<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// Get CourseLising Page
			CourseListingPage courseListingPage = new CourseListingPage(driver);

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			coursePage.clickReadingCourse();
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			Log.message("The subject name is " + Constants.READING);

			// Executing Reading in student dashboard
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);
			
			String studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, "userName");

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUsername,
					password);
			StudentDashboardPage studentDashboardPage = new StudentDashboardPage(studentDriver);

			// Course Execution
			// Need to attend 150 questions to clear IP. Each iteration has 50 questions. So
			// Gave count as 4 and total questions is 200.
			IntStream.rangeClosed(1, 4).forEach(value -> {
				Log.message("Math Custom Course Execution");

				try {
					studentDashboardPage.executeReadingCourse(
							SMUtils.getKeyValueFromResponse(teacherDetails, "userId"), Constants.READING, "95",
							"2", "25");
				} catch (IOException e) {
					Log.message("Error occurred while running the simulator");
				}

			});
			studentDashboardPage.logout();
			studentDriver.quit();

			// Navigate to teacher page again
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(Constants.READING);

			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(Constants.READING),
					"Assignment Title is displayed", "Assignment Title is not displayed");

			// Clicking on Ellipsis icon at the student level
			assignmentDetailsPage.clickDotEllipsisButton();
			Log.assertThat(assignmentDetailsPage.fluencyFilesInEllipsis().contains(Constants.FLUENCY_FILES),
					"Fluency Files option is displaying Fluency Files(0)",
					"Fluency Files option is not displaying Fluency Files(0)");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"SMK-11039 - Verify that the gain displayed in the assignment details page is displayed correctly (Gain= Current Level - IP Level) for a student who has started working on the assignment and has passed the IP for the default Reading Course<small><b><i>[\" + browser + \"]</b></i></small>");
			String studentName = assignmentDetailsPage.getStudentName(
					SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));
			Log.assertThat(
					assignmentDetailsPage.gainValueCalculationChecking(studentName)
							.equals(assignmentDetailsPage.gainValueChecking(studentName)),
					"Gain displayed in the assignment details page is displayed correctly (Gain= Current Level - IP Level) for a student who has started working on the assignment and has passed the IP for the default Reading Course",
					"Gain displayed in the assignment details page is not displayed correctly for a student who has started working on the assignment and has passed the IP for the default Reading Course");
			Log.testCaseResult();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the IP level and Gain for the Reading and Math custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 2)
	public void tcAssignmentDetailsIPGain023() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		SMUtils.logDescriptionTC(
				"SMK-11029: Verify that the IP level is NA for the Reading and Math custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			String customSettingCourseMath = Constants.CUSTOM_MATH_ASSIGMENT_TITLE + System.nanoTime();
			String customSettingCourseReading = Constants.CUSTOM_READING_ASSIGMENT_TITLE + System.nanoTime();

			// navigate to Course Listing Page
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// Get CourseLising Page
			CourseListingPage courseListingPage = new CourseListingPage(driver);

			// Select Default Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Create Math custom setting course with IP Off
			coursePage.clickMathCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(customSettingCourseMath);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();
			coursePage.turnOffInitialPlacement();
			coursePage.clickCreateBtn();

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(customSettingCourseMath);
			coursePage.clickCourseName(customSettingCourseMath);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			tHomePage.topNavBar.navigateToCourseListingPage();

			// Select Default Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Create Reading custom setting course with IP Off
			coursePage.clickReadingCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(customSettingCourseReading);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();
			coursePage.turnOffInitialPlacement();
			coursePage.clickCreateBtn();

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(customSettingCourseReading);
			coursePage.clickCourseName(customSettingCourseReading);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			driver.quit();

			// Executing math assignments in student dashboard
			executeSimulator(customSettingCourseMath, Constants.MATH);

			// Executing reading assignments in student dashboard
			executeSimulator(customSettingCourseReading, Constants.READING);

			// Navigate to teacher page again		
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page
					.viewAssignmentDetailsByAssignmentName(customSettingCourseMath);
			String studentName = assignmentDetailsPage.getStudentName(
					SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));

			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(customSettingCourseMath),
					"Assignment Title is displayed", "Assignment Title is not displayed");

			Log.assertThat(
					assignmentDetailsPage.ipLevelValueChecking(studentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"IP level is NA for the Math custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment",
					"IP level is not NA for the Math custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"SMK-11032 - Verify that the Gain is some non zero numeric value(Eg- 1.00) for the Math custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment and made some progress<small><b><i>[\" + browser + \"]</b></i></small>");
			Log.assertThat(
					assignmentDetailsPage.checkDecimalValue(assignmentDetailsPage.gainValueChecking(studentName)),
					"Gain is displayed as some numeric values(eg. 1.00) for the Math custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment and has made some progress",
					"Gain is not displayed as some numeric values(eg. 1.00) for the Math custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment and has made some progress");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"SMK-11040 - Verify that for Custom Math Course By Setting where IP-> OFF, the Gain is displayed correctly(Gain= Current Level- Assigned Level) when the student has started working on the assignment and made some progress<small><b><i>[\" + browser + \"]</b></i></small>");
			Log.assertThat(
					assignmentDetailsPage.checkDecimalValue(assignmentDetailsPage.gainValueChecking(studentName)),
					"Gain is displayed correctly(Gain= Current Level- Assigned Level) when the student has started working on the assignment and made some progress",
					"Gain is not displayed correctly(Gain= Current Level- Assigned Level) when the student has started working on the assignment and made some progress");
			Log.testCaseResult();

			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			page.viewAssignmentDetailsByAssignmentName(customSettingCourseReading);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(customSettingCourseReading),
					"Assignment Title is displayed", "Assignment Title is not displayed");

			Log.assertThat(
					assignmentDetailsPage.ipLevelValueChecking(studentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"IP level is NA for the Reading custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment",
					"IP level is not NA for the Reading custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"SMK-11032 - Verify that the Gain is some non zero numeric value(Eg- 1.00) for the Reading custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment and made some progress<small><b><i>[\" + browser + \"]</b></i></small>");
			Log.assertThat(
					assignmentDetailsPage.checkDecimalValue(assignmentDetailsPage.gainValueChecking(studentName)),
					"Gain is displayed as some numeric values(eg. 1.00) for the Reading custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment and has made some progress",
					"Gain is not displayed as some numeric values(eg. 1.00) for the Reading custom course by settings when the Initial Placement(IP) setting is OFF and student has started working on the assignment and has made some progress");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"SMK-11041 - Verify that for Custom Reading Course By Setting where IP-> OFF, the Gain is displayed correctly(Gain= Current Level- Assigned Level) when the student has started working on the assignment and made some progress<small><b><i>[\" + browser + \"]</b></i></small>");
			Log.assertThat(
					assignmentDetailsPage.checkDecimalValue(assignmentDetailsPage.gainValueChecking(studentName)),
					"Gain is displayed correctly(Gain= Current Level- Assigned Level) when the student has started working on the assignment and made some progress",
					"Gain is not displayed correctly(Gain= Current Level- Assigned Level) when the student has started working on the assignment and made some progress");
			Log.testCaseResult();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the IP level and Gain is displayed as some numeric values(eg. 4.00) for the Reading and Math Default courses, custom course by settings when the Initial Placement(IP) setting is ON and student has started working on the assignment and has made some progress", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 2)
	public void tcAssignmentDetailsIPGain024() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		SMUtils.logDescriptionTC(
				"SMK-11031 : Verify that the IP level is displayed as some numeric values(eg. 4.00) for the Reading and Math Default courses, custom course by settings when the Initial Placement(IP) setting is ON and student has started working on the assignment and has made some progress<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// Get CourseLising Page
			CourseListingPage courseListingPage = new CourseListingPage(driver);

			// Select Default Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// create Math custom course by Skills
			coursePage.copyOfCourse(CUSTOM_BY_SETTINGS_MATH_COURSE, Constants.SETTINGS, Constants.MATH);

			// Assigning Course to student
			coursePage.clickCourseName(CUSTOM_BY_SETTINGS_MATH_COURSE);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			driver.quit();

			// Executing Math in student dashboard                 
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

			String studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, "userName");
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUsername,
					password);

			StudentDashboardPage studentDashboardPage = new StudentDashboardPage(studentDriver);

			// Course Execution
			// Need to attend 150 questions to clear ip. Each interation 50 Questions. So
			// Gave count as 4 and total questions is 200.
			IntStream.rangeClosed(1, 4).forEach(value -> {
				Log.message("Math Custom Course Execution");
				try {
					studentDashboardPage.executeMathCourse(
							SMUtils.getKeyValueFromResponse(teacherDetails, "userId"),
							CUSTOM_BY_SETTINGS_MATH_COURSE, "95", "2", "25");
				} catch (IOException e) {
					Log.message("Error occurred while running the simulator");
				}

			});
			studentDashboardPage.logout();
			studentDriver.quit();

			// Navigate to teacher page again
			// Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page
					.viewAssignmentDetailsByAssignmentName(CUSTOM_BY_SETTINGS_MATH_COURSE);
			String studentName = assignmentDetailsPage.getStudentName(
					SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));
			Log.assertThat(
					assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(CUSTOM_BY_SETTINGS_MATH_COURSE),
					"Assignment Title is displayed", "Assignment Title is not displayed");
			Log.assertThat(
					assignmentDetailsPage.checkDecimalValue(assignmentDetailsPage.ipLevelValueChecking(studentName)),
					"IP level is displayed as some numeric values(eg. 4.00) for the Reading and Math Default courses, custom course by settings when the Initial Placement(IP) setting is ON and student has started working on the assignment and has made some progress",
					"IP level is not displayed as some numeric values(eg. 4.00) for the Reading and Math Default courses, custom course by settings when the Initial Placement(IP) setting is ON and student has started working on the assignment and has made some progress");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"SMK-11033 - Verify that the Gain is some non zero numeric value(Eg- 1.00) for the Reading and Math Default courses, custom course by settings when the Initial Placement(IP) setting is ON and student has started working on the assignment and made some progress<small><b><i>[\" + browser + \"]</b></i></small>");
			Log.assertThat(
					assignmentDetailsPage.checkDecimalValue(assignmentDetailsPage.gainValueChecking(studentName)),
					"Gain is displayed as some numeric values(eg. 1.00) for the Math Default courses, custom course by settings when the Initial Placement(IP) setting is ON and student has started working on the assignment and has made some progress",
					"Gain is not displayed as some numeric values(eg. 1.00) for the Math Default courses, custom course by settings when the Initial Placement(IP) setting is ON and student has started working on the assignment and has made some progress");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"SMK-11038 - Verify that the gain displayed in the assignment details page is displayed correctly (Gain= Current Level - IP Level) for a student who has started working on the assignment and has passed the IP for the default Math Course<small><b><i>[\" + browser + \"]</b></i></small>");
			Log.assertThat(
					assignmentDetailsPage.gainValueCalculationChecking(studentName)
							.equals(assignmentDetailsPage.gainValueChecking(studentName)),
					"Gain displayed in the assignment details page is displayed correctly (Gain= Current Level - IP Level) for a student who has started working on the assignment and has passed the IP for the default Math Course",
					"Gain displayed in the assignment details page is not displayed correctly for a student who has started working on the assignment and has passed the IP for the default Math Course");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"SMK-11047 - Verify that %Correct is some numeric value(Eg: 65%) when the student has started working on an assignment");
			Log.assertThat(assignmentDetailsPage.percentageCorrectValueChecking(studentName),
					"%Correct is some numeric value(Eg: 65%) when the student has started working on an assignment",
					"%Correct is not a numeric value(Eg: 65%) when the student has started working on an assignment");
			Log.testCaseResult();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the Current level is -- for Default Courses/ Custom Math/Reading By Settings courses when the student has not started working on the assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 2)
	public void tcAssignmentDetailsIPGain025() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		SMUtils.logDescriptionTC(
				"SMK-11044: Verify that the Current level is -- for Default Courses/ Custom Math/Reading By Settings courses when the student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// navigate to Course Listing Page
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			// Get CourseLising Page
			CourseListingPage courseListingPage = new CourseListingPage(driver);

			// Select Default Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Create Reading custom setting course
			coursePage.clickReadingCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(staticCourseName);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();
			coursePage.clickCreateBtn();

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courses Tab
			tHomePage.topNavBar.navigateToCourseListingPage();

			// Select Default Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			coursePage.clickMathCourse();
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),
					"Assignment Title is displayed", "Assignment Title is not displayed");
			Log.assertThat(
					assignmentDetailsPage.currentLevelValueChecking(firstStudentName)
							.equals(Constants.NOT_STARTED_VALUE),
					"Current Level is -- for Custom Course when the student has not started working on the assignment",
					"Current Level is not -- for Custom Course when the student has not started working on the assignment");

			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			page.viewAssignmentDetailsByAssignmentName(Constants.MATH);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(Constants.MATH),
					"Assignment Title is displayed", "Assignment Title is not displayed");
			Log.assertThat(
					assignmentDetailsPage.currentLevelValueChecking(firstStudentName)
							.equals(Constants.NOT_STARTED_VALUE),
					"Current Level is -- for Default Course when the student has not started working on the assignment",
					"Current Level is not -- for Default Course when the student has not started working on the assignment");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify tooltip is displayed for the Assignment Title and Student names when we hover the cursor over them.", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 3)
	public void tcAssignmentDetailsIPGain026() throws Exception {
		Log.testCaseInfo(
				"SMK-11044: Verify tooltip is displayed for the Assignment Title and Student names when we hover the cursor over them.<small><b><i>["
						+ browser + "]</b></i></small>");
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			SMUtils.logDescriptionTC(
					"SMK-11044: Verify that the Current level is -- for Default Courses/ Custom Math/Reading By Settings courses when the student has not started working on the assignment<small><b><i>["
							+ browser + "]</b></i></small>");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);

			Log.assertThat(assignmentDetailsPage.isToolTipDisplayedForAssignmentTitle(),
					"Tooltip displayed for assignment", "Tooltip not displayed for assignment");
			String firstStudentsName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.isTooltipforStudentNameDisplayed(),
					"Tooltip displayed for student name", "Tooltip not displayed for student name");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify when you click on the Fluency Files(x) option from the Ellipsis menu for a student, Fluency File Popup is displayed.", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 3)
	public void tcAssignmentDetailsIPGain027() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo(
				"tcAssignmentDetailsIPGain027: SMK-11010: Verify when you click on the Fluency Files(x) option from the Ellipsis menu for a student, Fluency File Popup is displayed.<small><b><i>["
						+ browser + "]</b></i></small>");
		String studentFirstName;
		String studentMiddleName;
		String studentLastName;
		try {
			// Verification for 1st student
			studentFirstName = SMUtils.getKeyValueFromResponse(studentDetails, "firstName");
			studentMiddleName = SMUtils.getKeyValueFromResponse(studentDetails, "middleName");
			studentLastName = SMUtils.getKeyValueFromResponse(studentDetails, "lastName");

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			completeStudentName = assignmentDetailsPage.completeStudentName(studentFirstName, studentMiddleName,
					studentLastName);
			assignmentDetailsPage.fluencyFilesInEllipsisFromStudent(completeStudentName, true);

			Log.assertThat(
					assignmentDetailsPage.getFluencyFilePopupHeader()
							.equalsIgnoreCase(completeStudentName + "'s Fluency Files"),
					"Fluency file popup loaded", "Fluency file popup not loaded.");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that while the skills tested tab is open for a student, when you click on the - icon near the student name, the tab is collapsed", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 3)
	public void tcAssignmentDetailsIPGain028() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo(
				"tcAssignmentDetailsIPGain028: SMK-11016: Verify that while the skills tested tab is open for a student, when you click on the - icon near the student name, the tab is collapsed<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),
					"Assignment Title is displayed", "Assignment Title is not displayed");

			// Click on Assignment Settings for first student
			String firstStudentsName = assignmentDetailsPage.getFirstStudentsName();
			assignmentDetailsPage.clickStudentAccordionButton(firstStudentsName);
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(), "Skills Tested Tab is displayed",
					"Skills Tested Tab is not displayed");
			assignmentDetailsPage.collapseSkillTested();
			Log.assertThat(!(assignmentDetailsPage.isSkillTestedExpanded()), "Skills Tested Tab is collapsed",
					"Skills Tested Tab is not collapsed");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that for a student who has started working on the assignment and made some progress, the Skills Tested tab is displaying graphical data.", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 3)
	public void tcAssignmentDetailsIPGain029() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo(
				"tcAssignmentDetailsIPGain029: SMK-11017: Verify that for a student who has started working on the assignment and made some progress, the Skills Tested tab is displaying graphical data<small><b><i>["
						+ browser + "]</b></i></small>");
		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page
					.viewAssignmentDetailsByAssignmentName(CUSTOM_BY_SETTINGS_MATH_COURSE);
			Log.assertThat(
					assignmentDetailsPage.gettitleOfAssignmentDetailsPage()
							.equals(CUSTOM_BY_SETTINGS_MATH_COURSE),
					"Assignment Title is displayed", "Assignment Title is not displayed");

			// Click on Assignment Settings for student
			String studentName = assignmentDetailsPage.getStudentName(
					SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));
			assignmentDetailsPage.clickStudentAccordionButton(studentName);
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(), "Skills Tested Tab is displayed",
					"Skills Tested Tab is not displayed");
			Log.assertThat(assignmentDetailsPage.isSkillTestedGraphDisplayed(), "Skills Tested Graph is displayed",
					"Skills Tested Graph is not displayed");
			assignmentDetailsPage.collapseSkillTested();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the IP level is NA for the Focus courses, custom courses by skills and custom courses by standard when the student has started the assignment and made some progress", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 3)
	public void tcAssignmentDetailsIPGain030() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		SMUtils.logDescriptionTC(
				"SMK-11024 : Verify that the IP level is NA for the Focus courses, custom courses by skills and custom courses by standard when the student has started the assignment and made some progress<small><b><i>["
						+ browser + "]</b></i></small>");
		SMUtils.logDescriptionTC(
				"SMK-11026 : Verify that the Gain is NA for the Focus courses, custom courses by skills and custom courses by standard when the student has started the assignment and made some progress <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// Get CourseLising Page
			CourseListingPage courseListingPage = new CourseListingPage(driver);

			// Select Default Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			String CUSTOM_BY_SKILLS_MATH_COURSE = Constants.CUSTOM_BY_SKILLS_MATH_COURSE + System.nanoTime();
			// create Math custom course by Skills
			coursePage.clickMathCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(CUSTOM_BY_SKILLS_MATH_COURSE);
			coursePage.coursesRadioBtn(Constants.SKILLS, CUSTOM_BY_SKILLS_MATH_COURSE);
			coursePage.courseBasedOnSkills(Constants.SKILLS, Constants.MATH);

			// Assigning Course to student
			coursePage.clickCourseName(CUSTOM_BY_SKILLS_MATH_COURSE);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// Select Default Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			String CUSTOM_BY_STANDARDS_MATH_COURSE = Constants.CUSTOM_BY_STANDARDS_MATH_COURSE + System.nanoTime();
			// create Math custom course by Standards
			coursePage.clickMathCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(CUSTOM_BY_STANDARDS_MATH_COURSE);
			coursePage.coursesRadioBtn(Constants.STANDARDS, CUSTOM_BY_STANDARDS_MATH_COURSE);
			coursePage.courseBasedOnDefaultOrFocusMathStandards(Constants.STANDARDS, Constants.MATH);

			// Assigning Course to students
			coursePage.clickCourseName(CUSTOM_BY_STANDARDS_MATH_COURSE);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Assigning Focus Course to student
			coursePage.clickCourseName(Constants.READING_FOCUS_COURSE_TITLE);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			// SignOut
			tHomePage.topNavBar.signOutfromSM();
			driver.quit();
		
			// Get driver
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

			String studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, "userName");
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUsername,
					password);

			StudentDashboardPage studentDashboardPage = new StudentDashboardPage(studentDriver);

			// Course Execution
			IntStream.rangeClosed(1, 2).forEach(value -> {
				Log.message("Math Custom Course By Skills Execution");
				try {
					studentDashboardPage.executeMathCourse(teacherID, CUSTOM_BY_SKILLS_MATH_COURSE, "95", "2", "25");
				} catch (IOException e) {
					Log.message("Error occurred while running the simulator");

				}

			});

			// Course Execution
			IntStream.rangeClosed(1, 2).forEach(value -> {
				Log.message("Math Custom Course By Standards Execution");
				try {
					studentDashboardPage.executeMathCourse(teacherID, CUSTOM_BY_STANDARDS_MATH_COURSE, "95", "2", "25");
				} catch (IOException e) {
					Log.message("Error occurred while running the simulator");

				}

			});

			// Course Execution
			IntStream.rangeClosed(1, 2).forEach(value -> {
				Log.message("Reading Focus Course Execution");
				try {
					studentDashboardPage.executeReadingCourse(teacherID, Constants.READING_FOCUS_COURSE_TITLE, "100",
							"2", "25");
				} catch (IOException e) {
					Log.message("Error occurred while running the simulator");

				}

			});
			// Logout
			studentDashboardPage.logout();
			studentDriver.quit();

			// Navigate to teacher page again		
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);


			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page
					.viewAssignmentDetailsByAssignmentName(CUSTOM_BY_SKILLS_MATH_COURSE);
			String studentName = assignmentDetailsPage.getStudentName(
					SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));
			Log.message(studentName);
			Log.message(assignmentDetailsPage.ipLevelValueChecking(studentName));
			Log.assertThat(
					assignmentDetailsPage.ipLevelValueChecking(studentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"IP level is NA for the Custom By Skills courses and student has started working on the assignment",
					"IP level is not NA for the Custom By Skills courses and student has started working on the assignment");
			Log.assertThat(assignmentDetailsPage.gainValueChecking(studentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"Gain is NA for the Custom By Skills courses and student has started working on the assignment",
					"Gain is not NA for the Custom By Skills courses and student has started working on the assignment");

			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			page.viewAssignmentDetailsByAssignmentName(CUSTOM_BY_STANDARDS_MATH_COURSE);
			Log.assertThat(
					assignmentDetailsPage.ipLevelValueChecking(studentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"IP level is NA for the Custom By Standard courses and student has started working on the assignment",
					"IP level is not NA for the Custom By Standard courses and student has started working on the assignment");
			Log.assertThat(assignmentDetailsPage.gainValueChecking(studentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"Gain is NA for the Custom By Standard courses and student has started working on the assignment",
					"Gain is not NA for the Custom By Standard courses and student has started working on the assignment");

			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
//			page.viewAssignmentDetailsByAssignmentName(Constants.READING_FOCUS_COURSE_TITLE);
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Constants.READING_FOCUS_COURSE_TITLE);
			Log.assertThat(
					assignmentDetailsPage.ipLevelValueChecking(studentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"IP level is NA for the Focus courses and student has started working on the assignment",
					"IP level is not NA for the Focus courses and student has started working on the assignment");
			Log.assertThat(assignmentDetailsPage.gainValueChecking(studentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"Gain is NA for the Focus courses and student has started working on the assignment",
					"Gain is not NA for the Focus courses and student has started working on the assignment");
			SMUtils.logDescriptionTC(
					"SMK-11043 : Verify that the Current level is NA for the Focus Courses when the student has started working on the assignment and made some progress<small><b><i>["
							+ browser + "]</b></i></small>");
			Log.assertThat(
					assignmentDetailsPage.currentLevelValueChecking(studentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"Current Level is NA for Focus Course when the student has started working on the assignment",
					"Current Level is not NA for Focus courses when the student has started working on the assignment");

			// Sign Out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that when we click on Pause all students, the assignment is paused for all students listed on the assignment details page", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 3)
	public void tcAssignmentDetailsIPGain031() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


		SMUtils.logDescriptionTC(
				"SMK-11037 : Verify that when we click on Pause all students, the assignment is paused for all students listed on the assignment details page"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
		SMUtils.logDescriptionTC(
				"SMK-11036 : Verify that for the student who completed the assignment, the Pause tag appears in Gray color on the left side of Completed tag under the student name if the assignment is paused for the student <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursepage = new CoursesPage(driver);
			staticCourseName = coursepage.generateRandomCourseName();

			// Get Assignments Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Default Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// create Math custom course by settings
			coursepage.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Assigning Course to student
			coursepage.clickCourseName(staticCourseName);
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);

			// Verify Pause All Student
			assignmentDetailsPage.pauseAllStudent();
			assignmentDetailsPage.pauseButtonFoAllSTudent();
			SMUtils.nap(5);// Waiting for toast message disappear

			// Verify the assignment got pause
			Log.assertThat(Boolean.TRUE.equals(assignmentDetailsPage.isAssignmentPausedatAssignmentLevel()),
					"Assignment paused for all successfully", "Assignment has not Paused");
			Log.assertThat(assignmentDetailsPage.checkPausedTag(), "Paused tag displayed", "Paused tag not displayed");
			Log.assertThat(assignmentDetailsPage.checkPausedTagColor().equals(Constants.PAUSED_COLOR),
					"Paused tag displayed in correct color", "Paused tag not displayed correctly");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		}

		catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "SMK-11005 : Verify that the sorting functionality is working for all the columns displayed in assignment details page.", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 3)
	public void tcAssignmentDetailsIPGain032() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tcAssignmentDetailsIPGain032: SMK-11005: Verify that the sorting functionality is working for all the columns displayed in assignment details page."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {

			// Get driver
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			studentDriver.register(eventListner);

			String studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, "userName");

			// Login as Student into Student dashBoard
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUsername,
					password);
			StudentDashboardPage stuPage = new StudentDashboardPage(studentDriver);

			// Course Execution
			IntStream.rangeClosed(1, 3).forEach(value -> {
				Log.message("Math Custom Course Execution");
				try {
					stuPage.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "userId"),
							CUSTOM_BY_SETTINGS_MATH_COURSE, "100", "2", "25");
				} catch (IOException e) {
					Log.message("Error occurred while running the simulator");
				}

			});
			// Logout
			stuPage.logout();
			studentDriver.quit();

			// Navigate to teacher page again		
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page
					.viewAssignmentDetailsByAssignmentName(Constants.CUSTOM_BY_SETTINGS_MATH_COURSE);
			Log.assertThat(
					assignmentDetailsPage.gettitleOfAssignmentDetailsPage()
							.equals(CUSTOM_BY_SETTINGS_MATH_COURSE),
					"Assignment Title is displayed", "Assignment Title is not displayed");
			SMUtils.logDescriptionTC("SMK-11052 : Verify the sorting order of 'IP Level' column"
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignmentDetailsPage.clickColumnnAndSort(Constants.IP_LEVEL, Constants.ASCENDING);
			String arrowOrder = assignmentDetailsPage.getArrowStateOfColumn();
			Log.assertThat(arrowOrder.equals(Constants.ASCENDING), "IP Level Sorted in Ascending order", "Not sorted");
			SMUtils.logDescriptionTC("SMK-11053 : Verify the sorting order of 'Gain' column"
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignmentDetailsPage.clickColumnnAndSort(Constants.GAIN, Constants.ASCENDING);
			arrowOrder = assignmentDetailsPage.getArrowStateOfColumn();
			Log.assertThat(arrowOrder.equals(Constants.ASCENDING), "Gain Sorted in Ascending order", "Not sorted");
			SMUtils.logDescriptionTC("SMK-11050 : Verify the sorting order of 'Current Level' column"
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignmentDetailsPage.clickColumnnAndSort(Constants.CURRENT_LEVEL, Constants.ASCENDING);
			arrowOrder = assignmentDetailsPage.getArrowStateOfColumn();
			Log.assertThat(arrowOrder.equals(Constants.ASCENDING), "Current Level Sorted in Ascending order",
					"Not sorted");
			SMUtils.logDescriptionTC("SMK-11051 : Verify the tooltip text displays for 'IP Level' and 'Gain' columns"
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			Log.assertThat(assignmentDetailsPage.isTooltipDisplayedForIp(), "Tooltip is displayed for IP Level",
					"Not displayed");
			Log.assertThat(assignmentDetailsPage.isTooltipDisplayedForGain(), "Tooltip is displayed for Gain",
					"Not displayed");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	public void executeSimulator(String assignmentName, String assignmentType) throws Exception {
       	// Get driver
		EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		studentDriver.register(eventListner);
		String studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, "userName");

		// Login to the SM_Application
		LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUsername,
				password);
		StudentDashboardPage studentDashboardPage = new StudentDashboardPage(studentDriver);

		try {
			if (assignmentType.equals(Constants.MATH)) {
				IntStream.rangeClosed(1, 4).forEach(value -> {
					Log.message("Course Execution");
					try {
						studentDashboardPage.executeMathCourse(
								SMUtils.getKeyValueFromResponse(teacherDetails, "userId"), assignmentName, "95",
								"2", "25");
					} catch (IOException e) {
						Log.message("Error occurred while running the simulator");
					}

				});

			} else {
				studentDashboardPage.executeReadingCourse(
						SMUtils.getKeyValueFromResponse(teacherDetails, "userId"), assignmentName, "100", "1",
						"10");
			}
		} catch (IOException e) {

			Log.message("Error occurred while running the simulator");
		}
		studentDriver.quit();
	}

}
