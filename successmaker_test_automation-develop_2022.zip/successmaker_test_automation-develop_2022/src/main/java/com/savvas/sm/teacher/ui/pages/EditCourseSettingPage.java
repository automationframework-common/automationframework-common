package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class EditCourseSettingPage extends LoadableComponent<EditCourseSettingPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    private WebDriver driver;
    boolean isPageLoaded;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    // *********  Page Elements ***************

    @FindBy ( css = "span.tile__title" )
    List<WebElement> courseName;

    @FindBy ( css = "div[class='tile__body'] .tile__title.tile__tooltip" )
    List<WebElement> listOfCustomCourses;

    @IFindBy ( how = How.CSS, using = "cel-button.edit-btn.hydrated", AI = false )
    public WebElement editBtnHost;

    @IFindBy ( how = How.CSS, using = ".cancel-button", AI = false )
    public WebElement cancelEditCoursePopUpBtnHost;

    @FindBy ( css = "div[class='first column'] .setting-wrapper .setting-label" )
    List<WebElement> listOfFirstColumnSections;

    @FindBy ( css = "div[class='second column'] .setting-label" )
    List<WebElement> listOfSecondColumnSections;

    @IFindBy ( how = How.CSS, using = "div[class='tile'] .tile__body>span[class='tile__title tile__tooltip']", AI = false )
    public WebElement pageTitle;

    @IFindBy ( how = How.CSS, using = "cel-button:not([class=cancel-button])[class=hydrated]", AI = false )
    public WebElement btnSaveHost;

    @IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
    public WebElement editSettingsPopUpTitle;

    @IFindBy ( how = How.CSS, using = "button.switch-button.toggle-on.ng-star-inserted", AI = false )
    public WebElement ToggleButton;

    @IFindBy ( how = How.CSS, using = "cel-button.edit-btn.hydrated", AI = false )
    public WebElement editShadowHostCssSelector;

    @FindBy ( css = "div [class='second column'] .toggle-control-wrapper" )
    List<WebElement> editCourseSecondColumnElements;

    @IFindBy ( how = How.CSS, using = "cel-multi-check-dropdown.hydrated", AI = false )
    public WebElement languageDropDownShadowHost;

    @IFindBy ( how = How.CSS, using = "edit-settings > div.container.course-settings.ng-star-inserted > div > div.first.column > div>div>div", AI = false )
    WebElement languageDropDownInvisible;

    @IFindBy ( how = How.CSS, using = ".cancel-button.hydrated", AI = false )
    public WebElement CancelEditCoursePopupButton;

    @FindBy ( css = "cel-dropdown-select > div > div > ul>li" )
    List<WebElement> SessionLengthValues;

    @FindBy ( css = "li.dropdown-option span" )
    List<WebElement> SessionLengthDropdownOptions;

    @FindBy ( css = "div.dropdown-select-options-wrapper.sc-cel-dropdown-select>ul>li" )
    List<WebElement> IdleTimeValues;

    // Root Child Elements
    private static String btnPrimary = ".primary_button";
    private static String editBtnElement = "button.secondary_button";
    private static String ElementTypeForToggle = ".switch-button";
    private static String ElementTypeForDropdown = ".dropdown-select-trigger";
    private static String childeditbutton = ".secondary_button";

    // languages
    private String languageDropDownParentCss = "div.multi-check-dropdown-container";
    // edit button
    private String editButtonCssSelector = "button.secondary_button";

    // cancel button
    private String cancelEditCoursePopUpBtnElementCss = "button.secondary_button";

    // Edit Settings
    private static String toggleOffButton = "button.switch-button.toggle-off";

    public EditCourseSettingPage() {}

    /**
     *
     * Constructor class for Courses page and initializing the driver for page
     * factory objects.
     *
     * @param driver
     * @param url
     */

    public EditCourseSettingPage( WebDriver driver ) {
        this.driver = driver;
        // Have Topbar here and init
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );

    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, pageTitle ) ) {
            Log.message( "SM Courses Page loaded successfully." );
        } else {
            Log.fail( "SM Courses Page did not load." );
        }
    }

    public boolean isLoadedCourseDetailsPage() throws Error {
        return SMUtils.isElementPresent( pageTitle );
    }

    public boolean isEditButtonEnabled() {
        WebElement editButtonTab = SMUtils.getWebElement( driver, editBtnHost, editBtnElement );
        if ( editButtonTab.isEnabled() ) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * To click Edit button under the course name
     */
    public void clickOnEditButton() {
        if ( isEditButtonEnabled() ) {
            WebElement editButton = SMUtils.getWebElement( driver, editBtnHost, editBtnElement );
            SMUtils.waitForElementToBeClickable( editButton, driver );
            SMUtils.clickJS( driver, editButton );
            Log.message( "Edit button present under the course name is clicked" );
        } else {
            Log.message( "Edit button present under the course name is not enabled" );
        }
    }

    public boolean isEditButtonDisplayed() {
        if ( !SMUtils.verifyElementDoesNotExist( By.cssSelector( childeditbutton ), driver ) )
            ;
        return false;
    }

    public boolean isDisplayedEditSettingsPopUp() {
        SMUtils.waitForElement( driver, editSettingsPopUpTitle );
        return SMUtils.isElementPresent( editSettingsPopUpTitle );
    }

    /**
     * To click Edit Setting button
     */
    public void clickEditSettingBtn() {
        WebElement clickEditSettingBtn = SMUtils.getWebElement( driver, editShadowHostCssSelector, editButtonCssSelector );
        SMUtils.waitForElementToBeClickable( clickEditSettingBtn, driver );
        SMUtils.clickJS( driver, clickEditSettingBtn );
        Log.message( "Edit button setting is clicked" );
    }

    public boolean isDisplayedToggleButton() {
        SMUtils.waitForElement( driver, ToggleButton );
        return SMUtils.isElementPresent( ToggleButton );
    }

    /**
     * To Click on translate button
     *
     */
    /**
     * To click on Translate section
     */
    public void clickOnTranslate( String labelType ) {
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equals( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement translateSection1 = parentElement.findElement( By.cssSelector( ".switch-button" ) );
                SMUtils.waitForElement( driver, translateSection1, 5 );
                SMUtils.clickJS( driver, translateSection1 );
                Log.message( "Clicked on Translate toggle" );
            }
        } ) );
    }

    /**
     * To click on IP
     */
    public void clickToggleButtonInFirstCloumnSettingsPage( String labelType ) {

        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                SMUtils.waitForElement( driver, element, 5 );
                SMUtils.clickJS( driver, element );

            }
        } ) );

    }

    public boolean isToggleButtonEnabledInFirstCloumnSettingsPage( String labelType ) {

        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                SMUtils.waitForElement( driver, element, 5 );
                element.isEnabled();
            }
        } ) );
        return true;

    }

    public void clickToggleButtonInSecondCloumnSettingsPage( String labelType ) {

        this.listOfSecondColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                SMUtils.waitForElement( driver, element, 5 );
                SMUtils.clickJS( driver, element );
            }
        } ) );

    }

    /**
     * To Verify cancel button is dispalyed
     *
     * Return isElementPresent
     */

    public boolean isDisplayedCancelButton() {
        SMUtils.waitForElement( driver, cancelEditCoursePopUpBtnHost );
        WebElement cancelEditCoursePopUp = SMUtils.getWebElementDirect( driver, cancelEditCoursePopUpBtnHost, cancelEditCoursePopUpBtnElementCss );
        return SMUtils.isElementPresent( cancelEditCoursePopUp );
    }

    /**
     * To Verify cancel button is dispalyed
     *
     * Return isElementPresent
     */
    public boolean isDisplayedSaveButton() {
        SMUtils.waitForElement( driver, cancelEditCoursePopUpBtnHost );
        WebElement saveBtn = SMUtils.getWebElementDirect( driver, btnSaveHost, btnPrimary );
        return SMUtils.isElementPresent( saveBtn );
    }

    /**
     * To verify Languages DropDown section is displayed
     */
    public boolean isDisplayedLanguagesDropDown() {
        WebElement languageChild = SMUtils.getWebElementDirect( driver, languageDropDownShadowHost, languageDropDownParentCss );
        WebElement languagesDropDown = languageChild.findElement( By.cssSelector( "button.dropdown-head" ) );
        SMUtils.waitForElement( driver, languagesDropDown );
        return SMUtils.isElementPresent( languagesDropDown );
    }

    /**
     * To Verify language dropdown is not dispalyed
     *
     */

    public boolean isNotDisplayedLanguagesDropDown() {
        SMUtils.waitForElement( driver, languageDropDownInvisible );
        return SMUtils.isElementPresent( languageDropDownInvisible );
    }

    /**
     * To generate course name return RandomStringUtils
     */
    public String generteCourseName() {
        return String.join( "", Constants.RANDOM_STRING_CHAR, RandomStringUtils.randomAlphabetic( 10 ) ).trim().replaceAll( "\\s{2,}", " " );
    }

    /**
     *
     * RandomStringUtils
     */
    public void wait( int seconds, WebDriver driver ) {
        driver.manage().timeouts().implicitlyWait( seconds, TimeUnit.SECONDS );
    }

    /**
     * To verify Courses Assignment Setting FirstColumn Sections displayed
     */
    public boolean isCourseSettingsFirstColumnDisplayed( String elementType, String labelType ) {
        String getElementType;
        if ( elementType.equals( Constants.TOGGLE_BUTTON ) ) {
            getElementType = ElementTypeForToggle;
        } else {
            getElementType = ElementTypeForDropdown;
        }
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement sessionLengthSection = parentElement.findElement( By.cssSelector( getElementType ) );
                SMUtils.waitForElement( driver, sessionLengthSection, 5 );
                status.set( SMUtils.isElementPresent( sessionLengthSection ) );
            }
        } ) );
        return status.get();
    }

    /**
     * To verify Courses Assignment Setting SecondColumn Sections displayed
     */
    public boolean isCourseSettingsSecondColumnDisplayed( String elementType, String labelType ) {
        String getElementType;
        if ( elementType.equals( Constants.TOGGLE_BUTTON ) ) {
            getElementType = ElementTypeForToggle;
        } else {
            getElementType = ElementTypeForDropdown;
        }
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfSecondColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement sessionLengthSection = parentElement.findElement( By.cssSelector( getElementType ) );
                SMUtils.waitForElement( driver, sessionLengthSection, 5 );
                status.set( SMUtils.isElementPresent( sessionLengthSection ) );
            }
        } ) );
        return status.get();
    }

    /**
     * To verify Initial Placement section is displayed
     */
    public boolean isDisplayedInitialPlacementSections( String labelType ) {
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                SMUtils.waitForElement( driver, element, 5 );
                status.set( SMUtils.isElementPresent( element ) );
            }
        } ) );
        return status.get();
    }

    /**
     * To verify Manually Set Course Level Section displayed
     */
    public boolean isDisplayedManuallySetCourseLevelSection( String labelType ) {
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfSecondColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                SMUtils.waitForElement( driver, element, 5 );
                status.set( SMUtils.isElementPresent( element ) );
            }
        } ) );
        return status.get();
    }

    public void clickOnSaveButton() {
        SMUtils.waitForElement( driver, btnSaveHost );
        btnSaveHost.click();
        Log.message( "Clicked on Save Button on Edit Course Setting Page" );
    }

    /**
     * To verify that toggle buttons display successfully on edit setting
     * screens
     */
    /**
     * Verify All Toggle Buttons From First Column Displayed
     *
     * @return
     */

    public boolean isDisplayedFirstColumnToggleButtons( String labelType ) {
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement toggleButtonFromFirstColumn = parentElement.findElement( By.cssSelector( ".switch-button" ) );
                SMUtils.waitForElement( driver, toggleButtonFromFirstColumn, 5 );
                status.set( SMUtils.isElementPresent( toggleButtonFromFirstColumn ) );
            }
        } ) );

        return status.get();

    }

    /**
     * Verify All Toggle Buttons From Second Column Displayed
     *
     * @return
     */

    public boolean isDisplayedSecondColumnToggleButtons( String labelType ) {
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfSecondColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement toggleButtonFromSecondColumn = parentElement.findElement( By.cssSelector( ".switch-button" ) );
                SMUtils.waitForElement( driver, toggleButtonFromSecondColumn, 5 );
                status.set( SMUtils.isElementPresent( toggleButtonFromSecondColumn ) );
            }
        } ) );
        return status.get();
    }

    /**
     * To verify Cancel button is Enabled
     */
    public boolean isCancelButtonEnabled() {
        return cancelEditCoursePopUpBtnHost.isEnabled();

    }

    /**
     * To click Cancel button from Edit Setting popup page
     */
    public void clickCancelBtn() {
        SMUtils.waitForElementToBeClickable( cancelEditCoursePopUpBtnHost, driver );
        SMUtils.clickJS( driver, cancelEditCoursePopUpBtnHost );
        Log.message( "Cancel button is clicked" );
    }

    /**
     * To Get the Boundary value of session length
     */
    public boolean SessionLengthBoundaryValue( String labelType, String Sessionlable ) {
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement SessionLengthDropdownBtn = parentElement.findElement( By.cssSelector( ".dropdown-select-trigger" ) );
                SMUtils.waitForElement( driver, SessionLengthDropdownBtn, 5 );
                SessionLengthDropdownBtn.click();
                this.SessionLengthDropdownOptions.stream().forEach( element1 -> Optional.ofNullable( element1.getText().trim() ).ifPresent( SessionLengthValues -> {
                    if ( SessionLengthValues.equalsIgnoreCase( Sessionlable ) ) {
                        status.set( true );
                    }
                } ) );
            }
        } ) );

        return status.get();
    }

    /**
     * To verify First Column Toggle Buttons are Selected
     */

    public boolean verifyFirstColumnToggleButtonSelected( String labelType ) {
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement toggleButtonFromFirstColumn = parentElement.findElement( By.cssSelector( ".switch-button" ) );
                SMUtils.waitForElement( driver, toggleButtonFromFirstColumn, 5 );
                if ( SMUtils.getAttributeOfWebElement( toggleButtonFromFirstColumn, driver, "class" ).contains( "toggle-on" ) ) {
                    Log.message( labelType + " Toggle Button is Already Selected" );
                    status.set( SMUtils.getAttributeOfWebElement( toggleButtonFromFirstColumn, driver, "class" ).contains( "toggle-on" ) );
                } else {
                    toggleButtonFromFirstColumn.click();
                    Log.message( labelType + " Toggle Button is Selected" );
                    status.set( SMUtils.getAttributeOfWebElement( toggleButtonFromFirstColumn, driver, "class" ).contains( "toggle-on" ) );
                }
            }
        } ) );
        return status.get();
    }

    /**
     * To verify Second Column Toggle Buttons are Selected
     */
    public boolean verifySecondColumnToggleButtonSelected( String labelType ) {
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfSecondColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement toggleButtonFromSecondColumn = parentElement.findElement( By.cssSelector( ".switch-button" ) );
                SMUtils.waitForElement( driver, toggleButtonFromSecondColumn, 5 );
                if ( SMUtils.getAttributeOfWebElement( toggleButtonFromSecondColumn, driver, "class" ).contains( "toggle-on" ) ) {
                    Log.message( labelType + " Toggle Button is Already Selected" );
                    status.set( SMUtils.getAttributeOfWebElement( toggleButtonFromSecondColumn, driver, "class" ).contains( "toggle-on" ) );
                } else {
                    toggleButtonFromSecondColumn.click();
                    Log.message( labelType + " Toggle Button is Selected" );
                    status.set( SMUtils.getAttributeOfWebElement( toggleButtonFromSecondColumn, driver, "class" ).contains( "toggle-on" ) );
                }
            }
        } ) );
        return status.get();
    }

    /**
     * To Get the Boundary value of Idle Time
     */
    public String getIdleTimeMaxBoundaryValue( String labelType ) {
        AtomicReference<String> status = new AtomicReference<>( null );
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement idleTimeBtn = parentElement.findElement( By.cssSelector( ".dropdown-select-trigger" ) );

                SMUtils.waitForElement( driver, idleTimeBtn, 5 );
                SMUtils.click( driver, idleTimeBtn );
                String IdleTimeMaxBoundaryValue = IdleTimeValues.get( IdleTimeValues.size() - 1 ).getText();
                status.set( IdleTimeMaxBoundaryValue );
            }
        } ) );
        return status.get();
    }

    /**
     * To Verify Toggle Buttons state is ON or OFF
     */
    public boolean verifyFirstColumnToggleButtonState( String labelType ) {
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement toggleButton = parentElement.findElement( By.cssSelector( ".switch-button" ) );
                SMUtils.waitForElement( driver, toggleButton, 5 );
                status.set( SMUtils.getAttributeOfWebElement( toggleButton, driver, "class" ).contains( "toggle-on" ) );
            }
        } ) );
        return status.get();
    }

    public boolean verifySecondColumnToggleButtonState( String labelType ) {
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfSecondColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement toggleButton = parentElement.findElement( By.cssSelector( ".switch-button" ) );
                SMUtils.waitForElement( driver, toggleButton, 5 );
                status.set( SMUtils.getAttributeOfWebElement( toggleButton, driver, "class" ).contains( "toggle-on" ) );
            }
        } ) );
        return status.get();
    }
}