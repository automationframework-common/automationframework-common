package com.savvas.sm.ui.tests.LoginSuite;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.pages.EBPlusAndAutoSignInPage;
import com.savvas.sm.ui.pages.LauncherPage;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.ui.pages.UnauthorizedModal;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

public class LoginTest extends BaseTest {
    private String smUrl;
    private String browser;

    private String username = null;
    private String studentUserName = null;
    private String teacher = "Teacher1";
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = SMUtils.getKeyValueFromResponse( RBSDataSetup.teacherDetails.get( teacher ), RBSDataSetupConstants.USERNAME );
        studentUserName = SMUtils.getKeyValueFromResponse( RBSDataSetup.studentDetails.get( "Student1" ), RBSDataSetupConstants.USERNAME );
    }

    @Test ( priority = 1, groups = { "SMK-50188", "eb_login", "basic", "P1", "UI" } )
    public void tcLoginLogoutOfBasicTeacher( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify basic teacher user is able to login to SM" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Logging in as basic teacher
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-50188", "eb_login", "auto", "P1", "UI" } )
    public void tcLoginLogoutOfAutoTeacher( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the auto Teacher is able to login to SM" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Logging in as auto teacher
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.AUTO, null, LoginConstants.AUTO_DISTRICT_DETAILS.USERNAME_WITH_DISTRICT_AUTO, password );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-50188", "eb_login", "auto", "P1", "UI" } )
    public void tcLoginLogoutOfAutoTeacherViaWAYF( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the auto Teacher is able to login Via WAYF" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Logging in as auto teacher
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.AUTO, LoginConstants.AUTO_DISTRICT_DETAILS.DISTRICT_NAME_AUTO, LoginConstants.AUTO_DISTRICT_DETAILS.USERNAME_AUTO, password );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-50188", "ps_login", "plus", "P1", "UI" } )
    public void tcLoginLogoutOfPlusTeacher( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the plus Teacher is able to login to SM" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Logging in as plus teacher
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.PLUS, null, LoginConstants.PLUS_DISTRICT_DETAILS.USERNAME_WITH_DISTRICT_PLUS, password );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-50188", "ps_login", "plus", "P1", "UI" } )
    public void tcLoginLogoutOfPlusTeacherViaWAYF( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the Plus Teacher is able to login Via WAYF" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Logging in as plus teacher
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.PLUS, LoginConstants.PLUS_DISTRICT_DETAILS.DISTRICT_NAME_PLUS, LoginConstants.PLUS_DISTRICT_DETAILS.USERNAME_PLUS, password );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-50188", "eb_login", "basic", "P1", "UI" } )
    public void tcLoginLogoutOfBasicStudent( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify basic student user is able to login to SM" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Logging in as basic student
            StudentDashboardPage studentHomePage = LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, LoginConstants.UserType.BASIC, null, studentUserName, password );

            // SignOut from SM
            studentHomePage.logout();

            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-50188", "eb_login", "auto", "P1", "UI" } )
    public void tcLoginLogoutOfAutoStudent( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the auto Student is able to login to SM" + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {

            // Logging in as auto Student
            StudentDashboardPage studentHomePage = LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, LoginConstants.UserType.AUTO, null, LoginConstants.AUTO_DISTRICT_DETAILS.STUDENT_USERNAME_WITH_DISTRICT_AUTO, password );

            // SignOut from SM
            studentHomePage.logout();

            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-50188", "eb_login", "auto", "P1", "UI" } )
    public void tcLoginLogoutOfAutoStudentViaWAYF( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the auto Student is able to login Via WAYF" + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {

            // Logging in as auto Student
            StudentDashboardPage studentHomePage = LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, LoginConstants.UserType.AUTO, LoginConstants.AUTO_DISTRICT_DETAILS.DISTRICT_NAME_AUTO, LoginConstants.AUTO_DISTRICT_DETAILS.STUDENT_USERNAME_AUTO,
                    password );

            // SignOut from SM
            studentHomePage.logout();

            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-50188", "ps_login", "plus", "P1", "UI" } )
    public void tcLoginLogoutOfPlusStudent( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the plus Student is able to login to SM" + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {

            // Logging in as plus student
            StudentDashboardPage studentHomePage = LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, LoginConstants.UserType.PLUS, null, LoginConstants.PLUS_DISTRICT_DETAILS.STUDENT_USERNAME_WITH_DISTRICT_PLUS, password );

            // SignOut from SM
            studentHomePage.logout();

            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-50188", "ps_login", "plus", "P1", "UI" } )
    public void tcLoginLogoutOfPlusStudentViaWAYF( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the Plus Student is able to login Via WAYF" + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {

            // Logging in as plus student
            StudentDashboardPage studentHomePage = LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, LoginConstants.UserType.PLUS, LoginConstants.PLUS_DISTRICT_DETAILS.DISTRICT_NAME_PLUS, LoginConstants.PLUS_DISTRICT_DETAILS.STUDENT_USERNAME_PLUS,
                    password );

            // SignOut from SM
            studentHomePage.logout();

            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-51112", "P1", "UI" } )
    public void tcOpenNewWindowForRumbaSignIn( ITestContext context ) throws Exception {

        if ( browser.toLowerCase().contains( "safari" ) || browser.toLowerCase().contains( "firefox" ) )
            throw new SkipException( "Script cannot run in browser- " + browser + ". Selenium webdriver known issue of opening new window." );
        else {
        	// Get driver
        	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        	EventListener eventListner = new EventListener();
        	driver.register(eventListner);
        	Log.testCaseInfo( "Verify the EB Sign in page opens in a new window and Url" + "<small><b><i>[" + browser + "]</b></i></small>" );

        	try {

                LauncherPage launcherPage = new LauncherPage( driver, smUrl ).get();
                Log.assertThat( launcherPage.validateEBSignPageOpenInNewWindow(), "EB Sign in page opened in new window", "EB Sign in page failed to open in new window" );
                Log.assertThat( driver.getCurrentUrl().contains( "/lms/sso.view" ), "Rumba sign-in page url contains /lms/sso.view", "Rumba sign-in page url doesn't contains /lms/sso.view" );
                Log.testCaseResult();

            } catch ( Exception e ) {
                Log.exception( e, driver );
            } finally {
                Log.endTestCase();
                driver.quit();
            }
        }
    }

    @Test ( priority = 1, groups = { "SMK-51119", "eb_login", "basic", "P1", "UI" } )
    public void tcAuthorisationLoginTest_001( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the Teacher can able to login only through the assigned Threesixty ID (Url) which is mapped with the respective district " + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {
            // Logging in as basic teacher
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, LoginConstants.DIFFERENT_DISTRICT_USERS.TEACHER_USERNAME_BASIC, password );
            Log.message( "the Teacher can able to login only through the assigned Threesixty ID (Url) which is mapped with the respective district " );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-51119", "eb_login", "basic", "P1", "UI" } )
    public void tcAuthorisationLoginTest_002( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the Teacher from the district-A cannot login to the instance which is mapped with district-B " + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Logging in as Auto teacher
            UnauthorizedModal unauthorizedPagePopupWindow = LoginWrapper.loginToSuccessMakerAsUnauthorized( driver, smUrl, LoginConstants.UserType.AUTO, null, LoginConstants.DIFFERENT_DISTRICT_USERS.TEACHER_USER_NAME_AUTO, password );
            Log.assertThat( unauthorizedPagePopupWindow.isUnauthorizedWindowPopupDisplayed(), "Unauthorized popup is displaying", "Unauthorized popup is not  displaying" );
            Log.assertThat( unauthorizedPagePopupWindow.getUnauthorizedText(), "Correct Header and description is displaying for unauthorization", "Incorrect Header and description is displaying for unauthorization" );
            LoginPage loginPage = unauthorizedPagePopupWindow.isLoginpageDisplayed();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-51119", "eb_login", "basic", "P1", "UI" } )
    public void tcAuthorisationLoginTest_003( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the Student can able to login only through the assigned Threesixty ID (Url) which is mapped with the respective district " + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Logging in as basic Student
            StudentDashboardPage studentdashboardpage = LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, LoginConstants.UserType.BASIC, null, LoginConstants.DIFFERENT_DISTRICT_USERS.STUDENT_USERNAME_BASIC, password );
            Log.message( "the Student can able to login only through the assigned Threesixty ID (Url) which is mapped with the respective district " );

            // SignOut from SM
            studentdashboardpage.logout();
            // verify the SM-Sign Out takes to EB SignIn Page
            Log.assertThat( new EBPlusAndAutoSignInPage( driver ).get().isSignInContainerDisplayed(), "EBPlus and Auto sign in page is displayed", "EBPlus and Auto sign in page not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-51119", "eb_login", "basic", "P1", "UI" } )
    public void tcAuthorisationLoginTest_004( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the Student from the district-A cannot login to the instance which is mapped with district-B " + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {
    		// Logging in as Auto Student
            UnauthorizedModal unauthorizedPagePopupWindow = LoginWrapper.loginToSuccessMakerAsUnauthorized( driver, smUrl, LoginConstants.UserType.AUTO, null, LoginConstants.DIFFERENT_DISTRICT_USERS.STUDENT_USERNAME_AUTO, password );
            Log.assertThat( unauthorizedPagePopupWindow.isUnauthorizedWindowPopupDisplayed(), "Unauthorized popup is displaying", "Unauthorized popup is not  displaying" );
            Log.assertThat( unauthorizedPagePopupWindow.getUnauthorizedText(), "Correct Header and description is displaying for unauthorization", "Incorrect Header and description is displaying for unauthorization" );
            LoginPage loginPage = unauthorizedPagePopupWindow.isLoginpageDisplayed();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
