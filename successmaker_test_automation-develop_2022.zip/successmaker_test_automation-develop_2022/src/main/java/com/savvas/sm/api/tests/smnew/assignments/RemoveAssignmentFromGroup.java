package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

public class RemoveAssignmentFromGroup extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String CourseId;
    private String assignmentID;
    private String AssignmentUserId;
    private String teacherUsername;
    List<String> studentRumbaIds = new ArrayList<>();
    RBSUtils rbsutils = new RBSUtils();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( priority = 1, dataProvider = "RemoveGroupPositiveFlow", groups = { "SMK-51917", "smoke_test_case", "RemoveGroup", "RemoveAssignmentFromGroup", "P1", "API" } )
    public void tcRemoveGroup001( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> requestIds = new ArrayList<>();

        HashMap<String, String> groupDetails = new HashMap<>();
        String endpoint = "null";

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        HashMap<String, String> response = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        String groupId = SMUtils.getKeyValueFromResponse( groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds ).get( "body" ), "data,groupId" );
        assignmentDetails.put( AssignmentAPIConstants.GROUP_ID, groupId );
        requestIds.add( groupId );
        switch ( scenario ) {

            case "Remove MATH":

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );

                break;

            case "Remove READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );

                break;

            case "Remove FOCUS READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );

                break;

            case "Remove FOCUS MATH":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );

                break;

            case "Remove CUSTOM SETTINGS MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                break;

            case "Remove CUSTOM SKILL MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                break;

            case "Remove CUSTOM STANDARD MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                break;

            case "Remove CUSTOM SETTINGS READING":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                break;

            case "Remove CUSTOM SKILL READING":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                break;

            case "Remove CUSTOM STANDARD READING":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }
        response = assignAssignment( smUrl, assignmentDetails, requestIds, "groups" );

        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_OK ), "Course assigned successfully", "Course not assigned" );
        String assignmentId = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
        Log.message( "assignmentId: " + assignmentId );

        Log.assertThat( SqlHelperAssignment.getGroupAssignmentStatus( assignmentId ).equals( "0" ), "Assignment details added in assignment_group table", "Assignment details not added in assignment_group table" );

        HashMap<String, String> getresponse = deleteAssignmentfromGroup( smUrl, assignmentDetails, endpoint );

        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
        Log.assertThat( smAPIprocessor.isSchemaValid( "RemoveAssignmentFromGroup", CommonAPIConstants.STATUS_CODE_OK, getresponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        Log.assertThat( SqlHelperAssignment.getGroupAssignmentStatus( assignmentId ).equals( "1" ), "Assignment details soft deleted in assignment_group table", "Assignment details not soft deleted in assignment_group table" );
        Log.testCaseResult();
    }

    @Test ( priority = 2, dataProvider = "RemoveGroupNegativeFlow", groups = { "SMK-51917", "RemoveGroup", "RemoveAssignmentFromGroup", "P1", "API" } )
    public void tcRemoveGroup002( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        String endpoint = "null";
        String message = null;
        String exception = null;
        List<String> requestIds = new ArrayList<>();

        boolean status = false;
        HashMap<String, String> response = new HashMap<>();

        HashMap<String, String> groupDetails = new HashMap<>();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        String groupId = SMUtils.getKeyValueFromResponse( groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds ).get( "body" ), "data,groupId" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        requestIds.add( groupId );
        assignmentDetails.put( AssignmentAPIConstants.GROUP_ID, groupId );

        switch ( scenario ) {

            case "Invalid OrgId in Path Param":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, requestIds, "groups" );
                Log.message( response.get( "body" ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, CommonAPIConstants.INVALID_ORG_ID );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "Empty OrgId in Path Param":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, requestIds, "groups" );
                Log.message( response.get( "body" ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, " " );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "Empty staffId in Path Param":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, requestIds, "groups" );
                Log.message( response.get( "body" ) );

                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, " " );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "InValid bearer token in Path Param":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, requestIds, "groups" );
                Log.message( response.get( "body" ) );

                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "Invalid staffId in Path Param":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, requestIds, "groups" );
                Log.message( response.get( "body" ) );

                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, "12345678" );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            case "Invalid CourseID":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );

                response = assignAssignment( smUrl, assignmentDetails, requestIds, "groups" );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "ZZZ" );
                exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
                message = null;
                status = true;
                break;

            case "Empty CourseID":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );

                response = assignAssignment( smUrl, assignmentDetails, requestIds, "groups" );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, " " );
                exception = CommonAPIConstants.NULL_EXCEPTION;
                message = null;
                status = true;
                break;
            case "Staff-Id in Path Param are from different organizations":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, requestIds, "groups" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, CommonAPIConstants.INVALID_STAFF_ID );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            default:
                Log.message( "Case is invalid" );
                break;

        }
        HashMap<String, String> getresponse = deleteAssignmentfromGroup( smUrl, assignmentDetails, endpoint );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
        Log.message( getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        if ( message != null ) {
            verifyException( getresponse.get( "body" ), exception, status, message );
        }

        Log.testCaseResult();

    }

    /**
     * Data provider to give the positive data
     * 
     * @return
     */
    @DataProvider ( name = "RemoveGroupPositiveFlow" )
    public Object[][] RemoveGroupPositiveFlow() {

        Object[][] inputData = {

                { "Verify the valid response to Remove Assignment From Group API for Default Math", "Remove MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Assignment From Group API for Default Reading", "Remove READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Assignment From Group API for Focus Reading", "Remove FOCUS READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Assignment From Group API for Focus Math", "Remove FOCUS MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Assignment From Group API for Custom Settings Math", "Remove CUSTOM SETTINGS MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Assignment From Group API for Custom Skill Math", "Remove CUSTOM SKILL MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Assignment From Group API for Custom Standards Math", "Remove CUSTOM STANDARD MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Assignment From Group API for Custom Settings Reading", "Remove CUSTOM SETTINGS READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Assignment From Group API for Custom Skill Reading", "Remove CUSTOM SKILL READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Assignment From Group API for Custom Standards Reading", "Remove CUSTOM STANDARD READING", CommonAPIConstants.STATUS_CODE_OK }, };

        return inputData;
    }

    /**
     * Data provider to give the Negative data
     * 
     * @return
     */
    @DataProvider ( name = "RemoveGroupNegativeFlow" )
    public Object[][] RemoveGroupNegativeFlow() {

        Object[][] inputData = { { "Verify the status code and response for invalid OrgId in Path Param", "Invalid OrgId in Path Param", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code and response for Empty OrgId in Path Param", "Empty OrgId in Path Param", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code and response for Empty StaffId in Path Param", "Empty staffId in Path Param", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code and response for invalid staffId in Path Param", "Invalid staffId in Path Param", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code and response for other org staffId in Path Param", "Staff-Id in Path Param are from different organizations", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code and response for inValid bearer token  in Header", "InValid bearer token in Path Param", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code and response for invalid Assignmentuserid", "Invalid CourseID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the status code and response for Empty Assignmentuserid", "Empty CourseID", CommonAPIConstants.STATUS_CODE_INTERNAL_ERROR },

        };
        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

}