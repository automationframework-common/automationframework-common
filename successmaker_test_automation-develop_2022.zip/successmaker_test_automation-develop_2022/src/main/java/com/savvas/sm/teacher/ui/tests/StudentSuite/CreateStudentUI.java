package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class CreateStudentUI extends BaseTest {

    private String teacherId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    List<String> studentIdList = null;
    List<String> studentUserNames = null;

    private AtomicReference<String> schoolUsed = new AtomicReference<>();

    @BeforeClass
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        String schools = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

        String teacherDetails = RBSDataSetup.getMyTeacher( schools );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

    }

    @Test ( description = "Verify Create Student Pop Up on clicking AddStudent Button", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent001( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    			
        SMUtils.logDescriptionTC( "SMK-6880 : Verify the Add student button" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the student tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Clicking the add student button
            WebElement addStuBtn = studentsPage.addStudentElement();
            SMUtils.clickJS( driver, addStuBtn );

            // Validating whether Add student Pop up is displayed
            Log.assertThat( studentsPage.isCreateStudentPopUpDisplayed(), " CreateStudent Pop is Displayed after clicking the add studnet Button ", " CreateStudent Pop is not Displayed after clicking the add studnet Button" );

            // Closing the POP UP
            studentsPage.closePopup();

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify new Student creation with all valid inputs", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent002( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        SMUtils.logDescriptionTC( "SMK-7021 : Verify the created student added in current teacher homeroom group." );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Student Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Creating Student
            String studentID = studentsPage.createStudent();

            // Validating whether Created Student present by the Toast Message PopUp
            Log.assertThat( studentsPage.closeStudentAddedToastPopUp(), studentID + " is Created and present in the Students lsiting page", studentID + " not created and not present in the students listing page" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Fields hidden under show more demographics", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent003( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-6999 : Verify the Show More Demographics Option" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab

            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Add Student Button to open the Pop Up
            studentsPage.clikAddStudentInStudentListingPage();

            // Click Show more demographics

            studentsPage.clickShowMoreDemographics();

            // Size of textfields after clicking show more demographics
            int size = studentsPage.getSizeofTextFieldsCreatePopup();

            // Storing all the hidden textfields in Array List
            List<String> textfieldsUnderShowMoreOption = studentsPage.getFieldNamesShowMore();

            // Validation
            Log.assertThat( size == Constants.Students.TOTAL_NUMBEROF_FIELDS_POPUP, "Show more demographics field is clicked and Values are : " + textfieldsUnderShowMoreOption + " ", "Show more demographics field is not clicked" );

            // Clicking Hide More Demographics
            studentsPage.clickHideMoreDemographics();

            // Closing the POP UP
            studentsPage.closePopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Hide More Demographics link", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent004( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        SMUtils.logDescriptionTC( "SMK-7000 : Verify the Hide More Demographics Option" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab

            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            studentsPage.clikAddStudentInStudentListingPage();

            // Click Show more demographics
            studentsPage.clickShowMoreDemographics();

            // Size of textfields after clicking show more demographics
            int sizeOfTextField_AfterClickingShowMore = studentsPage.getSizeofTextFieldsCreatePopup();

            // Storing all the hidden textfields in Array List
            List<String> textfieldsUnderShowMoreOption = studentsPage.getFieldNamesShowMore();

            // Clicking Hide More Demographics
            studentsPage.clickHideMoreDemographics();

            // Size of textfields after clicking hide more demographics
            int sizeOfTextField_AfterClickingHideMore = studentsPage.getSizeofTextFieldsCreatePopup();

            // Validation
            Log.assertThat( sizeOfTextField_AfterClickingShowMore > sizeOfTextField_AfterClickingHideMore, "After Clicking Hide More Demographics following Values hidden : " + textfieldsUnderShowMoreOption + "",
                    "Hide More Demographics button not clicked" );

            // Closing the POP UP
            studentsPage.closePopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the close button", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent005( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-6883 : Verify the close button in Add Student Dialog Box" );

    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            studentsPage.clikAddStudentInStudentListingPage();

            // Closing the PopUp after entering the Student Details
            String studentID = studentsPage.enterOnlyStudentDetails();

            // Closing the PopUp using close button
            studentsPage.closePopup();

            Log.assertThat( studentsPage.isStudentNotPresent( studentID ), studentID + " is not Created and not present in the Students lsiting page", studentID + "  created and  present in the students listing page" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the cancel button", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent006( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);        
    	SMUtils.logDescriptionTC( "SMK-7003 : Verify the cancel button in Add Student UI" );

    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            studentsPage.clikAddStudentInStudentListingPage();

            // Providing all student details in the POP UP
            String studentID = studentsPage.enterOnlyStudentDetails();

            // Closing the PopUp using the cancel button
            studentsPage.clickCancelButtonInCreateStudentPopup();

            // Validation
            Log.assertThat( studentsPage.isStudentNotPresent( studentID ), studentID + " is not Created and not present in the Students lsiting page", studentID + "  created and  present in the students listing page" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the firstName with apostrophe symbol and mixed characs", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent007( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-6895 : Verify the user can able to enter the firstname as text input along with apstrophe symbol " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            studentsPage.clikAddStudentInStudentListingPage();

            // Creating Student with Astrophe Symbol and mixed Characs
            String studentID = studentsPage.enterOnlyStudentDetails();

            // Passing Apostrophe and mixed chars in the text field
            String fName = studentsPage.reNameTextFields( Constants.Students.APOSTROPHE_AND_MIXED_CHARACS_VALUE, Constants.FIRSTNAME );

            // Click Add Student Button
            studentsPage.clickcreateStudentButton();

            // Validation
            Log.assertThat( studentsPage.closeStudentAddedToastPopUp(), "First Name" + fName + "is Created with apostrophe symbol and mixed characs and present in the Students lsiting page",
                    studentID + " not created and not present in the students listing page" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the LastName with apostrophe symbol and mixed characs", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent008( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-6919 : Verify the user can able to enter the last name as text input along with apstrophe symbol " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            studentsPage.clikAddStudentInStudentListingPage();

            // Creating Student with Astrophe Symbol and mixed Characs
            String studentID = studentsPage.enterOnlyStudentDetails();

            // Passing Apostrophe and mixed chars in the text field
            String lName = studentsPage.reNameTextFields( Constants.Students.APOSTROPHE_AND_MIXED_CHARACS_VALUE, Constants.LASTNAME );

            // Click Add Student Button
            studentsPage.clickcreateStudentButton();

            // Validation
            Log.assertThat( studentsPage.closeStudentAddedToastPopUp(), "Last Name " + lName + " is Created with apostrophe symbol and mixed characs and present in the Students lsiting page",
                    studentID + " not created and not present in the students listing page" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the UserName with apostrophe symbol and mixed characs", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent009( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-6949 : Verify the user can able to enter the user name as text input along with apstrophe symbol " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            studentsPage.clikAddStudentInStudentListingPage();

            // Creating Student with Astrophe Symbol and mixed Characs
            String studentID = studentsPage.enterOnlyStudentDetails();

            // Passing Apostrophe and mixed chars in the text field
            String uName = studentsPage.reNameTextFields( Constants.Students.APOSTROPHE_AND_MIXED_CHARACS_VALUE, Constants.USER_NAME );

            // Click Add Student Button
            studentsPage.clickcreateStudentButton();

            // Validation
            Log.assertThat( studentsPage.closeStudentAddedToastPopUp(), " Username " + uName + " is Created with apostrophe symbol and mixed characs and present in the Students lsiting page",
                    studentID + " not created and not present in the students listing page" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Error Message for Conform Password not match with New Password field", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent010( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-6976 : Verify both confirm password and password are different " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            studentsPage.clikAddStudentInStudentListingPage();

            // Entering student details
            String studentID = studentsPage.enterOnlyStudentDetails();

            // Creating Student with Password field and Confirm Password field not same
            studentsPage.reNameTextFields( Constants.FIRSTNAME, "ConfirmPassword" );
            studentsPage.clickcreateStudentButton();

            // Validating the Error Message for the Password mismatch
            Log.assertThat( studentsPage.validateErrorMessage( Constants.Students.PASSWORD_MISMATCH_ERROR_MESSAGE ), "Error Message : Password does not match", "Error Message Not shown" );

            // Closing the PopUp using the cancel button
            studentsPage.clickCancelButtonInCreateStudentPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify error message for using already used username", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent011( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-6955 : Verify the username with existing username which was already taken" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the student tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Creating Student
            String studentID = studentsPage.createStudent();

            studentsPage.closeStudentAddedToastPopUp();

            studentsPage.clikAddStudentInStudentListingPage();

            // Entering details to create another student
            studentsPage.enterOnlyStudentDetails();

            // Passing same UserName
            studentsPage.reNameTextFields( studentID, Constants.USER_NAME );

            studentsPage.clickcreateStudentButton();

            // Validating the Error Message for the Already used username
            Log.assertThat( studentsPage.validateErrorMessage( Constants.Students.DUPLICATE_USERNAME_ERROR_MESSAGE ), "Error Message : Username already exists", "Error Message Not shown" );

            // Closing the PopUp using the cancel button
            studentsPage.clickCancelButtonInCreateStudentPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    // Student Id field is not Mandatory part of SME-187
    @Test ( description = "Verify error message for using already used StudentId", groups = { "SMK-39134", "student", "createstudent" }, priority = 1, enabled = false )
    public void tcCreateStudent012( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-7017 : Verify the teacher canno use existing students student ID" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Creating Student
            String studentID = studentsPage.createStudent();

            // Entering details to create another student
            studentsPage.enterOnlyStudentDetails();

            // Passing already Used studentID
            studentsPage.reNameTextFields( studentID, Constants.STUDENT_ID );

            studentsPage.clickcreateStudentButton();

            // Validating the Error Message for the Already used username
            Log.assertThat( studentsPage.validateErrorMessage( Constants.Students.DUPLICATE_STUDENTID_ERROR_MESSAGE ), "Error Message : StudentID already exists", "Error Message Not shown" );

            // Closing the PopUp using the cancel button
            studentsPage.clickCancelButtonInCreateStudentPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the firstname as empty field", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent013( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        SMUtils.logDescriptionTC( "SMK-6896 : Verify the firstname field is blank " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // createStudent_With_firstNameAsBlank
            studentsPage.createStudentwithBlankFields( Constants.FIRSTNAME );

            // Validating the Error Message for the Password mismatch
            Log.assertThat( studentsPage.validateErrorMessage( Constants.Students.MANDATORY_FIELD_ERROR_MESSAGE ), "Error Message : Enter all required fields.", "Error Message Not shown" );

            // Closing the PopUp using the cancel button
            studentsPage.clickCancelButtonInCreateStudentPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the lastName as empty field", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent014( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-6920 : Verify the last name field is blank" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // createStudent_With_LastNameAsBlank
            studentsPage.createStudentwithBlankFields( Constants.LASTNAME );

            // Validating the Error Message for the Password mismatch
            Log.assertThat( studentsPage.validateErrorMessage( Constants.Students.MANDATORY_FIELD_ERROR_MESSAGE ), "Error Message : Enter all required fields.", "Error Message Not shown" );

            // Closing the PopUp using the cancel button
            studentsPage.clickCancelButtonInCreateStudentPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the userName as empty field", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent015( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        SMUtils.logDescriptionTC( "SMK-6950 : Verify the user name field is blank" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // createStudent_With_UserNameAsBlank
            studentsPage.createStudentwithBlankFields( Constants.USER_NAME );

            // Validating the Error Message for the Password mismatch
            Log.assertThat( studentsPage.validateErrorMessage( Constants.Students.MANDATORY_FIELD_ERROR_MESSAGE ), "Error Message : Enter all required fields.", "Error Message Not shown" );

            // Closing the PopUp using the cancel button
            studentsPage.clickCancelButtonInCreateStudentPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    // Student ID Field is not Mandatory part of SME-187 so Adding Enabled = false tag
    @Test ( description = "Verify the studentID as empty field", groups = { "SMK-39134", "student", "createstudent" }, priority = 1, enabled = false )
    public void tcCreateStudent016( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-6939 : Verify the student id field is blank" );

    	try {
    		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // createStudent_With_firstNameAsBlank
            studentsPage.createStudentwithBlankFields( "studentID" );

            // Validating the Error Message for the Password mismatch
            Log.assertThat( studentsPage.validateErrorMessage( Constants.Students.MANDATORY_FIELD_ERROR_MESSAGE ), "Error Message : Enter all required fields.", "Error Message Not shown" );

            // Closing the PopUp using the cancel button
            studentsPage.clickCancelButtonInCreateStudentPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Birthday field with invalid characs", groups = { "SMK-39134", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent017( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-6930 : Verify the invalid numericals in Birthday day text field " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            studentsPage.clikAddStudentInStudentListingPage();

            // CreateStudent_with_InvalidBirthDateFormat()
            studentsPage.enterOnlyStudentDetails();

            // Passing Invalid Date Format in to the Birthday Date field
            studentsPage.enterDOB( "11/20/1@@4" );

            // Validating the Error Message for the Password mismatch
            Log.assertThat( studentsPage.validateErrorMessage( Constants.Students.INVALID_BIRTHDATE_CHARAC_ERROR_MESSAGE ), "Error Message : Must be a valid date.", "Error Message Not shown" );

            // Closing the PopUp using the cancel button
            studentsPage.clickCancelButtonInCreateStudentPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher can able to see the warning popup displayed after creating the student.", groups = { "SMK-58157", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent018( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-6880 : Verify the teacher can able to see the warning popup displayed after creating the student." );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the student tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Creating a student
            studentsPage.createStudent();
            SMUtils.logDescriptionTC( "SMK-6880 : Verify the teacher can able to see the warning popup heading as \"Student added successfully\"" );
            Log.assertThat( studentsPage.isWarningPopupDisplayed(), "Test Passed! Warning Message Content Popup get displayed after creating student ", " Test Failed! Warning Message Popup not get displayed after creating student" );
            SMUtils.logDescriptionTC( "SMK-6880 : Verify the teacher can able to warning popup message as \"The added student will be displayed in the student list only if the student is added to a group. Navigate to the Groups tab to add this student to a group.\"" );
            Log.assertThat(studentsPage.isWarningPopupContentDisplayed(), "Test Passed! Warning Message Content in Popup get displayed after creating student ", " Test Failed! Warning Message Content in Popup not get displayed after creating student");
            // Closing the POP UP
            SMUtils.logDescriptionTC( "SMK-6880 : Verify the teacher can able to click the X icon on the popup." );
            studentsPage.clickXiconWarningpPopup();

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify popup is disappeared once the teacher clicks the close button.", groups = { "SMK-58157", "student", "createstudent" }, priority = 1 )
    public void tcCreateStudent019( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the student tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //creating a student
            studentsPage.createStudent();
            SMUtils.logDescriptionTC( "SMK-6880 : Verify the teacher can able to see the close icon in the popup." );

            // Closing the POP UP
            SMUtils.logDescriptionTC( "SMK-6880 : Verify popup is disappeared once the teacher clicks the close button." );
            studentsPage.clickCloseIconWarningPopup();
            boolean popupStatus = studentsPage.isWarningPopupDisplayed();
            Log.message("popuopClosed" + popupStatus);
            Log.assertThat(!popupStatus, "Popup get disapperaed", "Popup Not get disappered");

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }


}
