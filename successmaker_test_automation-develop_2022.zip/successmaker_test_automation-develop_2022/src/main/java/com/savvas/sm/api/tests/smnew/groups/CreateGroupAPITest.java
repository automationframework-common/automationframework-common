package com.savvas.sm.api.tests.smnew.groups;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.getGroupListAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;

/**
 * To test the create group API
 * 
 * @author ajith.mohan
 *
 */
public class CreateGroupAPITest extends GroupAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String classId = null;
    String className = null;

    // Teacher variable used for this class
    private String orgUsed = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL);
    private String readingSchool = RBSDataSetup.getSchools( Schools.READING_SCHOOL);
    private String teacherUsed;
    private String orgId;
    private String mathSchoolID;
    private String readingSchoolID;
    private String teacherId;
    private String username;

    // other school constants
    private String readingSchoolId;
    private String readingSchoolTeacherId;
    private String readingSchoolTeacherUsername;

    // Second Teacher
    private String secondTeacherId;
    private String secondTeacherUsername;
    List<String> schools = new ArrayList<>();
    HashMap<String, String> userDetails = new HashMap<>();
    List<String> studentRumbaIds = new ArrayList<>();

    @BeforeClass(alwaysRun=true)
    public void BeforeTest() throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        // Teacher used Details
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        mathSchoolID = RBSDataSetup.organizationIDs.get( mathSchool );
        readingSchoolID = RBSDataSetup.organizationIDs.get( readingSchool );
        Log.message("Flex OrgID: " + orgId + " Math Org ID: "  + mathSchoolID +" Read Org ID: "  + readingSchoolId);
        teacherUsed = RBSDataSetup.getMyTeacher( orgUsed );
        JSONObject userJsonObject = new JSONObject( teacherUsed );
        teacherId = new SMAPIProcessor().getKeyValues( userJsonObject, RBSDataSetupConstants.USERID ).get( 0 );
        username = new SMAPIProcessor().getKeyValues( userJsonObject, RBSDataSetupConstants.USERNAME ).get( 0 );
        String secondTeacherUsername1="secondTeacherUsername";

         }

    /**
     * Tests the positive scenarios of create group.
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
   @Test ( dataProvider = "createGroupPositiveScenariosData", groups = { "smoke_test_case", "Smoke TC001_CreateGroup","Create Group","P1","SMK-50200", "Group", "Create Group", "P1", "API" } )
    public void tcCreateGroup001( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );
        HashMap<String, String> groupDetails = new HashMap<>();
        
        List<String> studentRumbaIds = new ArrayList<>();
        HashMap<String, String> userDetails = new HashMap<>();
        String groupName = "Successmaker API Test Group " + System.nanoTime();
        boolean withStudent = false;
        String multiSchoolTeacher = null;
        UserAPI users = new UserAPI();

        switch ( scenario ) {
        
            case "GROUP WITHOUT STUDENT":
            	HashMap<String, String> groupDetail = new HashMap<>();
            	List<String> studentRumbaIds1 = new ArrayList<>();
            	Log.testCaseInfo("Verify the teacher can add the student who is part of the group which is not having the Successmaker product.");
            	Log.testCaseInfo("Verify the Google class room teacher can able to create group in Successmaker.");
            	groupDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD )); 
            	groupDetail.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            	groupDetail.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
            	groupDetail.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            	validatePositiveResponse(groupDetail, studentRumbaIds1, false);
                break;
                
            case "GROUP WITH STUDENTS":
            	HashMap<String, String> groupDetailsWithStudents = new HashMap<>();
            	List<String> studentRumbaId = new ArrayList<>();
                studentRumbaId.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
                studentRumbaId.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student2" ), "userId" ) );
                studentRumbaId.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student3" ), "userId" ) );
                groupDetailsWithStudents.put( RBSDataSetupConstants.BEARER_TOKEN,  new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetailsWithStudents.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetailsWithStudents.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
                groupDetailsWithStudents.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                withStudent = true;
                validatePositiveResponse(groupDetailsWithStudents, studentRumbaId, withStudent);
                break;
                
            case "GROUP WITH DUPLICATE NAME":
            	HashMap<String, String> groupDetailsDuplicateName = new HashMap<>();
            	List<String> studentRumbaIds2 = new ArrayList<>();
                String duplicateName = "SuccessMakerDuplicate Group Test";
                groupDetailsDuplicateName.put( RBSDataSetupConstants.BEARER_TOKEN,  new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ));
                groupDetailsDuplicateName.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetailsDuplicateName.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
                groupDetailsDuplicateName.put( CreateGroupAPIConstants.GROUP_NAME, duplicateName );
                validatePositiveResponse(groupDetailsDuplicateName, studentRumbaIds2, false);
                break;

            case "GROUP WITH SHARED STUDENT":
            	HashMap<String, String> groupDetailsSharedStd = new HashMap<>();
            	List<String> studentRumbaIdSharedStd = new ArrayList<>();
            	
                String sharedTeacher = "SharedTeacher" + System.nanoTime();

                HashMap<String, String> userDetail = new HashMap<>();
                userDetail.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetail.put( RBSDataSetupConstants.USERNAME, sharedTeacher );
                userDetail.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                userDetail.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( orgUsed ) );

                String sharedTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetail ), RBSDataSetupConstants.USERID );

                studentRumbaIdSharedStd.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
                studentRumbaIdSharedStd.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student2" ), "userId" ) );
                studentRumbaIdSharedStd.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student3" ), "userId" ) );

                groupDetailsSharedStd.put( RBSDataSetupConstants.BEARER_TOKEN,  new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD) );
                groupDetailsSharedStd.put( CreateGroupAPIConstants.GROUP_OWNER_ID, sharedTeacherID );
                groupDetailsSharedStd.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
                groupDetailsSharedStd.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                createGroup( smUrl, groupDetailsSharedStd, studentRumbaIdSharedStd );
                groupDetailsSharedStd.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                withStudent = true;
                validatePositiveResponse(groupDetailsSharedStd, studentRumbaIdSharedStd, withStudent);
                break;
                
                
            case "GROUP WITH MULTIPLE SCHOOL TEACHER":
            	HashMap<String, String> groupDetailsMultiSchT = new HashMap<>();
            	List<String> studentRumbaIdsMultiTec = new ArrayList<>();
            	HashMap<String, String> userDetailMultiTec = new HashMap<>();
            	
            	String multiSchoolTeacherUser = "MultiSchTeacher" + System.nanoTime();
    			String studentUserName = "StudentuserName" + System.nanoTime();
    			userDetailMultiTec.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
    			userDetailMultiTec.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacherUser );
    			userDetailMultiTec.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
    			List<String> schools = new ArrayList<>();
    			schools.add( RBSDataSetup.organizationIDs.get( mathSchool ) );
    			schools.add( RBSDataSetup.organizationIDs.get( orgUsed ) );
    			Log.message("Org ID Math: " + schools.get(0) );
    			Log.message("Org ID Flex: " + schools.get(1) );
    			String listString = "";
    			for ( String school : schools ) {
    				listString += school.concat( "\",\"" );
    			}
    			listString = listString.substring( 0, listString.length() - 3 );
    			Log.message("List String Value: " + listString);
    			userDetailMultiTec.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
    			
    			String multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetailMultiTec ), RBSDataSetupConstants.USERID );
    			new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( orgUsed ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

    			HashMap<String, String> userDetailForStudent = new HashMap<>();
    			userDetailForStudent.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
    			userDetailForStudent.put( RBSDataSetupConstants.USERNAME, studentUserName );
    			userDetailForStudent.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
    			userDetailForStudent.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( orgUsed ) );
    			String studentId = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetailForStudent ), RBSDataSetupConstants.USERID );
    			studentRumbaIdsMultiTec.add( studentId );

    			HashMap<String, String> multiSchTeacherStudent = new HashMap<>();
    			multiSchTeacherStudent = generateRequestValues( new RBSUtils().getUser( studentId ), multiSchTeacherStudent, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( orgUsed ) );
    			multiSchTeacherStudent = SMUtils.updateRequestBodyValues( multiSchTeacherStudent, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( orgUsed ) );
    			multiSchTeacherStudent = SMUtils.updateRequestBodyValues( multiSchTeacherStudent, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERID ) );
    			multiSchTeacherStudent = SMUtils.updateRequestBodyValues( multiSchTeacherStudent, RBSDataSetupConstants.BEARER_TOKEN,
    					new RBSUtils().getAccessToken( multiSchoolTeacherUser, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
    			new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), multiSchTeacherStudent );
    			new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( orgUsed ), RBSDataSetupConstants.DEFAULT_PASSWORD, studentId );

    			String multiTeacherGroupName = "MULTISCHOOL_TEACHER_GROUP_" + System.nanoTime();
    			groupDetailsMultiSchT.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeacherUser, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
    			groupDetailsMultiSchT.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
    			groupDetailsMultiSchT.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
    			groupDetailsMultiSchT.put( CreateGroupAPIConstants.GROUP_NAME, multiTeacherGroupName  );
    			Log.message("groupDetailsMultiSchT List Value--> " + groupDetailsMultiSchT);
    			Log.message("");
                withStudent = true;
                validatePositiveResponse(groupDetailsMultiSchT, studentRumbaIdsMultiTec, withStudent);
                break;
                
            case "GROUP WITH MULTIPLE SCHOOL STUDENT":
            	HashMap<String, String> groupDetailsMultiSchS = new HashMap<>();
            	List<String> studentRumbaIdsMultiSch = new ArrayList<>();
            	HashMap<String, String> userDetailMultiSch = new HashMap<>();
            	
            	String multiSchoolStudent = "MultipleSchStudentTest" + System.nanoTime();

            	userDetailMultiSch.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
            	userDetailMultiSch.put( RBSDataSetupConstants.USERNAME, multiSchoolStudent );
            	userDetailMultiSch.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
    			List<String> schools1 = new ArrayList<>();
    			schools1.add( RBSDataSetup.organizationIDs.get(orgUsed ) );
    			schools1.add( RBSDataSetup.organizationIDs.get( readingSchool ) );
    			Log.message("Org ID Flex: " + schools1.get(0) );
    			Log.message("Org ID Reading School: " + schools1.get(1) );
    			String finalSchool1 = "";
    			for ( String school : schools1 ) {
    				finalSchool1 += school.concat( "\",\"" );
    			}
    			int finalSchoolLength = finalSchool1.length();
    			Log.message("finalSchoolLength" + finalSchoolLength);
    			finalSchool1 = finalSchool1.substring( 0, finalSchool1.length() - 3 );
    			userDetailMultiSch.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool1 );
    			String multiSchoolStudentID1 = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetailMultiSch ), RBSDataSetupConstants.USERID );
    			studentRumbaIdsMultiSch.add( multiSchoolStudentID1 );
    			
    			HashMap<String, String> studentInfo = new HashMap<>();
    			studentInfo = generateRequestValues( new RBSUtils().getUser( multiSchoolStudentID1 ), studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( orgUsed ) );
    			studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( orgUsed ) );
    			studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERID ) );
    			studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN,
    					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
    			new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
    			new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( orgUsed ), RBSDataSetupConstants.DEFAULT_PASSWORD, multiSchoolStudentID1 );

    			groupDetailsMultiSchS.put( RBSDataSetupConstants.BEARER_TOKEN,  new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
    			groupDetailsMultiSchS.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
    			groupDetailsMultiSchS.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
    			groupDetailsMultiSchS.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
    			withStudent = true;
    			validatePositiveResponse(groupDetailsMultiSchS, studentRumbaIdsMultiSch, withStudent);
                break;
                
            case "HAPPY PATH":
            	Log.testCaseInfo("Verify the class created in SM has the roster service as Successmaker.");
            	Log.testCaseInfo("Verify the teacher can able to create group with the student who does not belongs to any group(Orphan student)");
                
            	HashMap<String, String> groupDetailsHappyPath = new HashMap<>();
            	List<String> studentRumbaIdsHappyPath = new ArrayList<>();
            	
            	studentRumbaIdsHappyPath.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
            	studentRumbaIdsHappyPath.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student2" ), "userId" ) );
            	studentRumbaIdsHappyPath.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student3" ), "userId" ) );
            	groupDetailsHappyPath.put( RBSDataSetupConstants.BEARER_TOKEN,  new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            	groupDetailsHappyPath.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            	groupDetailsHappyPath.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
            	groupDetailsHappyPath.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                withStudent = true;
                validatePositiveResponse(groupDetailsHappyPath, studentRumbaIdsHappyPath, withStudent);
                break;

            case "GROUP NAME WITH 3 CHAR":
            	HashMap<String, String> groupDetailsMin = new HashMap<>();
            	List<String> studentRumbaIdMin = new ArrayList<>();
            	
            	studentRumbaIdMin.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
            	studentRumbaIdMin.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student2" ), "userId" ) );
            	studentRumbaIdMin.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student3" ), "userId" ) );
            	groupDetailsMin.put( RBSDataSetupConstants.BEARER_TOKEN,  new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            	groupDetailsMin.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            	groupDetailsMin.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
            	groupDetailsMin.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.GROUP_NAME_WITH_MIN );
                withStudent = true;
                validatePositiveResponse(groupDetailsMin, studentRumbaIdMin, withStudent);
                break;
                
            case "GROUP NAME WITH 75 CHAR":
            	HashMap<String, String> groupDetailsMax = new HashMap<>();
            	List<String> studentRumbaIdsMax = new ArrayList<>();
            	studentRumbaIdsMax.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
            	studentRumbaIdsMax.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student2" ), "userId" ) );
            	studentRumbaIdsMax.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student3" ), "userId" ) );
            	groupDetailsMax.put( RBSDataSetupConstants.BEARER_TOKEN,  new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            	groupDetailsMax.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            	groupDetailsMax.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
            	groupDetailsMax.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.GROUP_NAME_WITH_MAX );
                withStudent = true;
                validatePositiveResponse(groupDetailsMax, studentRumbaIdsMax, withStudent);
                break;
        }

        Log.testCaseResult();
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "createGroupPositiveScenariosData" )
    public Object[][] createGroupData() {

        Object[][] inputData = { { "Verify the teacher can create the class with no students.", "GROUP WITHOUT STUDENT", CommonAPIConstants.STATUS_CODE_CREATED },
                { "Verify the teacher can create the class with multiple students.", "GROUP WITH STUDENTS", CommonAPIConstants.STATUS_CODE_CREATED },
                { "Verify the teacher can create class with duplicate name.", "GROUP WITH DUPLICATE NAME", CommonAPIConstants.STATUS_CODE_CREATED },
                { "Verify the teacher can create the class with shared students.", "GROUP WITH SHARED STUDENT", CommonAPIConstants.STATUS_CODE_CREATED },
                { "Verify the class created in given school when the teacher is part of multiple schools.", "GROUP WITH MULTIPLE SCHOOL TEACHER", CommonAPIConstants.STATUS_CODE_CREATED },
                { "Verify the class created with multi school associated students.", "GROUP WITH MULTIPLE SCHOOL STUDENT", CommonAPIConstants.STATUS_CODE_CREATED },
                { "Verify the class created in SM, reflectes in CMS with proper details.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_CREATED },
//                { "Verify the class created in SM has the roster service as Successmaker.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_CREATED },
//                { "Verify the teacher can able to create group with the student who does not belongs to any group(Orphan student).", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_CREATED },
//                { "Verify the Google class room teacher can able to create group in Successmaker.", "GROUP WITHOUT STUDENT", CommonAPIConstants.STATUS_CODE_CREATED },
//                { "Verify the teacher can add the student who is part of the group which is not having the Successmaker product.", "GROUP WITHOUT STUDENT", CommonAPIConstants.STATUS_CODE_CREATED },
                { "Verify the teacher cannot able to create group when group name as less than 3 characters", "GROUP NAME WITH 3 CHAR", CommonAPIConstants.STATUS_CODE_CREATED },
                { "Verify the teacher cannot able to create group when group name as less than 75 characters", "GROUP NAME WITH 75 CHAR", CommonAPIConstants.STATUS_CODE_CREATED }

        };
        return inputData;
    }

    /**
     * To test the negative scenarios of create group API
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( dataProvider = "createGroupNegativeScenariosData", groups = {"SMK-50200", "Group", "Create Group", "P2", "API" } )
    public void tcCreateGroup002( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        String groupName = "Successmaker API Test Group " + System.nanoTime();
        String exception = null;
        boolean status = false;
        String message = null;

        switch ( scenario ) {
            case "CLASS WITH DIFFERENT SCHOOL":
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student2" ), "userId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student3" ), "userId" ) );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                break;
            case "CLASS WITH STUDENT PART OF DIFFERENT SCHOOL":
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ).get( "Student1" ), "userId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ).get( "Student2" ), "userId" ) );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                break;
            case "INVALID ORGANIZATION":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                groupDetails.put( CreateGroupAPIConstants.INVALID_ORG, getGroupListAPIConstants.INVALID_INPUT );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = CreateGroupAPIConstants.INVALID_ORGID_MESSAGE;
                status = true;
                break;
            case "INVALID TEACHER":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                groupDetails.put( CreateGroupAPIConstants.INVALID_TEACHER, getGroupListAPIConstants.INVALID_INPUT );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = CreateGroupAPIConstants.INVALID_TEACHER_MESSAGE;
                status = true;
                break;
            case "INVALID STUDENT":
                studentRumbaIds.add( getGroupListAPIConstants.INVALID_INPUT );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                message = CommonAPIConstants.INVALID_STUDENT_MESSAGE;
                status = true;
                break;
            case "INVALID CREDENTIAL":
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student2" ), "userId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student3" ), "userId" ) );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, getGroupListAPIConstants.INVALID_INPUT );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            case "STUDENT AUTHORIZATION":
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student2" ), "userId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student3" ), "userId" ) );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "STUDENT AS OWNER":
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student2" ), "userId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student3" ), "userId" ) );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                break;

            case "GROUP NAME AS EMPTY":

                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), "userId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student2" ), "userId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student3" ), "userId" ) );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.EMPTY_VALUE );
                exception = CommonAPIConstants.VALIDATION_EXCEPTION;
                message = CommonAPIConstants.GROUP_NAME_MESSAGE;
                status = true;
                break;
        }

        HashMap<String, String> response = createGroup( smUrl, groupDetails, studentRumbaIds );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + response.get( Constants.REPORT_BODY ) );
        verifyException( response.get( Constants.REPORT_BODY ), exception, status, message );
        Log.testCaseResult();
    }

    /**
     * Data provider to give the data of negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "createGroupNegativeScenariosData" )
    public Object[][] createGroupDataInvalid() {

        //Commented cases are has future backlog tickets since its excluded from execution
        Object[][] inputData = {
                //{ "Verify the API returns exception when the class created in different school.(Teacher is part of different school).", "CLASS WITH DIFFERENT SCHOOL", CommonAPIConstants.STATUS_CODE_BAD_REQUEST},
                //{ "Verify the API returns exception when the class created with students part of different school.", "CLASS WITH STUDENT PART OF DIFFERENT SCHOOL", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API returns exception when the organization is invalid.", "INVALID ORGANIZATION", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API returns exception when the teacher id is invalid.", "INVALID TEACHER", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API returns exception when the students IDs are invalid.", "INVALID STUDENT", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API throwing exception when the authorization is invalid.", "STUDENT AUTHORIZATION", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the API throwing exception when the authentication is invalid. ", "INVALID CREDENTIAL", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the teacher cannot able to create group when group name as null. ", "GROUP NAME AS EMPTY", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                //{ "Verify the API is not creating the group with owner ID as student ID. ", "STUDENT AS OWNER",  CommonAPIConstants.STATUS_CODE_BAD_REQUEST} 
        };
        return inputData;
    }

    /**
     * bulk student test
     * 
     * @throws Exception
     */
    @Test ( groups = { "smoke_test_case", "Smoke TC003_CreateGroup","Create Group","P1","SMK-50200", "Group", "Create Group", "P2", "API" } )
    public void tcCreateGroup003() throws Exception {

        Log.testCaseInfo( "Verify the group created with 250 students IDs" );

        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();

        IntStream.rangeClosed( 1, 101 ).forEach( student -> {
            HashMap<String, String> userDetails = new HashMap<>();
            String multiSchoolStudent = "MultiSchStudent" + System.nanoTime();
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolStudent );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( orgUsed ) );
            String multiSchoolStudentID = null;
            try {
                multiSchoolStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                Log.message( "Student " + student + " - " + multiSchoolStudentID );
            } catch ( Exception e ) {
                e.printStackTrace();
            }
            studentRumbaIds.add( multiSchoolStudentID );
        } );
        String groupName = "Successmaker API Test Group " + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
        HashMap<String, String> response = createGroup( smUrl, groupDetails, studentRumbaIds );
        Log.message( "Response:" + response );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_BAD_REQUEST ), "Status code returned as expected!",
                "Issue in returning status code! Expected - " + "400" + " Actual - " + response.get( Constants.STATUS_CODE ) );
        verifyException( response.get( Constants.REPORT_BODY ), CommonAPIConstants.VALIDATION_EXCEPTION, true, CommonAPIConstants.LIMIT_MESSAGE );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "createGroupWithStudentSchema", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        Log.testCaseResult();
    }

    /**
     * Verify the response data
     * 
     * @param expectedResponse
     * @param actualResponse
     * @param withStudent
     * @return
     * @throws IOException
     */
    public boolean verifyResponse( String expectedResponse, String actualResponse, boolean withStudent ) throws IOException {
        boolean isVerified = false;
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "createGroupWithoutStudentSchema", CommonAPIConstants.STATUS_CODE_CREATED, actualResponse ), "Schema is returned as expected.", "Schema is not as expected." );
        try {
            String teacherID = SMUtils.getKeyValueFromResponse( expectedResponse, CreateGroupAPIConstants.ROSTER_TEACHER_ID );
            teacherID = teacherID.substring( 2, teacherID.length() - 2 );

            if ( SMUtils.getKeyValueFromResponse( actualResponse, CreateGroupAPIConstants.DATA_GROUP_OWNER_ID ).equals( teacherID ) ) {
                Log.pass( "Group Owner ID verified as Expected!" );
                isVerified = true;
            } else {
                Log.fail( "Group owner is not returned as expected! Expected - " + teacherID + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, CreateGroupAPIConstants.DATA_GROUP_OWNER_ID ) );
            }

            if ( SMUtils.getKeyValueFromResponse( actualResponse, CreateGroupAPIConstants.DATA_GROUP_ID ).equals( SMUtils.getKeyValueFromResponse( expectedResponse, CreateGroupAPIConstants.ROSTER_CLASS_ID ) ) ) {
                Log.pass( "Group ID verified as Expected!" );
                isVerified = true;
            } else {
                Log.fail( "Group ID is not returned as expected! Expected - " + SMUtils.getKeyValueFromResponse( expectedResponse, CreateGroupAPIConstants.ROSTER_CLASS_ID ) + "Actual - "
                        + SMUtils.getKeyValueFromResponse( actualResponse, CreateGroupAPIConstants.DATA_GROUP_ID ) );
            }
            if ( SMUtils.getKeyValueFromResponse( actualResponse, CreateGroupAPIConstants.DATA_GROUP_NAME ).equals( SMUtils.getKeyValueFromResponse( expectedResponse, CreateGroupAPIConstants.ROSTER_CLASS_NAME ) ) ) {
                Log.pass( "Group Name  verified as Expected!" );
                isVerified = true;
            } else {
                Log.fail( "Group Name is not returned as expected! Expected - " + SMUtils.getKeyValueFromResponse( expectedResponse, CreateGroupAPIConstants.ROSTER_CLASS_NAME ) + "Actual - "
                        + SMUtils.getKeyValueFromResponse( actualResponse, CreateGroupAPIConstants.DATA_GROUP_NAME ) );
            }
            if ( SMUtils.getKeyValueFromResponse( actualResponse, CreateGroupAPIConstants.DATA_GROUPOWNER_ORGID ).equals( SMUtils.getKeyValueFromResponse( expectedResponse, CreateGroupAPIConstants.ROSTER_ORG_ID ) ) ) {
                Log.pass( "Group Org ID verified as Expected!" );
                isVerified = true;
            } else {
                Log.fail( "Group Org ID is not returned as expected! Expected - " + SMUtils.getKeyValueFromResponse( expectedResponse, CreateGroupAPIConstants.ROSTER_ORG_ID ) + "Actual - "
                        + SMUtils.getKeyValueFromResponse( actualResponse, CreateGroupAPIConstants.DATA_GROUPOWNER_ORGID ) );
            }
            if ( withStudent ) {
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "createGroupWithStudentSchema", CommonAPIConstants.STATUS_CODE_CREATED, actualResponse ), "Schema is returned as expected.", "Schema is not as expected." );
                String studentsExpected = SMUtils.getKeyValueFromResponse( expectedResponse, CreateGroupAPIConstants.ROSTER_STUDID );
                String studentsActual = SMUtils.getKeyValueFromResponse( actualResponse, CreateGroupAPIConstants.DATA_STUDENTRUMBA_IDS );
                studentsExpected = studentsExpected.substring( 1, studentsExpected.length() - 1 );
                studentsActual = studentsActual.substring( 1, studentsActual.length() - 1 );
                List<String> expectedStudentList = new ArrayList<String>();
                List<String> actualStudentList = new ArrayList<String>();
                for ( String student : studentsExpected.split( "," ) ) {
                    expectedStudentList.add( student );
                }
                for ( String student : studentsActual.split( "," ) ) {
                    actualStudentList.add( student );
                }

                if ( SMUtils.sortList( actualStudentList ).equals( SMUtils.sortList( expectedStudentList ) ) ) {
                    Log.pass( "Student ID verified as Expected!" );
                    isVerified = true;
                } else {
                    Log.fail( "Student ID is not returned as expected! Expected - " + SMUtils.getKeyValueFromResponse( expectedResponse, CreateGroupAPIConstants.ROSTER_STUDID ) + "Actual - "
                            + SMUtils.getKeyValueFromResponse( actualResponse, CreateGroupAPIConstants.DATA_STUDENTRUMBA_IDS ) );
                }
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isVerified;
    }
    
    
    public void validatePositiveResponse(HashMap<String,String> groupDetails, List<String> studentRumbaIds , boolean withStudent  ) throws IOException {
    	
    	 HashMap<String, String> response;
    	 String classDataFromCMS;
		try {
			response = createGroup( smUrl, groupDetails, studentRumbaIds );
			Log.message("CreateGroupAPI Response is--> " + response);
	        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_CREATED ), "Status code returned as expected!", "Issue in returning status code! Expected - " +  CommonAPIConstants.STATUS_CODE_CREATED + " Actual - " + response.get( Constants.STATUS_CODE ) );
	        classDataFromCMS = new RBSUtils().getClass( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE ) );
	        Log.pass( "Class From CMS - " + classDataFromCMS );
	        Log.pass( "Create Group - " + response.get( Constants.REPORT_BODY ) );
	        verifyResponse( classDataFromCMS, response.get( Constants.REPORT_BODY ), withStudent );

		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    
    
    
    /**
	 * Generating request values
	 * 
	 * @param studentExistingData
	 * @param newDetails
	 * @param key
	 * @param value
	 * @return
	 */
	public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

		HashMap<String, String> generatedStudentDetails = newDetails;
		generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
		generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
		generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
		generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
		generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
		generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
		generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
		generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
		generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
		generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
		generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
		generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
		generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
		generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
		generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
		generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
		generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

		return generatedStudentDetails;
	}

}