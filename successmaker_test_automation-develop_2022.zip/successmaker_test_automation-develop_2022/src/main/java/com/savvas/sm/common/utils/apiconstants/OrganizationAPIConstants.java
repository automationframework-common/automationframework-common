package com.savvas.sm.common.utils.apiconstants;

public interface OrganizationAPIConstants {
    // Constants - API
    public static String ORGID = "org-id";
    public static String USERID = "user-id";
    public static String AUTHORISATION = "Authorization";
    public static String BEARER = "Bearer ";

    //HolidayScheduler
    public static String START_DATE = "startDate";
    public static String END_DATE = "endDate";
    public static String DESCRIPTION = "description";
    public static String HOLIDAY = "holiday";
    
    //ShareCourse
    public static String ORGANIZATION_ID = "organizationIds";
    public static String COURSE_ID = "courseId";

    //OrganizationFlags
    String IS_DIAGNOSTIC_ENABLED = "isDiagnosticEnabled";
    String IS_AUTOASSIGN_ENABLED = "isAutoAssignEnabled";
    String FLAGS = "flags";

    // Constants - Endpoints
    public static String GET_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/getHolidays";
    public static String PUT_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/addHolidays";
    public static String DELETE_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/deleteHolidays";
    public static String GET_CHILD_ORGANIZATIONS = "/lms/web/api/v1/organizations/getChildren";
    public static String CHILD_ORGANIZATION_FROM_ORGSERVICE = "/org-service/v1/organizations/{organizationId}/childtree";
    public static String GET_SHARE_COURSE = "/lms/web/api/v1/sharedCourse";
    public static String GET_SHARED_COURSE = "/lms/web/api/v1/sharedCourse";

    String GET_ORGANIZATION_FLAGS = "/lms/web/api/v1/organizations/getOrganizationFlags";
    String POST_ORGANIZATION_FLAGS = "/lms/web/api/v1/organizations/setOrganizationFlags";

    String GET_SUCCESS_MSG = "Operation succeeded!";
    String AUTHENTICATION_FAILED = "Authentication Failed";
    String PARAMETER_MISSING = "Required request parameter 'flags' for method parameter type String[] is not present";
    String ORG_ID_MISSING = "Required request header 'org-id' for method parameter type String is not present";
    String ACCESS_DENIED = "Access is denied";
    String FLAGS_CREATED = "Flags created successfully";
    String MISSING_BODY = "Required request body is missing";
    String INVALID_BODY_VALUE = "Values for Organization Settings are invalid";
    String VALID_RESPONSE_MSG = "Message response is correct and valid";
    String INVALID_RESPONSE_MSG = "Message is not expected value and invalid";
}