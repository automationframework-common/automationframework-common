package com.savvas.sm.api.tests.smnew.report.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude ( JsonInclude.Include.NON_NULL )
public class ReportRequest {
    public List<String> students = new ArrayList<>();
    public Object subject;
    public Object limit;
    public Object offset;
    public String orderBy;
    public List<Object> assignmentIds;
    public Object targetDate;
    public Object startDate;
    public Object endDate;
    public Object weeks;
    public Object rbs;
    public Object stv;
    public Object ps;
    public Object pbs;
    public Object aod;
    public Object gradeId;
    public Object lastSession;
    public Object levelTarget;
    public List<Object> lastSessionDates;
    public Map<String, String> studentGrade;
    
    public List<Object> getLastSessionDates() {
        return lastSessionDates;
    }

    public Map<String, String> getStudentGrade() {
        return studentGrade;
    }

    public void setStudentGrade( Map<String, String> student ) {
        this.studentGrade = student;
    }

    public void setLastSessionDates( List<Object> lastSessionDates ) {
        this.lastSessionDates = lastSessionDates;
    }

    public Object getLastSession() {
        return lastSession;
    }

    public void setLastSession( Object lastSession ) {
        this.lastSession = lastSession;
    }

    public Object getPs() {
        return ps;
    }

    public void setPs( Object ps ) {
        this.ps = ps;
    }

    public Object getPbs() {
        return pbs;
    }

    public void setPbs( Object pbs ) {
        this.pbs = pbs;
    }

    public Object getAod() {
        return aod;
    }

    public void setAod( Object aod ) {
        this.aod = aod;
    }

    public Object getGradeId() {
        return gradeId;
    }

    public void setGradeId( Object gradeId ) {
        this.gradeId = gradeId;
    }

    public Object getRbs() {
        return rbs;
    }

    public void setRbs( Object rbs ) {
        this.rbs = rbs;
    }

    public Object getStv() {
        return stv;
    }

    public void setStv( Object stv ) {
        this.stv = stv;
    }

    public Object getWeeks() {
        return weeks;
    }

    public void setWeeks( Object weeks ) {
        this.weeks = weeks;
    }

    public List<String> getStudents() {
        return students;
    }

    public void setStudents( List<String> students ) {
        this.students = students;
    }

    public Object getSubject() {
        return subject;
    }

    public void setSubject( Object subject ) {
        this.subject = subject;
    }

    public Object getLimit() {
        return limit;
    }

    public void setLimit( Object limit ) {
        this.limit = limit;
    }

    public Object getOffset() {
        return offset;
    }

    public void setOffset( Object offset ) {
        this.offset = offset;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy( String orderBy ) {
        this.orderBy = orderBy;
    }

    public List<Object> getAssignmentIds() {
        return assignmentIds;
    }

    public void setAssignmentIds( List<Object> assignmentIds ) {
        this.assignmentIds = assignmentIds;
    }

    public Object getTargetDate() {
        return targetDate;
    }

    public void setTargetDate( Object targetDate ) {
        this.targetDate = targetDate;
    }

    public Object getStartDate() {
        return startDate;
    }

    public void setStartDate( Object startDate ) {
        this.startDate = startDate;
    }

    public Object getEndDate() {
        return endDate;
    }

    public void setEndDate( Object endDate ) {
        this.endDate = endDate;
    }
    
    public void targetLevel( Object levelTarget ) {
        this.aod = aod;
    }
    
}
