package com.savvas.sm.api.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.Consts;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Students;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;

import io.restassured.response.Response;

public class BaseAPITest {

    /**
     * @param baseUrl
     * @param userName
     * @param password
     * @return
     * @throws ClientProtocolException
     * @throws IOException
     */
    public String getJessionCookie( String baseUrl, String userName, String password ) throws ClientProtocolException, IOException {

        // Form Data
        List<NameValuePair> form = new ArrayList<>();
        form.add( new BasicNameValuePair( "user", userName ) );
        form.add( new BasicNameValuePair( "pwd", password ) );
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity( form, Consts.UTF_8 );

        // Make POST Call
        HttpClient smAPI = HttpClientBuilder.create().build();
        HttpPost httpPost = new HttpPost( baseUrl + Constants.LOGIN_URL_RESOURCE );
        httpPost.addHeader( "Content-Type", "application/x-www-form-urlencoded" );
        httpPost.setEntity( entity );
        HttpResponse smLoginResponse = smAPI.execute( httpPost );

        // Retrieve cookie
        String Cookie1 = smLoginResponse.getFirstHeader( "Set-Cookie" ).getValue();
        //Log.message("Session Cookie - " + Cookie1);

        return Cookie1;
    }

    /**
     * @param baseUrl
     * @param jSessionId
     * @return
     * @throws ClientProtocolException
     * @throws IOException
     */
    public void invalidateSession( String baseUrl, String jSessionId ) throws ClientProtocolException, IOException {

        // Make call
        HttpClient smAPI = HttpClientBuilder.create().build();
        HttpGet httpGet = new HttpGet( baseUrl + Constants.LOGOUT_URL_RESOURCE );
        httpGet.addHeader( "Cookie", jSessionId );

        HttpResponse smLoginResponse = smAPI.execute( httpGet );

        // Get cookie
        String Cookie1 = smLoginResponse.getFirstHeader( "Set-Cookie" ).getValue();
        String Cookie2 = smLoginResponse.getLastHeader( "Set-Cookie" ).getValue();

        // Check session deleted
        if ( Cookie1.contains( "JSESSIONID=deleteMe" ) || Cookie2.contains( "JSESSIONID=deleteMe" ) ) {
            Log.message( "Session - " + jSessionId + " invalidated by logout" );
        } else {
            Log.message( "Session not invalidated - " + jSessionId );
        }
    }

    /**
     * @param expectedJsonText
     * @param actualJsonText
     * @return
     * @throws ClientProtocolException
     * @throws IOException
     */
    public boolean compareJSON( String expectedJsonText, String actualJsonText ) throws ClientProtocolException, IOException {
        JSONObject actualJson = new JSONObject( actualJsonText );
        JSONObject expectedJson = new JSONObject( expectedJsonText );
        JSONCompareResult compareResult;
        compareResult = JSONCompare.compareJSON( expectedJson, actualJson, JSONCompareMode.LENIENT );

        String failureMessage = "";
        if ( compareResult != null && compareResult.failed() ) {
            failureMessage = compareResult.getMessage();
            Log.message( "JSON Compare Failed: " + failureMessage );
        }

        return compareResult != null && compareResult.passed();
    }

    /**
     * This will do comparision by exclding the tags (exclude files)
     * 
     * @param expectedJsonText
     * @param actualJsonText
     * @param excludeFields -If there is no exclusion needs to pass null,else
     *            needs to pass the values as comma separated String
     * @return
     * @throws ClientProtocolException
     * @throws IOException
     */
    public boolean compareJSON( String expectedJsonText, String actualJsonText, String excludeFields ) throws ClientProtocolException, IOException {
        JSONObject actualJson = new JSONObject( actualJsonText );
        JSONObject expectedJson = new JSONObject( expectedJsonText );
        JSONCompareResult compareResult;
        compareResult = JSONCompare.compareJSON( expectedJson, actualJson, JSONCompareMode.NON_EXTENSIBLE );

        if ( excludeFields != null ) {

            String[] excludeFields_Array = excludeFields.split( "," );
            boolean cmpFailed = false;

            compareResult.getFieldFailures().get( 0 ).getField();
            for ( int fIndex = 0; fIndex < compareResult.getFieldFailures().size(); fIndex++ ) {
                String failedField = compareResult.getFieldFailures().get( fIndex ).getField();
                boolean fieldFaild = true;
                for ( int skipIndex = 0; skipIndex < excludeFields_Array.length; skipIndex++ ) {
                    if ( failedField.contains( excludeFields_Array[skipIndex] ) ) {
                        fieldFaild = false;

                    }
                }
                if ( fieldFaild ) {
                    String failedFieldsinComparision = "Failed in field - " + failedField + ", Actual: " + compareResult.getFieldFailures().get( fIndex ).getActual() + ", Expected: " + compareResult.getFieldFailures().get( fIndex ).getExpected();
                    Log.message( failedFieldsinComparision );
                    cmpFailed = true;
                }
            }
            if ( cmpFailed ) {
                Log.message( "JSON Compare is failed!" );
            } else {
                Log.message( "JSON Compare is passed !" );
            }
            return !cmpFailed;
        } else {
            String failureMessage = "";
            if ( compareResult != null && compareResult.failed() ) {
                failureMessage = compareResult.getMessage();
                Log.message( "JSON Compare Failed: " + failureMessage );
            }
        }

        return compareResult != null && compareResult.passed();
    }

    /**
     * This method extracts and returns the array object from the given response
     * 
     * @param jsonResponse
     * @param arrayName
     * @return
     */
    public JSONArray getJsonArrayFromResponse( String jsonResponse, String arrayName ) {
        JSONObject jsonObject = null;
        JSONArray jsonArray = null;
        try {
            jsonObject = new JSONObject( jsonResponse );
            jsonArray = jsonObject.getJSONArray( arrayName );
        } catch ( Exception e ) {
            Log.message( "Error extracting JsonArray from JsonResponse" );
        }
        return jsonArray;
    }

    /**
     * This method is used to setup header for both positive & negative
     * scenarios Depends on @param validationFields
     * 
     * @param sessionCookie
     * @param validationFields
     * @return
     */
    public Map<String, String> getHeaders( String sessionCookie, String... validationFields ) {
        Map<String, String> headers = new HashMap<String, String>();
        String cookieKey = Constants.COOKIES;
        String cookieValue = sessionCookie;
        String contentTypeKey = Constants.CONTENT_TYPE;
        String contentTypeValue = Constants.JSON_CONTENT_TYPE;
        ;
        // validation fields
        String invalidCookieKey = "invalidCookieKey";
        String invalidCookieValue = "invalidCookieValue";
        String invalidContentType = "invalidContentType";
        String emptyContentType = "emptyContentType";
        String noContentType = "noContentType";

        try {
            if ( validationFields.length > 0 ) {
                // Setup- Headers - Cookie
                if ( validationFields[0].equals( invalidCookieKey ) )
                    cookieKey = Constants.COOKIES_INVALID;
                else if ( validationFields[0].equals( invalidCookieValue ) )
                    cookieValue = sessionCookie.replace( "JSESSIONID=", "JSESSIONID=1" );

                // Setup- Headers - Content Type
                if ( validationFields[0].equals( invalidContentType ) )
                    contentTypeValue = Constants.XML_CONTENT_TYPE;
                else if ( validationFields[0].equals( emptyContentType ) )
                    contentTypeValue = Constants.JSON_CONTENT_TYPE_EMPTY;
            }

            headers.put( cookieKey, cookieValue );
            if ( !validationFields[0].equals( noContentType ) )
                headers.put( contentTypeKey, contentTypeValue );

        } catch ( Exception e ) {
            Log.message( "Error in setting-up the headers in BaseAPITest" );
        }
        return headers;
    }

    /**
     * To create a course based on configurations.
     * 
     * @param smUrl
     * @param sessionCookie
     * @param subject
     * @param teacherID
     * @param schoolID
     * @param courseType
     * @param courseName
     * @return
     * @throws Exception
     */
    public String createCourse( String smUrl, String sessionCookie, String subject, String teacherID, String schoolID, String courseType, String courseName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        try {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Input Params
            HashMap<String, String> params = new HashMap<>();

            // EndPoint Details
            String endPoint_post = Constants.POST_STANDARD_COURSE_COPY;
            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, schoolID );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherID );

            Map<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( courseType.equalsIgnoreCase( DataSetupConstants.SETTINGS ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = generateRequestBody( DataSetupConstants.CUSTOM_BY_SETTING_BODY_MATH, courseDetails );
                } else {
                    requestBody = generateRequestBody( DataSetupConstants.CUSTOM_BY_SETTING_BODY_READING, courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.SKILL ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_BODY_MATH, courseDetails );
                } else {
                    requestBody = generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_BODY_READING, courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.STANDARD ) ) {
                List<String> standardDetails = new ArrayList<>();

                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    //      standardDetails = StandardVersionTable.getRandomStandardGradeID( DataSetupConstants.MATH );
                } else {
                    //     standardDetails = StandardVersionTable.getRandomStandardGradeID( DataSetupConstants.READING );
                }

                //    List<String> listLO = UserSqlHelper.getLOIDsRandomStandard( standardDetails.get( 0 ), standardDetails.get( 1 ) );
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
                //  courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO
                // courseDetails.put( Constants.LOID, listLO.get( 0 ) );
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "customByStandardsRandom_MATH.json" ), courseDetails );
                } else {
                    requestBody = generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "customByStandardsRandom_READING.json" ), courseDetails );
                }

            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.ONE_LO ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_ONE_LO, courseDetails );
                }
            }
            response_post = RestHttpClientUtil.POST( smUrl, headers, params, endPoint_post, requestBody );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }

    /**
     * To assign the course using course ID
     * 
     * @param smUrl
     * @param sessionCookie
     * @param subject
     * @param schoolID
     * @param teacherID
     * @param courseID
     * @param studentIDs
     * @return
     * @throws Exception
     */
    public boolean assignCourse( String smUrl, String sessionCookie, String subject, String schoolID, String teacherID, String courseID, List<String> studentIDs ) throws Exception {
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Input Params
            HashMap<String, String> params = new HashMap<>();

            // endpoint
            String endPoint = Constants.POST_STUDENTS_TO_COURSE;
            endPoint = endPoint.replace( "{organizationId}", schoolID );
            endPoint = endPoint.replace( "{staffId}", teacherID );
            endPoint = endPoint.replace( "{courseId}", courseID );

            String studentIds = "";
            for ( String studentID : studentIDs ) {
                studentIds += studentID + ",";
            }

            StringBuffer studentIDsForRequest = new StringBuffer( studentIds );
            studentIDsForRequest.deleteCharAt( studentIDsForRequest.length() - 1 );

            Map<String, String> studentDetailsRequest = new HashMap<String, String>();

            studentDetailsRequest.put( Constants.STUDENT_ID, studentIDsForRequest.toString() );
            String requestBody = null;
            String[] enrollmentOptions = DataSetupConstants.ENROLLMENT_OPTIONS_ARRAY.split( "," );
            String enrollmentOptionsValues = SMUtils.getKeyValueFromResponse( getEnrollmentOptions( smUrl, sessionCookie, courseID ), Constants.REPORT_BODY_DATA );
            if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                requestBody = generateAssignCourseBody( DataSetupConstants.ASSIGN_MATH_COURSE_STUDENT, "{" + enrollmentOptions[0] + "}", getEnrollmentOptionID( enrollmentOptionsValues, enrollmentOptions[0] ) );
            } else {
                requestBody = generateAssignCourseBody( DataSetupConstants.ASSIGN_READING_COURSE_STUDENT, "{" + enrollmentOptions[0] + "}", getEnrollmentOptionID( enrollmentOptionsValues, enrollmentOptions[0] ) );
            }
            for ( int i = 1; i < enrollmentOptions.length; i++ ) {
                requestBody = generateAssignCourseBody( requestBody, "{" + enrollmentOptions[i] + "}", getEnrollmentOptionID( enrollmentOptionsValues, enrollmentOptions[i] ) );
            }
            requestBody = generateRequestBody( requestBody, studentDetailsRequest );
            HashMap<String, String> response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );
            if ( response.get( Constants.STATUS_CODE ).equals( "200" ) ) {
                return true;
            } else {
                return false;
            }
        } catch ( Exception e ) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 
     * @param smUrl
     * @param sessionCookie
     * @param userType
     * @param personID
     * @return
     * @throws Exception
     */
    public String getUserDetails( String smUrl, String sessionCookie, String userType, String personID ) throws Exception {

        HashMap<String, String> response = new HashMap<>();
        try {
            //headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );

            //Input Params
            HashMap<String, String> params = new HashMap<>();
            String endPoint = null;
            //endPoint
            if ( userType.equalsIgnoreCase( "Teacher" ) ) {
                endPoint = Constants.GET_USER_PROFILE;
                endPoint = endPoint.replace( "{person_id}", personID );
            } else {
                endPoint = Constants.GET_STUDENT_DETAILS;
                endPoint = endPoint.replace( Constants.STUDENT_ID, personID );
            }
            response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
            return response.get( Constants.RESPONSE_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return response.get( Constants.RESPONSE_BODY );
        }
    }

    /**
     * This method used for create the student
     * 
     * @param smUrl
     * @param sessionCookie
     * @param userName
     * @param firstName
     * @param middleName
     * @param lastName
     * @param teacherID
     * @param orgID
     * @param grade
     * @return
     * @throws Exception
     */
    public String createStudent( String smUrl, String sessionCookie, String userName, String firstName, String middleName, String lastName, String teacherID, String orgID, String grade ) throws Exception {
        HashMap<String, String> response = new HashMap<>();
        try {
            //headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );

            String endPoint = Constants.CREATE_USER;
            HashMap<String, String> params = new HashMap<>();

            Map<String, String> studentDetails = new HashMap<String, String>();
            studentDetails.put( Constants.FIRSTNAME, firstName );
            studentDetails.put( Constants.MIDDLENAME, middleName );
            studentDetails.put( Constants.LASTNAME, lastName );
            studentDetails.put( Constants.TEACHER_ID, teacherID );
            studentDetails.put( Constants.SCHOOL_ID, orgID );
            studentDetails.put( Constants.GRADE, grade );
            studentDetails.put( Constants.USER_ID, userName );
            studentDetails.put( Constants.USER_NAME, userName );

            String requestBody = generateRequestBody( DataSetupConstants.CREATE_STUDENT_BODY, studentDetails );

            response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );

            return SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.PERSONID );
        } catch ( Exception e ) {
            e.printStackTrace();
            return response.get( Constants.REPORT_BODY );
        }
    }

    /**
     * This method used to get the enrollment option ID from enrollment options.
     * 
     * @param enrollmentOptions
     * @param enrollmentOptionName
     * @return
     */
    public String getEnrollmentOptionID( String enrollmentOptions, String enrollmentOptionName ) {
        String enrollmentOptionId = null;
        if ( enrollmentOptions.contains( enrollmentOptionName ) ) {
            String enrollmentOption = SMUtils.getKeyValueFromResponse( enrollmentOptions, enrollmentOptionName );
            enrollmentOptionId = SMUtils.getKeyValueFromResponse( enrollmentOption, "enrollmentOptionId" );
            return enrollmentOptionId;
        }
        return enrollmentOptionId;
    }

    /**
     * This method is used for adding the student to group.
     * 
     * @param smUrl
     * @param sessionCookie
     * @param groupID
     * @param studentID
     * @param staffID
     * @param schoolID
     * @return
     * @throws Exception
     */
    public boolean addStudentToGroup( String smUrl, String sessionCookie, Integer groupID, String studentID, Integer staffID, Integer schoolID ) throws Exception {
        try {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );

            // Input Params
            HashMap<String, String> params = new HashMap<>();

            // End-Point
            String endPoint = Constants.PUT_ADDSTUDENTS_GROUP;
            endPoint = endPoint.replace( Constants.ORG_ID, schoolID.toString() );
            endPoint = endPoint.replace( Constants.STAFF_ID, staffID.toString() );

            Map<String, String> groupDetails = new HashMap<String, String>();
            groupDetails.put( Constants.STUDENT_ID, studentID );
            groupDetails.put( Constants.GROUP_ID, groupID.toString() );

            String requestBody = generateRequestBody( DataSetupConstants.ADD_STUDENT_GROUP, groupDetails );
            HashMap<String, String> putResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, requestBody );
            if ( putResponse.get( Constants.STATUS_CODE ).equals( "200" ) )
                return true;
            else
                return false;

        } catch ( Exception e ) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * This method used for creating the group.
     * 
     * @param smUrl
     * @param sessionCookie
     * @param groupName
     * @param teacherID
     * @param schoolID
     * @return
     * @throws Exception
     */
    public Integer createGroup( String smUrl, String sessionCookie, String groupName, String teacherID, String schoolID ) throws Exception {
        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // InputParams
            HashMap<String, String> params = new HashMap<>();

            Map<String, String> groupDetails = new HashMap<String, String>();
            groupDetails.put( Constants.GROUP_NAME, groupName );
            // Generating request Body
            String requestBody = generateRequestBody( DataSetupConstants.CREATE_GROUP_BODY, groupDetails );

            // end point
            String endPoint = Constants.CREATE_GROUP_WITH_STUDENT;
            endPoint = endPoint.replace( Constants.ORGANIZATION_ID, schoolID );
            endPoint = endPoint.replace( Constants.TEACHER_ID, teacherID );

            response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );
            return Integer.parseInt( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.GROUP_ID ) );
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * This method gets all the enrollment options based on course ID.
     * 
     * @param smUrl
     * @param sessionCookie
     * @param courseID
     * @return
     * @throws Exception
     */
    public String getEnrollmentOptions( String smUrl, String sessionCookie, String courseID ) throws Exception {
        HashMap<String, String> response = new HashMap<>();
        try {
            Map<String, String> headers = new HashMap<String, String>();
            HashMap<String, String> params = new HashMap<>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            String endPoint = Constants.GET_ASSIGNMENT_SETTINGS;

            endPoint = endPoint.replace( "{course_id}", courseID );

            response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
            return response.get( Constants.REPORT_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return response.get( Constants.REPORT_BODY );
        }

    }

    /**
     * This method generates the request body for assign course API.
     * 
     * @param bodyTemplate
     * @param enrolmentOptionName
     * @param enrollmentOptionValue
     * @return
     */
    public String generateAssignCourseBody( String bodyTemplate, String enrolmentOptionName, String enrollmentOptionValue ) {
        String requestBody = bodyTemplate;
        if ( requestBody.contains( enrolmentOptionName ) ) {
            requestBody = requestBody.replace( enrolmentOptionName, enrollmentOptionValue );
        }
        return requestBody;
    }

    /**
     * This method generates the request body required for API.
     * 
     * @param requestBodyTemplate
     * @param requestDetails
     * @return
     */
    public String generateRequestBody( String requestBodyTemplate, Map<String, String> requestDetails ) {
        String requestBody = requestBodyTemplate;
        if ( requestBody.contains( Constants.GROUPNAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.GROUPNAME_VALUE, requestDetails.get( Constants.GROUP_NAME ) );
        }
        if ( requestBody.contains( Constants.STUDENT_IDS_VALUE ) ) {
            requestBody = requestBody.replace( Constants.STUDENT_IDS_VALUE, requestDetails.get( Constants.STUDENT_ID ) );
        }
        if ( requestBody.contains( Constants.GROUP_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.GROUP_ID_VALUE, requestDetails.get( Constants.GROUP_ID ) );
        }
        if ( requestBody.contains( Constants.SCHOOL_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.SCHOOL_ID_VALUE, requestDetails.get( Constants.SCHOOL_ID ) );
        }
        if ( requestBody.contains( Constants.FIRST_NAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.FIRST_NAME_VALUE, requestDetails.get( Constants.FIRSTNAME ) );
        }
        if ( requestBody.contains( Constants.MIDDLE_NAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.MIDDLE_NAME_VALUE, requestDetails.get( Constants.MIDDLENAME ) );
        }
        if ( requestBody.contains( Constants.LAST_NAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.LAST_NAME_VALUE, requestDetails.get( Constants.LASTNAME ) );
        }
        if ( requestBody.contains( Constants.USERNAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.USERNAME_VALUE, requestDetails.get( Constants.USER_NAME ) );
        }
        if ( requestBody.contains( Constants.TEACHER_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.TEACHER_ID_VALUE, requestDetails.get( Constants.TEACHER_ID ) );
        }
        if ( requestBody.contains( Constants.USERID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.USERID_VALUE, requestDetails.get( Constants.USER_ID ) );
        }
        if ( requestBody.contains( Constants.STUDENTUSERID ) ) {
            requestBody = requestBody.replace( Constants.STUDENTUSERID, requestDetails.get( Constants.USERID ) );
        }
        if ( requestBody.contains( Constants.GRADE_VALUE ) ) {
            requestBody = requestBody.replace( Constants.GRADE_VALUE, requestDetails.get( Constants.GRADE ) );
        }
        if ( requestBody.contains( Constants.COURSENAME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.COURSENAME_VALUE, requestDetails.get( Constants.COURSE_NAME ) );
        }
        if ( requestBody.contains( Constants.ASSIGNMENT_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.ASSIGNMENT_ID_VALUE, requestDetails.get( Constants.ASSIGNMENT_ID ) );
        }
        if ( requestBody.contains( Constants.ASSIGNMENT_USER_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.ASSIGNMENT_USER_ID_VALUE, requestDetails.get( Constants.ASSIGNMENT_USER_ID ) );
        }
        if ( requestBody.contains( Constants.GRADE_ID ) ) {
            requestBody = requestBody.replace( Constants.GRADE_ID, requestDetails.get( Constants.GRADE_ID ) );
        }
        if ( requestBody.contains( Constants.STANDARDFRAMEWORK_ID ) ) {
            requestBody = requestBody.replace( Constants.STANDARDFRAMEWORK_ID, requestDetails.get( Constants.STANDARDFRAMEWORK_ID ) );
        }
        if ( requestBody.contains( Constants.BANKID ) ) {
            requestBody = requestBody.replace( Constants.BANKID, requestDetails.get( Constants.BANKID ) );
        }
        if ( requestBody.contains( Constants.LOID ) ) {
            requestBody = requestBody.replace( Constants.LOID, requestDetails.get( Constants.LOID ) );
        }
        if ( requestBody.contains( Constants.SUBJECT_TYPE_ID_VALUE ) ) {
            requestBody = requestBody.replace( Constants.SUBJECT_TYPE_ID_VALUE, requestDetails.get( Constants.SUBJECT_ID ) );
        }
        if ( requestBody.contains( Constants.PAYLOAD_ASSIGNMENT_USER_IDS ) ) {
            requestBody = requestBody.replace( Constants.PAYLOAD_ASSIGNMENT_USER_IDS, requestDetails.get( Constants.ASSIGNMENT_USER_ID ) );
        }
        if ( requestBody.contains( Constants.PAYLOAD_SUBJECT_TYPE_ID ) ) {
            requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, requestDetails.get( Constants.SUBJECT_ID ) );
        }
        return requestBody;
    }

    /**
     * To get the group Students based on group ID
     * 
     * @param smUrl
     * @param sessionCookie
     * @param groupID
     * @return
     * @throws Exception
     */
    public String getGroupStudent( String smUrl, String sessionCookie, String groupID ) throws Exception {
        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // InputParams
            HashMap<String, String> params = new HashMap<>();

            // end point
            String endPoint = Constants.GET_GROUP_STUDNETS;
            endPoint = endPoint.replace( Constants.GROUP_ID, groupID );

            response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
            return response.get( Constants.REPORT_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return response.get( Constants.REPORT_BODY );
        }
    }

    /**
     * Get groups based on student ID
     * 
     * @param smUrl
     * @param sessionCookie
     * @param studentID
     * @param schoolID
     * @return
     * @throws Exception
     */
    public String getstudentGroups( String smUrl, String sessionCookie, String studentID, String schoolID ) {
        HashMap<String, String> response = new HashMap<>();
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // InputParams
            HashMap<String, String> params = new HashMap<>();
            params.put( Constants.STUDENT_LIST_PARAM, schoolID );
            // end point
            String endPoint = Constants.GET_GROUP_LIST;
            endPoint = endPoint.replace( "{person_Id}", studentID );
            response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
            return response.get( Constants.REPORT_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return response.get( Constants.REPORT_BODY );
        }
    }

    /**
     * Get the assignment by student id
     * 
     * @param smUrl
     * @param sessionCookie
     * @param studentID
     * @param schoolID
     * @param teacherID
     * @return
     * @throws Exception
     */
    public String getAssignmentByStudent( String smUrl, String sessionCookie, String studentID, String schoolID, String teacherID ) throws Exception {
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            HashMap<String, String> params = new HashMap<>();
            params.put( "organization-id", schoolID );
            params.put( "staff-id", teacherID );
            params.put( "student-id", studentID );

            // Input Path Parameters
            String endPoint = Constants.GET_ASSIGNMENT_DETAILS_BY_STUDENTID;

            Response response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint, params );
            return response.getBody().asString();
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Get the assignment by teacher ID
     * 
     * @param smUrl
     * @param sessionCookie
     * @param schoolID
     * @param teacherID
     * @return
     * @throws Exception
     */
    public String getAssignmentByTeacher( String smUrl, String sessionCookie, String schoolID, String teacherID ) throws Exception {
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            HashMap<String, String> params = new HashMap<>();

            // Input Path Parameters
            String endPoint = Constants.GET_ASSIGNMENTS_BY_TEACHER;
            endPoint = endPoint.replace( "{organization-id}", schoolID );
            endPoint = endPoint.replace( "{staff-id}", teacherID );

            HashMap<String, String> response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
            return response.get( Constants.REPORT_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * To delete the Group
     * 
     * @param smUrl
     * @param sessionCookie
     * @param schoolID
     * @param teacherID
     * @param groupId
     */
    public void deleteGroup( String smUrl, String sessionCookie, String schoolID, String teacherID, String groupId ) {

        String endPoint = Constants.DELETE_GROUP_DETAILS;
        endPoint = endPoint.replace( "{groupID}", groupId );

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.COOKIES, sessionCookie );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // InputParams
        HashMap<String, String> params = new HashMap<>();

        try {
            HashMap<String, String> response = RestHttpClientUtil.DELETE( smUrl, endPoint, headers, params );
            Log.message( groupId + " <=Group deleted!" );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /**
     * To Delete the Students by Admin
     * 
     * @param smUrl
     * @param sessionCookie ( admin session cookie)
     * @param studentIds
     * @param orgId
     * @return
     */
    public Boolean deleteStudents( String smUrl, String sessionCookie, ArrayList<String> studentIds, String orgId ) {
        String endPoint = Students.POST_DELETE_STUDENTS;
        // endPoint = endPoint.replace( Constants.ORG_ID, orgId );
        String requestBody = "{\"studentIds\":" + studentIds.toString() + "}";
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.COOKIES, sessionCookie );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        // InputParams
        Map<String, String> params = new HashMap<>();
        params.put( Constants.SCHOOL_ID, orgId );
        HashMap<String, String> response = null;
        try {
            response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );

        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if ( response.get( Constants.STATUS_CODE ).equals( "200" ) ) {
            Log.message( "Students deleted!" );
            return true;
        } else {
            Log.message( "Students not deleted. Received response=>" + response.get( Constants.RESPONSE_BODY ) );
            return false;
        }
    }

    /**
     * To transfer the user based on user type(Student/teacher)
     * 
     * @param smUrl
     * @param sessionCookie
     * @param oldSchoolID
     * @param newSchoolID
     * @param userType
     * @param personId
     * @return
     * @throws Exception
     */
    public Boolean transferUser( String smUrl, String sessionCookie, String oldSchoolID, String newSchoolID, String userType, String personId ) throws Exception {
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            HashMap<String, String> params = new HashMap<>();
            Map<String, String> userDetails = new HashMap<String, String>();

            String endPoint = null;
            String requestBody = null;

            if ( userType.toLowerCase().equals( "teacher" ) ) {
                endPoint = Constants.TRANSFER_TEACHER;
                endPoint = endPoint.replace( Constants.NEW_ORG_ID, newSchoolID );
                endPoint = endPoint.replace( Constants.ORG_ID, oldSchoolID );
                userDetails.put( Constants.TEACHER_ID, personId );
                requestBody = generateRequestBody( DataSetupConstants.TRANSFER_TEACHER_BODY, userDetails );
            } else {
                endPoint = Constants.TRANSFER_STUDENT;
                endPoint = endPoint.replace( Constants.NEW_ORG_ID, newSchoolID );
                userDetails.put( Constants.STUDENT_ID, personId );
                requestBody = generateRequestBody( DataSetupConstants.TRANSFER_STUDENT_BODY, userDetails );
            }

            HashMap<String, String> response = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, requestBody );
            if ( response.get( Constants.STATUS_CODE ).equals( "200" ) ) {
                Log.message( "Transferred the user!" );
                return true;
            } else {
                return false;
            }
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Restore assignment
     * 
     * @param smUrl
     * @param sessionCookie
     * @param assignmentId
     * @param assignmentUserId
     * @param studentID
     * @return
     * @throws Exception
     */
    public Boolean restoreAssignment( String smUrl, String sessionCookie, String assignmentId, String assignmentUserId, String studentID ) throws Exception {
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            HashMap<String, String> params = new HashMap<>();

            // Input Path Parameters
            String endPoint = Constants.RESTORE_ASSIGNMENT;

            Map<String, String> assignmentDetails = new HashMap<String, String>();
            assignmentDetails.put( Constants.STUDENT_ID, studentID );
            assignmentDetails.put( Constants.ASSIGNMENT_ID, assignmentId );
            assignmentDetails.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId );

            String requestBody = generateRequestBody( DataSetupConstants.RESTORE_ASSIGNMENT_BODY, assignmentDetails );
            HashMap<String, String> response = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, requestBody );
            if ( response.get( Constants.STATUS_CODE ).equals( "200" ) )
                return true;
            else
                return false;
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * To get Group Skills Assessment data
     * 
     * @param smUrl
     * @param sessionCookie
     * @param orgId
     * @param teacherId
     * @param groupId
     * @param subjectTypeId
     * @param contentBaseId
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getSkillsAssessmentDataFromAPI( String smUrl, String sessionCookie, String orgId, String teacherId, String groupId, String subjectTypeId, String contentBaseId ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.COOKIES, sessionCookie );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // InputParams
        HashMap<String, String> params = new HashMap<>();
        params.put( Constants.SUBJECT_TYPE_ID, subjectTypeId );

        // end point
        String endPoint = Constants.GET_SKILLS_ASSESSMENT;
        endPoint = endPoint.replace( Constants.ORG_ID, orgId );
        endPoint = endPoint.replace( Constants.STAFF_ID, teacherId );
        endPoint = endPoint.replace( Constants.CONTENTBASE_ID, contentBaseId );
        endPoint = endPoint.replace( Constants.GROUPID, groupId );

        //getting Skills Assessment data from API
        HashMap<String, String> response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
        return response;
    }

    /**
     * Get the assignment by student id
     * 
     * @param smUrl
     * @param sessionCookie
     * @param organizationId
     * @param studentId
     * @param teacherId
     * @param assignmentId
     * @param assignmentUserId
     * @param subjectType
     * @return
     * @throws Exception
     */
    public String getLastSessionSkillTestedByStudent( String smUrl, String sessionCookie, String schoolID, String teacherID, String studentID, String assignmentId, String assignmentUserId, String subjectType ) throws Exception {
        try {

            // InputParams
            HashMap<String, String> params = new HashMap<>();

            // headers
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            // request body
            HashMap<String, String> requestBody = new HashMap<>();
            requestBody.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId );
            if ( subjectType.equals( Constants.MATH ) ) {
                requestBody.put( Constants.SUBJECT_ID, "1" );
            } else {
                requestBody.put( Constants.SUBJECT_ID, "2" );
            }

            String requestPayLoad = generateRequestBody( Constants.LastSessionSkillTested.SKILLTESTED_BODY, requestBody );

            // end point
            String endPoint = Constants.LastSessionSkillTested.SKILL_TESTED_ENDPOINT;
            endPoint = endPoint.replace( Constants.ORG_ID, schoolID );
            endPoint = endPoint.replace( Constants.STAFF_ID, teacherID );
            endPoint = endPoint.replace( Constants.ASSIGNMENT_ID_VALUE, assignmentId );
            endPoint = endPoint.replace( Constants.STUDENT_IDS_VALUE, studentID );

            //getting data from API
            HashMap<String, String> response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestPayLoad );
            return response.get( Constants.REPORT_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * This method used for update the student
     * 
     * @param smUrl
     * @param sessionCookie
     * @param userName
     * @param firstName
     * @param middleName
     * @param lastName
     * @param teacherID
     * @param orgID
     * @param grade
     * @return
     * @throws Exception
     */
    public String updateStudent( String smUrl, String sessionCookie, String userName, String firstName, String middleName, String lastName, String teacherID, String orgID, String grade, String personId ) throws Exception {
        HashMap<String, String> response = new HashMap<>();
        try {
            //headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );

            String endPoint = Constants.CREATE_USER + "/" + personId;
            HashMap<String, String> params = new HashMap<>();

            Map<String, String> studentDetails = new HashMap<>();
            studentDetails.put( Constants.FIRSTNAME, firstName );
            studentDetails.put( Constants.MIDDLENAME, middleName );
            studentDetails.put( Constants.LASTNAME, lastName );
            studentDetails.put( Constants.TEACHER_ID, teacherID );
            studentDetails.put( Constants.SCHOOL_ID, orgID );
            studentDetails.put( Constants.GRADE, grade );
            studentDetails.put( Constants.USER_ID, userName );
            studentDetails.put( Constants.USER_NAME, userName );

            String requestBody = generateRequestBody( DataSetupConstants.CREATE_STUDENT_BODY, studentDetails );

            response = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, requestBody );

            return response.get( Constants.REPORT_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return response.get( Constants.REPORT_BODY );
        }
    }

    /**
     * To get the reportUsage for groups
     * 
     * @param smUrl
     * @param sessionCookie
     * @param organizationId
     * @param staffId
     * @param groupId
     * @return
     * @throws Exception
     */
    public String getGroupUsageReport( String smUrl, String sessionCookie, String organizationId, String staffId, String groupId ) throws Exception {
        try {

            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            HashMap<String, String> params = new HashMap<>();
            params.put( Constants.GROUP_ID, groupId );

            // Input Path Parameters
            String endPoint = Constants.GROUP_USAGE_REPORT;
            endPoint = endPoint.replace( Constants.ORGANIZATION_ID, organizationId );
            endPoint = endPoint.replace( Constants.STAFF_ID_VALUE, staffId );
            String requestBody = "{}";
            HashMap<String, String> response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );
            return response.get( Constants.REPORT_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Get the assignment by teacher ID
     * 
     * @param smUrl
     * @param sessionCookie
     * @param schoolID
     * @param teacherID
     * @return
     * @throws Exception
     */
    public String getUsageGoal( String smUrl, String sessionCookie, String schoolID, String teacherID ) throws Exception {
        try {
            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            HashMap<String, String> params = new HashMap<>();

            String endPoint = Constants.GET_USAGE_GOAL;
            endPoint = endPoint.replace( Constants.ORG_ID, schoolID );
            endPoint = endPoint.replace( Constants.STAFF_ID, teacherID );

            //Get usage details
            HashMap<String, String> response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
            return response.get( Constants.REPORT_BODY );

        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Get the assignment by teacher ID
     * 
     * @param smUrl
     * @param sessionCookie
     * @param schoolID
     * @param teacherID
     * @param assignmentUserIds
     * @param subjectID
     * @return
     * @throws Exception
     */
    public String getUsageGoalStudentList( String smUrl, String sessionCookie, String schoolID, String teacherID, String assignmentUserIds, String subjectID ) throws Exception {
        try {

            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.COOKIES, sessionCookie );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            HashMap<String, String> params = new HashMap<>();

            String postEndPoint = Constants.POST_USAGE_GOAL_STUDENTLIST;
            postEndPoint = postEndPoint.replace( Constants.ORG_ID, schoolID );
            postEndPoint = postEndPoint.replace( Constants.STAFF_ID, teacherID );

            // request body
            HashMap<String, String> requestDetails = new HashMap<>();
            requestDetails.put( Constants.ASSIGNMENT_USER_ID, assignmentUserIds );
            requestDetails.put( Constants.SUBJECT_ID, subjectID );

            String requestPayLoad = generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "UsageGoalStudentList.json" ), requestDetails );

            //Get usage details
            HashMap<String, String> postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, requestPayLoad );

            return postResponse.get( Constants.REPORT_BODY );
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

}