package com.savvas.sm.api.tests.smnew.homePage;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.restoreassignment.RestoreAssignment;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.homepage.HomePage;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class EditUsageGoalAPITest extends EnvProperties {
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    //private String mathSchool = RBSDataSetup.getSchools(Schools.MATH_SCHOOL);
    private String smUrl;
    private String flexSchoolTeacherDetails;
    private String orgID;
    private String userID;
    private String studentDetail;
    private String studentUsername;
    private String teacherUsername;
    private String password;
    private String exception = null;
    private String message = null;
    private String accessToken;
    private static List<String> studentRumbaIds = new ArrayList<>();
    String mathSchoolTeacherDetails;
    HashMap<String, String> assignmentDetails = new HashMap<>();
    HashMap<String, String> mathAssignmentDetails = new HashMap<>();
    HashMap<String, String> readingAssignmentDetails = new HashMap<>();
    HashMap<String, String> groupdetails = new HashMap<>();
    Map<String, String> response = new HashMap<>();
    Map<String, String> assignmentResponse = new HashMap<>();
    SqlHelperCourses helperCourse = new SqlHelperCourses();
    String mathAssignmentUserId1;
    String mathAssignmentUserId2;
    String readingAssignmentUserId1;
    String readingAssignmentUserId2;
    String endDateFromGetResponse;
    String targetHrsFromGetResponse;
    HomePage homePage = new HomePage();
    AssignmentAPI assign = new AssignmentAPI();
    LocalDate today = LocalDate.now();
    private String teacherDetails;

    @BeforeClass(alwaysRun = true)
    public void beforeClass() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );

        //mathSchoolTeacherDetails = RBSDataSetup.getMyTeacher(mathSchool);
        userID = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        // Getting ORGID of Flex school
        orgID = RBSDataSetup.organizationIDs.get( flexSchool );
        // Getting Students from Flex school
        studentDetail = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( flexSchool, teacherUsername ), "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( flexSchool, teacherUsername ), "userId" ) );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        accessToken = new RBSUtils().getAccessToken( teacherUsername, password );
        // Creating Group to add the student to assign assignment
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, userID );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgID );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupdetails, studentRumbaIds );
        Log.message( "" + createGroup );

        // Assigning Math assignment
        mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
        mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
        mathAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        
        Log.message( "Math Assignment Details: " + mathAssignmentDetails );
        Log.message( "Student Details: " + studentRumbaIds);
        
        HashMap<String, String> mathRssignmentResponse = assign.assignMultipleAssignments( smUrl, mathAssignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );

        // Getting assignment id
        JSONObject mathAssignmentDetailsJson = new JSONObject( mathRssignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject mathAssignmentInfo = new JSONObject( mathAssignmentList.get( 0 ).toString() );
        String mathAssignmentId = mathAssignmentInfo.get( "assignmentId" ).toString();
        mathAssignmentUserId1 = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), mathAssignmentId );
        mathAssignmentUserId2 = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 1 ), mathAssignmentId );

        // Assigning Reading assignment
        readingAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
        readingAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
        readingAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
        readingAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        
        Log.message( "Reading Assignment Details: " + readingAssignmentDetails );
        Log.message( "Student Details: " + studentRumbaIds);
        
        HashMap<String, String> readingAssignmentResponse = assign.assignMultipleAssignments( smUrl, readingAssignmentDetails, studentRumbaIds, Arrays.asList( "2" ) );

        // Getting assignment id
        JSONObject readingAssignmentDetailsJson = new JSONObject( readingAssignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray readingAssignmentList = readingAssignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject readingAssignmentInfo = new JSONObject( readingAssignmentList.get( 0 ).toString() );
        String readingAssignmentId = readingAssignmentInfo.get( "assignmentId" ).toString();
        readingAssignmentUserId1 = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), readingAssignmentId );
        readingAssignmentUserId2 = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 1 ), readingAssignmentId );

    }

    @Test ( dataProvider = "getDataforPostive", priority = 1, groups = { "smoke_test_case","EditUsage", "SMK-51100", "P1", "API" } )
    public void getUsageGoal_Positive( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseID + " - " + testDescription );
        String endDate = "";
        String targetHours = "";
        Map<String, String> getResponse = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        headers.put( Constants.ORGID_SM_HEADER, orgID );
        headers.put( Constants.USERID_SM_HEADER, userID );

        switch ( scenario ) {
            case "Update target hours and end date for Math":
                endDate = String.valueOf( today.plusDays( 10 ) );
                targetHours = "25";
                homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( mathAssignmentUserId1 ), "1" );

                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID, endDate, targetHours, Arrays.asList( mathAssignmentUserId1 ), "" );
                // Data validation
                getResponse = homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( mathAssignmentUserId1 ), "1" );

                break;

            case "Update target hours and end date for Reading":
                endDate = String.valueOf( today.plusDays( 10 ) );
                targetHours = "25";
                homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( readingAssignmentUserId1 ), "2" );

                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID, endDate, targetHours, Arrays.asList( readingAssignmentUserId1 ), "" );
                getResponse = homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( readingAssignmentUserId1 ), "2" );

                break;

            case "Update target hours and end date more than one student for Math":
                endDate = String.valueOf( today.plusDays( 10 ) );
                targetHours = "30";
                homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( mathAssignmentUserId2 ), "1" );
                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID, endDate, targetHours, Arrays.asList( mathAssignmentUserId1, mathAssignmentUserId2 ), "" );
                getResponse = homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( mathAssignmentUserId1 ), "1" );
                break;

            case "Update target hours and end date more than one student for Reading":
                endDate = String.valueOf( today.plusDays( 10 ) );
                targetHours = "20";
                homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( readingAssignmentUserId2 ), "2" );
                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID, endDate, targetHours, Arrays.asList( readingAssignmentUserId1, readingAssignmentUserId2 ), "" );
                getResponse = homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( readingAssignmentUserId1 ), "2" );
                break;

            case "Edit the end date in Usage goals for student with valid data":
                endDate = String.valueOf( today.plusDays( 10 ) );
                targetHours = "30";
                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID, endDate, targetHours, Arrays.asList( mathAssignmentUserId1, mathAssignmentUserId2 ), "" );
                getResponse = homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( mathAssignmentUserId1 ), "1" );
                break;

            case "When student is not attended the Math session so far":
                endDate = String.valueOf( today.plusDays( 10 ) );
                targetHours = "30";
                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID, endDate, targetHours, Arrays.asList( mathAssignmentUserId1 ), "" );
                getResponse = homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( mathAssignmentUserId1 ), "1" );
                break;

            case "When student is not attended the Reading session so far":
                endDate = String.valueOf( today.plusDays( 10 ) );
                targetHours = "30";
                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID, endDate, targetHours, Arrays.asList( readingAssignmentUserId1 ), "" );
                getResponse = homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( readingAssignmentUserId1 ), "2" );
                break;

            case "when restored Math assignmentUserId is given in request body":
                // Edit Usage Goal of Student
                endDate = String.valueOf( today.plusDays( 10 ) );
                targetHours = "30";
                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID, endDate, targetHours, Arrays.asList( mathAssignmentUserId1 ), "" );
                // Removing math assignment
                HashMap<String, String> assignmentDetailMath = new HashMap<>();
                assignmentDetailMath.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetailMath.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetailMath.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetailMath.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, mathAssignmentUserId1 );
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetailMath, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

                // Restore Math assignmnet
                HashMap<String, String> userDetail = new HashMap<>();
                userDetail.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
                userDetail.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                userDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, mathAssignmentUserId1 );
                Log.assertThat( new RestoreAssignment().restoreDeletedAssignment( smUrl, userDetail, CourseAPIConstants.NULL ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment restored sucessfully!", "Issue in restoring the assignment!" );

                getResponse = homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( mathAssignmentUserId1 ), "1" );
                break;

            case "when restored Reading assignmentUserId is given in request body":

                // Edit Usage Goal of Student
                endDate = String.valueOf( today.plusDays( 10 ) );
                targetHours = "30";
                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID, endDate, targetHours, Arrays.asList( readingAssignmentUserId1 ), "" );
                Log.message( response.toString() );
                // remove Reading assignment for student
                HashMap<String, String> assignmentDetailReading = new HashMap<>();
                assignmentDetailReading.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetailReading.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetailReading.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentDetailReading.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, readingAssignmentUserId1 );
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetailReading, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

                // Restore Reading assignment
                HashMap<String, String> adminUserDetail = new HashMap<>();
                adminUserDetail.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
                adminUserDetail.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                adminUserDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                adminUserDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, readingAssignmentUserId1 );
                Log.assertThat( new RestoreAssignment().restoreDeletedAssignment( smUrl, adminUserDetail, CourseAPIConstants.NULL ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment restored sucessfully!", "Issue in restoring the assignment!" );

                getResponse = homePage.getUsageGoalStudentList( smUrl, headers, userID, orgID, Arrays.asList( readingAssignmentUserId1 ), "2" );
                break;
        }

        //Status code verification
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        //schema validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "EditUsageGoal", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        // Data validation
        endDateFromGetResponse = SMUtils.getKeyValueFromResponse( getResponse.get( Constants.REPORT_BODY ), "data,goalEndDate" );
        targetHrsFromGetResponse = SMUtils.getKeyValueFromResponse( getResponse.get( Constants.REPORT_BODY ), "data,goalMinutesInCourse" );
        Log.message( "getresponse " + getResponse.get( Constants.REPORT_BODY ) );
        Log.message( endDateFromGetResponse );
        Log.message( targetHrsFromGetResponse );
        Log.message( "" + Integer.parseInt( targetHours ) * 60 );
        Log.assertThat( Arrays.asList( endDateFromGetResponse.split( "/" ) ).containsAll( Arrays.asList( endDate.split( "-" ) ) ), "Enddate updated successfully", "Issue in updating the end date " );
        Log.assertThat( targetHrsFromGetResponse.equals( String.valueOf( Integer.parseInt( targetHours ) * 60 ) ), "Target hours updated successfully", "Issue in updating target hours" );

    }

    @Test ( priority = 2, dataProvider = "getDataforNegative", groups = {"EditUsage", "SMK-51100", "P2", "API" } )
    public void tcNegativeTestcases( String tcId, String description, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        String accessToken = new RBSUtils().getAccessToken( teacherUsername, password );

        switch ( scenario ) {
            case "Negative with invalid authorization":
                response = new HomePage().putEditUsageGoal( smUrl, accessToken + "inviald", orgID, userID, String.valueOf( today.plusDays( 10 ) ), "25", Arrays.asList( mathAssignmentUserId1 ), "" );
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "Negative with invalid UserID":
                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID + "inviald", String.valueOf( today.plusDays( 10 ) ), "25", Arrays.asList( mathAssignmentUserId1 ), "" );
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "Negative with invalid End point":
                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID, String.valueOf( today.plusDays( 10 ) ), "25", Arrays.asList( mathAssignmentUserId1 ), "/lms/web/api/v1/usageGoalsSettingsinvalid" );

                break;

            case "Negative with Student's Authorization":

                response = new HomePage().putEditUsageGoal( smUrl, new RBSUtils().getAccessToken(studentUsername,password ),
                        RBSDataSetup.organizationIDs.get( flexSchool ), SMUtils.getKeyValueFromResponse( studentDetail, "userId" ), String.valueOf( today.plusDays( 10 ) ), "25",
                        Arrays.asList( mathAssignmentUserId1 ), "" );
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "Empty end date is passing ":
                response = new HomePage().putEditUsageGoal( smUrl, accessToken, orgID, userID, "1", "25", Arrays.asList( mathAssignmentUserId1 ), "" );
                message = CommonAPIConstants.EMPTY_END_DATE;
                exception = CommonAPIConstants.VALIDATION_EXCEPTION;
                break;

            case "Negative with  Admin's Authorization":
                String adminToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                String adminOrgId1 = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN ), "primaryOrgId" );
                String adminUserId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN ), RBSDataSetupConstants.USERID );

                Log.message( "Token: " + adminToken );
                Log.message( "admin orgid: " + adminOrgId1 );
                Log.message( "admin user id: " + adminUserId );

                response = new HomePage().putEditUsageGoal( smUrl, adminToken, adminOrgId1, adminUserId, String.valueOf( today.plusDays( 10 ) ), "25", Arrays.asList( mathAssignmentUserId1 ), "" );
                message = CommonAPIConstants.UNEXPECTED_ERROR;
                exception = CommonAPIConstants.NULL_EXCEPTION_NEW;
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

        if ( !scenario.equalsIgnoreCase( "Negative with invalid End point" ) ) {
            // Schema Validation
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "EditUsageGoal", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

            // Exception validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ).equalsIgnoreCase( exception ), "Exception Verified successfully!",
                    "Issue in displaying exception! Expected - " + exception + "Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ) );

            // Status Validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,status" ).equalsIgnoreCase( "failure" ), "Status Verified successfully!", "Issue in displaying Status!" );

            // message Validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( message ), "Message Verified successfully!",
                    "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ) );

        }
    }

    @DataProvider ( name = "getDataforPostive" )
    public Object[][] getDataforPostive() {
        Object[][] data = { { "tcEditUsageGoal001", "Verify the status code is 200 for updating Math course target hours and target end date for one student.", "200", "Update target hours and end date for Math" },
                { "tcEditUsageGoal002", "Verify the status code is 200 for updating Reading course target hours and target end date for one student.", "200", "Update target hours and end date for Reading" },
                { "tcEditUsageGoal003", "Verify the status code is 200 for updating Math course target hours and target end date for more than one students", "200", "Update target hours and end date more than one student for Math" },
                { "tcEditUsageGoal004", "Verify the status code is 200 for updating Reading course target hours and target end date for more than one students", "200", "Update target hours and end date more than one student for Reading" },
                { "tcEditUsageGoal005", "Edit the end date in Usage goals for student with valid data, Verify the status code is 200 ", "200", "Edit the end date in Usage goals for student with valid data" },
                { "tcEditUsageGoal006", "verify the Status Code is 200 and valid Response body, when the student is not attended the Math session so far.", "200", "When student is not attended the Math session so far" },
                { "tcEditUsageGoal007", "verify the Status Code is 200 and valid Response body, when the student is not attended the Reading session so far.", "200", "When student is not attended the Reading session so far" },
                { "tcEditUsageGoal008", "Verify the status code is 200 with response body when restored Math assignmentUserId is given in request body.", "200", "when restored Math assignmentUserId is given in request body" },
                { "tcEditUsageGoal009", "Verify the status code is 200 with response body when restored Reading assignmentUserId is given in request body.", "200", "when restored Reading assignmentUserId is given in request body" }, };
        return data;
    }

    @DataProvider ( name = "getDataforNegative" )
    public Object[][] getDataforNegative() {
        Object[][] data = { { "tcEditUsageGoal0010", "Verify the status code is 401 for incorrect authorization", "401", "Negative with invalid authorization" },
                { "tcEditUsageGoal0011", "Verify the status code is 401 when invalid headers is passed", "401", "Negative with invalid UserID" },
                { "tcEditUsageGoal0012", "Verify the status code is 404 for incorrect End poin is given", "404", "Negative with invalid End point" },
                { "tcEditUsageGoal0013", "Verify the status code is 401 for Student's Authorization .", "401", "Negative with Student's Authorization" },
                { "tcEditUsageGoal0014", "Verify response with 400 Bad request  when empty  end date is passing", "400", "Empty end date is passing " },
                { "tcEditUsageGoal0015", "Verify the status code is 401 for Admin's Authorization .", "401", "Negative with  Admin's Authorization" },

        };
        return data;
    }

    // This method is extracting error message from response
    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

}