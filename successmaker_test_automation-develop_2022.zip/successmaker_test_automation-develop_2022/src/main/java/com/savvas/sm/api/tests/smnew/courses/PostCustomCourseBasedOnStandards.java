package com.savvas.sm.api.tests.smnew.courses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

public class PostCustomCourseBasedOnStandards extends CourseAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String flexSchoolTeacherDetails = null;
    private String mathSchoolTeacherDetails = null;
    private String readingSchoolTeacherDetails = null;
    private String focusReadingSchoolTeacherDetails = null;
    private String focusMathSchoolTeacherDetails = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String readingSchool = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String focusMathSchool = RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL );
    private String focusReadingSchool = RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL );
    private String token = null;
    String userName = null;
    String schoolType = null;
    String courseNameBasedOnStandard = null;
    String orgID = null;
    String userID = null;
    public  String isItMt = null;

    @BeforeClass(alwaysRun=true)
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        mathSchoolTeacherDetails = RBSDataSetup.getMyTeacher( mathSchool );
        readingSchoolTeacherDetails = RBSDataSetup.getMyTeacher( readingSchool );
        focusMathSchoolTeacherDetails = RBSDataSetup.getMyTeacher( focusMathSchool );
        focusReadingSchoolTeacherDetails = RBSDataSetup.getMyTeacher( focusReadingSchool );
        //Course name
        courseNameBasedOnStandard = "Course Based On Standard" + System.nanoTime();
        orgID = RBSDataSetup.organizationIDs.get( mathSchool );
        userID = SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, "userId" );
        isItMt = configProperty.getProperty( "isMTExecution" );
    }

    @Test ( priority = 1, dataProvider = "scenarioForPostCustomCourse", groups = { "SMK-52106", "Course", "CustomCourseByStandards", "P1", "API", "smoke_test_case" } )
    public void postCustomCourseBasedOnStandards( String description, String scenario, String statusCode, String schoolTypeForTokenCreation, String successStatusCodeForGroupCreation, String courseId, String productDescription,
            String statusCodeForCustomCourse, String orgIdValidity, String authorizationValidity, String teacherValidity, String courseIdValidity, String courseNameValidity, String gradeIdValidity, String standardIdValidity, String contentBaseIdValidity,
            String mapLoTaxonomyIdMapValidity, String bankIdValidity, String loIdValidity, String payload ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );
        Map<String, String> apiResponseForCustomCourseCreation = null;
        Map<String, String> apiResponseForGetCourseListPresentOnDashboard = new HashMap<>();
        String reponseDataForValidation;
        Map<String, String> customCourseBasedOnStandardParameters = new HashMap<>();
        String courseNameBasedOnStandard = null;
        List<String> totalCoursesBefore = new ArrayList<String>();
        List<String> totalCoursesAfter = new ArrayList<String>();

        switch ( scenario ) {

            case "CATEGORY_ONE":
                //Creating school based one the licenses
                tokenCreation( schoolTypeForTokenCreation );

                //Course name
                courseNameBasedOnStandard = "Course Based On Standard" + System.nanoTime();

                if ( CourseAPIConstants.INVALID.equalsIgnoreCase( authorizationValidity ) ) {
                    customCourseBasedOnStandardParameters.put( RBSDataSetupConstants.BEARER_TOKEN, CourseAPIConstants.INVALID_AUTHORIZATION_ID );
                } else {
                    customCourseBasedOnStandardParameters.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                }

                if ( CourseAPIConstants.INVALID.equalsIgnoreCase( teacherValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.INVALID_STAFF_ID, CourseAPIConstants.INVALID_STAFF_ID_RANDOM );
                } else if ( CourseAPIConstants.NON_EXISTING.equalsIgnoreCase( teacherValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.INVALID_STAFF_ID, CourseAPIConstants.NON_EXISTING_STAFF_ID );
                } else {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                }

                if ( CourseAPIConstants.INVALID.equalsIgnoreCase( orgIdValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.INVALID_ORG_ID, CourseAPIConstants.INVALID_ORGANIZATION_ID );
                } else if ( CourseAPIConstants.NON_EXISTING.equalsIgnoreCase( orgIdValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.INVALID_ORG_ID, CourseAPIConstants.NON_EXISTING_ORGANIZATION_ID );
                } else {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
                }

                if ( CourseAPIConstants.INVALID.equalsIgnoreCase( courseIdValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.COURSE_ID, CourseAPIConstants.INVALID_COURSE_ID );
                } else if ( CourseAPIConstants.NON_EXISTING.equalsIgnoreCase( courseIdValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.COURSE_ID, CourseAPIConstants.NON_EXISTING_COURSE_ID );
                } else {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.COURSE_ID, courseId );
                }

                if ( CourseAPIConstants.NULL.equalsIgnoreCase( courseNameValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.COURSE_NAME, CourseAPIConstants.COURSE_NAME_NULL );
                }

                if ( CourseAPIConstants.INVALID.equalsIgnoreCase( gradeIdValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.GRADE_ID, CourseAPIConstants.INVALID_GRADE_ID );
                } else if ( CourseAPIConstants.NON_EXISTING.equalsIgnoreCase( gradeIdValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.GRADE_ID, CourseAPIConstants.NON_EXISTING_GRADE_ID );
                }

                if ( CourseAPIConstants.INVALID.equalsIgnoreCase( standardIdValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.STANDARD_FRAMEWORK_ID, CourseAPIConstants.INVALID_STANDARD_FRAMEWORK_ID );
                } else if ( CourseAPIConstants.NON_EXISTING.equalsIgnoreCase( standardIdValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.STANDARD_FRAMEWORK_ID, CourseAPIConstants.NON_EXISTING_STANDARD_FRAMEWORK_ID );
                }

                if ( CourseAPIConstants.INVALID.equalsIgnoreCase( contentBaseIdValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.CONTENT_BASE_TYPE, CourseAPIConstants.INVALID_CONTENT_BASE_TYPE );
                } else {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.CONTENT_BASE_TYPE, "4" );
                }

                if ( CourseAPIConstants.INVALID.equalsIgnoreCase( mapLoTaxonomyIdMapValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.MAP_LO_TAXONOMY, CourseAPIConstants.INVALID_MAP_LO_TAXONOMY );
                } else if ( CourseAPIConstants.NON_EXISTING.equalsIgnoreCase( mapLoTaxonomyIdMapValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.MAP_LO_TAXONOMY, CourseAPIConstants.NON_EXISTING_MAP_LO_TAXONOMY );
                }

                if ( CourseAPIConstants.INVALID.equalsIgnoreCase( loIdValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.LO, CourseAPIConstants.INVALID_LO );
                } else if ( CourseAPIConstants.NON_EXISTING.equalsIgnoreCase( loIdValidity ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.LO, CourseAPIConstants.NON_EXISTING_LO );
                }

                if ( CourseAPIConstants.TRUE.equalsIgnoreCase( payload ) ) {
                    customCourseBasedOnStandardParameters.put( CourseAPIConstants.PAYLOAD, payload );
                }

                customCourseBasedOnStandardParameters.put( CourseAPIConstants.COURSE_TYPE, DataSetupConstants.STANDARD );
                customCourseBasedOnStandardParameters.put( CourseAPIConstants.COURSE_NAME, courseNameBasedOnStandard );
                customCourseBasedOnStandardParameters.put( CourseAPIConstants.STATUS_CODE, statusCodeForCustomCourse );
                customCourseBasedOnStandardParameters.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                customCourseBasedOnStandardParameters.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( schoolType ) );

                //Get courses present at teacher course ware
                apiResponseForGetCourseListPresentOnDashboard = getCoursesAtOrgLevelTeacherUi( schoolType );

                //Getting the subject name
                reponseDataForValidation = SMUtils.getKeyValueFromResponse( apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ), Constants.DATA );
                totalCoursesBefore = SMUtils.getTheKeyCount( reponseDataForValidation.toString(), Constants.ID );

                //Get courses present at teacher UI home page
                apiResponseForCustomCourseCreation = postCustomCourseBasedOnStandard( schoolType, customCourseBasedOnStandardParameters );
                Log.message( "Course Id is " + apiResponseForCustomCourseCreation );

                //Get courses present at teacher course ware
                apiResponseForGetCourseListPresentOnDashboard = getCoursesAtOrgLevelTeacherUi( schoolType );
                Log.message( "Returned API Response - " + apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ) );

                //Getting the subject name
                reponseDataForValidation = SMUtils.getKeyValueFromResponse( apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ), Constants.DATA );
                totalCoursesAfter = SMUtils.getTheKeyCount( reponseDataForValidation.toString(), Constants.ID );

                //Assertion
                Log.softAssertThat( apiResponseForCustomCourseCreation.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCodeForCustomCourse ),
                        "Status code is returned as expected and the same is " + apiResponseForCustomCourseCreation.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + apiResponseForCustomCourseCreation + " Actual - " + apiResponseForCustomCourseCreation.get( Constants.STATUS_CODE ) );

                Log.softAssertThat( Boolean.TRUE.equals( totalCoursesBefore.size() == totalCoursesAfter.size() ), "As expected no new courses were created", "New courses have been created. Please check!!! " );
                break;

            default:
                //Creating school based one the licenses
                tokenCreation( schoolTypeForTokenCreation );

                //Course name
                courseNameBasedOnStandard = "Course Based On Standard" + System.nanoTime();

                customCourseBasedOnStandardParameters.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                customCourseBasedOnStandardParameters.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                customCourseBasedOnStandardParameters.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
                customCourseBasedOnStandardParameters.put( CourseAPIConstants.COURSE_ID, courseId );
                customCourseBasedOnStandardParameters.put( CourseAPIConstants.COURSE_TYPE, DataSetupConstants.STANDARD );
                customCourseBasedOnStandardParameters.put( CourseAPIConstants.COURSE_NAME, courseNameBasedOnStandard );
                customCourseBasedOnStandardParameters.put( CourseAPIConstants.STATUS_CODE, statusCodeForCustomCourse );
                customCourseBasedOnStandardParameters.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                customCourseBasedOnStandardParameters.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( schoolType ) );

                //Get courses present at teacher UI home page
                apiResponseForCustomCourseCreation = postCustomCourseBasedOnStandard( schoolType, customCourseBasedOnStandardParameters );
                Log.message( "Course Id is " + apiResponseForCustomCourseCreation );

                //Get courses present at teacher UI home page
                apiResponseForGetCourseListPresentOnDashboard = getCoursesAtOrgLevelTeacherUi( schoolType );

                //Getting the subject name
                reponseDataForValidation = SMUtils.getKeyValueFromResponse( apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ), Constants.DATA );

                //Assertion
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataForValidation, CourseAPIConstants.PRODUCT_DESCRIPTION, productDescription ), "Expected course is present in the response", "Expected course is absent in the response" );
                Log.softAssertThat(
                        SMUtils.compareKeyValue( reponseDataForValidation, Constants.ID, SMUtils.getKeyValueFromResponse( apiResponseForCustomCourseCreation.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID ) ),
                        "Expected course ID is present in the response", "Expected course ID is absent in the response" );

                Log.softAssertThat( apiResponseForGetCourseListPresentOnDashboard.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ),
                        "Status code is returned as expected and the same is " + apiResponseForGetCourseListPresentOnDashboard.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponseForGetCourseListPresentOnDashboard.get( Constants.STATUS_CODE ) );
                break;
        }
        //Logging final status(pass/fail) for each case
//        Log.testCaseResult();
    }

    @Test ( priority = 1, dataProvider = "createCustomCourseBasedOnStandards", groups = { "SMK-53109", "GetSkillsHierarchy for Custom Courses", "Course", "P1", "API" } )
    public void createCourseBasedOnStandardsNegativeScenarios( String description, String scenario, String scenario1, String schoolTypeForTokenCreation, String statusCode, String gradeId, String courseId, String standardFrmeworkId, String parentNode,
            String ChildNode, String contentBaseID, String courseName, String settingName, String settingsID, String settingValue, String orgId, String teacherId ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> courseDetails = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> headersInvalid = new HashMap<>();

        Map<String, String> apiResponseForGetCourseListPresentOnDashboard = new HashMap<>();
        String reponseDataForValidation;
        List<String> totalCoursesBefore = new ArrayList<String>();
        List<String> totalCoursesAfter = new ArrayList<String>();

        // Authorization
        tokenCreation( schoolTypeForTokenCreation );

        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( schoolType ) );
        headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        courseDetails.put( Constants.GRADE_VALUE, gradeId );
        courseDetails.put( Constants.STANDARD_FRAMEWORK_VALUE, standardFrmeworkId );
        courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
        courseDetails.put( CourseAPIConstants.PARENT_NODE, parentNode );
        courseDetails.put( CourseAPIConstants.CHILD_NODE, ChildNode );
        courseDetails.put( CourseAPIConstants.CONTENT_BASE_ID, contentBaseID );

        courseDetails.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( settingsID ) );
        courseDetails.put( CourseAPIConstants.SESSION_STRENGTH_NAME, settingName );
        courseDetails.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, settingValue );

        courseDetails.put( Constants.COURSE_NAME, courseName );

        //Get courses present at teacher course ware
        apiResponseForGetCourseListPresentOnDashboard = getCoursesAtOrgLevelTeacherUi( schoolType );
        Log.message( "Returned API Response - " + apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ) );

        //Getting the subject name
        reponseDataForValidation = SMUtils.getKeyValueFromResponse( apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ), Constants.DATA );
        totalCoursesBefore = SMUtils.getTheKeyCount( reponseDataForValidation.toString(), Constants.ID );

        switch ( scenario1 ) {
            case "NegativeScenarios":

                apiResponse = createCourseByStandardForNegativeScenarios( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );
                //Get courses present at teacher course ware
                apiResponseForGetCourseListPresentOnDashboard = getCoursesAtOrgLevelTeacherUi( schoolType );

                //Getting the subject name
                reponseDataForValidation = SMUtils.getKeyValueFromResponse( apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ), Constants.DATA );
                totalCoursesAfter = SMUtils.getTheKeyCount( reponseDataForValidation.toString(), Constants.ID );

                //Assertion
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + apiResponse + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                Log.softAssertThat( Boolean.TRUE.equals( totalCoursesBefore.size() == totalCoursesAfter.size() ), "As expected no new courses were created", "New courses have been created. Please check!!! " );
                break;

            case "NegativeScenariosForEnrollmentOptions":
                apiResponse = createCourseByStandardNegativeScenarionsForEnrollmentOptions( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );
                //Get courses present at teacher course ware
                apiResponseForGetCourseListPresentOnDashboard = getCoursesAtOrgLevelTeacherUi( schoolType );
                Log.message( "Returned API Response - " + apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ) );

                //Getting the subject name
                reponseDataForValidation = SMUtils.getKeyValueFromResponse( apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ), Constants.DATA );
                totalCoursesAfter = SMUtils.getTheKeyCount( reponseDataForValidation.toString(), Constants.ID );

                //Assertion
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + apiResponse + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                Log.softAssertThat( Boolean.TRUE.equals( totalCoursesBefore.size() == totalCoursesAfter.size() ), "As expected no new courses were created", "New courses have been created. Please check!!! " );
                break;

            case "InvalidOrgAndTeacherDetails":
                headersInvalid.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalid.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalid.put( Constants.AUTHORIZATION, "Bearer " + token );
                headersInvalid.put( Constants.ORGID_SM_HEADER, orgId );
                headersInvalid.put( Constants.USERID_SM_HEADER, teacherId );

                apiResponse = createCourseByStandardForNegativeScenarios( smUrl, headersInvalid, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );
                //Get courses present at teacher course ware
                apiResponseForGetCourseListPresentOnDashboard = getCoursesAtOrgLevelTeacherUi( schoolType );
                Log.message( "Returned API Response - " + apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ) );

                //Getting the subject name
                reponseDataForValidation = SMUtils.getKeyValueFromResponse( apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ), Constants.DATA );
                totalCoursesAfter = SMUtils.getTheKeyCount( reponseDataForValidation.toString(), Constants.ID );

                //Assertion
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + apiResponse + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                Log.softAssertThat( Boolean.TRUE.equals( totalCoursesBefore.size() == totalCoursesAfter.size() ), "As expected no new courses were created", "New courses have been created. Please check!!! " );
                break;
            case "PosiveScenario":
                apiResponse = createCourseByStandardForNegativeScenarios( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );

                //Assertion
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + apiResponse + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

        }

        //Logging final status(pass/fail) for each case
//        Log.testCaseResult();

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return inputData
     */
    @DataProvider ( name = "scenarioForPostCustomCourse" )
    public Object[][] getCourseListAtDashboardLevelPositiveScenario() {
        Object[][] inputData = {
                { "TC001_Verify the status code is 201 when valid test data is given for default Math.", "", "200", "mathLicensesSchool", "201", "1", "Courses created by teachers", "201", "valid", "valid", "valid", "valid", "null", "null", "null", "null",
                        "null", "null", "null", "null" },
                { "TC002_Verify the status code is 201 when valid test data is given for Focus Math.", "", "200", "focusMathLicensesSchool", "201", "3", "Courses created by teachers", "201", "valid", "valid", "valid", "valid", "null", "null", "null",
                        "null", "null", "null", "null", "null" },
                { "TC004_Verify the status code is 201 when valid test data is given for default Reading.", "", "200", "readingLicensesSchool", "201", "2", "Courses created by teachers", "201", "valid", "valid", "valid", "valid", "null", "null", "null",
                        "null", "null", "null", "null", "null" },
                { "TC005_Verify the status code is 201 when valid test data is given for Focus Reading.", "", "200", "focusReadingLicensesSchool", "201", "15", "Courses created by teachers", "201", "valid", "valid", "valid", "valid", "null", "null",
                        "null", "null", "null", "null", "null", "null" },
                { "TC008_Verify the status code is 400 when the invalid Course Id is given.", "CATEGORY_ONE", "200", "flexLicensesSchool", "201", "1", "Courses created by teachers", "400", "valid", "valid", "valid", "invalid", "null", "null", "null",
                        "null", "null", "null", "null", "null" },
                { "TC009_Verify the status code is 200 when non existing Course Id is given.", "CATEGORY_ONE", "200", "flexLicensesSchool", "201", "2", "Courses created by teachers", "200", "valid", "valid", "valid", "nonexisting", "null", "null", "null",
                        "null", "null", "null", "null", "null" },
                { "TC040_Verify the status code is 403 when the invalid authorization is given", "CATEGORY_ONE", "200", "flexLicensesSchool", "201", "1", "Courses created by teachers", "401", "valid", "invalid", "valid", "valid", "null", "null", "null",
                        "null", "null", "null", "null", "null" },
                { "TC014_Verify the response is 400 when we pass invalid data for 'StandardFrameworkId' in request body", "CATEGORY_ONE", "200", "flexLicensesSchool", "201", "1", "Courses created by teachers", "400", "valid", "valid", "valid", "valid",
                        "name", "null", "invalid", "null", "null", "null", "null", "true" },
                { "TC018_Verify the response is 200 when we are passing non existing value for 'GradeId' in request body", "CATEGORY_ONE", "200", "flexLicensesSchool", "201", "1", "Courses created by teachers", "400", "valid", "valid", "valid", "valid",
                        "name", "nonexisting", "null", "null", "null", "null", "null", "true" },
                { "TC020_Verify the response is 400 when we pass invalid data for 'ContentBaseType' in request body", "CATEGORY_ONE", "200", "flexLicensesSchool", "201", "1", "Courses created by teachers", "400", "valid", "valid", "valid", "valid", "name",
                        "null", "null", "invalid", "null", "null", "null", "true" },
                { "TC024_Verify the response is 400 when we pass value as Null for 'New Course Name' and in request body", "CATEGORY_ONE", "200", "flexLicensesSchool", "201", "1", "Courses created by teachers", "400", "valid", "valid", "valid", "valid",
                        "null", "null", "null", "null", "null", "null", "null", "true" },
                { "TC025_Verify the response is 400 when we pass invalid data for 'mapLoTaxonomyId' in request body", "CATEGORY_ONE", "200", "flexLicensesSchool", "201", "1", "Courses created by teachers", "400", "valid", "valid", "valid", "valid", "name",
                        "null", "null", "null", "invalid", "null", "null", "true" },
                { "TC026_Verify the response is 400 when we are passing non existing value for 'mapLoTaxonomyId' in request body", "CATEGORY_ONE", "200", "flexLicensesSchool", "201", "1", "Courses created by teachers", "400", "valid", "valid", "valid",
                        "valid", "name", "null", "null", "null", "nonexisting", "null", "null", "true" },
                { "TC028_Verify the response is 400 when we pass invalid data for 'Lo's' ' in request body", "CATEGORY_ONE", "200", "flexLicensesSchool", "201", "1", "Courses created by teachers", "400", "valid", "valid", "valid", "valid", "name", "null",
                        "null", "null", "null", "null", "invalid", "true" },
                { "TC029_Verify the response is 400 when we are passing non existing value for 'Lo's' in request body", "CATEGORY_ONE", "200", "flexLicensesSchool", "201", "1", "Courses created by teachers", "400", "valid", "valid", "valid", "valid",
                        "name", "null", "null", "null", "null", "null", "nonexisting", "true" } };
        return inputData;
    }

    /**
     * Data provider for Custom Course positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "createCustomCourseBasedOnStandards" )
    public Object[][] createCourseAndGetHierarchy() {
        Object[][] inputData = {
                { "TC0222_Verify the response is 400 when we pass duplicate name for 'New Course Name' in request body", "MATH", "PosiveScenario", "mathLicensesSchool", "400", "1000030207", "1", "1000030206", "1000030209", "SMMA_LO_00700_1000030209", "4",
                        "CustomByStandards53109", null, null, null, null, null },
                { "TC015_Verify the response is 200 when we passing non existing value for 'StandardFrameworkId' in request body", "MATH", "NegativeScenarios", "mathLicensesSchool", "200", "1000030207", "1", "1234", "1000030209",
                        "SMMA_LO_00700_1000030209", "4", courseNameBasedOnStandard, null, null, null, null, null },
                { "TC016_Verify the response is 400 when we pass value as Null for 'StandardFrameworkId' in request body", "MATH", "NegativeScenarios", "mathLicensesSchool", "400", "1000030207", "1", "null", "1000030209", "SMMA_LO_00700_1000030209", "4",
                        courseNameBasedOnStandard, null, null, null, null, null },
                { "TC017_Verify the response is 400 when we pass invalid data for 'GradeId' in request body", "MATH", "NegativeScenarios", "mathLicensesSchool", "400", "1234s", "1", "1000030206", "1000030209", "SMMA_LO_00700_1000030209", "4",
                        courseNameBasedOnStandard, null, null, null, null, null },
                { "TC019_Verify the response is 400 when we pass value as Null for 'GradeId' and in request body", "MATH", "NegativeScenarios", "mathLicensesSchool", "400", "null", "1", "1000030206", "1000030209", "SMMA_LO_00700_1000030209", "4",
                        courseNameBasedOnStandard, null, null, null, null, null },
                { "TC021_Verify the response when we pass value as Null for 'ContentBaseType' and in request body", "MATH", "NegativeScenarios", "mathLicensesSchool", "400", "1000030207", "1", "1000030206", "1000030209", "SMMA_LO_00700_1000030209", "null",
                        courseNameBasedOnStandard, null, null, null, null, null },

                { "TC022_Verify the response is 400 when we pass duplicate name for 'New Course Name' in request body", "MATH", "NegativeScenarios", "mathLicensesSchool", "400", "1000030207", "1", "1000030206", "1000030209", "SMMA_LO_00700_1000030209",
                        "4", "CustomByStandards53109", null, null, null, null, null },
                { "TC027_Verify the response when we pass value as Null for 'mapLoTaxonomyId' in request body", "MATH", "NegativeScenarios", "mathLicensesSchool", "400", "1000030207", "1", "1000030206", "null", "SMMA_LO_00700_1000030209", "4",
                        courseNameBasedOnStandard, null, null, null, null, null },
                { "TC030_Verify the response is 400 when we pass value as Null for 'Lo's' in request body", "MATH", "NegativeScenarios", "mathLicensesSchool", "400", "1000030207", "1", "1000030206", "1000030209", "null", "4", courseNameBasedOnStandard,
                        null, null, null, null, null },
                { "TC031_Verify the response is 400 when we pass numerical value for 'name' (enrollment option ) in request body", "MATH", "NegativeScenariosForEnrollmentOptions", "mathLicensesSchool", "400", "1000030207", "1", "1000030206", "1000030209",
                        "SMMA_LO_00700_1000030209", "4", courseNameBasedOnStandard, "123", "1", "15", null, null },
                { "TC032_Verify the response is 400 when we pass value as Null for 'name' (enrollment option ) and in request body", "MATH", "NegativeScenariosForEnrollmentOptions", "mathLicensesSchool", "400", "1000030207", "1", "1000030206",
                        "1000030209", "SMMA_LO_00700_1000030209", "4", courseNameBasedOnStandard, "null", "1", "15", null, null },
                { "TC033_Verify the response is 400 when we pass invalid data for 'name' (enrollment option ) and in request body.", "MATH", "NegativeScenariosForEnrollmentOptions", "mathLicensesSchool", "400", "1000030207", "1", "1000030206",
                        "1000030209", "SMMA_LO_00700_1000030209", "4", courseNameBasedOnStandard, "123@&abc", "1", "15", null, null },
                { "TC034_Verify the response when is 400 we pass invalid value for setting id (enrollment option ) in request body", "MATH", "NegativeScenariosForEnrollmentOptions", "mathLicensesSchool", "400", "1000030207", "1", "1000030206",
                        "1000030209", "SMMA_LO_00700_1000030209", "4", courseNameBasedOnStandard, "pst.enrollment_option.session_length", "123@&abc", "15", null, null },
                { "TC035_Verify the response when we pass value as Null for setting id (enrollment option ) in request body", "MATH", "NegativeScenariosForEnrollmentOptions", "mathLicensesSchool", "400", "1000030207", "1", "1000030206", "1000030209",
                        "SMMA_LO_00700_1000030209", "4", courseNameBasedOnStandard, "pst.enrollment_option.session_length", "null", "15", null, null },
                { "TC036_Verify the response when we pass non existing id for setting id (enrollment option ) in request body", "MATH", "NegativeScenariosForEnrollmentOptions", "mathLicensesSchool", "400", "1000030207", "1", "1000030206", "1000030209",
                        "SMMA_LO_00700_1000030209", "4", courseNameBasedOnStandard, "pst.enrollment_option.session_length", "11", "15", null, null },
                { "TC037_Verify the response when we pass invalid data for \"current value\" (enrollment option ) in request body", "MATH", "NegativeScenariosForEnrollmentOptions", "mathLicensesSchool", "400", "1000030207", "1", "1000030206", "1000030209",
                        "SMMA_LO_00700_1000030209", "4", courseNameBasedOnStandard, "pst.enrollment_option.session_length", "1", "123@&abc", null, null },
                { "TC038_Verify the response when we keep \"current value\" (enrollment option ) as a null in request body", "MATH", "NegativeScenariosForEnrollmentOptions", "mathLicensesSchool", "400", "1000030207", "1", "1000030206", "1000030209",
                        "SMMA_LO_00700_1000030209", "4", courseNameBasedOnStandard, "pst.enrollment_option.session_length", "1", "null", null, null },
                { "TC039_Verify the response is 400 when we exceeding the limit of \"current value\" in request body.Ex.Idle time (max value=6)", "MATH", "NegativeScenariosForEnrollmentOptions", "mathLicensesSchool", "400", "1000030207", "1", "1000030206",
                        "1000030209", "SMMA_LO_00700_1000030209", "4", courseNameBasedOnStandard, "pst.enrollment_option.session_length", "1", "15134", null, null },

                { "TC010_Verify the status code is 400 when the invalid organization Id is given.", "MATH", "InvalidOrgAndTeacherDetails", "mathLicensesSchool", "403", "1000030207", "1", "1000030206", "1000030209", "SMMA_LO_00700_1000030209", "4",
                        courseNameBasedOnStandard, "pst.enrollment_option.session_length", "1", "15134", "123@$abc", userID },
                { "TC011_Verify the status code is 400 when non existing organization Id is given.", "MATH", "InvalidOrgAndTeacherDetails", "mathLicensesSchool", "403", "1000030207", "1", "1000030206", "1000030209", "SMMA_LO_00700_1000030209", "4",
                        courseNameBasedOnStandard, "pst.enrollment_option.session_length", "1", "15134", "8a72019a7f90ca06017fb5b542c41014", userID },
                { "TC012_Verify the status code is 400 when the invalid staff Id is given.", "MATH", "InvalidOrgAndTeacherDetails", "mathLicensesSchool", "401", "1000030207", "1", "1000030206", "1000030209", "SMMA_LO_00700_1000030209", "4",
                        courseNameBasedOnStandard, "pst.enrollment_option.session_length", "1", "15134", orgID, "123@$abc" },
                { "TC013_Verify the status code is 200 when non existing staff Id is given.", "MATH", "InvalidOrgAndTeacherDetails", "mathLicensesSchool", "401", "1000030207", "1", "1000030206", "1000030209", "SMMA_LO_00700_1000030209", "4",
                        courseNameBasedOnStandard, "pst.enrollment_option.session_length", "1", "15134", orgID, "8a7209eb7f65705b017f65738c010000" }

        };
        return inputData;
    }

    /**
     * Token creation
     * 
     * @param school
     */
    public void tokenCreation( String school ) {
        try {
            switch ( school ) {
                case CommonAPIConstants.FLEX_LICENSE_SCHOOL:
                    schoolType = flexSchool;
                    teacherDetails = flexSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.MATH_LICENSE_SCHOOL:
                    schoolType = mathSchool;
                    teacherDetails = mathSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.READING_LICENSE_SCHOOL:
                    schoolType = readingSchool;
                    teacherDetails = readingSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.FOCUS_MATH_LICENSE_SCHOOL:
                    schoolType = focusMathSchool;
                    teacherDetails = focusMathSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.FOCUS_READING_LICENSE_SCHOOL:
                    schoolType = focusReadingSchool;
                    teacherDetails = focusReadingSchoolTeacherDetails;
                    break;
            }
            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
            userName = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Error occurred in the token creation. Please check!!" );
        }
    }

    /**
     * Create custom course based on standard
     * 
     * @param school
     * @param customCourseBasedOnStandardParameters
     * 
     * @return apiResponse
     */
    public Map<String, String> postCustomCourseBasedOnStandard( String school, Map<String, String> customCourseBasedOnStandardParameters ) {
        Map<String, String> apiResponse = null;
        Map<String, String> customCourseBasedOnStandard = new HashMap<>();
        try {
            customCourseBasedOnStandard.put( RBSDataSetupConstants.BEARER_TOKEN, customCourseBasedOnStandardParameters.get( RBSDataSetupConstants.BEARER_TOKEN ) );
            if ( customCourseBasedOnStandardParameters.containsKey( CourseAPIConstants.INVALID_ORG_ID ) ) {
                customCourseBasedOnStandard.put( CourseAPIConstants.INVALID_ORG_ID, customCourseBasedOnStandardParameters.get( CourseAPIConstants.INVALID_ORG_ID ) );
            } else {
                customCourseBasedOnStandard.put( CourseAPIConstants.ORG_ID, customCourseBasedOnStandardParameters.get( CourseAPIConstants.ORG_ID ) );
            }
            if ( customCourseBasedOnStandardParameters.containsKey( CourseAPIConstants.INVALID_STAFF_ID ) ) {
                customCourseBasedOnStandard.put( CourseAPIConstants.INVALID_STAFF_ID, customCourseBasedOnStandardParameters.get( CourseAPIConstants.INVALID_STAFF_ID ) );
            } else {
                customCourseBasedOnStandard.put( CourseAPIConstants.TEACHER_ID, customCourseBasedOnStandardParameters.get( CourseAPIConstants.TEACHER_ID ) );
            }
            customCourseBasedOnStandard.put( CourseAPIConstants.COURSE_ID, customCourseBasedOnStandardParameters.get( CourseAPIConstants.COURSE_ID ) );
            customCourseBasedOnStandard.put( CourseAPIConstants.COURSE_TYPE, customCourseBasedOnStandardParameters.get( CourseAPIConstants.COURSE_TYPE ) );
            customCourseBasedOnStandard.put( CourseAPIConstants.COURSE_NAME, customCourseBasedOnStandardParameters.get( CourseAPIConstants.COURSE_NAME ) );
            customCourseBasedOnStandard.put( CourseAPIConstants.STATUS_CODE, customCourseBasedOnStandardParameters.get( CourseAPIConstants.STATUS_CODE ) );
            customCourseBasedOnStandard.put( Constants.USERID_SM_HEADER, customCourseBasedOnStandardParameters.get( Constants.USERID_SM_HEADER ) );
            customCourseBasedOnStandard.put( Constants.ORGID_SM_HEADER, customCourseBasedOnStandardParameters.get( Constants.ORGID_SM_HEADER ) );
            if ( customCourseBasedOnStandardParameters.containsKey( CourseAPIConstants.GRADE_ID ) ) {
                customCourseBasedOnStandard.put( CourseAPIConstants.GRADE_ID, customCourseBasedOnStandardParameters.get( CourseAPIConstants.GRADE_ID ) );
            }
            if ( customCourseBasedOnStandardParameters.containsKey( CourseAPIConstants.STANDARD_FRAMEWORK_ID ) ) {
                customCourseBasedOnStandard.put( CourseAPIConstants.STANDARD_FRAMEWORK_ID, customCourseBasedOnStandardParameters.get( CourseAPIConstants.STANDARD_FRAMEWORK_ID ) );
            }

            if ( customCourseBasedOnStandardParameters.containsKey( CourseAPIConstants.CONTENT_BASE_TYPE ) ) {
                customCourseBasedOnStandard.put( CourseAPIConstants.CONTENT_BASE_TYPE, customCourseBasedOnStandardParameters.get( CourseAPIConstants.CONTENT_BASE_TYPE ) );
            }
            if ( customCourseBasedOnStandardParameters.containsKey( CourseAPIConstants.MAP_LO_TAXONOMY ) ) {
                customCourseBasedOnStandard.put( CourseAPIConstants.MAP_LO_TAXONOMY, customCourseBasedOnStandardParameters.get( CourseAPIConstants.MAP_LO_TAXONOMY ) );
            }
            if ( customCourseBasedOnStandardParameters.containsKey( CourseAPIConstants.LO ) ) {
                customCourseBasedOnStandard.put( CourseAPIConstants.LO, customCourseBasedOnStandardParameters.get( CourseAPIConstants.LO ) );
            }
            if ( customCourseBasedOnStandardParameters.containsKey( CourseAPIConstants.PAYLOAD ) ) {
                customCourseBasedOnStandard.put( CourseAPIConstants.PAYLOAD, customCourseBasedOnStandardParameters.get( CourseAPIConstants.PAYLOAD ) );
            }

            apiResponse = createCourseBasedOnStandards( smUrl, customCourseBasedOnStandard );
        } catch ( Exception e ) {
            Log.message( "Error occurred in while creating the course based on standards. Please check!!" );
        }
        return apiResponse;
    }

    /**
     * This method is to create a course based on standards
     * <p>
     * envUrl - The SM instance URL
     * <p>
     * customCourseBasedOnStandardDetails - It should include orgId,teacherId
     * and courseId
     * 
     * @param envUrl
     * @param customCourseBasedOnStandardDetails
     * 
     * @return response_post
     * 
     * @throws Exception
     */
    public Map<String, String> createCourseBasedOnStandards( String envUrl, Map<String, String> customCourseBasedOnStandardDetails ) throws Exception {
        Map<String, String> response_post = new HashMap<>();
        try {
            String orgId = null;
            String staffId = null;
            //Headers
            Map<String, String> headers = new HashMap<String, String>();
            // Input Params
            HashMap<String, String> params = new HashMap<>();
            // EndPoint Details
            String endPoint_post = CourseAPIConstants.CREATE_CUSTOM_COURSE;

            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + customCourseBasedOnStandardDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
            headers.put( Constants.USERID_SM_HEADER, customCourseBasedOnStandardDetails.get( Constants.USERID_SM_HEADER ) );
            headers.put( Constants.ORGID_SM_HEADER, customCourseBasedOnStandardDetails.get( Constants.ORGID_SM_HEADER ) );

            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.INVALID_ORG_ID ) ) {
                orgId = customCourseBasedOnStandardDetails.get( CourseAPIConstants.INVALID_ORG_ID );
            } else {
                orgId = customCourseBasedOnStandardDetails.get( CourseAPIConstants.ORG_ID );
            }

            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.INVALID_STAFF_ID ) ) {
                staffId = customCourseBasedOnStandardDetails.get( CourseAPIConstants.INVALID_STAFF_ID );
            } else {
                staffId = customCourseBasedOnStandardDetails.get( CourseAPIConstants.TEACHER_ID );
            }
            endPoint_post = endPoint_post.replace( Constants.COURSE_ID, customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ) );
            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgId );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, staffId );

            HashMap<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_NAME ) );
            String requestBody = null;
            List<String> standardDetails = new ArrayList<>();

            if ( customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_ONE ) || customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_THREE ) ) {
                standardDetails = UserSqlHelper.getRandomStandardGradeID( CourseAPIConstants.TEACHER, DataSetupConstants.MATH,isItMt.equalsIgnoreCase( "true" ) );
            } else if ( customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_TWO ) || customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_FIFTEEN ) ) {
                standardDetails = UserSqlHelper.getRandomStandardGradeID( CourseAPIConstants.TEACHER, DataSetupConstants.READING,isItMt.equalsIgnoreCase( "true" ) );
            } else {
                standardDetails = UserSqlHelper.getRandomStandardGradeID( CourseAPIConstants.TEACHER, DataSetupConstants.READING,isItMt.equalsIgnoreCase( "true" ) );
            }

            List<String> listLO = UserSqlHelper.getLOIDsRandomStandard( CourseAPIConstants.TEACHER, standardDetails.get( 0 ), standardDetails.get( 1 ),isItMt.equalsIgnoreCase( "true" ) );
            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.STANDARD_FRAMEWORK_ID ) ) {
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, customCourseBasedOnStandardDetails.get( CourseAPIConstants.STANDARD_FRAMEWORK_ID ) );
            } else {
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
            }
            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.GRADE_ID ) ) {
                courseDetails.put( Constants.GRADE_ID, customCourseBasedOnStandardDetails.get( CourseAPIConstants.GRADE_ID ) );
            } else {
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
            }

            courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO

            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.LO ) ) {
                courseDetails.put( Constants.LOID, customCourseBasedOnStandardDetails.get( CourseAPIConstants.LO ) );
            } else {
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
            }
            if ( customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.CONTENT_BASE_TYPE ) ) {
                courseDetails.put( Constants.CONTENT_BASE_TYPE, customCourseBasedOnStandardDetails.get( CourseAPIConstants.CONTENT_BASE_TYPE ) );
            } else {
                courseDetails.put( Constants.CONTENT_BASE_TYPE, CourseAPIConstants.STRING_FOUR );
            }

            if ( !customCourseBasedOnStandardDetails.containsKey( CourseAPIConstants.PAYLOAD ) ) {
                if ( customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_ONE ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_MATH ), courseDetails );
                } else if ( customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_THREE ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_FOCUS_MATH_THREE ), courseDetails );
                } else if ( customCourseBasedOnStandardDetails.get( CourseAPIConstants.COURSE_ID ).equals( CourseAPIConstants.STRING_FIFTEEN ) ) {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_FOCUS_READING_FIFTEEN ), courseDetails );
                } else {
                    requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_READING ), courseDetails );
                }
            } else {
                requestBody = new RBSUtils().generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_MATH_INVALID ), courseDetails );
            }

            try {
                response_post = RestHttpClientUtil.POST( envUrl, headers, params, endPoint_post, requestBody );
            } catch ( Exception e ) {
                Log.message( "Issue while executing the post command" );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post;
    }

    /**
     * Get response for the Create Course By Skill API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseByStandardForNegativeScenarios( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "READING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardReadingNew" ) ) );

            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardMathNew" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.STANDARDFRAMEWORK_ID, courseDetails.get( Constants.STANDARD_FRAMEWORK_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            requestBody.set( requestBody.get().replace( Constants.CONTENT_BASE_ID_PAYLOAD, courseDetails.get( CourseAPIConstants.CONTENT_BASE_ID ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseByStandard method" );
            return null;
        }
    }

    /**
     * Get response for the Create Course By Skill API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseByStandardNegativeScenarionsForEnrollmentOptions( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "READING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardReadingNew1" ) ) );

            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardMathNew1" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.STANDARDFRAMEWORK_ID, courseDetails.get( Constants.STANDARD_FRAMEWORK_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            requestBody.set( requestBody.get().replace( Constants.CONTENT_BASE_ID_PAYLOAD, courseDetails.get( CourseAPIConstants.CONTENT_BASE_ID ) ) );
            requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_ID, courseDetails.get( CourseAPIConstants.SESSION_STRENGTH_ID ) ) );
            requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_NAME, courseDetails.get( CourseAPIConstants.SESSION_STRENGTH_NAME ) ) );
            requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_VALUE, courseDetails.get( CourseAPIConstants.SESSION_STRENGTH_VALUE ) ) );

            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseByStandardNegativeScenarionsForEnrollmentOptions method" );
            return null;
        }
    }

    /**
     * Get courses present at teacher UI home page
     * 
     * @param school
     * 
     * @return apiResponse
     */
    public Map<String, String> getCoursesAtOrgLevelTeacherUi( String school ) {
        Map<String, String> apiResponse = new HashMap<>();
        Map<String, String> dashboardCourseListDetails = new HashMap<>();
        try {
            dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            apiResponse = getCoursesAtOrgLevel( smUrl, dashboardCourseListDetails );
        } catch ( Exception e ) {
            Log.message( "Error occurred in while getting the courses from the dashboard of Teacher UI. Please check!!" );
        }
        return apiResponse;
    }
}