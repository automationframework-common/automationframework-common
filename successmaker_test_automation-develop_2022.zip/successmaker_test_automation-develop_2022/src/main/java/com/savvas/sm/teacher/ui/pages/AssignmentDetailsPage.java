package com.savvas.sm.teacher.ui.pages;

import java.text.DecimalFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.TestDataConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class AssignmentDetailsPage extends LoadableComponent<AssignmentDetailsPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    public WebDriver driver;
    boolean isPageLoaded;
    public String sessionLengthButton = "button";

    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    // *********Assignment Details Page Table******

    @IFindBy ( how = How.CSS, using = ".tile__title", AI = false )
    public WebElement assignmentTitle;

  @FindBy (css="div.row > h4")
  public WebElement assignmentAvailability;

    @FindBy ( css = ".table-body>tr" )
    List<WebElement> availableStudents;

    @FindBy ( css = "table#report th>span" )
    List<WebElement> columnNamesList;

    @FindBy ( css = "div.content > div > p" )
    List<WebElement> deletePopupTextList;

    @FindBy ( css = "div.highcharts-legend-item>span" )
    List<WebElement> legendNames;

    @IFindBy ( how = How.CSS, using = "span.tile__subtitle", AI = false )
    public WebElement activePausedText;

    @IFindBy ( how = How.CSS, using = "span.tile__tooltiptext", AI = false )
    public WebElement assignmentTitleTooltipText;

    @IFindBy ( how = How.CSS, using = "div.skill-graph", AI = false )
    public WebElement skillTestedGraph;

    @IFindBy ( how = How.CSS, using = "span.date-cell", AI = false )
    public WebElement lastSessionValues;

    @IFindBy ( how = How.CSS, using = "cel-radio-button:nth-of-type(2) .radio__label.sc-cel-radio-button", AI = false )
    public WebElement studentRadioButton;

    @IFindBy ( how = How.CSS, using = "div.dialog-wrapper", AI = false )
    public WebElement studentPopupModalPopup;

    @IFindBy ( how = How.CSS, using = "div.popup-dialog-header", AI = false )
    public WebElement fluencyPopup;

    @IFindBy ( how = How.CSS, using = "rect.highcharts-background", AI = false )
    public WebElement progressMonitoringGraph;

    @IFindBy ( how = How.CSS, using = "rect.highcharts-legend-box", AI = false )
    public WebElement legendsDisplay;

    @IFindBy ( how = How.CSS, using = "g.highcharts-axis.highcharts-xaxis > text", AI = false )
    public WebElement xAxisDisplay;

    @IFindBy ( how = How.CSS, using = "g.highcharts-axis.highcharts-yaxis > text", AI = false )
    public WebElement yAxisDisplay;

    @IFindBy ( how = How.CSS, using = "div.table-container>table>tbody>tr:nth-of-type(1) >td:nth-child(1)>div>span", AI = false )
    public WebElement firstStudentName;

    @IFindBy ( how = How.CSS, using = "span[class='zero-state-span'] h3[class='header']", AI = false )
    public WebElement progressMonitoringZeroState;

    // **** Edit Assignment setting
    @FindBy (css="cel-button-menu.table-dropdown-menu")
    public WebElement assigmnentSettingGrandRoot;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "//div[@class='dropdown-select-options-wrapper sc-cel-dropdown-select']/ul/li" )
    List<WebElement> dropdownGeneric;

    //TODO: Replace the xpath with css locator
      @IFindBy ( how = How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[1]", AI = false )
      public WebElement sessionLength;

    @IFindBy ( how = How.CSS, using = "span.cell-tooltiptext", AI = false )
    public WebElement tooltipStudentName;

    //TODO: Replace the xpath with css locator
    
     @FindBy (css="span.dropdown-select-value.sc-cel-dropdown-select span.dropdown-select-label")
     public WebElement sessionLengthValue;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[2]", AI = false )
    public WebElement idealTime;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[2]/span/span", AI = false )
    public WebElement idealTimeValue;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[3]", AI = false )
    public WebElement showProgressReport;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[4]", AI = false )
    public WebElement speedGamesTimePerQuestion;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[5]", AI = false )
    public WebElement speedGameTotalTime;

    @FindBy ( css = "filter-group-student >div >div.list-data > div" )
    List<WebElement> studentListAssignmentPopUp;

    @FindBy ( css = "div.table-container>table>tbody>tr" )
    List<WebElement> studentListAssignmentTable;

    @FindBy ( css = "div.table-container>table>tbody>tr>td:nth-of-type(1) .text-overflow-nowrap" )
    List<WebElement> studentNameViewAssignmentTable;

    @IFindBy ( how = How.CSS, using = "cel-button-menu.table-dropdown-menu", AI = false )
    public WebElement resumeAssignmentForStudentGrandRoot;

    @IFindBy ( how = How.CSS, using = "div.confirm-modal-footer > cel-button:nth-of-type(2)", AI = false )
    public WebElement pauseAssignmentbtnOnPopUpRoot;

    @IFindBy ( how = How.CSS, using = "div.confirm-modal-footer> cel-button:nth-of-type(2)", AI = false )
    public WebElement removeButtonOnpopupRoot;

    // *******Pause All Student
    // *******Pause All Student and Resume all

    @IFindBy ( how = How.CSS, using = "div .confirm-modal-footer > cel-button:nth-of-type(2)", AI = false )
    public WebElement pauseAllStudentBtnRoot;

    @IFindBy ( how = How.CSS, using = "cel-button-menu.tile-ellipsis-btn", AI = false )
    public WebElement resumeAllStudentsGrandRoot;

    @FindBy(css="cel-button-menu.tile-ellipsis-btn")
    WebElement pauseAllStudentsGrandRoot;

    //TODO - Avoid indexing
    @IFindBy ( how = How.CSS, using = "div .confirm-modal-footer > cel-button:nth-of-type(1)", AI = false )
    public WebElement cancelbtnPauseStudentParent;

    // ********Delete Assignments
    // ********Delete all Assignments

    @FindBy(css="div.dialog-wrapper")
    public WebElement deletePopupModalPopup;

    @FindBy(css="cel-button-menu.tile-ellipsis-btn")
    WebElement deleteAssignmentGrandRoot;

    @FindBy(css="div .confirm-modal-footer > cel-button:not([color='secondary'])")
    WebElement deleteAssignmentsDeleteBtn;

    @IFindBy ( how = How.CSS, using = "cel-button-menu.tile-ellipsis-btn", AI = false )
    public WebElement deleteAssignment;

    @IFindBy ( how = How.CSS, using = "div .confirm-modal-footer > cel-button:nth-of-type(2)", AI = false )
    public WebElement deleteAssignmentsCancelBtn;

    @IFindBy ( how = How.CSS, using = "div.confirm-modal-footer cel-button:not([color=\"secondary\"])", AI = false )
    public WebElement deleteButtonPopupGrandRoot;

    // ********Assigned To sub tab and Mastery sub tab***********
    @IFindBy ( how = How.CSS, using = "cel-toggle-button.hydrated", AI = false )
    public WebElement assignedToAndMasteryBtnRoot;

    @FindBy ( css = "h1[title='Delete Assignment']" )
    List<WebElement> textInDeleteAssignmentPopup;

    @FindBy(css="cel-icon#dialogHeaderClose")
    public WebElement deleteAssignmentPopupCloseBtnRoot;

    @IFindBy ( how = How.CSS, using = ".mastery-assignments-hierarchy .zero-state-content", AI = false )
    public WebElement masteryZeroState;
    
    @IFindBy ( how = How.CSS, using = ".strand-name", AI = false )
    public WebElement strandName;
    
    @IFindBy ( how = How.CSS, using = ".select-lo", AI = false )
    public WebElement LOArrow;
    
    @FindBy ( css = ".select-lo" )
    List<WebElement> LOArrowList;
    
    @IFindBy ( how = How.CSS, using = ".lo-catalog-link", AI = false )
    public WebElement LOLink;
    
    @IFindBy ( how = How.CSS, using = ".assignments-mastery", AI = false )
    public WebElement LODetailsCard;
    
    @IFindBy ( how = How.CSS, using = ".card-title", AI = false )
    public WebElement strandTitle;
    
    @IFindBy ( how = How.CSS, using = ".card-topic", AI = false )
    public WebElement standardTitle;
    
    @IFindBy ( how = How.CSS, using = "cel-multi-part-progress-bar", AI = false )
    public WebElement progressBar;
    
    @IFindBy ( how = How.CSS, using = ".col-name", AI = false )
    public WebElement studentNameCol;
    
    @IFindBy ( how = How.CSS, using = ".badge", AI = false )
    public WebElement studentMasteryStatusCol;
    
    @IFindBy ( how = How.CSS, using = ".col-skills", AI = false )
    public WebElement studentSkillsEvaluatedCol;
    
    @IFindBy ( how = How.CSS, using = ".col-attempts", AI = false )
    public WebElement studentAttemptsCol;

    // ********Column names inside the Assignment Details Page
    @IFindBy ( how = How.CSS, using = "#report > thead > tr > th:nth-of-type(1)", AI = false )
    public WebElement columnName;
    
    @IFindBy ( how = How.CSS, using = "#report > thead > tr > th:nth-of-type(2)", AI = false )
    public WebElement columnLastSession;

    @IFindBy ( how = How.CSS, using = "#report > thead > tr > th:nth-of-type(3)", AI = false )
    public WebElement columnIPLevel;

    @IFindBy ( how = How.CSS, using = "#report > thead > tr > th:nth-of-type(4)", AI = false )
    public WebElement columnAssignedLevel;

    @IFindBy ( how = How.CSS, using = "#report > thead > tr > th:nth-of-type(5)", AI = false )
    public WebElement columnCurrentLevel;

    @IFindBy ( how = How.CSS, using = "#report > thead > tr > th:nth-of-type(6)", AI = false )
    public WebElement columnGain;

    @IFindBy ( how = How.CSS, using = "#report > thead > tr > th:nth-of-type(7)", AI = false )
    public WebElement columnPercentageCorrect;

    //TODO: Replace the xpath with css locator
    @FindBy ( xpath = "(//div[@class='cell-group cell-tooltip'])[1]" )
    List<WebElement> pauseText;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "//span[@aria-label='Student is Paused']", AI = false )
    public WebElement capturePaused;

    //TODO: Replace the xpath with css locator
    @FindBy (css="(//div[@class='cell-group cell-tooltip']/span[3])[1]")
    public WebElement captureAssignmentlevelPaused;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "(//span[@class='text-overflow-nowrap'])[1]", AI = false )
    public WebElement isStudentDisplayedElement;

    @FindBy ( css = "td.accordion-table-cell > div > span.text-overflow-nowrap" )
    List<WebElement> studentNames;

    @IFindBy ( how = How.CSS, using = "div.tile__body .tile__tooltip", AI = false )
    public WebElement titleOfAssignmentDetailsPage;
    
    @IFindBy ( how = How.CSS, using = "div.tile__body>span:nth-of-type(1) > span", AI = false )
    public WebElement titleTooltipOfAssignmentDetailsPage;

    @IFindBy ( how = How.CSS, using = "div.tile__body>span:nth-child(2)", AI = false )
    public WebElement subTitleOfAssignmentDetailsPage;

     @FindBy (css="tbody.table-body > tr:nth-child(1)> td.action-menu-cell > cel-button-menu")
     public WebElement dotEllipsisOptionRoot;

    @FindBy(css="cel-button-menu.tile-ellipsis-btn")
    public WebElement dotEllipsisBesideAssignBtnGrandRoot;
    
//    @IFindBy ( how = How.CSS, using = "#cel-overlay-1 > div > cel-dialog-header > div > h1", AI = false )
//    public WebElement assignmentEditPopup;
    
    @FindBy (css="#cel-overlay-1 > div > cel-dialog-header > div > h1")
    public WebElement assignmentEditPopup;

    @FindBy (css="cel-button-menu.table-dropdown-menu")
    public WebElement assignmentSettingsForStudentGrandRoot;

    @FindBy (css="cel-button-menu.tile-ellipsis-btn")
    WebElement assignmentSettingForAllGrandRoot;

    @IFindBy ( how = How.CSS, using = "div.footer-button-wrapper > cel-button:nth-of-type(1)", AI = false )
    public WebElement assignmentCancelBtnRoot;

    @FindBy(css="cel-button-menu.table-dropdown-menu")
    public WebElement pauseAssignmentForStudentGrandRoot;

    @IFindBy ( how = How.CSS, using = "div.confirm-modal-footer > cel-button:nth-of-type(1)", AI = false )
    public WebElement pauseAssignmentForStudentCancelbtn;

    @IFindBy ( how = How.CSS, using = "cel-button-menu.table-dropdown-menu", AI = false )
    public WebElement removeStudentBtnGrandRoot;

    @FindBy(css="div.confirm-modal-footer> cel-button:nth-of-type(1)")
    public WebElement removeStudentCancelButton;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "//div[@class='cell-group cell-tooltip']/span[1]", AI = false )
    public WebElement allAssignedStudentsDetails;

    @IFindBy ( how = How.CSS, using = "div.footer-button-wrapper > cel-button:nth-of-type(2)", AI = false )
    public WebElement assignmentSaveBtnRoot;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "(//div[@class='cell-group cell-tooltip']/span[1])[1]", AI = false )
    public WebElement waitForListingStr;

    @IFindBy ( how = How.CSS, using = "div.row > h4", AI = false )
    public WebElement assignmentText;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "(//div[@class='dropdown-select sc-cel-dropdown-select']/button/span/span)[1]", AI = false )
    public WebElement sessionLengthText;

    @FindBy(css="div .cel-button-Assign")
    WebElement assignBtnAssignmentlistRoot;
    
    @IFindBy ( how = How.CSS, using = "div cel-button.cel-button-Assign", AI = false )
    public WebElement assignBtnAssignmentlist;

    @FindBy ( css = "div.table-container td:nth-of-type(1)" )
    List<WebElement> assignmentTitles;

    // Skill Tested related Elements
    @FindBy ( css = "cel-multi-part-progress-bar" )
    List<WebElement> lastSessionSkillTestedNames;

    @FindBy ( css = "div.skill-graph div.skills-correct small" )
    List<WebElement> skillsCorrectList;

    @FindBy ( css = "div.skills-tested-report cel-progress-bar" )
    List<WebElement> progressBarRoot;

    public static String progressBarCSS = "div.progressBar";
    public static String progressBarTextZeroCSS = "span.textOutside.progressBarText";

    @IFindBy ( how = How.CSS, using = "div.assignment-detail-grid-row__scroll cel-button", AI = false )
    public WebElement btnAapplyFilterRoot;

    @FindBy (css="div.row.skills-tested-graph-filter cel-multi-check-dropdown")
    public WebElement dropdownLastSession;

    @IFindBy ( how = How.CSS, using = "div cel-multi-check-dropdown ", AI = false )
    public WebElement dropdownRoot1;

    @IFindBy ( how = How.CSS, using = "tbody.table-body", AI = false )
    public WebElement studentTable;

    @IFindBy ( how = How.CSS, using = "h5.skilled-header", AI = false )
    public WebElement skillTestedHeader;

    @IFindBy ( how = How.CSS, using = "div.skills-tested-graph-wrapper div.zero-state-content", AI = false )
    public WebElement zeroStateParent;

    //Last Session skill teste popup
    @FindBy ( css = "td.skills-tested-td a.skill-name" )
    List<WebElement> skillNames;

    @IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
    public WebElement skillTestedPopupHeader;

    @IFindBy ( how = How.CSS, using = "cel-icon#dialogHeaderClose", AI = false )
    public WebElement closeIconParentRoot;

    @IFindBy ( how = How.CSS, using = "div.skills-popup div.skills-correct", AI = false )
    public WebElement countOFCorrectAandAttemptedInPopup;

    @IFindBy ( how = How.CSS, using = "div.skills-desc div.text-truncate", AI = false )
    public WebElement lblSkillNameInPopup;

    @IFindBy ( how = How.CSS, using = "div.cell-data a", AI = false )
    public WebElement catalogNumber;

    @IFindBy ( how = How.CSS, using = "div.cell-data span", AI = false )
    public WebElement txtSkillDescription;

    @IFindBy ( how = How.CSS, using = "div.skills-footer cel-button", AI = false )
    public WebElement closeBtnInSkillTestedPopup;

    @IFindBy ( how = How.CSS, using = "cel-icon[name='addition']", AI = false )
    public WebElement btnSkillTestedPlusIconRoot;

    @IFindBy ( how = How.CSS, using = "td.accordion-table-cell", AI = false )
    public WebElement btnSkillTestedPlusIconGrandRoot;

    @FindBy ( css = "span[class='text-overflow-nowrap']" )
    List<WebElement> lblStudentName;

    @IFindBy ( how = How.CSS, using = "cel-icon[name='subtraction']", AI = false )
    public WebElement iconCollapseSkillTested;

    @FindBy ( css = "div[class='skills-desc cell-tooltip-if-ellipsis'] a" )
    List<WebElement> skillLink;

    @FindBy ( css = ".student-name div[class='name']" )
    List<WebElement> groupNameListFromAssignPopup;

    @IFindBy ( how = How.CSS, using = "div.skills-popup div.report .hydrated", AI = false )
    public WebElement progressBarInPopup;

    // *****assignPopupAssignBtnRoot***** 
    @IFindBy ( how = How.CSS, using = "cel-radio-button.sc-cel-radio-button-s .radio__wrapper", AI = false )
    List<WebElement> radioButton;

    @IFindBy ( how = How.CSS, using = "div.add-btn cel-button", AI = false )
    public WebElement addBtnRoot;

    @IFindBy ( how = How.CSS, using = "cel-button.assign-button.hydrated", AI = false )
    public WebElement assignPopupAssignBtnRoot;

    //***** Fluency Files option ******
    @FindBy(css="cel-button-menu.table-dropdown-menu")
    public WebElement fluencyFilesGrandRoot;

    //***** Assign button of home page
    @IFindBy ( how = How.CSS, using = "cel-button.cel-button-assign", AI = false )
    public WebElement assignButton;

    //***** Edit Targets pop up *****
    @IFindBy ( how = How.CSS, using = "button > cel-icon.hydrated", AI = false )
    public WebElement studentExpandicon;

    @IFindBy ( how = How.CSS, using = "span.accordion-graph-header-text", AI = false )
    public WebElement progressGraphHeader;

    @IFindBy ( how = How.CSS, using = "table cel-icon", AI = false )
    public WebElement arrowIcon;

    @IFindBy ( how = How.CSS, using = "span[title='Gain'] span[class='sort-type-none']", AI = false )
    public WebElement gainTooltip;

    @IFindBy ( how = How.CSS, using = "span[title='IP Level'] span[class='sort-type-none']", AI = false )
    public WebElement ipLevelTooltip;

    @FindBy ( css = "button.graph-button" )
    List<WebElement> progressGraphButtons;

    @FindBy ( css = "setting-control.control div div cel-dropdown-select div div ul li" )
    List<WebElement> listOfSessionLength;

    @FindBy ( css = "setting-control.dropdown-control-wrapper div.setting-label" )
    List<WebElement> sessionLengthDropdown;

    @FindBy (css="setting-control.progress-dropdown-control-wrapper button")
    public WebElement limitProgressDropdown;

    @FindBy ( css = "setting-control.progress-dropdown-control-wrapper li" )
    List<WebElement> limitProgressList;

    @FindBy ( css = "div.setting-label" )
    List<WebElement> headerList;

    @FindBy ( css = "setting-control.multi-dropdown-control-wrapper div.setting-label" )
    List<WebElement> speedGameTimeDropdown;

    @FindBy ( css = "setting-control.multi-dropdown-control-wrapper li" )
    List<WebElement> listOfSpeedGames;

    @FindBy ( css = "div.setting-label" )
    List<WebElement> headingLabel;

    @FindBy(css="span[class='heading-text']")
    public WebElement fluencyFilesPopupHeader;

    @IFindBy ( how = How.CSS, using = "cel-checkbox[aria-label='checkAll']", AI = false )
    public WebElement selectAllCheckBoxRoot;

    @IFindBy ( how = How.CSS, using = ".cancel-btn-wrapper cel-button", AI = false )
    public WebElement cancelBtnRootFluencyPopup;

    @IFindBy ( how = How.CSS, using = ".download-button-wrapper cel-button", AI = false )
    public WebElement DownloadBtnRootFluencyPopup;

    @IFindBy ( how = How.CSS, using = ".delete-button-wrapper cel-button", AI = false )
    public WebElement deleteBtnRootFluencyPopup;

    @FindBy ( css = ".dialog-body th.th-text span span" )
    List<WebElement> fluencyPopupHeaders;

    @FindBy ( css = ".dialog-body tr" )
    List<WebElement> FluencyFileTableRows;

    @FindBy ( css = ".confirm-modal cel-button" )
    List<WebElement> fluencyFileDeletePopupButtonsRoot;

    @IFindBy ( how = How.CSS, using = ".alert__message sc-cel-toast", AI = false )
    public WebElement deleteFluencyToastMessage;

    @IFindBy ( how = How.CSS, using = ".confirm-modal .subtext", AI = false )
    public WebElement deletePopupContent;

    @IFindBy ( how = How.CSS, using = ".zero-state-content h3", AI = false )
    public WebElement zeroStateFluencyFile;

    @IFindBy ( how = How.CSS, using = "a.show-details ", AI = false )
    public WebElement backIconNavigation;

    @FindBy ( css = "tr.accordion-table-row" )
    List<WebElement> studentTableRow;

    // *********Remove student popup
    @IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
    public WebElement removeStudentPopupHeader;

    @FindBy ( css = "div.confirm-modal p" )
    List<WebElement> removeStudentHeadsupMessage;

    @FindBy ( css = "create-confirm-popup span" )
    List<WebElement> removeStudentPopupText;

    @IFindBy ( how = How.CSS, using = "div.confirm-modal-footer cel-button:not([color])", AI = false )
    public WebElement removeStudentButton;
    
    @IFindBy ( how = How.CSS, using = "div.confirm-modal-footer cel-button:nth-child(2)", AI = false )
    public WebElement removeCourseButton;

    @IFindBy ( how = How.CSS, using = "cel-button[color='secondary']", AI = false )
    public WebElement cancelRemoveStudentButton;

    @IFindBy ( how = How.CSS, using = "cel-icon.dialog-header__icon-close.hydrated ", AI = false )
    public WebElement xRemoveStudentButton;

    @IFindBy ( how = How.CSS, using = "#closeBtn", AI = false )
    public WebElement closeIconRemoveStudent;

    @FindBy ( css = "tbody tr" )
    List<WebElement> studentRows;

    @FindBy ( css = ".action-menu-cell cel-button-menu" )
    List<WebElement> studentsEllipsisRoot;

    //Progress Monitoring Graph
    @IFindBy ( how = How.CSS, using = "cel-icon[name='icon_bullet_list']", AI = false )
    public WebElement viewSummaryBtn;

    @FindBy ( css = "cel-icon[name='icon_goal']" )
    List<WebElement> editTargetBtn;

    @FindBy ( css = "cel-icon[name='file-pdf']" )
    List<WebElement> printBtn;

    @FindBy ( css = "g.highcharts-xaxis-labels text" )
    List<WebElement> dateValuesXAxis;

    @FindBy ( css = "g.highcharts-yaxis-labels text" )
    List<WebElement> courseValuesYAxis;

    @FindBy (css=".graph-buttons-container cel-icon[name='icon_goal']")
    public WebElement editTargetsButton;

    @IFindBy ( how = How.CSS, using = "cel-icon.contextual-help-icon", AI = false )
    public WebElement editTargetPopupHelpIcon;

    @IFindBy ( how = How.CSS, using = ".edit-target-reset-button-wrapper cel-button.hydrated", AI = false )
    public WebElement resetButton;

    @IFindBy ( how = How.CSS, using = ".edit-target-cancel-button-wrapper cel-button.hydrated", AI = false )
    public WebElement cancelButton;

    @IFindBy ( how = How.CSS, using = "edit-targets cel-icon[aria-label='icon close']", AI = false )
    public WebElement closeButtonOfEditTargetPopup;

    @IFindBy ( how = How.CSS, using = "cel-date-picker.edit-target-date-picker", AI = false )
    public WebElement calendarIcon;

    @IFindBy ( how = How.CSS, using = "cel-button.edit-target-save-button-wrapper", AI = false )
    public WebElement saveButtonEditTargetPopup;

    @FindBy ( css = ".dialog-wrapper__content .min-max-value span.max-value" )
    List<WebElement> slidersMaxValue;

    @FindBy ( css = ".dialog-wrapper__content .min-max-value span.min-value" )
    List<WebElement> slidersMinValue;

    @FindBy ( css = ".dialog-wrapper__content cel-range-slider" )
    List<WebElement> sliders;

    @IFindBy ( how = How.CSS, using = "button[class='graph-button zoom-in-label']", AI = false )
    public WebElement zoomInButton;

    @IFindBy ( how = How.CSS, using = "button[class='dialog-btn-close'] cel-icon", AI = false )
    public WebElement closeButton;
    //******* Zoom In Page *************
    @IFindBy ( how = How.CSS, using = "button.graph-button cel-icon.graph-button-icon.hydrated", AI = false )
    public WebElement clickViewSummaryBtnCss;

    @IFindBy ( how = How.CSS, using = "tr.accordion-table-row.accordion-head-1 td:first-child+td+td>div .text-overflow-nowrap", AI = false )
    public WebElement zeroIPLevelBtnCss;

    @IFindBy ( how = How.CSS, using = "button.graph-button.zoom-in-label", AI = false )
    public WebElement zoomInBtn;

    @IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
    public WebElement viewGraphTitle;

    @IFindBy ( how = How.CSS, using = "cel-icon[name='icon_goal']", AI = false )
    public WebElement editTargetsBtnHost;

    @IFindBy ( how = How.CSS, using = "cel-icon[name='file-pdf']", AI = false )
    public WebElement printBtnHost;

    @IFindBy ( how = How.CSS, using = "img[src='./assets/sm_logo_colored.svg']", AI = false )
    public WebElement successmakerLogo;

    @IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
    List<WebElement> textInZoomInPopup;

    @IFindBy ( how = How.CSS, using = "div.popup-dialog-header>div>span.heading-text", AI = false )
    public WebElement editTargetPopUpTitle;

    @IFindBy ( how = How.CSS, using = ".focus-outline-visible", AI = false )
    public WebElement successmakerLogoInPrintPopUp;

    @IFindBy ( how = How.CSS, using = "button.switch-button.toggle-off", AI = false )
    public WebElement clickToggleOFFShowTarget;

    @IFindBy ( how = How.CSS, using = "button.switch-button.toggle-on", AI = false )
    public WebElement clickToggleONShowTarget;

    @IFindBy ( how = How.CSS, using = "cel-button.edit-btn.hydrated", AI = false )
    public WebElement editShadowHostCssSelector;

//    @IFindBy ( how = How.CSS, using = ".accordion-toggle-button cel-icon[name='subtraction']", AI = false )
//    public WebElement substractionToggle;
    
    @FindBy (css=".accordion-toggle-button cel-icon[name='subtraction']")
    public WebElement substractionToggle;
    
    @FindBy (css=".accordion-toggle-button cel-icon[name='addition']")
    public WebElement additionToggle;

    @IFindBy ( how = How.CSS, using = "h1[title='View Graph']", AI = false )
    public WebElement viewGraph;

    @IFindBy ( how = How.CSS, using = "#cel-overlay-1 > div > cel-dialog-header > div", AI = false )
    public WebElement viewGraphDialogHeader;

    @IFindBy ( how = How.CSS, using = "div.graph-header>.graph-heading-wrapper>.accordion-graph-header-text", AI = false )
    public WebElement progressHeader;

    @IFindBy ( how = How.CSS, using = "#cel-overlay-1 > div > div > progress-graph-popup > div", AI = false )
    public WebElement progressDialogHeader;

    @IFindBy ( how = How.CSS, using = ".highcharts-plot-border", AI = false )
    public WebElement borderXYAxis;

    @IFindBy ( how = How.CSS, using = "svg > g.highcharts-legend.legend-image > rect.highcharts-legend-box", AI = false )
    public WebElement rectangularLgendsBox;

    @IFindBy ( how = How.CSS, using = "progress-graph-popup > div > div.graph-options-container > div > div > div", AI = false )
    public WebElement showTargetLink;

    @IFindBy ( how = How.CSS, using = "#cel-overlay-1>div>div>progress-graph-popup>div>div.graph-options-container>div>div>switch-button>button", AI = false )
    public WebElement showtargetToggle;

    @IFindBy ( how = How.CSS, using = "svg > g.highcharts-axis.highcharts-xaxis > text[text-anchor='middle']", AI = false )
    public WebElement calenderDays;

    @IFindBy ( how = How.CSS, using = "svg > g.highcharts-axis.highcharts-yaxis > path", AI = false )
    public WebElement yAxis;

    @IFindBy ( how = How.CSS, using = "div.dialog-header", AI = false )
    public WebElement viewGrapHeaderBox;

    @FindBy (css=".highcharts-background.highcharts div.highcharts-container rect.highcharts-plot-background")
    public WebElement zoomInGrapArea;
    
    @FindBy ( css = ".highcharts-series.highcharts-series-0.highcharts-line-series path.highcharts-graph" )
    List<WebElement> viewGraphTargetLine;

    @FindBy ( css = "g.highcharts-xaxis-labels text" )
    List<WebElement> firstDateOnXAxis;

    @FindBy ( css = ".highcharts-legend-item.highcharts-line-series.highcharts-color-undefined.highcharts-series-4 span" )
    List<WebElement> gainValueZoomIn;

    @FindBy ( css = "g.highcharts-legend.legend-image rect" )
    List<WebElement> legendImageZoomIn;

    @IFindBy ( how = How.CSS, using = "span.d-flex span.sort-icon cel-icon.arrow-down", AI = false )
    public WebElement nameSortingCheck;

    //****Progress View Summary **

    @FindBy(css="cel-icon[name='icon_bullet_list']")
    public WebElement viewSummaryRoot;

    @IFindBy ( how = How.CSS, using = "div.graph-header > span", AI = false )
    public WebElement proogressHeader;

    @IFindBy ( how = How.CSS, using = "cel-icon[name='icon_goal']", AI = false )
    public WebElement editTargets;

    @IFindBy ( how = How.CSS, using = "cel-icon[name='file-pdf']", AI = false )
    public WebElement print;

    @IFindBy ( how = How.CSS, using = "g.highcharts-axis.highcharts-yaxis > text", AI = false )
    public WebElement courseLevelText;

    @IFindBy ( how = How.CSS, using = "span.edit-target-cancel-button-wrapper > cel-button", AI = false )
    public WebElement editCancelbtnRoot;

    @FindBy ( css = "span.summary-name" )
    List<WebElement> viewSummaryList;

    @FindBy ( css = "div.progress-summary-graph>header>strong" )
    List<WebElement> viewSummaryHeaders;

    @FindBy ( css = "span.summary-value" )
    List<WebElement> viewSummaryNameValues;

    @FindBy ( css = "div.setting-label" )
    List<WebElement> assignmentSettingValues;

    @IFindBy ( how = How.CSS, using = "span[aria-label='Student is Paused']", AI = false )
    public WebElement pausedTag;

    @IFindBy ( how = How.CSS, using = "span.status-green", AI = false )
    public WebElement completedTag;

    @IFindBy ( how = How.CSS, using = "print-preview-app", AI = false )
    public WebElement windowPopuproot;
    
    @IFindBy ( how = How.CSS, using = "cel-button.dialog-button", AI = false )
    public WebElement popupCloseButton;
    
    @IFindBy ( how = How.CSS, using = "cel-button.assign-course-button.close-button", AI = false )
    public WebElement closeButtonElement;
    
    // *******Child Elements***************

    //  ** Print Popup **

    String windowPopupChild1 = "print-preview-sidebar#sidebar";
    String windowPopupChild2 = "print-preview-button-strip";
    String windowPopupChild3 = "cr-button.cancel-button";

    String studentNameCSS = "td:nth-of-type(1)>div>.text-overflow-nowrap";
    String studentLastSessionCSS = "";
    String studentAssignedLevelCSS = "";
    String studentCurrentLevelCSS = "";
    String studentEllipsisRootCSS = "td:nth-of-type(8)>.table-dropdown-menu";
    String studentEllipsisCSS = ".buttonmenu__dots";
    String studentEllipsisDropdownOptionsChildRootCSS = "cel-dropdown-menu-box";
    String studentEllipsisDropdownOptionsAssignmentSettingsCSS = "span[aria-label='Assignment Settings']";
    String studentEllipsisDropdownOptionsRemoveStudentCSS = "span[aria-label='Remove Student']";
    String addButtonRoot = "div.add-btn cel-button";
    String settingValue = "div.setting-value";
    String childElementStudentNameAssignmentDetailsTable = "span.text-overflow-nowrap";
    String tableColumn = "td";
    String labelStudentIPandGain = "span.text-overflow-nowrap";
    String labelLastSession = "span.date-cell";
    String arrowUp = "icon_arrow_thin_up";
    String arrowDown = "icon_arrow_thin_down";
    //******** fluencyFiles elements
    private static String fluencyFileschild = "div > ul > li:nth-of-type(1)";
    private static String fluencyFilesParent = "cel-dropdown-menu-box.hydrated";
    private static String fluencyFileSelectAllBtnChild = "input[type='checkbox']";
    private static String fluencyFilesForStudentChild = "span[aria-label='Fluency Files (0)']";
    private static String chBXRootForFluency = ".td-check cel-checkbox";

    //TODO - Some of the below static elements are repeated with similar String values but are given different names we should try to reduce this duplicates.
    // *****assigmnentSetting elements
    private static String assigmnentSettingParent = "cel-dropdown-menu-box.hydrated";
    private static String assigmnentSettingchild = "span[aria-label='Assignment Settings']";
    private static String assignmentSaveBtnChild = ".primary_button";
    private static String assignmentCancelBtn = ".secondary_button";
    private static String mainList = "ul";
    private static String subList = "li";

    // ******pauseAssignmentForStudent and Resume Assignment For Student

    private static String pauseAssignmentForStudentParent = "cel-dropdown-menu-box.hydrated";
    private static String pauseAssignmentForStudentChild = "span[aria-label='Pause Assignment For Student']";
    private static String pauseAssignmentForStudentCancelChild = ".secondary_button";
    private static String pauseAssignmentForStudentPauseChild = ".primary_button";
    private static String resumerAssignmentForStudentParent = "cel-dropdown-menu-box.hydrated";
    private static String pauseAssignmentStudentChild = "span[aria-label='Pause Assignment For Student']";
    private static String resumeAssignmentForStudentChild = "span[aria-label='Resume Assignment For Student']";
    private static String resumeAssignmentForStudentParent = "cel-dropdown-menu-box.hydrated";
    // *******removeStudent
    private static String removeStudentBtnParent = "cel-dropdown-menu-box.hydrated";
    private static String removeStudentChild = "span[aria-label='Remove Student']";
    private static String removeStudentCancelChild = ".secondary_button";
    private static String removebuttonchild = ".primary_button";
    private static String dotEllipsisOptionChild = "cel-icon[tabindex='0']";
    private static String dotEllipsisBesideAssignBtnParent = ".buttonmenu__dots";
    private static String dotEllipsisBesideAssignBtnChild = ".icon-inner";

    // ************ Edit Assignments Setting for All beside Assign btn

    private static String assignmentSettingForAllParent = "cel-dropdown-menu-box.menu-position-left";
    private static String assignmentSettingChild = "span.menu-item__label";
    

    // **********Pause All Student Elements
    private static String pauseAllStudentsParent = "cel-dropdown-menu-box.menu-position-left";
    private static String pauseAllStudentChild = "li:nth-child(2) > a > span";
    
    private static String pauseButtonChild = ".primary_button";
    private static String resumeAllStudentsParent = "cel-dropdown-menu-box.menu-position-left";
    private static String resumeAllStudentChild = "li:nth-child(2) > a > span";

    // *********Delete Assignment Elements
    private static String deleteAssignmentParent = "cel-dropdown-menu-box.menu-position-left";
    private static String deleteAssignmentChild = "li:nth-child(3) > a > span";
    private static String deleteAssignmentDeleteChild = ".primary_button";

    private static String assignBtnChild = ".primary_button";

    // **********Skill tested Elements **************
    public static String dropdownListRoot1CSS = "div div div div li";
    public static String dropdownListRoot2CSS = "li[class*='dropdown-item'] div  cel-checkbox";
    public static String dropdownElementRoot = "label[class*='checkbox__label']";
    public static String selectAllCSS = "div.dropdown-all-select";
    public static String btnApplyFilterCSS = "button.primary_button";
    public static String SKILL_CORRECT = "Skill Correct";
    public static String SKILL_PERCENT_VALUE = "Bar Percent Value";
    public static String BAR_WIDTH = "Bar Width";
    public static String PROGRESS_BAR_COLOR = "Bar Color";
    public static String SKILL_PERCENT_VALUE_COLOR = "Bar Percent Text Color";
    public static String dropdownCSS = "div.row.skills-tested-graph-filter cel-multi-check-dropdown";
    public static String grandtDropdownCSS = "cel-icon";
    public static String parentDropdownCSS = "img.icon-inner";

    //****Last session skill tested skill tested***
    private static String closeIconChild = "img.icon-inner";
    private static String closeButtonChild = "button.primary_button";

    private static String skillTestedRoot = "cel-icon[name='addition']";
    private static String skillTestedSubtractionRoot = "cel-icon[name='subtraction']";
    private static String collapseIconCSS = "cel-icon[aria-pressed='true']";

    // *************Assign button popup
    private static String btnSecondary = ".secondary_button";
    private static String btnPrimary = ".primary_button";
    private static String assignRadiobutton = "cel-radio-button.sc-cel-radio-button-s";
    private static String assignlabel = "label";

    //************Toggle Button*********
    private static String assignedToToggleButton = "div > button:nth-of-type(1)";
    private static String masteryToggleButton = "div > button:nth-of-type(2)";
    private static String deleteAssignmentPopupCloseBtnChild = "img.icon-inner";

    //************Zoom In Elements*********
    private static String clickViewSummaryBtnRoot = "img.icon-inner";
    private String editButtonCssSelector = "button.secondary_button";

    //************Edit Target Popup Elements*********
    private String calendarIconRoot = "cel-icon.calendar-icon";
    private String calendarIconImg = "img[class='icon-inner']";
    private String calendarPopup = "cel-date-picker-popup.hydrated";
    private String calendarWrapper = "div.date-picker-modal-wrapper";
    private String calendarHeaderText = "span.date-picker-modal-header-text";
    private String calendarLeftArrow = "cel-icon[aria-label='icon chevron left'";
    private String calendarRightArrow = "cel-icon[aria-label='chevron right'";
    private String calendarDateButton = "div.date-picker-modal-dates button[class='date-picker-clear-button date-button']";
    private String calendarSelectedDateButton = "div.date-picker-modal-dates button[class='date-picker-clear-button date-button selected']";
    private String datePickerInput = "input.date-picker-input";
    private String datePickerAttributeTag = "data-default-value";
    private String sliderInput = "input[class='slider']";

    @IFindBy ( how = How.CSS, using = "cel-icon[name='icon_bullet_list']", AI = false )
    public WebElement viewSummaryIconCss;

    @IFindBy ( how = How.CSS, using = "cel-icon[name='file-pdf']", AI = false )
    public WebElement printIconHost;

    private static String progressIconShadowRootCss = "img.icon-inner";

    private static String settingLabel = ".setting-label";
    private static String toggleOffButton = "button.switch-button.toggle-off";
    private static String toggleOnButton = "button.switch-button.toggle-on";
    private String toggleStatus = null;

    @FindBy ( css = "setting-control.toggle-control-wrapper" )
    List<WebElement> singleColumnElements;
    
    @IFindBy(how=How.CSS, using="span.col-name", AI=false)
    public WebElement studentName;
    
    // *********Common Methods*************

    public AssignmentDetailsPage() {}

    /**
     *
     * Constructor class for Assignment details page and initializing the driver
     * for page factory objects.
     *
     * @param driver
     * @param url
     */

    public AssignmentDetailsPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, assignmentTitle );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, assignmentTitle, 30 ) ) {
            Log.message( "View Assignment Details Page loaded successfully." );
        } else {
            Log.fail( "View Assignment Details Page did not load." );
        }

    }

    //TODO - As its a common method will check null safe in further PRs of the story.

    /**
     * Gets and returns the student names associated to the assignment
     *
     * @return
     */
    public List<String> getStudentsAssociatedWithAssignment() {
        SMUtils.nap( 0.2 );
        List<String> associatedStudents = new ArrayList<>();
        try {
            for ( WebElement student : availableStudents ) {
                WebElement studentNameElement = SMUtils.getChildWebElementFromParent( student, studentNameCSS );
                String studentFullName = studentNameElement.getText();

                // remove middle name from student name
                String[] studentName = studentFullName.split( " " );
                String studentFirstLastName = "";
                if ( studentName.length > 2 ) {
                    studentFirstLastName = studentName[0] + " " + studentName[2];
                } else {
                    studentFirstLastName = studentFullName;
                }

                associatedStudents.add( studentFirstLastName );
            }
            return associatedStudents;
        } catch ( NullPointerException e ) {
            Log.message( "Student list is empty for this particular assignment" );
            return Collections.emptyList();
        }

    }

    //TODO - It was already present in the code-base. Will try to shorten this code in the upcoming PRs of the new story.
    /**
     * Clicks the Assignment Settings option from ellipsis of the given student
     *
     * @return
     */
    public void clickAssignmentSettingsOfStudent( String studentNameToSelect ) {
        SMUtils.nap( 1 );
        PageFactory.initElements( driver, this );
        try {
            for ( WebElement student : availableStudents ) {
                WebElement studentNameElement = SMUtils.getChildWebElementFromParent( student, studentNameCSS );
                String studentFullName = studentNameElement.getText();

                // remove middle name from student name
                String[] studentName = studentFullName.split( " " );
                String studentFirstLastName = "";
                if ( studentName.length > 2 ) {
                    studentFirstLastName = studentName[0] + " " + studentName[2];
                } else {
                    studentFirstLastName = studentFullName;
                }

                if ( studentFirstLastName.equals( studentNameToSelect ) ) {
                    // click the ellipsis of the respective student
                    WebElement studentEllipsisRootElement = SMUtils.getChildWebElementFromParent( student, studentEllipsisRootCSS );
                    WebElement studentEllipsisElement = SMUtils.getWebElement( driver, studentEllipsisRootElement, studentEllipsisCSS );
                    //TODO - Please try to implement suggestions from SonarLint
                    try {
                        SMUtils.scrollWebElementToView( driver, studentEllipsisElement );
                        studentEllipsisElement.click();
                    } catch ( ElementNotInteractableException e ) {
                        SMUtils.clickJS( driver, studentEllipsisElement );
                    }

                    // Get Ellipsis options
                    WebElement studentEllipsisDropdownOptionsChildRootElement = SMUtils.getWebElement( driver, studentEllipsisRootElement, studentEllipsisDropdownOptionsChildRootCSS );

                    // Get Ellipsis->Assignment Settings option and click
                    WebElement studentEllipsisDropdownOptionsAssignmentSettingsElement = SMUtils.getWebElement( driver, studentEllipsisDropdownOptionsChildRootElement, studentEllipsisDropdownOptionsAssignmentSettingsCSS );
                    //TODO - Please try to implement suggestions from SonarLint
                    try {
                        studentEllipsisDropdownOptionsAssignmentSettingsElement.click();
                    } catch ( ElementNotInteractableException e ) {
                        SMUtils.clickJS( driver, studentEllipsisDropdownOptionsAssignmentSettingsElement );
                    }
                    break;
                }
            }
        } catch ( NullPointerException e ) {
            Log.message( "Student " + studentNameToSelect + " is not assigned to the assignment" );
        }

    }

    /**
     * Click Ellipsis by student name
     *
     * @param studentName
     */
    public void clickEllipsisBtnByName( String studentName ) {
        SMUtils.nap( 2 );
        WebElement ellipsisRoot = driver.findElement( By.xpath( "//span[text()='" + studentName + "']/parent::div/parent::td//following-sibling::td[7]/cel-button-menu" ) );
        Log.message( ellipsisRoot.toString() );
        WebElement dotEllipsisButton = SMUtils.getWebElement( driver, ellipsisRoot, dotEllipsisOptionChild );
        SMUtils.nap( 2 );
        SMUtils.scrollWebElementToView( driver, dotEllipsisButton );
        SMUtils.nap( 2 );
        SMUtils.clickJS( driver, dotEllipsisButton );
        Log.message( studentName + " ellipsis button is clicked" );

    }

    /**
     * To Get Assignment Setting tab
     *
     * @return
     */
    public String assignmentSettingInEllipsis() {

        SMUtils.waitForElement( driver, assigmnentSettingGrandRoot );
        WebElement assigmentsSettingParent = SMUtils.getWebElement( driver, assigmnentSettingGrandRoot, assigmnentSettingParent );
        WebElement assigmentsSetting = SMUtils.getWebElement( driver, assigmentsSettingParent, assigmnentSettingchild );
        return assigmentsSetting.getText();
    }

    /**
     * To Get Pause assignment for Student Tab
     *
     * @return
     */
    public String pauseAssignmentForStudentTabInEllipsis() {
        SMUtils.waitForElement( driver, pauseAssignmentForStudentGrandRoot );
        WebElement pauseAssignmentParent = SMUtils.getWebElement( driver, pauseAssignmentForStudentGrandRoot, pauseAssignmentForStudentParent );
        WebElement pauseAssignment = SMUtils.getWebElement( driver, pauseAssignmentParent, pauseAssignmentForStudentChild );
        return pauseAssignment.getText();
    }

    /**
     * To Click Pause assignment for Student Tab
     */
    public void pauseAssignmentForStudentTab() {
        SMUtils.waitForElement( driver, pauseAssignmentForStudentGrandRoot );
        WebElement pauseAssignmentParent = SMUtils.getWebElement( driver, pauseAssignmentForStudentGrandRoot, pauseAssignmentForStudentParent );
        WebElement pauseAssignment = SMUtils.getWebElement( driver, pauseAssignmentParent, pauseAssignmentForStudentChild );
        SMUtils.clickJS( driver, pauseAssignment );
        Log.message( "Clicked Pause Assignments for Student tab" );

    }

    /**
     * To Get Remove student Tab on assignments Listing
     *
     * @return
     */
    public String removeStudentTabInEllipsis() {
        SMUtils.waitForElement( driver, removeStudentBtnGrandRoot );
        WebElement removeStudentParent = SMUtils.getWebElement( driver, removeStudentBtnGrandRoot, removeStudentBtnParent );
        WebElement removeStudent = SMUtils.getWebElement( driver, removeStudentParent, removeStudentChild );
        return removeStudent.getText();
    }

    /**
     * To Get Assignment Setting Tab on assignments Listing
     */
    public String assignmentSettingTabTopEllipsis() {
	         SMUtils.waitForElement( driver, assignmentSettingForAllGrandRoot,30 );
              WebElement allAssignmentSetting = SMUtils.getWebElementDirect( driver, assignmentSettingForAllGrandRoot, assignmentSettingForAllParent, assignmentSettingChild );
              return allAssignmentSetting.getText();
    }

    /**
     * Get on assignment Level Pause Student
     *
     * @return
     */
    public String pauseAllStudentTopEllipsis() {
        SMUtils.waitForElement( driver, pauseAllStudentsGrandRoot );
        WebElement pauseAllStudentTabParent = SMUtils.getWebElement( driver, pauseAllStudentsGrandRoot, pauseAllStudentsParent );
        WebElement pauseAllStudentTab = SMUtils.getWebElement( driver, pauseAllStudentTabParent, pauseAllStudentChild );
        return pauseAllStudentTab.getText();
    }

    /**
     * Get Delete Assignment tab at Assignment Level
     *
     * @return
     */
    public String deleteAssignmenttabTopEllipsis() {
        SMUtils.waitForElement( driver, deleteAssignmentGrandRoot );
//        WebElement deleteAssignmentTabParent = SMUtils.getWebElement( driver, deleteAssignmentGrandRoot, deleteAssignmentParent );
//        WebElement deleteAssignmentTab = SMUtils.getWebElement( driver, deleteAssignmentTabParent, deleteAssignmentChild );
        WebElement deleteAssignmentTab = SMUtils.getWebElementDirect( driver, deleteAssignmentGrandRoot, deleteAssignmentParent, deleteAssignmentChild );
        return deleteAssignmentTab.getText();
    }

    /**
     * Find all assigned list of Student on assignments details page
     */

    /**
     * Gets Name column name
     */
    public String getColumnName() {
        return columnName.getText().toString();
        
    }

    /**
     * Gets LastSession column name
     */
    public String getColumnLastSession() {
        return columnLastSession.getText();
    }

    /**
     * Gets IPLevel column name
     */
    public String getColumnIPLevel() {
        return columnIPLevel.getText();
    }

    /**
     * Gets AssignedLevel column name
     */
    public String getColumnAssignedLevel() {
        return columnAssignedLevel.getText();
    }

    /**
     * Gets CurrentLevel column name
     */
    public String getColumnCurrentLevel() {
        return columnCurrentLevel.getText();
    }

    /**
     * Gets Gain column name
     */
    public String getColumnGain() {
        return columnGain.getText();
    }

    /**
     * Gets PercentageCorrect column name
     */
    public String getColumnPercentageCorrect() {
        return columnPercentageCorrect.getText();
    }

    /**
     * Gets Title Of Assignment Details Page
     */
    public String gettitleOfAssignmentDetailsPage() {
        String title;
        SMUtils.waitForElement( driver, titleOfAssignmentDetailsPage, 30 );
        title = titleTooltipOfAssignmentDetailsPage.getText().trim();
        if ( StringUtils.isNotEmpty( title ) ) {
            return title;
        } else {
            title = titleOfAssignmentDetailsPage.getText().trim();
            return title;
        }
    }

    /**
     * Gets SubTitle Of Assignment Details Page
     */
    public String getsubTitleOfAssignmentDetailsPage() {
        SMUtils.waitForElement( driver, subTitleOfAssignmentDetailsPage );
        return subTitleOfAssignmentDetailsPage.getText();
    }

    /**
     * To Click dot Ellipsis icon on Assignment Listing Page
     */
    public void clickDotEllipsisButton() {
        SMUtils.waitForElement( driver, dotEllipsisOptionRoot, 30 );
        WebElement dotEllipsisButton = SMUtils.getWebElement( driver, dotEllipsisOptionRoot, dotEllipsisOptionChild );
        SMUtils.clickJS( driver, dotEllipsisButton );
        Log.message( "Clicked to Ellipsis Button" );

    }

    /**
     * To Click Assignment Setting tab
     */
    public void clickAssignmentSetting() {

        SMUtils.waitForElement( driver, assigmnentSettingGrandRoot, 30 );
        SMUtils.nap( 1 );
        WebElement assigmentsSettingParent = SMUtils.getWebElement( driver, assigmnentSettingGrandRoot, assigmnentSettingParent );

        WebElement assigmentsSetting = SMUtils.getWebElement( driver, assigmentsSettingParent, assigmnentSettingchild );
        SMUtils.clickJS( driver, assigmentsSetting );
        Log.message( "Clicked Assignement Setting tab" );

    }

    /**
     * To Click Save Button for Assignments Setting
     */
    public void clickSaveButton() {
        SMUtils.waitForElement( driver, assignmentSaveBtnRoot );
        WebElement saveButton = SMUtils.getWebElement( driver, assignmentSaveBtnRoot, assignmentSaveBtnChild );
        SMUtils.clickJS( driver, saveButton );
        Log.message( "Clicked Save Button for Edit assignment" );

    }

    /**
     * To Click Cancel Button for Assignments Setting
     */
    public void clickCancelButton() {
        SMUtils.waitForElement( driver, assignmentCancelBtnRoot );
        WebElement cancelButton = SMUtils.getWebElement( driver, assignmentCancelBtnRoot, assignmentCancelBtn );
        SMUtils.clickJS( driver, cancelButton );
        Log.message( "Clicked cancel Button" );

    }

    /**
     * To Click cancel on popup for Pause assignment for Student Tab
     */
    public void pauseAssignmentForStudentcancelButton() {
        SMUtils.waitForElement( driver, pauseAssignmentForStudentCancelbtn );
        WebElement pauseAssignmentCancel = SMUtils.getWebElement( driver, pauseAssignmentForStudentCancelbtn, pauseAssignmentForStudentCancelChild );
        SMUtils.clickJS( driver, pauseAssignmentCancel );
        Log.message( "Clicked Cancel button for pause assignments for student" );

    }

    /**
     * To click Remove student Tab on assignments Listing
     */
    public void removeStudentTab() {
        SMUtils.waitForElement( driver, removeStudentBtnGrandRoot );
        WebElement removeStudentParent = SMUtils.getWebElement( driver, removeStudentBtnGrandRoot, removeStudentBtnParent );
        WebElement removeStudent = SMUtils.getWebElement( driver, removeStudentParent, removeStudentChild );
        SMUtils.clickJS( driver, removeStudent );
        Log.message( "Clicked remove student tab" );

    }

    /**
     * To click Remove student Tab on assignments Listing
     */
    public void removeStudentCancelButton() {
        SMUtils.waitForElement( driver, removeStudentCancelButton );
        WebElement removeStudentCancel = SMUtils.getWebElement( driver, removeStudentCancelButton, removeStudentCancelChild );
        SMUtils.clickJS( driver, removeStudentCancel );
        Log.message( "Clicked Cancel button in the Remove Student popup" );

    }

    /**
     * Remove the student by clicking on remove button
     */
    public void removeStudent() {
        SMUtils.waitForElement( driver, removeButtonOnpopupRoot );
        WebElement removebtn = SMUtils.getWebElement( driver, removeButtonOnpopupRoot, removebuttonchild );
        SMUtils.clickJS( driver, removebtn );
        SMUtils.nap( 1 );//To wait for the page load
        Log.message( "Clicked Remove button for remove student" );

    }

    /**
     * Click Dot ellipsis at assignments level
     */
    public void assignmentLevelEllipsis() {
        SMUtils.waitForElement( driver, dotEllipsisBesideAssignBtnGrandRoot, 30 );
        WebElement assignlevelEllipsisParent = SMUtils.getWebElement( driver, dotEllipsisBesideAssignBtnGrandRoot, dotEllipsisBesideAssignBtnParent );
        PageFactory.initElements( driver, this );
        WebElement assignlevelEllipsis = SMUtils.getWebElement( driver, assignlevelEllipsisParent, dotEllipsisBesideAssignBtnChild );
        SMUtils.clickJS( driver, assignlevelEllipsis );
        Log.message( "Clicked dot ellipsis button at assignment level" );
    }

    /**
     * To check Assignment Level Ellipses clicked
     */
    public boolean assignmentLevelEllipsisClicked() {
        SMUtils.waitForElement( driver, dotEllipsisBesideAssignBtnGrandRoot, 10 );
        WebElement assignLevelEllipsis = SMUtils.getWebElementDirect( driver, dotEllipsisBesideAssignBtnGrandRoot, dotEllipsisBesideAssignBtnParent, dotEllipsisBesideAssignBtnChild );
        SMUtils.clickJS( driver, assignLevelEllipsis );
        return assignLevelEllipsis.isEnabled();
    }

    /**
     * Check Click Delete Assignment tab at Assignment Level
     */
    public boolean checkDeleteAssignmentTabClicked() {
        SMUtils.waitForElement( driver, deleteAssignmentGrandRoot );
        WebElement deleteAssignmentTab = SMUtils.getWebElementDirect( driver, deleteAssignmentGrandRoot, deleteAssignmentParent, deleteAssignmentChild );
        return deleteAssignmentTab.isEnabled();

    }

    /**
     * To check display of Delete Assignment
     */
    public boolean isDeleteAssignmentPopUpDisplayed() {
        SMUtils.waitForElement( driver, deletePopupModalPopup, 10 );
        driver.switchTo().activeElement();
        return SMUtils.isElementPresent( deletePopupModalPopup );

    }

    /**
     * Checks Delete Assignment Popup closed or not
     */
    public boolean isDeleteAssignmentPopupClosed() {
        return CollectionUtils.isEmpty( textInDeleteAssignmentPopup );
    }

    /**
     * To Click Close(X) Button for Assignment Delete Popup
     */

    public void clickCloseButton() {
        SMUtils.waitForElement( driver, deleteAssignmentPopupCloseBtnRoot );
        WebElement closeButton = SMUtils.getWebElement( driver, deleteAssignmentPopupCloseBtnRoot, deleteAssignmentPopupCloseBtnChild );
        SMUtils.clickJS( driver, closeButton );
        Log.message( "Clicked Close Button" );
        isDeleteAssignmentPopupClosed();

    }

    /**
     * To Click Cancel Button for Delete Assignment
     */
    public void clickCancelButtonForDeleteAssignment() {
        SMUtils.waitForElement( driver, removeStudentCancelButton );
        WebElement cancelButton = SMUtils.getWebElement( driver, removeStudentCancelButton, pauseAssignmentForStudentCancelChild );
        SMUtils.clickJS( driver, cancelButton );
        Log.message( "Clicked Cancel Button" );
    }

    /**
     * Check Assignment Availability
     */
    public boolean assignmentDeleted() {

        SMUtils.waitForElement( driver, assignmentAvailability, 10 );
        return assignmentAvailability.isDisplayed();
    }

    /**
     * Click Delete Assignment tab at Assignment Level
     */
    public void deleteAssignmenttab() {
        SMUtils.waitForElement( driver, deleteAssignmentGrandRoot );
        WebElement deleteAssignmentTabParent = SMUtils.getWebElement( driver, deleteAssignmentGrandRoot, deleteAssignmentParent );
        WebElement deleteAssignmentTab = SMUtils.getWebElement( driver, deleteAssignmentTabParent, deleteAssignmentChild );
        SMUtils.clickJS( driver, deleteAssignmentTab );
        Log.message( "Clicked delete Assignment tab" );
    }

    /**
     * Click Delete Assignment tab at Assignment Level
     */
    public void deleteAssignmentButton() {
        SMUtils.waitForElement( driver, deleteAssignmentsDeleteBtn );
        WebElement deleteAssignmentBtn = SMUtils.getWebElement( driver, deleteAssignmentsDeleteBtn, deleteAssignmentDeleteChild );
        SMUtils.clickJS( driver, deleteAssignmentBtn );
        Log.message( "Clicked delete button and delete Assignment" );
    //    SMUtils.waitForElement( driver, assignmentText, 5 );
    }

    /**
     * Capture the Assignment Text
     *
     */
    public String getAssignmentText() {
        return assignmentText.getText();
    }

    /**
     * Generic Dropdown
     */
    public void genericDropdown( String value ) {
        SMUtils.nap( 1 );
        for ( WebElement options : dropdownGeneric ) {
            String text = options.getText();
            if ( text.equalsIgnoreCase( value ) ) {
                options.click();
                break;

            }
        }
    }

    /**
     * To Get Session Length
     */
    public void selectValueFromDropDownSessionLength( String value ) {
        SMUtils.nap( 1 );
        SMUtils.waitForElement( driver, sessionLength, 30 );
        SMUtils.clickJS( driver, sessionLength );
        genericDropdown( value );
        Log.message( value + " session length is Selected" );
    }

    public String getsessionLength() {
        SMUtils.waitForElement( driver, sessionLength );
        return sessionLength.getText();
    }

    /**
     * Idle Time Dropdown in Assignment Setting Page
     */

    public void selectValueFromDropDownIdleTime( String value ) {
        SMUtils.clickJS( driver, idealTime );
        genericDropdown( value );
    }

    /**
     * Ideal Time text
     *
     * @return
     */

    public String idealTime() {
        return idealTime.getText();
    }

    /**
     *
     * Session Length
     *
     * @return
     */
    public boolean isSessionLengthDisplayed() {
        return ( sessionLengthText.isDisplayed() );
    }

    /**
     * Click on Pause Button on Pause window
     */
    public void clickPauseButtononPopUpPage() {
        SMUtils.waitForElement( driver, pauseAssignmentbtnOnPopUpRoot );
        WebElement pauseButtonOnPopup = SMUtils.getWebElement( driver, pauseAssignmentbtnOnPopUpRoot, pauseAssignmentForStudentPauseChild );
        SMUtils.clickJS( driver, pauseButtonOnPopup );
        Log.message( "Clicked Pause Button On Pause assignment Pop up" );
    }

    /**
     * Click on Assignment level Assignment Setting
     */
    public void allAssignmenttSettingTab() {
      //  SMUtils.waitForElement( driver, assignmentSettingForAllGrandRoot );
    	SMUtils.nap(5);
        WebElement allAssignmentSettingParent = SMUtils.getWebElementDirect( driver, assignmentSettingForAllGrandRoot, assignmentSettingForAllParent );
        WebElement allAssignmentSetting = SMUtils.getWebElementDirect( driver, allAssignmentSettingParent, assignmentSettingChild );
        SMUtils.clickJS( driver, allAssignmentSetting );
        Log.message( "Clicked assignment level Assignment Setting tab" );
    }

    /**
     * CLick on assignment Level Pause Student
     */
    public void pauseAllStudent() {
        SMUtils.waitForElement( driver, pauseAllStudentsGrandRoot );
        SMUtils.clickJS( driver, pauseAllStudentsGrandRoot );
        SMUtils.nap(5);
        WebElement pauseAllStudentTabParent = SMUtils.getWebElement( driver, pauseAllStudentsGrandRoot, pauseAllStudentsParent );
        WebElement pauseAllStudentTab = SMUtils.getWebElement( driver, pauseAllStudentTabParent, pauseAllStudentChild );
        SMUtils.clickJS( driver, pauseAllStudentTab );
        Log.message( "Clicked assignment level pause Student tab" );

    }
    public void popupClose() {
    	SMUtils.waitForElement(driver, popupCloseButton);
    	SMUtils.click(driver, popupCloseButton);
	}

    /**
     * CLick on Pause button at poppup at assign Level for Pause Student
     */

    public void pauseButtonFoAllSTudent() {
        SMUtils.waitForElement( driver, pauseAllStudentBtnRoot, 10 );
        WebElement pauseAllStudentbutton = SMUtils.getWebElement( driver, pauseAllStudentBtnRoot, pauseButtonChild );
        SMUtils.clickJS( driver, pauseAllStudentbutton );
        Log.message( "Clicked pause button at assignment level for All student" );
        SMUtils.waitForElement( driver, studentTable, 5 );
    }

    /**
     * Resume Assignment at student level
     */
    public void resumeAssignment() {
        SMUtils.waitForElement( driver, resumeAssignmentForStudentGrandRoot );
        WebElement resumeAssignmentParent = SMUtils.getWebElement( driver, resumeAssignmentForStudentGrandRoot, resumerAssignmentForStudentParent );
        WebElement resumeAssignment = SMUtils.getWebElement( driver, resumeAssignmentParent, resumeAssignmentForStudentChild );
        SMUtils.clickJS( driver, resumeAssignment );
        Log.message( "Clicked Resume Assignment tab" );

    }

    /**
     * Pause Text Displaying
     */
    public void resumeAllAssignment() {
        SMUtils.waitForElement( driver, resumeAllStudentsGrandRoot );
        SMUtils.clickJS( driver, resumeAllStudentsGrandRoot );
        SMUtils.nap(5);
        WebElement resumeAllAssignmentParent = SMUtils.getWebElement( driver, resumeAllStudentsGrandRoot, resumeAllStudentsParent );
        WebElement resumeAllAssignment = SMUtils.getWebElement( driver, resumeAllAssignmentParent, resumeAllStudentChild );
        SMUtils.clickJS( driver, resumeAllAssignment );
        Log.message( "Clicked Resume all Assignment tab" );

    }

    /**
     * Resume all Assignment button at assignment level
     */
    public void resumeButtonFoAllSTudent() {
        SMUtils.waitForElement( driver, pauseAllStudentBtnRoot );
        WebElement pauseAllStudentbutton = SMUtils.getWebElement( driver, pauseAllStudentBtnRoot, pauseButtonChild );
        SMUtils.clickJS( driver, pauseAllStudentbutton );
        Log.message( "Clicked Resume button at assignment level for All student" );
        SMUtils.waitForElement( driver, studentTable, 5 );

    }

    /**
     * CLick Pause Button on window pop up
     */
    public void clickResumeButtononPopUpPage() {
        SMUtils.waitForElement( driver, pauseAssignmentbtnOnPopUpRoot );
        WebElement pauseButtonOnPopup = SMUtils.getWebElement( driver, pauseAssignmentbtnOnPopUpRoot, pauseAssignmentForStudentPauseChild );
        SMUtils.clickJS( driver, pauseButtonOnPopup );
        Log.message( "Clicked Resume Button On Pause assignment Pop up" );

    }

    /**
     * Assignment Availability
     */

    public boolean isAssignmentDisplayed() {

        SMUtils.waitForElement( driver, assignmentAvailability );
        return assignmentAvailability.isDisplayed();
    }

    /***
     * Is student displaying after deleted
     */

    public boolean isStudentDisplayed() {
        SMUtils.waitForElement( driver, isStudentDisplayedElement );
        return isStudentDisplayedElement.isDisplayed();
    }

    /**
     * Get Resume Student
     */
    public Boolean isStudentPaused() {

        SMUtils.waitForElement( driver, isStudentDisplayedElement );
        try {
            return pauseText.stream().anyMatch( ele -> ele.getText().equals( Constants.PAUSED_STUDENT ) );
        } catch ( Exception e ) {
            return false;
        }

    }

    /**
     * Assignment Paused
     */
    public boolean isAssignmentPaused() {
        SMUtils.waitForElement( driver, capturePaused );
        return capturePaused.isDisplayed();
    }

    /**
     * Paused at Assignment level
     */
    public boolean isAssignmentPausedatAssignmentLevel() {
        SMUtils.waitForElement( driver, captureAssignmentlevelPaused, 20);
        return captureAssignmentlevelPaused.isDisplayed();
    }

    //TODO - Suggestion from SonarLint : Rename the method "getSessionLength" to prevent any misunderstanding/clash with method "getsessionLength"
    /**
     * To Get Session Length
     *
     * @return
     */
    public String getSessionLength() {
        SMUtils.waitForElement( driver, sessionLengthValue );
        String valueOfSessionLength = sessionLengthValue.getText().trim();
        Log.message( valueOfSessionLength );
        return valueOfSessionLength;
    }

    /**
     * Get Student Listing on assignment listing
     *
     * @return
     */
    public List<String> getStudentListfromAssignementDetailsTable() {
        SMUtils.waitForElement( driver, isStudentDisplayedElement );
        new WebDriverWait( driver, Duration.ofSeconds( 5 ) ).until( ExpectedConditions.visibilityOfAllElements(assignmentTitles));
        List<String> assignementDetailsTableStudentList = new ArrayList<>();
        assignmentTitles.stream().forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( assignementDetailsTableStudentList::add ) );
        return assignementDetailsTableStudentList;
    }

    /**
     * Get Student List from assignment details page
     *
     * @return
     */
    public List<String> getStudentListfromAssignementDetails() {
        SMUtils.waitForElement( driver, isStudentDisplayedElement );
        List<String> assignementDetailsPageStudentList = new ArrayList<>();
        studentNameViewAssignmentTable.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( assignementDetailsPageStudentList::add ) );
        return assignementDetailsPageStudentList;
    }

    /**
     * To get ideal Time
     *
     * @return
     */
    public String getIdealTime() {
        SMUtils.waitForElement( driver, idealTimeValue );
        String valueOfIdealTime = idealTimeValue.getText().trim();
        Log.message( "Value of ideal time :" + valueOfIdealTime );
        return valueOfIdealTime;
    }

    /**
     * To get session length
     *
     * @return
     */
    public String sessioLength() {
        SMUtils.waitForElement( driver, sessionLengthValue );
        String valueOfSessionLength = sessionLengthValue.getText().trim();
        Log.message( "Value of session length :" + valueOfSessionLength );
        return valueOfSessionLength;
    }

    /**
     * To get Assign button element
     *
     * @return
     * @return
     */
    public WebElement assignElement() {
        SMUtils.waitForElement( driver, assignBtnAssignmentlistRoot );
        return SMUtils.getWebElement( driver, assignBtnAssignmentlistRoot, assignBtnChild );
    }
    public WebElement assignElementVerify() {
        SMUtils.waitForElement( driver, assignBtnAssignmentlist );
        return SMUtils.getWebElementDirect(driver, assignBtnAssignmentlist);
      //  return SMUtils.getWebElement( driver, assignBtnAssignmentlist );
    }
    

    /**
     * To Click Assign Button on Assign listing page
     */
    public AssignAssignmentPopup clickAssignButton() {
        SMUtils.waitForElement( driver, assignBtnAssignmentlistRoot );
        WebElement assignButton = SMUtils.getWebElement( driver, assignBtnAssignmentlistRoot, assignBtnChild );
        SMUtils.clickJS( driver, assignButton );
        Log.message( "Clicked Assign Button on Assignments Listing Button" );
        return new AssignAssignmentPopup( driver );

    }

    /**
     * To Delete Assignment
     *
     * @return
     */
    public void clickDeleteAssignmenttabTopEllipsis() {
        SMUtils.waitForElement( driver, deleteAssignmentGrandRoot );
        SMUtils.clickJS( driver, deleteAssignmentGrandRoot );
        WebElement deleteAssignmentTabParent = SMUtils.getWebElement( driver, deleteAssignmentGrandRoot, deleteAssignmentParent );
        WebElement deleteAssignmentTab = SMUtils.getWebElement( driver, deleteAssignmentTabParent, deleteAssignmentChild );
        SMUtils.clickJS( driver, deleteAssignmentTab );
        deleteAssignmentButton();
        Log.message( "Clicked delete assignment tab in top ellipsis" );
    }

    /**
     * Return all the options of the ellipsis for any student in the Assignments
     * section for particular student
     *
     * @return
     */
    public List<String> getAllEllipsisOptionAtStudentLevel( String studentNameToSelect ) {
        List<String> ellipsisOption = new ArrayList<>();
        SMUtils.waitForLocator( driver, By.cssSelector( studentEllipsisRootCSS ), 5 );
        availableStudents.stream().forEach( element -> Optional.ofNullable( SMUtils.getChildWebElementFromParent( element, studentNameCSS ).getText().trim() ).ifPresent( elementText -> {
            if ( elementText.equals( studentNameToSelect ) ) {
                // Click the ellipsis of the respective student
                WebElement studentEllipsisRootElement = SMUtils.getChildWebElementFromParent( element, studentEllipsisRootCSS );
                WebElement studentEllipsisElement = SMUtils.getWebElement( driver, studentEllipsisRootElement, studentEllipsisCSS );
                try {
                    SMUtils.scrollWebElementToView( driver, studentEllipsisElement );
                    SMUtils.click( driver, studentEllipsisElement );
                    WebElement studentEllipsisDropdownOptionsChildRootElement = SMUtils.getWebElementDirect( driver, studentEllipsisRootElement, assigmnentSettingParent, mainList );
                    studentEllipsisDropdownOptionsChildRootElement.findElements( By.cssSelector( subList ) ).stream().forEach( ellipsisElement -> ellipsisOption.add( SMUtils.getTextOfWebElement( ellipsisElement, driver ) ) );
                } catch ( ElementNotInteractableException e ) {
                    Log.message( "Hidden element detected" );
                }
            }
        } ) );
        return ellipsisOption;
    }

    /**
     *
     * @param firstName
     * @param middleName
     * @param lastName
     * @throws Exception
     */
    public void clicktoggleButtonForStudent( String firstName, String middleName, String lastName ) throws Exception {
        String studentName = completeStudentName( firstName, middleName, lastName );
        try {
            SMUtils.waitForElement( driver, assignBtnAssignmentlistRoot, 10 );
            if ( !isSkillTestedExpanded() ) {
                SMUtils.waitForElement( driver, assignBtnAssignmentlistRoot, 10 );
                lblStudentName.stream().forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( studentFromUI -> {
                    if ( studentFromUI.equalsIgnoreCase( studentName ) ) {
                        WebElement grandRoot = element.findElement( By.xpath( "./../.." ) );
                        WebElement parentRoot = grandRoot.findElement( By.cssSelector( skillTestedRoot ) );
                        WebElement plusIcon = SMUtils.getWebElement( driver, parentRoot, dotEllipsisBesideAssignBtnChild );
                        SMUtils.clickJS( driver, plusIcon );
                        SMUtils.waitForElement( driver, skillTestedHeader, 5 );
                        Log.message( "Expanded the skill dropdown for student - " + studentName );
                    }
                } ) );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param firstName
     * @param middleName
     * @param lastName
     * @throws Exception
     */
    public void skillTestCollapseForStudent( String firstName, String middleName, String lastName ) throws Exception {
        String studentName = completeStudentName( firstName, middleName, lastName );
        try {
            SMUtils.waitForElementToBeClickable( assignBtnAssignmentlistRoot, driver );
            if ( isSkillTestedExpanded() ) {
                SMUtils.waitForElement( driver, assignBtnAssignmentlistRoot );
                lblStudentName.stream().forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( studentFromUI -> {
                    if ( studentFromUI.equalsIgnoreCase( studentName ) ) {
                        WebElement grandRoot = element.findElement( By.xpath( "./../.." ) );
                        WebElement parentRoot = grandRoot.findElement( By.cssSelector( skillTestedSubtractionRoot ) );
                        WebElement plusIcon = SMUtils.getWebElement( driver, parentRoot, dotEllipsisBesideAssignBtnChild );
                        SMUtils.click( driver, plusIcon );
                        SMUtils.waitForElement( driver, skillTestedHeader );
                        Log.message( "Collapsed the skill dropdown for student - " + studentName );
                    }
                } ) );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * This method will return concatenated name of the Student
     *
     * @param firstName
     * @param middleName
     * @param lastName
     *
     * @return String
     */
    public String completeStudentName( String firstName, String middleName, String lastName ) {

        String studentFullName = "";

        if ( middleName.isEmpty() ) {
            studentFullName = String.join( " ", firstName, lastName );
        } else {
            studentFullName = String.join( " ", firstName, middleName, lastName );
        }
        return studentFullName.trim().replaceAll( "\\s{2,}", " " );
    }

    /**
     * To get the Last session dropdown values
     *
     * @return
     */

    public List<String> getLastSessionDropdownValues() {
        List<String> dropdownValues = new ArrayList<>();
        List<WebElement> listDropdown = SMUtils.getWebElementsDirect( driver, dropdownRoot1, dropdownListRoot1CSS );
        Log.message( "dropdown size: " + listDropdown.size() );

        listDropdown.stream().forEach( element -> {
            WebElement root2 = element.findElement( By.cssSelector( dropdownListRoot2CSS ) );
            WebElement dropdownElement = SMUtils.getWebElementDirect( driver, root2, dropdownElementRoot );
            //SMUtils.clickJS( driver, dropdownElement );
            String text = dropdownElement.getText().trim();
            dropdownValues.add( text );
        } );
        return dropdownValues;
    }

    /**
     * To Click select All option in Last Session Dropdown
     */
    public void clickSelectAll() {
        SMUtils.waitForElementToBeClickable( dropdownRoot1, driver );
        WebElement selectAll = SMUtils.getWebElementDirect( driver, dropdownRoot1, selectAllCSS );
        SMUtils.clickJS( driver, selectAll );
        Log.message( "Select all option clicked" );
    }

    /**
     * To click apply filter button in Skill Tested section
     */
    public void clickApplyFilter() {
        WebElement applyFilter = SMUtils.getWebElementDirect( driver, btnAapplyFilterRoot, btnApplyFilterCSS );
        SMUtils.clickJS( driver, applyFilter );
        Log.message( "Clicked Apply filter button" );
        SMUtils.waitForElement( driver, skillTestedHeader, 5 );
    }

    /**
     * It is used to checkBox in LastSession dropdown
     *
     * @param values in dropdonw to selected
     */
    public void clickCheckBoxinLastSessionDropdown( List<String> values ) {

        if ( isSkillTestedExpanded() ) {

            List<WebElement> listDropdown = SMUtils.getWebElementsDirect( driver, dropdownRoot1, dropdownListRoot1CSS );
            listDropdown.stream().forEach( element -> {
                WebElement root2 = element.findElement( By.cssSelector( dropdownListRoot2CSS ) );
                WebElement dropdownElement = SMUtils.getWebElementDirect( driver, root2, dropdownElementRoot );
                String text = dropdownElement.getText().trim();
                if ( values.contains( text ) ) {
                    SMUtils.scrollWebElementToView( driver, dropdownElement );
                    SMUtils.clickJS( driver, dropdownElement );
                    Log.message( "checked the value: " + text );
                }
            } );
        } else {
            Log.message( "Skill tested already expanded" );
        }
    }

    /**
     * to click the last session dropdown values
     */
    public void clickLastSession() {
        if ( !collapseLastSession() ) {
        	SMUtils.waitForElement(driver, dropdownLastSession, 30);
            SMUtils.scrollWebElementToView( driver, dropdownLastSession);
            WebElement root2 = SMUtils.getWebElement( driver, dropdownLastSession, grandtDropdownCSS );
            WebElement dropdownLastSession = SMUtils.getWebElementDirect( driver, root2, parentDropdownCSS );
            SMUtils.waitForElementToBeClickable( dropdownLastSession, driver );
            SMUtils.clickJS( driver, dropdownLastSession );
            Log.message( "Clicked Last Session dropdown" );
        }
    }

    public boolean collapseLastSession() {

        try {
        	SMUtils.waitForElement(driver, dropdownLastSession, 20);
            SMUtils.scrollWebElementToView( driver, dropdownLastSession );
            WebElement root2 = SMUtils.getWebElement( driver, dropdownLastSession, collapseIconCSS );
            WebElement dropdownLastSessionCollapse = SMUtils.getWebElementDirect( driver, root2, parentDropdownCSS );
            SMUtils.clickJS( driver, dropdownLastSessionCollapse );
            Log.message( "Collapsed last session drop down" );
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To get the Skill Tested Values
     *
     * @return
     */
    public HashMap<String, HashMap<String, String>> getSkillsTestedValues() {
        HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<>();
        List<String> skillsName = new ArrayList<>();
        List<String> skillsCorrect = new ArrayList<>();

        SMUtils.nap( 5 );
        Log.message( "No of Skill Tested is " + lastSessionSkillTestedNames.size() );
        // Adding skill Names
        if ( !lastSessionSkillTestedNames.isEmpty() ) {
            lastSessionSkillTestedNames.stream().forEach( skillName -> {
                String name = skillName.getText().trim();
                skillsName.add( name );
            } );

            // Adding skillCorrect Text
            skillsCorrectList.stream().forEach( skillCorrect -> {
                String name = skillCorrect.getText().trim();
                skillsCorrect.add( name );
            } );

            IntStream.range( 0, progressBarRoot.size() ).forEach( skillCount -> {
                WebElement parent = SMUtils.getWebElementDirect( driver, progressBarRoot.get( skillCount ), progressBarCSS );
                String barText = null;
                String barWidthArrtribute = null;
                HashMap<String, String> eachValues = new HashMap<>();
                try {
                    barText = parent.getText();
                    barWidthArrtribute = parent.getAttribute( "style" );
                } catch ( Exception NullPointerException ) {
                    parent = SMUtils.getWebElementDirect( driver, progressBarRoot.get( skillCount ), progressBarTextZeroCSS );
                    barWidthArrtribute = parent.getAttribute( "style" );
                    eachValues.put( SKILL_PERCENT_VALUE, parent.getText().trim() );
                    eachValues.put( BAR_WIDTH, barWidthArrtribute );
                }
                eachValues.put( SKILL_CORRECT, skillsCorrect.get( skillCount ) );
                eachValues.put( SKILL_PERCENT_VALUE, barText );
                eachValues.put( BAR_WIDTH, barWidthArrtribute );
                skillsTestedList.put( skillsName.get( skillCount ), eachValues );
            } );
        } else {
            Log.message( "The student has no skills tested" );
        }
        return skillsTestedList;
    }

    /**
     * verify zero state for Skill Tested return true if Skill Testesd Component
     * is zero state
     *
     * @return
     */
    public Boolean isZeroStatePresentforSkillTested() {
        return !SMUtils.verifyElementDoesNotExist( By.cssSelector( "div.skills-tested-graph-wrapper div.zero-state-content" ), driver );

    }

    /**
     * To get the Skills Name from the hashMap getSkillsTestedValues() method
     *
     * @param hashMap
     * @return Skill Name as ArrayList
     */
    public List<String> getSkillsListFromMap( HashMap<String, HashMap<String, String>> hashMap ) {
        List<String> KeyValues = new ArrayList<>();
        Set<String> keys = hashMap.keySet();
        keys.stream().forEach( key -> {
            KeyValues.add( key );
        } );

        return KeyValues;
    }

    /**
     * To get the Expected Dropdown values for the Last session dropdonw values
     * for the skill Tested component
     *
     * @return
     */
    public List<String> getExpectedDatesinLastSession() {
        LocalDateTime now1 = LocalDateTime.now( ZoneId.of( "UTC-7" ) );
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern( "MM/dd/yyyy" );
        LocalDateTime now = LocalDateTime.now();
        List<String> datesDropdown = new ArrayList<>();
        datesDropdown.add( "Last Session" );

        IntStream.range( 0, 14 ).forEach( dateCount -> {
            String date = dtf.format( now1.minusDays( dateCount ) );
            datesDropdown.add( date );
        } );

        return datesDropdown;
    }

    /**
     * Get IP Level and Gain for students in Assignment Details page
     *
     * @param firstName
     * @param middleName ( Give null if not available)
     * @param secondName
     * @return
     */
    public List<String> getStudentIPLevelandGain( String firstName, String middleName, String secondName ) {
        String tooltipText = null;
        if ( middleName == null ) {
            tooltipText = firstName + " " + secondName;
        } else {
            tooltipText = firstName + " " + middleName + " " + secondName;
        }
        SMUtils.waitForElement( driver, studentTable, 3 );
        List<String> studentIPandGain = new ArrayList<>();
        for ( WebElement tableRow : studentTableRow ) {
            String studentName = tableRow.findElements( By.cssSelector( childElementStudentNameAssignmentDetailsTable ) ).get( 0 ).getText().trim();
            if ( studentName.equals( tooltipText ) ) {

                studentIPandGain.add( tableRow.findElements( By.cssSelector( tableColumn ) ).get( 2 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.add( tableRow.findElements( By.cssSelector( tableColumn ) ).get( 5 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                Log.message( "Student IP Level is " + studentIPandGain.get( 0 ) );
                Log.message( "Student Gain is " + studentIPandGain.get( 1 ) );
                break;
            }
        }
        return studentIPandGain;

    }

    public Map<String, String> getStudentAssignmentDetailsPageIPLevelandGain( String firstName, String middleName, String secondName ) {
        String tooltipText = null;
        if ( middleName == null ) {
            tooltipText = firstName + " " + secondName;
        } else {
            tooltipText = firstName + " " + middleName + " " + secondName;
        }
        SMUtils.waitForElement( driver, studentTable, 3 );
        Map<String, String> studentIPandGain = new HashMap<>();
        for ( WebElement tableRow : studentTableRow ) {
            String studentName = tableRow.findElements( By.cssSelector( childElementStudentNameAssignmentDetailsTable ) ).get( 0 ).getText().trim();
            if ( studentName.equals( tooltipText ) ) {
                studentIPandGain.put( "IP Level", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 2 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "Assigned Level", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 3 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "Current Level", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 4 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "Gain", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 5 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "% Correct", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 6 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                break;
            }
        }
        return studentIPandGain;
    }

    /**
     * Click Back icon navigation from Assignment Details page
     *
     */
    public AssignmentsPage clickBackfromAssignmentDetails() {
        SMUtils.clickJS( driver, backIconNavigation );
        AssignmentsPage assignmentsPage = new AssignmentsPage( driver );
        return assignmentsPage;
    }

    /**
     * To click skill Name in last session skill tested
     *
     * @param skillName
     */
    public void clickSkillNameInSkillTested( String skillName ) {
        SMUtils.waitForElement( driver, skillTestedHeader );
        WebElement lblSkillName = skillNames.stream().filter( txtSkillName -> txtSkillName.getText().trim().equals( skillName ) ).findAny().orElse( null );
        if ( Objects.nonNull( lblSkillName ) ) {
            SMUtils.clickJS( driver, lblSkillName );
            Log.message( "Clicked skill name - " + lblSkillName.getText() );
        } else {
            Log.message( "Skill Name is not present under the respective student!" );
        }
    }

    /**
     * To verify header and buttons in skill tested popup
     *
     * @param assignmentType
     */
    public boolean verifySkillTestedPopupHeaderAndButtons( String assignmentType ) {
        SMUtils.waitForElement( driver, skillTestedPopupHeader, 30);
        try {
            //Verifying Header
            if ( assignmentType.equals( Constants.MATH ) ) {
                if ( skillTestedPopupHeader.getText().trim().equals( Constants.LastSessionSkillTested.MATH_SKILL_TESTED_POPUP_HEADER ) ) {
                    Log.message( "Skill Tested popup header displayed properly - " + Constants.LastSessionSkillTested.MATH_SKILL_TESTED_POPUP_HEADER );
                } else {
                    Log.message( "Skill Tested popup header not displayed properly! \n Expected : " + Constants.LastSessionSkillTested.MATH_SKILL_TESTED_POPUP_HEADER + "\n Actual : " + skillTestedPopupHeader.getText().trim() );
                    return false;
                }
            } else {
                if ( skillTestedPopupHeader.getText().trim().equals( Constants.LastSessionSkillTested.READING_SKILL_TESTED_POPUP_HEADER ) ) {
                    Log.message( "Skill Tested popup header displayed properly - " + Constants.LastSessionSkillTested.READING_SKILL_TESTED_POPUP_HEADER );
                } else {
                    Log.message( "Skill Tested popup header not displayed properly! \n Expected : " + Constants.LastSessionSkillTested.READING_SKILL_TESTED_POPUP_HEADER + "\n Actual : " + skillTestedPopupHeader.getText().trim() );
                    return false;
                }
            }

            //Verifying close icon
            if ( SMUtils.getWebElementDirect( driver, closeIconParentRoot, closeIconChild ).isDisplayed() ) {
                Log.message( "Close icon displayed in the skill tested popup!" );
            } else {
                Log.message( "Close icon is not displayed  properly in the skill tested popup" );
                return false;
            }

            //Verifying close button
            if ( SMUtils.getWebElementDirect( driver, closeBtnInSkillTestedPopup, closeButtonChild ).isDisplayed() ) {
                Log.message( "Close button displayed in the skill tested popup!" );
            } else {
                Log.message( "Close button is not displayed  properly in the skill tested popup" );
                return false;
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify values in skill tested popup
     *
     * @param skillDetails
     */
    public boolean verifySkillTestedPopupValues( Map<String, String> skillDetails ) {
        SMUtils.waitForElement( driver, skillTestedPopupHeader );
        try {
            //Verifying skill name in popup
            if ( lblSkillNameInPopup.getText().trim().equals( skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) ) ) {
                Log.message( "Skill Name displayed properly in the skill tested popup! - " + skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) );
            } else {
                Log.message( "Skill Name not displayed properly in the skill tested popup! - \n Expected : " + skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) + "\n Actual : " + lblSkillNameInPopup.getText().trim() );
                return false;
            }

            //Verifying skill description in popup
            if ( txtSkillDescription.getText().replaceAll( "[^a-zA-Z0-9]", "" ).trim().equals( skillDetails.get( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ).replaceAll( "[^a-zA-Z0-9]", "" ) ) ) {
                Log.message( "Skill description displayed properly in the skill tested popup! - " + skillDetails.get( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
            } else {
                Log.message( "Skill description not displayed properly in the skill tested popup! - \n Expected : " + skillDetails.get( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) + "\n Actual : " + txtSkillDescription.getText().trim() );
                return false;
            }

            //Verifying LO/SCO in popup
            if ( catalogNumber.getText().trim().equals( skillDetails.get( Constants.LastSessionSkillTested.CATALOG_NUMBER ) ) ) {
                Log.message( "LO/SCO displayed properly in the skill tested popup! - " + Constants.LastSessionSkillTested.CATALOG_NUMBER );
            } else {
                Log.message( " LO/SCO not displayed properly in the skill tested popup! - \n Expected : " + skillDetails.get( Constants.LastSessionSkillTested.CATALOG_NUMBER ) + "\n Actual : " + catalogNumber.getText().trim() );
                return false;
            }

            //Verifying no.of questions correct and attempted in popup
            if ( countOFCorrectAandAttemptedInPopup.getText().trim().equals( skillDetails.get( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) + " / " + skillDetails.get( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) + " correct" ) ) {
                Log.message( "Count of correct and attempted questions are displayed properly in the skill tested popup! - " + countOFCorrectAandAttemptedInPopup.getText().trim() );
            } else {
                Log.message( "Count of correct and attempted questions are not displayed properly in the skill tested popup! - \n Expected : " + skillDetails.get( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) + " / "
                        + skillDetails.get( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) + " correct\n Actual : " + countOFCorrectAandAttemptedInPopup.getText().trim() );
                return false;
            }

            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To click LO/SCO
     *
     */
    public void clickLOInSkillTestedPopup() {
        SMUtils.clickJS( driver, catalogNumber );
        Log.message( "Clicked LO/SCO From skill tested popup!" );
    }

    public boolean isSkillTestedExpanded() {
        boolean isExpanded = false;
        try {
            SMUtils.waitForElement( driver, assignBtnAssignmentlistRoot );
            if ( iconCollapseSkillTested.isDisplayed() )
                isExpanded = true;
        } catch ( NoSuchElementException | StaleElementReferenceException e ) {
            isExpanded = false;
        }
        return isExpanded;

    }

    public void collapseSkillTested() throws Exception {
        try {
            if ( isSkillTestedExpanded() ) {
                SMUtils.click( driver, iconCollapseSkillTested );
            } else {
                Log.message( "Skill tested already closed!" );
            }
        } catch ( Exception e ) {
            Log.exception( e );
        }
    }

    public String getSkillTestedHeader() {
        SMUtils.waitForElement( driver, skillTestedHeader );
        SMUtils.scrollIntoView( driver, skillTestedHeader );
        return SMUtils.getTextOfWebElement( skillTestedHeader, driver );
    }

    public boolean isSkillNameLinkDisplayed( String skillName ) {

        String linkText = skillLink.stream().filter( lbllegend -> lbllegend.getText().trim().equals( skillName ) ).map( WebElement::getText ).findAny().orElse( null );
        if ( Objects.nonNull( linkText ) ) {
            return true;
        }
        return false;
    }

    /**
     * To get Group list from Assignment details table
     *
     * @return
     */
    public List<String> getGroupListfromAssignementDetailsTable() {
        //This nap is required for the Group list to load
        SMUtils.nap( 5 );
        List<String> assignementDetailsTableGroupList = new ArrayList<>();
        groupNameListFromAssignPopup.stream().forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( assignementDetailsTableGroupList::add ) );
        Collections.sort( assignementDetailsTableGroupList );
        assignementDetailsTableGroupList.stream().forEach( studentName -> Log.message( "Student in assigned the assignment " + studentName ) );
        return assignementDetailsTableGroupList;
    }

    /**
     * To Click cancel on popup for Resume assignment for Student Tab
     */
    public void resumeAssignmentForStudentcancelButton() {
        SMUtils.waitForElement( driver, pauseAssignmentForStudentCancelbtn );
        WebElement pauseAssignmentCancel = SMUtils.getWebElement( driver, pauseAssignmentForStudentCancelbtn, pauseAssignmentForStudentCancelChild );
        SMUtils.clickJS( driver, pauseAssignmentCancel );
        Log.message( "Clicked Cancel button for resume assignments for student" );
    }

    /**
     * Gets Assigned To-ToggleButton of Assignment Details Page
     */
    public String getAssignedToToggleButton() {
        WebElement actualAssignedToElement = SMUtils.getWebElementDirect( driver, assignedToAndMasteryBtnRoot, assignedToToggleButton );
        return actualAssignedToElement.getText();
    }

    /**
     * Gets Mastery-ToggleButton of Assignment Details Page
     */
    public String getMasteryToggleButton() {
        WebElement actualMasteryElement = SMUtils.getWebElementDirect( driver, assignedToAndMasteryBtnRoot, masteryToggleButton );
        return actualMasteryElement.getText();
    }

    /**
     * Add students to Assignment
     */
    public void addAssignmentToStudents() {
        // SMUtils.waitForElement( driver, studentRadioBtn );
        //SMUtils.clickJS( driver, studentRadioBtn );
        selectRadioButton( "Students" );
        SMUtils.waitForElement( driver, addBtnRoot );
        List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );
        addBtns.forEach( elements -> {
            WebElement addBtn = SMUtils.getWebElementDirect( driver, elements, btnSecondary );
            SMUtils.clickJS( driver, addBtn );
        } );
        WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignBtnRoot, btnPrimary );
        SMUtils.clickJS( driver, assignPopUpBtn );
        Log.message( "Students are added to Assignment" );
    }
    
    public void ellipseCheck() {
    	List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );
    	addBtns.forEach( elements -> {
            WebElement addBtn = SMUtils.getWebElementDirect( driver, elements, btnSecondary );
            SMUtils.clickJS( driver, addBtn );
        } );
    }

    /**
     * To Get FluencyFiles option at student level
     *
     * @return
     */
    public String fluencyFilesInEllipsis() {
        SMUtils.waitForElement( driver, fluencyFilesGrandRoot );
        WebElement fluencyFiles = SMUtils.getWebElementDirect( driver, fluencyFilesGrandRoot, fluencyFilesParent, fluencyFileschild );
        Log.message( "Fluency Files option is displayed in Ellipsis" );
        return SMUtils.getTextOfWebElement( fluencyFiles, driver );
    }

    /**
     * Clicks the remove student option from ellipsis of the given student
     *
     * @return
     * @throws InterruptedException
     */
    public void removeStudentFromAssignment( String studentNameToSelect ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 30 );
        SMUtils.waitForLocator( driver, By.cssSelector( studentEllipsisRootCSS ), 20 );
        PageFactory.initElements( driver, this );
        for ( WebElement student : availableStudents ) {
            WebElement studentNameElement = SMUtils.getChildWebElementFromParent( student, studentNameCSS );
            String studentFullName = studentNameElement.getText();
            // remove middle name from student name
            String studentName = studentNameWithFirstAndLastName( studentFullName );

            if ( studentName.equals( studentNameToSelect ) ) {
                // click the ellipsis of the respective student
                WebElement studentEllipsisRootElement = SMUtils.getChildWebElementFromParent( student, studentEllipsisRootCSS );
                WebElement studentEllipsisElement = SMUtils.getWebElementDirect( driver, studentEllipsisRootElement, studentEllipsisCSS );
                try {
                    SMUtils.scrollWebElementToView( driver, studentEllipsisElement );
                    studentEllipsisElement.click();
                } catch ( ElementNotInteractableException e ) {
                    SMUtils.clickJS( driver, studentEllipsisElement );
                }

                // Get Ellipsis options
                WebElement studentEllipsisDropdownOptionsChildRootElement = SMUtils.getWebElementDirect( driver, studentEllipsisRootElement, studentEllipsisDropdownOptionsChildRootCSS );

                // Get Ellipsis->Assignment Settings option and click
                WebElement studentEllipsisDropdownOptionsRemoveStudentElement = SMUtils.getWebElementDirect( driver, studentEllipsisDropdownOptionsChildRootElement, studentEllipsisDropdownOptionsRemoveStudentCSS );
                try {
                	SMUtils.waitForElement(driver, studentEllipsisDropdownOptionsRemoveStudentElement, 20);
                	SMUtils.clickJS(driver, studentEllipsisDropdownOptionsRemoveStudentElement);
                } catch ( ElementNotInteractableException e ) {
                    SMUtils.clickJS( driver, studentEllipsisDropdownOptionsRemoveStudentElement );
                }

                //remove the student from remove popup
                removeStudent();
                break;
            }
        }
        // should return assignment settings popup component
    }

    /**
     * Getting student name with First and Last name
     *
     * @param studentName
     * @return studentNameWithFirstAndLastName
     */
    public String studentNameWithFirstAndLastName( String studentName ) {
        String[] studentFullName = studentName.split( " " );
        String studentNameWithFirstAndLastName = "";
        if ( studentFullName.length > 2 ) {
            studentNameWithFirstAndLastName = studentFullName[0] + " " + studentFullName[2];
        } else {
            studentNameWithFirstAndLastName = studentName;
        }
        return studentNameWithFirstAndLastName;
    }

    /**
     * Assignment Availability
     */
    public boolean AssignmentDeleted() {
        SMUtils.waitForElement( driver, assignmentAvailability, 5 );
        return assignmentAvailability.isDisplayed();
    }

    /**
     * Get Student FN and LN list from assignment details page
     *
     * @return
     */
    public List<String> getStudentFNLNListfromAssignementDetails() {
        SMUtils.waitForElement( driver, isStudentDisplayedElement );
        List<String> assignementDetailsPageStudentList = new ArrayList<>();
        studentNameViewAssignmentTable.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( elementText -> {
            SMUtils.waitForElementToBeClickable( element, driver );
            String name = element.getText().trim();
            String[] fullName = name.split( "\\s+" );
            if ( fullName.length == 3 ) {
                assignementDetailsPageStudentList.add( fullName[0] + " " + fullName[2] );
            } else {
                assignementDetailsPageStudentList.add( name );
            }
        } ) );
        return assignementDetailsPageStudentList;
    }

    /**
     * This method is to click student/group radio button
     *
     * @param radioBtnToClick
     */
    public void selectRadioButton( String radioBtnToClick ) {
        SMUtils.waitForLocator( driver, By.cssSelector( assignRadiobutton ), 5 );
        try {
            radioButton.forEach(
                    element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( assignlabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( radioBtnToClick ) ).ifPresent( elementFinalText -> {
                        if ( elementFinalText.equalsIgnoreCase( radioBtnToClick ) ) {
                            SMUtils.clickJS( driver, element.findElement( By.cssSelector( assignlabel ) ) );
                        }
                    } ) );
        } catch ( Exception e ) {
            Log.message( "Hidden row detected." );
        }
    }

    /**
     * To verify mastery zero state
     *
     * @param groupName
     * @return
     */
    public boolean verifyMasteryZeroState() {
        SMUtils.waitForElement( driver, masteryZeroState );
        String zeroStateFromUI = masteryZeroState.getText().trim();
        if ( zeroStateFromUI.contains( Constants.MasteryUI.MASTERY_ZERO_STATE_MESSAGE.get( 0 ) ) && zeroStateFromUI.contains( Constants.MasteryUI.MASTERY_ZERO_STATE_MESSAGE.get( 1 ) ) ) {
            Log.pass( "Zero state message is displayed successfully!" );
            return true;
        } else {
            Log.fail( "Zero state message is not displayed successfully!" );
            return false;
        }
    }

    /**
     * To click Mastery-ToggleButton of Assignment Details Page
     *
     * @throws InterruptedException
     */
    public void clickMasteryToggleButton() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, assignedToAndMasteryBtnRoot );
        SMUtils.getWebElementDirect( driver, assignedToAndMasteryBtnRoot, masteryToggleButton ).click();
        Log.message( "Mastery toggle button is clicked" );
    }
    
    /**
     * To Verify the presence of the mastery strand
     *
     * @throws InterruptedException
     */
    public boolean verifyMasteryStrand() throws InterruptedException {
        boolean status = false;
    	SMUtils.waitForElement( driver, strandName );
            if ( strandName.isDisplayed() ){
               status = true;
               }
        return status;
    }
    
    /**
     * To Verify the presence of the LO Arrow
     *
     * @throws InterruptedException
     */
    public boolean verifyArrow() throws InterruptedException {
        boolean status = false;
    	SMUtils.waitForElement( driver, LOArrow );
            if ( LOArrow.isDisplayed() ){
                status = true;
                }
        return status;
    }
    
    /**
     * Navigate to LO View page by clicking given LO link
     * 
     * @param loLink
     */
    public boolean navigateToLoViewPage () {
    	//define LO arrow with shadow dom utils
    	Boolean flag = false;
    	SMUtils.scrollWebElementToView( driver, LOArrow, SMUtils.SCROLL_TO_MIDDLE );
    	SMUtils.nap(3);
        SMUtils.click( driver, LOArrow );
        Log.message("Clicking on LO Arrow");
            if(LODetailsCard.isDisplayed()){
        		    Log.message("Mastery Details card has loaded");
        		    flag = true;
            }else {
        	    Log.message("Mastery Details card has not loaded");
            }

        return flag;
    }
    
    /**
     * Verify Strand Name of LO View Page
     * 
     * @param loLink
     */
    public boolean verifyStrand () {
    	
    	Boolean flag = false;
    	    if(strandTitle.isDisplayed()){
    		    Log.message("Strand has loaded");
    		    flag = true;
        }else {
    	    Log.message("Strand has not loaded");
        }

    return flag;

    }
    
    /**
     * Verify Standard Name of LO View Page
     * 
     * @param loLink
     */
    public boolean verifyStandard () {
    	
    	Boolean flag = false;
    	    if(standardTitle.isDisplayed()){
    		    Log.message("Standard title has loaded");
    		    flag = true;
        }else {
    	    Log.message("Standard title has not loaded");
        }

    return flag;

    }
    
    /**
     * Verify Progress bar of LO View Page
     * 
     * @param loLink
     */
    public boolean verifyProgressBar () {
    	
    	Boolean flag = false;
    	    if(progressBar.isDisplayed()){
    		    Log.message("Progress bar has loaded");
    		    flag = true;
        }else {
    	    Log.message("Progress bar has not loaded");
        }

    return flag;

    }
    
    /**
     * Verify Student Name Column of LO View Page
     * 
     * @param loLink
     */
    public boolean verifyStudentNameColumn () {
    	
    	Boolean flag = false;
    	    if(studentNameCol.isDisplayed()){
    		    Log.message("Student Name Column has loaded");
    		    flag = true;
        }else {
    	    Log.message("Student Name Column has not loaded");
        }

    return flag;

    }
    
    /**
     * Verify Mastery Status Column of LO View Page
     * 
     * @param loLink
     */
    public boolean verifyMasteryStatusColumn () {
    	
    	Boolean flag = false;
    	    if(studentMasteryStatusCol.isDisplayed()){
    		    Log.message("Mastery Status Column has loaded");
    		    flag = true;
        }else {
    	    Log.message("Mastery Status Column has not loaded");
        }

    return flag;

    }
    
    /**
     * Verify Skills Column of LO View Page
     * 
     * @param loLink
     */
    public boolean verifySkillsColumn () {
    	
    	Boolean flag = false;
    	    if(studentSkillsEvaluatedCol.isDisplayed()){
    		    Log.message("Skills Column has loaded");
    		    flag = true;
        }else {
    	    Log.message("Skills Column has not loaded");
        }

    return flag;

    }
    
    /**
     * Verify Student Attempts Column of LO View Page
     * 
     * @param loLink
     */
    public boolean verifyStudentAttemptsColumn () {
    	
    	Boolean flag = false;
    	    if(studentAttemptsCol.isDisplayed()){
    		    Log.message("Student Attempts Column has loaded");
    		    flag = true;
        }else {
    	    Log.message("Student Attempts Column has not loaded");
        }

    return flag;

    }
    
    
    
    /**
     * To click LO number in Skills tested popup
     * 
     * @return
     */
    public String getLONumberfromUrl() {
        SMUtils.waitForElement( driver, LOArrow );
        SMUtils.clickJS( driver, LOArrow );
        Log.message( "LO number clicked Successfully" );
        String currentWindow = driver.getWindowHandle();
        Set<String> windowHandles = driver.getWindowHandles();
        List<String> windowList = new ArrayList<>( windowHandles );
        driver.switchTo().window( windowList.get( 1 ) );
        String lourl = driver.getCurrentUrl();
        Log.message( lourl );
        return lourl;
    }
    

    /**
     * To select give student fluency file
     *
     * @param studentFNMNLN
     * @param click
     * @return
     */
    public String fluencyFilesInEllipsisFromStudent( String studentFNMNLN, boolean click ) {
        SMUtils.waitForElement( driver, fluencyFilesGrandRoot );
        AtomicReference<String> fluencyCount = new AtomicReference<>();
        SMUtils.waitForLocator( driver, By.cssSelector( studentEllipsisRootCSS ), 5 );
        availableStudents.stream().forEach( element -> Optional.ofNullable( SMUtils.getChildWebElementFromParent( element, studentNameCSS ).getText().trim() ).ifPresent( elementText -> {
            if ( elementText.equals( studentFNMNLN ) ) {
                // Click the ellipsis of the respective student
                WebElement studentEllipsisRootElement = SMUtils.getChildWebElementFromParent( element, studentEllipsisRootCSS );
                WebElement studentEllipsisElement = SMUtils.getWebElement( driver, studentEllipsisRootElement, studentEllipsisCSS );
                try {
                    SMUtils.scrollWebElementToView( driver, studentEllipsisElement );
                    SMUtils.click( driver, studentEllipsisElement );
                    WebElement fluencyFileCountUI = SMUtils.getWebElementDirect( driver, studentEllipsisRootElement, fluencyFilesParent, fluencyFileschild );

                    if ( click ) {
                        SMUtils.click( driver, fluencyFileCountUI );
                        SMUtils.waitForElement( driver, fluencyFilesPopupHeader, 5 );
                        Log.message( "Fluency file popup loaded" );
                    } else {
                        fluencyCount.set( SMUtils.getTextOfWebElement( fluencyFileCountUI, driver ) );
                    }
                } catch ( ElementNotInteractableException e ) {
                    Log.message( "Hidden element detected" );
                }
            }
        } ) );
        Log.message( "Fluency Files option is displayed in Ellipsis" );
        return fluencyCount.get();
    }

    /**
     * To download the fluency file clicking the download button and handling
     * windows
     *
     * @param browser
     */
    public void clickDownloadFluency( String browser ) {
        if ( checkDownloadBtnEnabled() ) {
            WebElement download = SMUtils.getWebElement( driver, DownloadBtnRootFluencyPopup, assignmentSaveBtnChild );

            SMUtils.click( driver, download );
            if ( browser.contains( "Safari" ) ) {
                //Workaround for safari window handling
                SMUtils.nap( 10 );
                Actions action = new Actions( driver );
                action.keyDown( Keys.CONTROL ).sendKeys( "1" ).keyUp( Keys.CONTROL ).perform();
                Log.message( "Safari window switched." );
                SMUtils.nap( 2 );
            }

            Log.message( "Download button clicked", driver );
        } else {
            Log.message( "Download is not enabled" );
        }
    }

    /**
     * To check the download button is enabled
     *
     * @return true / false
     */
    public boolean checkDownloadBtnEnabled() {
        WebElement download = SMUtils.getWebElement( driver, DownloadBtnRootFluencyPopup, assignmentSaveBtnChild );
        return download.isEnabled();
    }

    /**
     * Clicking the delete fluency button
     */
    public void clickDeleteFluency() {
        if ( checkDeleteBtnEnabled() ) {
            WebElement delete = SMUtils.getWebElement( driver, deleteBtnRootFluencyPopup, assignmentCancelBtn );
            SMUtils.click( driver, delete );
            Log.message( "Delete button clicked" );
        } else {
            Log.message( "Delete is not enabled" );
        }
    }

    /**
     * Checking delete button enabled
     *
     * @return
     */
    public boolean checkDeleteBtnEnabled() {
        WebElement delete = SMUtils.getWebElement( driver, deleteBtnRootFluencyPopup, assignmentCancelBtn );
        return delete.isEnabled();
    }

    /**
     * Clicking cancel button
     */
    public void clickCancelButtonFluency() {
        WebElement cancel = SMUtils.getWebElement( driver, cancelBtnRootFluencyPopup, assignmentCancelBtn );
        SMUtils.click( driver, cancel );
        Log.message( "Cancel button clicked" );

    }

    /**
     * To select the file using file name
     *
     * @param fileName
     */
    public void selectFluencyFileByName( String fileName ) {
        SMUtils.waitForElement( driver, fluencyFilesPopupHeader, 5 );
        SMUtils.waitForElement( driver, selectAllCheckBoxRoot, 5 );
        WebElement fluencyRow = FluencyFileTableRows.stream().filter( element -> element.getText().trim().contains( fileName ) ).findFirst().get();
        String[] fileNameUI = fluencyRow.getText().trim().split( " " );
        if ( fileNameUI[0].equalsIgnoreCase( fileName ) ) {
            try {
                WebElement CheckBoxRoot = fluencyRow.findElement( By.cssSelector( chBXRootForFluency ) );
                WebElement CheckBox = SMUtils.getWebElement( driver, CheckBoxRoot, fluencyFileSelectAllBtnChild );
                SMUtils.click( driver, CheckBox );
                Log.message( "Fluency file selected - " + fileName );
            } catch ( ElementNotInteractableException e ) {
                Log.message( "Element not found" );
            }
        }

    }

    /**
     * Verifying fluency file exist
     *
     * @param fileName
     * @return
     */
    public boolean isFluencyFileExist( String fileName ) {
        boolean isExist = false;
        try {
            SMUtils.waitForElement( driver, fluencyFilesPopupHeader, 5 );
            SMUtils.waitForElement( driver, selectAllCheckBoxRoot, 5 );
            isExist = FluencyFileTableRows.stream().filter( element -> element.getText().trim().contains( fileName ) ).findFirst().isPresent();
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isExist;
    }

    /**
     * to get all the fluency files
     *
     * @return
     */
    public List<String> getAllFluencyFiles() {
        List<String> files = new ArrayList<>();
        SMUtils.waitForElement( driver, fluencyFilesPopupHeader, 5 );
        SMUtils.waitForElement( driver, selectAllCheckBoxRoot, 5 );
        try {
            SMUtils.waitForElement( driver, fluencyFilesPopupHeader, 5 );
            SMUtils.waitForElement( driver, selectAllCheckBoxRoot, 5 );
            List<String> fileProperties = new ArrayList<>();
            FluencyFileTableRows.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( fileProperties::add ) );

            fileProperties.forEach( file -> {
                String[] fileName = file.split( " " );
                files.add( fileName[0] );
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return files;
    }

    /**
     * Select all the fluency files
     */
    public void selectAllFluencyFiles() {
        SMUtils.waitForElement( driver, selectAllCheckBoxRoot, 5 );
        WebElement element = SMUtils.getWebElement( driver, selectAllCheckBoxRoot, fluencyFileSelectAllBtnChild );
        SMUtils.click( driver, element );
        Log.message( "Select all check box clicked" );
    }

    /**
     * Get fluency popup header
     *
     * @return
     */
    public String getFluencyFilePopupHeader() {
        SMUtils.waitForElement( driver, fluencyFilesPopupHeader );
        return SMUtils.getTextOfWebElement( fluencyFilesPopupHeader, driver );
    }

    /**
     * Clicking buttons based on name from delete fluency popup
     *
     * @param buttonName
     */
    public void clickButtonsFromPopup( String buttonName ) {
        try {
            SMUtils.waitForElement( driver, deletePopupContent, 5 );
            Log.message( "Delete fluency popup loaded!" );
            WebElement button = fluencyFileDeletePopupButtonsRoot.stream().filter( element -> element.getText().trim().equalsIgnoreCase( buttonName ) ).findFirst().get();
            WebElement buttontoClick;
            if ( buttonName.equalsIgnoreCase( Constants.DELETE ) ) {
                buttontoClick = SMUtils.getWebElement( driver, button, assignmentSaveBtnChild );
                SMUtils.waitForElement( driver, deleteFluencyToastMessage );
                SMUtils.checkBackgroundColor( buttontoClick, Constants.BUTTON_COLOR_CODE );
                Log.message( "Background color for delete button is displayed as " + Constants.BUTTON_COLOR_CODE, "Background color for delete button is not displayed as " + Constants.BUTTON_COLOR_CODE );
            } else {
                buttontoClick = SMUtils.getWebElement( driver, button, assignmentCancelBtn );
            }
            SMUtils.click( driver, buttontoClick );
            Log.message( buttonName + "Button Clicked." );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * getting toast message of fluency
     *
     * @return
     */
    public String getToastMessageForDeleteFluency() {
        return SMUtils.getTextOfWebElement( deleteFluencyToastMessage, driver );
    }

    /**
     * Verifying the toast message.
     */
    public void verifyToastMessage() {
        SMUtils.waitForElement( driver, deleteFluencyToastMessage );
        if ( deleteFluencyToastMessage.getText().trim().equalsIgnoreCase( Constants.TOAST_MESSAGE ) ) {
            Log.pass( "Toast message displayed properly" );
        } else {
            Log.fail( "Toast message not displayed" );
        }
    }

    /**
     * Verifying the zero state of fluency files
     */
    public void verifyZeroStateFluencyFile() {
        SMUtils.waitForElement( driver, zeroStateFluencyFile, 5 );
        if ( Constants.ZERO_STATE_FLUENCY.equalsIgnoreCase( getZeroStateMessageFluency() ) ) {
            Log.pass( "Zero state displayed properly!" );
        } else {
            Log.fail( "Zero state message not displayed" );
        }
    }

    /**
     * getting zero state message
     *
     * @return
     */
    public String getZeroStateMessageFluency() {
        SMUtils.waitForElement( driver, zeroStateFluencyFile, 5 );
        return SMUtils.getTextOfWebElement( zeroStateFluencyFile, driver );
    }

    /**
     *
     * To Click assign button for home page
     */
    public void clickAssignButtonhome() {
        SMUtils.waitForElement( driver, assignButton );
        WebElement assignButtonhome = SMUtils.getWebElement( driver, assignButton, assignBtnChild );
        SMUtils.clickJS( driver, assignButtonhome );
        Log.message( "Clicked Assign button in home page" );
    }

    /**
     * List of session Length
     *
     * @return
     */
    public List<String> getListOfSessionLength( String headervalue ) {
        SMUtils.nap( 1 );//edit Page will take time, this wait is required
        sessionLengthDropdown.forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( headervalue ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                SMUtils.click( driver, parentElement.findElement( By.cssSelector( sessionLengthButton ) ) );
            }
        } );
        Log.message( "List Of dropdown values inside Session Length filter" );
        return listOfSessionLength.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * List Limit Progress Value
     *
     * @return
     */
    public List<String> getListOfLimitProgress() {
        SMUtils.nap( 1 );//edit Page will take time, this wait is required
        SMUtils.waitForElement( driver, limitProgressDropdown );
        SMUtils.clickJS( driver, limitProgressDropdown );
        Log.message( "List of dropdown values inside limit progress filter" );
        return limitProgressList.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     *
     */
    public String isElementDisplaOnEditPage( String speedgameQuestionField ) {
        headerList.forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( speedgameQuestionField ) ) {
                Log.message( "Speed Game Question is displaying on edit assignments page" );
            }

        } );
        return speedgameQuestionField;
    }

    /**
     *
     * List Of Speed Game
     *
     * @return
     */
    public List<String> getListOfSpeedgame() {
        SMUtils.nap( 2 );//edit Page will take time, this wait is required
        speedGameTimeDropdown.forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( "Speed Games Time per Question" ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                SMUtils.clickJS( driver, parentElement.findElement( By.cssSelector( sessionLengthButton ) ) );
            }
        } );
        Log.message( "List of all Speed games per question values inside speed game per question filter" );
        return listOfSpeedGames.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     *
     * List Of Speed Game total times
     *
     * @return
     */
    public List<String> getListOfSpeedgameTotaltime() {
        SMUtils.nap( 2 );//edit Page will take time, this wait is required
        speedGameTimeDropdown.forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( "Speed Games Total Time" ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                SMUtils.clickJS( driver, parentElement.findElement( By.cssSelector( sessionLengthButton ) ) );
            }
        } );
        Log.message( "List of all Speed game Question time value inside the speed game total time filter" );
        return listOfSpeedGames.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     *
     * Return Set course level , IP status on edit assignment page
     *
     * @param value
     * @return
     */
    public String getValueOfIPSetCourseLevel( String value ) {
        SMUtils.nap( 2 );//edit Page will take time, this wait is required
        Log.message( "Returing the Status of " + value );
        return headingLabel.stream().filter( element -> element.getText().trim().equalsIgnoreCase( value ) ).map( element -> {
            WebElement parentElement = element.findElement( By.xpath( "./.." ) );
            return parentElement.findElement( By.cssSelector( settingValue ) ).getText().trim();
        } ).findFirst().orElse( null );
    }

    /***
     * Get column names from Assignment Details page
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getNamesFromAssignmentDetailsPage() throws Exception {

        // get column names
        List<String> columnNames = columnNamesList.stream().map( value -> value.getText().trim() ).collect( Collectors.toList() );
        Log.message( "Got all column names from Assignment Details Page" );
        return columnNames;
    }

    /***
     * Check Legend names in Progress Monitoring Graph
     *
     * @return boolean
     */
    public boolean checkLegendNames( String legendName ) {

        boolean result = legendNames.stream().map( value -> value.getText().trim() ).anyMatch( s -> s.contains( legendName ) );
        Log.message( "Got Expected Result" );
        return result;
    }

    /**
     * To add Assignment to students
     */
    public void assignAssignmentToStudents() {
        SMUtils.waitForElement( driver, studentRadioButton, 10 );
        SMUtils.clickJS( driver, studentRadioButton );
        SMUtils.waitForElement( driver, addBtnRoot );
        List<WebElement> addBtns = driver.findElements( By.cssSelector( addButtonRoot ) );
        addBtns.forEach( element -> {
            WebElement addBtn = SMUtils.getWebElementDirect( driver, element, btnSecondary );
            SMUtils.clickJS( driver, addBtn );
        } );
        WebElement assignPopUpBtn = SMUtils.getWebElementDirect( driver, assignPopupAssignBtnRoot, btnPrimary );
        SMUtils.waitForElement( driver, assignPopUpBtn );
        SMUtils.clickJS( driver, assignPopUpBtn );
        Log.message( "Assignment added to Students" );
    }

    /**
     * To Get Assignment Setting Tab on assignments Listing
     */
    public String assignmenttSettingTabTopEllipsis() {
        SMUtils.waitForElement( driver, assignmentSettingForAllGrandRoot, 30 );
     //   WebElement allAssignmentSettingParent = SMUtils.getWebElement( driver, assignmentSettingForAllGrandRoot, assignmentSettingForAllParent );
      //  WebElement allAssignmentSetting = SMUtils.getWebElement( driver, allAssignmentSettingParent, assignmentSettingChild );
    //    return allAssignmentSetting.getText();
    	 WebElement webElementDirect = SMUtils.getWebElementDirect(driver, assignmentSettingForAllGrandRoot, assignmentSettingForAllParent);
    	 WebElement webElementDirect2 = SMUtils.getWebElementDirect(driver, webElementDirect, assignmentSettingChild);
    	 return webElementDirect2.getText();
    }

    /**
     * To Get the name of first student in assignment details page
     */
    public String getFirstStudentsName() {
        SMUtils.waitForElement( driver, firstStudentName, 10 );
        return firstStudentName.getText();
    }

    /**
     * Clicks the ellipsis of the given student
     *
     * @return
     */
    public void clickEllipsesOfStudent( String studentNameToSelect ) {
        SMUtils.nap( 1 );
        for ( WebElement student : availableStudents ) {
            WebElement studentNameElement = SMUtils.getChildWebElementFromParent( student, studentNameCSS );
            String studentFullName = studentNameElement.getText();
            // remove middle name from student name
            studentNameWithFirstAndLastName( studentFullName );
            if ( studentNameWithFirstAndLastName( studentFullName ).equals( studentNameToSelect ) ) {
                // click the ellipsis of the respective student
                WebElement studentEllipsisRootElement = SMUtils.getChildWebElementFromParent( student, studentEllipsisRootCSS );
                WebElement studentEllipsisElement = SMUtils.getWebElement( driver, studentEllipsisRootElement, studentEllipsisCSS );
                try {
                    SMUtils.waitForElement( driver, studentEllipsisElement, 10 );
                    SMUtils.scrollWebElementToView( driver, studentEllipsisElement );
                    studentEllipsisElement.click();
                } catch ( ElementNotInteractableException e ) {
                    SMUtils.clickJS( driver, studentEllipsisElement );
                }
            }
        }
    }

    /**
     * To click Assignment Setting student Tab on assignments Listing
     */
    public void assignmentSettingStudentTab() {
        SMUtils.waitForElement( driver, assignmentSettingsForStudentGrandRoot );
        WebElement assignmentSettingsStudentParent = SMUtils.getWebElement( driver, assignmentSettingsForStudentGrandRoot, assigmnentSettingParent );
        WebElement assignmentSettingsStudent = SMUtils.getWebElement( driver, assignmentSettingsStudentParent, assigmnentSettingchild );
        Log.message( assignmentSettingsStudent.getText() );
        SMUtils.clickJS( driver, assignmentSettingsStudent );
        Log.message( "Clicked Assignment Settings student tab" );
    }

    /**
     * To get title of Edit Assignments popup
     */
    public String getEditSettingsPopupTitle() {
        SMUtils.waitForElement( driver, assignmentEditPopup, 40 );
        return assignmentEditPopup.getText().trim();
    }

    /**
     * To click Pause student Tab on assignments Listing
     */

    public void pauseAssignmentStudentTab() {
        SMUtils.waitForElement( driver, pauseAssignmentForStudentGrandRoot );
        WebElement pauseStudentParent = SMUtils.getWebElement( driver, pauseAssignmentForStudentGrandRoot, resumeAssignmentForStudentParent );
        WebElement pauseStudent = SMUtils.getWebElement( driver, pauseStudentParent, pauseAssignmentStudentChild );
        Log.message( pauseStudent.getText() );
        SMUtils.clickJS( driver, pauseStudent );
        Log.message( "Clicked Pause student tab" );

    }

    /**
     * To click Fluency Tab on assignments Listing
     */

    public void fluencyFilesStudentTab() {
        SMUtils.waitForElement( driver, pauseAssignmentForStudentGrandRoot );
        WebElement fluencyFileParent = SMUtils.getWebElement( driver, pauseAssignmentForStudentGrandRoot, resumeAssignmentForStudentParent );
        WebElement fluencyFileStudent = SMUtils.getWebElement( driver, fluencyFileParent, fluencyFilesForStudentChild );
        Log.message( fluencyFileStudent.getText() );
        SMUtils.clickJS( driver, fluencyFileStudent );
        Log.message( "Clicked Fluency File student tab" );

    }

    /**
     * To click Resume student Tab on assignments Listing
     */

    public void resumeAssignmentStudentTab() {
        SMUtils.waitForElement( driver, resumeAssignmentForStudentGrandRoot );
        WebElement resumeStudentParent = SMUtils.getWebElement( driver, resumeAssignmentForStudentGrandRoot, resumeAssignmentForStudentParent );
        WebElement resumeStudent = SMUtils.getWebElement( driver, resumeStudentParent, resumeAssignmentForStudentChild );
        SMUtils.clickJS( driver, resumeStudent );
        Log.message( "Clicked Resume student tab" );

    }

    /**
     * To check display of Fluency file for student popup
     */
    public boolean isFluencyPopUpDisplayed() {
        SMUtils.waitForElement( driver, fluencyPopup, 10 );
        driver.switchTo().activeElement();
        return SMUtils.isElementPresent( fluencyPopup );

    }

    /**
     * To check display of Pause Assignment for student popup
     */
    public boolean isPauseStudentPopUpDisplayed() {
        SMUtils.waitForElement( driver, studentPopupModalPopup, 10 );
        driver.switchTo().activeElement();
        return SMUtils.isElementPresent( studentPopupModalPopup );

    }

    /**
     * To check display of Resume Assignment for student popup
     */
    public boolean isResumeStudentPopUpDisplayed() {
        SMUtils.waitForElement( driver, studentPopupModalPopup, 10 );
        driver.switchTo().activeElement();
        return SMUtils.isElementPresent( studentPopupModalPopup );

    }

    /**
     * To check display of Remove Assignment for student popup
     */
    public boolean isRemoveStudentPopUpDisplayed() {
        SMUtils.waitForElement( driver, studentPopupModalPopup, 10 );
        driver.switchTo().activeElement();
        return SMUtils.isElementPresent( studentPopupModalPopup );

    }

    /**
     * To click on Accordion button for a student
     */
    public void clickStudentAccordionButton( String studentNameToSelect ) {
        try {
        	SMUtils.waitForElement(driver, assignBtnAssignmentlistRoot, 20);
            SMUtils.waitForElementToBeClickable( assignBtnAssignmentlistRoot, driver );
            if ( !isSkillTestedExpanded() ) {
                SMUtils.waitForElement( driver, assignBtnAssignmentlistRoot );
                lblStudentName.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( studentFromUI -> {
                	if ( studentFromUI.equalsIgnoreCase( studentNameToSelect ) ) {
                        WebElement grandRoot = element.findElement( By.xpath( "./../.." ) );
                        WebElement parentRoot = grandRoot.findElement( By.cssSelector( skillTestedRoot ) );
                        WebElement plusIcon = SMUtils.getWebElement( driver, parentRoot, dotEllipsisBesideAssignBtnChild );
                        SMUtils.click( driver, plusIcon );
                        SMUtils.waitForElement( driver, skillTestedHeader );
                        Log.message( "Expanded the skill dropdown for student - " + studentNameToSelect, driver, true );
                    }
                } ) );
            }
        } catch ( NoSuchElementException | StaleElementReferenceException e ) {
            Log.message( "Skill dropdown not expanded for student - " + studentNameToSelect );
        }
    }

    /**
     * To check IP Level value displayed for a student
     *
     * @param firstStudent
     * @return
     */
    public String ipLevelValueChecking( String firstStudent ) {
        String ipLevelValue = null;
        SMUtils.waitForElement( driver, studentTable, 5 );
        for ( WebElement tableRow : studentTableRow ) {
            String studentName = tableRow.findElements( By.cssSelector( childElementStudentNameAssignmentDetailsTable ) ).get( 0 ).getText().trim();
            if ( studentName.equals( firstStudent ) ) {
                ipLevelValue = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 2 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText();
                Log.message( "Last Session for " + studentName + " is: " + lastSessionValues.getText().trim() );
                if ( lastSessionValues.getText().trim().equals( Constants.NOT_STARTED_VALUE ) ) {
                    Log.message( "IP Level for " + studentName + " who has not started assignment is: " + ipLevelValue );
                } else {
                    Log.message( "IP Level for " + studentName + " who has started assignment is: " + ipLevelValue );
                }
            }
        }
        return ipLevelValue.trim();
    }

    /**
     * To check Gain value displayed for a student
     *
     * @param firstStudent
     * @return
     */
    public String gainValueChecking( String firstStudent ) {
        String gainValue = null;
        SMUtils.waitForElement( driver, studentTable, 5 );
        for ( WebElement tableRow : studentTableRow ) {
            String studentName = tableRow.findElements( By.cssSelector( childElementStudentNameAssignmentDetailsTable ) ).get( 0 ).getText().trim();
            if ( studentName.equals( firstStudent ) ) {
                gainValue = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 5 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText();
                Log.message( "Last Session for " + studentName + " is: " + lastSessionValues.getText().trim() );
                if ( lastSessionValues.getText().trim().equals( Constants.NOT_STARTED_VALUE ) ) {
                    Log.message( "Gain for " + studentName + " who has not started assignment is: " + gainValue );
                } else {
                    Log.message( "Gain for " + studentName + " who has started assignment is: " + gainValue );
                }
            }
        }
        return gainValue.trim();

    }

    /**
     * To check Current Level value displayed for a student
     *
     * @param firstStudent
     * @return
     */
    public String currentLevelValueChecking( String firstStudent ) {
        String currentLevelValue = null;
        SMUtils.waitForElement( driver, studentTable, 5 );
        for ( WebElement tableRow : studentTableRow ) {
            String studentName = tableRow.findElements( By.cssSelector( childElementStudentNameAssignmentDetailsTable ) ).get( 0 ).getText().trim();
            if ( studentName.equals( firstStudent ) ) {
                currentLevelValue = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 4 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText();
                Log.message( "Last Session for " + studentName + " is: " + lastSessionValues.getText().trim() );
                if ( lastSessionValues.getText().trim().equals( Constants.NOT_STARTED_VALUE ) ) {
                    Log.message( "Current Level for " + studentName + " who has not started assignment is: " + currentLevelValue );
                } else {
                    Log.message( "Current Level for " + studentName + " who has started assignment is: " + currentLevelValue );
                }
            }
        }
        return currentLevelValue.trim();
    }

    /**
     * To Get the name of student in assignment details page
     */
    public String getStudentName( String firstName, String middleName, String secondName ) {
        String nameOfStudent = null;
        if ( middleName == null ) {
            nameOfStudent = firstName + " " + secondName;
        } else {
            nameOfStudent = firstName + " " + middleName + " " + secondName;
        }
        return nameOfStudent;
    }

    /**
     * To check Percentage Correct value displayed for a student
     */
    public String percentCorrectValueChecking( String firstStudent ) {
        String percentCorrectValue = null;
        SMUtils.waitForElement( driver, studentTable, 5 );
        for ( WebElement tableRow : studentTableRow ) {
            String studentName = tableRow.findElements( By.cssSelector( childElementStudentNameAssignmentDetailsTable ) ).get( 0 ).getText().trim();
            if ( studentName.equals( firstStudent ) ) {
                percentCorrectValue = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 6 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText();
                Log.message( "Last Session for " + studentName + " is: " + lastSessionValues.getText() );
                if ( lastSessionValues.getText().trim().equals( Constants.NOT_STARTED_VALUE ) ) {
                    Log.message( "% Correct for " + studentName + " who has not started assignment is: " + percentCorrectValue.trim() );
                } else {
                    Log.message( "% Correct for " + studentName + " who has started assignment is: " + percentCorrectValue.trim() );
                }
            }

        }
        return percentCorrectValue.trim();
    }

    public boolean checkDecimalValue( String stringToCheck ) {
        return stringToCheck.matches( Constants.DECIMAL_FORMAT );
    }

    /**
     * To check Gain value displayed for a student
     */
    public String gainValueCalculationChecking( String firstStudent ) {
        String gainValue = null;
        String currentLevel = null;
        String ipLevel = null;
        String assignedLevel = null;
        DecimalFormat value = new DecimalFormat( Constants.GAIN_VALUE_FORMAT );
        SMUtils.waitForElement( driver, studentTable, 5 );
        for ( WebElement tableRow : studentTableRow ) {
            String studentName = tableRow.findElements( By.cssSelector( childElementStudentNameAssignmentDetailsTable ) ).get( 0 ).getText().trim();
            if ( studentName.equals( firstStudent ) ) {
                currentLevel = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 4 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText();
                float floatcurrentLevel = Float.parseFloat( currentLevel );
                ipLevel = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 2 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText();
                float floatIpLevel = Float.parseFloat( ipLevel );
                assignedLevel = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 3 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText();
                float floatAssignedLevel = Float.parseFloat( assignedLevel );
                if ( ipLevel.equals( Constants.NOT_APPLICABLE_VALUE ) ) {
                    gainValue = value.format( floatcurrentLevel - floatAssignedLevel );

                } else {

                    if ( ( floatcurrentLevel - floatIpLevel ) < 0 ) {
                        gainValue = value.format( 0 );
                    } else {
                        gainValue = value.format( floatcurrentLevel - floatIpLevel );
                    }
                }
            }
        }
        return String.valueOf( gainValue ).trim();

    }

    /**
     * To check Percentage Correct value displayed for a student
     */
    public boolean percentageCorrectValueChecking( String firstStudent ) {
        String percentCorrectValue = null;
        SMUtils.waitForElement( driver, studentTable, 5 );
        for ( WebElement tableRow : studentTableRow ) {
            String studentName = tableRow.findElements( By.cssSelector( childElementStudentNameAssignmentDetailsTable ) ).get( 0 ).getText().trim();
            if ( studentName.equals( firstStudent ) ) {
                percentCorrectValue = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 6 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText();
                Log.message( "% Correct value is: " + percentCorrectValue );
            }
        }
        return percentCorrectValue.matches( Constants.PERCENTAGE_VALUE_FORMAT );
    }

    /**
     * Clicking cancel button on Remove Student pop-up
     *
     * return
     */
    public boolean clickCancelButtononRemoveStudentpopup() {
        SMUtils.waitForElement( driver, cancelRemoveStudentButton );
        WebElement cancelremoveStudentBtn = SMUtils.getWebElement( driver, cancelRemoveStudentButton, btnSecondary );
        try {
            if ( SMUtils.isElementPresent( cancelremoveStudentBtn ) ) {
                Log.message( "Cancel button is getting displayed successfully!" );
                SMUtils.clickJS( driver, cancelremoveStudentBtn );
                Log.pass( "Clicked cancel button in the Remove Student popup!" );
            } else {
                Log.fail( "Cancel button is not getting displayed!" );
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * Clicking X button on Remove Student pop-up
     *
     * return
     */
    public boolean clickXButtononRemoveStudentpopup() {
        SMUtils.waitForElement( driver, xRemoveStudentButton );
        if ( SMUtils.isElementPresent( xRemoveStudentButton ) ) {
            Log.message( "X button is getting displayed successfully!" );
            SMUtils.clickJS( driver, xRemoveStudentButton );
            Log.pass( "Clicked 'X' button!" );
        } else {
            Log.fail( "X button is not getting displayed!" );
        }
        return true;
    }

    /**
     * To get the RemoveStudent confirmation popup is having X, Cancel and
     * Remove button with message
     *
     * @return popupMessage
     */
    public String isRemoveStudentAssignmentPopupDisplayed() {
        String popupMessage = "";
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( TestDataConstants.SIMULATOR_WAIT ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( removeStudentHeadsupMessage ) );
        try {
            if ( SMUtils.isElementPresent( removeStudentPopupHeader ) ) {
                for ( WebElement element : removeStudentHeadsupMessage ) {
                    popupMessage += SMUtils.getTextOfWebElement( element, driver ).toString();
                }
                Log.pass( "Assignment pop-up Message: " + popupMessage );
            } else {
                Log.fail( "Assignment pop-up is not getting displayed" );
            }

            if ( SMUtils.isElementPresent( xRemoveStudentButton ) ) {
                Log.pass( "X button is displayed successfully!" );
            } else {
                Log.fail( "X button is not getting displayed on the Remove Student pop-up!" );
            }

            if ( SMUtils.isElementPresent( cancelRemoveStudentButton ) ) {
                Log.pass( "Cancel button is displayed successfully!" );
            } else {
                Log.fail( "Cancel button is not getting displayed on the Remove Student pop-up!" );
            }

            if ( SMUtils.isElementPresent( removeStudentButton ) ) {
                Log.pass( "Remove Button is getting displayed!" );
            } else {
                Log.fail( "Remove button is not getting displayed on the Remove Student pop-up!" );
            }
        } catch ( Exception e ) {
            Log.fail( "Error occured while verifying the popup" );
        }
        return popupMessage;
    }

    /**
     * To get Remove Student for each students in the Assignment
     *
     */
    public void removeStudentForEachStudent() {
        try {
            studentsEllipsisRoot.forEach( element -> {
                clickDotEllipsisButton();
                removeStudentTab();
                removeStudent();
            } );
            Log.message( "All the students has been Removed from the Assignment" );
        } catch ( Exception e ) {
            Log.message( "Student Not found " );
        }
    }

    /**
     * To get Remove Student Ellipses Tab/option
     *
     * @return studentRemoveEllipsis
     */
    public WebElement getStudentRemoveEllipsis() {
        SMUtils.waitForElement( driver, removeStudentBtnGrandRoot, 10 );
        WebElement studentRemoveEllipsis = SMUtils.getWebElementDirect( driver, removeStudentBtnGrandRoot, removeStudentBtnParent, removeStudentChild );
        return studentRemoveEllipsis;
    }

    /**
     * To check the availability of cancel button in the Remove student popup
     */
    public boolean checkCancelbuttonremoveStudent() {
        try {
            SMUtils.waitForElement( driver, removeStudentCancelButton );
            return cancelRemoveStudentButton.isDisplayed();
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To Click Close(X) Button/Icon the Remove Student Popup
     */
    public void clickCloseRemoveStudentPopup() {
        SMUtils.waitForElement( driver, closeIconRemoveStudent );
        SMUtils.click( driver, closeIconRemoveStudent );
        Log.message( "Clicked Close(x) icon in the Remove Student Popup" );
    }

    /**
     * To check whether tooltip for Assignment Title is displayed or not.
     */
    public boolean isToolTipDisplayedForAssignmentTitle() {
        SMUtils.waitForElement( driver, assignmentTitle, 5 );
        SMUtils.moveToElementSelenium( driver, assignmentTitle );
        SMUtils.waitForElement( driver, assignmentTitleTooltipText, 5 );
        Log.message( assignmentTitleTooltipText.getText() );
        return assignmentTitleTooltipText.isDisplayed();
    }

    /**
     * To get Zero State Screen Text for Progress Monitoring Graph
     *
     * @return
     */

    public String getZeroStateTextFromProgressGraph() throws Exception {
        String text = null;
        SMUtils.waitForElement( driver, progressMonitoringZeroState, 10 );
        try {
            text = progressMonitoringZeroState.getText();
            Log.message( "Message Fetched Successfully" );

        } catch ( Exception e ) {
            Log.message( "Message Not Found" );
            Log.exception( e );
        }
        return text;

    }

    /**
     * To check display of Edit Target Link
     */
    public boolean verifyEditTargetLinkNotDisplayed() {
        return CollectionUtils.isEmpty( editTargetBtn );
    }

    /**
     * To check display of Print Link
     */
    public boolean verifyPrintLinkNotDisplayed() {
        return CollectionUtils.isEmpty( printBtn );
    }

    /**
     * To check the X axis display
     */
    public String verifyXAxisValue() {
        SMUtils.waitForElement( driver, xAxisDisplay, 10 );
        return xAxisDisplay.getText().trim();
    }

    /**
     * To check the Y axis display
     */
    public String verifyYAxisValue() {
        SMUtils.waitForElement( driver, yAxisDisplay, 10 );
        return yAxisDisplay.getText().trim();
    }

    /**
     * To check display of Summary Link
     */
    public boolean verifyViewSummaryLinkDisplayed() {
        SMUtils.waitForElement( driver, viewSummaryBtn, 5 );
        return viewSummaryBtn.isDisplayed();
    }

    /**
     * To check display of Progress Monitoring Graph
     */
    public boolean isProgressMonitoringGraphDisplayed() {
    	 try {
             SMUtils.waitForSpinnertoDisapper( driver, 60 );
         } catch ( InterruptedException e ) {
             Log.message( "Issue in Spinner Loading" );
         }
        SMUtils.waitForElement( driver, progressMonitoringGraph, 10 );
        return SMUtils.isElementPresent( progressMonitoringGraph );
    }

    /**
     * To check display of Legends in Progress Monitoring Graph
     */
    public boolean isLegendsDisplayed() {
        SMUtils.waitForElement( driver, legendsDisplay, 10 );
        return SMUtils.isElementPresent( legendsDisplay );

    }

    /**
     * To get XAxis Date on UI
     *
     * @return
     */

    public boolean getXAxisDateOnUI() {
        String firstValueUI = dateValuesXAxis.get( 0 ).getText().trim();
        Log.message( firstValueUI );
        return firstValueUI.matches( Constants.XAXIS_DATE );
    }

    /**
     * Check whether tooltip is displayed for student names
     *
     * @return
     */
    public boolean isTooltipforStudentNameDisplayed() {
        SMUtils.waitForElement( driver, firstStudentName, 10 );
        SMUtils.moveToElementSelenium( driver, firstStudentName );
        SMUtils.waitForElement( driver, tooltipStudentName, 5 );
        return tooltipStudentName.isDisplayed();
    }

    /**
     * Check whether Skill Tested Graph is displayed
     *
     * @return
     */
    public boolean isSkillTestedGraphDisplayed() {

        SMUtils.waitForElement( driver, skillTestedGraph, 5 );

        return skillTestedGraph.isDisplayed();

    }

    /**
     * To check first value in the UI
     *
     * @return
     */

    public Boolean isYAxisFirstSameAsAssigned() {
        boolean status = false;
        String assignedLevel = null;
        String firstValueUI = courseValuesYAxis.get( 0 ).getText().trim();
        SMUtils.waitForElement( driver, studentTable, 5 );
        for ( WebElement tableRow : studentTableRow ) {
            assignedLevel = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 3 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText();
        }
        if ( firstValueUI.equals( assignedLevel ) ) {
            status = true;
            Log.message( "Course Level is displayed" );
        }
        return status;
    }

    /**
     *
     * To Click Edit Targets Button
     */

    public void clickEditTargetButton() {
        SMUtils.clickJS( driver, editTargetsButton );
        Log.message( "Edit Target button is clicked" );
    }

    /**
     * To verify the presence of help icon
     *
     * @return boolean
     */
    public boolean verifyThePresenceOfHelpIcon() {
        String messageToBeDisplayed = editTargetPopupHelpIcon.isDisplayed() ? "Help icon is present" : "Help icon is absent";
        Log.message( messageToBeDisplayed );
        return editTargetPopupHelpIcon.isDisplayed();
    }

    /**
     * To wait for 'Edit Targets' button
     */
    public void waitForEditTargetsButton() {
        SMUtils.waitForElement( driver, editTargetsButton, 10 );
        String messageToBeDisplayed = editTargetsButton.isDisplayed() ? "Edit Target button is present" : "Edit Target button is absent";
        Log.message( messageToBeDisplayed );
    }

    /**
     * To wait for 'Help Icon' in the 'Edit Targets' popup
     */
    public void waitForHelpIcon() {
        SMUtils.waitForElement( driver, editTargetPopupHelpIcon, 7 );
        String messageToBeDisplayed = editTargetPopupHelpIcon.isDisplayed() ? "Edit Target help icon is present" : "Edit Target help icon is absent";
        Log.message( messageToBeDisplayed );
    }

    /**
     * To verify Reset button in 'Edit Targets' popup is enabled or not
     *
     * @return boolean
     */
    public boolean verifyResetButtonIsEnabled() {
        WebElement resetButtonFinal = SMUtils.getWebElementDirect( driver, resetButton, editButtonCssSelector );
        String messageToBeDisplayed = resetButtonFinal.isEnabled() ? "Reset button is enabled" : "Reset button is enabled";
        Log.message( messageToBeDisplayed );
        return resetButtonFinal.isEnabled();
    }

    /**
     * To verify Cancel button in 'Edit Targets' popup is enabled or not
     *
     * @return boolean
     */
    public boolean verifyCancelButtonIsEnabled() {
        WebElement cancelButtonFinal = SMUtils.getWebElementDirect( driver, cancelButton, editButtonCssSelector );
        String messageToBeDisplayed = cancelButtonFinal.isEnabled() ? "Cancel button is enabled" : "Cancel button is enabled";
        Log.message( messageToBeDisplayed );
        return cancelButtonFinal.isEnabled();
    }

    /**
     * To click on the close button of 'Edit Targets' popup
     */
    public void clickCloseButtonOfEditTargets() {
        WebElement closeButton = SMUtils.getWebElementDirect( driver, closeButtonOfEditTargetPopup, deleteAssignmentPopupCloseBtnChild );
        SMUtils.clickJS( driver, closeButton );
        Log.message( "Close button of Edit Target poup is clicked" );
    }

    /**
     * To click on the Cancel button of 'Edit Targets' popup
     */
    public void clickCancelButtonOfEditTargetsPopup() {
        SMUtils.clickJS( driver, cancelButton );
        Log.message( "Cancel button of Edit Target poup is clicked" );
    }

    /**
     * To click on the calendar icon
     */
    public void clickOnCalendarIcon() {
        WebElement calendarButton = SMUtils.getWebElementDirect( driver, calendarIcon, calendarIconRoot, calendarIconImg );
        SMUtils.clickJS( driver, calendarButton );
        Log.message( "Calendar icon button of Edit Target poup is clicked" );
    }

    /**
     * To verify whether calendar is displayed
     *
     * @return boolean
     */
    public boolean isCalendarOpen() {
        WebElement calendar = SMUtils.getWebElementDirect( driver, calendarIcon, calendarPopup, calendarWrapper );
        String messageToBeDisplayed = calendar.isDisplayed() ? "Calendar is displayed" : "Calendar is not displayed";
        Log.message( messageToBeDisplayed );
        return calendar.isDisplayed();
    }

    /**
     * To open the calendar
     */
    public void open() {
        if ( !isCalendarOpen() ) {
            clickOnCalendarIcon();
            Log.message( "Calendar is opened" );
        }
    }

    /**
     * To close the calendar
     */
    public void close() {
        if ( isCalendarOpen() ) {
            clickOnCalendarIcon();
            Log.message( "Calendar is closed" );
        }
    }

    /**
     * To get the month and year from the calendar popup
     *
     * @return String
     */
    public String getCurrentYearAndMonthFromCalendar() {
        WebElement currentYearAndMonthFromCalendar = SMUtils.getWebElementDirect( driver, calendarIcon, calendarPopup, calendarHeaderText );
        Log.message( "Got the current month and the year from the calendar" );
        return SMUtils.getTextOfWebElement( currentYearAndMonthFromCalendar, driver );
    }

    /**
     * To get the current date and year
     *
     * @return LocalDate
     */
    public LocalDate getCurrentPeriod() {
        String currentYearAndMonthFromCalendar = getCurrentYearAndMonthFromCalendar();
        String[] currentPeriod = currentYearAndMonthFromCalendar.split( " " );
        Log.message( "Got the current period from the calendar" );
        return LocalDate.of( Integer.parseInt( currentPeriod[1] ), Month.valueOf( currentPeriod[0].toUpperCase() ), 1 );
    }

    /**
     * To click on the forward/backward arrow based on the month
     *
     * @param date
     */
    public void chooseMonth( LocalDate date ) {
        WebElement leftArrow = SMUtils.getWebElementDirect( driver, calendarIcon, calendarPopup, calendarLeftArrow );
        WebElement rightArrow = SMUtils.getWebElementDirect( driver, calendarIcon, calendarPopup, calendarRightArrow );
        LocalDate currentPeriod = getCurrentPeriod();
        long monthsAway = ChronoUnit.MONTHS.between( currentPeriod, date.withDayOfMonth( 1 ) );
        WebElement arrow = monthsAway < 0 ? leftArrow : rightArrow;
        IntStream.range( 0, (int) Math.abs( monthsAway ) ).forEach( elementIndex -> arrow.click() );
        Log.message( "Clicked on the desired arrow of the date picker" );
    }

    /**
     * To click on the desired date
     *
     * @param dayOfMonth
     */
    public void chooseDay( int dayOfMonth ) {
        WebElement dayRootWebElement = SMUtils.getWebElementDirect( driver, calendarIcon, calendarPopup );
        List<WebElement> dayMainElements = SMUtils.getWebElements( driver, dayRootWebElement, calendarDateButton );
        dayMainElements.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( elementText -> {
            if ( dayOfMonth == Integer.parseInt( elementText ) ) {
                SMUtils.clickJS( driver, element );
            }
        } ) );
        Log.message( "Clicked on the desired date" );
    }

    /**
     * To fetch the selected date
     *
     * @return LocalDate
     */
    public LocalDate getSelectedDate() {
        open();
        String currentYearAndMonthFromCalendar = getCurrentYearAndMonthFromCalendar();
        WebElement dayRootWebElement = SMUtils.getWebElementDirect( driver, calendarIcon, calendarPopup, calendarSelectedDateButton );
        String[] currentMonthAndYearPeriod = currentYearAndMonthFromCalendar.split( " " );
        Log.message( "Got the selected date" );
        return LocalDate.of( Integer.parseInt( currentMonthAndYearPeriod[1] ), getMonthNumber( currentMonthAndYearPeriod[0] ), Integer.parseInt( dayRootWebElement.getText() ) );
    }

    /**
     * To get the month number from month name
     *
     * @param monthName
     *
     * @return int
     */
    private int getMonthNumber( String monthName ) {
        Log.message( "Got the month name from the string" );
        return Month.valueOf( monthName.toUpperCase() ).getValue();
    }

    /**
     * To get pair of days which is more and one less than todays date
     *
     * @return dateList
     */
    public List<Integer> getYesterdayAndTomorrowsDate() {
        List<Integer> dateList = new ArrayList<>();
        LocalDate today = LocalDate.now();
        int yesterday = today.getDayOfMonth() - 1;
        dateList.add( yesterday );
        int tomorrow = today.getDayOfMonth() + 1;
        dateList.add( tomorrow );
        Log.message( "Got the required dates" );
        return dateList;
    }

    /**
     * To click on the desired date
     *
     * @param date
     *
     * @return LocalDate
     */
    public LocalDate chooseDate( LocalDate date ) {
        open();
        chooseMonth( date );
        chooseDay( date.getDayOfMonth() );
        Log.message( "Chose the required date from the date picker" );
        return getSelectedDate();
    }

    /**
     * To enter the date to the 'Target Date' field
     */
    public void enterTheDateInTargetDateField() {
        JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) driver;
        javaScriptExecutor.executeScript( "document.querySelector('cel-date-picker.edit-target-date-picker').shadowRoot.querySelector('input.date-picker-input').value = '05/06/22'" );
        close();
        Log.message( "Entered the desired dates" );
    }

    /**
     * To click on the Save button of Edit Targets popup
     */
    public void clickOnSaveButtonOfEditTargets() {
        WebElement saveButton = SMUtils.getWebElementDirect( driver, saveButtonEditTargetPopup, closeButtonChild );
        try {
            SMUtils.clickJS( driver, saveButton );
            Log.message( "Clicked on the save button of the Edit Target popup" );
        } catch ( Exception e ) {
            waitForEditTargetsButton();
        }
    }

    /**
     * To verify whether Save button is enabled
     *
     * @return boolean
     */
    public boolean verifySaveButtonIsEnabled() {
        WebElement saveButton = SMUtils.getWebElementDirect( driver, saveButtonEditTargetPopup, closeButtonChild );
        String messageToBeDisplayed = saveButton.isEnabled() ? "Save button is present" : "Save button is absent";
        Log.message( messageToBeDisplayed );
        return saveButton.isEnabled();
    }

    /**
     * To get the value from the date field
     *
     * @return dateFromUi
     */
    public String getTheDateInTargetDateField() {
        WebElement dateInputfield = SMUtils.getWebElementDirect( driver, calendarIcon, datePickerInput );
        SMUtils.clickJS( driver, dateInputfield );
        JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) driver;
        String dateFromUi = javaScriptExecutor.executeScript( "document.querySelector('cel-date-picker.edit-target-date-picker').shadowRoot.querySelector('input.date-picker-input').value" ).toString();
        Log.message( "Date from UI is " + dateFromUi );
        return dateFromUi;
    }

    /**
     * To click on the Reset button
     */
    public void clickOnResetButtonOfEditTargets() {
        WebElement resetButtonFinal = SMUtils.getWebElementDirect( driver, resetButton, editButtonCssSelector );
        try {
            SMUtils.clickJS( driver, resetButtonFinal );
            Log.message( "Reset button is clicked" );
        } catch ( Exception e ) {
            waitForHelpIcon();
        }
    }

    /**
     * To verify the max value of the sliders for Edit Target popup
     *
     * @return boolean
     */
    public boolean verifyMaxValuesOfSliderOfEditTargetPopup() {
        Set<String> maxValuesOfSlider = new HashSet<>();
        slidersMaxValue.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( elementText -> {
            if ( elementText.equals( Constants.SLIDER_MAX_VALUE ) ) {
                maxValuesOfSlider.add( elementText );
            }
        } ) );
        Log.message( "Veified maximum values of the slider" );
        return maxValuesOfSlider.size() == 1;
    }

    /**
     * To verify the min value of the sliders for Edit Target popup
     *
     * @return boolean
     */
    public boolean verifyMinValuesOfOfSliderOfEditTargetPopup() {
        Set<String> minValuesOfSlider = new HashSet<>();
        slidersMinValue.forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( elementText -> {
            if ( elementText.equals( Constants.SLIDER_MIN_VALUE ) ) {
                minValuesOfSlider.add( elementText );
            }
        } ) );
        Log.message( "Veified minimum values of the slider" );
        return minValuesOfSlider.size() == 1;
    }

    /**
     * To set the slider values for Edit Target popup
     *
     * @param sliderValue
     */
    public void setSliderValuesOfEditTargetPopup( int sliderValue ) {
        drageTheSlider( sliderValue );
        Log.message( "Draged the slide value" );
    }

    /**
     * To get the slider values for Edit Target popup
     *
     * @return sliderValues
     */
    public List<String> getSliderValuesOfEditTargetPopup() {
        List<String> sliderValues = new ArrayList<>();
        sliders.forEach( element -> {
            try {
                sliderValues.add( element.getAttribute( "data-default-value" ) );
                Log.message( element.getAttribute( datePickerAttributeTag ) + " is the slide value" );
            } catch ( Exception e ) {
                Log.message( "Hidden element detected. Please ignore." );
            }
        } );
        return sliderValues;
    }

    /**
     * To verify the slider values for Edit Target popup
     *
     * @return boolean
     */
    public boolean verifySliderValuesOfEditTargetPopup( int sliderPercentage ) {
        drageTheSlider( sliderPercentage );
        Log.message( "Slider values verified" );
        return getSliderValuesOfEditTargetPopup().equals( Constants.SLIDER_VALUES );
    }

    /**
     * To drag the slider
     *
     * @param dragPixels
     */
    public void drageTheSlider( int dragPixels ) {
        Actions a = new Actions( driver );
        sliders.forEach( element -> {
            try {
                a.dragAndDropBy( element.findElement( By.cssSelector( sliderInput ) ), dragPixels, 0 ).perform();
            } catch ( Exception e ) {
                Log.message( "Dragged the slider successfully" );
            }
        } );
    }

    /**
     * To click on the Zoom In button
     *
     */
    public void clickZoomInButton() {
        SMUtils.waitForElement( driver, zoomInButton, 10 );
        SMUtils.clickJS( driver, zoomInButton );
        SMUtils.waitForElement( driver, closeButton, 10 );
    }

    /**
     * To check view summary button is displayed or not.
     */
    public boolean isDisplayedViewSummaryBtn() {
        WebElement clickViewSummaryBtn = SMUtils.getWebElementDirect( driver, clickViewSummaryBtnCss, clickViewSummaryBtnRoot );
        String message = SMUtils.isElementPresent( clickViewSummaryBtn ) ? "View summary button is present" : "View summary button is absent";
        Log.message( message );
        return SMUtils.isElementPresent( clickViewSummaryBtn );
    }

    /**
     * To check zero ip level is displayed or not.
     */

    public boolean isDisplayedZeroIPLevel() {
        SMUtils.waitForElement( driver, zeroIPLevelBtnCss );
        String message = SMUtils.isElementPresent( zeroIPLevelBtnCss ) ? "Zero IP level is displayed" : "Zero IP level is not displayed";
        Log.message( message );
        return SMUtils.isElementPresent( zeroIPLevelBtnCss );
    }

    /**
     * To click on zoom in button.
     */
    public void clickZoomInBtn() {
        SMUtils.waitForElement( driver, zoomInBtn, 5 );
        SMUtils.clickJS( driver, zoomInBtn );
        Log.message( "Clicked on zoom in button." );
    }

    /**
     * To check view graph title is displayed or not.
     */
    public boolean isDisplayedVeiwGraphTitle() {
        SMUtils.waitForElement( driver, viewGraphTitle, 6 );
        String message = SMUtils.isElementPresent( viewGraphTitle ) ? "Veiw Graph tiltle is displayed" : "Veiw Graph tiltle is not displayed";
        Log.message( message );
        return SMUtils.isElementPresent( viewGraphTitle );
    }

    /**
     * To click on edit target button.
     */
    public void clickEditTargetBtn() {
        WebElement editTargetBtn = SMUtils.getWebElementDirect( driver, editTargetsBtnHost, clickViewSummaryBtnRoot );
        SMUtils.waitForElement( driver, editTargetBtn, 5 );
        SMUtils.clickJS( driver, editTargetBtn );
        Log.message( "Clicked on edit target button." );
    }

    /**
     * To check edit target button is displayed or not.
     */

    public boolean isDisplayedEditTargetBtn() {
        WebElement editTargetBtn = SMUtils.getWebElementDirect( driver, editTargetsBtnHost, clickViewSummaryBtnRoot );
        SMUtils.waitForElement( driver, editTargetBtn, 5 );
        String message = SMUtils.isElementPresent( editTargetBtn ) ? "Edit target button is displayed" : "Edit target button is not displayed";
        Log.message( message );
        return editTargetBtn.isDisplayed();
    }

    /**
     * To click on print button.
     */
    public void clickPrintBtn() {
        SMUtils.waitForElement( driver, printBtnHost );
        WebElement printBtn = SMUtils.getWebElementDirect( driver, printBtnHost, clickViewSummaryBtnRoot );
        SMUtils.waitForElement( driver, printBtn, 5 );
        SMUtils.clickJS( driver, printBtn );
        Log.message( "Clicked on print button." );
    }

    /**
     * To click cancel on Print popup
     */
    public void clickClosePrintPopup() {
        SMUtils.waitForElement( driver, windowPopuproot );
        SMUtils.getWebElementDirect( driver, windowPopuproot, windowPopupChild1, windowPopupChild2, windowPopupChild3 ).click();
    }

    /***
     * Checks whether SM logo is displayed
     *
     * @return
     */
    public boolean isNewSuccessmakerLogoDisplayed() {
        SMUtils.waitForElement( driver, successmakerLogo );
        return successmakerLogo.isDisplayed();
    }

    /**
     * To check print button is displayed or not.
     */
    public boolean isDispayedPrintBtn() {
        WebElement printBtn = SMUtils.getWebElementDirect( driver, printBtnHost, clickViewSummaryBtnRoot );
        SMUtils.waitForElement( driver, printBtn, 5 );
        String message = SMUtils.isElementPresent( printBtn ) ? "Print button is displayed" : "Print button is not displayed";
        Log.message( message );
        return printBtn.isDisplayed();
    }

    /**
     * To verify Print icon displayed
     */
    public boolean isDispayedPrintIcon() {
        SMUtils.waitForElement( driver, printIconHost, 5 );
        WebElement printBtn = SMUtils.getWebElementDirect( driver, printIconHost, progressIconShadowRootCss );
        return printBtn.isDisplayed();
    }

    /**
     * To click on view summary
     */
    public void clickViewSummary() {
        SMUtils.waitForElement( driver, viewSummaryIconCss, 5 );
        WebElement actualViewSummary = SMUtils.getWebElementDirect( driver, viewSummaryIconCss, progressIconShadowRootCss );
        SMUtils.clickJS( driver, actualViewSummary );
    }

    /**
     * Checks Zoom In Popup closed or not
     */
    public boolean isZoomInPopupClosed() {
        return CollectionUtils.isEmpty( textInZoomInPopup );
    }

    /**
     * To check edit target pop up title is displayed or not.
     */
    public boolean isDisplayedEditTargetTitlePopUp() {
        SMUtils.waitForElement( driver, editTargetPopUpTitle, 5 );
        String message = SMUtils.isElementPresent( editTargetPopUpTitle ) ? "Edit Target pop up title is displayed" : "Edit Target pop up title is not displayed";
        Log.message( message );
        return SMUtils.isElementPresent( editTargetPopUpTitle );
    }

    /**
     * To check print pop up title is displayed or not.
     */
    public boolean isDisplayedPrintTitlePopUp() {
        SMUtils.waitForElement( driver, successmakerLogoInPrintPopUp, 5 );
        String message = SMUtils.isElementPresent( successmakerLogoInPrintPopUp ) ? "Print popup is present" : "Print popup is absent";
        Log.message( message );
        return SMUtils.isElementPresent( successmakerLogoInPrintPopUp );
    }

    /**
     * To Click Close(X) Button for Zoom In Popup
     */

    public void clickZoomInCloseButton() {
        SMUtils.waitForElement( driver, deleteAssignmentPopupCloseBtnRoot );
        WebElement closeButton = SMUtils.getWebElement( driver, deleteAssignmentPopupCloseBtnRoot, deleteAssignmentPopupCloseBtnChild );
        SMUtils.clickJS( driver, closeButton );
        Log.message( "Clicked Close Button" );
        isZoomInPopupClosed();

    }

    /**
     * To check weather toggle OFF is displayed or not.
     */
    public boolean isDisplayedToggleONShowTarget() {
        SMUtils.waitForElement( driver, clickToggleOFFShowTarget, 5 );
        String message = SMUtils.isElementPresent( clickToggleOFFShowTarget ) ? "Show target toggle is in ON mode" : "Show target toggle is not in ON mode";
        Log.message( message );
        return clickToggleOFFShowTarget.isDisplayed();
    }

    /**
     * To check weather toggle ON show target is displayed or not.
     */

    public void clickToggleONShowTarget() {
        SMUtils.waitForElement( driver, clickToggleOFFShowTarget, 5 );
        SMUtils.clickJS( driver, clickToggleOFFShowTarget );
        Log.message( "Turned off toggle button of show target" );
    }

    /**
     * To check weather toggle OFF is displayed or not.
     */
    public boolean isDisplayedToggleOffShowTarget() {
        SMUtils.waitForElement( driver, clickToggleONShowTarget, 5 );
        String message = SMUtils.isElementPresent( clickToggleONShowTarget ) ? "Show target toggle is in OFF mode" : "Show target toggle is not in OFF mode";
        Log.message( message );
        return clickToggleONShowTarget.isDisplayed();

    }

    /**
     * Click on toggle button for show target
     */
    public void clickToggleOffShowTarget() {
        SMUtils.waitForElement( driver, clickToggleONShowTarget, 5 );
        SMUtils.clickJS( driver, clickToggleONShowTarget );
        Log.message( "Turned on toggle button of show target" );
    }

    /**
     * To click Edit Setting button
     */
    public void clickEditSettingBtn() {
        WebElement clickEditSettingBtn = SMUtils.getWebElement( driver, editShadowHostCssSelector, editButtonCssSelector );
        SMUtils.waitForElementToBeClickable( clickEditSettingBtn, driver );
        SMUtils.clickJS( driver, clickEditSettingBtn );
        Log.message( "Edit button setting is clicked" );
    }

    /**
     * To scroll into view
     */
    public void scrollInToExpandedStudent() {
        SMUtils.waitForElement( driver, substractionToggle );
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript( "arguments[0].scrollIntoView();", substractionToggle );
        Log.message( "Scrolled into student expanded" );
    }
    
    /**
     * To scroll into view
     */
    public void scrollInToExpandedStudentAddition() {
        SMUtils.waitForElement( driver, additionToggle );
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript( "arguments[0].scrollIntoView();", additionToggle );
        Log.message( "Scrolled into student expanded" );
    }

    /**
     * From the Assignment Details page this method will pause the Assignment
     * for all Students
     */
    public void pauseAssignmentForAllStudents() {
        pauseAllStudent();
        pauseButtonFoAllSTudent();
    }

    /**
     * To delete the Assignments from assignment details page
     */
    public void deleteAssignment() {
        deleteAssignmenttab();
        deleteAssignmentButton();

    }

    /**
     * To get the Skill Tested - Correct Count & Percentage
     *
     * @return
     */
    public HashMap<String, HashMap<String, String>> getSkillsCorrectCountAndPercentage() {
        HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<>();
        HashMap<String, HashMap<String, String>> skillsTestedFirst = new HashMap<>();
        List<String> skillsName = new ArrayList<>();
        List<String> skillsCorrect = new ArrayList<>();

        Log.message( "No of Skill Tested is " + lastSessionSkillTestedNames.size() );
        // Adding skill Names
        if ( CollectionUtils.isNotEmpty( lastSessionSkillTestedNames ) ) {
            lastSessionSkillTestedNames.forEach( skillName -> {
                String name = skillName.getText().trim();
                skillsName.add( name );
            } );

            // Adding skillCorrect Text
            skillsCorrectList.forEach( skillCorrect -> {
                String name = skillCorrect.getText().trim();
                skillsCorrect.add( name );
            } );

            IntStream.range( 0, progressBarRoot.size() ).forEach( skillCount -> {
                WebElement parent = SMUtils.getWebElementDirect( driver, progressBarRoot.get( skillCount ), progressBarCSS );
                String barText = null;
                String barWidthArrtribute = null;
                String barColor = null;
                String barTextColor = null;
                HashMap<String, String> eachValues = new HashMap<>();
                try {
                    barText = parent.getText();
                    barTextColor = Color.fromString( parent.getCssValue( "color" ) ).asHex();
                    barWidthArrtribute = parent.getAttribute( "style" );
                    barColor = Color.fromString( parent.getCssValue( "background-color" ) ).asHex();

                } catch ( Exception NullPointerException ) {
                    parent = SMUtils.getWebElementDirect( driver, progressBarRoot.get( skillCount ), progressBarTextZeroCSS );
                    barWidthArrtribute = parent.getAttribute( "style" );
                    eachValues.put( SKILL_PERCENT_VALUE, parent.getText().trim() );
                    eachValues.put( BAR_WIDTH, barWidthArrtribute );
                    eachValues.put( SKILL_PERCENT_VALUE_COLOR, barTextColor );
                    eachValues.put( PROGRESS_BAR_COLOR, parent.getCssValue( "background-color" ) );
                }
                eachValues.put( SKILL_CORRECT, skillsCorrect.get( skillCount ) );
                eachValues.put( SKILL_PERCENT_VALUE, barText );
                eachValues.put( BAR_WIDTH, barWidthArrtribute );
                eachValues.put( PROGRESS_BAR_COLOR, barColor );
                eachValues.put( SKILL_PERCENT_VALUE_COLOR, barTextColor );
                skillsTestedList.put( skillsName.get( skillCount ), eachValues );
            } );

            skillsTestedFirst.put( skillsName.stream().findFirst().get(), skillsTestedList.get( skillsName.stream().findFirst().get() ) );

        } else {
            Log.message( "The student has no skills tested" );
        }
        return skillsTestedFirst;
    }

    /**
     * To get the Skill Tested Popup - Correct Count & Percentage
     *
     * @return
     */
    public HashMap<String, HashMap<String, String>> getSkillsPopupCorrectCountAndPercentage() {
        HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<>();
        String skillsName;
        String skillsCorrect;

        Log.message( "Name of Skill Tested is: " + lblSkillNameInPopup.getText() );
        // Adding skill Names
        if ( !lblSkillNameInPopup.getText().isEmpty() ) {
            skillsName = lblSkillNameInPopup.getText().trim();

            // Adding skillCorrect Text
            skillsCorrect = countOFCorrectAandAttemptedInPopup.getText().trim();

            WebElement parent = SMUtils.getWebElementDirect( driver, progressBarInPopup, progressBarCSS );
            HashMap<String, String> eachValues = new HashMap<>();
            String barText = parent.getText();
            String barTextColor = Color.fromString( parent.getCssValue( "color" ) ).asHex();
            String barWidthArrtribute = parent.getAttribute( "style" );
            String barColor = Color.fromString( parent.getCssValue( "background-color" ) ).asHex();

            eachValues.put( SKILL_CORRECT, skillsCorrect );
            eachValues.put( SKILL_PERCENT_VALUE, barText );
            eachValues.put( BAR_WIDTH, barWidthArrtribute );
            eachValues.put( PROGRESS_BAR_COLOR, barColor );
            eachValues.put( SKILL_PERCENT_VALUE_COLOR, barTextColor );
            skillsTestedList.put( skillsName, eachValues );

        } else {
            Log.message( "The Skill Pop up widget is not displayed" );
        }
        return skillsTestedList;
    }

    /**
     * To Compare the Skill Tested data & Skill Tested Popup data
     *
     * @return
     */
    public boolean skillTestedAndSkillPopupMatch( HashMap<String, HashMap<String, String>> skill, HashMap<String, HashMap<String, String>> skillPopup ) {
        SMUtils.waitForElement( driver, progressBarInPopup );
        return ( skill.keySet().equals( skillPopup.keySet() ) );
    }

    /**
     * To Compare the Skill Tested Popup and Skill Tested expansion for Correct
     * Count & Total Count
     *
     * @return
     */
    public boolean skillTestedAndSkillPopupCorrectTotalMatch( HashMap<String, HashMap<String, String>> skill, HashMap<String, HashMap<String, String>> skillPopup, String skillName ) {
        return ( skill.get( skillName ).get( SKILL_CORRECT ).equals( skillPopup.get( skillName ).get( SKILL_CORRECT ) ) );
    }

    /**
     * To Compare the MATH Skill Tested Popup and Skill Tested expansion for
     * Progress Bar % Correct and Text Color
     *
     * @return
     */
    public boolean skillTestedAndSkillPopupBarTextMath( HashMap<String, HashMap<String, String>> skill, HashMap<String, HashMap<String, String>> skillPopup, String skillName ) {
        return ( skill.get( skillName ).get( SKILL_PERCENT_VALUE ).equals( skillPopup.get( skillName ).get( SKILL_PERCENT_VALUE ) ) && skillPopup.get( skillName ).get( SKILL_PERCENT_VALUE_COLOR ).equals( Constants.MATH_PERCENT_TEXT_COLOR ) );
    }

    /**
     * To Compare the Read Skill Tested Popup and Skill Tested expansion for
     * Progress Bar % Correct and Text Color
     *
     * @return
     */
    public boolean skillTestedAndSkillPopupBarTextRead( HashMap<String, HashMap<String, String>> skill, HashMap<String, HashMap<String, String>> skillPopup, String skillName ) {
        return ( skill.get( skillName ).get( SKILL_PERCENT_VALUE ).equals( skillPopup.get( skillName ).get( SKILL_PERCENT_VALUE ) ) && skillPopup.get( skillName ).get( SKILL_PERCENT_VALUE_COLOR ).equals( Constants.READ_PERCENT_TEXT_COLOR ) );
    }

    /**
     * To Verify MATH Progress bar color and value
     *
     * @return
     */
    public boolean skillTestedPopupProgressBarColorMath( HashMap<String, HashMap<String, String>> skillPopup, String skillName ) {
        SMUtils.waitForElement( driver, progressBarInPopup );
        return ( skillPopup.get( skillName ).get( PROGRESS_BAR_COLOR ).equals( Constants.MATH_COLOR_STRING ) );
    }

    /**
     * To Verify Reading Progress bar color
     *
     * @return
     */
    public boolean skillTestedPopupProgressBarColorRead( HashMap<String, HashMap<String, String>> skillPopup, String skillName ) {
        SMUtils.waitForElement( driver, progressBarInPopup );
        return ( skillPopup.get( skillName ).get( PROGRESS_BAR_COLOR ).equals( Constants.READ_COLOR_STRING ) );
    }

    /**
     * To check Assigned Level value displayed for a student
     */
    public String assignedLevelValueChecking( String firstStudent ) {
        String assignedLevelValue = null;
        SMUtils.waitForElement( driver, studentTable, 5 );
        for ( WebElement tableRow : studentTableRow ) {
            String studentName = tableRow.findElements( By.cssSelector( childElementStudentNameAssignmentDetailsTable ) ).get( 0 ).getText().trim();
            if ( studentName.equals( firstStudent ) ) {
                assignedLevelValue = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 3 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText();
                Log.message( "Last Session for " + studentName + " is: " + lastSessionValues.getText().trim() );
                if ( lastSessionValues.getText().trim().equals( Constants.NOT_STARTED_VALUE ) ) {
                    Log.message( "Assigned Level for " + studentName + " who has not started assignment is: " + assignedLevelValue );
                } else {
                    Log.message( "Assigned Level for " + studentName + " who has started assignment is: " + assignedLevelValue );
                }
            }
        }
        return assignedLevelValue.trim();
    }

    /**
     *
     * To return the Heading of Progress
     */
    public String getTextProgressHeading() {
        SMUtils.waitForElement( driver, proogressHeader );
        return SMUtils.getTextOfWebElement( proogressHeader, driver );
    }

    /**
     *
     * To verify edit target is displayed
     */
    public boolean isdisplayedEditTargets() {
        SMUtils.waitForElement( driver, editTargets );
        return editTargets.isDisplayed();
    }

    /**
     *
     * To verify Print is displayed
     */
    public boolean isdisplayedPrint() {
        SMUtils.waitForElement( driver, print );
        return print.isDisplayed();
    }

    /**
     *
     * To verify View Graph is displayed
     */
    public boolean isdisplayedViewGraph() {
        SMUtils.waitForElement( driver, viewSummaryRoot );
        return viewSummaryRoot.isDisplayed();
    }

    /**
     *
     * To verify integer is displayed in Total Session
     */
    public boolean isIntegerValue( String value ) {
        StringUtils.isNumeric( value );
        return true;
    }

    /**
     *
     * To verify Decimal Format
     */
    public boolean verifyDecimalformat( String stringToCheck ) {
        return stringToCheck.contains( "0." );
    }
    
    

    /**
     *
     * To click Edit Target
     */
    public void clickEditTargets() {
        SMUtils.waitForElement( driver, editTargets );
        SMUtils.clickJS( driver, editTargets );
        Log.message( "Clicked Edit Target Button" );
    }

    /**
     *
     * To Verify Edit Cancel button is enable
     */
    public boolean isEditCancelButtonEnable() {
        SMUtils.waitForElement( driver, editCancelbtnRoot );
        return editCancelbtnRoot.isDisplayed();
    }

    /**
     *
     * To Click edit cancel button
     */
    public void clickeditCancelButton() {
        SMUtils.waitForElement( driver, editCancelbtnRoot );
        SMUtils.clickJS( driver, editCancelbtnRoot );
        Log.message( "Clicked cancel button in Edit Target Popup" );
    }

    /**
     *
     * To verify navigating to graph page
     */
    public boolean iscourseLevelTextisdisplayed() {
        SMUtils.waitForElement( driver, courseLevelText );
        return courseLevelText.isDisplayed();
    }

    /***
     * Get Summary labels
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getViewSummayDetails() throws Exception {

        // get header names
        List<String> view_SummaryNames = viewSummaryList.stream().map( value -> value.getText().trim() ).collect( Collectors.toList() );
        Log.message( "Got all labels from View Summary" );
        return view_SummaryNames;
    }

    /***
     * Get Summary Headers
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getViewSummayHeaders() throws Exception {

        // get header names
        List<String> view_SummaryHeaders = viewSummaryHeaders.stream().map( value -> value.getText().trim() ).collect( Collectors.toList() );
        Log.message( "Got all Headers from View Summary" );
        return view_SummaryHeaders;
    }

    /**
     *
     * To verify values format in view summary
     */
    public void valuesFormatChecking() throws Exception {
        try {
            HashMap<String, String> summaryMap = new HashMap<>();
            SMUtils.waitForElement( driver, viewSummaryRoot, 10 );

            IntStream.range( 0, viewSummaryList.size() ).forEach( index -> summaryMap.computeIfAbsent( viewSummaryList.get( index ).getText().trim(), k -> viewSummaryNameValues.get( index ).getText().trim() ) );

            for ( Map.Entry<String, String> set : summaryMap.entrySet() ) {
                String summaryLabelm = set.getKey();
                String summaryValuem = set.getValue();

                if ( summaryLabelm.matches( "Primary Target" ) ) {
                    boolean value = verifyDecimalformat( summaryValuem );
                    Log.assertThat( value, "Primary Target format value displayed sucessfully", "Primary Target format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Secondary Target" ) ) {
                    boolean value = verifyDecimalformat( summaryValuem );
                    Log.assertThat( value, "Secondary Target format value displayed sucessfully", "Secondary Target format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Assigned Level" ) ) {
                    boolean value = verifyDecimalformat( summaryValuem );
                    Log.assertThat( value, "Assigned Level format value displayed sucessfully", "Assigned Level format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "IP Level" ) ) {
                    boolean value = verifyDecimalformat( summaryValuem );
                    Log.assertThat( value, "IP Level format value displayed sucessfully", "IP Level format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Current Level" ) ) {
                    boolean value = verifyDecimalformat( summaryValuem );
                    Log.assertThat( value, "Current Level format value displayed sucessfully", "Current Level format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Gain" ) ) {
                    boolean value = verifyDecimalformat( summaryValuem );
                    Log.assertThat( value, "Gain format value displayed sucessfully", "Gain format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Total Sessions" ) ) {
                    boolean value = isIntegerValue( summaryValuem );
                    Log.assertThat( value, "Total Sessions format value displayed sucessfully", "Total Sessions format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Sessions Since IP" ) ) {
                    boolean value = isIntegerValue( summaryValuem );
                    Log.assertThat( value, "Sessions Since IP format value displayed sucessfully", "Sessions Since IP format value is not displayed properly" );
                }

            }
        } catch ( Exception e ) {
            Log.exception( e );
        }
    }

    /**
     *
     * To verify view summary values match with the assignment page
     */

    public void ViewSummaryvalCheckAsgmt( String label, String labelValue ) throws Exception {
        try {
            HashMap<String, String> summaryMap = new HashMap<>();
            List<String> summaryLabels = new ArrayList<>();
            List<String> summaryValues = new ArrayList<>();
            SMUtils.waitForElement( driver, viewSummaryRoot, 10 );

            viewSummaryList.stream().forEach( summaryLabela -> {
                String summaryLabel = summaryLabela.getText().trim();
                summaryLabels.add( summaryLabel );
            } );

            viewSummaryNameValues.stream().forEach( summaryValuea -> {
                String summaryValue = summaryValuea.getText().trim();
                summaryValues.add( summaryValue );
            } );

            IntStream.range( 0, viewSummaryList.size() ).forEach( index -> summaryMap.computeIfAbsent( viewSummaryList.get( index ).getText().trim(), k -> viewSummaryNameValues.get( index ).getText().trim() ) );

            for ( Map.Entry<String, String> set : summaryMap.entrySet() ) {
                String summaryLabelm = set.getKey();
                String summaryValuem = set.getValue().trim();
                if ( summaryLabelm.matches( label ) ) {
                    if ( labelValue.matches( summaryValuem ) ) {
                        Log.pass( "Assignment of " + label + " value matched with the View Summary successfully " + label + " Value" );
                    } else {
                        Log.fail( "Assignment of " + label + "value not matched with the View Summary  " + label + " Value" );
                    }
                }
            }

        } catch ( Exception e ) {
            Log.exception( e );
        }
    }

    /**
     *
     * To Click view summary for assignment page
     */
    public void clickViewSummaryPage() {
        driver.findElement( By.tagName( "body" ) ).sendKeys( Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB );
        SMUtils.waitForElement( driver, viewSummaryRoot, 30 );
        SMUtils.clickJS( driver, viewSummaryRoot );
        Log.message( "Clicked View Summary" );

    }

    /**
     * To Get Assignment Setting tab
     *
     * @return
     */
    public void clickAssignmentSettingInEllipsis() {

        SMUtils.waitForElement( driver, assigmnentSettingGrandRoot );
        WebElement assigmentsSettingParent = SMUtils.getWebElement( driver, assigmnentSettingGrandRoot, assigmnentSettingParent );
        WebElement assigmentsSetting = SMUtils.getWebElement( driver, assigmentsSettingParent, assigmnentSettingchild );
        SMUtils.clickJS( driver, assigmentsSetting );
    }

    /**
     * Verify zoom in link is present in progress monitoring graph
     */

    public boolean isDisplayedZoomInLink() {
        SMUtils.waitForElement( driver, zoomInBtn, 6 );
        String message = SMUtils.isElementPresent( zoomInBtn ) ? "Zoom In link is displayed" : "Zoom In link is not displayed";
        Log.message( message );
        return SMUtils.isElementPresent( zoomInBtn );
    }

    /**
     *
     * To verify color of Zoom In link.
     */
    public boolean verifyColorZoomInLink() {
        SMUtils.waitForElement( driver, zoomInBtn );
        String backColor = zoomInBtn.getCssValue( "color" );
        String hexColor = Color.fromString( backColor ).asHex();
        Log.message( "Hex color of zoom in link is" + hexColor );
        return hexColor.equals( Constants.ZOOM_IN_TEXT_COLOR );
    }

    /**
     *
     * To verify wheather view graph text is in bold font.
     */
    public boolean verifyViewGraphTextIsBold() {
        SMUtils.waitForElement( driver, viewGraphTitle );
        String isBold = viewGraphTitle.getCssValue( "font-weight" );
        Log.message( "Font wieght of view graph is" + isBold );
        return isBold.equals( Constants.VIEW_GRAPH_FONT_WEIGHT );
    }

    /**
     *
     * To verify wheather Progress text is in bold font.
     */
    public boolean verifyProgressTextIsBold( String browser ) {
        SMUtils.waitForElement( driver, progressHeader );
        String isBold = progressHeader.getCssValue( "font-weight" );
        System.out.println( isBold );
        Log.message( "Font wieght of Progress is" + isBold );
        if ( browser.equalsIgnoreCase( Constants.CHROME ) ) {
            return isBold.equals( Constants.PROGRESS_TEXT_FONT_WEIGHT );
        } else {
            return isBold.equals( Constants.BOLD );
        }
    }

    /**
     *
     * To verify font size of show target.
     */
    public boolean verifyShowTargetFontSize( String browser ) {
        SMUtils.waitForElement( driver, showTargetLink );
        String getFontSize = showTargetLink.getCssValue( "font-size" );
        Log.message( "Font size of show target is" + getFontSize );
        if ( browser.equalsIgnoreCase( Constants.CHROME ) ) {
            return getFontSize.equals( Constants.SHOW_TARGET_FONT_SIZE );
        } else {
            return getFontSize.equals( Constants.SHOW_TARGET_FONT_SIZE_SAFARI );
        }
    }

    /**
     *
     * To verify font size of Progress.
     */
    public boolean verifyProgressFontSize() {
        SMUtils.waitForElement( driver, progressHeader );
        String getFontSize = progressHeader.getCssValue( "font-size" );
        Log.message( "Font size of Progress is" + getFontSize );
        return getFontSize.equals( Constants.PROGRESS_FONT_SIZE );
    }

    /**
     *
     * To verify x and y axis is displayed or not
     */
    public boolean isDisplayedXYAxis() {
        SMUtils.waitForElement( driver, borderXYAxis );
        String message = SMUtils.isElementPresent( borderXYAxis ) ? "x and y axis is displayed" : "x and y axis is not displayed";
        Log.message( message );
        return borderXYAxis.isDisplayed();
    }

    public boolean verifyStudentsAssignedToAssignment( String studentName ) {
        return availableStudents.stream().anyMatch( student -> student.getText().contains( studentName ) );
    }

    /**
     * To check for completed tag.
     */
    public boolean checkCompletedTag() {

        SMUtils.waitForElement( driver, completedTag, 5 );
        //commented the below lines as it was throwing java.lang.reflect.InvocationTargetException
        //sometimes.
        //SMUtils.moveToElementSelenium( driver, completedTag );
        SMUtils.moveToElementJS(driver, completedTag);
        return completedTag.isDisplayed();
    }

    /**
     *
     * To check for completed tag color.
     */
    public String checkCompletedTagColor() {

        SMUtils.waitForElement( driver, pausedTag, 5 );
        SMUtils.moveToElementSelenium( driver, pausedTag );
        String color = completedTag.getCssValue( "background-color" );
        return Color.fromString( color ).asHex();
    }

    /**
     *
     * To check for paused tag color.
     */
    public String checkPausedTagColor() {

        SMUtils.waitForElement( driver, pausedTag, 5 );
        SMUtils.moveToElementSelenium( driver, pausedTag );
        String color = pausedTag.getCssValue( "background-color" );
        return Color.fromString( color ).asHex();
    }

    /**
     * To check for Paused tag.
     */
    public boolean checkPausedTag() {

        SMUtils.waitForElement( driver, pausedTag, 5 );
        SMUtils.moveToElementSelenium( driver, pausedTag );
        return pausedTag.isDisplayed();
    }

    /**
     * To get the state of Arrow UP or Down
     *
     * @return
     */
    public String getArrowStateOfColumn() {
        String status = arrowIcon.getAttribute( "name" );
        if ( status.equals( arrowUp ) ) {
            return Constants.ASCENDING;
        } else if ( status.equals( arrowDown ) ) {
            return Constants.DESCENDING;
        } else {
            Log.fail( "Arrow icon is not found" );
            return null;
        }
    }

    /**
     * To click the column Name and select the sorting type
     *
     * @param columnName
     * @param sortingType - Ascending(up) or Descending(down)
     */
    public void clickColumnnAndSort( String columnName, String sortingType ) {
        for ( WebElement heading : columnNamesList ) {
            if ( columnName.equals( heading.getText().trim() ) ) {
                SMUtils.click( driver, heading );
                Log.message( "Clicked Column " + columnName );
                break;
            }
        }
        String state = getArrowStateOfColumn();
        if ( state.equals( Constants.DESCENDING ) ) {
            Log.fail( "The default sorting is not in ASCENDING Order" );
        }
        if ( sortingType.equals( Constants.DESCENDING ) ) {
            SMUtils.click( driver, arrowIcon );
            Log.message( "Clicked Arrow for Down" );
        }
    }

    /**
     * Check whether tooltip is displayed for IP Level column
     *
     * @return
     */
    public boolean isTooltipDisplayedForIp() {
        SMUtils.waitForElement( driver, ipLevelTooltip, 5 );
        return ipLevelTooltip.isDisplayed();
    }

    /**
     * To verify rectangular legends box is displayed or not
     */
    public boolean isDisplayedRectangularLgendsBox() {
        SMUtils.waitForElement( driver, rectangularLgendsBox );
        String message = SMUtils.isElementPresent( rectangularLgendsBox ) ? "Legends box is displayed" : "Legends box is not displayed";
        Log.message( message );
        return rectangularLgendsBox.isDisplayed();
    }

    /**
     *
     * To get all legend names.
     */
    public List<String> getLegendNames() throws Exception {

        List<String> legendsList = new ArrayList<>();
        legendNames.stream().forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( legendsList::add ) );
        Log.message( "got all the legends" + legendsList );
        return legendsList;
    }

    /**
     *
     * To verify zoom in pop up closed by clicking outside of the pop up.
     */
    public void clickOutside() {
        Actions action = new Actions( driver );
        action.moveByOffset( 3, 5 ).click().build().perform();
        Log.message( "successfully clicked outside of the zoom in pop up" );
    }

    /**
     *
     * To verify color of Print and edit Target button.
     */
    public boolean verifyColorPrintAndEditTarget() {
        WebElement printBtn = SMUtils.getWebElementDirect( driver, printIconHost, progressIconShadowRootCss );
        WebElement editTargetBtn = SMUtils.getWebElementDirect( driver, editTargetsBtnHost, clickViewSummaryBtnRoot );
        String backColorPrint = printBtn.getCssValue( "color" );
        String backColorEditTarget = editTargetBtn.getCssValue( "color" );
        String hexColorPrint = Color.fromString( backColorPrint ).asHex();
        String hexColorEditTarget = Color.fromString( backColorEditTarget ).asHex();
        Log.message( "Hex color of print and edit target is" + hexColorPrint + hexColorEditTarget );
        return hexColorPrint.equals( Constants.ZOOM_IN_TEXT_COLOR ) && hexColorEditTarget.equals( Constants.ZOOM_IN_TEXT_COLOR );
    }

    /**
     *
     * To verify color of show target link.
     */
    public boolean verifyColorShowTargetToggle() {
        String backColor = showtargetToggle.getCssValue( "color" );
        String hexColor = Color.fromString( backColor ).asHex();
        Log.message( "Hex color of show target is" + hexColor );
        return hexColor.equals( Constants.MATH_PERCENT_TEXT_COLOR );
    }

    /**
     * Verify the header "View Graph" is displayed in zoom in pop up.
     */
    public boolean isDisplayedProgressHeader() {
        SMUtils.waitForElement( driver, progressHeader, 6 );
        String message = SMUtils.isElementPresent( progressHeader ) ? "Progress header is displayed" : "Progress header is not displayed";
        Log.message( message );
        return SMUtils.isElementPresent( progressHeader );
    }

    /**
     * Check whether tooltip is displayed for Gain
     *
     * @return
     */
    public boolean isTooltipDisplayedForGain() {
        SMUtils.waitForElement( driver, gainTooltip, 5 );
        return gainTooltip.isDisplayed();
    }

    public String getactivePausedText() {
        SMUtils.waitForElement( driver, activePausedText, 5 );
        return activePausedText.getText();
    }

    /***
     * Get Delete Popup Text from Assignment Details page
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getTextFromDeleteAssignmentPopup() throws Exception {
        SMUtils.waitForElement( driver, deletePopupModalPopup, 10 );
        driver.switchTo().activeElement();
        return deletePopupTextList.stream().map( value -> value.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * Check delete Assignment option highlighted
     *
     */
    public boolean checkDeleteAssignmentHighlighted() {
        SMUtils.waitForElement( driver, dotEllipsisBesideAssignBtnGrandRoot, 10 );
        WebElement assignLevelEllipsis = SMUtils.getWebElementDirect( driver, dotEllipsisBesideAssignBtnGrandRoot, dotEllipsisBesideAssignBtnParent, dotEllipsisBesideAssignBtnChild );
        SMUtils.clickJS( driver, assignLevelEllipsis );
        SMUtils.waitForElement( driver, deleteAssignmentGrandRoot );
        WebElement deleteAssignmentTabParent = SMUtils.getWebElement( driver, deleteAssignmentGrandRoot, deleteAssignmentParent );
        WebElement deleteAssignmentTab = SMUtils.getWebElement( driver, deleteAssignmentTabParent, deleteAssignmentChild );
        String color = deleteAssignmentTab.getCssValue( "color" );
        SMUtils.moveToElementSelenium( driver, deleteAssignmentTab );
        String hovercolor = deleteAssignmentTab.getCssValue( "color" );
        Log.message( color );
        Log.message( hovercolor );
        return color.equals( hovercolor );
    }

    /**
     * Verify if text "Calendar Days" is center aligned with x- axis.
     */
    public boolean isCalenderTextCenterAligned() {
        SMUtils.waitForElement( driver, calenderDays, 8 );
        return ( SMUtils.verifyCssPropertyForElement( calenderDays, Constants.TEXT_ANCHOR, Constants.MIDDLE ) );
    }

    /**
     * Verify vertical alignment between "Progress" ,"View Graph" and "course
     * level" is proper.
     */
    public boolean isAlignmentOfProgressViewGraphCourseLevelProper( String browser ) {
        SMUtils.waitForElement( driver, viewGraph, 6 );
        SMUtils.waitForElement( driver, progressHeader, 6 );
        SMUtils.waitForElement( driver, courseLevelText, 6 );
        if ( browser.equalsIgnoreCase( Constants.CHROME ) ) {
            return ( SMUtils.verifyCssPropertyForElement( viewGraphDialogHeader, Constants.PADDING_LEFT, Constants.VIEW_GRAPH_LEFT_PADDING )
                    && SMUtils.verifyCssPropertyForElement( progressDialogHeader, Constants.MARGIN_LEFT, Constants.PROGRESS_MARGIN_LEFT ) && SMUtils.verifyCssPropertyForElement( courseLevelText, Constants.TEXT_ALIGN, Constants.LEFT ) );
        } else {
            return ( SMUtils.verifyCssPropertyForElement( viewGraphDialogHeader, Constants.PADDING_LEFT, Constants.VIEW_GRAPH_LEFT_PADDING )
                    && SMUtils.verifyCssPropertyForElement( progressDialogHeader, Constants.MARGIN_LEFT, Constants.PROGRESS_MARGIN_LEFT_SAFARI ) && SMUtils.verifyCssPropertyForElement( courseLevelText, Constants.TEXT_ALIGN, Constants.LEFT ) );
        }
    }

    /**
     * Verify vertical alignment between "Close button" and "Print" is as per
     * UX.
     *
     */
    public boolean isCloseButtonAndPrintVerticallyAligned() {
        return ( SMUtils.verifyCssPropertyForElement( closeButton, Constants.TEXT_ALIGN, Constants.CENTER ) && SMUtils.verifyCssPropertyForElement( print, Constants.TEXT_ALIGN, Constants.CENTER ) );
    }

    /**
     * Verify the space between "Course level" and Y-axis is proper as per UX.
     */
    public boolean isSpacingBetCourseLevelAndYAxisProper() {
        return ( SMUtils.verifyCssPropertyForElement( courseLevelText, Constants.TRANSFORM_ORIGIN, Constants.TRANSFORM_ORIGIN_VALUE ) && SMUtils.verifyCssPropertyForElement( yAxis, Constants.TRANSFORM_ORIGIN, Constants.TRANSFORM_ORIGIN_VALUE ) );

    }

    /**
     * Verify spacing between "show target" and "toggle button" is as per UX.
     *
     */
    public boolean isSpacingBetShowTargetAndToggleBtnProper() {
        return ( SMUtils.verifyCssPropertyForElement( showTargetLink, Constants.PADDING_RIGHT, Constants.NAME_TOP_SPACING_VALUE )
                && SMUtils.verifyCssPropertyForElement( showtargetToggle, Constants.PADDING_LEFT, Constants.SHOW_TARGET_TOGGLE_PADDING_LEFT ) );
    }

    /*
     * To verify whether the horizontal line is present between the names
     *
     * @return boolean
     */

    public boolean isHorizonalLinePresent() {
        SMUtils.waitForElement( driver, viewGrapHeaderBox );
        Log.message( "Border bottom color is " + Color.fromString( viewGrapHeaderBox.getCssValue( "border-bottom-color" ) ).asHex() );
        return ( Color.fromString( viewGrapHeaderBox.getCssValue( "border-bottom-color" ) ).asHex().equalsIgnoreCase( Constants.DARK_GRAY_HEX ) );
    }

    /**
     * To verifyPadding of View Graph area
     *
     * @return boolean
     */

    public boolean paddingOfViewGraph( String browser ) {
        Log.message( "To check the height, width, X & Y axis area of Graph area is as expected" );
        Boolean paddingOfViewGraph;
        if ( browser.toLowerCase().contains( "safari" ) ) {
            paddingOfViewGraph = zoomInGrapArea.getCssValue( "height" ).contains( Constants.HEIGHT_OF_VIEW_GRAP_ZOOM_IN_MAC ) && zoomInGrapArea.getCssValue( "width" ).contains( Constants.WIDTH_OF_VIEW_GRAP_ZOOM_IN_MAC )
                    && zoomInGrapArea.getCssValue( "x" ).contains( Constants.X_AXIS_LENGTH_ZOOM_IN_MAC ) && zoomInGrapArea.getCssValue( "y" ).contains( Constants.Y_AXIS_LENGTH_ZOOM_IN_MAC );
        } else {
            paddingOfViewGraph = zoomInGrapArea.getCssValue( "height" ).contains( Constants.HEIGHT_OF_VIEW_GRAP_ZOOM_IN ) && zoomInGrapArea.getCssValue( "width" ).contains( Constants.WIDTH_OF_VIEW_GRAP_ZOOM_IN )
                    && zoomInGrapArea.getCssValue( "x" ).contains( Constants.X_AXIS_LENGTH_ZOOM_IN ) && zoomInGrapArea.getCssValue( "y" ).contains( Constants.Y_AXIS_LENGTH_ZOOM_IN );
        }
        return paddingOfViewGraph;
    }

    /**
     * To verify position of last date on X axis in graph
     *
     * @return boolean
     */

    public boolean positionOfLastDateInXAxis() {
        Log.message( "To check Position of last date displayed on X-Axis" );
        return ( dateValuesXAxis.stream().sorted( ( a, b ) -> -1 ).findFirst().get().getCssValue( "transform" ).contains( Constants.LAST_DATE_X_AXIS_TRANSFORM_ORIGIN_VAUE ) );
    }

    /**
     * To verify position of Target Date line on X axis in graph gainValueZoomIn
     *
     * @return boolean
     */

    public boolean isTargetLinePresent() {
        Log.message( "To check Position of Target line on X-Axis" );
        return ( SMUtils.isElementPresent( viewGraphTargetLine.stream().sorted( ( a, b ) -> -1 ).findFirst().get() )
                && Color.fromString( viewGraphTargetLine.stream().sorted( ( a, b ) -> -1 ).findFirst().get().getCssValue( "stroke" ) ).asHex().contains( Constants.TARGET_LINE_ZOOM_IN ) );
    }

    /**
     * To verify position of first date on X axis in graph
     *
     * @return boolean
     */

    public boolean isFirstDatePresent() {
        Log.message( "To check Position of First date displayed on X-Axis" );
        return ( SMUtils.isElementPresent( firstDateOnXAxis.stream().findFirst().get() ) );
    }

    /**
     * To verify presence of Gain Zoom In popup
     *
     * @return boolean
     */

    public boolean isGainPresent() {
        Log.message( "To check Position of last date displayed on X-Axis" );
        return ( SMUtils.isElementPresent( gainValueZoomIn.stream().sorted( ( a, b ) -> -1 ).findFirst().get() ) );
    }

    /**
     * To verify Position of Legend Image Zoom IN legendImageZoomIn
     *
     * @return boolean
     */

    public boolean positionOfLegendImageZoomIn() {
        Log.message( "To check the height, width, X & Y axis area of Legend Image" );
        return ( legendImageZoomIn.stream().sorted( ( a, b ) -> -1 ).findFirst().get().getCssValue( "height" ).contains( Constants.HEIGHT_OF_LEGEND_IMAGE_ZOOM_IN )
                && legendImageZoomIn.stream().sorted( ( a, b ) -> -1 ).findFirst().get().getCssValue( "x" ).contains( Constants.X_AXIS_LENGTH_LEGEND_IMAGE )
                && legendImageZoomIn.stream().sorted( ( a, b ) -> -1 ).findFirst().get().getCssValue( "y" ).contains( Constants.Y_AXIS_LENGTH_LEGEND_IMAGE ) );
    }

    /**
     * To verify position of Course Level Text in Y Axis
     *
     * @return boolean
     */

    public boolean positionOfCourseLevelTextOnYAxis() {
        Log.message( "To check Position of Course Level" );
        return ( courseLevelText.getCssValue( "transform" ).contains( Constants.LAST_DATE_X_AXIS_TRANSFORM_ORIGIN_VAUE ) );
    }

    /**
     *
     * To verify Assignment Button Color
     */

    public void verifyassignButtonColor() {
        WebElement assignButton = SMUtils.getWebElement( driver, assignBtnAssignmentlistRoot, assignBtnChild );
        String buttonColor = assignButton.getCssValue( "color" );
        String colorFormatName = Color.fromString( buttonColor ).asHex();
        String expectedValue = Constants.READ_PERCENT_TEXT_COLOR;
        if ( colorFormatName.matches( expectedValue ) ) {
            Log.pass( "Assign Button color is   displayed in the Blue color" );
        } else {
            Log.fail( "AssignButton color is not displayed in the Blue color" );
        }

    }

    /**
     *
     * To verify Assignment Settings Label
     */
    public List<String> getAssignWidget( String browser ) throws Exception {
        SMUtils.waitForElement( driver, assignBtnAssignmentlistRoot, 10 );
        List<String> assignmentSettings = assignmentSettingValues.stream().map( value -> value.getText().trim() ).collect( Collectors.toList() );
        // get header names
        if ( !browser.contains( "Safari" ) ) {
            SMUtils.waitForElement( driver, assignBtnAssignmentlistRoot, 10 );
            Log.message( "Got all Headers from View Assignment Settings chrome" );
            Log.assertThat( ( assignmentSettings.toString() ).equalsIgnoreCase( Constants.ASSIGNMENT_SETTINGS.toString() ), "Assignment Setting Labels are displayed successfully", "Assignment Setting Labels are not displayed correctly" );
        } else if ( browser.contains( "Safari" ) ) {
            SMUtils.waitForElement( driver, assignBtnAssignmentlistRoot, 10 );
            assignmentSettings.replaceAll( String::toUpperCase );
            Log.message( "Got all Headers from View Assignment Settings Safari" );
            Log.assertThat( ( assignmentSettings.toString() ).equalsIgnoreCase( Constants.ASSIGNMENT_SETTINGS_SAFARI.toString() ), "Assignment Setting Labels are displayed successfully", "Assignment Setting Labels are not displayed correctly" );

        }
        return assignmentSettings;
    }

    /**
     * Click Delete Assignment tab at Assignment Level
     *
     * @throws Exception
     */
    public boolean verifyColorCodeFordeleteAssignmentButton() throws Exception {
        boolean status = false;
        SMUtils.waitForElement( driver, deleteAssignmentsDeleteBtn );
        WebElement deleteAssignmentBtn = SMUtils.getWebElement( driver, deleteAssignmentsDeleteBtn, deleteAssignmentDeleteChild );
        status = SMUtils.checkBackgroundColor( deleteAssignmentBtn, Constants.BUTTON_COLOR_CODE );
        return status;
    }

    /**
     * To verify the color code for Remove button in Remove Student from
     * Assignment popup
     *
     * @throws Exception
     */
    public boolean verifyColorCodeRemoveBtnForAssignment() throws Exception {
        boolean status = false;
        SMUtils.waitForElement( driver, removeButtonOnpopupRoot );
        WebElement removebtn = SMUtils.getWebElement( driver, removeButtonOnpopupRoot, removebuttonchild );
        status = SMUtils.checkBackgroundColor( removebtn, Constants.BUTTON_COLOR_CODE );
        return status;

    }

    /**
     *
     * To verify values format in view summary
     */

    public void valuesFormatCheckingnotstartFocus() throws Exception {
        try {
            HashMap<String, String> summaryMap = new HashMap<>();
            SMUtils.waitForElement( driver, viewSummaryRoot, 10 );

            IntStream.range( 0, viewSummaryList.size() ).forEach( index -> summaryMap.computeIfAbsent( viewSummaryList.get( index ).getText().trim(), k -> viewSummaryNameValues.get( index ).getText().trim() ) );

            Log.message( "Verify Defaulty Coursed doesnot start" );
            for ( Map.Entry<String, String> set : summaryMap.entrySet() ) {
                String summaryLabelm = set.getKey();
                String summaryValuem = set.getValue();

                if ( Constants.VIEW_SUMMARY_FORMAT_FOCUS_NOTSTART.contains( summaryLabelm ) ) {
                    verifyValuesformatnotstartFocusa( summaryLabelm, summaryValuem );
                } else if ( summaryLabelm.matches( "Last Session Date" ) ) {
                    boolean value = verifyValuesformatnotstart( summaryValuem );
                    Log.assertThat( value, "Last Session  date not start format value displayed sucessfully", "Last Session Date format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Total Sessions" ) ) {
                    boolean value = isIntegerValue( summaryValuem );
                    Log.assertThat( value, "Total Sessions format value displayed sucessfully", "Total Sessions format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Total Time Spent" ) ) {
                    boolean value = verifyTimeformat( summaryValuem );
                    Log.assertThat( value, "Total Time Spent format value displayed sucessfully", "Total Time Spent format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Avg. Session Time" ) ) {
                    boolean value = verifyTimeformat( summaryValuem );
                    Log.assertThat( value, "Avg. Session Time format value displayed sucessfully", "Avg. Session Time format value is not displayed properly" );
                }

            }
        } catch ( Exception e ) {
            Log.exception( e );
        }
    }

    /**
     *
     * To verify not start Format for Focus Courses
     */

    public boolean verifyValuesformatnotstartFocus( String stringToCheck ) {
        return stringToCheck.matches( Constants.NOTAPPLICABLE );
    }

    /**
     *
     * To verify not start Format for Default Courses
     */
    public boolean verifyValuesformatnotstart( String stringToCheck ) {
        return stringToCheck.matches( Constants.BLANKVALUE );
    }

    /**
     *
     * To verify time format
     */
    public boolean verifyTimeformat( String stringToCheck ) {
        return stringToCheck.matches( Constants.TIME_FORMAT );
    }

    /**
     *
     * To verify values student does not start default courses in view summary
     */
    public void valuesFormatCheckingnotstart() throws Exception {
        try {
            HashMap<String, String> summaryMap = new HashMap<>();
            SMUtils.waitForElement( driver, viewSummaryRoot, 20 );

            IntStream.range( 0, viewSummaryList.size() ).forEach( index -> summaryMap.computeIfAbsent( viewSummaryList.get( index ).getText().trim(), k -> viewSummaryNameValues.get( index ).getText().trim() ) );

            Log.message( "VErify Defaulty Coursed doesnot start" );
            for ( Map.Entry<String, String> set : summaryMap.entrySet() ) {
                String summaryLabelm = set.getKey();
                String summaryValuem = set.getValue();

                if ( Constants.VIEW_SUMMARY_FORMAT_NOTSTART.contains( summaryLabelm ) ) {
                    verifyValuesformatnotstarta( summaryLabelm, summaryValuem );
                } else if ( summaryLabelm.matches( "Assigned Level" ) ) {
                	 Log.message(summaryValuem);
                    boolean value = verifyDecimalformat( summaryValuem );
                    Log.assertThat( value, "Assigned Level format value displayed sucessfully", "Assigned Level format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Total Sessions" ) ) {
                    boolean value = isIntegerValue( summaryValuem );
                    Log.assertThat( value, "Total Sessions format value displayed sucessfully", "Total Sessions format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Sessions Since IP" ) ) {
                    boolean value = isIntegerValue( summaryValuem );
                    Log.assertThat( value, "Sessions Since IP format value displayed sucessfully", "Sessions Since IP format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Total Time Spent" ) ) {
                    boolean value = verifyTimeformat( summaryValuem );
                    Log.assertThat( value, "Total Time Spent format value displayed sucessfully", "Total Time Spent format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Avg. Session Time" ) ) {
                    boolean value = verifyTimeformat( summaryValuem );
                    Log.assertThat( value, "Avg. Session Time format value displayed sucessfully", "Avg. Session Time format value is not displayed properly" );
                }

            }
        } catch ( Exception e ) {
            Log.exception( e );
        }
    }

    /**
     *
     * To verify primary and secondary value
     */
    public void calculationPrimarySecondary() {
        String assignedValue = null;
        String ipValue = null;
        String primaryValue = null;
        String secondaryValue = null;

        HashMap<String, String> summaryMap = new HashMap<>();
        SMUtils.waitForElement( driver, viewSummaryRoot, 10 );

        IntStream.range( 0, viewSummaryList.size() ).forEach( index -> summaryMap.computeIfAbsent( viewSummaryList.get( index ).getText().trim(), k -> viewSummaryNameValues.get( index ).getText().trim() ) );

        for ( Map.Entry<String, String> set : summaryMap.entrySet() ) {
            String summaryLabelm = set.getKey();
            String summaryValuem = set.getValue().trim();
            if ( summaryLabelm.matches( "Assigned Level" ) ) {
                assignedValue = summaryValuem;
            } else if ( summaryLabelm.matches( "IP Level" ) ) {
                ipValue = summaryValuem;
            } else if ( summaryLabelm.matches( "Primary Target" ) ) {
                primaryValue = summaryValuem;
            } else if ( summaryLabelm.matches( "Secondary Target" ) ) {
                secondaryValue = summaryValuem;
            }

        }

        double primaryValuef = Float.parseFloat( primaryValue );
        double secondaryValuef = Float.parseFloat( secondaryValue );
        double assignedValuef = Float.parseFloat( assignedValue );
        double ipValuef = Float.parseFloat( ipValue );

        double primaryValueResult = assignedValuef + 1;
        double secondaryValueResult = ipValuef + 1;
        double maxValue = 7.50;
        if ( assignedValuef <= maxValue ) {
            if ( Double.compare( primaryValuef, primaryValueResult ) == 0 ) {
                Log.message( "Expected Primary Target Value displayed successfully" );
            } else {
                Log.fail( "Expected Primary Target Value is not displayed" );
            }
        } else {
            Log.message( "Expected Primary Target Value is Max value displayed successfully" );
        }

        if ( ipValuef <= maxValue ) {
            if ( Double.compare( secondaryValuef, secondaryValueResult ) == 0 ) {
                Log.message( "Expected Secondary Target Value displayed successfully" );
            } else {
                Log.fail( "Expected Secondary Target Value is not displayed" );
            }
        } else {
            Log.message( "Expected Secondary Target Value is Max value displayed successfully" );
        }

    }

    /**
     *
     * To verify Date Format
     */
    public boolean verifyDateformat( String stringToCheck ) {
        return stringToCheck.matches( Constants.DATE_FORMAT );
    }

    /**
     * To check Last Session Level value displayed for a student
     */
    public String lastSessionDateValueChecking( String firstStudent ) {
        String lastSessionDate = null;
        SMUtils.waitForElement( driver, studentTable, 5 );
        for ( WebElement tableRow : studentTableRow ) {
            String studentName = tableRow.findElements( By.cssSelector( childElementStudentNameAssignmentDetailsTable ) ).get( 0 ).getText().trim();
            if ( studentName.equals( firstStudent ) ) {
                lastSessionDate = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 1 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText();
                Log.message( "Last Session for " + studentName + " is: " + lastSessionValues.getText().trim() );
                if ( lastSessionValues.getText().trim().equals( Constants.NOT_STARTED_VALUE ) ) {
                    Log.message( "Last Session Date for " + studentName + " who has not started assignment is: " + lastSessionDate );
                } else {
                    Log.message( "Last Session Date for " + studentName + " who has started assignment is: " + lastSessionDate );
                }
            }
        }
        String outPutvalue = lastSessionDate.substring( 0, 10 );
        return outPutvalue.trim();
    }

    /**
     *
     * To verify view summary values match with the assignment page
     */

    public void viewSummaryvalCheckAsgmt( String label, String labelValue ) throws Exception {
        try {
            HashMap<String, String> summaryMap = new HashMap<>();
            SMUtils.waitForElement( driver, viewSummaryRoot, 10 );

            IntStream.range( 0, viewSummaryList.size() ).forEach( index -> summaryMap.computeIfAbsent( viewSummaryList.get( index ).getText().trim(), k -> viewSummaryNameValues.get( index ).getText().trim() ) );

            for ( Map.Entry<String, String> set : summaryMap.entrySet() ) {
                String summaryLabelm = set.getKey();
                String summaryValuem = set.getValue().trim();
                if ( summaryLabelm.matches( label ) ) {
                    if ( labelValue.matches( summaryValuem ) ) {
                        Log.pass( "Assignment of " + label + " value matched with the View Summary successfully " + label + " Value" );
                    } else {
                        Log.fail( "Assignment of " + label + "value not matched with the View Summary  " + label + " Value" );
                    }
                }
            }

        } catch ( Exception e ) {
            Log.exception( e );
        }
    }

    /**
     *
     * To Verify links color
     */
    public void verifyLinksColorSummary() {
        String viewlinkColor = viewSummaryRoot.getCssValue( "color" );
        String editlinkColor = editTargets.getCssValue( "color" );
        String printlinkColor = print.getCssValue( "color" );
        String colorFormatview = Color.fromString( viewlinkColor ).asHex();
        String colorFormatedit = Color.fromString( editlinkColor ).asHex();
        String colorFormatprint = Color.fromString( printlinkColor ).asHex();
        if ( colorFormatview.matches( Constants.ZOOM_IN_TEXT_COLOR ) ) {
            Log.pass( "View Summary link is  displayed in the Blue color" );
        } else {
            Log.fail( "View Summary link is not displayed in the Blue color" );
        }
        if ( colorFormatedit.matches( Constants.ZOOM_IN_TEXT_COLOR ) ) {
            Log.pass( "Edit link is  displayed in the Blue color" );
        } else {
            Log.fail( "Edit link is not displayed in the Blue color" );
        }

        if ( colorFormatprint.matches( Constants.ZOOM_IN_TEXT_COLOR ) ) {
            Log.pass( "Print link is  displayed in the Blue color" );
        } else {
            Log.fail( "Print link is not displayed in the Blue color" );
        }

    }

    /**
     *
     * To verify Bold Text
     */
    public void fontBold( String browser ) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        for ( WebElement textBold : viewSummaryHeaders ) {
            String value = textBold.getText();
            String fontWeight = (String) js.executeScript( "return getComputedStyle(arguments[0]).getPropertyValue('font-Weight');", textBold );
            if ( !browser.contains( "Safari" ) ) {
                if ( fontWeight.trim().equals( Constants.PROGRESS_TEXT_FONT_WEIGHT ) ) {
                    Log.pass( value + "is displayed in Bold Sucessfully" );
                } else {
                    Log.fail( value + "not displayed Bold - " + fontWeight );
                }
            } else if ( browser.contains( "Safari" ) )// Verifying the font is bold in Safari browser
            {
                if ( fontWeight.trim().equals( Constants.BOLD ) ) {
                    Log.pass( value + "is displayed in Bold Sucessfully" );
                } else {
                    Log.fail( value + "not displayed Bold - " + fontWeight );
                }
            }

        }

    }

    /**
     *
     * To verify Sub heading color in view summary
     */

    public void subheadingsColor() {
        String expectedColor = Constants.VIEW_SUMMARY_SUBHEADING_COLOR;
        for ( WebElement colorText : viewSummaryList ) {
            String value = colorText.getCssValue( "color" );
            String sumHeading = colorText.getText();
            String colorFormatsumHeading = Color.fromString( value ).asHex();

            if ( colorFormatsumHeading.matches( expectedColor ) ) {
                Log.pass( sumHeading + " color is displayed expected sucessfully" );
            } else {
                Log.fail( sumHeading + " color is not displayed expected " );
            }

        }

        for ( WebElement colorTexta : viewSummaryNameValues ) {
            String valuea = colorTexta.getCssValue( "color" );
            String sumValue = colorTexta.getText();
            String colorFormatName = Color.fromString( valuea ).asHex();
            if ( colorFormatName.matches( expectedColor ) ) {
                Log.pass( sumValue + " color is displayed expected sucessfully" );
            } else {
                Log.fail( sumValue + " color is not displayed expected " );
            }
        }
    }

    /**
     *
     * To verify values Custom course IP OFf courses in view summary
     */
    public void valuesFormatCheckingcustomIPoff() throws Exception {
        try {
            HashMap<String, String> summaryMap = new HashMap<>();
            SMUtils.waitForElement( driver, viewSummaryRoot, 10 );
            IntStream.range( 0, viewSummaryList.size() ).forEach( index -> summaryMap.computeIfAbsent( viewSummaryList.get( index ).getText().trim(), k -> viewSummaryNameValues.get( index ).getText().trim() ) );

            Log.message( "Verify Custom Course IP Off" );
            for ( Map.Entry<String, String> set : summaryMap.entrySet() ) {
                String summaryLabelm = set.getKey();
                String summaryValuem = set.getValue();
                if ( Constants.VIEW_SUMMARY_FORMAT_FOCUS.contains( summaryLabelm ) ) {
                    verifyValuesformatnotstartFocusa( summaryLabelm, summaryValuem );
                } else if ( summaryLabelm.matches( "Assigned Level" ) ) {
                    boolean value = verifyDecimalformat( summaryValuem );
                    Log.assertThat( value, "Assigned Level format value displayed sucessfully", "Assigned Level format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Current Level" ) ) {
                    boolean value = verifyDecimalformat( summaryValuem );
                    Log.assertThat( value, "Current Level format value displayed sucessfully", "Current Level format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Gain" ) ) {
                    boolean value = verifyDecimalformat( summaryValuem );
                    Log.assertThat( value, "Gain format value displayed sucessfully", "Gain format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Last Session Date" ) ) {
                    boolean value = verifyDateformat( summaryValuem );
                    Log.assertThat( value, "Last Session  date  format value displayed sucessfully", "Last Session Date format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Total Sessions" ) ) {
                    boolean value = isIntegerValue( summaryValuem );
                    Log.assertThat( value, "Total Sessions format value displayed sucessfully", "Total Sessions format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Total Time Spent" ) ) {
                    boolean value = verifyTimeformat( summaryValuem );
                    Log.assertThat( value, "Total Time Spent format value displayed sucessfully", "Total Time Spent format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Avg. Session Time" ) ) {
                    boolean value = verifyTimeformat( summaryValuem );
                    Log.assertThat( value, "Avg. Session Time format value displayed sucessfully", "Avg. Session Time format value is not displayed properly" );
                }

            }
        } catch ( Exception e ) {
            Log.exception( e );
        }
    }

    /**
     *
     * To verify Default course in view summary
     */
    public void valuesFormatCheckingDefaultIP() throws Exception {
        try {
            HashMap<String, String> summaryMap = new HashMap<>();
            SMUtils.waitForElement( driver, viewSummaryRoot, 10 );

            IntStream.range( 0, viewSummaryList.size() ).forEach( index -> summaryMap.computeIfAbsent( viewSummaryList.get( index ).getText().trim(), k -> viewSummaryNameValues.get( index ).getText().trim() ) );

            Log.message( "Verify In-IP status" );
            for ( Map.Entry<String, String> set : summaryMap.entrySet() ) {
                String summaryLabelm = set.getKey();
                String summaryValuem = set.getValue();

                if ( Constants.VIEW_SUMMARY_FORMAT_IP.contains( summaryLabelm ) ) {
                    verifyValuesInIPCoursesa( summaryLabelm, summaryValuem );
                } else if ( summaryLabelm.matches( "Assigned Level" ) ) {
                    boolean value = verifyDecimalformat( summaryValuem );
                    Log.assertThat( value, "Assigned Level format value displayed sucessfully", "Assigned Level format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Last Session Date" ) ) {
                    boolean value = verifyDateformat( summaryValuem );
                    Log.assertThat( value, "Last Session  date  format value displayed sucessfully", "Last Session Date format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Total Sessions" ) ) {
                    boolean value = isIntegerValue( summaryValuem );
                    Log.assertThat( value, "Total Sessions format value displayed sucessfully", "Total Sessions format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Sessions Since IP" ) ) {
                    boolean value = isIntegerValue( summaryValuem );
                    Log.assertThat( value, "Sessions Since IP format value displayed sucessfully", "Sessions Since IP format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Total Time Spent" ) ) {
                    boolean value = verifyTimeformat( summaryValuem );
                    Log.assertThat( value, "Total Time Spent format value displayed sucessfully", "Total Time Spent format value is not displayed properly" );
                } else if ( summaryLabelm.matches( "Avg. Session Time" ) ) {
                    boolean value = verifyTimeformat( summaryValuem );
                    Log.assertThat( value, "Avg. Session Time format value displayed sucessfully", "Avg. Session Time format value is not displayed properly" );
                }

            }
        } catch ( Exception e ) {
            Log.exception( e );
        }
    }

    /**
     *
     * To verify IN IP values of Courses
     */
    public boolean verifyValuesInIPCourses( String stringToCheck ) {
        return stringToCheck.matches( Constants.INIP );
    }

    /**
     *
     * To verify IN IP format values of Courses
     */
    public void verifyValuesInIPCoursesa( String sumLabel, String sumValue ) {
        boolean valueIP = sumValue.matches( Constants.INIP );
        Log.assertThat( valueIP, sumLabel + " format value displayed sucessfully", sumLabel + " format value is not displayed properly" );
    }

    /**
     *
     * To verify Not Start Focus format values of Courses
     */
    public void verifyValuesformatnotstartFocusa( String sumLabel, String sumValue ) {
        boolean value = sumValue.matches( Constants.NOTAPPLICABLE );
        Log.assertThat( value, sumLabel + " format value displayed sucessfully", sumLabel + " format value is not displayed properly" );

    }

    /**
     *
     * To verify Not Start Courses format values
     */
    public void verifyValuesformatnotstarta( String sumLabel, String sumValue ) {
        boolean value = sumValue.matches( Constants.BLANKVALUE );
        Log.assertThat( value, sumLabel + " format value displayed sucessfully", sumLabel + " format value is not displayed properly" );
    }

    /**
     *
     * To get all the values of student from assignment details page
     */

    public Map<String, String> getStudentAssignmentDetailsPageValues( String firstName, String middleName, String secondName ) {
        String tooltipText = null;
        if ( middleName == null ) {
            tooltipText = firstName + " " + secondName;
        } else {
            tooltipText = firstName + " " + middleName + " " + secondName;
        }
        SMUtils.waitForElement( driver, studentTable, 3 );
        Map<String, String> studentIPandGain = new HashMap<>();
        for ( WebElement tableRow : studentTableRow ) {
            String studentName = tableRow.findElements( By.cssSelector( childElementStudentNameAssignmentDetailsTable ) ).get( 0 ).getText().trim();
            if ( studentName.equals( tooltipText ) ) {
                studentIPandGain.put( "Name", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 0 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "Last session", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 1 ).findElement( By.cssSelector( labelLastSession ) ).getText() );
                studentIPandGain.put( "IP Level", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 2 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "Assigned Level", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 3 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "Current Level", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 4 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "Gain", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 5 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "% Correct", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 6 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                break;
            }
        }
        return studentIPandGain;
    }

    /**
     * To get the state of Arrow UP or Down
     *
     * @return
     */
    public String getArrowStateOfnameColumn() {
        String status = nameSortingCheck.getAttribute( "name" );
        if ( status.equals( arrowUp ) ) {
            return Constants.ASCENDING;
        } else if ( status.equals( arrowDown ) ) {
            return Constants.DESCENDING;
        } else {
            Log.fail( "Arrow icon is not found" );
            return null;
        }
    }

    /**
     * To verify Toggle is ON/OFF
     *
     * @param toggleName, status
     */
    public String getTheStatusOfTheToggle( String toggleName, String status ) {
        SMUtils.waitForLocator( driver, By.cssSelector( settingLabel ), 5 );
        toggleStatus = null;
        try {
            singleColumnElements.stream().distinct().forEach(
                    element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element.findElement( By.cssSelector( settingLabel ) ), driver ) ).filter( elementText -> elementText.equalsIgnoreCase( toggleName ) ).ifPresent( elementFinalText -> {
                        if ( elementFinalText.equalsIgnoreCase( toggleName ) ) {
                            if ( status.equalsIgnoreCase( Constants.ON_CAPS ) ) {
                                element.findElement( By.cssSelector( toggleOnButton ) ).isDisplayed();
                                Log.message( toggleName + " is visiable as ON" );
                                toggleStatus = Constants.ON_CAPS;
                            } else {
                                element.findElement( By.cssSelector( toggleOffButton ) ).isDisplayed();
                                Log.message( toggleName + " is visible as OFF" );
                                toggleStatus = Constants.OFF_CAPS;
                            }
                        }
                    } ) );
        } catch ( Exception e ) {
            Log.message( "Hidden row detected." );
        }
        return toggleStatus;
    }
    
    public void removeStudentFromCourse() {
        SMUtils.waitForElement( driver, removeCourseButton );
    	SMUtils.click(driver, removeCourseButton); 
	}
    
    /**
     * To check the availability of cancel button in the Remove student popup
     */   
    public boolean checkRemoveStudent() {
        try {
            SMUtils.waitForElement( driver, removeCourseButton );
            return removeCourseButton.isDisplayed();
        } catch ( Exception e ) {
            return false;
        }
    }
    public void closeButton() {
       SMUtils.waitForElement(driver, closeButtonElement);
       SMUtils.click(driver, closeButtonElement);
	}
}

