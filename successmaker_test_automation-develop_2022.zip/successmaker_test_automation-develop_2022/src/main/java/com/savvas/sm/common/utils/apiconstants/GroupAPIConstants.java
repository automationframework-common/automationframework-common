package com.savvas.sm.common.utils.apiconstants;

import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

public interface GroupAPIConstants {

    public interface CreateGroupAPIConstants {
        //End points

        public static String CREATE_GROUP_API = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/groups/students";
        public static String GET_CLASS_CMS = "/roster-service/v1/sections/%s";
        public static String UPDATE_GROUP_API = "/lms/web/api/v1/groups/{group_id}";
        public static String DELETE_CLASS_CMS = "/roster-service/v2/sections/%s";
        public static String STUDENTS_NOT_PARTOF_GROUP = "/lms/web/api/v1/staffs/{teacher_id}/students";

        //Fields
        public static String GROUP_ID = "groupId";
        public static String GROUP_NAME = "groupName";
        public static String GROUP_OWNER_ORG_ID = "groupOwnerOrgId";
        public static String ORGANIZATION_ID = "organizationId";
        public static String GROUP_OWNER_ID = "groupOwnerId";
        public static String STUDENT_RUMBA_IDS = "studentRumbaIds";
        public static String INVALID_TEACHER = "INVALID_TEACHER";
        public static String INVALID_ORG = "INVALID_ORG";
        public static String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
        public static String ROSTER_STUDID = "roster,studentIds";
        public static String DATA_GROUPOWNER_ORGID = "data,groupOwnerOrgId";
        public static String DATA_GROUP_NAME = "data,groupName";
        public static String DATA_GROUP_ID = "data,groupId";
        public static String DATA_GROUP_OWNER_ID = "data,groupOwnerId";
        public static String DATA_STUDENTRUMBA_IDS = "data,studentRumbaIds";
        public static String ROSTER_CLASS_ID = "roster,classId";
        public static String ROSTER_CLASS_NAME = "roster,className";
        public static String ROSTER_ORG_ID = "roster,organizationId";
        public static String ROSTER_TEACHER_ID = "roster,teacherIds";
        public static String CREATE_GROUP_API_PAYLOAD = "createGroupAPIPayload";
        public static String INVALID_ORGID_MESSAGE = "OrgId: ABCD from request URI does not present in OrgIds: [" + RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) + "] from request header";
        public static String INVALID_TEACHER_MESSAGE = "Login UserId / Request User Id mismatch";
        public static String OTHER_ORGID_MESSAGE = "Student Not Found";

        public static String INVALID_ORGID_MESSAGE2 = "OrgId: ABCD from request URI does not present in OrgIds: [" + RBSDataSetup.organizationIDs.get( school ) + "] from request header";

        public static String EMPTY_VALUE = " ";
        public static String GET_GROUP_LIST_FOR_TEACHERID_NEW_API = "/lms/web/api/v1/users/{userId}/groups";

        //UPDATE GROUP
        public static String INVALID_GROUP_ID = "INVALID_GROUPID";
        public static String INVALID_GROUP_NAME = "INVALID_GROUPNAME";
        public static String INVALID_GROUP_OWNER_ID = "INVALID_GROUPOWNER_ID";
        public static String GROUP_NAME_WITH_MAX = "75nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn";
        public static String GROUP_NAME_WITH_MIN = "SME";
        public static String ROSTER_SERVICE = "roster_service";
        // public static String MULTI_TEACHER_STRING = "";
        public static String CREATE_GRP_PAYLOAD_NAME2 = "createGroupAPIPayload2.json";
        public static String UPDATED_NAME_GRP = "updated name";
        public static String UPDATED = "UPDATED";
        public static String DATA = "data";
        public static String SECTION = "section";
        public static String ID = "id";

        public static String CREATE_GROUP_API_NEW = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/groups/students";
        public static String ASSIGN_COURSE_GROUP = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/assign";
        public static String GROUP_ASSIGNMENT_SETTINGS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/groups/{groupId}/courseassignments/{courseId}/settings";
    }

    public interface getGroupListAPIConstants {
        public static String GET_GROUP_LIST_FOR_STUDENT_API = "/lms/web/api/v1/users/%s/groups";
        public static String STAFF_ID = "staffId";
        public static String STUDENT_ID = "studentId";
        public static String USER_ID = "userId";

        public static String GET_GROUP_LIST_CMS = "/cms/v1/students/%s/sections";
        public static String INVALID_STUDENT = "INVALID_STUDENT";
        public static String STUDENT_COUNT = "studentCount";
        public static String ORG_ID = "orgId";
        public static String INVALID_INPUT = "ABCD";

    }

    public interface RemoveStudentsFromGroupsAPIConstants {
        public static String ENDPOINT = "/lms/web/api/v1/organizations/orgId/staffs/staffId/groups/students";
        public static String ORG_ID = "orgId";
        public static String STAFF_ID = "staffId";
        public static String STUDENT_IDS = "studentIds";
        public static String GROUP_IDS = "groupIds";
        public static String STUDENT_IDS_VALUE = "studentIdsValue";
        public static String GROUP_IDS_VALUE = "groupIdsValue";
        public static String ORG_ID_HEADER = "org-Id";
        public static String USER_ID_HEADER = "user-Id";
    }

    public interface DeleteGroupAPIConstants {
        public static String ENDPOINT = "/lms/web/api/v1/groups/groupId";
        public static String SECTION_ID_NOT_FOUND_MESSAGE = "Section id not found";
        
        //  Field Names
        public static String GROUP_ID_FIELD = "groupId";
        public static String USER_ID_FIELD = "user-id";
        public static String ORG_ID_FIELD = "org-id";
        public static String BODY_FIELD = "body";
        public static String BODY_DATA_FIELD = "body,data";
        public static String STATUSCODE_FIELD = "StatusCode";
        public static String MESSAGE_FIELD = "message";
        public static String GC_USER_BASIC = "demo_gc_teacher01";
        public static String GC_USER_ID_BASIC = "ffffffff62669a5618146a002fd52dd6";
        public static String GC_SCHOOL_BASIC = "8a72019a7f90ca06017fd05d12f01ab2";



    }

    public interface studentsNotPartofGroupsAPIConstants {
        public static String MESSAGE_MESSAGE = "messages,message";
        public static String MESSAGE_STATUS = "messages,status";
        public static String MESSAGE_EXCEPTION = "messages,exception";
        public static String FAILURE = "failure";
        public static String SCHEMA_FILE = "StudentsNotPartOfGroup";
        public static String TEACHER_ID = "{teacher_id}";
        public static String STUDENT_DETAILS_SCHEMA = "studentDetailsforGroupId";
    }

    public interface ReturnStudentListAPI {
        public static String RETURN_STUDENT_ENDPOINT = "/lms/web/api/v1/organization/{organizationId}/staffs/{userID}/courses/{courseId}/unassigned";

        //  Field Names
        public static String DATA = "data";
        public static String USERNAME = "username";
        public static String SECTION = "section";
        public static String SECTION_INFO = "sectionInfo";
        public static String ID = "id";
        public static String VALID = "valid";
        public static String GRADE_VALUE = "G02";
        public static String INVALID_ORG_ID = "invalidorg";
        public static String INVALID_TEACHER = "invalidteacherid";
        public static String INVALID_COURSE_ID = "invalidcourseid";
        public static String STATUSCODE_FIELD = "StatusCode";
        public static String MESSAGE_FIELD = "message";
        public static String ACCESS_DENIED_EXCEPTION = "org.springframework.security.access.AccessDeniedException";
        public static String DATA_NOT_FOUND_EXCEPTION = "com.savvas.core.exceptions.DataNotFoundException";
        public static String STUDENT_NOT_FOUND_MESSAGE = "Student Not Found";
        public static String ACCESS_DENIED_MESSAGE = "Access is denied";
        public static String BUSINESS_RULE_EXCEPTION = "com.savvas.core.exceptions.BusinessRuleViolationException";
        public static String INVALID_TEACHER_MESSAGE = "Login UserId / Request User Id mismatch";
        public static String AUTHENTICATION_FAILED_MESSAGE = "Authentication Failed";
        public static String EXCEPTION_MESSAGE = "java.lang.Exception";
        public static String INVALID_ORG_MESSAGE = "request URI does not present in OrgIds";
        public static String STUDENT_FIRST_NAME = "stud1";
        public static String STUDENT_MIDDLE_NAME = "stud2";
        public static String STUDENT_LAST_NAME = "stud2";
        public static String ADD_PRODUCT = "addProductToClassGraphQL.json";
        public static String UPDATE_GRADE = "updateStudentGrade.json";

        //Values
        public static String MATH_CONTENT_ID = "1";
        public static String READING_CONTENT_ID = "2";
        public static String FOCUS_COURSE_1 = "3";
        public static String FOCUS_COURSE_2 = "4";
    }

    public interface GetGroupListAPI {
        public static String GET_GROUP_LIST_FOR_TEACHERID_NEW_API = "/lms/web/api/v1/users/{userId}/groups";
        public static String GET_GROUP_DETAIL_SWAGGER = "/cms/v1/teachers/{userid}/sections";
        public static String INVALID_ACCESS_TOKEN = "245446565767673234134ty4y45tyrtsg";
        public static String INVALID_TEACHER = "INVALID_TEACHER";
        public static String INVALID_ORG = "INVALID_ORG";
        public static String GROUP_SCHEMA = "getGroupListForTeacherID";
        public static String GROUP_NAME = "groupName";
        public static String GROUP_OWNER_ORGID = "groupOwnerOrgId";
        public static String GROUP_ID = "groupId";
        public String GROUP_PROGRESS_ASSIGNMENTS = "groupProgressAssignments";

    }

    public interface GetGroupMostAssessedSkill {
        String ENDPOINT = "/lms/web/api/v1/organizations/%s/staffs/%s/contentBase/%s/groups/%s/mostAssessedSkills";
        String SUBJECT_TYPE_ID = "subjectTypeId";
        String CONTENT_BASE = "contentBase";
        String INVALID_CONTENT_BASE = "invalid content base";
        String INVALID_SUBJECT_TYPE = "invalid subjectType";
    }

}
