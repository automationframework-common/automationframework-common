package com.savvas.sm.teacher.ui.tests.smnew.UsersSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MyProfilePage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class UserPasswordUpdate extends BaseTest {
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String token = null;
    private static String teacherDetails;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherID;
    String studentDetails;
    String studentDetailsSecond;
    String studentSMDetails;
    String studentSMDetailsSecond;
    private HashMap<String, String> groupDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        UserAPI userAPIMethod = new UserAPI();

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        studentDetails = RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" );
        studentDetailsSecond = RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, RBSDataSetupConstants.USERID ) );
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        // Student SM Details
        studentSMDetails = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ), teacherID, RBSDataSetup.organizationIDs.get( school ), token ).get( Constants.REPORT_BODY );
        studentSMDetailsSecond = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetailsSecond, RBSDataSetupConstants.USERID ), teacherID, RBSDataSetup.organizationIDs.get( school ), token ).get( Constants.REPORT_BODY );

        // Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

    }

    @Test ( description = "Verify Password Setting Policy For Teacher Profile", groups = { "SMK-56844", "User", "UserPasswordUpdate" }, priority = 1 )
    public void tcUserPasswordUpdate001( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        SMUtils.logDescriptionTC( "Verify that the teacher can view the Change Password link in my profile page" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Check Change password link is present
            SMUtils.logDescriptionTC( "Verify that the teacher can view the Change Password link in my profile page" );
            new SMUtils();
            Log.assertThat( SMUtils.isElementPresent( myProfilePage.changePasswordLink ), "Change Password link is dispayed", "Change Password link is not dispayed" );

            // Clicking change password link
            SMUtils.logDescriptionTC( "Verify that the teacher can click on Change Password link in my profile page" );
            myProfilePage.clickChangePasswordLink();
            SMUtils.logDescriptionTC( "Verify that the change password link is changed to inactive after clicking on Change Password link" );
            SMUtils.logDescriptionTC( "Verify that on clicking Change Password link, Enter New Password and Confirm New Password fields are shown" );
            Log.assertThat( myProfilePage.VerifyNewPasswordandConfirmPasswordisPresent(), "The New Password Field and Confirm Password field is present as Expected!", "The New Password Field and Confirm Password field is not present as Expected!" );
            SMUtils.logDescriptionTC( "Verify the password setting policy as per A&E is displayed to the user when he clicks on the 'i' icon near the Enter New Password field" );
            // Verifying password policies
            myProfilePage.clickInformationCircle();
            Log.assertThat( myProfilePage.VerifyPasswordRequirementTexts(), "The password setting policy is displayed correctly!", "The password setting policy is not displayed!" );
            String updatedPassword = Constants.TeacherUserProfile.NEW_PASSWORD;
            SMUtils.logDescriptionTC( "Verify that the change password link is changed to inactive after clicking on Change Password link" );
            new SMUtils();
            Log.assertThat( SMUtils.isElementPresent( myProfilePage.changePasswordLink ), "Change Password link is inactive", "Change Password link is not inactive" );

            // Updating New password
            myProfilePage.modifyNewPassword( updatedPassword );
            myProfilePage.modifyConfirmPassword( updatedPassword );
            SMUtils.logDescriptionTC( "Verify that Save button is changed to active after clicking Change Password link." );
            myProfilePage.saveChanges();

            new SMUtils();
            // Waiting for the alert message
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( MyProfilePage.alertMessageCSS ), 5 );
            Log.assertThat( SMUtils.verifyWebElementTextEquals( myProfilePage.alertElement, Constants.TeacherUserProfile.CHANGES_SAVED_TOAST_MESSAGE ), "Toast message is matched!", "Toast message is not matched!" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();
            SMUtils.logDescriptionTC( "Verify that after updating the password, the user cannot able to login with old password and able to login only with new password." );
            LoginPage smLoginPage = new LoginPage( driver, smUrl );
            smLoginPage.enterCredentialsAndLogIn( username, password );
            new SMUtils();
            Log.assertThat( SMUtils.isElementPresent( smLoginPage.loginErrorMessage ), "Not able to login with old password", "Able to login with old password" );

            SMUtils.logDescriptionTC( "Verify the student can able to login after teacher changes the password." );
            SMUtils.logDescriptionTC( "Verify that when you provide the confirm password first, and then the Enter new password and, it is behaving correctly" );
            smLoginPage = new LoginPage( driver, smUrl );
            smLoginPage.enterCredentialsAndLogIn( username, updatedPassword );

            // Navigating to the MyProfilePage tab
            tHomePage.topNavBar.navigateToMyProfile();
            // Clicking change password link
            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyConfirmPassword( RBSDataSetupConstants.DEFAULT_PASSWORD );
            myProfilePage.modifyNewPassword( RBSDataSetupConstants.DEFAULT_PASSWORD );
            SMUtils.logDescriptionTC( "Verify that the teacher can click Save button to save the changed password" );
            SMUtils.logDescriptionTC( "Verify that the Save button is changed to active after validating the passwords are the same and following the rules." );
            myProfilePage.saveChanges();

            // Verifying not matched password
            SMUtils.logDescriptionTC( " Verify that if the values entered in New Password and Confirm Password fields do not match, a validate message 'Does not match new password' is shown" );
            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyNewPassword( updatedPassword );
            myProfilePage.modifyConfirmPassword( updatedPassword + 1 );
            myProfilePage.modifyMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( MyProfilePage.erroMessgaeCSS ), 3 );
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.DOES_NOT_MATCH_NEW_PASSWORD ), "The Error message matches!", "The Error message does not match!" );
            myProfilePage.cancelChanges();

            SMUtils.logDescriptionTC( " Verify the teacher gives username as password" );
            // Clicking change password link
            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyNewPassword( username );
            myProfilePage.modifyMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( MyProfilePage.erroMessgaeCSS ), 3 );
            // Verifying error message
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            myProfilePage.cancelChanges();

            SMUtils.logDescriptionTC( " Verify the teacher gives firstname/lastname as password" );
            String firstName = myProfilePage.firstNameField.getText();
            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyNewPassword( firstName );
            myProfilePage.modifyMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( MyProfilePage.erroMessgaeCSS ), 3 );
            // Verifying error message
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            myProfilePage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify that the teacher cannot give only special characters as password." );
            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyNewPassword( Constants.TeacherUserProfile.SPECIAL_CHARACTER_PASSWORD );
            myProfilePage.modifyMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( MyProfilePage.erroMessgaeCSS ), 3 );
            // Verifying error message
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            myProfilePage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify the teacher cannot give only numbers in password" );
            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyNewPassword( Constants.TeacherUserProfile.NUMERIC_PASSWORD );
            myProfilePage.modifyMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( MyProfilePage.erroMessgaeCSS ), 3 );
            // Verifying error message
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            myProfilePage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify the limit of the password length" );
            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyNewPassword( Constants.TeacherUserProfile.LESS_THAN_8_CHARACTER_PASSWORD );
            myProfilePage.modifyMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( MyProfilePage.erroMessgaeCSS ), 3 );
            // Verifying error message
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            myProfilePage.cancelChanges();

            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyNewPassword( Constants.TeacherUserProfile.GREATER_THAN_32_CHARACTER_PASSWORD );
            myProfilePage.modifyMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( MyProfilePage.erroMessgaeCSS ), 3 );
            // Verifying error message
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            myProfilePage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify that a validate message 'Password does not meet requirements', is shown in the UI when the user enters a password in the 'New Password' field, that does not meet the requirements" );

            SMUtils.logDescriptionTC( "Verify that if we enter short passwords('123''abc'), a validate message 'Password does not meet requirements' is shown." );
            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyNewPassword( "abc" );
            myProfilePage.modifyMiddleName( "" );
            // Verifying error message
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            SMUtils.logDescriptionTC( "Verify that the teacher can click Cancel button to cancel changes that have been made." );
            myProfilePage.cancelChanges();

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Password Setting Policy For Student Profile", groups = { "SMK-56844", "User", "UserPasswordUpdate" }, priority = 1 )
    public void tcUserPasswordUpdate002( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        SMUtils.logDescriptionTC( "Verify that the teacher can view the Change Password link in my profile page" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickFirstStudent();

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.logDescriptionTC( "Verify that the teacher can click on Change Password link" );
            // Clicking change password link
            studentsPage.clickChangePassword();
            SMUtils.logDescriptionTC( "Verify that the change password link is changed to inactive after clicking on Change Password link" );
            new SMUtils();
            Log.assertThat( SMUtils.isElementPresent( studentsPage.disabledChangePasswordLink ), "Change Password link is inactive", "Change Password link is not inactive" );

            SMUtils.logDescriptionTC( "Verify that on clicking Change Password link, Enter New Password and Confirm New Password fields are shown" );
            Log.assertThat( studentsPage.VerifyNewPasswordandConfirmPasswordisPresent(), "The New Password Field and Confirm Password field is present as Expected!", "The New Password Field and Confirm Password field is not present as Expected!" );
            SMUtils.logDescriptionTC( "Verify the password setting policy as per A&E is displayed to the user when he clicks on the 'i' icon near the Enter New Password field" );
            // Verifying password policies
            studentsPage.clickInformationCircle();
            Log.assertThat( studentsPage.VerifyPasswordRequirementTexts(), "The password setting policy is displayed correctly!", "The password setting policy is not displayed!" );
            String updatedPassword = Constants.TeacherUserProfile.NEW_PASSWORD;

            // Updating with new password
            studentsPage.modifyNewPassword( updatedPassword );
            studentsPage.modifyConfirmPassword( updatedPassword );
            SMUtils.logDescriptionTC( "Verify that Save button is changed to active after clicking Change Password link." );
            SMUtils.logDescriptionTC( "Verify that the teacher can click Save button to save the changed password" );
            SMUtils.logDescriptionTC( "Verify that the Save button is changed to active after validating the passwords are the same and following the rules." );
            studentsPage.saveChanges();

            // Verifying not matched password
            SMUtils.logDescriptionTC( " Verify that if the values entered in New Password and Confirm Password fields do not match, a validate message 'Does not match new password' is shown" );
            studentsPage.clickChangePassword();
            studentsPage.modifyNewPassword( updatedPassword );
            studentsPage.modifyConfirmPassword( updatedPassword + 1 );
            studentsPage.changeMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.DOES_NOT_MATCH_NEW_PASSWORD ), "The Error message matches!", "The Error message does not match!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( " Verify the teacher gives username as password" );
            String userName = studentsPage.userNameField.getText();
            studentsPage.clickChangePassword();
            studentsPage.modifyNewPassword( userName );
            studentsPage.changeMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( " Verify the teacher gives firstname/lastname as password" );
            String firstName = studentsPage.firstNameField.getText();
            studentsPage.clickChangePassword();
            studentsPage.modifyNewPassword( firstName );
            studentsPage.changeMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify that the teacher cannot give only special characters as password." );
            studentsPage.clickChangePassword();
            studentsPage.modifyNewPassword( Constants.TeacherUserProfile.SPECIAL_CHARACTER_PASSWORD );
            studentsPage.changeMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify the teacher cannot give only numbers in password" );
            studentsPage.clickChangePassword();
            studentsPage.modifyNewPassword( Constants.TeacherUserProfile.NUMERIC_PASSWORD );
            studentsPage.changeMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify the limit of the password length" );
            studentsPage.clickChangePassword();
            studentsPage.modifyNewPassword( Constants.TeacherUserProfile.LESS_THAN_8_CHARACTER_PASSWORD );
            studentsPage.changeMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            studentsPage.clickChangePassword();
            studentsPage.modifyNewPassword( Constants.TeacherUserProfile.GREATER_THAN_32_CHARACTER_PASSWORD );
            studentsPage.changeMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify that a validate message 'Password does not meet requirements', is shown in the UI when the user enters a password in the 'New Password' field, that does not meet the requirements" );

            SMUtils.logDescriptionTC( "Verify that if we enter short passwords('123''abc'), a validate message 'Password does not meet requirements' is shown." );
            studentsPage.clickChangePassword();
            studentsPage.modifyNewPassword( "abc" );
            studentsPage.changeMiddleName( "" );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            SMUtils.logDescriptionTC( "Verify that the teacher can click Cancel button to cancel changes that have been made." );
            studentsPage.cancelChanges();

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Password Setting Policy For Add Student", groups = { "SMK-56844", "User", "UserPasswordUpdate" }, priority = 1 )
    public void tcUserPasswordUpdate003( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        SMUtils.logDescriptionTC( "Verify that the teacher can view the Change Password link in my profile page" );
        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            // Navigating to the student tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Clicking the add student button
            WebElement addStuBtn = studentsPage.addStudentElement();
            SMUtils.clickJS( driver, addStuBtn );
            // Validating whether Add student Pop up is displayed
            Log.assertThat( studentsPage.isCreateStudentPopUpDisplayed(), " CreateStudent Pop is Displayed after clicking the add studnet Button ", " CreateStudent Pop is not Displayed after clicking the add studnet Button" );

            SMUtils.logDescriptionTC( "Verify the password setting policy as per A&E is displayed to the user when he clicks on the 'i' icon near the Enter New Password field" );
            // Verifying password policies
            studentsPage.clickInformationCircle();
            Log.assertThat( studentsPage.VerifyPasswordRequirementTexts(), "The password setting policy is displayed correctly!", "The password setting policy is not displayed!" );
            String updatedPassword = Constants.TeacherUserProfile.NEW_PASSWORD;
            // updating with new password
            Faker studentDetail = new Faker();
            String firstName = studentDetail.name().firstName();
            String lastName = studentDetail.name().firstName();
            String userName = firstName + System.nanoTime();
            studentsPage.enterFirstName( firstName );
            studentsPage.enterLastName( lastName );
            studentsPage.enterUserName( userName );
            SMUtils.waitForElement( driver, studentsPage.ddGradeSelection );
            SMUtils.clickJS( driver, studentsPage.ddGradeSelection );
            studentsPage.selectGrade( "Grade 1" );
            studentsPage.modifyNewPassword( updatedPassword );
            studentsPage.modifyConfirmPassword( updatedPassword );
            SMUtils.logDescriptionTC( "Verify that the teacher can click Save button to save the changed password" );
            SMUtils.logDescriptionTC( "Verify that the Save button is changed to active after validating the passwords are the same and following the rules." );
            studentsPage.addStudent();
            studentsPage.clickCloseForPopup();

            // Verifying not matched password
            SMUtils.logDescriptionTC( " Verify that if the values entered in New Password and Confirm Password fields do not match, a validate message 'Does not match new password' is shown" );
            // Clicking the add student button
            WebElement addStudBtn = studentsPage.addStudentElement();
            SMUtils.clickJS( driver, addStudBtn );
            studentsPage.modifyNewPassword( updatedPassword );
            studentsPage.modifyConfirmPassword( updatedPassword + 1 );
            studentsPage.enterFirstName( firstName );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.DOES_NOT_MATCH_NEW_PASSWORD ), "The Error message matches!", "The Error message does not match!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( " Verify the teacher gives username as password" );
            // Clicking the add student button
            WebElement addStdntBtn = studentsPage.addStudentElement();
            SMUtils.clickJS( driver, addStdntBtn );
            studentsPage.enterUserName( userName + 1 );
            studentsPage.modifyNewPassword( userName + 1 );
            studentsPage.enterFirstName( firstName );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( " Verify the teacher gives firstname/lastname as password" );
            // Clicking the add student button
            WebElement addStudtBtn = studentsPage.addStudentElement();
            SMUtils.clickJS( driver, addStudtBtn );
            studentsPage.enterFirstName( firstName );
            studentsPage.modifyNewPassword( firstName );
            studentsPage.enterUserName( userName );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify that the teacher cannot give only special characters as password." );
            // Clicking the add student button
            WebElement addStudntBtn = studentsPage.addStudentElement();
            SMUtils.clickJS( driver, addStudntBtn );
            studentsPage.modifyNewPassword( Constants.TeacherUserProfile.SPECIAL_CHARACTER_PASSWORD );
            studentsPage.enterFirstName( firstName );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify the teacher cannot give only numbers in password" );
            // Clicking the add student button
            WebElement addStudntButton = studentsPage.addStudentElement();
            SMUtils.clickJS( driver, addStudntButton );
            studentsPage.modifyNewPassword( Constants.TeacherUserProfile.NUMERIC_PASSWORD );
            studentsPage.enterFirstName( firstName );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify the limit of the password length" );
            // Clicking the add student button
            WebElement addStudentButton = studentsPage.addStudentElement();
            SMUtils.clickJS( driver, addStudentButton );
            studentsPage.modifyNewPassword( Constants.TeacherUserProfile.LESS_THAN_8_CHARACTER_PASSWORD );
            studentsPage.enterFirstName( firstName );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            // Clicking the add student button
            WebElement addStudetBtn = studentsPage.addStudentElement();
            SMUtils.clickJS( driver, addStudetBtn );
            studentsPage.modifyNewPassword( Constants.TeacherUserProfile.GREATER_THAN_32_CHARACTER_PASSWORD );
            studentsPage.enterFirstName( firstName );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( StudentsPage.erroMessgaeCSS ), 3 );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            studentsPage.cancelChanges();

            SMUtils.logDescriptionTC( "Verify that a validate message 'Password does not meet requirements', is shown in the UI when the user enters a password in the 'New Password' field, that does not meet the requirements" );

            SMUtils.logDescriptionTC( "Verify that if we enter short passwords('123''abc'), a validate message 'Password does not meet requirements' is shown." );
            WebElement addStudentBtn = studentsPage.addStudentElement();
            SMUtils.clickJS( driver, addStudentBtn );
            studentsPage.modifyNewPassword( "abc" );
            studentsPage.enterFirstName( firstName );
            Log.assertThat( studentsPage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error Message is displayed correctly!", "The Error Message is not displayed correctly!" );
            SMUtils.logDescriptionTC( "Verify that the teacher can click Cancel button to cancel changes that have been made." );
            studentsPage.cancelChanges();

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
