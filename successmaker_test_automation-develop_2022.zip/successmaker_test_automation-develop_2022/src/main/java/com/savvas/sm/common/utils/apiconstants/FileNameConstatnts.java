package com.savvas.sm.common.utils.apiconstants;

public interface FileNameConstatnts {

    public static String SINGLE_TEACHER_JSON = "singleTeacher.json";
    public static String SINGLE_STUDENT_JSON = "singleStudent.json";
    public static String CREATE_CLASS_PAYLOAD2 = "createClassPayload2.json";
    public static String CREATE_USER_BY_USERSERVICE = "createUserByUserService.json";
    public static String UPDATE_USER_BY_USERSERVICE = "updateUserByUserService.json";
    public static String UPDATE_USER_BY_USERSERVICE_DEMO = "updateUserwithDemographics.json";
    public static String STUDENT_DETAILS_FOR_STUDENTID = "StudentDetaiilsForStudentId";
    public static String STUDENT_DETAILS_FOR_TEACHER_ID = "GetStudentDetailsForTeacher";
    public static String GET_RECENT_ASSIGNMENTS_SCHEMA_FILE = "GetRecentAssignments";
    public static String GET_RECENT_ASSIGNMENTS_EXCEPCTIONS_SCHEMA_FILE = "GetRecentAssignmentsExceptions";
    public static String GET_ASSIGNMENTS_SCHEMA_FILE = "GetAssignmentsListing";
    public static String UPDATE_STAFF_PROFILE = "updateStaffProfilePayload.json";
    public static String UPDATE_USER_ORG_PAYLOAD = "updateOrganizationlForUser.xml";
    public static String UPDATE_ASSIGNMENT_USER_SETTINGS_SCHEMA_FILE = "UpdateAssignmentUserSettings";
    public static String UPDATE_STUDENT_PROFILE_SCHEMA = "UpdatetStudentProfileSchema";
    public static String GET_GROUPS_NOT_BELONGS_TO_STUDENTS_SCHEMA = "GetGroupsNotBelongsToStudents";
    public static String GET_COURSE_LIST_FOR_GROUP_ID_SCHEMA = "GetCourseListForGroupId";

}
