package com.savvas.sm.common.utils.apiconstants;

public interface CourseAPIConstants {
    //End Points
    public String GET_COURSES_AT_ORG_LEVEL_API = "/lms/web/api/v1/organizations/{organizationId}/courses";
    public String GET_COURSES_AT_DASHBOARD_LEVEL_API = "/lms/web/api/v1/organizations/{organizationId}/courses";
    public String GET_COURSE_SETTING_API = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/settings";
    public String DELETE_COURSE_API = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}";
    public String GET_COURSE_SETTING_API_COURSE_TYPE_ID = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/settings?assign=false&courseTypeId={courseId}";
    public String POST_STANDARD_COURSE_COPY = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/copy";
    public String GET_SKILLS_HIERARCHY = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/skills/{courseID}/hierarchy";
    public String CREATE_CUSTOM_COURSE = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/copy";
    public String GET_STANDARD_HIERARCHY = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/standards/{courseID}/hierarchy";
    public String CUSTOM_COURSE_SETTINGS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/settings";
    public String UPDATE_CUSTOM_COURSE_BY_STANDARDS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}";
    public String UPDATE_CUSTOM_COURSE_BY_STANDARDS1 = "/lms/web/api/v1/organizations/{organizationId}/staffs/ffffffff6230751c18a8c80030acee34/courses/583";
    public String GET_ASSIGNMENT_OWNER_LIST = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/assignments/owners";
    public String UPDATE_ASSIGNMENT_SETTINGS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courseassignments/{courseId}/settings";
    public String GET_ASSIGNMENT_SETTINGS = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/settings";
    public String UPDATE_CUSTOM_COURSE_BY_STANDARDS_INVALID = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courseses12/{courseId}";
    public String CUSTOM_COURSE_SETTINGS_INVALID = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/courses/{courseId}/settingss12";
    
    //Headers
    public String TEACHER_ID = "teacherID";
    public String ORG_ID = "orgID";
    public String STUDENT_RUMBA_IDS = "studentRumbaIds";
    public String STUDENT_RUMBA_GRADE_IDS = "studentRumbaIds_Grades";
    public String STATUS = "status";
    public String INVALID_ORG_ID = "invalidOrgID";
    public String DATE_ASSIGNED = "dateAssigned";

    public String INVALID_TEACHER_ID = "invalidteacherID";

    public String INVALID_STAFF_ID = "invalidStaffID";

    //Attributes
    public String USERS_TYPE = "users";
    public String GROUPS_TYPE = "groups";
    public String COURSE_ID = "courseID";
    public String ASSIGNMENT_USER_ID = "assignmentUserID";
    public String ASSIGNED_COURSE = "assignedCourses";
    public String COURSE_START_TIME = "courseStartTime";
    String STANDARD_FRAMEWORK_ID = "standardFrameworkId";
    String GRADE_ID = "gradeId";
    String CONTENT_BASE_TYPE = "contentBaseType";
    String MAP_LO_TAXONOMY = "mapLoTaxonomy";
    String LO = "lo";
    String PAYLOAD = "payload";
    public String ASSIGN = "assign";
    public String APPY_TO_USERS = "applyToUsers";
    public String COURSE_TYPE_ID = "courseTypeId";
    public String CTTYPE_ID = "cttypeID";
    public String BANK_ID = "bankID";
    public String LEVEL = "level";
    public String INCLUDE_LOS = "includeLos";
    public String CONTENT_BASE_ID = "contentBaseTypeId";
    public String GROUP_ID = "groupID";
    //Course Settings
    public String SESSION_STRENGTH_ID = "sessionStrengthId";
    public String INVALID_SESSION_STRENGTH_ID = "invalidSessionStrengthId";
    public String SESSION_STRENGTH_NAME = "sessionStrengthName";
    public String SESSION_STRENGTH_VALUE = "sessionStrengthValue";
    public String SESSION_LENGTH_ID = "sessionLengthId";
    public String SESSION_LENGTH_NAME = "sessionLengthName";
    public String SESSION_LENGTH_VALUE = "sessionLengthValue";
    public String IDLE_TIME_ID = "idleTimeId";
    public String IDLE_TIME_NAME = "idleTimeName";
    public String IDLE_TIME_VALUE = "idleTimeValue";
    public String INITIAL_PLACEMENT_NAME = "initialPlacementName";
    public String INITIAL_PLACEMENT_ID = "initialPlacementId";
    public String INITIAL_PLACEMENT_VALUE = "initialPlacementValue";
    public String CALCULATOR_NAME = "calculatorName";
    public String CALCULATOR_ID = "calculatorId";
    public String CALCULATOR_VALUE = "calculatorValue";
    
    public String NAME = "name";
    public String CURRENT_VALUE = "currentValue";
    public String SESSION_LENGTH = "SESSION_LENGTH";
    public String IDLE_TIME = "IDLE_TIME";
    public String INITIAL_PLACEMENT = "INITIAL_PLACEMENT";
    public String CALCULATOR = "CALCULATOR";
    
    //Course IDs
    public String STRING_ONE = "1";
    public String STRING_TWO = "2";
    public String STRING_FOUR = "4";
    public String STRING_FOURTEEN = "14";
    public String STRING_THREE = "3";
    public String STRING_EIGHTEEN = "18";
    public String STRING_FIFTEEN = "15";
    public String STRING_THIRTEEN = "13";
    public String STRING_SEVEN = "7";
    public String STRING_SIX = "6";
    public String STRING_NINE = "9";

    //Course product description
    public String SUCCESSMAKER_DEFAULT_MATH = "SuccessMaker Default Math";
    public String SUCCESSMAKER_DEFAULT_READING = "SuccessMaker Default Reading";
    public String SUCCESSMAKER_FOCUS_MATH = "SuccessMaker Focus Math";
    public String SUCCESSMAKER_FOCUS_READING = "SuccessMaker Focus Reading";
    public String SUCCESSMAKER_COURSE_CREATED_BY_TEACHER = "Courses created by teachers";

    //Course constants
    String PRODUCT_DESCRIPTION = "productDescription";
    String TEACHER = "teacher";
    public String SAVE_SCO_START_TIME = "/lms/web/assignments/scostart";
    public String SAVE_SAVE_SESSION_START_TIME = "/lms/web/assignments/sessionstart";

    //Query params
    public String CTTYPE_ID_PARAM = "cttypeId";
    public String BANK_ID_PARAM = "bankId";
    public String LEVEL_PARAM = "level";
    public String INCLUDE_LOS_PARAM = "includeLos";

    //Shared course constants
    public String ID = "id";
    public String OWNER_ORG_ID = "ownerOrgId";
    public String SHARED_ORG_COUNT = "sharedOrgCount";
    public String PARENT_NODE = "parentNode";
    public String CHILD_NODE = "childNode";
    String SUBJECT = "subject";
    String COURSE_TYPE = "courseType";
    String COURSE_NAME = "courseName";
    String STATUS_CODE = "statuCode";
    String VALID = "valid";
    String TRUE = "true";

    //Invalid
    String INVALID = "invalid";
    public String INVALID_COURSE_ID = "invalidcourseid";
    String INVALID_ORGANIZATION_ID = "22220a5a7f2c9dcf017f3fe81bc602we";
    String EMPTY_ORG_ID = "null";
    String INVALID_STAFF_ID_RANDOM = "ssffffff621e74da6d1f1500304271ab";
    String NULL_STAFF_ID = "null";
    String INVALID_AUTHORIZATION_ID = "2344444444444444ddffssgag123444445555";
    String INVALID_STANDARD_FRAMEWORK_ID = "Test123";
    String INVALID_GRADE_ID = "112233";
    String INVALID_CONTENT_BASE_TYPE = "12#";
    String INVALID_MAP_LO_TAXONOMY = "1001111059998";
    String INVALID_LO = "SMMA_LO_1169970";
    String INVALID_COURSE_ID_SYMBOL = "&*&";
    String DIFFERENT_ORG_ID = "8a7201c77ea23877017ef7c0e1271b48";
    String DIFFERENT_ORG_TEACHER_ID = "ffffffff620a2f73fe4bbc00309e33f0";
    String TEACHER_ID_MORE_THAN_255_CHAR = "Apart from counting words and characters, our online editor can help you to improve word choice and writing style, and, optionally, help you to detect grammar mistakes and plagiarism. To check word count, simply place your cursor into the text box above and start typing. You'll see the number of characters and words increase or decrease as you type, delete, and edit them. You can also copy and paste text from another program over into the online editor above. The Auto-Save feature will make sure you won't lose any changes while editing, even if you leave the site and come back later. Knowing the word count of a text can be important. For example, if an author has to write a minimum or maximum amount of words for an article, essay, report, story, book, paper, you name it. WordCounter will help to make sure its word count reaches a specific requirement or stays within a certain limit. In addition, WordCounter shows you the top 10 keywords and keyword density of the article you're writing. This allows you to know which keywords you use how often and at what percentages. This can prevent you from over-using certain words or word combinations and check for best distribution of keywords in your writing. In the Details overview you can see the average speaking and reading time for your text, while Reading Level is an indicator of the education level a person would need in order to understand the words you're using. Disclaimer: We strive to make our tools as accurate as possible but we cannot guarantee it will always be so.";
    String UNAUTHORIZED_ORG_ID = "8a7204c37f90ca06017f917e4b470031";
    String UNAUTHORIZED_STAFF_ID = "ffffffff61d41c916e4125002f230e72";
    String INVALID_GROUP_ID = "ssffffff621e74da6d1f1500304271ab";

    //Non-existing
    String NON_EXISTING = "nonexisting";
    String NON_EXISTING_ORGANIZATION_ID = "8a720a5a7f2c9dcf017f3fe81bc602we";
    String DEFFERENT_ORGANIZATION_ID = "8a7208df80ac943f0180bd8f2d630096";
    String NON_EXISTING_COURSE_ID = "100000000001";
    String NON_EXISTING_STAFF_ID = "ffffffff621e74da6d1f1500304271ab";
    String DIFFERENT_STAFF_ID = "ffffffff627e5b0c3f948a002f1ecd2e";
    String NON_EXISTING_STANDARD_FRAMEWORK_ID = "1000111556";
    String NON_EXISTING_GRADE_ID = "Testing!234";
    String NON_EXISTING_MAP_LO_TAXONOMY = "SMMA_LO_11670_1000001058";
    String NON_EXISTING_LO = "SMMA_LO_11670111";

    //Null
    String NULL = "null";
    String COURSE_NAME_NULL = "null";
    String NULL_COURSE_NAME = null;

    //Constant Values
    public String INVALID_ORG_ID_CONSTANT_VALUE = "1917407100715";

}