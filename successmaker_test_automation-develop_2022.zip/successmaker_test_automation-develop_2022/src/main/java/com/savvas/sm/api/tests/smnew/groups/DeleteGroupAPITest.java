package com.savvas.sm.api.tests.smnew.groups;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.DeleteGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

/**
 * To test the create group API
 * 
 *
 */
public class DeleteGroupAPITest extends GroupAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    String sessionCookie;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String reqBodyTemplate = null;

    // Teacher variable used for this class
    private String orgUsed = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String orgUsed2 = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String teacherUsed;
    String smURL;
    String orgId;
    String teacherId;
    String username;
    String org1TeacherId2;
    String org1TeacherUsername2;
    
    String teacherdetails1Org1;
    String teacherdetails2Org1;
    
    
    //Student variable used for this class
    String studentDetails1;
    String studentDetails2;
    String studentDetails3;
    String studentDetails4;
    String studentDetails5;
    
    HashMap<String, String> groupDetails = new HashMap<>();
    private ArrayList<String> studentRumbaIds;

    // other school teacher details
    private String org2Id;
    private String org2TeacherId1;
    private String org2TeacherUsername1;
    String teacherdetails1Org2;
    String teacherdetails2Org2;

    @BeforeClass(alwaysRun = true)
    public void BeforeTest() throws IOException {

        smURL = configProperty.getProperty( "SMAppUrl" );

        // Teacher used Details
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        teacherdetails1Org1 = RBSDataSetup.getMyTeacher(orgUsed);
        teacherId = SMUtils.getKeyValueFromResponse( teacherdetails1Org1, Constants.USERID_HEADER );
        username = SMUtils.getKeyValueFromResponse( teacherdetails1Org1, Constants.USER_NAME);
        
        // Teacher 2 Details
        
        teacherdetails2Org1 = RBSDataSetup.getMyTeacher(orgUsed); 
        org1TeacherId2 = SMUtils.getKeyValueFromResponse( teacherdetails2Org1, Constants.USERID );
        org1TeacherUsername2 = SMUtils.getKeyValueFromResponse( teacherdetails2Org1, Constants.USER_NAME);
        
        
        // Other School Details
        org2Id = RBSDataSetup.organizationIDs.get( orgUsed2 );
        teacherdetails1Org2 =RBSDataSetup.getMyTeacher(orgUsed2);
        org2TeacherId1 = SMUtils.getKeyValueFromResponse( teacherdetails1Org2, Constants.USERID );
        org2TeacherUsername1 =  SMUtils.getKeyValueFromResponse( teacherdetails1Org2, Constants.USER_NAME );

        // StudentDetails
        studentDetails1=RBSDataSetup.getMyStudent(orgUsed, username);
        studentDetails2=RBSDataSetup.getMyStudent(orgUsed, username);
        studentDetails3=RBSDataSetup.getMyStudent(orgUsed, username);
        studentDetails4=RBSDataSetup.getMyStudent(orgUsed, username);
        studentDetails5=RBSDataSetup.getMyStudent(orgUsed, username); 
        
       

        studentRumbaIds = new ArrayList<String>();
        studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails1, RBSDataSetupConstants.USERID));
        studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails2, RBSDataSetupConstants.USERID));
        studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails3, RBSDataSetupConstants.USERID));
        studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails4, RBSDataSetupConstants.USERID));
        studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails5, RBSDataSetupConstants.USERID));
    
       
    }

    @Test ( priority = 1, groups = { "SMK-51981", "Delete a Group", "Group", "P1", "API" } )
    public void tcDeleteGroup_001() throws Exception {
        Log.testCaseInfo( "SMK-15859- Verify the Response code 404 when the group has been already deleted" );
        String className = "ClasstoDelete" + System.nanoTime();
        
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,  new RBSUtils().getAccessToken( username, password ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, className );
        HashMap<String, String> createGroup = createGroup( smURL, groupDetails, studentRumbaIds );
        String classId = SMUtils.getKeyValueFromResponse(createGroup.get(Constants.REPORT_BODY), "data,groupId");
        
        String accessCode = new RBSUtils().getAccessToken( username, password );
        deleteGroup( classId, teacherId, orgId, accessCode );

        HashMap<String, String> response = deleteGroup( classId, teacherId, orgId, accessCode );
        Log.message("The response is:" + response);

        // Validations
        VerifyResponseCode( response, CommonAPIConstants.STATUS_CODE_NOTFOUND );
        VerifyResponseMessage( response, DeleteGroupAPIConstants.SECTION_ID_NOT_FOUND_MESSAGE );
        
        // Verifying schema
        VerifySchema( CommonAPIConstants.STATUS_CODE_NOTFOUND, response );
        Log.testCaseResult();
    }

    @Test ( priority = 1, groups = { "SMK-51981", "Delete a Group", "Group", "P1", "API" } )
    public void tcDeleteGroup_002() throws Exception {

        Log.testCaseInfo( "SMK-15860- Verify the 401 authentication exception when the access token in invalid." );
        String className = "ClasstoDelete" + System.nanoTime();
        
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,  new RBSUtils().getAccessToken( username, password ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, className );
        HashMap<String, String> createGroup = createGroup( smURL, groupDetails, studentRumbaIds );
        String classId = SMUtils.getKeyValueFromResponse(createGroup.get(Constants.REPORT_BODY), "data,groupId");
        
        String accessCode = CommonAPIConstants.INVALID_ACCESS_TOKEN;

        HashMap<String, String> response = deleteGroup( classId, teacherId, orgId, accessCode );

        // Validations
        VerifyResponseCode( response, CommonAPIConstants.STATUS_CODE_UNAUTHORIZED );
        VerifyResponseMessage( response, CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE );
        // Verifying schema
        VerifySchema( CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, response );
        Log.testCaseResult();
    }

    @Test ( priority = 1, groups = { "SMK-51981", "Delete a Group", "Group", "P1", "API" } )
    public void tcDeleteGroup_003() throws Exception {

        Log.testCaseInfo( "SMK-15861- Verify the Response code 403, when the authorization is invalid(student authorization)" );

        String className = "ClasstoDelete" + System.nanoTime();
   
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,  new RBSUtils().getAccessToken( username, password ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, className );
        HashMap<String, String> createGroup = createGroup( smURL, groupDetails, studentRumbaIds ); 
        String classId = SMUtils.getKeyValueFromResponse(createGroup.get(Constants.REPORT_BODY), "data,groupId");
        
        String studUsername = SMUtils.getKeyValueFromResponse(studentDetails1,RBSDataSetupConstants.USERNAME );
        String accessCode = new RBSUtils().getAccessToken( studUsername, password );

        HashMap<String, String> response = deleteGroup( classId, studentRumbaIds.get( 0 ), orgId, accessCode );

        // Validations
        VerifyResponseCode( response, CommonAPIConstants.STATUS_CODE_FORBIDDAN );
        VerifyResponseMessage( response, CommonAPIConstants.FORBIDDAN_MESSAGE );
        // Verifying schema
        VerifySchema( CommonAPIConstants.STATUS_CODE_FORBIDDAN, response );
        Log.testCaseResult();
    }

    @Test ( priority = 1, groups = { "SMK-51981", "smoke_test_case","Delete_Group_TC01", "Delete a Group", "Group", "P1", "API" }, dataProvider = "deleteGroupPositiveScenariosData" )
    public void tcDeleteGroup_004( String description, String scenario, String expStatusCode ) throws Exception {

        String accessCode;
        String className = null;
        String classId = null;
        HashMap<String, String> response = null;
        Log.testCaseInfo( description );

        switch ( scenario ) {
            case "VALID_SCENARIO":
                Log.testCaseInfo( "SMK-15858- Verify the Response body when the valid inputs are given" );
                Log.testCaseInfo( "SMK-15866- Verify the response when you try to delete a manually rostered class" );
                // Test data       
                className = "ClasstoDelete" + System.nanoTime();
                accessCode = new RBSUtils().getAccessToken( username, password );
                
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,  new RBSUtils().getAccessToken( username, password ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, className );
                HashMap<String, String> createGroup = createGroup( smURL, groupDetails, studentRumbaIds );
                
                
                classId = SMUtils.getKeyValueFromResponse(createGroup.get(Constants.REPORT_BODY), "data,groupId");
                
                response = deleteGroup( classId, teacherId, orgId, accessCode );
                break;

            case "EMPTY_GROUP":
                className = "ClasstoDelete" + System.nanoTime();
                accessCode = new RBSUtils().getAccessToken( username, password );
                classId = createGroupWithCustomization( "Group - with no student", teacherId, new ArrayList<String>(), orgId, accessCode );
                response = deleteGroup( classId, teacherId, orgId, accessCode );
                break;

            case "NO_SM_PRODCUT":
                className = "ClasstoDelete" + System.nanoTime();
                accessCode = new RBSUtils().getAccessToken( username, password );
                studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails1, RBSDataSetupConstants.USERID));
                studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails2, RBSDataSetupConstants.USERID));
                classId = new RBSUtils().createClassWithMultipleTeacher( className, Arrays.asList( teacherId ), studentRumbaIds, orgId, accessCode );
                response = deleteGroup( classId, teacherId, orgId, accessCode );
                break;

            case "SHARED_STUDENT":

                // Test data    
                accessCode = new RBSUtils().getAccessToken( username, password );
                String studentName = "SharedStudent" + System.nanoTime();
                String StudentId = new UserAPI().createSharedStudent( studentName, teacherId, new RBSUtils().getAccessToken( username, password ), org1TeacherId2, new RBSUtils().getAccessToken( org1TeacherUsername2, password ), orgId );

                className = "Group with Shared student " + System.nanoTime();
                classId = createGroupWithCustomization( className, teacherId, Arrays.asList( StudentId ), orgId, new RBSUtils().getAccessToken( username, password ) );
                response = deleteGroup( classId, teacherId, orgId, accessCode );
                break;

            case "MULTI_ORG_TEACHER":

                // Mulit Org TEacher
                String teacherName = "multiorgteacher" + System.nanoTime();
                String teacherIdMultiOrg = new UserAPI().createMultiOrgTeacher( Arrays.asList( orgId, org2Id ), teacherName );
                String accessToken = new RBSUtils().getAccessToken( teacherName, password );

                className = "Group with Shared Teacher " + System.nanoTime();
                classId = createGroupWithCustomization( className, teacherIdMultiOrg, studentRumbaIds, orgId, accessToken );
                response = deleteGroup( classId, teacherIdMultiOrg, orgId, accessToken );

                break;
            case "MULTI_ORG_STUDENT":

                // Create a student present in both org
                studentName = "student" + System.nanoTime();
                accessCode = new RBSUtils().getAccessToken( username, password );
                String studentId = new UserAPI().createMultiOrgStudent( Arrays.asList( orgId, org2Id ), studentName );

                className = "Group with Shared student " + System.nanoTime();
                classId = createGroupWithCustomization( className, teacherId, Arrays.asList( studentId ), orgId, accessCode );
                response = deleteGroup( classId, teacherId, orgId, accessCode );
                break;

            case "SHARED_GROUP":

                className = "Group with Shared student " + System.nanoTime();
                accessCode = new RBSUtils().getAccessToken( username, password );
                classId = new RBSUtils().createClassWithMultipleTeacher( className, Arrays.asList( teacherId, org1TeacherId2 ), studentRumbaIds, orgId, accessCode );
                new RBSUtils().addProductToClassGraphQL(orgId, classId, configProperty.getProperty( "mathOnlyProduct" ), accessCode, teacherId);
                response = deleteGroup( classId, teacherId, orgId, accessCode );
                break;

            default:
                break;

        }

        // Validating Response Code and message
        VerifyResponseCode( response, expStatusCode );
        VerifyResponseMessage( response, CommonAPIConstants.GROUP_DELETE_SUCCESS_MESSAGE );

        // Verifying schema
        VerifySchema( CommonAPIConstants.STATUS_CODE_OK, response );
        Log.testCaseResult();
    }

    /**
     * Verify the schema for the api
     * 
     * @param StatusCode
     * @param Body
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = new SMAPIProcessor().isSchemaValid( "DeleteGroupSchema", StatusCode, response.get( DeleteGroupAPIConstants.BODY_FIELD ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
        Log.assertThat( isValid, "The schema is valid and mathcing", "The schema is not valid and not  mathcing for the Status code :" + StatusCode );
    }
    
	

    public void VerifyResponseCode( HashMap<String, String> response, String expectedCode ) {
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( expectedCode ), "Response status code is as expected - " + expectedCode,
                "Response status code is not as expected - Actual " + response.get( DeleteGroupAPIConstants.STATUSCODE_FIELD ) + " Expected " + expectedCode );
    }

    public void VerifyResponseMessage( HashMap<String, String> response, String expectedMessage ) {
    	boolean flag = false;

		String responseBody = response.get(Constants.REPORT_BODY);
		String message = SMUtils.getKeyValueFromResponse(responseBody, "messages,message");
		Log.message(message);
		flag = message.contains(expectedMessage) ? true : false;

        Log.assertThat( flag, "Message is matching as expected!", "The message is not matching not expected " + expectedMessage + " Actual " + message );
    }

    @DataProvider ( name = "deleteGroupPositiveScenariosData" )
    public Object[][] deleteGroupPositiveScenariosData() {

        Object[][] inputData = { { "SMK-15857- Verify the Response code 200 when the valid inputs are given", "VALID_SCENARIO", "200" },
                { "SMK-15862- Verify the response code, while deleting the group that does not have any students", "EMPTY_GROUP", "200" },
                { "SMK-15863- Verify the response code, while deleting the group that is not associated with SuccessMaker product", "NO_SM_PRODCUT", "200" },
                { "SMK-15870- Verify the response when you try to delete a group with shared students", "SHARED_STUDENT", "200" },
                { "SMK-15874- Verify the group is getting deleted in only one school when the teacher part of multiple school.", "MULTI_ORG_TEACHER", "200" },
                { "SMK-15875- Verify the group is getting deleted when the group has student with multiple schools.", "MULTI_ORG_STUDENT", "200" }, 
                { "SMK-15871- Verify the response when you try to delete a shared group", "SHARED_GROUP", "200" }

        };

        return inputData;
    }
}