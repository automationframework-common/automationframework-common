package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class StudentUsageChart extends BaseTest {

    private boolean isStudentCrossedHours = false;
    private static String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    String teacherDetails;
    String studentDetails;

    private String teacherId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;

    List<String> studentIdList = null;
    List<String> studentUserNames = null;

    private AtomicReference<String> schoolUsed = new AtomicReference<>();

    @BeforeClass
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        String teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        ArrayList<String> studentDetails = new ArrayList<>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<>();
        studentUserNames = new ArrayList<>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

    }

    @Test ( description = "Verify 'NO DATA YET' message shown if the student not attended any course", groups = { "SMK-39154", "usageChart", "studentUsageChart" }, priority = 1 )
    public void tcSMStudentUsage001() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "tcSMStudentUsage001: Verify 'NO DATA YET' message shown if the student not attended any course <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // navigate to Student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            String studentDetail = DataSetup.teacherStudentMap.get( username ).get( "Student2" );
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetail, "data,studentIdentificationNumber" ) );

            SMUtils.logDescriptionTC( "SMK-8188 - Verify 'NO DATA YET' message shown if the student not attended any course" );
            //Verify zero state message for student usage chart
            Log.assertThat( studentPage.verifyZeroStateForStudentUsageChart(), "Zero state message displayed sucessfully!", "Zero state message is not displayed properly." );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify student usage shown for the particular student", groups = { "SMK-39154", "usageChart", "studentUsageChart" }, priority = 1 )
    public void tcSMStudentUsage002() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMStudentUsage002: Verify student usage shown for the particular student. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Login with teacher credential
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetails, "data,studentIdentificationNumber" ) );

            SMUtils.logDescriptionTC( "SMK-8189 - Verify student usage shown for the particular student" );
            SMUtils.logDescriptionTC( "SMK-8190 - Verify the chart is shown to the student if he has attended any course" );
            SMUtils.logDescriptionTC( "SMK-8191 - Verify the titles 'THIS WEEK', 'LAST WEEK' and 'SCHOOL YEAR' are shown in capital letters" );
            SMUtils.logDescriptionTC( "SMK-8196 - Verify the Math and Reading legends are shown in the student usage" );
            //Verify  student usage chart fields
            Log.assertThat( studentPage.verifyStudentUsageChart(), "All fields displayed properly in student usage chart!", "Fields are not displayed properly in student usage chart." );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the chart is shown to the student if he has attended any course", dataProvider = "getUsageDataFromAPI", groups = { "SMK-39154", "usageChart", "studentUsageChart" }, priority = 2 )
    public void tcSMStudentUsage003( Map<String, HashMap<String, Integer>> usageHours, Map<String, Integer> individualFields ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "tcSMStudentUsage003: Verify the chart is shown to the student if he has attended any course. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            //Enter into student detail page
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetails, "data,studentIdentificationNumber" ) );

            SMUtils.logDescriptionTC( "SMK-8190 - Verify the chart is shown to the student if he has attended any course" );
            //Verify This week, Last week and School year in
            Log.assertThat( studentPage.verifyStudentUsageChartFieldsData( individualFields, isStudentCrossedHours ), "All fields data displayed properly in student usage chart!", "Fields data are not displayed properly in student usage chart." );

            // Verify student usage graph data
            Log.assertThat( studentPage.verifyStudentUsageGraph( usageHours, isStudentCrossedHours ), "Student usage graph data displayed properly", "Student usage graph not data displayed properly!" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if other teacher student has been added to the current teacher the student usage should display", dataProvider = "getUsageDataFromAPI", groups = { "SMK-39154", "usageChart", "studentUsageChart" }, priority = 2 )
    public void tcSMStudentUsage004( Map<String, HashMap<String, Integer>> usageHours, Map<String, Integer> individualFields ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMStudentUsage004: Verify if other teacher student has been added to the current teacher the student usage should display. <small><b><i>[" + browser + "]</b></i></small>" );
        String teacherUsername = "AutomatedTeacher_ForSharedStudentTest" + System.nanoTime();
        try {
            //Creating teacher for shared student test
            new UserSqlHelper().createTeacher( teacherUsername, teacherUsername, teacherUsername, Constants.PASSWORD_HASH, DataSetup.organizationId );

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            String groupName = "Atutomation" + System.nanoTime();
            groupsTab.createGroupWithSchoolStudents( groupName, SMUtils.getKeyValueFromResponse( studentDetails, "data,userName" ), "All Grades" );

            // navigate to student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetails, "data,studentIdentificationNumber" ) );

            SMUtils.logDescriptionTC( "SMK-8217 - Verify if other teacher student has been added to the current teacher the student usage should display" );
            // Verify student usage graph data
            Log.assertThat( studentPage.verifyStudentUsageGraph( usageHours, isStudentCrossedHours ), "Student usage graph data displayed properly", "Student usage graph not data displayed properly!" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if student assignment is deleted, then student usage will not show  usage hours", groups = { "SMK-39154", "usageChart", "studentUsageChart" }, priority = 2 )
    public void tcSMStudentUsage005() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "tcSMStudentUsage005: Verify if student assignment is deleted, then student usage will not show  usage hours. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetails, "data,studentIdentificationNumber" ) );
            studentPage.clickSubNavigation( "Assignments" );
            studentPage.removeStudentFromAssignment( Constants.UsageChart.MATH );
            studentPage.removeStudentFromAssignment( Constants.UsageChart.READING );

            // navigate to student Page
            studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetails, "data,studentIdentificationNumber" ) );

            SMUtils.logDescriptionTC( "SMk-8219 - Verify if student assignment is deleted, then student usage will not show  usage hours" );
            // Verify student usage graph data
            Log.assertThat( studentPage.verifyZeroStateForStudentUsageChart(), "Zero state message displayed sucessfully after delete the assignments!", "Zero state message is not displayed properly after delete the assignments." );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the chart shows only reading assignment information if student attends only reading assignment", groups = { "SMK-39154", "usageChart", "studentUsageChart" }, priority = 3 )
    public void tcSMStudentUsage006() throws Exception {
        EventFiringWebDriver driver = null;

        Log.testCaseInfo( "tcSMStudentUsage006: Verify the chart shows only reading assignment information if student attends only reading assignment. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            final WebDriver chromeDriver = WebDriverFactory.get( chromePlatform );
            String studentDetail = DataSetup.teacherStudentMap.get( username ).get( "Student2" );
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( SMUtils.getKeyValueFromResponse( studentDetail, "data,userName" ), password, true );
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "Reading", "95", "5", "20" );
            studentDashboardPage.logout();
            chromeDriver.quit();

            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		EventListener eventListner = new EventListener();
    		driver.register(eventListner);
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetail, "data,studentIdentificationNumber" ) );

            SMUtils.logDescriptionTC( "SMK-8208 - Verify the chart shows only reading assignment information if student attends only reading assignment" );
            SMUtils.logDescriptionTC( "SMK-8210 - Verify the chart when student has information for current week alone" );
            // Verify student usage graph data
            Log.assertThat( ( !studentPage.isStudentUsageMathBarDisplayed() ) && studentPage.isStudentUsageReadingBarDisplayed(), "The chart showed only reading assignment information if student attends only reading assignment",
                    "The chart not showed only reading assignment information if student attends only reading assignment" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the chart shows only math assignment information if student attends only math assignment", groups = { "SMK-39154", "usageChart", "studentUsageChart" }, dataProvider = "getUsageDataFromAPIForMathAlone", priority = 3 )
    public void tcSMStudentUsage007( Map<String, HashMap<String, Integer>> usageHours, Map<String, Integer> individualFields ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMStudentUsage007: Verify the chart shows only math assignment information if student attends only math assignment <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );
            String studentDetail = DataSetup.teacherStudentMap.get( username ).get( "Student3" );
            // navigate to student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentPage.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( studentDetail, "data,studentIdentificationNumber" ) );

            SMUtils.logDescriptionTC( "SMK-8190 - Verify the chart is shown to the student if he has attended any course" );
            SMUtils.logDescriptionTC( "SMK-8191 - Verify the titles 'THIS WEEK', 'LAST WEEK' and 'SCHOOL YEAR' are shown in capital letters" );
            SMUtils.logDescriptionTC( "SMK-8196 - Verify the Math and Reading legends are shown in the student usage" );
            //Verify  student usage chart fields
            Log.assertThat( studentPage.verifyStudentUsageChart(), "All fields displayed properly in student usage chart!", "Fields are not displayed properly in student usage chart." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8200 - Verify the THIS WEEK information shows the sum of reading and math assignments" );
            SMUtils.logDescriptionTC( "SMK-8202 - Verify the SCHOOL YEAR information shows the sum of reading and math assignments" );
            SMUtils.logDescriptionTC( "SMK-8203 - Verify the minutes of reading and math courses are shown correctly in the chart" );
            SMUtils.logDescriptionTC( "SMK-8193 - Verify 'THIS WEEK' hours show in hours/minutes" );
            SMUtils.logDescriptionTC( "SMK-8194 - Verify 'LAST WEEK' hours show in hours/minutes" );
            SMUtils.logDescriptionTC( "SMK-8195- Verify 'SCHOOL YEAR' hours show in hours" );
            //Verify This week, Last week and School year in
            Log.assertThat( studentPage.verifyStudentUsageChartFieldsData( individualFields, isStudentCrossedHours ), "All fields data displayed properly in student usage chart!", "Fields data are not displayed properly in student usage chart." );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8203 - Verify the minutes of reading and math courses are shown correctly in the chart" );
            SMUtils.logDescriptionTC( "SMK-8205 - Verify when hovering the mouse over each week on any assignment the total time spent for the assignment is shown" );
            SMUtils.logDescriptionTC( "SMK-8197 - Verify the date's shown on the x-axis are start of the week and it should be Monday" );
            SMUtils.logDescriptionTC( "SMK-8198 - Verify the date's shown in the chart are in the format mm/dd" );
            SMUtils.logDescriptionTC( "SMK-8206 - Verify the total time includes all the math courses" );
            SMUtils.logDescriptionTC( "SMK-8207 - Verify the total time includes all the reading courses" );
            // Verify student usage graph data
            Log.assertThat( studentPage.verifyStudentUsageGraph( usageHours, isStudentCrossedHours ), "Student usage graph data displayed properly", "Student usage graph not data displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8209 - Verify the chart shows only math assignment information if student attends only math assignment" );
            // Verify student usage graph data
            Log.assertThat( studentPage.isStudentUsageMathBarDisplayed() && ( !studentPage.isStudentUsageReadingBarDisplayed() ), "The chart showed only math assignment information if student attends only math assignment",
                    "The chart not showed only math assignment information if student attends only math assignment" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8199 - Verify the chart columns for each week which shows reading at the bottom and math at the top" );
            SMUtils.logDescriptionTC( "SMK-8215 - Verify the color code of reading and math assignment in the chart" );
            Log.assertThat( studentPage.getOrderOfSubjectinUsageGraph().get( 0 ).equals( Constants.READING ), "The chart displayed the reading at bottom", "The chart not displayed the reading at bottom" );
            Log.assertThat( studentPage.getOrderOfSubjectinUsageGraph().get( 1 ).equals( Constants.MATH ), "The chart displayed the math at top", "The chart not math the reading at top" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8216 - Verify the order of the legends in the chart" );
            List<String> legends = studentPage.getLegends();
            Log.assertThat( legends.get( 0 ).equals( Constants.MATH ) && legends.get( 1 ).equals( Constants.READING ), "Legends are displayed in proper order.", "Legends are not displayed in proper order" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @DataProvider ( name = "getUsageDataFromAPI" )
    public Object[][] getUsageDataFromAPI() throws Exception {
        HashMap<String, String> response = new HashMap<>();

        // headers
        String sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.COOKIES, sessionCookie );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // InputParams
        HashMap<String, String> params = new HashMap<>();
        params.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentDetails, "data,personId" ) );

        // end point
        String endPoint = Constants.POST_STUDENT_USAGE;
        endPoint = endPoint.replace( Constants.ORG_ID, DataSetup.organizationId.toString() );
        endPoint = endPoint.replace( Constants.STAFF_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ) );

        //getting student usage data from API
        response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, "" );
        String reponseData = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data" );
        HashMap<String, HashMap<String, Integer>> usageHours = new HashMap<>();
        HashMap<String, Integer> individualFields = new HashMap<>();
        List<String> lastFourWeeks = StudentsPage.getFourWeeksMonday();
        isStudentCrossedHours = false;
        for ( int week = 0; week < 4; week++ ) {
            HashMap<String, Integer> subjectUsage = new HashMap<>();
            JSONObject jsonObj = new JSONObject( reponseData );
            JSONArray ja = jsonObj.getJSONArray( "studentUsageData" );
            JSONObject jObj = ja.getJSONObject( week );
            subjectUsage.put( Constants.UsageChart.MATH, Integer.parseInt( jObj.get( "mathMins" ).toString() ) );
            subjectUsage.put( Constants.UsageChart.READING, Integer.parseInt( jObj.get( "readingMins" ).toString() ) );
            subjectUsage.put( Constants.UsageChart.TOTAL, subjectUsage.get( "Math" ) + subjectUsage.get( "Reading" ) );
            if ( subjectUsage.get( Constants.UsageChart.MATH ) + subjectUsage.get( Constants.UsageChart.READING ) > 60 ) {
                isStudentCrossedHours = true;
            }
            usageHours.put( lastFourWeeks.get( week ), subjectUsage );
        }

        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 0 ), Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, "thisWeekMins" ) ) );
        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 1 ), Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, "lastWeekMins" ) ) );
        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 2 ), Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, "totalMinutes" ) ) );

        Object[][] studentUsagDataFromAPI = { { usageHours, individualFields } };
        return studentUsagDataFromAPI;
    }

    @DataProvider ( name = "getUsageDataFromAPIForMathAlone" )
    public Object[][] getUsageDataFromAPIForMathAlone() throws Exception {
        HashMap<String, String> response = new HashMap<>();

        // headers
        String sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.COOKIES, sessionCookie );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        // InputParams
        HashMap<String, String> params = new HashMap<>();
        String studentDetail = DataSetup.teacherStudentMap.get( username ).get( "Student3" );
        params.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentDetail, "data,personId" ) );

        // end point
        String endPoint = Constants.POST_STUDENT_USAGE;
        endPoint = endPoint.replace( Constants.ORG_ID, DataSetup.organizationId.toString() );
        endPoint = endPoint.replace( Constants.STAFF_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ) );

        //getting student usage data from API
        response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, "" );
        String reponseData = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data" );
        HashMap<String, HashMap<String, Integer>> usageHours = new HashMap<>();
        HashMap<String, Integer> individualFields = new HashMap<>();
        List<String> lastFourWeeks = StudentsPage.getFourWeeksMonday();
        isStudentCrossedHours = false;
        for ( int week = 0; week < 4; week++ ) {
            HashMap<String, Integer> subjectUsage = new HashMap<>();
            JSONObject jsonObj = new JSONObject( reponseData );
            JSONArray ja = jsonObj.getJSONArray( "studentUsageData" );
            JSONObject jObj = ja.getJSONObject( week );
            subjectUsage.put( Constants.UsageChart.MATH, Integer.parseInt( jObj.get( "mathMins" ).toString() ) );
            subjectUsage.put( Constants.UsageChart.READING, Integer.parseInt( jObj.get( "readingMins" ).toString() ) );
            subjectUsage.put( Constants.UsageChart.TOTAL, subjectUsage.get( "Math" ) + subjectUsage.get( "Reading" ) );
            if ( subjectUsage.get( Constants.UsageChart.MATH ) + subjectUsage.get( Constants.UsageChart.READING ) > 60 ) {
                isStudentCrossedHours = true;
            }
            usageHours.put( lastFourWeeks.get( week ), subjectUsage );
        }

        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 0 ), Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, "thisWeekMins" ) ) );
        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 1 ), Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, "lastWeekMins" ) ) );
        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 2 ), Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, "totalMinutes" ) ) );

        Object[][] studentUsagDataFromAPI = { { usageHours, individualFields } };
        return studentUsagDataFromAPI;
    }
}
