package com.savvas.sm.teacher.ui.tests.SmokeSuite;

import java.util.Arrays;
import java.util.List;

import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

/*
 * How to Use simulator method
 */

public class Simulator extends BaseTest {

    private String smUrl;
    private String browser;
    List<String> expectedCourseTypesInDropdown = Arrays.asList( "Focus Courses", "Default Courses", "Custom Courses", "All Courses" );

    @BeforeTest
    public void initTest( ITestContext context ) {
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher2" );
        //        username = SMUtils.getKeyValueFromResponse(teacherDetails, "data,userId");
        //        schoolID = SMUtils.getKeyValueFromResponse(teacherDetails, "data,organizationId").replaceAll("[^0-9]", "");
        //        teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId");

        Log.message( "teacherDetails: " + teacherDetails );
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
    }

    @Test ( description = "Verify Student Tab", priority = 1 )
    public void tcSimulatorSample( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        // Get Test Data

        Log.testCaseInfo( "tcSMBVT005: Verify Student Tab <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            StudentDashboardPage studentsPage = smLoginPage.loginToSMasStudent( "rc_student01", "rc_student01", true );
            //            TeacherHomePage studentsPage = smLoginPage.loginToSM( "teacher7", "teacher7", true );

            //            SqlHelperUsage.shareUsageData("RVC_org2");

            studentsPage.executeReadingCourse( "teacher7", "Reading", "100", "1", "5" );

            //            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            //            studentsPage.clickviewStudentByEllipsis("Grade_11");
            SMUtils.nap( 1 );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

}
