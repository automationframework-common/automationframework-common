package com.savvas.sm.api.tests.smnew.courses;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

/**
 * This class is used to test the delete course API
 *
 * @author Subbu
 */

public class DeleteCourseAPITest extends CourseAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private final String orgUsed = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String smUrl;
    String teacherUsed;
    String orgId;
    String teacherId;
    String username;
    String accessCode;
    RBSUtils rbsutils = new RBSUtils();
    private String token = null;
    String userName = null;
    AssignmentAPI assignmentObg = new AssignmentAPI();
    String flexSchoolStudentDetails;
    String StudentId;
    GroupAPI groupApi;

    @BeforeClass ( alwaysRun = true )
    public void InitializedSchoolData() throws IOException {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        // Teacher used Details
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        teacherUsed = RBSDataSetup.getMyTeacher( orgUsed );
        JSONObject teacherJson = new JSONObject( teacherUsed );
        teacherId = new SMAPIProcessor().getKeyValues( teacherJson, RBSDataSetupConstants.USERID ).get( 0 );
        username = new SMAPIProcessor().getKeyValues( teacherJson, RBSDataSetupConstants.USERNAME ).get( 0 );

        flexSchoolStudentDetails = RBSDataSetup.getMyStudent( orgUsed, username );
        groupApi = new GroupAPI();
    }

    //This is default course test cases and custom Courses test cases will be added later and during custom course deletion the course existence in DB will be checked after custom course deletion
    @Test ( dataProvider = "DeleteCoursePositiveScenarios", groups = { "SMK-52111", "Delete Default Course from School", "Course", "P1", "API", "smoke_test_case" } )
    public void deleteDefaultCoursePositiveScenarios( String description, String scenario, String statusCode, String courseid, String status, String message ) throws Exception {
        Log.testCaseInfo( description );
        // Authorization
        accessCode = rbsutils.getAccessToken( SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Map<String, String> response = null;
        response = getResponse( teacherId, orgId, accessCode, courseid );
        // Validations
        if ( response != null ) {
            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Response status code is as expected - " + response.get( "statusCode" ), "Response status code is not as expected - " + response.get( "statusCode" ) );
            Log.message( "Delete Response: " + response.get( Constants.REPORT_BODY ) );
            if ( smUrl.contains( Constants.NIGHTLY_SM_URL ) ) {
                VerifySchema( response.get( "statusCode" ), response.get( Constants.REPORT_BODY ) );
                verifyResponse( response.get( Constants.REPORT_BODY ), message, status );
            }
        } else {
            Log.fail( "Response is null" );
        }
        Log.testCaseResult();
    }

    //This is default course test cases and custom Courses test cases will be added later and during custom course deletion the course existence in DB will be checked after custom course deletion
    @Test ( dataProvider = "DeleteCourseNegativeScenarios", priority = 2, groups = { "SMK-52111", "Delete Default Course from School", "Course", "P1", "API" } )
    public void deleteDefaultCourseNegativeScenarios( String description, String scenario, String statusCode, String courseid, String status, String message ) throws Exception {
        Log.testCaseInfo( description );
        // Authorization
        accessCode = rbsutils.getAccessToken( SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Map<String, String> response = null;
        if ( scenario.equalsIgnoreCase( "INVALID_BEARER_TOKEN" ) ) {
            response = getResponse( teacherId, orgId, "ABC", courseid );
        } else {
            response = getResponse( teacherId, orgId, accessCode, courseid );
        }

        if ( response != null ) {
            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Response status code is as expected - " + response.get( "statusCode" ), "Response status code is not as expected - " + response.get( "statusCode" ) );
            VerifySchema( response.get( "statusCode" ), response.get( Constants.REPORT_BODY ) );
            verifyResponse( response.get( Constants.REPORT_BODY ), message, status );
        } else {
            Log.fail( "Response is null" );
        }
        Log.testCaseResult();
    }

    //This is default course test cases and custom Courses test cases will be added later and during custom course deletion the course existence in DB will be checked after custom course deletion
    @Test ( dataProvider = "DeleteAssignedCourseScenarios", priority = 2, groups = { "SMK-52111", "Delete Default Course from School", "Course", "P1", "API" } )
    public void deleteAssignedCourseScenarios( String description, String statusCode, String courseId, String scenario, String scenario1 ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );

        HashMap<String, String> apiResponse_createSettingBasedCourse = new HashMap<>();
        HashMap<String, String> courseDetails = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();
        Map<String, String> response = null;
        Map<String, String> response_deleteAssignedCourse = null;

        Map<String, String> response_AlreadyDeletedCourse = null;
        StudentId = SMUtils.getKeyValueFromResponse( flexSchoolStudentDetails, "userId" );

        //Authorization
        accessCode = rbsutils.getAccessToken( SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Create Custom course by setting
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
        headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( orgUsed ) );
        headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherUsed, "userId" ) );

        //course details
        //courseDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        courseDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherUsed, "userId" ) );
        courseDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
        courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
        courseDetails.put( Constants.COURSE_NAME, "Settings" + System.nanoTime() );

        //Creating custom by setting course
        apiResponse_createSettingBasedCourse = createCourseBySetting( smUrl, headers, courseDetails, scenario );
        Log.message( "response from PostCall for setting based course- " + apiResponse_createSettingBasedCourse );
        String customCourseId = SMUtils.getKeyValueFromResponse( apiResponse_createSettingBasedCourse.get( Constants.REPORT_BODY ), "data,id" );

        switch ( scenario1 ) {
            case "Custom_Course_Deletion":

                response = getResponse( teacherId, orgId, accessCode, customCourseId );
                Log.message( "response from deletete course- " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Response status code is as expected - " + response.get( "statusCode" ), "Response status code is not as expected - " + response.get( "statusCode" ) );
                break;

            case "AlreadyDeleted_Course_Deletion":

                response = getResponse( teacherId, orgId, accessCode, customCourseId );
                Log.message( "response from deletete course- " + response );
                response_AlreadyDeletedCourse = getResponse( teacherId, orgId, accessCode, customCourseId );
                Log.message( "response from already deletete course- " + response_AlreadyDeletedCourse );
                Log.assertThat( response_AlreadyDeletedCourse.get( Constants.STATUS_CODE ).equals( statusCode ), "Response status code is as expected - " + response_AlreadyDeletedCourse.get( "statusCode" ),
                        "Response status code is not as expected - " + response_AlreadyDeletedCourse.get( "statusCode" ) );
                VerifySchema( response_AlreadyDeletedCourse.get( "statusCode" ), response_AlreadyDeletedCourse.get( Constants.REPORT_BODY ) );

                break;

            case "Assigned_Course_Deletion":

                //Assigning a newly created course to student
                List<String> studentRumbaIdsTc001 = new ArrayList<>();

                //Adding students to group
                studentRumbaIdsTc001 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, accessCode, orgUsed );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, customCourseId, orgUsed, studentRumbaIdsTc001.get( 0 ) );

                //deleting a assigned custom course.
                response_deleteAssignedCourse = getResponse( teacherId, orgId, accessCode, customCourseId );
                Log.message( "response from deletet assign course- " + response_deleteAssignedCourse );

                Log.assertThat( response_deleteAssignedCourse.get( Constants.STATUS_CODE ).equals( statusCode ), "Response status code is as expected - " + response_deleteAssignedCourse.get( "statusCode" ),
                        "Response status code is not as expected - " + response_deleteAssignedCourse.get( "statusCode" ) );
                VerifySchema( response_deleteAssignedCourse.get( "statusCode" ), response_deleteAssignedCourse.get( Constants.REPORT_BODY ) );

                break;
        }
        Log.testCaseResult();
    }

    @DataProvider ( name = "DeleteAssignedCourseScenarios" )
    public Object[][] groupDataAssignedCourseValid() {

        Object[][] inputData = { { "TC001_Verify the status code is 200  when the teacher has deleted the unassigned custom course.", "200", "2", "READING", "Custom_Course_Deletion" },
                { "TC003_Verify the status code is 400 when the deletion of a course which is assigned to one or multiple student.", "400", "2", "READING", "Assigned_Course_Deletion" },
                { "TC004 _Verify the status code is 400 when Validate the deletion of a course which is assigned to one or multiple Group.", "400", "2", "READING", "Assigned_Course_Deletion" },
                { "TC012_Verify the status code is 200 when the deletion of a course which is already deleted by teacher.", "200", "2", "READING", "AlreadyDeleted_Course_Deletion", }, };

        return inputData;
    }

    @DataProvider ( name = "DeleteCoursePositiveScenarios" )
    public Object[][] groupDataValid() {

        Object[][] inputData = { { "Verify the status code is 400  when the deletion of a default math course belongs to the organization", "DELETE_DEFAULT_MATH", "400", "1", "failure", CommonAPIConstants.DEFAULT_COURSE_DELETE_MESSAGE + "1" },
                { "Verify the status code is 400  when the deletion of a default reading course belongs to the organization", "DELETE_DEFAULT_READING", "400", "2", "failure", CommonAPIConstants.DEFAULT_COURSE_DELETE_MESSAGE + "2" },
                { "Verify the status code is 400  when the deletion of a SM Focus Math course belongs to the organization", "DELETE_SM_FOCUS_MATH", "400", "3", "failure", CommonAPIConstants.SMFOCUS_COURSE_DELETE_MESSAGE + "3" },
                { "Verify the status code is 400  when the deletion of a SM Focus Reading course belongs to the organization", "DELETE_SM_FOCUS_READING", "400", "11", "failure", CommonAPIConstants.SMFOCUS_COURSE_DELETE_MESSAGE + "11" },

        };
        return inputData;
    }

    @DataProvider ( name = "DeleteCourseNegativeScenarios" )
    public Object[][] groupDataInvalid() {

        Object[][] inputData = {
                { "Verify the status code is 200 (data not found) when non existing course id is given", "DELETE_NOT_EXISTING_ID", "200", "1791271", "failure",
                        CommonAPIConstants.COURSE_DELETE_NON_EXISTING_ID_MESSAGE.replaceFirst( "courseid", "1791271" ).replaceFirst( "orgId", orgId ) },
                { "Verify the status code is 400 when invalid course id(@#) is given", "DELETE_INVALID_COURSE_ID", "400", "@#", "failure", CommonAPIConstants.COURSE_DELETE_INVALID_MESSAGE },
                { "Verify the status code is 400 when invalid course(abc) id is given", "DELETE_INVALID_COURSE_ID_ABC", "400", "abc", "failure", CommonAPIConstants.COURSE_DELETE_INVALID_MESSAGE },
                { "Verify the status code is 400 when invalid course(null) id is given", "DELETE_INVALID_COURSE_ID_NULL", "400", "null", "failure", CommonAPIConstants.COURSE_DELETE_INVALID_MESSAGE },
                { "Verify the status code is 401 when the invalid bearer token is given", "INVALID_BEARER_TOKEN", "401", "1", "failure", CommonAPIConstants.COURSE_DELETE_INVALID_BEARER_TOKEN }, };
        return inputData;
    }

    //Adding Students to group
    public List<String> addStudentsToGroup( String statusCode, String userName, String school ) {
        HashMap<String, String> response;
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        try {
            //Adding students to group
            String groupName = "Successmaker API Test Group " + System.nanoTime();
            studentRumbaIds.add( StudentId );
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, userName );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherUsed, "userId" ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            Log.message( "groupDetails is " + groupDetails );
            GroupAPI GroupAPI = new GroupAPI();
            response = GroupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );
            Log.message( "response for group creation is " + response );
            Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        } catch ( Exception e ) {
            Log.message( "Issue occured in addStudentsToGroup" );
        }
        return studentRumbaIds;
    }

    //Assigning assignment to student
    public void addAssignmentsToStudents( String statusCode, String courseId, String school, String studentRumbaId ) {
        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentRumbaId );
        try {
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessCode );
            assignmentDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherUsed, "userId" ) );
            assignmentDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            assignmentDetails.put( CourseAPIConstants.COURSE_ID, courseId );
            HashMap<String, String> assignCourseToTheStudent = assignmentObg.assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
            if ( assignCourseToTheStudent.get( Constants.STATUS_CODE ).equals( statusCode ) ) {
                Log.message( "Course has been assigned to the student!" );
            } else {
                Log.message( "Something went wrong while assigning the course to the student! - " + assignCourseToTheStudent.get( Constants.REPORT_BODY ) );
            }
        } catch ( Exception e ) {
            Log.message( "Issue occured in addAssignmentsToStudents" );
        }
    }

    /**
     * Verify the schema for the api
     *
     * @param StatusCode
     * @param Body
     */
    public void VerifySchema( String StatusCode, String Body ) {
        boolean isValid = false;
        try {
            isValid = new SMAPIProcessor().isSchemaValid( "deletecourse", StatusCode, Body );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        Log.assertThat( isValid, "The schema is valid and matching", "The schema is not valid and not  matching for the Status code :" + StatusCode );
    }

    /**
     * Get response for the Delete Course API
     *
     * @param teacherId
     * @param orgId
     * @param accessToken
     * @param courseId
     * @return
     */
    public Map<String, String> getResponse( String teacherId, String orgId, String accessToken, String courseId ) {
        try {
            // Endpoint
            String endpoint = CourseAPIConstants.DELETE_COURSE_API;
            endpoint = endpoint.replace( Constants.ORG_ID, orgId );
            endpoint = endpoint.replace( Constants.STAFF_ID, teacherId );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseId );
            // headers
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.USERID_SM_HEADER, teacherId );

            // Make DELETE Call
            Log.message( "Making DELETE Call - " + configProperty.getProperty( "SMAppUrl" ) + endpoint );
            return RestHttpClientUtil.DELETE( configProperty.getProperty( "SMAppUrl" ), headers, new HashMap<String, String>(), endpoint, "" );
        } catch ( Exception e ) {
            Log.message( "Error in response method" );
        }
        return null;

    }

    public void verifyResponse( String actualResponse, String message, String status ) {

        try {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
                Log.pass( CommonAPIConstants.COURSE_DELETE_SUCCESS_MESSAGE );
            } else {
                Log.fail( CommonAPIConstants.COURSE_DELETE_FAILURE_MESSAGE );
            }
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( status ) ) {
                Log.pass( CommonAPIConstants.COURSE_DELETE_SUCCESS_STATUS );
            } else {
                Log.fail( CommonAPIConstants.COURSE_DELETE_FAILURE_STATUS );
            }

        } catch ( Exception e ) {
            Log.message( "Error in verifyResponse method" );
        }

    }

    /**
     * Get response for the Create Course By Setting API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySetting( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySetting= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "READING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsReadingPayload" ) ) );

            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsMathPayload" ) ) );
            }

            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySetting method" );
            return null;
        }
    }
}
