package com.savvas.sm.students.bff.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.restoreassignment.RestoreAssignment;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.student.api.dashboard.StudentAPI;

import io.restassured.response.Response;

public class GetAssignmentListBffTest extends EnvProperties {

    private static String smUrl;
    private static String orgName;
    private static String orgId;
    private static String teacherDetails;
    private static String mathTeacherDetails;
    private static String teacherUsername;
    private static String teacherUserId;
    private static String token;
    private static String studentUsername;
    private static String studentUserId;
    private static String studentAccessToken;
    private static String deletedAssigmentUserId;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private static Response responseBff;
    private static Response responseApi;
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static List<String> courseIds = new ArrayList<>();
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static HashMap<String, String> assignmentIds = new HashMap<>();
    private static Map<String, String> headers = new HashMap<>();
    StudentAPI studentDashboard = new StudentAPI();

    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        orgName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( orgName );

        teacherDetails = RBSDataSetup.getMyTeacher( orgName );
        mathTeacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID );
        token = new RBSUtils().getAccessToken( teacherUsername, password );

        String studentDetails = RBSDataSetup.getMyStudent( orgName, teacherUsername );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, Constants.USER_NAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, Constants.USERID );

        studentAccessToken = new RBSUtils().getAccessToken( studentUsername, password );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, "SM Focus Math: Grade 1" );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, "SM Focus Reading: Grade 1" );

        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.STANDARD, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING_1 );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        courseIds.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        courseIds.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIds.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        Log.message( "Assigning assignment..." );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentUserId ), courseIds );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }
        Log.message( "Assignment IDs - " + assignmentIds );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + studentAccessToken );
        headers.put( Constants.USERID_SM_HEADER, studentUserId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        responseApi = studentDashboard.getAssignmentListForStudent( smUrl, orgId, studentUserId, studentAccessToken );
        responseBff = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, studentUserId, headers );
        Log.message( "Response Bff- " + responseBff.getBody().asString() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest001() throws IOException {

        Log.testCaseInfo( "tc:001 - Verify the status code 200 and response while passing the proper cred in getStudentAssignment Bff" );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );

        JSONArray jsonArrayApi = new JSONObject( responseApi.getBody().asString() ).getJSONArray( "data" );
        Map<String, Map<String, String>> assignmentsFromResponseAPI = new HashMap<>();
        for ( Object object : jsonArrayApi ) {
            Map<String, String> assignmentFromResponseAPI = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseAPI.put( assignmentFromResponseAPI.get( "assignmentUserId" ), assignmentFromResponseAPI );
        }
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );

        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentUserId" ), assignmentFromResponseBff );

        }
        Log.assertThat(
                assignmentsFromResponseAPI.entrySet().stream().allMatch( assignmentFromResponseAPI -> assignmentFromResponseAPI.getValue().keySet().stream().allMatch(
                        key -> assignmentFromResponseAPI.getValue().get( key ).equalsIgnoreCase( assignmentsFromResponseBff.get( assignmentFromResponseAPI.getKey() ).get( key ) ) ) ),
                "All the assignments are fetched properly in the BFF response", "All the assignments are not fetched properly in the BFF response. Expected - " + assignmentsFromResponseAPI + ".Actual - " + assignmentsFromResponseBff );

        //Schema validation
        try {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "GetStudentAssignmentBff", String.valueOf( responseBff.getStatusCode() ), responseBff.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
        } catch ( Exception e ) {
            Log.message( "Getting Issue while validate the schema.Exception -" + e.getMessage() );
            e.printStackTrace();
        }
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest002() throws IOException {

        Log.testCaseInfo( "tc:002 - Verify the status code 200 and fields are displaying properly in the response body" );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );

        JSONArray jsonArrayApi = new JSONObject( responseApi.getBody().asString() ).getJSONArray( "data" );
        Map<String, Map<String, String>> assignmentsFromResponseAPI = new HashMap<>();
        for ( Object object : jsonArrayApi ) {
            Map<String, String> assignmentFromResponseAPI = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseAPI.put( assignmentFromResponseAPI.get( "assignmentUserId" ), assignmentFromResponseAPI );
        }
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );

        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentUserId" ), assignmentFromResponseBff );

        }
        Log.assertThat(
                assignmentsFromResponseAPI.entrySet().stream().allMatch( assignmentFromResponseAPI -> assignmentFromResponseAPI.getValue().keySet().stream().allMatch(
                        key -> assignmentFromResponseAPI.getValue().get( key ).equalsIgnoreCase( assignmentsFromResponseBff.get( assignmentFromResponseAPI.getKey() ).get( key ) ) ) ),
                "All the assignments are fetched properly in the BFF response", "All the assignments are not fetched properly in the BFF response. Expected - " + assignmentsFromResponseAPI + ".Actual - " + assignmentsFromResponseBff );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest003() throws IOException {

        Log.testCaseInfo( "tc:003 - Verify the status code 200 and response if the student has default courses" );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) ).get( "courseName" ).equalsIgnoreCase( AssignmentAPIConstants.MATH_COURSE ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) ).get( "courseType" ).equalsIgnoreCase( AssignmentAPIConstants.MATH ), "Course name and Course type are fetched properly in the BFF response",
                "Course name and Course type are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( AssignmentAPIConstants.READING_COURSE ) ).get( "courseName" ).equalsIgnoreCase( AssignmentAPIConstants.READING_COURSE ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( AssignmentAPIConstants.READING_COURSE ) ).get( "courseType" ).equalsIgnoreCase( AssignmentAPIConstants.MATH ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest004() throws IOException {

        Log.testCaseInfo( "tc:004 - Verify the status code 200 and response if the student has focus courses" );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }
        Log.assertThat(
                assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) ) ).get( "courseName" ).equalsIgnoreCase(
                        contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) ) ).get( "courseType" ).equalsIgnoreCase( AssignmentAPIConstants.FOCUS_MATH_2 ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );
        Log.assertThat(
                assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) ) ).get( "courseName" ).equalsIgnoreCase(
                        contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) ) ).get( "courseType" ).equalsIgnoreCase( AssignmentAPIConstants.FOCUS_MATH_2 ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest005() throws IOException {

        Log.testCaseInfo( "tc:005 - Verify the status code 200 and response if the student has custom courses" );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }
        Log.assertThat(
                assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ).get( "courseName" ).equalsIgnoreCase(
                        contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ).get( "courseType" ).equalsIgnoreCase( AssignmentAPIConstants.READING ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );

        Log.assertThat(
                assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ).get( "courseName" ).equalsIgnoreCase(
                        contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ).get( "courseType" ).equalsIgnoreCase( AssignmentAPIConstants.READING ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );

        Log.assertThat(
                assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ).get( "courseName" ).equalsIgnoreCase(
                        contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ).get( "courseType" ).equalsIgnoreCase( AssignmentAPIConstants.FOCUS_MATH ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );

        Log.assertThat(
                assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) ).get( "courseName" ).equalsIgnoreCase(
                        contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) ).get( "courseType" ).equalsIgnoreCase( AssignmentAPIConstants.FOCUS_MATH_2 ),
                "Course name and Course type are fetched properly in the BFF response", "Course name and Course type are not fetched properly in the BFF response." );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest006() throws IOException {

        Log.testCaseInfo( "tc:006 - Verify the status code 200 and creatorFirstName, creatorTitle  in bff response if user update the creator first name" );

        String updatedFirstName = "John";
        try {
            //To update the teacher detail
            HashMap<String, String> teacherDetail = new HashMap<>();
            JSONObject teacher = new JSONObject( teacherDetails );
            teacherDetail.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            teacherDetail.put( UserConstants.USERID, teacher.get( "userId" ).toString() );
            teacherDetail.put( UserConstants.ORGID, orgId );
            teacherDetail.put( UserConstants.STAFFID, teacher.get( "userId" ).toString() );
            teacherDetail.put( "personId", teacher.get( "userId" ).toString() );
            teacherDetail.put( "firstName", updatedFirstName );
            teacherDetail.put( "middleName", teacher.get( "middleName" ).toString() );
            teacherDetail.put( "lastName", teacher.get( "lastName" ).toString() );
            teacherDetail.put( "email", new JSONObject( teacher.getJSONArray( "emailInfo" ).get( 0 ).toString() ).get( "emailAddress" ).toString() );
            teacherDetail.put( "userName", teacher.get( "userName" ).toString() );
            teacherDetail.put( "title", "DR" );
            teacherDetail.put( "userPassword", password );
            teacherDetail.put( "oldPassword", password );

            HashMap<String, String> updateStaffProfile = new UserAPI().updateStaffProfile( smUrl, teacherDetail );
            Log.message( updateStaffProfile.toString() );
        } catch ( Exception e ) {
            Log.message( "Getting issue while update the teacher profile" );
            e.printStackTrace();
        }

        Response response = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, studentUserId, headers );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONObject( "data" ).getJSONArray( "getStudentAssignments" );
        String teacherFirstName = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ) {
                teacherFirstName = SMUtils.getKeyValueFromResponse( object.toString(), "creatorFirstName" );
                break;
            }
        }

        Log.assertThat( teacherFirstName.equalsIgnoreCase( updatedFirstName ), "Updated teacher first name is fetched properly in the response", "Updated teacher first name  is not fetching in the API response" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest007() throws IOException {

        Log.testCaseInfo( "tc:007 - Verify the status code 200 and creatorLastName in bff response if user update the creator last name" );

        String updatedLastName = "Stephen";
        try {
            //To update the teacher detail
            HashMap<String, String> teacherDetail = new HashMap<>();
            JSONObject teacher = new JSONObject( teacherDetails );
            teacherDetail.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            teacherDetail.put( UserConstants.USERID, teacher.get( "userId" ).toString() );
            teacherDetail.put( UserConstants.ORGID, orgId );
            teacherDetail.put( UserConstants.STAFFID, teacher.get( "userId" ).toString() );
            teacherDetail.put( "personId", teacher.get( "userId" ).toString() );
            teacherDetail.put( "firstName", teacher.get( "firstName" ).toString() );
            teacherDetail.put( "middleName", teacher.get( "middleName" ).toString() );
            teacherDetail.put( "lastName", updatedLastName );
            teacherDetail.put( "email", new JSONObject( teacher.getJSONArray( "emailInfo" ).get( 0 ).toString() ).get( "emailAddress" ).toString() );
            teacherDetail.put( "userName", teacher.get( "userName" ).toString() );
            teacherDetail.put( "title", "DR" );
            teacherDetail.put( "userPassword", password );
            teacherDetail.put( "oldPassword", password );

            HashMap<String, String> updateStaffProfile = new UserAPI().updateStaffProfile( smUrl, teacherDetail );
            Log.message( updateStaffProfile.toString() );
        } catch ( Exception e ) {
            Log.message( "Getting issue while update the teacher profile" );
            e.printStackTrace();
        }

        Response response = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, studentUserId, headers );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONObject( "data" ).getJSONArray( "getStudentAssignments" );
        String teacherLastName = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ) {
                teacherLastName = SMUtils.getKeyValueFromResponse( object.toString(), "creatorLastName" );
                break;
            }
        }

        Log.assertThat( teacherLastName.equalsIgnoreCase( updatedLastName ), "Updated teacher Last name is fetched properly in the response", "Updated teacher Last name  is not fetching in the API response" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest008() throws IOException {

        Log.testCaseInfo( "tc:008 - Verify the status code 200 and response if user delete the assignment" );

        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }

        //To delete the Reading assignment
        deletedAssigmentUserId = assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ).get( "assignmentUserId" );
        try {
            assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, deletedAssigmentUserId );
            new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        Response responseBff = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, studentUserId, headers );
        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );

        keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }
        Log.assertThat( !assignmentsFromResponseBff.containsKey( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ), "Deleted  assignment are not displayed in the BFF response",
                "Deleted  assignment are displayed in the BFF response" );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest009() throws IOException {

        Log.testCaseInfo( "tc:009 - Verify the status code 200 and response if user restore the assignment" );

        // Getting savvas admin details in RBS Datasetup
        String savvasAdminUserName = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
        String savvasAdminDetails = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
        String savvasAdminUserId = SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERID );
        String savvasAdminAccessToken = new RBSUtils().getAccessToken( savvasAdminUserName, password );

        HashMap<String, String> savvasAdminheaders = new HashMap<>();
        savvasAdminheaders.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        savvasAdminheaders.put( Constants.AUTHORIZATION, "Bearer " + savvasAdminAccessToken );
        savvasAdminheaders.put( Constants.USERID_SM_HEADER, savvasAdminUserId );
        savvasAdminheaders.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );

        //To restore the Assignment
        Response response = new RestoreAssignment().restoreAssignmentBFF( savvasAdminheaders, deletedAssigmentUserId, savvasAdminUserId, configProperty.getProperty( "district_ID" ), orgId );

        Log.message( response.getBody().asString() );
        Response responseBff = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, studentUserId, headers );
        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );

        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }

        Log.assertThat( assignmentsFromResponseBff.containsKey( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ), "Restore assignment is fetched properly in the response",
                "Restore assignment  is not fetching in the API response" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest010() throws IOException {

        Log.testCaseInfo( "tc:010 - Verify the status code 200 and response if the student is part of school 1 and school2" );

        RBSUtils rbsUtils = new RBSUtils();
        String multiSchStudentUsername = "multischstud1@" + orgId;
        String multiSchoolStudentID = "";
        //To create the multiple school student
        try {
            List<String> allUserNamesFromOrg = rbsUtils.getAllUserNamesFromOrg( orgId );

            if ( allUserNamesFromOrg.contains( multiSchStudentUsername ) ) {
                String userDetail = rbsUtils.getUser( rbsUtils.getUserIDByUserName( multiSchStudentUsername ) );
                multiSchoolStudentID = SMUtils.getKeyValueFromResponse( userDetail, RBSDataSetupConstants.USERID );
            } else {
                HashMap<String, String> userDetails = new HashMap<>();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchStudentUsername );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

                List<String> schools = Arrays.asList( orgId, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                String finalSchool = "";
                for ( String school : schools ) {
                    finalSchool += school.concat( "\",\"" );
                }
                finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
                String studentDetail = new RBSUtils().createUser( userDetails );
                multiSchoolStudentID = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID );

                HashMap<String, String> studentInfo = new HashMap<>();
                studentInfo = RBSDataSetup.generateRequestValues( studentDetail, studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, teacherUserId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, token );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( smUrl, studentInfo );

            }

            //Group Creation in flex school
            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherUserId );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            groupDetails.put( GroupConstants.GROUP_NAME, "Group " + System.nanoTime() );

            HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( multiSchoolStudentID ) );

            if ( createGroup.get( "statusCode" ).equals( "201" ) ) {
                Log.message( "Group Created in Flex School for multiple school student" );
            }

            //Group Creation in math school
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbsUtils.getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USER_NAME ), password ) );
            groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USERID ) );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            groupDetails.put( GroupConstants.GROUP_NAME, "Group " + System.nanoTime() );

            createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( multiSchoolStudentID ) );

            if ( createGroup.get( "statusCode" ).equals( "201" ) ) {
                Log.message( "Group Created in Math School for multiple school student" );
            }

            //Assigning reading assignment from flex school teacher
            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( multiSchoolStudentID ), Arrays.asList( "2" ) );

            //Assigning math assignment from math school teacher
            assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USERID ) );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbsUtils.getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USER_NAME ), password ) );
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( multiSchoolStudentID ), Arrays.asList( "1" ) );
        } catch ( Exception e ) {
            Log.message( "Issue in creating the assignment" );
            e.printStackTrace();
        }

        HashMap<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + rbsUtils.getAccessToken( multiSchStudentUsername, password ) );
        headers.put( Constants.USERID_SM_HEADER, multiSchoolStudentID );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        Response response = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, multiSchoolStudentID, headers );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONObject( "data" ).getJSONArray( "getStudentAssignments" );
        String flexSchoolCreatorFirstName = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( "Reading" ) ) {
                flexSchoolCreatorFirstName = SMUtils.getKeyValueFromResponse( object.toString(), "creatorFirstName" );
                break;
            }
        }

        String mathSchoolcreatorFirstName = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( "Math" ) ) {
                mathSchoolcreatorFirstName = SMUtils.getKeyValueFromResponse( object.toString(), "creatorFirstName" );
                break;
            }
        }

        Log.assertThat( flexSchoolCreatorFirstName.equalsIgnoreCase( new JSONObject( teacherDetails ).get( "firstName" ).toString() ) && mathSchoolcreatorFirstName.equalsIgnoreCase( new JSONObject( mathTeacherDetails ).get( "firstName" ).toString() ),
                "Both schools assignmnets are fetched properly for multiple school student", "Both schools assignmnets are not fetched properly for multiplpe school student" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest011() throws IOException {

        Log.testCaseInfo( "tc:011 - Verify the status code 200 and sessionLengthMin in bff response when creating the math course when there is no change in session length afterwards" );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) ).get( "sessionLengthMin" ).equalsIgnoreCase( "15" ), "session Length Min are fetched properly in the BFF response",
                "session Length Min are not fetched properly in the BFF response." );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest012() throws IOException {

        Log.testCaseInfo( "tc:012 - Verify the status code 200 and sessionLengthMin in bff response when creating the reading course when there is no change in session length afterwards" );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( AssignmentAPIConstants.READING_COURSE ) ).get( "sessionLengthMin" ).equalsIgnoreCase( "20" ), "session Length Min are fetched properly in the BFF response",
                "session Length Min are not fetched properly in the BFF response." );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest013() throws Exception {

        Log.testCaseInfo( "tc:013 - Verify the status code 200 and sessionLengthMin in bff response when user update the session length mins" );

        //To get the assignment userId
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
        Log.message( "assignmentUserId -" + assignmentUserId );
        //To update the assignment settings
        HashMap<String, String> assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
        assignmentSettings.put( "SESSION_LENGTH", "25" );

        HashMap<String, String> assignmentDetail = new HashMap<>();
        assignmentDetail.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
        assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        new AssignmentAPI().updateAssignmentUserSettings( smUrl, assignmentDetail, assignmentSettings, Arrays.asList( studentUserId ), AssignmentAPIConstants.MATH_COURSE );

        Response response = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, studentUserId, headers );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONObject( "data" ).getJSONArray( "getStudentAssignments" );
        String sessionLength = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) ) {
                sessionLength = SMUtils.getKeyValueFromResponse( object.toString(), "sessionLengthMin" );
                break;
            }
        }

        Log.assertThat( sessionLength.equals( "25" ), "Session length is fetched properly for updated math settings courses", "Session length is not fetched properly for updated math settings courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest014() throws Exception {

        Log.testCaseInfo( "tc:014 - Verify the status code 200 and sessionLengthMin in bff response when user update the session length mins for group assignment" );

        //Group Creation in flex school
        HashMap<String, String> groupDetails = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherUserId );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupDetails.put( GroupConstants.GROUP_NAME, "Group " + System.nanoTime() );

        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( studentUserId ) );
        String groupId = SMUtils.getKeyValueFromResponse( createGroup.get( "body" ), "data,groupId" );
        if ( createGroup.get( "statusCode" ).equals( "201" ) ) {
            Log.message( "Group Created in Flex School" );
        }
        String courseName = String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() );
        String courseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName );

        //Assignment details
        HashMap<String, String> assignmentDetail = new HashMap<>();
        assignmentDetail.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetail.put( AssignmentAPIConstants.GROUP_ID, groupId );
        assignmentDetail.put( AssignmentAPIConstants.COURSE_ID, courseId );

        new AssignmentAPI().assignAssignment( smUrl, assignmentDetail, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );

        HashMap<String, String> updatedGroupAssignmentSettings = new HashMap<>();

        updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, courseId );

        HashMap<String, String> apiResponseGetGroupAssignmentSettings = new AssignmentAPI().getGroupAssignmentSettings( smUrl, assignmentDetail );

        //Please remove before final merge
        Log.message( "Response is " + apiResponseGetGroupAssignmentSettings );

        JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj( apiResponseGetGroupAssignmentSettings.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

        JSONObject data2 = getSettingsResp.getJSONObject( "SESSION_LENGTH" );
        String sessionLengthName = data2.getString( "name" );
        Long sessionLengthId = data2.getLong( "id" );
        String sessionLengthValue = data2.getString( "currentValue" );
        Log.message( "Name of the session length : " + sessionLengthName );
        Log.message( "Id of the session length : " + sessionLengthId );
        Log.message( "CurrentValue of the session length : " + sessionLengthValue );

        JSONObject data3 = getSettingsResp.getJSONObject( "IDLE_TIME" );
        String idleTimeName = data3.getString( "name" );
        Long idleTimeId = data3.getLong( "id" );
        String idleTimeValue = data3.getString( "currentValue" );
        Log.message( "Name of the idleTime : " + idleTimeName );
        Log.message( "Id of the idleTime : " + idleTimeId );
        Log.message( "CurrentValue of the idleTime : " + idleTimeValue );

        //Updating the Settings As per Scenarios

        //Update the setting as per your need
        updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_ID, String.valueOf( sessionLengthId ) );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_NAME, sessionLengthName );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_VALUE, "60" );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, "4" );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.ORG_ID, orgId );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.TEACHER_ID, teacherUserId );
        updatedGroupAssignmentSettings.put( "groupId", groupId );

        //Updating the Custom By Settings
        HashMap<String, String> apiResponseUpdatedGroupAssignmentSetting = new AssignmentAPI().updateGroupAssignmentSetting( smUrl, assignmentDetail, updatedGroupAssignmentSettings, DataSetupConstants.MATH );
        Log.message( "Update course setting response: " + apiResponseUpdatedGroupAssignmentSetting );

        Response response = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, studentUserId, headers );

        //To get the assignment names in the response
        JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONObject( "data" ).getJSONArray( "getStudentAssignments" );
        String sessionLength = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( courseName ) ) {
                sessionLength = SMUtils.getKeyValueFromResponse( object.toString(), "sessionLengthMin" );
                break;
            }
        }

        Log.assertThat( sessionLength.equals( "60" ), "Session length is fetched properly for updated the group assignment settings courses", "Session length is not fetched properly for updated the group assignment settings courses" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest015() throws IOException {

        Log.testCaseInfo( "tc:015 - Verify the status code 200 and Product ID in bff response for Math default and custom course" );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) ).get( "productId" ).equalsIgnoreCase( "2089014" ), "Product Id are fetched properly in the BFF response",
                "Product Id are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) ).get( "productId" ).equalsIgnoreCase( "2089014" ),
                "Product Id are fetched properly in the BFF response", "Product Id are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ).get( "productId" ).equalsIgnoreCase( "2089014" ),
                "Product Id are fetched properly in the BFF response", "Product Id are not fetched properly in the BFF response." );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest016() throws IOException {

        Log.testCaseInfo( "tc:016 - Verify the status code 200 and Product ID in bff response for Reading default and custom course" );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( AssignmentAPIConstants.READING_COURSE ) ).get( "productId" ).equalsIgnoreCase( "2089015" ), "Product Id are fetched properly in the BFF response",
                "Product Id are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) ).get( "productId" ).equalsIgnoreCase( "2089015" ),
                "Product Id are fetched properly in the BFF response", "Product Id are not fetched properly in the BFF response." );
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) ).get( "productId" ).equalsIgnoreCase( "2089015" ),
                "Product Id are fetched properly in the BFF response", "Product Id are not fetched properly in the BFF response." );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest017() throws IOException {

        Log.testCaseInfo( "tc:017 - Verify the status code 200 and Product ID in bff response for Math focus course" );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) ) ).get( "productId" ).equalsIgnoreCase( "2089016" ),
                "Product Id are fetched properly in the BFF response", "Product Id are not fetched properly in the BFF response." );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest018() throws IOException {

        Log.testCaseInfo( "tc:018 - Verify the status code 200 and Product ID in bff response for Reading focus course" );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "data" );
        JSONArray jsonArrayBff = new JSONObject( keyValueFromResponse ).getJSONArray( "getStudentAssignments" );
        Map<String, Map<String, String>> assignmentsFromResponseBff = new HashMap<>();
        for ( Object object : jsonArrayBff ) {
            Map<String, String> assignmentFromResponseBff = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            assignmentsFromResponseBff.put( assignmentFromResponseBff.get( "assignmentId" ), assignmentFromResponseBff );
        }
        Log.assertThat( assignmentsFromResponseBff.get( assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) ) ).get( "productId" ).equalsIgnoreCase( "2089017" ),
                "Product Id are fetched properly in the BFF response", "Product Id are not fetched properly in the BFF response." );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest019() throws IOException {

        Log.testCaseInfo( "tc:019 - Verify the status code 404 when we pass invalid endpoint " );
        responseBff = studentDashboard.getAssignmentListBffForStudent( "/endPoint", orgId, studentUserId, headers );
        //status code     
        Log.assertThat( responseBff.getStatusCode() == 404, "Status code is returned as expected", "Status code is not returned as expected. Expected - 404 .Actual-" + responseBff.getStatusCode() );

        Log.assertThat( SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "message" ).contains( "not found" ), "Error message are fetched properly in the BFF response", "Error message are not fetched properly in the BFF response." );
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest020() throws IOException {

        Log.testCaseInfo( "tc:020 - Verify the status code 200 when we pass invalid orgId" );

        HashMap<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + studentAccessToken );
        headers.put( Constants.USERID_HEADER, studentUserId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        responseBff = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId + "1", studentUserId, headers );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        Log.assertThat( SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "message" ).contains( "not found" ), "Error message are fetched properly in the BFF response", "Error message are not fetched properly in the BFF response." );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest021() throws IOException {

        Log.testCaseInfo( "tc:021 - Verify the status code 200 when we pass invalid userId" );

        HashMap<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + studentAccessToken );
        headers.put( Constants.USERID_HEADER, studentUserId );

        responseBff = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, studentUserId + "1", headers );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        Log.assertThat( SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "message" ).contains( "401: Unauthorized" ), "Error message are fetched properly in the BFF response",
                "Error message are not fetched properly in the BFF response." );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest022() throws IOException {

        Log.testCaseInfo( "tc:022 - Verify the status code 200 when we pass invalid authorization" );
        HashMap<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.USERID_SM_HEADER, studentUserId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + studentAccessToken + "11" );

        responseBff = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, studentUserId, headers );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        Log.assertThat( responseBff.getBody().asString().contains( "401: Unauthorized" ), "Error message are fetched properly in the BFF response", "Error message are not fetched properly in the BFF response." );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest023() throws IOException {

        Log.testCaseInfo( "tc:023 - Verify the status code 200 and bff response when any new student without any assignment is passed in request body" );

        String studentDetails = RBSDataSetup.getMyStudent( orgName, teacherUsername );

        //To get the previously assigned assignment
        Response response = studentDashboard.getAssignmentListForStudent( smUrl, orgId, SMUtils.getKeyValueFromResponse( studentDetails, Constants.USERID ),
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, Constants.USER_NAME ), password ) );

        //To delete the assignments
        if ( response.getBody().asString().contains( "assignmentUserId" ) ) {
            JSONArray jsonArray = new JSONObject( response.getBody().asString() ).getJSONArray( "data" );
            List<String> assignmentUserIds = new ArrayList<>();
            for ( Object object : jsonArray ) {
                Map<String, String> assignmentFromResponse = new Gson().fromJson( object.toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
                assignmentUserIds.add( assignmentFromResponse.get( "assignmentUserId" ) );
            }
            assignmentUserIds.forEach( assignmentUserId -> {
                try {
                    assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                    new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetails, AssignmentAPIConstants.EXCEPTIONNULL );
                } catch ( Exception e ) {
                    e.printStackTrace();
                }
            } );
        }

        HashMap<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, Constants.USER_NAME ), password ) );
        headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( studentDetails, Constants.USERID ) );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        Response responseBff = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, SMUtils.getKeyValueFromResponse( studentDetails, Constants.USERID ), headers );

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        Log.message( responseBff.getBody().asString() );
        Log.assertThat( SMUtils.getKeyValueFromResponse( responseBff.getBody().asString(), "message" ).contains( "No Course Found for the student" ), "Zero state message is verified successfully ", "Zero state message is not displayed properly" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest024() throws IOException {

        Log.testCaseInfo( "tc:024 - Verify the status code 200 and bff response should not fetch paused assignments" );

        // To get the assignment user Id for DefaultMath
        JSONArray jsonArray = new JSONObject( responseApi.getBody().asString() ).getJSONArray( "data" );
        String mathAssignmentUserId = null;
        for ( Object object : jsonArray ) {
            if ( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ).equalsIgnoreCase( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) ) {
                mathAssignmentUserId = SMUtils.getKeyValueFromResponse( object.toString(), "assignmentUserId" );
                break;
            }
        }

        //To pause the Math assignment
        try {
            assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, mathAssignmentUserId );
            HashMap<String, String> pauseAssignmentResponse = new AssignmentAPI().changeAssignmentStatus( smUrl, assignmentDetails, "INACTIVE", AssignmentAPIConstants.EXCEPTIONNULL );
            Log.message( pauseAssignmentResponse.toString() );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        Response response = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, studentUserId, headers );

        Log.message( "Response - " + response.getBody().asString() );

        // To get the assignment names
        jsonArray = new JSONObject( response.getBody().asString() ).getJSONObject( "data" ).getJSONArray( "getStudentAssignments" );
        List<String> assignmentNames = new ArrayList<>();
        for ( Object object : jsonArray ) {
            assignmentNames.add( SMUtils.getKeyValueFromResponse( object.toString(), "courseName" ) );
        }

        Log.assertThat( !assignmentNames.contains( "Math" ), "Paused assignments are not fetched in the api as expected", "Paused assignments are fetching in the Get student assignment API" );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "getStudentAssignmentsDetailsBff", "P1", "SMK-70075" }, priority = 1 )
    public void getAssignmentDetailsTest025() throws Exception {

        Log.testCaseInfo( "tc:025 - Verify the status code 200 and bff response when suspended student authentication is passed in headers" );

        RBSUtils rbsUtils = new RBSUtils();
        String suspendedStudentUsername = "suspendedstud1@" + orgId;
        String suspendedStudentUserID = null;

        //To create the multiple school student
        try {
            List<String> allUserNamesFromOrg = rbsUtils.getAllUserNamesFromOrg( orgId );

            if ( allUserNamesFromOrg.contains( suspendedStudentUsername ) ) {
                String userDetail = rbsUtils.getUser( rbsUtils.getUserIDByUserName( suspendedStudentUsername ) );
                suspendedStudentUserID = SMUtils.getKeyValueFromResponse( userDetail, RBSDataSetupConstants.USERID );
            } else {
                HashMap<String, String> userDetails = new HashMap<>();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, suspendedStudentUsername );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

                List<String> schools = Arrays.asList( orgId );
                String finalSchool = "";
                for ( String school : schools ) {
                    finalSchool += school.concat( "\",\"" );
                }
                finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
                String studentDetail = new RBSUtils().createUser( userDetails );
                suspendedStudentUserID = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID );

                HashMap<String, String> studentInfo = new HashMap<>();
                studentInfo = RBSDataSetup.generateRequestValues( studentDetail, studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, teacherUserId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, token );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( smUrl, studentInfo );

            }

            //Group Creation in flex school
            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherUserId );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            groupDetails.put( GroupConstants.GROUP_NAME, "Group " + System.nanoTime() );

            HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( suspendedStudentUserID ) );

            if ( createGroup.get( "statusCode" ).equals( "201" ) ) {
                Log.message( "Group Created in Flex School for suspend student" );
            }

            //Assigning reading assignment from flex school teacher
            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( suspendedStudentUserID ), Arrays.asList( "2" ) );
        } catch ( Exception e ) {
            Log.message( "Issue in creating the assignment" );
            e.printStackTrace();
        }

        //To suspend the user
        new RBSUtils().suspendUser( Arrays.asList( suspendedStudentUserID ) );

        String accessToken = null;
        try {
            accessToken = new RBSUtils().getAccessToken( suspendedStudentUsername, password );
        } catch ( Exception e ) {
            Log.message( "Unable to create access token for suspended student as expected" );
        }

        HashMap<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        headers.put( Constants.USERID_SM_HEADER, suspendedStudentUserID );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        Response responseBff = studentDashboard.getAssignmentListBffForStudent( "/graphql", orgId, suspendedStudentUserID, headers );

        //status code validation

        //status code     
        Log.assertThat( responseBff.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + responseBff.getStatusCode() );
        Log.assertThat( responseBff.getBody().asString().contains( "401: Unauthorized" ), "Error message are fetched properly in the BFF response", "Error message are not fetched properly in the BFF response." );

    }

}