package com.savvas.sm.teacher.ui.tests.ReportSuite;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Reports;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LSRPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.ReportComponent;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class LastSessionReport extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String sessionCookie;
    private String studentLastName;

    WebDriver driver;
    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;
    ReportComponent reportComponent;
    LSRPage reportPage;
    String reportFilterName;
    TeacherHomePage tHomePage;

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher7" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( description = "Verify Last Session Report should open and shows proper header and description.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR001: Verify Last Session option should present under the Reports top menu and should open after clicking. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.LSR_REPORT ), "Last Session Report sub menu is Present under report menu", "Last Session Report sub menu is not Present under report menu" );

            // navigate to LSR Page
            LSRPage reportPage = teacherHomePage.topNavBar.navigateToReportsLastSessionTab();
            Log.assertThat( reportPage.getReportPageHeader().contains( Constants.Reports.LSR_HEADER ), "Last Session page is opened after clicking the Last Session option in sub menu",
                    "Last Session page is not opened after clicking the Last Session option in sub menu" );

            // Verify LSR header
            Log.assertThat( reportComponent.getReportPageHeader().equals( Constants.Reports.LSR_HEADER ), "Last Session Report header is Present", "Last Session Report header is not Present" );

            // Verifying LSR Report Description report
            Log.assertThat( reportComponent.getReportDescription().equals( Constants.Reports.LSR_DESCRIPTION ), "Last Session Report description is present and displayed as expected",
                    "Last Session Report description is not Present or displaying wrong text" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Groups and Students radio button Inside the FILTERS", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR002: Verify Groups and Students radio button Inside the FILTERS <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Verify Group radio button
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.GROUP_DROPDOWN );
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.GROUP_DROPDOWN ), "Groups radio button is present and checked", "Groups radio button is not present" );

            // Verify Students radio button
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.STUDENTS_DROPDOWN ), "Students radio button is present and checked", "Students radio button is not present" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Remove Page Breaks' and 'Mask Student Display' checkbox on LSR page.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR003: Verify 'Remove Page Breaks' and 'Mask Student Display' checkbox on LSR page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );
            // Navigate to LSR
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Verify Remove Page Breaks
            reportComponent.checkOrUncheckRemovePageBreak();
            Log.assertThat( reportComponent.isRemovePageBreakChecked(), "The Remove Page Breaks check box is clickable and clicked", "The Remove Page Breaks check box is not clickable and clicked" );
            // Verify Mask Student Display
            reportComponent.checkOrUncheckMaskStudentDisplay();
            Log.assertThat( reportComponent.isMaskStudentDisplayChecked(), "The Mask Student Display check box is clickable and clicked", "The Mask Student Display check box is not clickable and clicked" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify SELECT ALL functionality in Assignments dropdown.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR004: Verify SELECT ALL option in Assignments dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            AssignmentsPage assignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            int listOfAssignments = assignmentsPage.assignmentsList().size();

            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( "All Assignments (" + listOfAssignments + ")" ),
                    "The default text on the drop down is displayed as All Assignments (" + listOfAssignments + ") ", "The default text on the drop down is wrong" );

            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "All the options in the drop down are selected by default", "All the options in the drop down are not selected by default" );

            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            Log.assertThat( !reportComponent.isSelectALLChecked( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "All the options in the drop down are unchecked", "All the options in the drop down are not unchecked" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the removed Assignments should not display in the Assignments dropdown.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR005: Verify the removed Assignments should not display in the Assignments dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            teacherHomePage.topNavBar.navigateToAssignmentsPage();

            AssignmentsPage assignmentDetails = new AssignmentsPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            List<String> assignmentsName = new ArrayList<>();
            List<String> assignmentsList = assignmentDetails.assignmentsList();
            for ( String value : assignmentsList ) {
                assignmentsName.add( value.trim() );
            }
            String deletedAssignment = assignmentsName.get( 0 );
            assignmentDetails.viewAssignmentDetailsByAssignmentName( deletedAssignment );
            assignmentDetailsPage.clickDeleteAssignmenttabTopEllipsis();

            // Navigate to LSR
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            reportComponent.getValuesFromDropDownMS();
            Log.assertThat( !assignmentsName.equals( deletedAssignment ), "Deleted assignment '" + deletedAssignment + " is not listed in Assignments dropdown", "Deleted assignment '" + deletedAssignment + " is listed in Assignments dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all fields are available in the Last session Report page.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR006: Verify all available fields in LSR page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Verify LSR header
            Log.assertThat( reportComponent.getReportPageHeader().equals( Constants.Reports.LSR_HEADER ), "Last Session Report header is Present", "Last Session Report header is not Present" );

            // Verify Filters heading
            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.FILTERS ), "Filters heading is present in the LSR Page", "Filters heading is not present in the LSR Page" );

            // Verify Select Groups or Students heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.GROUP_OR_STUDENT_HEADER ), "Select Groups or Students heading is present in the LSR Page",
                    "Select Groups or Students heading is not present in the LSR Page" );

            // Verify group dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.GROUP_DROPDOWN ), "Group dropdown is present in the LSR Page", "Group dropdown is not present in the LSR Page" );

            // Verify student dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.STUDENTS_DROPDOWN ), "Student dropdown is present in the LSR Page", "Students dropdown is not present in the LSR Page" );

            // Verify Refine search heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.REFINE_SEARCH ), "Refine search heading is present in the LSR Page", "Refine search heading is present in the LSR Page" );

            // Verify subject dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject dropdown is present in the LSR Page", "Subjects dropdown is not present in the LSR Page" );

            // Verify assignment dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "Assignments dropdown is present in the LSR Page", "Assignments dropdown is not present in the LSR Page" );

            // Verify Report option heading
            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.REPORT_OPTION_HEADER ), "Report option heading is present in the LSR Page", "Report option heading is not present in the LSR Page" );

            // Verify Saved Option dropdown heading
            Log.assertThat( reportComponent.isSavedOptionDropdownHeadingPresent(), "Saved Option dropdown is present in the LSR Page", "Saved Option dropdown is not present in the LSR Page" );

            // Verify additional grouping dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.ADDITIONAL_GROUPING ), "Additional grouping dropdown heading is present in the LSR Page", "Additional grouping dropdown is not present in the LSR Page" );

            // Verify Display dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.DISPLAY_DROPDOWN ), "Display dropdown heading is present in the LSR Page", "Display dropdown heading is not present in the LSR Page" );

            // Verify Display dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.SORT_DROPDOWN ), "Sort dropdown heading is present in the LSR Page", "Sort dropdown heading is not present in the LSR Page" );

            // Verify Remove page break field
            Log.assertThat( reportComponent.isMaskStudentDisplayAndRemovePageBreakFieldDisplayed( Constants.Reports.MASK_STUDENT_DISPLAY ), "Mask student display field is present in the LSR page",
                    "Mask student display field is not present in the LSR page" );

            // Verify Mask student display field
            Log.assertThat( reportComponent.isMaskStudentDisplayAndRemovePageBreakFieldDisplayed( Constants.Reports.REMOVE_PAGE_BREAKS ), "Remove page break field is present in the LSR page", "Remove page break field is not present in the LSR page" );

            // Verify Save Report Option button
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getSaveReportOptionButton() ), "Saved Report option button is present", "Saved Report option button is not present!" );

            // Verify Run Report
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getRunReportOption() ), "Run report button present!", "Run report not button present!" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify group names listed in the Groups dropdown and able to select one or more group.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR007: Verify group names listed in the Groups dropdown and able to select one or more group. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Getting groups names from UI
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsList = groupsTab.getGroupListNames();

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Validating groups names are listed in Groups drop-down
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsOnUI = reportComponent.getValuesFromDropDownMS();

            Log.assertThat( groupsList.containsAll( groupsOnUI ), "All Groups displayed successfully!", "Groups not displayed properly", driver );
            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> singleGroup = new ArrayList<>();
            List<String> multiGroup = new ArrayList<>();
            // Verify the Dropdown text after selecting one Group
            singleGroup.add( groupsFromUI.get( 0 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, singleGroup );
            Log.assertThat( groupsFromUI.get( 0 ).equals( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ) ), "Selected group name is Displayed", "Selected group name is not Displayed" );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            // Verify for multiple groups
            multiGroup.add( groupsFromUI.get( 0 ) );
            multiGroup.add( groupsFromUI.get( 1 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, multiGroup );
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Count of selected group is Displayed",
                    "count of selected group name is not Displayed" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Removed group should not display in the Groups dropdown.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR008() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMLSR008: Verify the Removed group should not display in the Groups dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Getting the groups names from the UI
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsList = groupsTab.getGroupListNames();

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Getting groups from UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();

            Log.assertThat( groupsList.containsAll( groupsFromUI ), "All Groups displayed successfully!", "Groups not displayed properly", driver );
            // getting Group Name
            String groupName = groupsFromUI.get( 0 );

            // Delete Group
            GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupPage.viewGroup( groupName );
            SMUtils.nap( 2 ); // Wait is required for Group detail page loading
            groupPage.deleteGroup( groupName );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // again Getting groups from UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            groupsFromUI = reportComponent.getValuesFromDropDownMS();

            // validate delete group should not display under groups dropdown
            Log.assertThat( !( groupsFromUI.contains( groupName ) ), "Deleted Group is not present under Groups Dropdown", "Deleted Group is present under Groups Dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher should be able to select one or more Student in the Students dropdown.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR009: Verify teacher should be able to select one or more Student in the Students dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            List<String> listOfStudents = reportComponent.getValuesFromDropDownMS();
            List<String> singleStudent = new ArrayList<>();
            List<String> multiStudents = new ArrayList<>();
            // Verify the dropdown text after selecting one Student
            // Verify for single Student
            singleStudent.add( listOfStudents.get( 0 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, singleStudent );
            Log.assertThat( listOfStudents.get( 0 ).equals( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ) ), "Selected Student name is Displayed", "Selected Student name is not Displayed" );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // Verify for multiple Students
            multiStudents.add( listOfStudents.get( 0 ) );
            multiStudents.add( listOfStudents.get( 1 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, multiStudents );
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_STUDENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Count of selected Student is Displayed",
                    "count of selected Student name is not Displayed" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify assignments listed in the Assignments dropdown and able to select one or more assignments.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR010() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR010: Verify assignments listed in the Assignments dropdown and able to select one or more assignments. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentsPage assignmentpage = new AssignmentsPage( driver );

            List<String> actualAssignmenstList = new ArrayList<>();
            List<String> assignmentsList = assignmentpage.assignmentsList();

            for ( String value : assignmentsList ) {
                actualAssignmenstList.add( value.trim() );
            }
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> valuesFromDropDownMS = reportComponent.getValuesFromDropDownMS();
            Log.assertThat( valuesFromDropDownMS.containsAll( actualAssignmenstList ), "All assignments are listed in Assignments dropdown", "Assignments dropdowm is not listed all assignments" );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );

            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> singleAssignment = new ArrayList<>();
            List<String> multiAssignments = new ArrayList<>();

            // Verify the dropdown text after selecting one Assignment
            if ( assignmentsFromUI.size() > 1 ) {
                // Verify for single Assignment
                singleAssignment.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, singleAssignment );
                Log.assertThat( assignmentsFromUI.get( 0 ).equals( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ) ), "Selected Assignment name is Displayed", "Selected Assignment name is not Displayed" );

            } else if ( assignmentsFromUI.size() == 1 ) {
                singleAssignment.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, singleAssignment );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "1" ) ),
                        "All Assignments text and count of the Assignments is Display Properly", "All Assignments text or count of the Assignments is not Display Properly" );

            } else {
                Log.message( "Given teacher don't have any Assignments" );
            }
            if ( assignmentsFromUI.size() > 2 ) {
                // Uncheck Select All checkbox
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );

                // Verify for multiple Assignments
                multiAssignments.add( assignmentsFromUI.get( 0 ) );
                multiAssignments.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, multiAssignments );
                String actual = reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
                String expected = Constants.Reports.SELECTED_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "2" );
                Log.assertThat( actual.equals( expected ), "Count of selected Assignment is Displayed", "count of selected Assignment name is not Displayed" );
            } else if ( assignmentsFromUI.size() == 2 ) {
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
                singleAssignment.add( assignmentsFromUI.get( 0 ) );
                singleAssignment.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, singleAssignment );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All Assignments text and count of the Assignments is Display Properly", "All Assignments text or count of the Assignments is not Display Properly" );

            } else {
                Log.message( "Given teacher don't have any Assignments" );
            }

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all available fields under the 'Additional grouping' and user can able to select one option.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR011: Verify all available fields under the 'Additional grouping' and user can able to select one option. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Verify all available fields
            Log.assertThat( reportComponent.isAdditionalGroupingDropdownPresent(), "Additional Grouping dropdown is present", "Additional Grouping dropdown is not present" );

            List<String> additionalGroupingvalues = reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN );
            Log.assertThat( additionalGroupingvalues.containsAll( Constants.Reports.ADDITION_GROUPING ), "All the Additional Grouping drop down values are displayed", "All the Additional Grouping drop down values are not displayed" );

            // Verify user can able to select one option
            Log.assertThat( reportComponent.selectValueFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, Constants.Reports.GRADES ), "The given option is selected in the Additional Grouping Drop down",
                    "The given option is selected in the Additional Grouping Drop down" );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.GRADES ), "The selected option is verified", "The selected option is not verified" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all available fields under the 'Display' dropdownand and user can able to select one option.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR012() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR012: Verify all available fields under the 'Display' dropdownand and user can able to select one option. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Verify all available fields
            Log.assertThat( reportComponent.isDisplayDropdownPresent(), "Display dropdown is present", "Display dropdown is not present" );

            List<String> additionalGroupingvalues = reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.DISPLAY_DROPDOWN );
            Log.assertThat( additionalGroupingvalues.containsAll( Constants.Reports.DISPLAY ), "All the display drop down values are displayed", "All the display drop down values are not displayed" );

            // Verify user can able to select one option
            Log.assertThat( reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENT_USERNAME ), "The given option is selected in the Display dropdown",
                    "The given option is selected in the Display dropdown" );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equals( Constants.Reports.STUDENT_USERNAME ), "The selected option is verified", "The selected option is not verified" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all available fields under the 'sort' dropdown and user can able to select one option.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR013() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR013: Verify all available fields under the 'sort' dropdown and user can able to select one option. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Verify all available fields
            Log.assertThat( reportComponent.isSortDropdownPresent(), "Sort dropdown is present", "Sort dropdown is not present" );

            List<String> additionalGroupingvalues = reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.SORT_DROPDOWN );
            Log.assertThat( additionalGroupingvalues.containsAll( Constants.Reports.SORT_LSR ), "All the Sort drop down values are displayed", "All the Sort drop down values are not displayed" );

            // Verify user can able to select one option
            Log.assertThat( reportComponent.selectValueFromStaticDropdown( Constants.Reports.SORT_DROPDOWN, Constants.Reports.TIME_SPENT ), "The given option is selected in the Sort dropdown", "The given option is selected in the Sort dropdown" );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Constants.Reports.TIME_SPENT ), "The selected option is verified", "The selected option is not verified" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Saved option' dropdown should have already Saved Reports.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR014() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR014: Verify 'Saved option' dropdown should have already Saved Reports. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Select values in static drop down
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, Constants.Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.SORT_DROPDOWN, Constants.Reports.TIME_SPENT );
            Log.message( "Values are selected in static dropdowns" );

            // Save the report
            SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyy/MM/dd HH:mm:ss" );
            String reportName = "Modified Report - " + dateFormat.format( new Date() );
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportName );
            Log.assertThat( reportComponent.isReportOptionSaved( reportName ), "Saved report is displyed in Saved Options dropdown", "Saved report is not displyed in Saved Options dropdown" );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equals( Constants.Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Constants.Reports.TIME_SPENT ), "The selected option is displayed in Sort dropdown",
                    "The selected option is not displayed in Sort dropdown" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify If click the 'Replace Existing Report Options' radio button in 'Save Report Option As' Popup.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR015() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMLSR015: Verify If click the 'Replace Existing Report Options' radio button in 'Save Report Option As' Popup. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Click Save Report Option
            reportComponent.clickSaveReportOption();
            // Click Replace Existing Report radio button
            reportComponent.clcikReplaceExistingReportRadioBtn();

            Log.assertThat( reportComponent.isReplaceExistingReportDropdownPresent(), "Replace Existing Report dropdown is present in Save Report Option as excepted", "Replace Existing Report dropdown is not present in Save Report Option" );
            Log.assertThat( !reportComponent.isSaveReportOptionNewRadioSelected(), "Name text box is not selected in Save Report Option as excepted", "Name text box is selected in Save Report Option" );

            reportComponent.clickcancelButtoninSaveReportPopup();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all available fields in 'Save Report Option As' Popup.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR016() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMLSR016: Verify all available fields in 'Save Report Option As' Popup. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Verifying the Save Report Option is displayed and clickable
            reportComponent.clickSaveReportOption();
            Log.assertThat( reportComponent.getSaveReportPopUpTextHeader().equals( Constants.Reports.SAVEREPORT_POUP_HEADER ), "Save Report Pop up is displayed and verified the header", "Save Report Pop up is not displayed and verified the header" );

            // Verifying all available fields in Save Report Option
            Log.assertThat( reportComponent.saveReportOptionNewFieldHeader().equals( Constants.Reports.NEW_HEADER_SAVEREPORT ), "New Radio button is displayed in Save Report Popup", "New Radio button is displayed in Save Report Popup" );
            Log.assertThat( reportComponent.saveReportOptionReplaceExistingFieldHeader().equals( Constants.Reports.REPLACE_EXISTING_HEADER ), "Replace Existing Radio button is displayed in Save Report Popup",
                    "Replace Existing Radio button is displayed in Save Report Popup" );
            Log.assertThat( reportComponent.saveBtnOnSaveReportPopUp().equals( Constants.Reports.SAVEBTN_SAVEREPORT_OPTION ), "Save button is displayed in Save Report Popup", "Save button is not displayed in Save Report Popup" );
            Log.assertThat( reportComponent.cancelBtnOnSaveReportPopUp().equals( Constants.Reports.CANCELBTN_SAVEREPORT_OPTION ), "Cancel button is displayed in Save Report Popup", "Cancel button is not displayed in Save Report Popup" );
            reportComponent.clickcancelButtoninSaveReportPopup();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to select the one option in 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR017() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMLSR017: Verify user can able to select the one option in 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Select values in static drop down
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, Constants.Reports.GRADES );

            // Save the report
            SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyy/MM/dd HH:mm:ss" );
            String reportName = "Modified Report - " + dateFormat.format( new Date() );
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportName );

            // Click Save Report Option
            reportComponent.clickSaveReportOption();
            // Click Replace Existing Report radio button
            reportComponent.clcikReplaceExistingReportRadioBtn();
            reportComponent.clickExistingReportValue( reportName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSavedOptionSelectedValue().equals( reportName ), "The selected option is displayed in Saved Option dropdown", "The selected option is not displayed in Saved Option dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Save Report Option with empty name, new name and existing name.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR018() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMLSR018: Verify Save Report Option with empty name, new name and existing name. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Verify with empty name
            reportComponent.clickSaveReportOption();
            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "Save button is disabled when name textbox is empty", "Save button is enabled when name textbox is empty" );

            // Verify with new name
            SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyy/MM/dd HH:mm:ss" );
            String reportName = "Modified Report - " + dateFormat.format( new Date() );
            reportComponent.saveReportOption( reportName );
            Log.assertThat( reportComponent.isReportOptionSaved( reportName ), "Saved report is displyed in Saved Options dropdown", "Saved report is not displyed in Saved Options dropdown" );

            // Verify with existing name
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportName );
            Log.assertThat( reportComponent.getSaveReportOptionErrorMsg().equals( Constants.Reports.EXISTING_NAME_ERROR ), "Save Report Option popup throws the error message for existing name",
                    "Save Report Option  popup is not throwing the error message for existing name" );
            reportComponent.clickcancelButtoninSaveReportPopup();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student names listed in the Students dropdown.", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 1 )
    public void tcSMLSR019() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSR019: Verify the Student names listed in the Students dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Check Students RB
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // get WebElements of dropdown option checkboxes
            List<String> allStudentsFromUI = reportComponent.getValuesFromDropDownMS();
            // getting the Student names from data setup
            List<String> studentList = new ArrayList<>();
            List<String> studentFirstNameAndLastNameList = new ArrayList<>();
            for ( int studentCount = 1; studentCount <= DataSetup.teacherStudentMap.get( username ).size(); studentCount++ ) {
                studentList.add( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ) );
                studentFirstNameAndLastNameList.add( SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,middleName" ) + ". "
                        + SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,lastName" ) );
            }

            Log.assertThat( studentFirstNameAndLastNameList.containsAll( allStudentsFromUI ), "All Students displayed properly in the student dropdown!", "Students not displayed properly in thes student dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify if click the save button with empty Name in 'Save Report Option As' Popup on LSR ", groups = { "SMK-40023", "Save reports options", "LastSessionReport" }, priority = 2 )
    public void tcSM_LSRSavedReport001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_LSRRSavedReport001: Verify if click the save button with empty Name in 'Save Report Option As' Popup on LSR <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();
            reportComponent.getReportPageHeader();
            Log.message( "Last Session page has loaded" );
            reportComponent.clickSaveReportOption();
            //Validate save report with empty name
            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "save button is not clickable with empty name", "save button is clickable with empty name" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if click the save button with already existing name in 'Save Report Option As' Popup on LSR", groups = { "SMK-40023", "Save reports options", "LastSessionReport" }, priority = 2 )
    public void tcSM_LSRSavedReport002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_LSRSavedReport002:Verify if click the save button with already existing name in 'Save Report Option As' Popup on LSR <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();

            reportComponent.getReportPageHeader();
            Log.message( "Last Session page has loaded" );
            // Save report options filter with new Name
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );

            // enter already existing name in the text box
            reportComponent.clickSaveReportOption();
            reportComponent.setReportFilterName( reportFilterName );
            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "save button is not clickable with already existing name", "save button is clickable with already existing name" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Subject dropdown in report page.", groups = { "SMK-43900", "reports", "LastSessionReport" }, priority = 1 )

    public void tcSMLSR020() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMLSR020: Verify the Subject dropdown in report page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Verifying the availability of Subject dropdown
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject dropdown is present", "Subject dropdown is not present" );

            // Verifying the options of Subject dropdown
            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.SUBJECT_DROPDOWN ), "Select All option is present in Subject dropdown", "Select All option is not present in Subject dropdown" );
            reportComponent.setDropDownMS( Constants.Reports.SUBJECT_DROPDOWN );
            Log.assertThat( reportComponent.getValuesFromDropDownMS().containsAll( Constants.Reports.SUBJECTS ), "All options are available in Subject dropdown", "Some option is missing in Subject dropdown" );

            // Verifying default selection of Subject dropdown
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "All options are selected by default in Subject dropdown", "All options are not selected by default in Subject dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = " Verify If teacher enter more than 50 characters in name text box ", groups = { "SMK-40023", "Save reports options", "LastSessionReport" }, priority = 2 )
    public void tcSM_LSRSavedReport003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_LSRSavedReport003: Verify If User enter more than 50 characters in name text box<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();
            reportComponent.getReportPageHeader();
            Log.message( "Last Session page has loaded" );
            // Click Save Report Option Link
            reportComponent.clickSaveReportOption();
            reportFilterName = Constants.Reports.SPR_SAVEDREPORT_NAME + System.nanoTime();
            reportComponent.typeReportName( reportFilterName );

            // Validate Error Message when Character Limit exceed
            reportComponent.getErrorMessageForExceedMaximumLength();
            // validate Save button enable or not after giving more than 50 cahr
            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "save button is not clickable when teacher give more than 50 character", "save button is  clickable when teacher give more than 50 character" );

            // Validate Cancel Button is displaying and click cancel button
            Log.assertThat( reportComponent.cancelBtnOnSaveReportPopUp().equals( Constants.Reports.CANCELBTN_SAVEREPORT_OPTION ), "Cancel Button on save report option Field is displaying on Poup",
                    "Cancel Button on save report option Field is not displaying on Poup" );
            reportComponent.clickCancelButtonFromPopup();
            // Validate save report window pop up should not display

            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.REPORT_OPTION_HEADER ), "Saved Report Option window popup is not displaying now", "Saved Report Option window popup is  displaying" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify user can able to select the one option in 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup on SPR.", groups = { "SMK-40023", "Save reports options", "LastSessionReport" }, priority = 2 )
    public void tcSM_LSRSavedReport004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_LSRSavedReport004:Verify user can able to select the one option in 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup on SPR.<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();
            reportComponent.getReportPageHeader();
            Log.message( "Last Session Report page has loaded" );

            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );
            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            reportComponent.clickSaveReportOption();
            reportComponent.replaceExistingReport( Constants.Reports.CHOOSE_ONE );
            reportComponent.replaceExistingReport( reportFilterName );
            reportComponent.clickSaveOnSaveReportPopUp();
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> loadedOptions = reportPage.getAllSelectedFilters( reportComponent );
            // Validate default retained after selecting the save report
            Log.assertThat( selectedOptions.equals( loadedOptions ), "All default values loaded properly after selecting save reports ", "All dafaul field not loaded Properly" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify If delete the group after saved the report option with that student on LSR.", groups = { "SMK-40023", "Save reports options", "LastSessionReport" }, priority = 2 )
    public void tcSM_LSRSavedReport005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_LSRSavedReport005:Verify If delete the group after saved the report option with that student on LSR<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();
            reportComponent.getReportPageHeader();
            Log.message( "Last Session page has loaded" );

            // getting the groups names from data setup
            List<String> groupsList = new ArrayList<>();
            String groupDetails = DataSetup.teacherGroupMap.get( username ).get( username );
            for ( int groupCount = 1; groupCount <= SMUtils.getWordCount( groupDetails, "groupName" ); groupCount++ ) {
                groupsList.add( SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", groupCount ) );
            }

            // Getting groups from UI
            reportComponent.setDropDownMS( "Groups" );

            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

            if ( groupsFromUI.size() > 0 ) {
                // getting Group Name
                String groupName = groupsFromUI.get( 0 );

                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String reportFilterName = "reportFilter" + System.nanoTime();
                reportComponent.saveReportOption( reportFilterName );

                // Delete Group
                GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
                groupPage.viewGroup( groupName );
                // Need For Page load
                SMUtils.nap( 2 );
                groupPage.deleteGroup( groupName );

                // navigate to LSR Page
                reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();

                // again Getting groups from UI
                reportComponent.setDropDownMS( "Groups" );
                groupsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

                // validate delete group should not display under groups
                // dropdown
                Log.assertThat( !( groupsFromUI.contains( groupName ) ), "Deleted Group is not present under Groups Dropdown", "Deleted Group is present under Groups Dropdown" );

                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( reportFilterName );

                // validate delete group should not display under groups
                // dropdown
                Log.assertThat( !( groupsFromUI.contains( groupName ) ), "Deleted Group is not present under Groups Dropdown fo saved report", "Deleted Group is present under Groups Dropdown for saved report" );

            } else {
                Log.message( "Given teacher don't have goups" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify If soft delete the assignment after saved the report option with that assignment on LSR", groups = { "SMK-40023", "Save reports options", "LastSessionReport" }, priority = 2 )
    public void tcSM_LSRSavedReport006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_LSRSavedReport006:Verify If soft delete the assignment after saved the report option with that assignment on LSR<small><b><i>[" + browser + "]</b></i></small>" );

        // Initiating the reports filter components

        try {
            studentLastName = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,lastName" );
            sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
            List<String> studentId = new ArrayList<>();
            studentId.add( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,personId" ) );
            new BaseAPITest().assignCourse( smUrl, sessionCookie, "Math", DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "1", studentId );
            smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );
            reportComponent = new ReportComponent( driver );

            // Navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();
            reportComponent.getReportPageHeader();
            Log.message( "Last Session page has loaded" );
            // Take all assignments from Data SetUp
            List<String> assignmnetsList = new ArrayList<>();
            String assignmentsDetails = DataSetup.teacherAssignmentMap.get( username ).get( username );
            for ( int assignmentsCount = 1; assignmentsCount <= SMUtils.getWordCount( assignmentsDetails, "name" ); assignmentsCount++ ) {
                assignmnetsList.add( SMUtils.getKeyValueFromJsonArray( assignmentsDetails, "name", assignmentsCount ) );
            }

            // Getting Assignments from UI
            reportComponent.setDropDownMS( "Assignments" );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

            if ( assignmentsFromUI.size() > 0 ) {
                // getting Assignment Name
                String assignmentsName = assignmentsFromUI.get( 0 );

                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String reportFilterName = "reportFilter" + System.nanoTime();
                reportComponent.saveReportOption( reportFilterName );
                // Navigate to Courseware tab
                AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

                // Click on Assignment SubMenu
                page.clickAssignmentSubMenu();

                // Click Delete Assignment
                AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( assignmentsName );
                assignmentDetailsPage.assignmentLevelEllipsis();
                assignmentDetailsPage.deleteAssignmenttab();
                SMUtils.nap( 2 );
                assignmentDetailsPage.deleteAssignmentButton();
                Log.assertThat( assignmentDetailsPage.isAssignmentDisplayed(), "Assignment has deleted successfully", "Assignment has not deleted successfully" );

                // navigate to LSR Report page
                reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();
                reportComponent.setDropDownMS( "Assignments" );
                assignmentsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

                Log.assertThat( !( assignmentsFromUI.contains( assignmentsName ) ), "Deleted assignments is not present under Assignments Dropdown", "Deleted assignments is present under assignments Dropdown" );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( reportFilterName );

                Log.assertThat( !( assignmentsFromUI.contains( assignmentsName ) ), "Deleted assignments is not present under Assignments Dropdown", "Deleted assignments is present under assignments Dropdown" );
            } else {
                Log.message( "Teacher dont have assignments" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify by Adding one more Groups / Assignment and verify the saved filter option retained with only previously saved options", groups = { "SMK-40023", "Save reports options", "LastSessionReport" }, priority = 2 )
    public void tcSM_LSRSavedReport007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_LSRSavedReport007:Verify by Adding one more Groups / Assignment and verify the saved filter option retained with only previously saved options:<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();
            reportComponent.getReportPageHeader();
            Log.message( " Last Session Page page has loaded" );

            //getting groups From UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupOptions = new ArrayList<>();

            //selecting  Groups
            if ( groupsFromUI.size() >= 2 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                groupOptions.add( groupsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
            }

            //Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // create New group
            GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
            String groupName = "Group" + System.nanoTime();
            groupPage.createGroupWithoutStudent( groupName );
            SMUtils.nap( 2 );//This wait required to load page after created group
            tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );
            //Get Selected Group
            String selectedGroup = reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            Log.assertThat( !selectedGroup.contentEquals( groupName ), "New group is not avaiable in saved report", "New group is avaiable in saved report" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify by Adding one more Student / Assignment and verify the saved filter option retained with only previously saved options", groups = { "SMK-40023", "Save reports options", "LastSessionReport" }, priority = 2 )
    public void tcSM_LSRSavedReport008() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_LSRSavedReport008:Verify by Adding one more Student / Assignment and verify the saved filter option retained with only previously saved options:<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();
            reportComponent.getReportPageHeader();
            Log.message( " Last Session Page page has loaded" );

            // getting students From UI
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> studentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();

            // selecting multiple Students
            if ( studentsFromUI.size() >= 2 ) {
                studentOptions.add( studentsFromUI.get( 0 ) );
                studentOptions.add( studentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );

                //Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String reportFilterName = "reportFilter" + System.nanoTime();
                reportComponent.saveReportOption( reportFilterName );
                //Create new Student
                StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();
                SMUtils.nap( 1 );
                String studentName = studentPage.createStudent();
                SMUtils.nap( 2 );//This wait required to load page after created group
                tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( reportFilterName );
                //Get Selected Group
                String selectedStudent = reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
                Log.assertThat( !selectedStudent.contentEquals( studentName ), "New Student is not avaiable in saved report", "New Student is avaiable in saved report" );

            } else {
                Log.message( "Teacher don't have student" );
            }

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in Last Session Report Page", groups = { "SMK-43900", "reports",
            "lastSessionReport" }, priority = 1 )
    public void tcSMLSR021() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo(
                "tcSMLSR021: Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in Last Session Report Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> subjectOption = new ArrayList<>();

            // Select Math from subject dropdown
            subjectOption.add( Constants.Reports.SUBJECTS.get( 0 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            if ( !reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String mathReportFilter = "Math Subject " + System.nanoTime();
                reportComponent.saveReportOption( mathReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( mathReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SUBJECTS.get( 0 ) ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );
            } else {
                Log.message( "No assignments available for Math subject" );
            }

            // Select Reading from subject dropdown
            subjectOption.add( Constants.Reports.SUBJECTS.get( 1 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            if ( !reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String readingReportFilter = "Reading Subject " + System.nanoTime();
                reportComponent.saveReportOption( readingReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( readingReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SUBJECTS.get( 1 ) ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );
            } else {
                Log.message( "No assignments available for Reading subject" );
            }

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 test cases for Last session report", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 3 )
    public void tcSMLSRP3AndP4_001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSRP3AndP4_001:P3 and P4 test cases for Last session report<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            tHomePage.topNavBar.navigateToReportsLastSessionTab();

            SMUtils.logDescriptionTC( "SMK-40024- Verify FILTERS field should be expandable and collapse." );

            reportComponent.collapseFilterButton();
            reportComponent.expandFilterButton();
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.GROUP_DROPDOWN ), "Group dropdown is present in the SPR Page", "Group dropdown is not present in the SPR Page" );

            SMUtils.logDescriptionTC( "SMK-40024-Verify SELECT ALL option in Groups and Students dropdown." );
            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.GROUP_DROPDOWN ), "SELECT ALL check box is displaying for Groups and it is checked", "SELECT ALL check box is not displaying for Groups and it is not checked" );
            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.STUDENTS_DROPDOWN ), "SELECT ALL check box is displaying for Student and it is checked", "SELECT ALL check box is not displaying for Student and it is not checked" );

            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> valuesFromDropDownMS = reportComponent.getValuesFromDropDownMS();
            List<String> actualAssignmenstList = valuesFromDropDownMS;
            Collections.sort( actualAssignmenstList );
            SMUtils.logDescriptionTC( "SMK-40024-Verify the Assignments name should display in Alphabetical order under Assignments dropdown" );
            Log.assertThat( actualAssignmenstList.equals( valuesFromDropDownMS ), "All assignments are listed in Assignments dropdown in sorted order", "Assignments dropdowm is not listed all assignments in sorted order" );

            //getting studentsFrom UI
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> studentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentsList = studentsFromUI;
            Log.assertThat( IntStream.range( 0, DataSetupConstants.STUDENT_COUNT ).allMatch( studentCount -> studentsFromUI.get( studentCount ).contains( studentsList.get( studentCount ) ) ), "Student name is displaying in order",
                    "Stundet name is not diplaying in order" );

            // Validating groups names are listed in Groups drop-down
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsOnUI = reportComponent.getValuesFromDropDownMS();

            List<String> sortgroups = groupsOnUI;
            Collections.sort( sortgroups );
            SMUtils.logDescriptionTC( "SMK-40024-Verify the Groups name should display in ascending order under Groups dropdown." );
            Log.assertThat( sortgroups.equals( groupsOnUI ), "All Groups displayed successfully! in sorted order", "Groups not displayed properly in sorted order", driver );

            SMUtils.logDescriptionTC( "SMK-40024:-Verify 'Run Report' button should display on SPR page." );
            // Verify Run Report
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getRunReportOption() ), "Run report button present!", "Run report not button present!" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 test cases for Last session report", groups = { "SMK-40024", "reports", "lastSessionReport" }, priority = 3 )
    public void tcSMLSRP3AndP4_002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLSRP3AndP4_002:P3 and P4 test cases for Last session report<small><b><i>[" + browser + "]</b></i></small>" );

        String teacherUsername = "AutomatedTeacher_ForZeroState" + System.nanoTime();
        //Creating teacher for Zero state test
        new UserSqlHelper().createTeacher( teacherUsername, teacherUsername, teacherUsername, Constants.PASSWORD_HASH, DataSetup.organizationId );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );
            // Navigate to LSR page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();

            Log.assertThat( reportComponent.isZeroStateMessageDisplayed(), "Zero state message is displaying", "Zero state message is not displaying" );

            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            String studentID = studentsPage.createStudent();
            // Navigate to SPR Page

            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();

            Log.assertThat( reportComponent.getZeroStateTextGroups().equalsIgnoreCase( Constants.Reports.ZERO_STATE_TEXT_GRP ), "Zero state message is displaying for group", "Zero state message is not displaying" );
            Log.assertThat( reportComponent.getZeroStateTextAssignments().equalsIgnoreCase( Constants.Reports.ZERO_STATE_TEXT_ASSIGNMENTS ), "Zero state message is displaying for assignments", "Zero state message is not displaying" );
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of check-box in subject dropdown", groups = { "SMK-43900", "reports", "lastSessionReport" }, priority = 3 )
    public void tcSM_SubjectDropdownLSR001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_SubjectDropdownLSR001: Verify the functionality of check-box in subject dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Last Session Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            SMUtils.logDescriptionTC( "SMK-11081 - Verify unchecking all options in Subject drop down in Last Session Reports Page" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.UNCHECKED_SUBJECTS ), "Subject dropdown is unchecked in Last Session Reports Page",
                    "Subject dropdown is not unchecked in Last Session Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11078 - Verify Math Option is selectable in Subject drop down in Last Session Reports Page" );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.MATH ) );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.MATH ), "Math option is selected in Subject dropdown in Last Session Reports Page",
                    "Math option is not selected in Subject dropdown in Last Session Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11079 - Verify Reading Option is selectable in Subject drop down in Last Session Reports Page" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.READING ) );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.READING ), "Reading option is selected in Subject dropdown in Last Session Reports Page",
                    "Reading option is not selected in Subject dropdown in Last Session Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11080 - Verify SELECT ALL Option is selectable in Subject drop down in Last Session Reports Page" );
            // Uncheck all subject
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            // Select all subjects
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "Select All option is selected in Subject dropdown in Last Session Reports Page", "Select All option is not selected in Subject dropdown in Last Session Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11075 - Verify that Subject drop down in Subject filter in Last Session Reports Page is a multiselect drop down" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Constants.Reports.SUBJECTS );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "Subject dropdown is a multi-select dropdown in Last Session Reports Page", "Subject dropdown is not a multi-select dropdown in Last Session Reports Page" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify subjects are displayed in subject dropdown", groups = { "SMK-43900", "reports", "lastSessionReport" }, priority = 3 )
    public void tcSM_SubjectDropdownLSR002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SubjectDropdownLSR002: Verify subjects are displayed in subject dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Last Session Page
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();

            SMUtils.logDescriptionTC( "SMK-11088 - Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Math and Reading subject alone in Last Session report page" );
            String selectedAssignments = reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            if ( !selectedAssignments.equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String allSubjectReportFilter = "All Subject " + System.nanoTime();
                reportComponent.saveReportOption( allSubjectReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( allSubjectReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "Selected subject filters are loaded Successfully", "Selected subject filters are not loaded Successfully" );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( selectedAssignments ), "Selected assignment filters are loaded Successfully",
                        "Selected assignment filters are not loaded Successfully" );
            } else {
                Log.message( "No assignments available for Math subject" );
            }
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11089 - Verify the teacher able to see All Subjects (2) while colapsing the Filters if both subjects are selected in Subjects dropdown" );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "All Subjects (2) is displayed while colapsing the filters if both subjects are selected in Subjects dropdown", "All Subjects (2) is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11090 - Verify the teacher able to see Math while colapsing the Filters if Math subject is selected in Subjects dropdown" );
            // Expanding filters
            reportComponent.expandFilterButton();
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.MATH ) );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.MATH ), "Math is displayed while colapsing the filters if both subjects are selected in Subjects dropdown",
                    "Math is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11091 - Verify the teacher able to see Reading while colapsing the Filters if Reading subject is selected in Subjects dropdown" );
            // Expanding filters
            reportComponent.expandFilterButton();
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.READING ) );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.READING ), "Reading is displayed while colapsing the filters if both subjects are selected in Subjects dropdown",
                    "Reading is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Save Report Option' on LSR.", groups = { "SMK-40022", "saveReports", "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_LSRSavedReport009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_LSRSavedReport009: Verify 'Save Report Option' on LSR." + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();

            SMUtils.logDescriptionTC( "Verify 'Save Report Option' on LSR." );
            // Verify Save Report Option button
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getSaveReportOptionButton() ), "Saved Report option button is present", "Saved Report option button is not present!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the 'Replace Existing Report Options' radio button in 'Save Report Option As' Popup on Last Session Report" );
            // Click Save Report Option
            reportComponent.clickSaveReportOption();
            // Click Replace Existing Report radio button
            reportComponent.clcikReplaceExistingReportRadioBtn();

            Log.assertThat( reportComponent.isReplaceExistingReportDropdownPresent(), "Replace Existing Report dropdown is present in Save Report Option as excepted", "Replace Existing Report dropdown is not present in Save Report Option" );
            Log.assertThat( !reportComponent.isNameTextBoxDisplayed(), "Name text box is not displayed in Save Report Option as excepted", "Name text box is displayed in Save Report Option" );
            reportComponent.clickcancelButtoninSaveReportPopup();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the save report with empty Name in 'Save Report Option As' Popup on Last Session Report" );
            // Verify with empty name
            reportComponent.clickSaveReportOption();
            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "Save button is disabled when name textbox is empty", "Save button is enabled when name textbox is empty" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the save report with Name contains special character and numbers in 'Save Report Option As' Popup on Last Session Report" );
            // Verify with new name
            SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyy/MM/dd HH:mm:ss" );
            String reportName = "LSR@001 - " + dateFormat.format( new Date() );
            // Changing Additional grouping value
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, Constants.Reports.NONE );
            reportComponent.saveReportOption( reportName );
            Log.assertThat( reportComponent.isReportOptionSaved( reportName ), "Saved report is displyed in Saved Options dropdown", "Saved report is not displyed in Saved Options dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with new name and default Values on Last Session Report and load the report." );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'None' option in Additional Grouping on Last Session Report and load the report" );
            // Click Save Report Option
            reportComponent.clickSaveReportOption();
            // Click Replace Existing Report radio button
            String changedName = "Modified Report name" + System.nanoTime();
            reportComponent.saveReportOption( changedName );

            //load report
            reportComponent.loadReportOption( "Choose One" );
            reportComponent.loadReportOption( changedName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.NONE ), "Report is saved with new name and existing values",
                    "Report is not saved with new name and existing values" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Save Report Option' with diffrent values in Additional Grouping, Display and Sort on LSR.", groups = { "SMK-40022", "saveReports", "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_LSRSavedReport010() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_LSRSavedReport010: Verify 'Save Report Option' with diffrent values in Additional Grouping, Display and Sort on LSR." + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Grade' option in Additional Grouping, 'Student Id' in Display and 'Current Course Level' in Sort on Last Session Report and load the report.\n"
                    + "Verify User can able to save the report option with 'Grade' option in Additional Grouping on Last Session Report and load the report.\n"
                    + "Verify User can able to save the report option with 'Remove Page breaks' on Last Session Report and load the report.\n"
                    + "Verify User can able to save the report option with 'All Students' & 'Mask student display' on Last Session Report and load the report.\n" );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT_LSR.get( 1 ) );
            // Check Mask Student and Remove page Break
            reportComponent.checkOrUncheckMaskStudentDisplay();
            reportComponent.checkOrUncheckRemovePageBreak();

            // Save the report
            String reportFilterNameOne = "Report Filter One: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterNameOne );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterNameOne );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equals( Constants.Reports.STUDENTID ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Reports.SORT_LSR.get( 1 ) ), "The selected option is displayed in Sort dropdown",
                    "The selected option is not displayed in Sort dropdown" );
            Log.assertThat( reportComponent.isMaskStudentDisplayChecked(), "Mask student display is checked as Expected", "Mask student display is not checked" );
            Log.assertThat( reportComponent.isRemovePageBreakChecked(), "Remove page breaks is checked as Expected", "Remove page breaks is not checked" );
            Log.testCaseResult();

            // Set filters as default
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with All Students, All Assignments, 'Exercises Percent Correct' in 'Sort' dropdown on Last session report and load the report" );

            //Selecting student radio button
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT_LSR.get( 4 ) );
            // Check Mask Student and Remove page Break
            reportComponent.checkOrUncheckMaskStudentDisplay();
            reportComponent.checkOrUncheckRemovePageBreak();

            // Save the report
            String reportFilterNameTwo = "Report Filter Two: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterNameTwo );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterNameTwo );

            // Verify the saved report
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.STUDENTS_DROPDOWN ), "Students radio button is present and checked", "Students radio button is not present" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Reports.SORT_LSR.get( 4 ) ), "The selected option is displayed in Sort dropdown",
                    "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            // Set filters as default
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping, Student Username in 'Display' and 'Exercises Correct' in 'Sort' dropdown on Last session report and load the report" );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 'Group' option in Additional Grouping on Last Session Report and load the report" );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT_LSR.get( 2 ) );
            // Check Mask Student and Remove page Break
            reportComponent.checkOrUncheckMaskStudentDisplay();
            reportComponent.checkOrUncheckRemovePageBreak();

            // Save the report
            String reportFilterNameThree = "Report Filter Three: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterNameThree );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterNameThree );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.GROUP ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equals( Constants.Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Reports.SORT_LSR.get( 2 ) ), "The selected option is displayed in Sort dropdown",
                    "The selected option is not displayed in Sort dropdown" );
            Log.assertThat( reportComponent.isMaskStudentDisplayChecked(), "Mask student display is checked as Expected", "Mask student display is not checked" );
            Log.assertThat( reportComponent.isRemovePageBreakChecked(), "Remove page breaks is checked as Expected", "Remove page breaks is not checked" );
            Log.testCaseResult();

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Save Report Option' with diffrent Students and Assignments.", groups = { "SMK-40022", "saveReports", "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_LSRSavedReport011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_LSRSavedReport011: Verify 'Save Report Option' with diffrent Students and Assignments." + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 5 Students, 5 Assignments, 'Help Used' in 'Sort' dropdown on Last session report and load the report" );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 2 Students and Sort by 'Help Used' on Last Session Report and load the report" );

            // Selecting multiple Students
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );
            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // Select students
            reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, Arrays.asList( reportComponent.getValuesFromDropDownMS().get( 0 ), reportComponent.getValuesFromDropDownMS().get( 1 ) ) );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );

            // Getting Assinments name
            List<String> allAssignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();
            IntStream.range( 0, 4 ).forEach( list -> assignmentOptions.add( allAssignmentsFromUI.get( list ) ) );
            // Select assignments
            reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            // Select value from Sort dropdown
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT_LSR.get( 5 ) );

            // Get selected values
            String exceptedAssignmentCount = reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            String exceptedStudentCount = reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // Save the report
            String reportFilterNameOne = "Report Filter One: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterNameOne );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterNameOne );

            // Verify the saved report
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).equals( exceptedStudentCount ), "Selected Students are displayed", "Selected Students are not displayed" );
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( exceptedAssignmentCount ), "Selected Assignments are displayed", "Selected Assignments are not displayed" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Reports.SORT_LSR.get( 5 ) ), "The selected option is displayed in Sort dropdown",
                    "The selected option is not displayed in Sort dropdown" );

            // Set filters as default
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 1 Student, All Assignments, 'Time Spent' in 'Sort' dropdown on Last session report and load the report" );
            SMUtils.logDescriptionTC( "Verify User can able to save the report option with one group and Sort by 'Total Sessions' on Last Session Report and load the repor" );

            // Selecting a Student
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );
            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, Arrays.asList( reportComponent.getValuesFromDropDownMS().get( 0 ) ) );
            // Select value from Sort dropdown
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT_LSR.get( 6 ) );

            // Get selected values
            String exceptedAssignment = reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            String exceptedStudent = reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // Save the report
            String reportFilterNameTwo = "Report Filter One: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterNameTwo );

            // load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterNameTwo );

            // Verify the saved report
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).equals( exceptedStudent ), "Selected Students are displayed", "Selected Students are not displayed" );
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( exceptedAssignment ), "Selected Assignments are displayed", "Selected Assignments are not displayed" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Reports.SORT_LSR.get( 6 ) ), "The selected option is displayed in Sort dropdown",
                    "The selected option is not displayed in Sort dropdown" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Save Report Option' with diffrent Students and Assignments.", groups = { "SMK-40022", "saveReports", "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_LSRSavedReport012() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_LSRSavedReport012: Verify 'Save Report Option' with diffrent Students and Assignments." + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with All Groups, All Assignments, 'Total Sessions' in 'Sort' dropdown on Last session report and load the report" );

            // Select value from Sort dropdown
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT_LSR.get( 7 ) );

            // Save the report
            String reportFilterNameOne = "Report Filter One: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterNameOne );

            // load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterNameOne );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Reports.SORT_LSR.get( 7 ) ), "The selected option is displayed in Sort dropdown",
                    "The selected option is not displayed in Sort dropdown" );

            // Set filters as default
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with 5 Groups, All Assignments, 'Remove Page breaks', 'Mask student display' selected and Sort by 'Session Date' on Last Session Report and load the report" );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, Arrays.asList( reportComponent.getValuesFromDropDownMS().get( 0 ), reportComponent.getValuesFromDropDownMS().get( 1 ) ) );
            // Select value from Sort dropdown
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT_LSR.get( 8 ) );
            // Check Mask Student and Remove page Break
            reportComponent.checkOrUncheckMaskStudentDisplay();
            reportComponent.checkOrUncheckRemovePageBreak();

            // Get selected values
            String exceptedGroupCount = reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            // Save the report
            String reportFilterNameTwo = "Report Filter One: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterNameTwo );

            // load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterNameTwo );

            // Verify the saved report
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( exceptedGroupCount ), "Selected Groups are displayed", "Selected Groups are not displayed" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Reports.SORT_LSR.get( 8 ) ), "The selected option is displayed in Sort dropdown",
                    "The selected option is not displayed in Sort dropdown" );
            Log.assertThat( reportComponent.isMaskStudentDisplayChecked(), "Mask student display is checked as Expected", "Mask student display is not checked" );
            Log.assertThat( reportComponent.isRemovePageBreakChecked(), "Remove page breaks is checked as Expected", "Remove page breaks is not checked" );

            // Set filters as default
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with All Groups and Sort by 'Time Spent' on Last Session Report and load the report" );

            // Select value from Sort dropdown
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT_LSR.get( 6 ) );

            // Get selected values
            String exceptedGroup = reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            // Save the report
            String reportFilterNameThree = "Report Filter One: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterNameThree );

            // load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterNameThree );

            // Verify the saved report
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( exceptedGroup ), "All Groups are selected", "All Groups are not selected" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Reports.SORT_LSR.get( 6 ) ), "The selected option is displayed in Sort dropdown",
                    "The selected option is not displayed in Sort dropdown" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Save Report Option' with diffrent Students and Assignments.", groups = { "SMK-40022", "saveReports", "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_LSRSavedReport013() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_LSRSavedReport013: Verify 'Save Report Option' with diffrent Students and Assignments." + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> multiGroup = new ArrayList<>();
            // Verify for multiple groups
            multiGroup.add( groupsFromUI.get( 0 ) );
            multiGroup.add( groupsFromUI.get( 1 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, multiGroup );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.SORT_DROPDOWN, Constants.Reports.EXERCISE_PERCENTAGE_CORRECT );
            // Save the report
            String reportFilterNameOrg = "Report Filter One: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterNameOrg );

            // load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterNameOrg );

            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Count of selected group is Displayed",
                    "count of selected group name is not Displayed" );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equalsIgnoreCase( Constants.Reports.EXERCISE_PERCENTAGE_CORRECT ), "Exercise percenatge correct is displaying",
                    "Exercise percenatge correct is not displaying" );

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            // Get selected values
            String exceptedGroup = reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.SORT_DROPDOWN, Constants.Reports.EXERCISE_ATTEMPT );
            // Save the report
            String reportFilterName = "Report Filter One: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            // load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( exceptedGroup ), "All Groups are selected", "All Groups are not selected" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equalsIgnoreCase( Constants.Reports.EXERCISE_ATTEMPT ), "Exercise Attempt is displaying", "Exercise attempt is not displaying" );

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            // Get selected values
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.SORT_DROPDOWN, Constants.Reports.CURRENT_COURSE_LEVEL );

            // Save the report
            String reportFilterNameThree = "Report Filter One: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterNameThree );

            // load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterNameThree );
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( exceptedGroup ), "All Groups are selected", "All Groups are not selected" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equalsIgnoreCase( Constants.Reports.CURRENT_COURSE_LEVEL ), "Current course level is displaying", "Current course level is not displaying" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Save Report Option' with diffrent Students and Assignments.", groups = { "SMK-40022", "saveReports", "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_LSRSavedReport014() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_LSRSavedReport014: Verify 'Save Report Option' with diffrent Students and Assignments." + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to LSR Page
            reportPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();
            //Selecting student radio button
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );
            // Get selected values
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.SORT_DROPDOWN, Constants.Reports.EXERCISE_CORRECT );
            // Save the report
            String reportFilterNameTwo = "Report Filter Two: " + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterNameTwo );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterNameTwo );

            // Verify the saved report
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.STUDENTS_DROPDOWN ), "Students radio button is present and checked", "Students radio button is not present" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equalsIgnoreCase( Constants.Reports.EXERCISE_CORRECT ), "Exercise correct is displaying", "Exercise correct is not displaying" );
            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }
}