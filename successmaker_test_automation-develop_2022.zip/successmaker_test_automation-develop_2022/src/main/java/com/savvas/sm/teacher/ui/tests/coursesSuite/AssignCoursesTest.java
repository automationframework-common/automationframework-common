package com.savvas.sm.teacher.ui.tests.coursesSuite;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesEditAssignmentSettingsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.teacher.ui.pages.TopNavBar;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This java class file contains test cases for JIRA story SMK-38839.
 *
 * @author baskar.panchavarnam
 *
 */

public class AssignCoursesTest {

    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String browser;

    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String schoolID;
    private String teacherID;
    String teacherDetails;
    String studentDetails;
    String studentDetailsSecond;
    String studentDetailsThree;
    String studentSMDetails;
    String studentSMDetailsSecond;
    String studentSMDetailsThree;
    private String smUrl;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private HashMap<String, String> groupDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String token = null;
    List<String> addStudentsToGroup;
    
    SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyyMMdd");
    Date dateformated = new Date();

    @BeforeTest
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        UserAPI userAPIMethod = new UserAPI();
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentDetails = RBSDataSetup.getMyStudent( school, username );
        studentDetailsSecond = RBSDataSetup.getMyStudent( school, username );
        studentDetailsThree = RBSDataSetup.getMyStudent( school, username );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsThree, "userId" ) );

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Student SM Details
        studentSMDetails = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( school ), token ).get( Constants.REPORT_BODY );
        studentSMDetailsSecond = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( school ), token ).get( Constants.REPORT_BODY );
        studentSMDetailsThree = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetailsThree, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( school ), token ).get( Constants.REPORT_BODY );

        //Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

    }

    @Test ( description = "Verify the 'Assign To' modal popup by clicking 'Default Math' course from 'Home' page", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )
    public void tcSMCoursesAssign001() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10036 : Verify the 'Assign To' modal popup by clicking 'Default Math' course from 'Home' page<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = new CoursesPage( driver );

            coursePage.clickOnTheCourseAtTheHomePage( Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver );

            //coursePage.clickAssignBtn();

            Log.assertThat( coursePage.verifyAssignTo(), "Assign To Modal appears for Default Math course", "Assign To modal not getting appeared" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Assign To' modal popup by clicking 'Default Reading' course from 'Home' page", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign002() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10037 : Verify the 'Assign To' modal popup by clicking 'Default Reading' course from 'Home' page<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = new CoursesPage( driver );
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickOnTheCourseAtTheHomePage( Constants.READING );
            SMUtils.waitForSpinnertoDisapper( driver );

            //coursePage.clickAssignBtn();

            Boolean assignToExpected = true;
            Boolean assignToPopup = coursePage.verifyAssignTo();

            Log.assertThat( assignToPopup.equals( assignToExpected ), "Assign To Modal appears for Default Reading course", "Assign To modal not appeared" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Assign To' modal popup by clicking 'Custom Reading' course from 'Home' page", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign003() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10039 : Verify the 'Assign To' modal popup by clicking 'Custom Reading' course from 'Home' page<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            CourseListingPage courseListingPage = new CourseListingPage( driver );

            String staticCourseName = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            SMUtils.waitForSpinnertoDisapper( driver );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            SMUtils.waitForSpinnertoDisapper( driver, 60 );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( staticCourseName );

            coursePage.clickAssignBtn();

            Boolean assignToPopup = coursePage.verifyAssignTo();

            Log.assertThat( assignToPopup.equals( Constants.STATUSTRUE ), "Assign To Modal appears for Custom Reading course", "Assign To modal not appeared" );

            tHomePage.topNavBar.navigateToHomeTab();

            coursePage.clickOnTheCourseAtTheHomePage( staticCourseName );
            SMUtils.waitForSpinnertoDisapper( driver );

            //coursePage.clickAssignBtn();

            Boolean assignToExpected = true;
            assignToPopup = coursePage.verifyAssignTo();

            Log.assertThat( assignToPopup.equals( assignToExpected ), "Assign To Modal appears for Default Reading course", "Assign To modal not appeared" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Groups' option selected by default in 'Assign to' modal popup", priority = 2, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign005() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10042 : Verify the 'Groups' option selected by default in 'Assign to' modal popup<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            String staticCourseName = coursePage.generateRandomCourseName();

            AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );

            //Get CourseLising Page

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            //Select default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.waitForSpinnertoDisapper( driver );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            SMUtils.waitForSpinnertoDisapper( driver );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickFromCourseListingPage( staticCourseName );

            coursePage.clickAssignBtn();

            Log.assertThat( assignAssignmentPopup.isGroupsChecked(), "Groups radio button selected by default", "Groups radio button is not selected by default" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Students' option in 'Assign to' modal popup", priority = 2, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign006() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10051 : Verify the 'Students' option in 'Assign to' modal popup<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            assignAssignmentPopup.checkStudents();
            
            Boolean studentState = assignAssignmentPopup.isStudentsChecked();

            Log.message( studentState.toString() );

            Log.assertThat( assignAssignmentPopup.isStudentRadioChecked(), "Students radio button is selected", "Students radio button is not selected" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Login as teacher who doesn't have students and group verify 'Assign To' modal popup", priority = 2, groups = { "SMK-38839", "Courses", "coursesAssignWidget" } )

    public void tcSMCoursesAssign007() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10060 : Login as teacher who doesn't have students and group verify 'Assign To' modal popup<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            assignAssignmentPopup.checkStudents();

            assignAssignmentPopup.selectAllStudents();

            assignAssignmentPopup.assign();

            tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            assignAssignmentPopup.checkStudents();

            Log.assertThat( assignAssignmentPopup.verifyAssignToZeroState(), "Zero text message appears for Groups", "Zero text message not exist for Groups" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user able to 'Remove' the added groups by clicking 'Remove' button", priority = 2, groups = { "SMK-43632", "Courses", "coursesAssignWidget" } )

    public void tcSMCoursesAssign008() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10055 : Verify the user able to 'Remove' the added groups by clicking 'Remove' button<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();

            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();
            
            assignAssignmentPopup.checkStudents();
            List<String> students = assignAssignmentPopup.getStudentListFromPopUp();
            if(students.isEmpty()) {
            	assignAssignmentPopup.clickCancelButtonOnPopup();
            	AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
                page.clickAssignmentSubMenu();
                // Click on ViewAssignments
                AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(Constants.MATH);
                // Click on Dot ellipsis
                assignmentDetailsPage.assignmentLevelEllipsis();
                assignmentDetailsPage.deleteAssignmenttab();
                assignmentDetailsPage.deleteAssignmentButton();
                SMUtils.waitForSpinnertoDisapper( driver );
                
                //Get CourseLising Page
                tHomePage.topNavBar.navigateToCourseListingPage();
                SMUtils.waitForSpinnertoDisapper( driver );
                
                coursePage.clickMathCourse();

                coursePage.clickAssignBtn();
                coursePage.selectOneGroup();
            }else {
            assignAssignmentPopup.checkGroupisReset();
            coursePage.selectOneGroup();
            }

            Log.assertThat( assignAssignmentPopup.RemoveStudentbutton(), "Remove Course button is available in AssignTo modal", "Remove course button is not available" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Assign To' modal popup by clicking 'SM Focus Math' course from 'Home' page ", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )
    public void tcSMCoursesAssign009() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10040 : Verify the 'Assign To' modal popup by clicking 'SM Focus Math' course from 'Home' page<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );
            //            CoursesPage coursePage = new CoursesPage(driver);

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            coursePage.clickCourseName( Constants.SM_FOCUS_MATH_GRADE_I );

            coursePage.clickAssignBtn();

            //Assign the course to the student
            coursePage.addCourseToStudents();

            tHomePage.topNavBar.navigateToHomeTab();

            courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            coursePage.clickOnTheCourseAtTheHomePage( Constants.SM_FOCUS_MATH_GRADE_I );
            SMUtils.waitForSpinnertoDisapper( driver );

            Boolean checkStatus = coursePage.verifyAssignTo();

            Log.assertThat( checkStatus.equals( Constants.STATUSTRUE ), "Assign To Modal appears for Focus Math course", "Assign To modal not appeared for Focus Math course" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Assign To' modal popup by clicking 'SM Focus Reading' course from 'Home' page", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )
    public void tcSMCoursesAssign010() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10041 :  Verify the 'Assign To' modal popup by clicking 'SM Focus Reading' course from 'Home' page<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            coursePage.clickCourseName( Constants.SM_FOCUS_READING_GRADE4 );

            coursePage.clickAssignBtn();

            //Assign the course to the student
            coursePage.addCourseToStudents();

            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.waitForSpinnertoDisapper( driver, 60 );

            tHomePage.topNavBar.navigateToHomeTab();
//            driver.navigate().refresh();
            
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            SMUtils.nap(5);
            courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );
            
            coursePage.clickOnTheCourseAtTheHomePage( Constants.SM_FOCUS_READING_GRADE4 );
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.nap(5);

            Boolean checkStatus = coursePage.verifyAssignTo();

            Log.assertThat( checkStatus.equals( Constants.STATUSTRUE ), "Assign To Modal appears for Focus Reading course", "Assign To modal not appeared for Focus Reading course" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Assign To' modal popup by clicking 'Custom Math' course from 'Home' page", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )
    public void tcSMCoursesAssign011() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10038 : Verify the 'Assign To' modal popup by clicking 'Custom Math' course from 'Home' page<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            String customCourse = "Custom Math_" + simpleFormat.format(dateformated) + System.nanoTime();
            SMUtils.waitForSpinnertoDisapper( driver );

            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.clickCourseName( Constants.MATH );

            coursePage.copyOfCourse( customCourse, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.waitForSpinnertoDisapper( driver, 60 );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursePage.clickCourseName( customCourse );

            coursePage.clickAssignBtn();

            //Assign the course to the student
            coursePage.addCourseToStudents();

            tHomePage.topNavBar.navigateToHomeTab();

            SMUtils.waitForSpinnertoDisapper( driver, 60 );

            courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            coursePage.clickOnTheCourseAtTheHomePage( customCourse );
            SMUtils.waitForSpinnertoDisapper( driver );

            Boolean assignToExpected = true;
            Boolean assignToPopup = coursePage.verifyAssignTo();

            Log.assertThat( assignToPopup.equals( assignToExpected ), "Assign To Modal appears for Custom Math course", "Assign To modal not appeared" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user able to 'Add' groups to courses", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign012() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10045 : Verify the user able to 'Add' groups to courses<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AssignAssignmentPopup assignpopup = new AssignAssignmentPopup( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );
            String customCourseGroup = "Custom Reading" + simpleFormat.format(dateformated) + System.nanoTime();
            coursePage.copyOfCourse( customCourseGroup, Constants.STANDARDS, Constants.READING );
            tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickCourseName( customCourseGroup );

            coursePage.clickAssignBtn();

            SMUtils.logDescriptionTC( "SMK-10043 - Verify the default watermark text displayed for 'Groups' textbox in 'Assign to' modal popup" );
            Log.softAssertThat( assignpopup.getWatermarkTestAvailable().equals( "Search by Groups" ), "Default watermark text displays correctly for Groups", "Incorrect watermark text displays for Groups" );

            SMUtils.logDescriptionTC( "SMK-10044 : Verify the 'Groups' displayed in the 'Assign to' modal popup" );
            Log.softAssertThat( assignpopup.getWatermarkTestAvailable().equals( "Search by Groups" ), "Groups displays", "Groups not displaying" );

            SMUtils.logDescriptionTC( "SMK-10048 : Verify the 'Assign' button state by adding & removing groups " );
            Log.softAssertThat( coursePage.isAddButtonEnabled(), "Add button is enabled", "Add button is disabled" );

            SMUtils.logDescriptionTC( "SMK-10049 : Verify the Groups / Students selection is getting reset when the user change the options" );
            Log.softAssertThat( !coursePage.assignButtonEnabled(), "Assign button is disabled", "Assign button is enabled" );

            SMUtils.logDescriptionTC( "SMK-10052 : Verify the watermark text displayed for 'Student' textbox in 'Assign to' modal popup " );
            Log.softAssertThat( assignpopup.getWatermarkTestAvailable().equals( "Search by Students' Names and Usernames" ), "Default watermark text displays correctly for Students", "Incorrect watermark text displays for Students" );

            SMUtils.logDescriptionTC( "SMK-10057 : Verify the 'Assign' button state by adding and removing students " );
            Log.softAssertThat( assignpopup.getWatermarkTestAvailable().equals( "Search by Students' Names and Usernames" ), "Default watermark text displays correctly for Students", "Incorrect watermark text displays for Students" );

            SMUtils.logDescriptionTC( "SMK-10050 : Verify the user able to type and select group names" );
            Log.softAssertThat( coursePage.clickAddButtonforOneGroup(), "One course is selected and Add button is disabled", "Add button is enabled" );

            SMUtils.logDescriptionTC( "SMK-10047 : Verify the user able to 'Remove' groups by clicking 'Remove' icon" );
            assignpopup.toClickRemove();
            Log.softAssertThat( !assignpopup.isAssignButtonEnable(), "Student is removed and Add button is enabled", "Add button is disabled" );

            assignpopup.clickMultipleAddButton();

            SMUtils.logDescriptionTC( "SMK-10057 : Verify the 'Assign' button state by adding and removing students" );
            Log.softAssertThat( !coursePage.assignButtonEnabled(), "Assign button is disabled", "Assign button is enabled" );

            SMUtils.logDescriptionTC( "SMK-10056 : Verify the user able to 'Remove' students by clicking 'Remove' icon" );
            assignpopup.clickMultipleRemoveIcon();
            Log.softAssertThat( !assignpopup.isAssignButtonEnable(), "Student is removed and Assign button is disabled", "Assign button is enabled" );

            SMUtils.logDescriptionTC( "SMK-10055 : Verify the user able to 'Remove' the added student by clicking 'Remove' button" );
            assignpopup.clickMultipleRemoveIcon();
            Log.softAssertThat( !assignpopup.isAssignButtonEnable(), "Student is removed and Add button is enabled", "Add button is disabled" );

            SMUtils.logDescriptionTC( "SMK-10059 : Verify the user able to type and select student names" );
            assignpopup.clickMultipleAddButton();
            Log.softAssertThat( assignpopup.isAssignButtonEnable(), "One Student is selected and Assign button is enabled", "Assign button is disabled" );

            SMUtils.logDescriptionTC( "SMK-10058 : Verify the Students / Groups selection is getting reset when the user change the options " );
            Log.softAssertThat( assignpopup.checkGroupisReset(), "Group radio button selected and Student names are cleared", "Group is not selected" );

            coursePage.clickAssignBtn();

            coursePage.addCourseToOneGroup();

            tHomePage.topNavBar.navigateToHomeTab();
            String assignmentStudentCount = tHomePage.toGetfirstAssignmentStudentCount();
            Log.message( "Assigned custom course : " + assignmentStudentCount );
            Log.softAssertThat( assignmentStudentCount.trim().equalsIgnoreCase( Constants.THREESTUDENTSASSIGNED ), "Assigned student count displays correctly as '1 Students Assigned'", "Student count is incorrect" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the 'Students' displayed in the 'Assign to' modal popup", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign004() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10053 : Verify the 'Students' displayed in the 'Assign to' modal popup<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            AssignAssignmentPopup assignpopup = new AssignAssignmentPopup( driver );
            
            assignpopup.checkStudents();
            List<String> students = assignpopup.getStudentListFromPopUp();
            if(students.isEmpty()) {
            	assignpopup.clickCancelButtonOnPopup();
            	AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
                page.clickAssignmentSubMenu();
                // Click on ViewAssignments
                AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(Constants.MATH);
                // Click on Dot ellipsis
                assignmentDetailsPage.assignmentLevelEllipsis();
                assignmentDetailsPage.deleteAssignmenttab();
                assignmentDetailsPage.deleteAssignmentButton();
                SMUtils.waitForSpinnertoDisapper( driver );
                
                //Get CourseLising Page
                tHomePage.topNavBar.navigateToCourseListingPage();
                SMUtils.waitForSpinnertoDisapper( driver );
                
                //Select Default Courses from the first drop down
                courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

                SMUtils.waitForSpinnertoDisapper( driver );
                coursePage.clickMathCourse();

                coursePage.clickAssignBtn();
            }

            Log.assertThat( assignpopup.GetStudentNameFromPopup(), "Students name displaying in Assign to Modal", "Student Details are not displaying in Assign to modal" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Create Custom Math course with settings and verify the corresponding settings are available in 'Assign To' modal popup", priority = 4, groups = { "SMK-40138", "Courses", "assignCourses" } )
    public void tcSMCoursesAssign016() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10065 : Create Custom Math course with settings and verify the corresponding settings are available in 'Assign To' modal popup <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = new CoursesPage( driver );

            CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

            String courseName = coursesEditAssignmentSettingsPage.generateCourseName();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.STANDARDS, Constants.MATH );

            SMUtils.waitForSpinnertoDisapper( driver, 60 );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            coursePage.clickFromCourseListingPage( courseName );

            coursesEditAssignmentSettingsPage.clickOnEditButton();

            //verify SessionLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            //verify IdleLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            //verify show/limt progreass report section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit  progress report" );
            //verify InitialPlacement section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );
            //verify Calculater section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.CALCULATOR ), "Calculater section is displayed", "Calculater section is not displayed" );
            //verify Translate section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            //verify Scratchpad section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SCRATCHPAD ), "Scratchpad section is displayed", "Scratchpad section is not displayed" );
            //verify ShowAnswer section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHOW_ANSWER ), "ShowAnswer section is displayd", "ShowAnswer section is not displayed" );
            //verify ExitCourseButton section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed",
                    "ExitCourseButton section is not displayed" );
            //verify SpeedGames section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SPEED_GAMES ), "SpeedGames section is displayed", "SpeedGames section is not displayed" );
            //verify ManualSetCourseLevel section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedManuallySetCourseLevelSection( Constants.MANUALLY_SET_COURSE_LEVEL ), "ManuallySetCourseLevel section is displayed", "ManuallySetCourseLevel section is not displayed" );

            coursePage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Create Custom Reading course with settings and verify the corresponding settings are available in 'Assign To' modal popup", priority = 4, groups = { "SMK-40138", "Courses", "assignCourses" } )
    public void tcSMCoursesAssign014() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10065 : Create Custom Reading course with settings and verify the corresponding settings are available in 'Assign To' modal popup <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = new CoursesPage( driver );

            CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

            String courseName = coursesEditAssignmentSettingsPage.generateCourseName();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.STANDARDS, Constants.READING );

            SMUtils.waitForSpinnertoDisapper( driver, 60 );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            SMUtils.waitForSpinnertoDisapper( driver );

            //Click on the course
            coursePage.clickFromCourseListingPage( courseName );

            //Click on Edit button
            coursesEditAssignmentSettingsPage.clickOnEditButton();

            //verify SessionLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            //verify IdleLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            //verify show/limt progreass report section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit  progress report" );
            //verify InitialPlacement section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );

            //verify LO Information section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.DISPLAY_LO_INFORMATION ), "LO Information is displayed", "LO Information is not displayed" );

            //verify HELP ICON ACTIVE
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.HELP_ICON_ACTIVE ), "Help icon is active", "Help icon is not active" );

            //verify ExitCourseButton section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed",
                    "ExitCourseButton section is not displayed" );

            // Verify Spanish Glossary section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SPANISH_GLOSSARY ), "SPANISH GLOSSARY is displayed", "SPANISH GLOSSARY section is not displayed" );

            // Verify Read To Me section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.READ_TO_ME ), "Read To Me is displayed", "Read to Me section is not displayed" );

            // Verify Translate section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate is displayed", "Translate section is not displayed" );

            // Verify Share at District Level? section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHARE_AT_DISTRICT_LABEL ), "Share at District Level? is displayed",
                    "Share at District Level? section is not displayed" );

            // Verify Fluency section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.FLUENCY ), "Fluency section is displayed", "Fluency section is not displayed" );

            //verify ManualSetCourseLevel section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedManuallySetCourseLevelSection( Constants.MANUALLY_SET_COURSE_LEVEL ), "ManuallySetCourseLevel section is displayed", "ManuallySetCourseLevel section is not displayed" );

            coursePage.clickSaveBtn();

            // Signout from the application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user able to 'Add' Students to courses", priority = 2, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign013() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10054 : Verify the user able to 'Add' Students to courses<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            String staticCourseName = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            SMUtils.waitForSpinnertoDisapper( driver, 60 );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( staticCourseName );

            coursePage.clickAssignBtn();

            coursePage.addCourseToStudents();

            TopNavBar topNavBar = tHomePage.topNavBar;

            topNavBar.navigateToHomeTab();

            String firstAssignmentName = tHomePage.toGetfirstAssignmentInWidget();

            Log.assertThat( firstAssignmentName.contains( staticCourseName ), "Course added to students Successfully", "Course not added to students" );

            Log.testCaseResult();

            // Signout from the application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    //Student Details impacted
    @Test ( description = "SMK-10061 : Verify the assigned student user able to take the corresponding assignment from 'Programs' section ", groups = { "SMK-43903", "Skillspopup", "studentdetailspage" }, priority = 1 )
    public void tcSMCoursesAssign017() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10061 : Verify the assigned student user able to take the corresponding assignment from 'Programs' section <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignAssignmentPopup assignPopUp = new AssignAssignmentPopup( driver );

            // Selecting Math Course and assigning to student
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            String customReadingCourse = "Custom Reading_" + System.nanoTime();

            //Get CourseLising Page
            coursePage.clickCourseName( Constants.READING );

            coursePage.copyOfCourse( customReadingCourse, Constants.STANDARDS, Constants.READING );

            teacherHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickCourseName( customReadingCourse );

            Log.message( "Created custom reading course : " + customReadingCourse );
            coursePage.clickAssignBtn();

            coursePage.addCourseToStudents();
            
            String studentDetail = studentSMDetails;
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, "data,userName" );
            
            coursePage.clickAssignBtn();   
            assignPopUp.checkStudents();
            List<String> students = assignPopUp.getStudentListFromPopUp();
                     
            if(students.contains(studentUsername)) {
            coursePage.addCourseToOneStudent(studentUsername);
            }

            //SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            //execute in new way            
            executeCourse( studentUsername, customReadingCourse, false );

            //Login with teacher credential

            WebDriver newDriver = WebDriverFactory.get( browser );

            LoginWrapper.loginToSuccessMakerAsTeacher( newDriver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( newDriver );
            TeacherHomePage teacherNewHomePage = new TeacherHomePage( newDriver );
            courseWidgetDisplayed = teacherNewHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // navigate to Student Page
            StudentsPage studentPage = new StudentsPage( newDriver );
            teacherNewHomePage.topNavBar.navigateToStudentsTab();

            Log.message( "Student User Name is " + studentUsername );
            studentPage.clickOnTheHoveredStudentUserName( studentUsername );
            
            studentPage.clickDropDownForLastSession();
            studentPage.selectSubjectFromLastSessionDropDown( customReadingCourse );

            String skillValueInWidget = studentPage.getFirstSkillsTestedValues();

            studentPage.clickRecentSkillName();

            // Check Point value in popup
            String skillValueInPoup = studentPage.getSkillsTestedValuesFromPopup();
            Log.assertThat( skillValueInWidget.equals( skillValueInPoup ), "Point Value displays correctly in Popup", "Incorrect value displays in Popup" );
            Log.testCaseResult();
            newDriver.quit();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    //Student Details impacted
    @Test ( description = "SMK-10062 : Verify the assigned group users able to take the corresponding assignment from 'Programs' section ", groups = { "SMK-43903", "Skillspopup", "studentdetailspage" }, priority = 1 )
    public void tcSMCoursesAssign018() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10062 : Verify the assigned group users able to take the corresponding assignment from 'Programs' section <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignAssignmentPopup assignPopUp = new AssignAssignmentPopup( driver );

            // Selecting Math Course and assigning to student
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            String customReadingCourse = "Custom Reading_" + System.nanoTime();

            //Get CourseLising Page
            coursePage.clickCourseName( Constants.READING );

            coursePage.copyOfCourse( customReadingCourse, Constants.STANDARDS, Constants.READING );

            teacherHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickCourseName( customReadingCourse );

            Log.message( "Created custom reading course : " + customReadingCourse );
            coursePage.clickAssignBtn();

            coursePage.addCourseToOneGroup();
            
            coursePage.clickAssignBtn();   
            assignPopUp.checkStudents();
            List<String> students = assignPopUp.getStudentListFromPopUp();
            
            String studentDetail = studentSMDetails;
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, "data,userName" );            
            if(students.contains(studentUsername)) {
            coursePage.addCourseToOneStudent(studentUsername);
            }

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            driver.quit();

            //execute in new way
            executeCourse( studentUsername, customReadingCourse, false );

            //Login with teacher credential
            WebDriver newDriver = WebDriverFactory.get( browser );
            LoginWrapper.loginToSuccessMakerAsTeacher( newDriver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            TeacherHomePage teacherNewHomePage = new TeacherHomePage( newDriver );
            courseWidgetDisplayed = teacherNewHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // navigate to Student Page
            StudentsPage studentPage = new StudentsPage( newDriver );
            teacherNewHomePage.topNavBar.navigateToStudentsTab();
            SMUtils.waitForSpinnertoDisapper( newDriver );

            Log.message( "Student User Name is " + studentUsername );
            studentPage.clickOnTheHoveredStudentUserName( studentUsername );

            studentPage.clickDropDownForLastSession();
            studentPage.selectSubjectFromLastSessionDropDown( customReadingCourse );

            String skillValueInWidget = studentPage.getFirstSkillsTestedValues();

            studentPage.clickRecentSkillName();

            // Check Point value in popup
            String skillValueInPoup = studentPage.getSkillsTestedValuesFromPopup();
            Log.assertThat( skillValueInWidget.equals( skillValueInPoup ), "Point Value displays correctly in Popup", "Incorrect value displays in Popup" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Assign Default Math Course and verify the settings in 'Assign To' modal popup", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign019() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10063 : Assign Default Math Course and verify the settings in 'Assign To' modal popup <small><b><i>[" + browser + "]</b></i></small>" );

        AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            Log.assertThat( assignAssignmentPopup.courseAssignSettingLabels(), "Assignment settings are exist for Default Math course", "Assignment settings are exist for Default Math course" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Assign Default Reading Course and verify the settings in 'Assign To' modal popup ", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign020() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10064 : Assign Default Reading Course and verify the settings in 'Assign To' modal popup <small><b><i>[" + browser + "]</b></i></small>" );

        AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickReadingCourse();

            coursePage.clickAssignBtn();

            Log.assertThat( assignAssignmentPopup.courseAssignSettingLabels(), "Assignment settings are exist for Default Reading course", "Assignment settings are exist for Default Reading course" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Create Custom Reading course with settings and verify the corresponding settings are available in 'Assign To' modal popup ", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign021() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10066 : Create Custom Reading course with settings and verify the corresponding settings are available in 'Assign To' modal popup <small><b><i>[" + browser + "]</b></i></small>" );
        AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            CourseListingPage courseListingPage = new CourseListingPage( driver );

            String staticCourseName = coursePage.generateRandomCourseName();

            //Get CourseLising Page CourseListingPage courseListingPage =
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            SMUtils.waitForSpinnertoDisapper( driver );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            coursePage.clickOnCourseNameFromList( staticCourseName );

            coursePage.clickAssignBtn();

            Log.assertThat( assignAssignmentPopup.courseAssignSettingLabels(), "Assignment settings are exist for Default Math course", "Assignment settings are exist for Default Math course" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Create 'SM Focus Math' course with settings and verify the corresponding settings are available in 'Assign To' modal popup", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign022() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10067 : Create 'SM Focus Math' course with settings and verify the corresponding settings are available in 'Assign To' modal popup -<small><b><i>[" + browser + "]</b></i></small>" );
        AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            coursePage.clickCourseName( Constants.SM_FOCUS_MATH_GRADE_I );

            coursePage.clickAssignBtn();

            Log.assertThat( assignAssignmentPopup.courseAssignSettingLabels(), "Assignment settings are exist for Default Math course", "Assignment settings are exist for Default Math course" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Create 'SM Focus Reading' course with settings and verify the corresponding settings are available in 'Assign To' modal popup", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign023() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10068 : Create 'SM Focus Reading' course with settings and verify the corresponding settings are available in 'Assign To' modal popup<small><b><i>[" + browser + "]</b></i></small>" );
        AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            coursePage.clickCourseName( Constants.SM_FOCUS_READING_GRADE_I );

            coursePage.clickAssignBtn();

            Log.assertThat( assignAssignmentPopup.courseAssignSettingLabels(), "Assignment settings are exist for Default Math course", "Assignment settings are exist for Default Math course" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Assign Default Math Course and verify the settings in 'Assign To' modal popup", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign024() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10063 : Assign Default Math Course and verify the settings in 'Assign To' modal popup <small><b><i>[" + browser + "]</b></i></small>" );

        AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );
        StudentsPage studentPage = new StudentsPage( driver );

        String studentDetail = studentSMDetailsThree;
        CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

        String studentFirstNameAndLastName = SMUtils.getKeyValueFromResponse( studentDetail, "data,firstName" ) + SMUtils.getKeyValueFromResponse( studentDetail, "data,lastName" );
        String unassignedStudentName = SMUtils.getKeyValueFromResponse( studentDetail, "data,userName" );
        String studentIdentificationNumber = SMUtils.getKeyValueFromResponse( studentDetail, "data,studentIdentificationNumber" );
        Log.message( "Student Username is " + unassignedStudentName );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickMathCourse();

            coursePage.clickAssignBtn();

            //coursePage.addCourseToOneStudent( studentFirstNameAndLastName );
            coursePage.addCourseToStudents();

            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            Log.message( "Student Username is " + unassignedStudentName );
            studentPage.clickOnTheHoveredStudentUserName(unassignedStudentName);
            
            studentsPage.clickingThreedotsEllipsisFromAssignments( Constants.MATH );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Clicking on Ellipsis
            studentsPage.clickingThreedotsEllipsisFromAssignments( Constants.MATH );

            // Edit  assignment
            studentsPage.editAssignmentSettingsFromAssignment( Constants.MATH );
            Log.assertThat( studentsPage.isDisplayedCloseIcon(), "Edit Assignment Settings popup is displayed", "Edit Assignment Settings popup is not displayed" );

            //verify SessionLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            //verify IdleLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            //verify show/limt progreass report section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit  progress report" );
            //verify InitialPlacement section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );
            //verify Calculater section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.CALCULATOR ), "Calculater section is displayed", "Calculater section is not displayed" );
            //verify Translate section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            //verify Scratchpad section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SCRATCHPAD ), "Scratchpad section is displayed", "Scratchpad section is not displayed" );
            //verify ShowAnswer section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHOW_ANSWER ), "ShowAnswer section is displayd", "ShowAnswer section is not displayed" );
            //verify ExitCourseButton section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed",
                    "ExitCourseButton section is not displayed" );
            Log.assertThat( assignAssignmentPopup.courseAssignSettingLabels(), "Assignment settings are exist for Default Math course", "Assignment settings are exist for Default Math course" );
            studentsPage.clickCloseIconInAssignmentsPopup();

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-10071 : Verify the settings modified in 'Assign To' modal popup is displayed correctly for 'Custom Math course' in student's 'Assignment settings' page -", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign025() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10071 : Verify the settings modified in 'Assign To' modal popup is displayed correctly for 'Custom Math course' in student's 'Assignment settings' page <small><b><i>[" + browser + "]</b></i></small>" );

        AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );
        StudentsPage studentPage = new StudentsPage( driver );

        String studentDetail = studentSMDetailsThree;
        CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

        String studentFirstNameAndLastName = SMUtils.getKeyValueFromResponse( studentDetail, "data,firstName" ) + SMUtils.getKeyValueFromResponse( studentDetail, "data,lastName" );
        String unassignedStudentName = SMUtils.getKeyValueFromResponse( studentDetail, "data,userName" );
        String studentIdentificationNumber = SMUtils.getKeyValueFromResponse( studentDetail, "data,studentIdentificationNumber" );
        Log.message( "Student Username is " + unassignedStudentName );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );
            
            String customCourse = "Custom Math_" + simpleFormat.format(dateformated) + System.nanoTime();

            coursePage.clickCourseName( "Math" );

            coursePage.copyOfCourse( customCourse, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( customCourse );

            coursePage.clickAssignBtn();

            //coursePage.addCourseToOneStudent( studentFirstNameAndLastName );
            coursePage.addCourseToStudents();

            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            Log.message( "Student Username is " + unassignedStudentName );
            studentPage.clickOnTheHoveredStudentUserName(unassignedStudentName);
            
            studentsPage.clickingThreedotsEllipsisFromAssignments( customCourse );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Clicking on Ellipsis
            studentsPage.clickingThreedotsEllipsisFromAssignments( customCourse );

            // Edit  assignment
            studentsPage.editAssignmentSettingsFromAssignment( customCourse );
            Log.assertThat( studentsPage.isDisplayedCloseIcon(), "Edit Assignment Settings popup is displayed", "Edit Assignment Settings popup is not displayed" );

            //verify SessionLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            //verify IdleLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            //verify show/limt progreass report section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit  progress report" );
            //verify InitialPlacement section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );
            //verify Calculater section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.CALCULATOR ), "Calculater section is displayed", "Calculater section is not displayed" );
            //verify Translate section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            //verify Scratchpad section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SCRATCHPAD ), "Scratchpad section is displayed", "Scratchpad section is not displayed" );
            //verify ShowAnswer section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHOW_ANSWER ), "ShowAnswer section is displayd", "ShowAnswer section is not displayed" );
            //verify ExitCourseButton section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed",
                    "ExitCourseButton section is not displayed" );
            Log.assertThat( assignAssignmentPopup.courseAssignSettingLabels(), "Assignment settings are exist for Default Math course", "Assignment settings are exist for Default Math course" );
            studentsPage.clickCloseIconInAssignmentsPopup();

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-10070 : Verify the settings modified in 'Assign To' modal popup is displayed correctly for 'Default Reading' in student's 'Assignment settings' page ", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign026() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10070 : Verify the settings modified in 'Assign To' modal popup is displayed correctly for 'Default Reading' in student's 'Assignment settings' page <small><b><i>[" + browser + "]</b></i></small>" );

        AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );
        StudentsPage studentPage = new StudentsPage( driver );

        String studentDetail = studentSMDetailsThree;
        CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

        String studentFirstNameAndLastName = SMUtils.getKeyValueFromResponse( studentDetail, "data,firstName" ) + SMUtils.getKeyValueFromResponse( studentDetail, "data,lastName" );
        String unassignedStudentName = SMUtils.getKeyValueFromResponse( studentDetail, "data,userName" );
        String studentIdentificationNumber = SMUtils.getKeyValueFromResponse( studentDetail, "data,studentIdentificationNumber" );
        Log.message( "Student Username is " + unassignedStudentName );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickReadingCourse();

            coursePage.clickAssignBtn();

            //coursePage.addCourseToOneStudent( studentFirstNameAndLastName );
            coursePage.addCourseToStudents();

            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            Log.message( "Student Username is " + unassignedStudentName );
            studentPage.clickOnTheHoveredStudentUserName(unassignedStudentName);
            
            studentsPage.clickingThreedotsEllipsisFromAssignments( Constants.READING );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Clicking on Ellipsis
            studentsPage.clickingThreedotsEllipsisFromAssignments( Constants.READING );

            // Edit  assignment
            studentsPage.editAssignmentSettingsFromAssignment( Constants.READING );
            Log.assertThat( studentsPage.isDisplayedCloseIcon(), "Edit Assignment Settings popup is displayed", "Edit Assignment Settings popup is not displayed" );

            //verify SessionLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            //verify IdleLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            //verify show/limt progreass report section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit  progress report" );
            //verify InitialPlacement section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );

            //verify LO Information section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.DISPLAY_LO_INFORMATION ), "LO Information is displayed", "LO Information is not displayed" );

            //verify HELP ICON ACTIVE
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.HELP_ICON_ACTIVE ), "Help icon is active", "Help icon is not active" );

            //verify ExitCourseButton section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed",
                    "ExitCourseButton section is not displayed" );

            // Verify Spanish Glossary section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SPANISH_GLOSSARY ), "SPANISH GLOSSARY is displayed", "SPANISH GLOSSARY section is not displayed" );

            // Verify Read To Me section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.READ_TO_ME ), "Read To Me is displayed", "Read to Me section is not displayed" );

            // Verify Translate section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate is displayed", "Translate section is not displayed" );

            // Verify Share at District Level? section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHARE_AT_DISTRICT_LABEL ), "Share at District Level? is displayed",
                    "Share at District Level? section is not displayed" );

            // Verify Fluency section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.FLUENCY ), "Fluency section is displayed", "Fluency section is not displayed" );

            //verify ManualSetCourseLevel section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedManuallySetCourseLevelSection( Constants.MANUALLY_SET_COURSE_LEVEL ), "ManuallySetCourseLevel section is displayed", "ManuallySetCourseLevel section is not displayed" );

            Log.assertThat( assignAssignmentPopup.courseAssignSettingLabels(), "Assignment settings are exist for Default Math course", "Assignment settings are exist for Default Math course" );
            studentsPage.clickCloseIconInAssignmentsPopup();

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the settings modified while Creating Custom Math course is available correctly in 'Assign To' modal popup and individual student's settings page", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign027() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10071 : Verify the settings modified in 'Assign To' modal popup is displayed correctly for 'Custom Math course' in student's 'Assignment settings' page <small><b><i>[" + browser + "]</b></i></small>" );

        AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );
        StudentsPage studentPage = new StudentsPage( driver );

        String studentDetail = studentSMDetailsThree;
        CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

        String studentFirstNameAndLastName = SMUtils.getKeyValueFromResponse( studentDetail, "data,firstName" ) + SMUtils.getKeyValueFromResponse( studentDetail, "data,lastName" );
        String unassignedStudentName = SMUtils.getKeyValueFromResponse( studentDetail, "data,userName" );
        String studentIdentificationNumber = SMUtils.getKeyValueFromResponse( studentDetail, "data,studentIdentificationNumber" );
        Log.message( "Student identification number is " + studentIdentificationNumber );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            String customCourse = "Custom Math_" + simpleFormat.format(dateformated) + System.nanoTime();

            coursePage.clickCourseName( "Math" );

            coursePage.copyOfCourse( customCourse, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( customCourse );

            coursePage.clickAssignBtn();

            //coursePage.addCourseToOneStudent( studentFirstNameAndLastName );
            coursePage.addCourseToStudents();

            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            Log.message( "Student Username is " + unassignedStudentName );
            studentPage.clickOnTheHoveredStudentUserName(unassignedStudentName);
          
            studentsPage.clickingThreedotsEllipsisFromAssignments( customCourse );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Clicking on Ellipsis
            studentsPage.clickingThreedotsEllipsisFromAssignments( customCourse );

            // Edit  assignment
            studentsPage.editAssignmentSettingsFromAssignment( customCourse );
            Log.assertThat( studentsPage.isDisplayedCloseIcon(), "Edit Assignment Settings popup is displayed", "Edit Assignment Settings popup is not displayed" );

            //verify SessionLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            //verify IdleLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            //verify show/limt progreass report section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit  progress report" );
            //verify InitialPlacement section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );
            //verify Calculater section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.CALCULATOR ), "Calculater section is displayed", "Calculater section is not displayed" );
            //verify Translate section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            //verify Scratchpad section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SCRATCHPAD ), "Scratchpad section is displayed", "Scratchpad section is not displayed" );
            //verify ShowAnswer section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHOW_ANSWER ), "ShowAnswer section is displayd", "ShowAnswer section is not displayed" );
            //verify ExitCourseButton section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed",
                    "ExitCourseButton section is not displayed" );
            Log.assertThat( assignAssignmentPopup.courseAssignSettingLabels(), "Assignment settings are exist for Default Math course", "Assignment settings are exist for Default Math course" );
            studentsPage.clickCloseIconInAssignmentsPopup();

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the settings modified while Creating Custom Reading course is available correctly in 'Assign To' modal popup and individual student's settings page", priority = 1, groups = { "SMK-38839", "Courses", "assignCourses" } )

    public void tcSMCoursesAssign028() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-10078 : Verify the settings modified while Creating Custom Reading course is available correctly in 'Assign To' modal popup and individual student's settings page <small><b><i>[" + browser + "]</b></i></small>" );

        AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );
        StudentsPage studentPage = new StudentsPage( driver );

        String studentDetail = studentSMDetailsThree;
        CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

        String studentFirstNameAndLastName = SMUtils.getKeyValueFromResponse( studentDetail, "data,firstName" ) + SMUtils.getKeyValueFromResponse( studentDetail, "data,lastName" );
        String unassignedStudentName = SMUtils.getKeyValueFromResponse( studentDetail, "data,userName" );

        String studentIdentificationNumber = SMUtils.getKeyValueFromResponse( studentDetail, "data,studentIdentificationNumber" );
        Log.message( "Student identification number is " + studentIdentificationNumber );

        try {
            AssignAssignmentPopup assignpopup = new AssignAssignmentPopup( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            String customCourseGroup = "Custom Reading" + simpleFormat.format(dateformated) + System.nanoTime();
            coursePage.copyOfCourse( customCourseGroup, Constants.STANDARDS, Constants.READING );
            tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( customCourseGroup );
            coursePage.clickAssignBtn();

            //coursePage.addCourseToOneStudent( studentFirstNameAndLastName );
            coursePage.addCourseToStudents();

            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            Log.message( "Student Username is " + unassignedStudentName );
            studentPage.clickOnTheHoveredStudentUserName(unassignedStudentName);
            
            studentsPage.clickingThreedotsEllipsisFromAssignments( customCourseGroup );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Clicking on Ellipsis
            studentsPage.clickingThreedotsEllipsisFromAssignments( customCourseGroup );

            // Edit  assignment
            studentsPage.editAssignmentSettingsFromAssignment( customCourseGroup );
            Log.assertThat( studentsPage.isDisplayedCloseIcon(), "Edit Assignment Settings popup is displayed", "Edit Assignment Settings popup is not displayed" );

            //verify SessionLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            //verify IdleLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            //verify show/limt progreass report section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit  progress report" );
            //verify InitialPlacement section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );

            //verify LO Information section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.DISPLAY_LO_INFORMATION ), "LO Information is displayed", "LO Information is not displayed" );

            //verify HELP ICON ACTIVE
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.HELP_ICON_ACTIVE ), "Help icon is active", "Help icon is not active" );

            //verify ExitCourseButton section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed",
                    "ExitCourseButton section is not displayed" );

            // Verify Spanish Glossary section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SPANISH_GLOSSARY ), "SPANISH GLOSSARY is displayed", "SPANISH GLOSSARY section is not displayed" );

            // Verify Read To Me section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.READ_TO_ME ), "Read To Me is displayed", "Read to Me section is not displayed" );

            // Verify Translate section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate is displayed", "Translate section is not displayed" );

            // Verify Share at District Level? section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHARE_AT_DISTRICT_LABEL ), "Share at District Level? is displayed",
                    "Share at District Level? section is not displayed" );

            // Verify Fluency section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.FLUENCY ), "Fluency section is displayed", "Fluency section is not displayed" );

            //verify ManualSetCourseLevel section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedManuallySetCourseLevelSection( Constants.MANUALLY_SET_COURSE_LEVEL ), "ManuallySetCourseLevel section is displayed", "ManuallySetCourseLevel section is not displayed" );

            Log.assertThat( assignAssignmentPopup.courseAssignSettingLabels(), "Assignment settings are exist for Default Math course", "Assignment settings are exist for Default Math course" );
            studentsPage.clickCloseIconInAssignmentsPopup();

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To execute the course
     *
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "10" );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "10" );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        }

    }
}