/**
 * Help Page Test Cases
 *
 * @author Sudarshan.Govindarajan
 */

package com.savvas.sm.teacher.ui.tests.ContextualHelpDocumentation;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.CPRPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LSRPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.SPRPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class ContextualHelpTestCases extends BaseTest {

    private String smUrl;
    private String browser;
    List<String> expectedCourseTypesInDropdown = Arrays.asList( "Focus Courses", "Default Courses", "Custom Courses", "All Courses" );
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher13" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( description = "Verify the contextual help icon is present in top right of the SM application page", priority = 1 )
    public void tcSMContextualHelp001() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMContextualHelp001 : Verify the contextual help icon is clickable, which is present in top right of the SM application Page <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            WebElement helpIconShadowElement = SMUtils.getWebElement( driver, tHomePage.topNavBar.getTopNavBarwithShadow(), tHomePage.topNavBar.getHelpIconShadowCSS() );
            WebElement helpIcon = SMUtils.getWebElement( driver, helpIconShadowElement, tHomePage.topNavBar.getHelpIconCSS() );
            Log.assertThat( helpIcon.isDisplayed(), "Help Icon is present", "Help Icon is not present" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the contextual help icon is clickable, which is present in top right of the SM application Page", priority = 2 )
    public void tcSMContextualHelp002() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMContextualHelp002 : Verify the contextual help icon is clickable, which is present in top right of the SM application Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            WebElement helpIconShadowElement = SMUtils.getWebElement( driver, tHomePage.topNavBar.getTopNavBarwithShadow(), tHomePage.topNavBar.getHelpIconShadowCSS() );
            WebElement helpIcon = SMUtils.getWebElement( driver, helpIconShadowElement, tHomePage.topNavBar.getHelpIconCSS() );
            Log.assertThat( SMUtils.verifyCssPropertyForElement( helpIcon, "cursor", "pointer" ), "Contextual Help Icon is clickable", "Contextual Help Icon is not clickable" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify user is navigated to the new tab when user click on the contextual help icon", priority = 3 )
    public void tcSMContextualHelp003() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMContextualHelp003 : Verify user is navigated to the new tab when user click on the contextual help icon <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            WebElement helpIconShadowElement = SMUtils.getWebElement( driver, tHomePage.topNavBar.getTopNavBarwithShadow(), tHomePage.topNavBar.getHelpIconShadowCSS() );
            WebElement helpIcon = SMUtils.getWebElement( driver, helpIconShadowElement, tHomePage.topNavBar.getHelpIconCSS() );
            Set<String> tabs_beforehelpiconclick = driver.getWindowHandles();
            SMUtils.clickJS( driver, helpIcon );
            Set<String> tabs_AfterHelpIconClick = driver.getWindowHandles();
            Log.assertThat( ( tabs_AfterHelpIconClick.size() > tabs_beforehelpiconclick.size() ? true : false ), "New Windows is opened", "New Windows is not opened" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the SM help Dashboard page is loaded in a new tab when user is clicked on contextual help icon", priority = 4 )
    public void tcSMContextualHelp004() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMContextualHelp004 : Verify the SM help Dashboard page is loaded in a new tab when user is clicked on contextual help icon <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            tHomePage.topNavBar.navigateToHelpPage();

            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, tHomePage.getHomePageHelpPageHeader(), 10 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.HOMEPAGEHELPTITLE ), "SM help Home page is loaded in a new tab", "SM help Home page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the SM help Groups List page is loaded in a new tab when user is clicked on contextual help icon", priority = 5 )
    public void tcSMContextualHelp005() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMContextualHelp005 : Verify the SM help Groups List page is loaded in a new tab when user is clicked on contextual help icon <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            tHomePage.topNavBar.navigateToStudentsTab();
            tHomePage.topNavBar.navigateToHelpPage();

            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, tHomePage.getStudentsPageHelpPageHeader(), 10 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.STUDENTHELPPAGETITLE ), "SM help Students page is loaded in a new tab", "SM help Courses page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the SM help Groups List page is loaded in a new tab when user is clicked on contextual help icon", priority = 6 )
    public void tcSMContextualHelp006() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMContextualHelp006 : Verify the SM help Groups List page is loaded in a new tab when user is clicked on contextual help icon <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            tHomePage.topNavBar.navigateToGroupsTab();
            tHomePage.topNavBar.navigateToHelpPage();

            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, tHomePage.getGroupsPageHelpPageHeader(), 10 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.GROUPSHELPPAGETITLE ), "SM help Groups page is loaded in a new tab", "SM help Courses page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the SM help Assignments List page is loaded in a new tab when user is clicked on contextual help icon", priority = 7 )
    public void tcSMContextualHelp007() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMContextualHelp007 : Verify the SM help Assignments List page is loaded in a new tab when user is clicked on contextual help icon <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            tHomePage.topNavBar.navigateToAssignmentsPage();
            tHomePage.topNavBar.navigateToHelpPage();

            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, tHomePage.getAssignementPageHelpPageHeader(), 10 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.ASSIGNMENTHELPPAGETITLE ), "SM help Assignments page is loaded in a new tab", "SM help Courses page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the SM help Courses page is loaded in a new tab when user is clicked on contextual help icon", priority = 8 )
    public void tcSMContextualHelp008() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMContextualHelp008 : Verify the SM help Courses page is loaded in a new tab when user is clicked on contextual help icon <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            tHomePage.topNavBar.navigateToCourseListingPage();
            tHomePage.topNavBar.navigateToHelpPage();

            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, tHomePage.getCoursesHelpPageHeader(), 10 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.COURSESHELPPAGETITLE ), "SM help Courses page is loaded in a new tab", "SM help Courses page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the SM help Mastery page is loaded in a new tab when user is clicked on contextual help icon", priority = 9 )
    public void tcSMContextualHelp009() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMContextualHelp009 : Verify the SM help Mastery page is loaded in a new tab when user is clicked on contextual help icon <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            tHomePage.topNavBar.navigateToMasteryTab();
            tHomePage.topNavBar.navigateToHelpPage();

            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, tHomePage.getMasteryHelpPageHeader(), 10 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.MASTERYHELPPAGETITLE ), "SM help Mastery page is loaded in a new tab", "SM help Mastery page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the SM help Cumulative Performance Report page is loaded in a new tab when user is clicked on contextual help icon", priority = 10 )
    public void tcSMContextualHelp010() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMContextualHelp010 : Verify the SM help Cumulative Performance Report page is loaded in a new tab when user is clicked on contextual help icon <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            CPRPage cprPage = tHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();
            WebElement cprPageHelpIcon = cprPage.getCprPageHelpIcon();
            SMUtils.clickJS( driver, cprPageHelpIcon );
            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, cprPage.getCprHelpPageHeader(), 10 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.CPRHELPPAGETITILE ), "SM help Cumulative Performance Report page is loaded in a new tab", "SM help Cumulative Performance Report page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the SM help Last Session Report page is loaded in a new tab when user is clicked on contextual help icon", priority = 11 )
    public void tcSMContextualHelp011() throws Throwable {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMContextualHelp011 : Verify the SM help Last Session Report page is loaded in a new tab when user is clicked on contextual help icon <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            LSRPage lastSessionPage = tHomePage.topNavBar.navigateToReportsLastSessionTab();
            WebElement lastSessionPageHelpIconPageHelpIcon = lastSessionPage.getLastSessionPageHelpIcon();
            SMUtils.clickJS( driver, lastSessionPageHelpIconPageHelpIcon );
            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, lastSessionPage.getLastSessionHeader(), 10 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.LSRHELPPAGETITLE ), "SM help Last Session Report page is loaded in a new tab", "SM help Last Session Report page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the SM help Last Session Report page is loaded in a new tab when user is clicked on contextual help icon", priority = 12 )
    public void tcSMContextualHelp012() throws Throwable {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        try {
            Log.testCaseInfo( "tcSMContextualHelp012 : Verify the SM help Last Session Report page is loaded in a new tab when user is clicked on contextual help icon <small><b><i>[" + browser + "]</b></i></small>" );
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            SPRPage studentPerformancePage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            WebElement studentPerformancePageHelpIcon = studentPerformancePage.getStudentPerformancePageHelpIcon();
            SMUtils.clickJS( driver, studentPerformancePageHelpIcon );
            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, studentPerformancePage.getStudentPerformanceHeader(), 10 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.SPRHELPPAGETITILE ), "SM help Student Performance Report page is loaded in a new tab", "SM help Student Performance Report page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the 'i' icon is present in top left of the Mastery title page", priority = 13 )
    public void tcSMContextualHelp013() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMContextualHelp013: Verify the 'i' icon is present in top left of the Mastery title page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            WebElement celliconexist = masteryPage.getCellIcon();
            Log.assertThat( SMUtils.isElementPresent( celliconexist ), "Information Icon exists", "Information Icon doesnot exist" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify user is able to click  'i' icon in the Mastery page", priority = 14 )
    public void tcSMContextualHelp014() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMContextualHelp014: Verify user is able to click  'i' icon in the Mastery page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            WebElement celliconexist = masteryPage.getCellIcon();
            Log.assertThat( SMUtils.verifyCssPropertyForElement( celliconexist, "cursor", "pointer" ), "Information Icon is clickable", "Information Icon is not clickable" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify user is navigated to the new tab when user click on the 'i' icon present in the Mastery page", priority = 15 )
    public void tcSMContextualHelp015() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMContextualHelp015: Verify user is navigated to the new tab when user click on the 'i' icon present in the Mastery page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            WebElement celliconexist = masteryPage.getCellIcon();
            Set<String> tabs_beforehelpiconclick = driver.getWindowHandles();
            SMUtils.clickJS( driver, celliconexist );
            Set<String> tabs_AfterHelpIconClick = driver.getWindowHandles();
            Log.assertThat( ( tabs_AfterHelpIconClick.size() > tabs_beforehelpiconclick.size() ? true : false ), "New Windows is opened", "New Windows is not opened" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the SM help Mastery page is loaded in a new tab when user is clicked 'i' icon present in the Mastery page", priority = 16 )
    public void tcSMContextualHelp016() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMContextualHelp016: Verify the SM help Mastery page is loaded in a new tab when user is clicked 'i' icon present in the Mastery page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            WebElement celliconexist = masteryPage.getCellIcon();
            SMUtils.clickJS( driver, celliconexist );
            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, masteryPage.getMasteryFromHelpPage(), 30 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.MASTERYHELPPAGETITLE ), "SM help Mastery page is loaded in a new tab", "SM help Mastery page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the 'i' icon is present in top of the create Group alert popup", priority = 17 )
    public void tcSMContextualHelp017() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMContextualHelp017: Verify the 'i' icon is present in top of the create Group alert popup <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
            driver.manage().timeouts().implicitlyWait( 20, TimeUnit.SECONDS );
            WebElement createNewGroupBtn = groupPage.getBtnCreateNewGroup();
            SMUtils.clickJS( driver, createNewGroupBtn );
            WebElement dialogbox = groupPage.getCreateNewGroupDialogBox();
            SMUtils.waitForElement( driver, dialogbox );
            WebElement groupHelpInfoIcon = groupPage.getBtnCreateNewGroupHelpInfoIcon();
            Log.assertThat( SMUtils.isElementPresent( groupHelpInfoIcon ), "Information Icon exists on the create New Group Dialog box", "Information Icon does not exist on the create New Group Dialog box" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the 'i' icon is clickable which is present in top of the create Group alert popup", priority = 18 )
    public void tcSMContextualHelp018() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMContextualHelp018: Verify the 'i' icon is clickable which is present in top of the create Group alert popup <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
            driver.manage().timeouts().implicitlyWait( 20, TimeUnit.SECONDS );
            WebElement createNewGroupBtn = groupPage.getBtnCreateNewGroup();
            SMUtils.clickJS( driver, createNewGroupBtn );
            WebElement dialogbox = groupPage.getCreateNewGroupDialogBox();
            SMUtils.waitForElement( driver, dialogbox );
            WebElement groupHelpInfoIcon = groupPage.getBtnCreateNewGroupHelpInfoIcon();
            Log.assertThat( SMUtils.verifyCssPropertyForElement( groupHelpInfoIcon, "cursor", "pointer" ), "Information Icon is clickable", "Information Icon is not clickable" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify user is navigated to the new tab when user click on the 'i' icon present in the Create Group alert popup", priority = 19 )
    public void tcSMContextualHelp019() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMContextualHelp019: Verify user is navigated to the new tab when user click on the 'i' icon present in the Create Group alert popup <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
            driver.manage().timeouts().implicitlyWait( 20, TimeUnit.SECONDS );
            WebElement createNewGroupBtn = groupPage.getBtnCreateNewGroup();
            SMUtils.clickJS( driver, createNewGroupBtn );
            WebElement dialogbox = groupPage.getCreateNewGroupDialogBox();
            SMUtils.waitForElement( driver, dialogbox );
            WebElement groupHelpInfoIcon = groupPage.getBtnCreateNewGroupHelpInfoIcon();
            Set<String> tabs_beforehelpiconclick = driver.getWindowHandles();
            SMUtils.clickJS( driver, groupHelpInfoIcon );
            Set<String> tabs_AfterHelpIconClick = driver.getWindowHandles();
            Log.assertThat( ( tabs_AfterHelpIconClick.size() > tabs_beforehelpiconclick.size() ? true : false ), "New Windows is opened", "New Windows is not opened" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the SM help Create a New Group page is loaded in a new tab when user is clicked 'i' icon present in the Create New Group alert popup", priority = 20 )
    public void tcSMContextualHelp020() throws Exception {

    	/* for browserstack execution */
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMContextualHelp020: Verify the SM help Create a New Group page is loaded in a new tab when user is clicked 'i' icon present in the Create New Group alert popup <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
            driver.manage().timeouts().implicitlyWait( 20, TimeUnit.SECONDS );
            WebElement createNewGroupBtn = groupPage.getBtnCreateNewGroup();
            SMUtils.clickJS( driver, createNewGroupBtn );
            WebElement dialogbox = groupPage.getCreateNewGroupDialogBox();
            SMUtils.waitForElement( driver, dialogbox );
            WebElement groupHelpInfoIcon = groupPage.getBtnCreateNewGroupHelpInfoIcon();
            String currentwindow = driver.getWindowHandle();
            SMUtils.clickJS( driver, groupHelpInfoIcon );
            Set<String> tabs_createnewgroup = driver.getWindowHandles();
            for ( String tab_createnewgroup : tabs_createnewgroup ) {
                if ( !tab_createnewgroup.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, groupPage.getCreateNewGroupHelpPageHeader(), 5 );
                    driver.switchTo().window( tab_createnewgroup );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.CREATENEWGROUPDIALOGBOXHELPPAGETITLE ), "SM help Create a New Group page is loaded in a new tab", "SM help Mastery page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }
}
