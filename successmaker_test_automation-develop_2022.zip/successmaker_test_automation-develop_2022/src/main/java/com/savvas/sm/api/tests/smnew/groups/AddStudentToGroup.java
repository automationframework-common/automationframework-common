package com.savvas.sm.api.tests.smnew.groups;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.getGroupListAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

/**
 * This class created to test the add student to assignment functionality API.
 * 
 * @author ajith.mohan
 *
 */
public class AddStudentToGroup extends GroupAPI {

    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );

    @BeforeClass ( alwaysRun = true )

    public void BeforeClass() {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
    }

    @Test ( priority = 1, dataProvider = "addStudentToGroupPositiveScenariosData", groups = { "smoke_test_case", "Smoke TC001_AddStudentsToGroup", "Adding Students to Group", "P1", "SMK-51958", "Group", "Adding Students to Group", "P1", "API" } )
    public void tcAddStudentToGroup001( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

       
        String studentUsername = null;
        String studentID = null;
        String sharedTeacher = null;
        String sharedTeacherID = null;

        switch ( scenario ) {
            case "HAPPY_PATH":
                HashMap<String, String> groupDetails = new HashMap<>();
                HashMap<String, String> userDetails = new HashMap<>();
                HashMap<String, String> response = new HashMap<>();
                List<String> groupIds = new ArrayList<>();
                List<String> studentRumbaIds = new ArrayList<>();
                List<String> teacherRumbaIds = new ArrayList<>();
                List<String> schools = new ArrayList<>();
                
                String groupName = "Successmaker API Test Group " + System.nanoTime();
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.BODY ), "data,groupId" ) );

                studentUsername = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsername );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );
                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );

                //Getting response
                response = addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "addStudentToGroup", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                verifyResponse( response.get( Constants.BODY ) );
                break;

            case "ADD STUDENT AGAIN":
                HashMap<String, String> groupDetails1 = new HashMap<>();
                HashMap<String, String> userDetails1 = new HashMap<>();
                HashMap<String, String> response1 = new HashMap<>();
                List<String> groupIds1 = new ArrayList<>();
                List<String> studentRumbaIds1 = new ArrayList<>();
                List<String> teacherRumbaIds1 = new ArrayList<>();
                List<String> schools1 = new ArrayList<>();
                String groupName1 = "Successmaker API Test Group " + System.nanoTime();
                groupDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails1.put( CreateGroupAPIConstants.GROUP_NAME, groupName1 );
                groupIds1.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails1, studentRumbaIds1 ).get( Constants.BODY ), "data,groupId" ) );

               String studentUsername1 = "AddStudGRPS1" + System.nanoTime();

                userDetails1.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails1.put( RBSDataSetupConstants.USERNAME, studentUsername1 );
                userDetails1.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails1.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails1.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );
                String studentID1 = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails1 ), RBSDataSetupConstants.USERID );
                studentRumbaIds1.add( studentID1 );
                addStudentToGroup( smUrl, groupDetails1, studentRumbaIds1, groupIds1 );

                //Getting response
                response1 = addStudentToGroup( smUrl, groupDetails1, studentRumbaIds1, groupIds1 );
                Log.assertThat( response1.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response1.get( Constants.STATUS_CODE ) );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "addStudentToGroup", statusCode, response1.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                verifyResponse( response1.get( Constants.BODY ) );
                break;

            case "SINGLE_STUDENT_WITH_MULTIPLE_GROUP":
                
                HashMap<String, String> groupDetails2 = new HashMap<>();
                HashMap<String, String> userDetails2 = new HashMap<>();
                HashMap<String, String> response2 = new HashMap<>();
                List<String> groupIds2 = new ArrayList<>();
                List<String> studentRumbaIds2 = new ArrayList<>();
                List<String> teacherRumbaIds2 = new ArrayList<>();
                List<String> schools2 = new ArrayList<>();
                String groupName2 = "Successmaker API Test Group " + System.nanoTime();

                groupDetails2.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails2.put( CreateGroupAPIConstants.GROUP_NAME, groupName2 + System.nanoTime() );
                groupIds2.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails2, studentRumbaIds2 ).get( Constants.BODY ), "data,groupId" ) );
                groupDetails2.put( CreateGroupAPIConstants.GROUP_NAME, groupName2 + System.nanoTime() );
                groupIds2.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails2, studentRumbaIds2 ).get( Constants.BODY ), "data,groupId" ) );
                groupDetails2.put( CreateGroupAPIConstants.GROUP_NAME, groupName2 + System.nanoTime() );
                groupIds2.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails2, studentRumbaIds2 ).get( Constants.BODY ), "data,groupId" ) );

                String studentUsername2 = "AddStudGRPS1" + System.nanoTime();
                studentRumbaIds2.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );

                userDetails2.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails2.put( RBSDataSetupConstants.USERNAME, studentUsername2 );
                userDetails2.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails2.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails2.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );
                String studentID2 = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails2 ), RBSDataSetupConstants.USERID );
                studentRumbaIds2.add( studentID2 );

                //Getting response
                response2 = addStudentToGroup( smUrl, groupDetails2, studentRumbaIds2, groupIds2 );
                Log.assertThat( response2.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response2.get( Constants.STATUS_CODE ) );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "addStudentToGroup", statusCode, response2.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                verifyResponse( response2.get( Constants.BODY ) );
                break;

            case "MULTIPLE STUDENTS TO SINGLE GROUP":
                HashMap<String, String> groupDetails3 = new HashMap<>();
                HashMap<String, String> userDetails3 = new HashMap<>();
                HashMap<String, String> response3 = new HashMap<>();
                List<String> groupIds3 = new ArrayList<>();
                List<String> studentRumbaIds3 = new ArrayList<>();
                List<String> teacherRumbaIds3 = new ArrayList<>();
                List<String> schools3 = new ArrayList<>();
                String groupName3 = "Successmaker API Test Group " + System.nanoTime();

                groupDetails3.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails3.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails3.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails3.put( CreateGroupAPIConstants.GROUP_NAME, groupName3 );
                groupIds3.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails3, studentRumbaIds3 ).get( Constants.BODY ), "data,groupId" ) );

                studentRumbaIds3.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );
                studentRumbaIds3.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), RBSDataSetupConstants.USERID ) );
                studentRumbaIds3.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student3" ), RBSDataSetupConstants.USERID ) );
                //Getting response
                response3 = addStudentToGroup( smUrl, groupDetails3, studentRumbaIds3, groupIds3 );
                Log.assertThat( response3.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response3.get( Constants.STATUS_CODE ) );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "addStudentToGroup", statusCode, response3.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                verifyResponse( response3.get( Constants.BODY ) );
                break;

            case "MULTI ORG STUDENT ID":
                HashMap<String, String> groupDetails4 = new HashMap<>();
                HashMap<String, String> userDetails4 = new HashMap<>();
                HashMap<String, String> response4 = new HashMap<>();
                List<String> groupIds4 = new ArrayList<>();
                List<String> studentRumbaIds4 = new ArrayList<>();
                List<String> teacherRumbaIds4 = new ArrayList<>();
                List<String> schools4 = new ArrayList<>();
                String groupName4= "Successmaker API Test Group " + System.nanoTime();

                groupDetails4.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails4.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails4.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails4.put( CreateGroupAPIConstants.GROUP_NAME, groupName4 );
                groupIds4.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails4, studentRumbaIds4 ).get( Constants.BODY ), "data,groupId" ) );

                String multiSchoolStudent = "MultiSchStudent" + System.nanoTime();
                studentRumbaIds4.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );

                userDetails4.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails4.put( RBSDataSetupConstants.USERNAME, multiSchoolStudent );
                userDetails4.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

                schools4.add( RBSDataSetup.organizationIDs.get( school ) );
                schools4.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                String finalSchool = "";
                for ( String school : schools4 ) {
                    finalSchool += school.concat( "\",\"" );
                }
                finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
                userDetails4.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
                String multiSchoolStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails4 ), RBSDataSetupConstants.USERID );
                studentRumbaIds4.add( multiSchoolStudentID );

                //Getting response
                response4 = addStudentToGroup( smUrl, groupDetails4, studentRumbaIds4, groupIds4 );
                Log.assertThat( response4.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response4.get( Constants.STATUS_CODE ) );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "addStudentToGroup", statusCode, response4.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                verifyResponse( response4.get( Constants.BODY ) );
                break;

            case "SHARED STUDNET GROUP":
                HashMap<String, String> groupDetails5 = new HashMap<>();
                HashMap<String, String> userDetails5= new HashMap<>();
                HashMap<String, String> response5 = new HashMap<>();
                List<String> groupIds5 = new ArrayList<>();
                List<String> studentRumbaIds5 = new ArrayList<>();
                List<String> teacherRumbaIds5 = new ArrayList<>();
                List<String> schools5= new ArrayList<>();
                String groupName5= "Successmaker API Test Group " + System.nanoTime();

                String sharedTeacher1 = "SharedTeacher" + System.nanoTime();

                userDetails5.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails5.put( RBSDataSetupConstants.USERNAME, sharedTeacher1 );
                userDetails5.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                userDetails5.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );

                sharedTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails5 ), RBSDataSetupConstants.USERID );
                new RBSUtils().resetPassword( userDetails5.get( RBSDataSetupConstants.ORGANIZATIONIDS ), RBSDataSetupConstants.DEFAULT_PASSWORD, sharedTeacherID );

                studentUsername = "sharedStudent01" + System.nanoTime();

                userDetails5.put( RBSDataSetupConstants.USERNAME, studentUsername );
                userDetails5.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                String studentID5 = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails5 ), RBSDataSetupConstants.USERID );

                //Creating new students and adding him in 2 groups from two teachers to make shared student
                studentRumbaIds5.add( studentID5 );

                //Adding new teachers group
                groupDetails5.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( sharedTeacher1, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails5.put( CreateGroupAPIConstants.GROUP_OWNER_ID, sharedTeacherID );
                groupDetails5.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails5.put( CreateGroupAPIConstants.GROUP_NAME, groupName5 + System.nanoTime() );
                createGroup( smUrl, groupDetails5, studentRumbaIds5 );
                groupDetails5.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );

                //Adding another teacher group
                groupDetails5.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails5.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails5.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails5.put( CreateGroupAPIConstants.GROUP_NAME, groupName5 + System.nanoTime() );
                createGroup( smUrl, groupDetails5, studentRumbaIds5 );

                //Creating empty group
                List<String> studentRumbaIdsEmpty = new ArrayList<String>();
                groupIds5.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails5, studentRumbaIdsEmpty).get( Constants.BODY ), "data,groupId" ) );

                //Getting response
                response5 = addStudentToGroup( smUrl, groupDetails5, studentRumbaIds5, groupIds5 );
                Log.assertThat( response5.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response5.get( Constants.STATUS_CODE ) );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "addStudentToGroup", statusCode, response5.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                verifyResponse( response5.get( Constants.BODY ) );
                break;

            case "SHARED TEACHER GROUP":
                HashMap<String, String> groupDetails6 = new HashMap<>();
                HashMap<String, String> userDetails6= new HashMap<>();
                HashMap<String, String> response6 = new HashMap<>();
                List<String> groupIds6 = new ArrayList<>();
                List<String> studentRumbaIds6 = new ArrayList<>();
                List<String> teacherRumbaIds6 = new ArrayList<>();
                List<String> schools6= new ArrayList<>();
                String groupName6= "Successmaker API Test Group " + System.nanoTime();


               String sharedTeacher2 = "SharedTeacher" + System.nanoTime();

                userDetails6.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails6.put( RBSDataSetupConstants.USERNAME, sharedTeacher2 );
                userDetails6.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                userDetails6.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );

                String sharedTeacherID2 = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails6 ), RBSDataSetupConstants.USERID );
                new RBSUtils().resetPassword( userDetails6.get( RBSDataSetupConstants.ORGANIZATIONIDS ), RBSDataSetupConstants.DEFAULT_PASSWORD, sharedTeacherID2 );

                teacherRumbaIds6.add( sharedTeacherID2 );
                teacherRumbaIds6.add( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );

                studentRumbaIds6.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );

                groupDetails6.clear();
                groupDetails6.put( RBSDataSetupConstants.USERNAME, sharedTeacher2 );
                groupDetails6.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails6.put( RBSDataSetupConstants.SECTION_NAME, groupName6 );
                groupDetails6.put( RBSDataSetupConstants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );

                String createGroupResp = new RBSUtils().createClassWithMultipleTeacher( groupDetails6, teacherRumbaIds6, studentRumbaIds6 );

                String sharedTeacherGroupId = new JSONObject( createGroupResp ).getJSONObject( "data" ).getJSONObject( "section" ).get( "id" ).toString();
                groupIds6.add( sharedTeacherGroupId );

                String studentUsername6 = "StudentTest" + System.nanoTime();
                userDetails6.put( RBSDataSetupConstants.USERNAME, studentUsername6 );
                userDetails6.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                String studentID6 = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails6 ), RBSDataSetupConstants.USERID );

                //Creating new students and adding him in 2 groups from two teachers to make shared student
                studentRumbaIds6.add( studentID6 );

                groupDetails6.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails6.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails6.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                //Getting response
                response6 = addStudentToGroup( smUrl, groupDetails6, studentRumbaIds6, groupIds6 );
                Log.assertThat( response6.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response6.get( Constants.STATUS_CODE ) );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "addStudentToGroup", statusCode, response6.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                verifyResponse( response6.get( Constants.BODY ) );
                break;

            case "ADDING USER TO THE GROUP WITH DUPLICATE NAME":
                HashMap<String, String> groupDetails7 = new HashMap<>();
                HashMap<String, String> userDetails7= new HashMap<>();
                HashMap<String, String> response7 = new HashMap<>();
                List<String> groupIds7 = new ArrayList<>();
                List<String> studentRumbaIds7 = new ArrayList<>();
                List<String> teacherRumbaIds7 = new ArrayList<>();
                List<String> schools7= new ArrayList<>();
                String groupName7= "Successmaker API Test Group " + System.nanoTime();

                groupDetails7.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails7.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails7.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails7.put( CreateGroupAPIConstants.GROUP_NAME, groupName7 );
                createGroup( smUrl, groupDetails7, studentRumbaIds7 );
                groupIds7.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails7, studentRumbaIds7 ).get( Constants.BODY ), "data,groupId" ) );

                String studentUsername7 = "AddStudGRPS1" + System.nanoTime();
                userDetails7.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails7.put( RBSDataSetupConstants.USERNAME, studentUsername7 );
                userDetails7.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails7.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails7.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );
                String studentID7 = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails7 ), RBSDataSetupConstants.USERID );
                studentRumbaIds7.add( studentID7 );

                //Getting response
                response = addStudentToGroup( smUrl, groupDetails7, studentRumbaIds7, groupIds7 );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "addStudentToGroup", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                verifyResponse( response.get( Constants.BODY ) );
                break;

        }

        Log.testCaseResult();

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */

    @DataProvider ( name = "addStudentToGroupPositiveScenariosData" )
    public Object[][] addstudentToGroupData() {

        Object[][] inputData = { { "Verify the api for the valid response code.", "HAPPY_PATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the api by adding students into Group again into mulitple time.", "ADD STUDENT AGAIN", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the api for Single Student with Multiple Groups Id.", "SINGLE_STUDENT_WITH_MULTIPLE_GROUP", CommonAPIConstants.STATUS_CODE_OK }, //Done
                { "Verify the api for multiple students with single Group ID.", "MULTIPLE STUDENTS TO SINGLE GROUP", CommonAPIConstants.STATUS_CODE_OK }, //Done
                { "Verify the API Response for Multi Org Student ID.", "MULTI ORG STUDENT ID", CommonAPIConstants.STATUS_CODE_OK }, //Done
                { "Verify the API Response for Shared student ID.", "SHARED STUDNET GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the API Response when student added to group that is shared with Two teachers.", "SHARED TEACHER GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the API Response when student tried to add in the group that have duplicate name.", "ADDING USER TO THE GROUP WITH DUPLICATE NAME", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the num of group id and student id in the response body should align with the details provided in the payload.", "HAPPY_PATH", CommonAPIConstants.STATUS_CODE_OK },

        };
        return inputData;
    }

    /**
     * To test the negative scenarios of create group API
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( priority = 2, dataProvider = "addStudentToGroupNegativeScenariosData", groups = { "Smoke TC002_AddStudentsToGroup", "Adding Students to Group", "P1", "SMK-51958", "Group", "Adding Students to Group", "P2", "API" } )
    public void tcAddStudentToGroup002( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> userDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        List<String> groupIds = new ArrayList<>();
        String groupName = "Successmaker API Test Group " + System.nanoTime();
        String exception = null;
        boolean status = false;
        String message = null;

        switch ( scenario ) {

            case "EMPTY STUDENTID":

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                //Creating group
                createGroup( smUrl, groupDetails, studentRumbaIds );
                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.BODY ), "data,groupId" ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( "body" ), "data,groupId" ) );
                exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                message = CommonAPIConstants.INVALID_USER_MESSAGE;

                break;

            case "EMPTY GROUPID":
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                exception = CommonAPIConstants.NOTFOUND_EXCEPTION;
                message = CommonAPIConstants.SECTION_ID_NOTFOUND_MESSAGE;
                status = true;
                break;

            case "MISMATCH TEACHER ID":
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

                String testTeacher = "TestTeacher" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, testTeacher );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );

                String testTeacherId = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                new RBSUtils().resetPassword( userDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ), RBSDataSetupConstants.DEFAULT_PASSWORD, testTeacherId );

                groupDetails.put( CreateGroupAPIConstants.INVALID_TEACHER, testTeacherId );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = CommonAPIConstants.MISMATCH_TEACHER_MESSAGE;
                status = true;
                break;

            case "MISMATCH ORGANIZATION ID":
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.INVALID_ORG, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = String.format( CommonAPIConstants.MISMATCH_ORG_MESSAGE, groupDetails.get( CreateGroupAPIConstants.INVALID_ORG ), groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );
                status = true;
                break;

            case "EMPTY STUDENT ID AND GROUPID":

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                exception = CommonAPIConstants.NOTFOUND_EXCEPTION;
                message = CommonAPIConstants.SECTION_ID_NOTFOUND_MESSAGE;
                status = true;
                break;

            case "INVALID ORGANIZATION":

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                //Creating group
                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.BODY ), "data,groupId" ) );

                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), RBSDataSetupConstants.USERID ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student3" ), RBSDataSetupConstants.USERID ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.INVALID_ORG, CreateGroupAPIConstants.INVALID_ORG );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = String.format( CommonAPIConstants.MISMATCH_ORG_MESSAGE, groupDetails.get( CreateGroupAPIConstants.INVALID_ORG ), groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );
                status = true;
                break;

            case "INVALID ACCESS TOKEN":
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), RBSDataSetupConstants.USERID ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student3" ), RBSDataSetupConstants.USERID ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                //Creating group
                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.BODY ), "data,groupId" ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, "ABCD" );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "STUDENT ACCESS TOKEN":
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), RBSDataSetupConstants.USERID ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                exception = CommonAPIConstants.ACCESS_DENIED_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "VALID AND INVALID GROUP ID IN SAME PAYLOAD":

                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), RBSDataSetupConstants.USERID ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student3" ), RBSDataSetupConstants.USERID ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.BODY ), "data,groupId" ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( "body" ), "data,groupId" ) );

                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.BODY ), "data,groupId" ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupIds.add( "" );
                exception = CommonAPIConstants.NOTFOUND_EXCEPTION;
                message = CommonAPIConstants.SECTION_ID_NOTFOUND_MESSAGE;
                status = true;

                break;

            case "VALID AND INVALID STUDENT ID IN SAME PAYLOAD":

                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), RBSDataSetupConstants.USERID ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.BODY ), "data,groupId" ) );

                studentRumbaIds.add( getGroupListAPIConstants.INVALID_STUDENT );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                message = CommonAPIConstants.INVALID_STUDENT_MESSAGE;
                status = true;
                break;

            case "NO SUCCESSMAKER PRODUCT":
                String withoutProductStudent = "noSMProductStudent" + System.nanoTime();
                String withoutProduct = "noSMProductGroup" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, withoutProductStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                String noProdStudent = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                HashMap<String, String> classDetails = new HashMap<>();
                classDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ) );
                classDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                classDetails.put( RBSDataSetupConstants.STAFF_PI_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                classDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, noProdStudent );
                classDetails.put( RBSDataSetupConstants.SECTION_NAME, withoutProduct );
                String noSMProductClassJson = new RBSUtils().createClass( classDetails );
                String noSMProductClassId = new JSONObject( noSMProductClassJson ).getJSONObject( "data" ).getJSONObject( "section" ).get( "id" ).toString();
                groupIds.add( noSMProductClassId );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                exception = CommonAPIConstants.ACCESS_DENIED_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "DELETED STUDENT":
                String deletedStudent = "deletedStudent" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, deletedStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                String deletedStudentId = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.BODY ), "data,groupId" ) );

                studentRumbaIds.add( deletedStudentId );
                new RBSUtils().deleteUser( studentRumbaIds );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                exception = CommonAPIConstants.ACCESS_DENIED_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "DELETED CLASS":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.BODY ), "data,groupId" ) );
                studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), RBSDataSetupConstants.USERID ) );
                new RBSUtils().deleteClass( groupIds.get( 0 ), "", groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ID ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                exception = CommonAPIConstants.NOTFOUND_EXCEPTION;
                message = CommonAPIConstants.SECTION_ID_NOTFOUND_MESSAGE;
                status = true;
                break;

            case "ADDING STUDENT TO THE OTHER ORG GROUP":
                String otherSchoolTeacher = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( otherSchoolTeacher, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( otherSchoolTeacher, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                groupIds.add( SMUtils.getKeyValueFromResponse( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.BODY ), "data,groupId" ) );

                String studentUsername = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsername );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

                String studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                break;
        }

        HashMap<String, String> response = addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "addStudentToGroup", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
        Log.testCaseResult();

    }

    @DataProvider ( name = "addStudentToGroupNegativeScenariosData" )
    public Object[][] addStudentToGroupDataInvalid() {

        Object[][] inputData = {
                //{ "Verify the API Response when deleted user is added to the class.", "DELETED STUDENT", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API for Student Id With Empty group ID.", "EMPTY GROUPID", CommonAPIConstants.STATUS_CODE_NOTFOUND }, { "Veriy the api for the empty Student id with group id", "EMPTY STUDENTID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the api for both group id and Student id is empty", "EMPTY STUDENT ID AND GROUPID", CommonAPIConstants.STATUS_CODE_NOTFOUND },
                { "Verify the API Response for the mismatch teacher_id.", "MISMATCH TEACHER ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API Response for the Invalid Org Id.", "INVALID ORGANIZATION", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API Response for the mismatch Org Id", "MISMATCH ORGANIZATION ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API Response for the invalid access_token", "INVALID ACCESS TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the API Response for the Student's access_token.", "STUDENT ACCESS TOKEN", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                //  { "Verify the API Response when student added to group that do not have successmaker product", "NO SUCCESSMAKER PRODUCT", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API Response when student tried to add in the deleted class.", "DELETED CLASS", CommonAPIConstants.STATUS_CODE_NOTFOUND },
                //{ "Verify the API Response when users added to the other org group ", "ADDING STUDENT TO THE OTHER ORG GROUP", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                // { "Verify the API Response when the other org user is added to group.", "ADDING STUDENT TO THE OTHER ORG GROUP", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the response when valid and invalid group id passed in the same payload.", "VALID AND INVALID GROUP ID IN SAME PAYLOAD", CommonAPIConstants.STATUS_CODE_NOTFOUND },
                { "Verify the response when valid and invalid student id passed in the same payload", "VALID AND INVALID STUDENT ID IN SAME PAYLOAD", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },

        };
        return inputData;
    }

    /**
     * To verify the actual response with CMS data
     * 
     * @param actualResponse
     * @return
     */
    public void verifyResponse( String actualResponse ) {

        JSONObject actualResponseJson = new JSONObject( actualResponse );
        JSONArray groupIds = actualResponseJson.getJSONObject( Constants.DATA ).getJSONArray( RemoveStudentsFromGroupsAPIConstants.GROUP_IDS );

        for ( Object groupId : groupIds ) {
            String groupDetails = new RBSUtils().getClass( groupId.toString() );
            JSONObject cmsResponse = new JSONObject( groupDetails );
            JSONArray studentIdsExpected = cmsResponse.getJSONObject( "roster" ).getJSONArray( RemoveStudentsFromGroupsAPIConstants.STUDENT_IDS );
            JSONArray studentIdsActual = actualResponseJson.getJSONObject( Constants.DATA ).getJSONArray( RemoveStudentsFromGroupsAPIConstants.STUDENT_IDS );
            studentIdsActual.forEach( studentId -> {
                studentIdsExpected.forEach( expectedStudentId -> {
                    if ( expectedStudentId.toString().equalsIgnoreCase( studentId.toString() ) ) {
                        Log.pass( "Student ID: " + studentId.toString() + " added into Group: " + groupId );
                    }
                } );
            } );
        }
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) {
        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

}
