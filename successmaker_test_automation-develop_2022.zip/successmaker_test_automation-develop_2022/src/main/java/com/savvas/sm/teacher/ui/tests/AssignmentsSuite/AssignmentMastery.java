package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

public class AssignmentMastery extends BaseTest {

	private String smUrl;
	private String browser;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private static String username = null;
	private static String password = DataSetupConstants.DEFAULT_PASSWORD;
	private String chromePlatform = "Windows_10_Chrome_latest"; // for Simulator Execution
	private String schoolID;
	private String teacherID;
	private String studentDetailsOne;
	private String studentDetailsTwo;
	private String studentDetailsThree;
	private String studentDetailsFour;
	private String studentDetailsFive;
	private String studentDetailsSix;

	private static String teacherDetails;
	private static String studentOne;
	private static String studentTwo;
	private static String studentThree;
	private static String studentFour;
	private static String studentFive;
	private static String studentSix;
	private HashMap<String, String> groupDetails = new HashMap<>();
	private static List<String> studentRumbaIds = new ArrayList<>();
	private String token = null;

	private String courseName = Constants.CUSTOM_BY_STANDARDS_COURSE + System.nanoTime();
	private String StaticCourseName;
	List<WebElement> masteredProgressBars;

	WebDriver driver;
	TeacherHomePage teacherHomePage;
	LoginPage smLoginPage;

	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		schoolID = RBSDataSetup.organizationIDs.get(school);
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;

		studentDetailsOne = RBSDataSetup.getMyStudent(school, username);
		studentOne = SMUtils.getKeyValueFromResponse(studentDetailsOne, "userName");
		studentDetailsTwo = RBSDataSetup.getMyStudent(school, username);
		studentTwo = SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userName");
		studentDetailsThree = RBSDataSetup.getMyStudent(school, username);
		studentThree = SMUtils.getKeyValueFromResponse(studentDetailsThree, "userName");
		studentDetailsFour = RBSDataSetup.getMyStudent(school, username);
		studentFour = SMUtils.getKeyValueFromResponse(studentDetailsFour, "userName");
		studentDetailsFive = RBSDataSetup.getMyStudent(school, username);
		studentFive = SMUtils.getKeyValueFromResponse(studentDetailsFive, "userName");
		studentDetailsSix = RBSDataSetup.getMyStudent(school, username);
		studentSix = SMUtils.getKeyValueFromResponse(studentDetailsSix, "userName");

		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsThree, "userId"));
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsFour, "userId"));
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsFive, "userId"));
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsSix, "userId"));

		// token creation
		token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(teacherDetails, "userName"),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		// Group
		String groupName = "GroupNo_" + System.nanoTime();
		groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		groupDetails.put(GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetails.put(GroupConstants.GROUP_NAME, groupName);
		String groupId = SMUtils.getKeyValueFromResponse(
				new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds).get(Constants.REPORT_BODY),
				"data,groupId");

		StaticCourseName = DataSetupConstants.SKILL_COURSE_NAME_MATH + System.nanoTime();
		String CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherID, schoolID, DataSetupConstants.SKILL, StaticCourseName );
		HashMap<String, String> assignmentDetails = new HashMap<>();
		HashMap<String, String> response = new HashMap<>();
		assignmentDetails.put( AssignmentAPIConstants.ORG_ID, schoolID );
		assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
		assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
		response = new AssignmentAPI().assignAssignment(smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
	}

	@Test(description = "Verify the zero state message displayed when No students have taken the assignment or they have not been assessed any of the skills in the assignment.", groups = {
			"SMK-43596", "assignments", "assignmentsMastery" }, priority = 1)
	public void tcAssignmentMastery001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tcAssignmentMastery001: Verify the zero state message displayed when No students have taken the assignment or they have not been assessed any of the skills in the assignment. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// navigate to Course Listing Page
			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.copyOfCourse(courseName, Constants.STANDARDS, Constants.MATH);
			coursePage.clickCourseFromTheListing(courseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			SMUtils.logDescriptionTC(
					"SMK-15027 - Verify the zero state message displayed when No students have taken the assignment or they have not been assessed any of the skills in the assignment.");

			// navigate to Assignment page
			AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage
					.viewAssignmentDetailsByAssignmentName(courseName);

			// Navigate to Mastery sub-tab
			assignmentDetailsPage.clickMasteryToggleButton();

			// Verify zero state message for student usage chart
			Log.assertThat(assignmentDetailsPage.verifyMasteryZeroState(),
					"Zero state message is displayed sucessfully for mastery!",
					"Zero state message is displayed sucessfully for mastery!");

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify Mastery tab in assignment details page.", groups = { "SMK-43596", "assignments",
			"assignmentsMastery" }, priority = 1)
	public void tcAssignmentMastery002() throws Exception {

       	// Get driver
		EventFiringWebDriver driver =null;
		
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);

		Log.testCaseInfo("tcAssignmentMastery002: Verify Mastery tab in assignment details page. <small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			// Executing math assignments in student dash-board
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentOne, password);
			StudentDashboardPage studentOneDashboardPage = new StudentDashboardPage(chromeDriver);

			studentOneDashboardPage.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),
					courseName, "100", "1", "30");
			studentOneDashboardPage.logout();
			chromeDriver.quit();

			// Get driver
			driver =  new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

			// Login as Teacher
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// navigate to Assignment page
			AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage
					.viewAssignmentDetailsByAssignmentName(courseName);

			SMUtils.logDescriptionTC(
					"SMK-14981 - Verify the teacher can able to view the mastery tab of that particular assignment.");
			Log.assertThat(assignmentDetailsPage.getMasteryToggleButton().contains(Constants.MASTERY),
					"Mastery tab is present for the viewed assignment",
					"Mastery tab is not present for the viewed assignment");

			SMUtils.logDescriptionTC(
					"SMK-14983 - Verify the teacher can able to click the mastery tab of that particular assignment.");
			SMUtils.logDescriptionTC(
					"SMK-14981 - Verify the teacher can able to navigate to the mastery tab page of that particular assignment.");
			// Navigate to Mastery sub-tab
			assignmentDetailsPage.clickMasteryToggleButton();

			SMUtils.logDescriptionTC(
					"SMK-14986 - Verify the Teacher can view the assignment name on the assignment display page.");
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(courseName),
					"Assignment name is displayed in the assignment details page",
					"Assignment name is not displayed in the assignment details page");

			SMUtils.logDescriptionTC(
					"SMK-14987 - Verify the teacher can able to view the assessed objectives legends ( Mastered, At Risk, Not Mastered, Unassessed ) of that particular assignment.");
			MasterySummaryComponent masteryComponent = new MasterySummaryComponent(driver);
			Log.assertThat(masteryComponent.getAssessedObjectivesHeaders(), "Assessed objectives are present",
					"Assessed objectives are not present");

			SMUtils.logDescriptionTC(
					"SMK-14992 - Verify the grade is displayed under mastery tab in the assignment page.");
			Log.assertThat(masteryComponent.verifyGradeIsDisplayed(),
					"Grade is displayed under mastery tab in the assignment page",
					"Grade is not displayed under mastery tab in the assignment page");

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the count of students assessed for the corresponding LO under mastery tab of that particular assignment.", groups = {
			"SMK-43596", "assignments", "assignmentsMastery" }, priority = 1)
	public void tcAssignmentMastery003() throws Exception {

		// Get driver
		EventFiringWebDriver driver =null;

		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);

		Log.testCaseInfo(
				"tcAssignmentMastery003: Verify the count of students assessed for the corresponding LO under mastery tab of that particular assignment. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			// Executing math assignments in student dash-board
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentTwo, password);
			StudentDashboardPage studentOneDashboardPage = new StudentDashboardPage(chromeDriver);

			studentOneDashboardPage.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),
					courseName, "100", "1", "30");
			studentOneDashboardPage.logout();
			chromeDriver.quit();

			// Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);
			// Login as Teacher
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// navigate to Assignment page
			AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage
					.viewAssignmentDetailsByAssignmentName(courseName);

			SMUtils.logDescriptionTC(
					"SMK-15001 Verify the teacher is able to see the count of students assessed for the corresponding LO under mastery tab of that particular assignment");
			SMUtils.logDescriptionTC(
					"SMK-15002 Verify the text displayed as #Student Assessments above the progress bar if more than one student has taken assessment corresponding to the LO only");

			// Navigate to Mastery sub-tab
			assignmentDetailsPage.clickMasteryToggleButton();
			MasterySummaryComponent masteryComponent = new MasterySummaryComponent(driver);

			SMUtils.logDescriptionTC(
					"SMK-15005 Verify the teacher able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only");

			Log.assertThat(
					masteryComponent.getStudentAssessmentOfLeafNodeLO().stream()
							.allMatch(studentCount -> !studentCount.isEmpty()),
					"The teacher is able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only",
					"The teacher is not able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO");

			SMUtils.logDescriptionTC(
					"SMK-15004 Verify the text displayed as Numbers Student Assessments above the progress bar if more than one student has taken assessment corresponding to the LO only");
			String singleStudentAssessCount = Constants.MasteryUI.STUDENT_ASSESSMENT_COUNT
					.replace(Constants.STUDENTS_COUNT, "1");
			String multiStudentAssessCount = Constants.MasteryUI.STUDENT_ASSESSMENT_COUNT
					.replace(Constants.STUDENTS_COUNT, "2");

			Log.assertThat(
					masteryComponent.getStudentAssessmentOfLeafNodeLO().stream().allMatch(
							list -> list.contains(singleStudentAssessCount) || list.contains(multiStudentAssessCount)),
					"Student assessed count is displayed if one or more student has taken an assessment",
					"Student assessed count is not displayed if one or more student has taken an assessment");

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Skills/Standards dropdown functionality", groups = { "SMK-43596", "assignments",
			"assignmentsMastery" }, priority = 1)
	public void tcAssignmentMastery004() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tcAssignmentMastery004: Verify Skills/Standards dropdown functionality. <small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// navigate to Assignment page
			AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
			SMUtils.nap(5);
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage
					.viewAssignmentDetailsByAssignmentName(courseName);

			// Navigate to Mastery sub-tab
			assignmentDetailsPage.clickMasteryToggleButton();
			MasterySummaryComponent masteryComponent = new MasterySummaryComponent(driver);
			MasteryFiltersComponent masteryPage = new MasteryFiltersComponent(driver);

			SMUtils.logDescriptionTC("SMK-15031 Verify the skills/standard dropdown is present under assignment details page");
			Log.assertThat(masteryPage.isSkillsStandardsDropdownPresent(),
					"Skills/Standards dropdown is present under assignment details page",
					"Skills/Standards dropdown is not present under assignment details page");

			SMUtils.logDescriptionTC(
					"SMK-15030 Verify teacher able to see Skills/Standards dropdown options clearly (without overlap or data missing)");
		    System.out.println("List is : " + masteryPage.getAllSkillStandardsDropDownValues().stream().map(String::toLowerCase)
							.collect(Collectors.toList()));
			Log.assertThat(
					masteryPage.getAllSkillStandardsDropDownValues().stream().map(String::toLowerCase)
							.collect(Collectors.toList())
							.containsAll(Constants.MATH_SKILLS_DROPDOWN_LIST.stream().map(String::toLowerCase)
									.collect(Collectors.toList())),
					"All skills are present in Skills/Standards dropdown",
					"All skills are not present in Skills/Standards dropdown");

			SMUtils.logDescriptionTC(
					"SMK-15034 Verify the details displayed based on the skills/standard dropdown selection in the assignment details page is matching with the details present under primary mastery tab for the same selection");
			List<String> contentsInAssignmentPage = masteryComponent.getLeafNodeContent();

			// Navigate to Mastery page
			teacherHomePage.topNavBar.navigateToMasteryTab();

			masteryPage.applyFilter();
			List<String> contentsInmasteryPage = masteryComponent.getLeafNodeContent();

			SMUtils.logDescriptionTC(
					"SMK-15028 Verify the mastery breakdown details present in mastery summary page for the particular assignment navigated through courseware tab is identical with the view of the mastery summary page navigated through primary mastery tab for the same partiuclar assignment");
			Log.assertThat(contentsInAssignmentPage.containsAll(contentsInmasteryPage),
					"The details displayed based on the skills/standard dropdown selection in the assignment details page is matching with the details present under primary mastery tab for the same selection",
					"The details displayed based on the skills/standard dropdown selection in the assignment details page is not matching with the details present under primary mastery tab for the same selection");

			SMUtils.logDescriptionTC(
					"SMK-15032 Verify the skills/standard dropdown can be modified in the assignment details page");
			SMUtils.logDescriptionTC(
					"SMK-15033 Verify the correct details is displayed based on the skills/standard dropdown selection in the assignment details page");

			teacherHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentPage.viewAssignmentDetailsByAssignmentName(courseName);
			assignmentDetailsPage.clickMasteryToggleButton();

			masteryPage.selectSkillStandards(Constants.MATH_SKILLS_DROPDOWN_LIST.get(1));
			Log.assertThat(
					masteryPage.getSelectedValueFromSkillStandardsDropDown()
							.equalsIgnoreCase(Constants.MATH_SKILLS_DROPDOWN_LIST.get(1)),
					"Selected Skills/Standards name is displayed in Skills/Standards dropdown",
					"Selected Skills/Standards name is not displayed in Skills/Standards dropdown");

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the functionality of LO in mastery tab of assignment detail page", groups = {
			"SMK-43596", "assignments", "assignmentsMastery" }, priority = 1)
	public void tcAssignmentMastery005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


		Log.testCaseInfo(
				"tcAssignmentMastery005: Verify the functionality of LO in mastery tab of assignment detail page. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// navigate to Assignment page
			AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage
					.viewAssignmentDetailsByAssignmentName(courseName);

			// Navigate to Mastery sub-tab
			assignmentDetailsPage.clickMasteryToggleButton();
			MasterySummaryComponent masteryComponent = new MasterySummaryComponent(driver);

			SMUtils.logDescriptionTC(
					"SMK-14999 Verify the teacher is able to see the LO as a blue link for math related assignments under mastery tab of the assignments page");
			Log.assertThat(masteryComponent.verifyLOColor(browser), "Teacher is able to see the LO as a blue link",
					"Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills");

			SMUtils.logDescriptionTC(
					"SMK-15000 Verify the teacher is able to see the LO description corrsponding to the LO id for math related assignments under mastery tab of that particular assignment");
			Log.assertThat(
					masteryComponent.getLeafNodeContent().stream().allMatch(loDescription -> !loDescription.isEmpty()),
					"LO description is displayed for math related assignments ",
					"LO description is not displayed for math related assignments ");

			SMUtils.logDescriptionTC(
					"SMK-14998 Verify the skill heading is displayed under domain and cluster in mastery tab of the assignment page");
			Log.assertThat(masteryComponent.verifySkillHeadingIsDisplayed(),
					"Skill heading is displayed under domain and cluster in mastery tab of the assignment page",
					"Skill heading is not displayed under domain and cluster in mastery tab of the assignment page");

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Mastery status colour indicator order in the progress bar", groups = { "SMK-43596",
			"Assignments", "AssignmentsMastery" }, priority = 3)
	public void tcAssignmentMastery006() throws Exception {
		EventFiringWebDriver driver = null;
		EventFiringWebDriver chromeDriver;
		
		Log.testCaseInfo(
				"tcAssignmentMastery006: Verify Mastery status colour indicator order in the progress bar. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			// Login as student1 to the executeCourses
			Log.message("Executing the courses using simulator for student1");
			chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
			EventListener eventListner = new EventListener();
			chromeDriver.register(eventListner);
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentOne, password);
			StudentDashboardPage studentOneDashboardPage = new StudentDashboardPage(chromeDriver);

			studentOneDashboardPage.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),
					StaticCourseName, "100", "2", "15");
			studentOneDashboardPage.logout();
			chromeDriver.quit();

			// Login as student2 to the executeCourses
			Log.message("Executing the courses using simulator for student2");
			chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
			eventListner = new EventListener();
			chromeDriver.register(eventListner);
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentTwo, password);
			StudentDashboardPage studentOneDashboardPage2 = new StudentDashboardPage(chromeDriver);

			studentOneDashboardPage2.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),
					StaticCourseName, "25", "3", "10");
			studentOneDashboardPage2.logout();
			chromeDriver.quit();

			// Login as student3 to the executeCourses
			Log.message("Executing the courses using simulator for student3");
			chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
			eventListner = new EventListener();
			chromeDriver.register(eventListner);
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentThree,
					password);
			StudentDashboardPage studentOneDashboardPage3 = new StudentDashboardPage(chromeDriver);

			studentOneDashboardPage3.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),
					StaticCourseName, "20", "8", "10");
			studentOneDashboardPage3.logout();
			chromeDriver.quit();

			// Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);
			// Login as Teacher
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// navigate to Assignment page
			AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName(StaticCourseName);

			// Navigate to Mastery sub-tab
			assignmentDetailsPage.clickMasteryToggleButton();
			MasterySummaryComponent masteryComponent = new MasterySummaryComponent(driver);

			SMUtils.logDescriptionTC("Verify the progress bar, 'Mastered' status is indicated by Green color");
			Log.assertThat(
					masteryComponent.getStatusColor(browser)
							.contains(Constants.MasteryUI.MASTERED_COLOR_CODE.toLowerCase()),
					"Mastered status is indicated by Green color in the progress bar ",
					"Mastered status is not indicated by Green color in the progress bar ");

			SMUtils.logDescriptionTC("Verify the progress bar, 'At Risk' status is indicated by Yellow color");
			System.out.println("At risk color : "+ masteryComponent.getStatusColor(browser));
			Log.assertThat(
					masteryComponent.getStatusColor(browser)
							.contains(Constants.MasteryUI.ATRISK_COLOR_CODE.toLowerCase()),
					"At Risk status is indicated by Yellow color in the progress bar ",
					"At Risk status is not indicated by Yellow color in the progress bar ");

			SMUtils.logDescriptionTC(
					"Verify the progress bar, total number of students 'Mastered'/Not Mastered/At Risk with respect to that skill is displaying inside Green/Yellow/red colour.");
			Log.assertThat(
					masteryComponent.getStudentAssessmentOfLeafNodeLO()
							.containsAll(masteryComponent.getStudentAssessmentCount()),
					"Total number of student assessment is displayed in progress bar",
					"Total number of student assessment is not displayed in progress bar");

			// signOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify total number of the students assessement taken is equal to the sum of 'Mastered', 'At Risk' and 'Not Mastered' students ", groups = {
			"SMK-43596", "Assignments", "Mastery" }, priority = 3)
	public void tcAssignmentMastery007() throws Exception {
		EventFiringWebDriver driver = null;
		EventFiringWebDriver chromeDriver;
		Log.testCaseInfo(
				"tcAssignmentMastery007: Verify total number of the students assessement taken is equal to the sum of 'Mastered', 'At Risk' and 'Not Mastered' students <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			// Login as student4 to the executeCourses
			Log.message("Executing the courses using simulator for student4");
			chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
			EventListener eventListner = new EventListener();
			chromeDriver.register(eventListner);
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentFour, password);
			StudentDashboardPage studentOneDashboardPage4 = new StudentDashboardPage(chromeDriver);
			SMUtils.nap(10);
			studentOneDashboardPage4.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),
					StaticCourseName, "100", "2", "15");
			studentOneDashboardPage4.logout();
			chromeDriver.quit();

			// Login as student5 to the executeCourses
			Log.message("Executing the courses using simulator for student5");
			chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
			eventListner = new EventListener();
			chromeDriver.register(eventListner);
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentFive, password);
			StudentDashboardPage studentOneDashboardPage5 = new StudentDashboardPage(chromeDriver);

			studentOneDashboardPage5.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),
					StaticCourseName, "25", "3", "10");
			studentOneDashboardPage5.logout();
			chromeDriver.quit();

			// Login as student6 to the executeCourses
			Log.message("Executing the courses using simulator for student6");
			chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
			eventListner = new EventListener();
			chromeDriver.register(eventListner);
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsStudent(chromeDriver, smUrl, UserType.BASIC, null, studentSix, password);
			StudentDashboardPage studentOneDashboardPage6 = new StudentDashboardPage(chromeDriver);

			studentOneDashboardPage6.executeMathCourse(SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"),
					StaticCourseName, "20", "8", "10");
			studentOneDashboardPage6.logout();
			chromeDriver.quit();
			// Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);
			// Login as Teacher
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// navigate to Assignment page
			AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName(StaticCourseName);

			// Navigate to Mastery sub-tab
			assignmentDetailsPage.clickMasteryToggleButton();
			MasterySummaryComponent masteryComponent = new MasterySummaryComponent(driver);
			masteredProgressBars = masteryComponent.getProgressBarLink(Constants.MasteryUI.MASTERED);

			SMUtils.nap(3);
			List<String> studentAssement = masteryComponent.getStudentAssessmentOfLeafNodeLO();
			List<String> listassesmentcount = masteryComponent.getStudentAssessmentCount();

			Log.assertThat(studentAssement.equals(listassesmentcount),
					"The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar ",
					" The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is not matching with TOTAL count of students have taken assessment displayed above the progress bar");
			// Sign Out
			// signOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

}