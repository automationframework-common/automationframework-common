package com.savvas.sm.teacher.ui.tests.StudentSuite;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class AddStudentsToGroupsPopup extends BaseTest {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherDetails;

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "Verify the Add students to group link and popup in zero state", groups = { "Students", "SMK-42998" }, priority = 1 )
    public void tcAddStuToGroupZeroState001( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the Add students to group link and popup in zero state. <small><b><i>[" + browser + "]</b></i></small>" );
        String studentDetails = RBSDataSetup.getMyStudent( school, username );
        String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        Log.message( "studentID: " + studentID );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Groups tab

            SMUtils.logDescriptionTC( "Verify that the zero state screen with proper message is displayed, when the student is already added to all the groups." );
            SMUtils.logDescriptionTC( "Verify the group is not displayed in the list, when the student is already added in the group." );
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            Log.assertThat( studentsPage.verifyAddStudentLinkinZeroState(), "Add Students to Group link is displayed successfully", "Add Students to Group link is not displayed" );

            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            SMUtils.logDescriptionTC( "SMK-10227 : Verify the \"Delete\" button color in Delete Group popup for teacher user" );
            groupsTab.deleteAllGroup( groupsTab );
            // Navigate to Students tab
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            SMUtils.logDescriptionTC( "SMK-10082 : Verify that Add Student to group(s) link is displayed, when teacher does not contain any students" );
            Log.assertThat( studentsPage.verifyAddStudentLinkinZeroState(), "Add Students to Group link is displayed successfully", "Add Students to Group link is not displayed" );
            SMUtils.logDescriptionTC( "SMK-10083 : Verify that clicking on Add Student to group(s) link, is opening the Add Student to group(s) popup" );
            studentsPage.clickAddStudentinZeroState();
            Log.assertThat( studentsPage.verifyZeroStateMsgInAddStuToGroup(), "Zero state message is verified successfully", "Zero state message is not displayed" );
            // perform signout action
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}