package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

public class AssignMultipleAssignments extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String teacherUsername;
    private String CourseId;
    private String assignmentID;
    private String AssignmentUserId;
    List<String> studentRumbaIds = new ArrayList<>();
    RBSUtils rbsutils = new RBSUtils();

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest()  {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(school , teacherUsername), Constants.USERID_HEADER) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(school , teacherUsername), Constants.USERID_HEADER) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(school , teacherUsername), Constants.USERID_HEADER) );
        
    }

    @Test ( priority = 1, dataProvider = "AssignMutipleStudentFlow", groups = { "SMK-51909", "smoke_test_case", "AssignMultipleAssignments", "P1", "API" } )
    public void tcAssignStudents001( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> requestIds = new ArrayList<>();
        List<String> courseIDs = new ArrayList<>();

        HashMap<String, String> groupDetails = new HashMap<>();
        String endpoint = "null";

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );       
        
        HashMap<String, String> response = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( "body" ), "data,groupId" );

        switch ( scenario ) {

            case "Default MATH":

                courseIDs.add( AssignmentAPIConstants.MATH );

                break;

            case "Default READING":
                courseIDs.add( AssignmentAPIConstants.READING );

                break;

            case "Default FOCUS READING":

                courseIDs.add( AssignmentAPIConstants.FOCUS_READING );

                break;

            case "Default FOCUS MATH":
                courseIDs.add( AssignmentAPIConstants.FOCUS_MATH );

                break;

            case "CUSTOM SETTINGS MATH":
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

                courseIDs.add( CourseId );

                break;

            case "CUSTOM SKILL MATH":
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );

                courseIDs.add( CourseId );

                break;

            case "CUSTOM STANDARD MATH":
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );

                courseIDs.add( CourseId );

                break;

            case "CUSTOM SETTINGS READING":
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                courseIDs.add( CourseId );

                break;

            case "CUSTOM SKILL READING":
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                courseIDs.add( CourseId );

                break;

            case "CUSTOM STANDARD READING":
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                courseIDs.add( CourseId );

                break;

            case "Assign All courses":

                courseIDs.add( AssignmentAPIConstants.READING );
                courseIDs.add( AssignmentAPIConstants.FOCUS_READING );
                courseIDs.add(
                        new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) ) );
                courseIDs.add( new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) ) );
                courseIDs.add(
                        new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) ) );

                courseIDs.add( AssignmentAPIConstants.MATH );
                courseIDs.add( AssignmentAPIConstants.FOCUS_MATH );
                courseIDs.add( new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) ) );
                courseIDs.add( new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) ) );
                courseIDs.add( new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) ) );
                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }

        response = assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );

        Log.message( "response: " + response );

        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "AssignMultipleAssignmentsSchema", CommonAPIConstants.STATUS_CODE_OK, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
        String assignmentId = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );

        List<String> assignDetails = SqlHelperAssignment.getAssignmentDetails( assignmentId );
        Log.assertThat( !assignDetails.isEmpty(), "Assignment Details Present in DB", "Assignment Details not Present in DB" );

    }

    @Test ( priority = 2, dataProvider = "AssignAssignmentsNegativeFlow", groups = { "SMK-51909", "AssignMultipleAssignments", "AssignMultipleAssignments", "P1", "API" } )
    public void tcAssignStudents002( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        String endpoint = "null";
        List<String> studentRumbaIds = new ArrayList<>();
        String message = null;
        String exception = null;
        List<String> requestIds = new ArrayList<>();
        List<String> courseIDs = new ArrayList<>();

        boolean status = false;
        HashMap<String, String> response = new HashMap<>();

        HashMap<String, String> groupDetails = new HashMap<>();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), "userId" ) );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( "body" ), "data,groupId" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        switch ( scenario ) {

            case "Invalid OrgId in Headers":
                courseIDs.add( AssignmentAPIConstants.MATH );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, CommonAPIConstants.INVALID_ORG_ID );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "Empty OrgId in Headers":
                courseIDs.add( AssignmentAPIConstants.MATH );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, " " );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "Empty staffId in Headers":
                courseIDs.add( AssignmentAPIConstants.MATH );

                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, " " );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "InValid bearer token in Headers":
                courseIDs.add( AssignmentAPIConstants.MATH );

                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "Invalid staffId in Headers":
                courseIDs.add( AssignmentAPIConstants.MATH );

                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, "12345678" );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            case "Invalid CourseID":
                courseIDs.add( "ZZZ" );

                exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
                message = null;
                status = true;
                break;

            case "InValid StudentID":
                courseIDs.add( AssignmentAPIConstants.MATH );
                studentRumbaIds.add( "rtrtr335" );
                exception = AssignmentAPIConstants.BUSINESS_VIOLATION_EXCEPTION;
                message = null;
                status = true;
                break;

            default:
                Log.message( "Case is invalid" );
                break;

        }
        HashMap<String, String> getresponse = assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );

        Log.message( getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
        if ( message != null ) {
            verifyException( getresponse.get( "body" ), exception, status, message );
        }

        Log.testCaseResult();

    }

    /**
     * Data provider to give the positive data
     * 
     * @return
     */
    @DataProvider ( name = "AssignMutipleStudentFlow" )
    public Object[][] AssignMutipleStudentFlow() {

        Object[][] inputData = {

                { "Verify the valid response to assign multiple assignments to multiple students API for Default Math", "Default MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to assign multiple assignments to multiple students API for Default Reading", "Default READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to assign multiple assignments to multiple students API for Focus Reading", "Default FOCUS READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to assign multiple assignments to multiple students API for Focus Math", "Default FOCUS MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to assign multiple assignments to multiple students API for Custom Settings Math", "CUSTOM SETTINGS MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to assign multiple assignments to multiple students API for Custom Skill Math", "CUSTOM SKILL MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to assign multiple assignments to multiple students API for Custom Standards Math", "CUSTOM STANDARD MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to assign multiple assignments to multiple students API for Custom Settings Reading", "CUSTOM SETTINGS READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to assign multiple assignments to multiple students API for Custom Skill Reading", "CUSTOM SKILL READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to assign multiple assignments to multiple students API for Custom Standards Reading", "CUSTOM STANDARD READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to assign multiple assignments to multiple students API for all the courses", "Assign All courses", CommonAPIConstants.STATUS_CODE_OK },

        };

        return inputData;
    }

    /**
     * Data provider to give the Negative data
     * 
     * @return
     */
    @DataProvider ( name = "AssignAssignmentsNegativeFlow" )
    public Object[][] AssignAssignmentsNegativeFlow() {

        Object[][] inputData = { { "Verify the status code and response for invalid OrgId in Headers", "Invalid OrgId in Headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code and response for Empty OrgId in Headers", "Empty OrgId in Headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code and response for Empty StaffId in Headers", "Empty staffId in Headers", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code and response for invalid staffId in Headers", "Invalid staffId in Headers", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code and response for inValid bearer token  in Header", "InValid bearer token in Headers", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code and response for invalid Assignmentuserid", "Invalid CourseID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the status code and response for Empty Assignmentuserid", "InValid StudentID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },

        };
        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

}