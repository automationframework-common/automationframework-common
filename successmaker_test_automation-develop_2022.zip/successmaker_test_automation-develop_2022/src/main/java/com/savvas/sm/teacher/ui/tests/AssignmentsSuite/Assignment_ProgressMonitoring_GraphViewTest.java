package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners(EmailReport.class)
public class Assignment_ProgressMonitoring_GraphViewTest extends BaseTest {
	private String smUrl;
	private String browser;
	private static String username = null;
	private static String password = DataSetupConstants.DEFAULT_PASSWORD;
	String teacherDetails;
	String studentDetails;
	private String teacherID;
	String staticCourseName = null;
	TeacherHomePage teacherHomePage;
	LoginPage smLoginPage;
	String studentDetailsSecond;
	String studentSMDetails;
	String studentSMDetailsSecond;
	String studentFirstName;
	String studentMiddleName;
	String studentLastName;
	String studentUsername;
	String schoolID;
	private String orgId;
	private String token = null;
	private HashMap<String, String> groupDetails = new HashMap<>();
	private static List<String> studentRumbaIds = new ArrayList<>();
	private static HashMap<String, String> mathAssignmentDetails = new HashMap<>();
	AssignmentAPI assign = new AssignmentAPI();
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	String Custom_Skills_Math = Constants.CUSTOM_BY_SKILLS_MATH_COURSE + System.nanoTime();
	String Custom_Standards_Math = Constants.CUSTOM_BY_STANDARDS_MATH_COURSE + System.nanoTime();
	String Custom_Settings_Reading = Constants.CUSTOM_READING_ASSIGMENT_TITLE + System.nanoTime();

	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		orgId = RBSDataSetup.organizationIDs.get( school );
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		schoolID = RBSDataSetup.organizationIDs.get(school);
		
		studentDetails = RBSDataSetup.getMyStudent(school, username);
		studentDetailsSecond = RBSDataSetup.getMyStudent(school, username);
		
		studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, "userName");
		studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
		studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ) );
		
		token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(teacherDetails, "userName"),
				RBSDataSetupConstants.DEFAULT_PASSWORD);
		// Student SM Details
		studentFirstName = SMUtils.getKeyValueFromResponse(studentDetails, "firstName");
		studentMiddleName = SMUtils.getKeyValueFromResponse(studentDetails, "middleName");
		studentLastName = SMUtils.getKeyValueFromResponse(studentDetails, "lastName");
		
		// token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Log.message( "Teacher access token: " + token );
        
     // Getting group details
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherID );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId);
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" + System.nanoTime() );
        // Creating a group
        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        
        // Assigning Math assignment
        mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
        mathAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        HashMap<String, String> mathRssignmentResponse = assign.assignMultipleAssignments( smUrl, mathAssignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );
        Log.message( mathRssignmentResponse.toString() );
		
		executeSimulator( studentUsername, Constants.MATH, Constants.MATH );

	}

	@Test(description = "Verify if teacher is able to see Student's progress in a graphical view for a particular assignment", groups = {
			"Assignments", "SMK-45587", "Progress_Monitoring_Graph" }, priority = 1)
	public void tcAssignmentProgressMonitoringGraph001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data
		Log.testCaseInfo(
				"tcAssignmentProgressMonitoringGraph001: SMK-13900: Verify if teacher is able to see Student's progress in a graphical view for a particular assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// create Reading custom course by settings
			coursePage.createCustomBySettingCourseWithIPOff(Custom_Settings_Reading, Constants.READING);

			// Assigning Course to student
			coursePage.clickCourseName(Custom_Settings_Reading);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			// SignOut
			tHomePage.topNavBar.signOutfromSM();

			// Get driver
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);
			
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUsername, password);

			StudentDashboardPage stuPage = new StudentDashboardPage(studentDriver);
			// Course Execution
			IntStream.rangeClosed(1, 4).forEach(value -> {
				Log.message("Reading Custom Course Execution");
				try {
					stuPage.executeReadingCourse(teacherID, Custom_Settings_Reading, "95", "2", "25");
				} catch (IOException e) {
					Log.message("Error occurred while running the simulator");
				}

			});
			// Logout
			SMUtils.nap(10);
			stuPage.logout();
			studentDriver.quit();

			// Navigate to teacher page again
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);
			
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");
			// Navigate to Courseware tab
			SMUtils.nap(10);
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Custom_Settings_Reading);
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			String studentName = assignmentDetailsPage.getStudentName(SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));
			assignmentDetailsPage.clickStudentAccordionButton(studentName);
			Log.assertThat(assignmentDetailsPage.isProgressMonitoringGraphDisplayed(),"Progress Monitoring Graph Displayed Successfuly", "Progress Monitoring Graph Not Displayed");
			SMUtils.logDescriptionTC("SMK-13901: Verify if the all the Legend details are displayed to the right side of the graph<small><b><i>["+ browser + "]</b></i></small>");
			Log.assertThat(assignmentDetailsPage.isLegendsDisplayed(), "Legends Displayed Successfuly","Legends Not Displayed");
			SMUtils.logDescriptionTC("SMK-13910: Verify if teacher is able to see Primary Target<small><b><i>["+ browser + "]</b></i></small>");
			Log.assertThat(assignmentDetailsPage.checkLegendNames(Constants.PRIMARY_TARGET),"Primary Target Displayed Successfuly", "Primary Target Not Displayed");
			SMUtils.logDescriptionTC("SMK-13911: Verify if teacher is able to see Secondary Target<small><b><i>["+ browser + "]</b></i></small>");
			Log.assertThat(assignmentDetailsPage.checkLegendNames(Constants.SECONDARY_TARGET),"Secondary Target Displayed Successfuly", "Secondary Target Not Displayed");
			// Sign Out
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify if the graph shows X axis and Y axis values correctly", groups = { "Assignments",
			"SMK-45587", "Progress_Monitoring_Graph" }, priority = 1)
	public void tcAssignmentProgressMonitoringGraph002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tcAssignmentProgressMonitoringGraph002: Verify if the graph shows X axis and Y axis values correctly<small><b><i>["
						+ browser + "]</b></i></small>");
		SMUtils.logDescriptionTC("SMK-13903: Verify if Progress Graph shows Dates in X-axis");
		SMUtils.logDescriptionTC("SMK-13902: Verify if Progress Graph shows course level in Y-axis");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Custom_Settings_Reading);
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			String studentName = assignmentDetailsPage.getStudentName(SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));
			assignmentDetailsPage.clickStudentAccordionButton(studentName);
			assignmentDetailsPage.scrollInToExpandedStudent();

			// Validating the X axis date in UI
			Log.assertThat(assignmentDetailsPage.getXAxisDateOnUI(), "X Axis is displaying dates correctly","X Axis is not displayed correctly");
			Log.assertThat(assignmentDetailsPage.verifyXAxisValue().contains(Constants.X_AXIS_VALUE),"X Axis is displayed correctly", "X Axis is not displayed correctly");

			// Validating the Y axis value in UI
			Log.assertThat(assignmentDetailsPage.verifyYAxisValue().equals(Constants.Y_AXIS_VALUE),"Y axis is displayed correctly ", "Y axis is not displayed correctly ");
			Log.assertThat(assignmentDetailsPage.isYAxisFirstSameAsAssigned(), "Y axis values are displayed correctly ",	"Y axis values are not displayed correctly ");

			// Sign Out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify if the zero state screen is displayed when a Custom By Skill/Custom By Standard, or Focus courseware is assigned to student", groups = {
			"Assignments", "SMK-45587", "Progress_Monitoring_Graph" }, priority = 2)
	public void tcAssignmentProgressMonitoringGraph003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentProgressMonitoringGraph003: SMK-13917: Verify if the zero state screen is displayed when a Custom By Skill/Custom By Standard, or Focus courseware is assigned to student<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// create Math custom course by Skills
			coursePage.clickMathCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(Custom_Skills_Math);
			coursePage.coursesRadioBtn(Constants.SKILLS, Constants.CUSTOM_BY_SKILLS_MATH_COURSE);
			coursePage.courseBasedOnSkills(Constants.SKILLS, Constants.MATH);

			// Assigning Course to student
			coursePage.clickCourseName(Custom_Skills_Math);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Get Student Page
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
			SMUtils.nap(10);
			Map<String, List<String>> studentDetailsFromStudentTab = studentsPage.getColumnDetailsAsList();
			List<String> studenListFromStudentTab = new ArrayList<>();
			for (int studentValue = 0; studentValue < studentDetailsFromStudentTab.get(Constants.FIRSTNAME).size(); studentValue++) {
				String studentFN = studentDetailsFromStudentTab.get(Constants.FIRSTNAME).get(studentValue);
				String studentLN = studentDetailsFromStudentTab.get(Constants.LASTNAME).get(studentValue);
				studenListFromStudentTab.add(coursePage.completeStudentName(studentFN, "", studentLN));
			}
			String[] FNLN = studenListFromStudentTab.get(0).split(" ");
			String studentFNLN = FNLN[0].concat(FNLN[1]);
			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// create Math custom course by Standards
			coursePage.clickMathCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(Custom_Standards_Math);
			coursePage.coursesRadioBtn(Constants.STANDARDS, Constants.CUSTOM_BY_STANDARDS_MATH_COURSE);
			coursePage.courseBasedOnDefaultOrFocusMathStandards(Constants.STANDARDS, Constants.MATH);

			// Assigning Course to student
			coursePage.clickCourseName(Custom_Standards_Math);
			coursePage.clickAssignBtn();
			coursePage.addCourseToOneStudent(studentFNLN);
			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// Assigning Focus Course to student
			coursePage.clickCourseName(Constants.READING_FOCUS_COURSE_TITLE);
			coursePage.clickAssignBtn();
			coursePage.addCourseToOneStudent(studentFNLN);
			// SignOut
			tHomePage.topNavBar.signOutfromSM();
			driver.quit();

			// Get driver
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUsername,
					password);
			StudentDashboardPage stuPage = new StudentDashboardPage(studentDriver);
			// Course Execution
			IntStream.rangeClosed(1, 2).forEach(value -> {
				Log.message("Math Custom Course By Skills Execution");
				try {
					stuPage.executeMathCourse(teacherID, Custom_Skills_Math, "100", "2", "25");
				} catch (IOException e) {
					Log.message("Error occurred while running the simulator");

				}

			});

			// Course Execution
			IntStream.rangeClosed(1, 2).forEach(value -> {
				Log.message("Math Custom Course By Standards Execution");
				try {
					stuPage.executeMathCourse(teacherID, Custom_Standards_Math, "95", "2", "25");
				} catch (IOException e) {
					Log.message("Error occurred while running the simulator");

				}

			});

			// Course Execution
			IntStream.rangeClosed(1, 2).forEach(value -> {
				Log.message("Reading Focus Course Execution");
				try {
					stuPage.executeReadingCourse(teacherID, Constants.READING_FOCUS_COURSE_TITLE, "100", "2", "25");
				} catch (IOException e) {
					Log.message("Error occurred while running the simulator");

				}

			});
			// Logout
			stuPage.logout();
			studentDriver.quit();
			// Navigate to teacher page again
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(Custom_Skills_Math);
			String studentName = assignmentDetailsPage.getStudentName(SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));
			assignmentDetailsPage.clickStudentAccordionButton(studentName);
			Log.assertThat(assignmentDetailsPage.getZeroStateTextFromProgressGraph().equals(Constants.NO_DATA_MESSAGE),
					"Zero State Message Displayed Successfuly for Custom By Skills Course",
					"Zero State Message Not Displayed");

			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			page.viewAssignmentDetailsByAssignmentName(Custom_Standards_Math);
			assignmentDetailsPage.clickStudentAccordionButton(studentName);
			Log.assertThat(assignmentDetailsPage.getZeroStateTextFromProgressGraph().equals(Constants.NO_DATA_MESSAGE),
					"Zero State Message Displayed Successfuly for Custom By Standards Course",
					"Zero State Message Not Displayed");

			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			page.viewAssignmentDetailsByAssignmentName(Constants.READING_FOCUS_COURSE_TITLE);
			assignmentDetailsPage.clickStudentAccordionButton(studentName);
			Log.assertThat(assignmentDetailsPage.getZeroStateTextFromProgressGraph().equals(Constants.NO_DATA_MESSAGE),
					"Zero State Message Displayed Successfuly for Focus Course", "Zero State Message Not Displayed");
			// Sign Out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify if the zero state screen is displayed when student's IP level is in In IP or --", groups = {
			"Assignments", "SMK-45587", "Progress_Monitoring_Graph" }, priority = 2)
	public void tcAssignmentProgressMonitoringGraph004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentProgressMonitoringGraph004: SMK-13918: Verify if the zero state screen is displayed when student's IP level is in In IP or --<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// Selecting Math Course and assigning to student
			coursePage.clickMathCourse();
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Get Student Page
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
			SMUtils.nap(10);
			Map<String, List<String>> studentDetailsFromStudentTab = studentsPage.getColumnDetailsAsList();
			List<String> studenListFromStudentTab = new ArrayList<>();
			for (int studentValue = 0; studentValue < studentDetailsFromStudentTab.get(Constants.FIRSTNAME).size(); studentValue++) {
				String studentFN = studentDetailsFromStudentTab.get(Constants.FIRSTNAME).get(studentValue);
				String studentLN = studentDetailsFromStudentTab.get(Constants.LASTNAME).get(studentValue);
				studenListFromStudentTab.add(coursePage.completeStudentName(studentFN, "", studentLN));
			}
			String[] FNLN = studenListFromStudentTab.get(0).split(" ");
			String studentFNLN = FNLN[0].concat(FNLN[1]);

			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			// Selecting Reading Course and assigning to student
			coursePage.clickReadingCourse();
			coursePage.clickAssignBtn();
			coursePage.addCourseToOneStudent(studentFNLN);

			// SignOut
			tHomePage.topNavBar.signOutfromSM();
			driver.quit();

			// Get driver
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);


			// Login as Student into Student dashBoard
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUsername,
					password);

			StudentDashboardPage stuPage = new StudentDashboardPage(studentDriver);

			Log.message("Reading Course Execution");
			stuPage.executeReadingCourse(teacherID, Constants.READING, "90", "1", "5");
			// Logout
			stuPage.logout();
			studentDriver.quit();

			// Navigate to teacher page again
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);


			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(Constants.READING);
			String studentName = assignmentDetailsPage.getStudentName(SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));
			// Click on plus icon to expand the student.
			assignmentDetailsPage.clickStudentAccordionButton(studentName);
//			assignmentDetailsPage.clicktoggleButtonForStudent(SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),
//					SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));
			Log.assertThat(assignmentDetailsPage.getZeroStateTextFromProgressGraph().equals(Constants.NO_DATA_MESSAGE),"Zero State Message Displayed Successfuly when IP Level is In IP",
					"Zero State Message Not Displayed");
			SMUtils.logDescriptionTC("SMK-13919: Verify if all links are hidden and only View Summary is visible when student's IP level is in In IP or -- or NA<small><b><i>["
							+ browser + "]</b></i></small>");
			Log.assertThat(assignmentDetailsPage.verifyEditTargetLinkNotDisplayed(),"Links are hidden and View Summary is displayed when IP Level is In IP", "Links Not hidden");
			Log.assertThat(assignmentDetailsPage.verifyPrintLinkNotDisplayed(),"Print link is hidden when when IP Level is In IP", "Print Link Not hidden");
			Log.assertThat(assignmentDetailsPage.verifyViewSummaryLinkDisplayed(),"View Summary Link is displayed when when IP Level is In IP", "View Summary Link is hidden");
			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			page.viewAssignmentDetailsByAssignmentName(Constants.MATH);
			assignmentDetailsPage.clickStudentAccordionButton(studentName);
			Log.assertThat(assignmentDetailsPage.getZeroStateTextFromProgressGraph().equals(Constants.NO_DATA_MESSAGE),
					"Zero State Message Displayed Successfuly when IP Level is --", "Zero State Message Not Displayed");
			SMUtils.logDescriptionTC("SMK-13919: Verify if all links are hidden and only View Summary is visible when student's IP level is in In IP or -- or NA<small><b><i>["
							+ browser + "]</b></i></small>");
			Log.assertThat(assignmentDetailsPage.verifyEditTargetLinkNotDisplayed(),"Edit Target link is hidden when IP Level is --", "Edit Target Link Not hidden");
			Log.assertThat(assignmentDetailsPage.verifyPrintLinkNotDisplayed(),"Print link is hidden when when IP Level is --", "Print Link Not hidden");
			Log.assertThat(assignmentDetailsPage.verifyViewSummaryLinkDisplayed(),"View Summary Link is displayed when when IP Level is --", "View Summary Link is hidden");
			// Sign Out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}
	
	 public void executeSimulator( String studentUsername, String assignmentName, String assignmentType ) throws Exception {
	        WebDriver studentDriver = WebDriverFactory.get( browser );
	        LoginPage smStudentLoginPage = new LoginPage( studentDriver, smUrl ).get();
	        StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
	        try {
	            if ( assignmentType.equals( Constants.MATH ) ) {
	                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
	                    Log.message( "Math Course Execution" );
	                    try {
	                        studentDashboardPage.executeMathCourse( username, assignmentName, "95", "2", "30" );
	                    } catch ( IOException e ) {
	                        Log.message( "Error occurred while running the simulator for Math" );
	                    }

	                } );

	            } else {
	                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
	                    Log.message( "Reading Course Execution" );
	                    try {
	                        studentDashboardPage.executeReadingCourse( username, assignmentName, "100", "2", "15" );
	                    } catch ( IOException e ) {
	                        Log.message( "Error occurred while running the simulator Reading" );
	                    }

	                } );

	            }
	        } catch ( Exception e ) {

	            Log.message( "Error occurred while running the simulator" );
	        }
	        studentDriver.quit();
	    

	}

}
