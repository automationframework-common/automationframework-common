package com.savvas.sm.teacher.ui.tests.MasterySuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.HomePageWidgetConstants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class HomepageMasteryTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String chromePlatform = "Windows_10_Chrome_latest";
    private String teacherId;
    private String orgId;

    List<String> studentIDList = null;
    List<String> studentNames = new ArrayList<>();
    BaseAPITest baseApiObject = new BaseAPITest();
    UserSqlHelper userSqlHelper = new UserSqlHelper();
    SqlHelperOrganization sqlHelperOrganization = new SqlHelperOrganization();
    List<String> MathAssignmentNames = new ArrayList<>();
    List<String> ReadingAssignmentNames = new ArrayList<>();

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher65" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        teacherId = userSqlHelper.getPersonID( username );
        orgId = userSqlHelper.getOrgId( teacherId );

        String sessionCookie = baseApiObject.getJessionCookie( smUrl, username, password );

        // Addding student usenames
        for ( int studentCount = 1; studentCount <= DataSetupConstants.STUDENT_COUNT; studentCount++ ) {
            String studentUN = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,userName" );
            studentNames.add( studentUN );
        }

        //Getting all the student ID
        studentIDList = new ArrayList<>();
        for ( int studentCount = 1; studentCount <= DataSetupConstants.STUDENT_COUNT; studentCount++ ) {
            String studentId = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,personId" );
            studentIDList.add( studentId );
        }
    }

    @Test ( priority = 1, groups = { "SMK-43626", "mastery", "HomePage-Mastery" } )
    public void tcMasteryHomePageTest_001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Go to the  assignment detail Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> AssignmentsName = assignmentsPage.getColumnAssignmentValues();

            // Deleting a all assignments
            for ( String assignmentName : AssignmentsName ) {
                AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentName );
                assignmentDetailsPage.deleteAssignment();
            }
            tHomePage.topNavBar.navigateToHomeTab();
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, tHomePage.getMasteryCardContainerElement(), 5 );
            SMUtils.logDescriptionTC( "SMK-12900_Verify when Assignment count is zero, zero state message is displayed" );
            //Check for the zero state message for Low Performing
            Log.softAssertThat( tHomePage.getAllAssignments().size() < 1, "The assignment count is zero as expected!", "The assignments count is not zero as expected!" );

            //  SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43626", "mastery", "HomePage-Mastery" } )
    public void tcMasteryHomePageTest_002() throws Exception {

        String sessionCookie = baseApiObject.getJessionCookie( smUrl, username, password );
        baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.MATH, DataSetup.organizationId.toString(), teacherId, "1", studentIDList );
        baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.READING, DataSetup.organizationId.toString(), teacherId, "2", studentIDList );
        MathAssignmentNames.add( DataSetupConstants.MATH );
        ReadingAssignmentNames.add( DataSetupConstants.READING );

        //Assigning Math Courses and Reading courses to 3 students
        int count = 4;
        for ( int i = 1; i < count; i++ ) {
            String assignmentName = "Math" + i;
            String courseId = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, assignmentName );
            boolean isAssigned = baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.MATH, orgId, teacherId, courseId, studentIDList.subList( 0, 5 ) );
            MathAssignmentNames.add( assignmentName );
        }
        for ( int i = 1; i < count; i++ ) {
            String assignmentName = "Reading" + i;
            String courseId = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, assignmentName );
            boolean isAssigned = baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.READING, orgId, teacherId, courseId, studentIDList.subList( 0, 5 ) );
            ReadingAssignmentNames.add( assignmentName );
        }
        // Student attending courses
		EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		studentDriver.register(eventListner);
        try {
            LoginPage smLoginPageStudent = new LoginPage( studentDriver, smUrl ).get();
            StudentDashboardPage studentsPage = smLoginPageStudent.loginToSMasStudent( studentNames.get( 0 ), DataSetupConstants.DEFAULT_PASSWORD, false );
            studentsPage.logout();
            for ( String userName : studentNames.subList( 0, 2 ) ) {
                Log.message( "Attending student as " + userName );
                smLoginPageStudent.enterCredentialsAndLogIn( userName, DataSetupConstants.DEFAULT_PASSWORD );
                // Attending math
                for ( String assignment : MathAssignmentNames ) {
                    studentsPage.executeMathCourse( username, assignment, "80", "3", "10" );
                }
                // Attending Reading
                for ( String assignment : ReadingAssignmentNames ) {
                    studentsPage.executeReadingCourse( username, assignment, "40", "3", "10" );
                }
                studentsPage.logout();
            }
        } catch ( Exception e ) {
            Log.exception( e, studentDriver );
        } finally {
            studentDriver.quit();
            Log.endTestCase();
        }

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		eventListner = new EventListener();
		driver.register(eventListner);

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.waitForSpinnertoDisapper( driver );
            MasteryPage masterypage = new MasteryPage( driver );

            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> mathAssignments = assignmentPage.getMathCourses();
            List<String> readingAssignments = assignmentPage.getReadingCourses();
            teacherHomePage.topNavBar.navigateToHomeTab();
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-12666:Verify on Mastery Card shows the 'Top Performing' (up to 3) and 'Low Performing' (up to 3) skills " + "for the particular assignment based on the subject & standards" );
            SMUtils.logDescriptionTC( "SMK-12667:Verify on Mastery Card 'Top Performing' and 'Low Performing' title is displaying in two column" );
            SMUtils.logDescriptionTC( "SMK-12668:Verify on Mastery Card 'Top Performing' and 'Low Performing' title is displaying in two columns and it has " + "LO Number, Skill name and Percentage displayed in it for math related assignments only" );
            SMUtils.logDescriptionTC( "SMK-12669:Verify on Mastery Card 'Top Performing' and 'Low Performing' title is displaying in two columns and it has " + "Skill name and Percentage displayed in it for reading related assignments only" );
            SMUtils.logDescriptionTC( "SMK-12670:Verify on Mastery card, The first top three performing LO/skill datas are shown in percentage in the top " + "performing column for the mastered students with respect to subject,standards and assignment" );
            SMUtils.logDescriptionTC( "SMK-12671:Verify on Mastery card, The first three low performing LO/skill datas are shown in percentage in the low " + "performing column for the mastered students with respect to subject,standards and assignment" );
            SMUtils.logDescriptionTC( "SMK-12678:Verify the text 'Mastered' is displayed under percentage view in the mastery card top and low performing " + "column for the particular assignment ,standards and subject" );
            SMUtils.logDescriptionTC( "SMK-12679:Verify the correct LO/skill percentage is displayed in the mastery card top and low performing column for " + "the particular/All assignment ,standards and subject selected from the dropdown" );
            SMUtils.logDescriptionTC( "SMK-12688:Verify the 'view all' link is seen along with the breadcrumb icon in the top and low performing column under mastery card" ); // Verifying mastery card
            teacherHomePage.verifyingMasteryCard();

            SMUtils.logDescriptionTC( "SMK-12689:Verify after clicking view all link breadcrumb icon , homepage is navigated to mastery summary " + "page under primary mastery tab" );
            teacherHomePage.clickViewAllinMasteryCard();
            Log.assertThat( masterypage.getMasteryHeading().equals( "Mastery" ), "NavigateD to Mastery page", "Clicking view all  is not navigated to Mastery page" );
            teacherHomePage.topNavBar.navigateToHomeTab();

            SMUtils.logDescriptionTC( "SMK-12692:Verify on Mastery Card , Apply filter button is in enabled state when '0 Assignment(s) ' is " + "selected from the assignment dropdown" );
            teacherHomePage.clickAssignmentDropdown();
            teacherHomePage.clickSelectAllCheckbox();
            Log.assertThat( !teacherHomePage.isMasteryApplyFilterdisabled(), "The apply filter is enabled", "The apply filter is not enabled" );
            SMUtils.logDescriptionTC( "SMK-12693:Verify on Mastery Card 'Top Performing' and 'Low Performing' datas are not displaying when " + "clicked on Apply filter button if '0 Assignment(s) ' is selected from the assignment dropdown" );
            teacherHomePage.clickApplyFilterinMasteryCard();
            Log.assertThat( !teacherHomePage.isMasterycardHasSkills(), "The skills are not displaying as Expected!", "The skills are displaying for the when 0 assignment is checked" );

            SMUtils.logDescriptionTC( "SMK-12696:Verify previously loaded Mastery Data are getting cleared on navigating back to home page" );
            teacherHomePage.selectAssignmentsinMasteryCard( Arrays.asList( "Math" ) );
            List<String> topSkillsPercent = teacherHomePage.getMasteryPercentValues( HomePageWidgetConstants.TOP_PERFORMING );
            teacherHomePage.navigateToGroupsMenu();
            teacherHomePage.topNavBar.navigateToHomeTab();
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForElement( driver, teacherHomePage.getMasteryCardContainerElement(), 5 );
            Log.assertThat( !topSkillsPercent.equals( teacherHomePage.getMasteryLoDetails( HomePageWidgetConstants.TOP_PERFORMING ) ), "The vaues are changed", "The values are not changed" );

            SMUtils.logDescriptionTC( "SMK-12697:Verify previously loaded Mastery Data are getting cleared by logout and login again." );
            teacherHomePage.selectAssignmentsinMasteryCard( Arrays.asList( "Math" ) );
            topSkillsPercent = teacherHomePage.getMasteryLoDetails( HomePageWidgetConstants.TOP_PERFORMING );
            teacherHomePage.topNavBar.signOutfromSM();
            smLoginPage.enterCredentialsAndLogIn( username, password );
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.assertThat( !topSkillsPercent.equals( teacherHomePage.getMasteryPercentValues( HomePageWidgetConstants.TOP_PERFORMING ) ), "The values are changed as expected!", "The values are not changed" );

            SMUtils.logDescriptionTC( "SMK-12665:Verify the assignment dropdown will list all available assignments for the logged in teacher based on subject only in mastery card in home page irrespective of standards selection " );
            MasteryFiltersComponent masteryFiltersComponent = masterypage.getMasteryFilterComponent();

            // Math courses filter
            masteryFiltersComponent.selectSubject( Constants.MATH );
            teacherHomePage.clickApplyFilterinMasteryCard();
            List<String> filteredList = teacherHomePage.getAllAssignments();
            Collections.sort( mathAssignments );
            Collections.sort( filteredList );
            Log.assertThat( mathAssignments.equals( filteredList ), "All the math courses is listed", "All the math courses is not listed" );

            // Reading courses filter
            masteryFiltersComponent.selectSubject( Constants.READING );
            teacherHomePage.clickApplyFilterinMasteryCard();
            filteredList = teacherHomePage.getAllAssignments();
            Collections.sort( readingAssignments );
            Collections.sort( filteredList );
            Log.assertThat( readingAssignments.equals( filteredList ), "All the reading courses is listed", "All the reading courses is not listed" );

            teacherHomePage.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
