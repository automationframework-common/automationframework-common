package com.savvas.sm.api.tests.smnew.sharedcourses;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class GetSharedCourses extends EnvProperties {

    private String smUrl;
    private String districtId;
    private String username;
    private String password;
    private String userId;
    private String teacherDetails;
    private String teacherUsername;
    private String teacherUserId;
    private String courseId;
    private String subdistrictSchoolTeacherID;
    private String subdistrictSchoolTeacher;
    private String sharedCourseName;
    private String sharedCourseId;
    private RBSUtils rbsUtils = new RBSUtils();
    Map<String, String> response = new HashMap<>();
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    SharedCourses sharedCourse = new SharedCourses();

    Map<String, String> headers = new HashMap<>();

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );

        // Getting admin details in RBS Datasetup
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );

        //create shared course 
        courseId = sharedCourse.createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherUserId, RBSDataSetup.organizationIDs.get( school ), DataSetupConstants.SETTINGS,
                "Shared Math course" + System.nanoTime() );

        String flexSchoolteacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        String flexSchoolteacherUsername = SMUtils.getKeyValueFromResponse( flexSchoolteacherDetails, RBSDataSetupConstants.USERNAME );
        String flexSchoolteacherUserId = SMUtils.getKeyValueFromResponse( flexSchoolteacherDetails, "userId" );

        //create shared course 
        String flexSchoolcourseId = sharedCourse.createCustomCourse( smUrl, rbsUtils.getAccessToken( flexSchoolteacherUsername, password ), DataSetupConstants.MATH, flexSchoolteacherUserId,
                RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ), DataSetupConstants.SETTINGS, "Shared Math course" + System.nanoTime() );
        Log.message( flexSchoolcourseId );
    }

    /**
     * This method is used to test the positive scenarios for Get- Shared
     * courses.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "poistiveScenarioTestData", groups = { "smoke_test_case", "sharedCourse", "SMK-51786", "P1", "API" } )
    public void getSharedCoursePositive( String tcID, String tcDescription, String statusCode, String scenarioType ) throws Exception {
        Log.testCaseInfo( tcID + ": " + tcDescription );
        List<String> orgId = new ArrayList<>();
        switch ( scenarioType ) {
            case "VALID":
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.USERID_SM_HEADER, userId );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                response = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                orgId = getOrganizationIdsForAdmin( Admins.DISTRICT_ADMIN );
                break;

            case "SUBDISTRICT_ADMIN_USER_ID":

                //create subdistrict teacher
                Map<String, String> userDetail = new HashMap<>();
                subdistrictSchoolTeacher = "SubdistrictSchoolTeacher" + System.nanoTime();
                userDetail.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
                userDetail.put( RBSDataSetupConstants.USERNAME, subdistrictSchoolTeacher );
                userDetail.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                List<String> listOfSchools = Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                String schoolList = "";
                for ( String school : listOfSchools ) {
                    schoolList += school.concat( "\",\"" );
                }
                schoolList = schoolList.substring( 0, schoolList.length() - 3 );
                userDetail.put( RBSDataSetupConstants.ORGANIZATIONIDS, schoolList );
                subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( (HashMap<String, String>) userDetail ), RBSDataSetupConstants.USERID );
                rbsUtils.resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, subdistrictSchoolTeacherID );

                //create course for subdistrict teacher
                sharedCourseName = "Shared Math course" + System.nanoTime();
                sharedCourseId = sharedCourse.createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherUserId, RBSDataSetup.organizationIDs.get( school ), DataSetupConstants.SETTINGS,
                        "Shared Math course" + System.nanoTime() );

                sharedCourse.createCustomCourse( smUrl, rbsUtils.getAccessToken( subdistrictSchoolTeacher, password ), DataSetupConstants.MATH, subdistrictSchoolTeacherID, teacherUserId, DataSetupConstants.SETTINGS, "Shared Math: " + System.nanoTime() );

                // Getting sub-district admin details in RBS Datasetup
                String subDistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERID ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.subDistrictwithSchoolId );
                response = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                orgId = getOrganizationIdsForAdmin( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );

                break;

            case "REMOVE_SHARED_COURSE":

                // Remove shared course
                sharedCourse.updateSharedCourse( smUrl, subdistrictSchoolTeacher, password, teacherUserId, RBSDataSetup.schoolUnderSubDistrict_SchoolId, sharedCourseId, sharedCourseName, "1", "false",
                        new SqlHelperCourses().getSharedCourseEnrollmentID( sharedCourseId ) );

                // Getting sub-district admin details in RBS Datasetup
                subDistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ), password ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERID ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.subDistrictwithSchoolId );
                response = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                orgId = getOrganizationIdsForAdmin( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );

                break;

            case "SCHOOL_ADMIN_USER_ID":

                // Getting sub-district admin details in RBS Datasetup
                String schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN ), password ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgId" ) );
                String[] schoolId = { SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgId" ) };
                sharedCourse.editShareCourseList( smUrl, headers, schoolId, courseId, "" );
                response = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                Log.message( response + "" );
                orgId = getOrganizationIdsForAdmin( Admins.MULTI_SCHOOL_ADMIN );

                break;

            case "AFTER_SHARED_WITH_NEW_ORG":
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.USERID_SM_HEADER, userId );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                String[] orgIDs = { RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) };
                sharedCourse.editShareCourseList( smUrl, headers, orgIDs, courseId, "" );
                response = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                Log.assertThat( verifySharedOrgCount( response.get( Constants.REPORT_BODY ), courseId, "2" ), "Shared org count is updated after shared with new organization", "Shared org count is not updated after shared with new organization" );
                orgId = getOrganizationIdsForAdmin( Admins.DISTRICT_ADMIN );

                break;

            case "AFTER_UNSHARED_WITH_ORG":
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.USERID_SM_HEADER, userId );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                String[] orgIds = { RBSDataSetup.organizationIDs.get( school ) };
                sharedCourse.editShareCourseList( smUrl, headers, orgIds, courseId, "" );
                response = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                Log.assertThat( verifySharedOrgCount( response.get( Constants.REPORT_BODY ), courseId, "1" ), "Shared org count is updated after unshared with organization", "Shared org count is not updated after unshared with organization" );
                orgId = getOrganizationIdsForAdmin( Admins.DISTRICT_ADMIN );
                break;

            case "AFTER_DELETE_THE_SHAREDCOURSE":
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.USERID_SM_HEADER, userId );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                sharedCourse.deleteCourse( smUrl, teacherUsername, password, teacherUserId, RBSDataSetup.organizationIDs.get( school ), courseId );
                response = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                Log.assertThat(
                        !IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), AdminAPIConstants.OWNER_ORG_ID ) ).anyMatch(
                                iter -> SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ID, iter ).equals( courseId ) ),
                        "Deleted shared course is not fetched as expected!", "API fetches deleted shared course after delete the shared courses!" );
                orgId = getOrganizationIdsForAdmin( Admins.DISTRICT_ADMIN );
                break;

            case "SHARED_COURSE_CREATED_BY_MULTIPLE_SCHOOL_TEACHER":
                //create multiple school teacher
                String multiSchoolTeacher = "MultiSchTeacher" + System.nanoTime();
                HashMap<String, String> userDetails = new HashMap<>();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                List<String> schools = new ArrayList<String>();
                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                String listString = "";
                for ( String school : schools ) {
                    listString += school.concat( "\",\"" );
                }
                listString = listString.substring( 0, listString.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
                String multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                rbsUtils.resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

                //create course for multiple school teacher
                String courseIdByMultipleSchoolTeacher = sharedCourse.createCustomCourse( smUrl, rbsUtils.getAccessToken( multiSchoolTeacher, password ), DataSetupConstants.MATH, multipleSchoolTeacherID,
                        RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), DataSetupConstants.SETTINGS, "Shared Math course" + System.nanoTime() );

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.USERID_SM_HEADER, userId );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                sharedCourse.deleteCourse( smUrl, teacherUsername, password, teacherUserId, RBSDataSetup.organizationIDs.get( school ), courseId );
                response = sharedCourse.getSharedCourseList( smUrl, headers, "" );

                Log.assertThat(
                        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), AdminAPIConstants.OWNER_ORG_ID ) ).filter(
                                iter -> SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ID, iter ).equals( courseIdByMultipleSchoolTeacher ) ).allMatch(
                                        iter -> SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.OWNER_ORG_ID, iter ).equals( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) ) ),
                        "Get shared course fetched organization if multiple school teacher created shared course", "Get shared course not fetched organization if multiple school teacher created shared course" );
                orgId = getOrganizationIdsForAdmin( Admins.DISTRICT_ADMIN );
                break;

            case "SAVVAS_ADMIN":
                // Getting sub-district admin details in RBS Datasetup
                String savvasAdminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), password ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( savvasAdminDetails, RBSDataSetupConstants.USERID ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( savvasAdminDetails, "primaryOrgId" ) );
                response = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                Log.message( response + "" );
                orgId = getOrganizationIdsForAdmin( Admins.MULTI_SCHOOL_ADMIN );

            default:
                Log.message( "not a valid scenario type" );
                break;
        }
        //status code validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );

        //schema validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "GetSharedCourse", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        //data validation
        Map<String, Map<String, String>> sharedCourseFromGetAPI = new HashMap<>();

        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), AdminAPIConstants.OWNER_ORG_ID ) ).parallel().forEach( iter -> {
            Map<String, String> sharedCourse = new HashMap<>();
            sharedCourse.put( AdminAPIConstants.COURSE_NAME, SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.COURSE_NAME, iter ) );
            sharedCourse.put( AdminAPIConstants.SHARED_ORG_COUNT, SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.SHARED_ORG_COUNT, iter ) );
            sharedCourse.put( AdminAPIConstants.OWNER_ORG_ID, SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.OWNER_ORG_ID, iter ) );
            sharedCourseFromGetAPI.put( SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ID, iter ), sharedCourse );
        } );

        List<String> orgIdForAdmin = orgId;
        Map<String, Map<String, String>> sharedCourseFromDB = new SqlHelperCourses().getAllSharedCourses().entrySet().stream().parallel().filter( entry -> orgIdForAdmin.contains( entry.getValue().get( AdminAPIConstants.OWNER_ORG_ID ) ) ).collect(
                Collectors.toMap( Map.Entry::getKey, Map.Entry::getValue ) );
        Log.message( sharedCourseFromGetAPI.toString() );
        Log.message( sharedCourseFromDB.toString() );

        Log.assertThat( sharedCourseFromDB.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), sharedCourseFromGetAPI.get( entry.getKey() ) ) ), "API fetched all the shared course properly",
                "API is not fetching all the shared course properly" );

    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "poistiveScenarioTestData" )
    public Object[][] poistiveScenarioTestData() {
        return new Object[][] { { "tc001", "Verify all the shared courses under district are returned in response with 200 response code for given district admin.", CommonAPIConstants.STATUS_CODE_OK, "VALID" },
                { "tc002", "Verify status code and response body when a User-ID is a sub-district admin in headers", CommonAPIConstants.STATUS_CODE_OK, "SUBDISTRICT_ADMIN_USER_ID" },
                { "tc003", "Verify status code 200 and response when the Shared course is removed from Shared course listing", CommonAPIConstants.STATUS_CODE_OK, "REMOVE_SHARED_COURSE" },
                { "tc004", "Verify status code 200 when a User-ID is a school admin in headers", CommonAPIConstants.STATUS_CODE_OK, "SCHOOL_ADMIN_USER_ID" },
                { "tc005", "Verify status code 200 and response when a course shared with new orgs under the district", CommonAPIConstants.STATUS_CODE_OK, "AFTER_SHARED_WITH_NEW_ORG" },
                { "tc006", "Verify status code 200 and response when a shared course is removed for some orgs under the district", CommonAPIConstants.STATUS_CODE_OK, "AFTER_UNSHARED_WITH_ORG" },
                { "tc007", "Verify status code 200 and response when a shared course is added and deleted the shared course", CommonAPIConstants.STATUS_CODE_OK, "AFTER_DELETE_THE_SHAREDCOURSE" },
                { "tc008", "Verify the response body if the shared course is created by multiple school teacher.", CommonAPIConstants.STATUS_CODE_OK, "SHARED_COURSE_CREATED_BY_MULTIPLE_SCHOOL_TEACHER" } };
    }

    /**
     * This method is used to test the negative scenarios for Get- Shared
     * courses.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 2, dataProvider = "negativeScenarioTestData", groups = { "sharedCourse", "SMK-51786", "P3", "API" } )
    public void getSharedCourseNegative( String tcID, String tcDescription, String statusCode, String scenarioType ) throws Exception {
        Log.testCaseInfo( tcID + ": " + tcDescription );

        Map<String, String> headers = new HashMap<>();
        // Input Params
        HashMap<String, String> params = new HashMap<>();

        String endPoint = AdminConstants.GET_SHARED_COURSE;

        switch ( scenarioType ) {
            case "WITHOUT_USER_ID":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, districtId );

                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                break;
            case "WITHOUT_BEARER_TOKEN":
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.USERID_SM_HEADER, userId );
                headers.put( Constants.ORGID_SM_HEADER, districtId );

                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                break;
            case "WITHOUT_ORG_ID":
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.USERID_SM_HEADER, userId );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                break;

            case "INVLAID_USER_ID":
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.USERID_SM_HEADER, userId + "Invalid" );
                headers.put( Constants.ORGID_SM_HEADER, districtId );

                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                break;

            case "WITH_STUDENT_CREDENTIAL":
                String studentDetails = RBSDataSetup.orgStudentDetails.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ).get( "Student1" );
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), password ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( Schools.MATH_SCHOOL ) );

                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                break;
            case "WITH_TEACHER_CREDENTIAL":
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( Schools.MATH_SCHOOL ) );

                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                break;
            default:
                Log.message( "not a valid scenario type" );
                break;
        }

        //status code validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );

        //schema validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "GetSharedCourse", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "negativeScenarioTestData" )
    public Object[][] negativeScenarioTestData() {
        return new Object[][] { { "tc006", "Verify status code 401 when user id is not passed in header parameter", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, "WITHOUT_USER_ID" },
                { "tc009", "Verify status code 401 when bearer token is not passed in header parameter", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, "WITHOUT_BEARER_TOKEN" },
                { "tc010", "Verify status code 403 when Org ID is not passed in query parameter", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "WITHOUT_ORG_ID" },
                { "tc011", "Verify status code 401 when User ID is invalid is in headers", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, "INVLAID_USER_ID" },
                { "tc012", "Verify status code 403 when User ID is student rumba id in headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN, "WITH_STUDENT_CREDENTIAL" },
                { "tc013", "Verify status code 403 when User ID is teacher rumba id in headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN, "WITH_TEACHER_CREDENTIAL" }, };
    }

    /**
     * To Verify the shared org count for given courseId
     * 
     * @param responseBody
     * @param courseId
     * @param expectedOrgCount
     * @return
     */
    public boolean verifySharedOrgCount( String responseBody, String courseId, String expectedOrgCount ) {
        return IntStream.rangeClosed( 1, SMUtils.getWordCount( responseBody, AdminAPIConstants.OWNER_ORG_ID ) ).filter( iter -> SMUtils.getKeyValueFromJsonArray( responseBody, AdminAPIConstants.ID, iter ).equals( courseId ) ).allMatch(
                iter -> SMUtils.getKeyValueFromJsonArray( responseBody, AdminAPIConstants.SHARED_ORG_COUNT, iter ).equals( expectedOrgCount ) );
    }

    /**
     * To get the organization List for given admin
     *
     * @param admin
     * @return
     * @throws Exception
     */
    public List<String> getOrganizationIdsForAdmin( Admins admin ) throws Exception {
        String orgId;
        if ( admin.equals( Admins.SCHOOL_ADMIN ) ) {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        } else {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );
        }
        String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userId" );
        String accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), password );

        Map<String, String> headers = new HashMap<>();
        //headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
        headers.put( AdminAPIConstants.USERID, userId );
        headers.put( AdminAPIConstants.ORGID, orgId );
        Map<String, String> response = new OrganizationListing().getOrganizationList( smUrl, headers );
        List<String> organizationListFromAPI = new ArrayList<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_NAME ) ).forEach(
                iter -> organizationListFromAPI.add( SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_ID, iter ) ) );

        return organizationListFromAPI;
    }
}
