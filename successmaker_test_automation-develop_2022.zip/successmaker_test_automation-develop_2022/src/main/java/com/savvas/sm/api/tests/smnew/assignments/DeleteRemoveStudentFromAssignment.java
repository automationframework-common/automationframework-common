package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

public class DeleteRemoveStudentFromAssignment extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String CourseId;
    private String assignmentID;
    private String AssignmentUserId;
    private String teacherUsername;
    List<String> studentRumbaIds = new ArrayList<>();

    RBSUtils rbsutils = new RBSUtils();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();

    }

    @Test ( priority = 1, dataProvider = "RemoveStudent_PositiveFlow", groups = { "SMK-51711", "smoke_test_case", "RemoveStudentFromAssignment", "P1", "API" } )
    public void tcRemoveStudent_01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        String endpoint = "null";

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        HashMap<String, String> response = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        switch ( scenario ) {

            case "Remove Student MATH":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            case "Remove Student READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            case "Remove Student FOCUS READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            case "Remove Student FOCUS MATH":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            case "Remove Student CUSTOM SETTINGS MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            case "Remove Student CUSTOM SKILL MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            case "Remove Student CUSTOM STANDARD MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            case "Remove Student CUSTOM SETTINGS READING":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            case "Remove Student CUSTOM SKILL READING":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            case "Remove Student CUSTOM STANDARD READING":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }
        HashMap<String, String> getresponse = removeStudentAssignment( smUrl, assignmentDetails, endpoint );
        Log.message( getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
        Log.assertThat( smAPIprocessor.isSchemaValid( "deleteStudentAssignment", CommonAPIConstants.STATUS_CODE_OK, getresponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
        Log.testCaseResult();
    }

    @Test ( priority = 2, dataProvider = "RemoveStudent_NegativeFlow", groups = { "SMK-51711", "Assignments", "RemoveStudentFromAssignment", "P1", "API" } )
    public void tcRemoveStudent_02( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        String endpoint = "null";
        String message = null;
        String exception = null;

        boolean status = false;
        HashMap<String, String> response = new HashMap<>();

        HashMap<String, String> groupDetails = new HashMap<>();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        switch ( scenario ) {

            case "Invalid OrgId in Headers":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, CommonAPIConstants.INVALID_ORG_ID );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "Empty OrgId in Headers":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, " " );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "Empty staffId in Headers":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, " " );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "InValid bearer token in Headers":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "Invalid staffId in Headers":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, "12345678" );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            case "Invalid Assignmentuserid":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, "aa" );
                exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
                message = null;
                status = true;
                break;

            case "Empty Assignmentuserid":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, " " );
                exception = CommonAPIConstants.NULL_EXCEPTION;
                message = null;
                status = true;
                break;
            case "Staff-Id in headers are from different organizations":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, CommonAPIConstants.INVALID_STAFF_ID );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            default:
                Log.message( "Case is invalid" );
                break;

        }
        HashMap<String, String> getresponse = removeStudentAssignment( smUrl, assignmentDetails, endpoint );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
        Log.message( getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        if ( message != null ) {
            verifyException( getresponse.get( "body" ), exception, status, message );
        }

        Log.testCaseResult();

    }

    /**
     * Data provider to give the positive data
     * 
     * @return
     */
    @DataProvider ( name = "RemoveStudent_PositiveFlow" )
    public Object[][] DeleteAssignments_PositiveFlow() {

        Object[][] inputData = {

                { "Verify the valid response to Remove Student From Assignment API for Default Math", "Remove Student MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Student From Assignment API for Default Reading", "Remove Student READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Student From Assignment API for Focus Reading", "Remove Student FOCUS READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Student From Assignment API for Focus Math", "Remove Student FOCUS MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Student From Assignment API for Custom Settings Math", "Remove Student CUSTOM SETTINGS MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Student From Assignment API for Custom Skill Math", "Remove Student CUSTOM SKILL MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Student From Assignment API for Custom Standards Math", "Remove Student CUSTOM STANDARD MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Student From Assignment API for Custom Settings Reading", "Remove Student CUSTOM SETTINGS READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Student From Assignment API for Custom Skill Reading", "Remove Student CUSTOM SKILL READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Remove Student From Assignment API for Custom Standards Reading", "Remove Student CUSTOM STANDARD READING", CommonAPIConstants.STATUS_CODE_OK }, };

        return inputData;
    }

    /**
     * Data provider to give the Negative data
     * 
     * @return
     */
    @DataProvider ( name = "RemoveStudent_NegativeFlow" )
    public Object[][] DeleteAssignments_NegativeFlow() {

        Object[][] inputData = { { "Verify the status code and response for invalid OrgId in Headers", "Invalid OrgId in Headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code and response for Empty OrgId in Headers", "Empty OrgId in Headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code and response for Empty StaffId in Headers", "Empty staffId in Headers", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code and response for invalid staffId in Headers", "Invalid staffId in Headers", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code and response for other org staffId in Headers", "Staff-Id in headers are from different organizations", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code and response for inValid bearer token  in Header", "InValid bearer token in Headers", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code and response for invalid Assignmentuserid", "Invalid Assignmentuserid", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the status code and response for Empty Assignmentuserid", "Empty Assignmentuserid", CommonAPIConstants.STATUS_CODE_INTERNAL_ERROR },

        };
        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

}