package com.savvas.sm.api.tests.smnew.groups;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.DeleteGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.getGroupListAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.studentsNotPartofGroupsAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.ethnicity;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.gender;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.grade;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasDisability;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEconomicDisadvantage;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEnglishProficiency;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.isMigrant;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.specialServices;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

/**
 * To test the GET list of students for given groupId API
 * 
 * @author nishanth.kamaraj
 *
 */
public class StudentDetailsforGroup extends GroupAPI {

    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String secondTeacher = null;

    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String studentId;
    String orgId;
    String studentId1;
    String studentUsername1;
    String studentDetails;
    String secondStudentId;
    String thirdStudentId;
    String teacherId;
    String username;
    String teacherId1;
    String username1;
    RBSUtils rbs = new RBSUtils();

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        secondTeacher = RBSDataSetup.getMyTeacher( school );
        teacherId1 = SMUtils.getKeyValueFromResponse( secondTeacher, "userId" );
        username1 = SMUtils.getKeyValueFromResponse( secondTeacher, "userName" );
        studentDetails = RBSDataSetup.getMyStudent( school, username );
        studentId1 = SMUtils.getKeyValueFromResponse( studentDetails, "userId" );
        studentUsername1 = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );

    }

    /**
     * Tests the positive scenarios of create group.
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( dataProvider = "viewGroupPositiveScenariosData", groups = { "SMK-50857", "Group", "View Group", "P1", "API", "smoke_test_case", "ViewGroup001", "View Group", "P1" } )
    public void tcViewGroup001( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );


       
        HashMap<String, String> createStudentResponse = new HashMap<>();
        List<String> schools = new ArrayList<>();
        String groupName = "Successmaker API Test Group " + System.nanoTime();
        boolean withStudent = false;
        String multiSchoolTeacher = null;
        String specialCharacter = "Test" + System.nanoTime();
       

        switch ( scenario ) {

            case "GROUP WITH STUDENTS":

                HashMap<String, String> studentDetails = new HashMap<String, String>();
                HashMap<String, String> viewGroupDetails = new HashMap<String, String>();
                List<String> studentRumbaIds = new ArrayList<>();
                HashMap<String, String> userDetails = new HashMap<>();
                HashMap<String, String> groupDetails = new HashMap<>();
                HashMap<String, String> response = new HashMap<>();

                studentDetails = generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.FIRSTNAME, RBSDataSetupConstants.FIRSTNAME + specialCharacter );
                studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.MIDDLENAME, RBSDataSetupConstants.MIDDLENAME );
                studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.LASTNAME, RBSDataSetupConstants.LASTNAME + specialCharacter );
                studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.USERNAME, RBSDataSetupConstants.USERNAME + System.nanoTime() );
                studentDetails = updateRequestBodyValues( studentDetails, UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER + specialCharacter );
                studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails = updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                studentDetails = updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                createStudentResponse = new UserAPI().createStudent( smUrl, studentDetails );

                studentId = SMUtils.getKeyValueFromResponse( createStudentResponse.get( Constants.REPORT_BODY ), Constants.PERSON_ID_DATAVALUE );

                studentRumbaIds.add( studentId );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                HashMap<String, String> createresponse1 = createGroup( smUrl, groupDetails, studentRumbaIds );

                String sampleGroup = SMUtils.getKeyValueFromResponse( createresponse1.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, sampleGroup );
                withStudent = true;
                
                response = getStudentDetailsforGroup( smUrl, viewGroupDetails );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                Log.message( "Actual response:" + response );
                Log.message( "Expected response:" + studentRumbaIds );
                Log.testCaseInfo( "Verify the Student details( id, firstName, middleName, lastName, username, studentid,grade,studentDistrictId) are displayed correctly" );
                Log.testCaseInfo( "Verify the Grade details(GradeId and Grade Name) are displayed correctly" );
                Log.testCaseInfo( "Verify the response student district id fields are returned correctly" );
                Log.testCaseInfo( "Verify the API success message is displayed correctly" );

                verifyResponse( response, studentRumbaIds );
                Log.testCaseInfo( "Verify the student details are reflected correctly in CMS" );

                Log.pass( "Create Group - " + response.get( Constants.REPORT_BODY ) );

                // Schema validation
                Log.assertThat( new SMAPIProcessor().isSchemaValid( studentsNotPartofGroupsAPIConstants.STUDENT_DETAILS_SCHEMA, statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

            case "REMOVE STUDENT FROM GROUP":
                
                HashMap<String, String> studentDetails1 = new HashMap<String, String>();
                HashMap<String, String> viewGroupDetails1 = new HashMap<String, String>();
                List<String> studentRumbaIds1 = new ArrayList<>();
                HashMap<String, String> userDetails1 = new HashMap<>();
                HashMap<String, String> groupDetails1 = new HashMap<>();
                HashMap<String, String> response1 = new HashMap<>();
                // empty group
                studentDetails1 = generateRequestValues( studentDetails1, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails1 = updateRequestBodyValues( studentDetails1, RBSDataSetupConstants.FIRSTNAME, RBSDataSetupConstants.FIRSTNAME + specialCharacter );
                studentDetails1 = updateRequestBodyValues( studentDetails1, RBSDataSetupConstants.MIDDLENAME, RBSDataSetupConstants.MIDDLENAME );
                studentDetails1 = updateRequestBodyValues( studentDetails1, RBSDataSetupConstants.LASTNAME, RBSDataSetupConstants.LASTNAME + specialCharacter );
                studentDetails1 = updateRequestBodyValues( studentDetails1, RBSDataSetupConstants.USERNAME, RBSDataSetupConstants.USERNAME + System.nanoTime() );
                studentDetails1 = updateRequestBodyValues( studentDetails1, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER + specialCharacter );
                studentDetails1 = updateRequestBodyValues( studentDetails1, UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                studentDetails1 = updateRequestBodyValues( studentDetails1, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails1 = updateRequestBodyValues( studentDetails1, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                studentDetails1 = updateRequestBodyValues( studentDetails1, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                createStudentResponse = new UserAPI().createStudent( smUrl, studentDetails1 );
                String studentId = SMUtils.getKeyValueFromResponse( createStudentResponse.get( Constants.REPORT_BODY ), Constants.PERSON_ID_DATAVALUE );

                // creating one more student
                HashMap<String, String> studentDetails2 = new HashMap<String, String>();

                studentDetails2 = generateRequestValues( studentDetails2, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails2 = updateRequestBodyValues( studentDetails2, RBSDataSetupConstants.FIRSTNAME, RBSDataSetupConstants.FIRSTNAME + specialCharacter );
                studentDetails2 = updateRequestBodyValues( studentDetails2, RBSDataSetupConstants.MIDDLENAME, RBSDataSetupConstants.MIDDLENAME );
                studentDetails2 = updateRequestBodyValues( studentDetails2, RBSDataSetupConstants.LASTNAME, RBSDataSetupConstants.LASTNAME + specialCharacter );
                studentDetails2 = updateRequestBodyValues( studentDetails2, RBSDataSetupConstants.USERNAME, RBSDataSetupConstants.USERNAME + System.nanoTime() );
                studentDetails2 = updateRequestBodyValues( studentDetails2, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER + specialCharacter );
                studentDetails2 = updateRequestBodyValues( studentDetails2, UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                studentDetails2 = updateRequestBodyValues( studentDetails2, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails2 = updateRequestBodyValues( studentDetails2, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                studentDetails2 = updateRequestBodyValues( studentDetails2, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                createStudentResponse = new UserAPI().createStudent( smUrl, studentDetails2 );
               String secondStudentId = SMUtils.getKeyValueFromResponse( createStudentResponse.get( Constants.REPORT_BODY ), Constants.PERSON_ID_DATAVALUE );

                studentRumbaIds1.add( studentId );
                studentRumbaIds1.add( secondStudentId );

                groupDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails1.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails1, studentRumbaIds1 );

                String removeStudGroup = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                String teacher1Id = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                new GroupAPI().removeStudentFromGroup( smUrl, studentId, removeStudGroup, teacher1Id, RBSDataSetup.organizationIDs.get( school ),
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                viewGroupDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                viewGroupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                viewGroupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                viewGroupDetails1.put( CreateGroupAPIConstants.GROUP_ID, removeStudGroup );
                withStudent = true;
                
                response1 = getStudentDetailsforGroup( smUrl, viewGroupDetails1 );
                Log.assertThat( response1.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response1.get( Constants.STATUS_CODE ) );

                Log.message( "Actual response:" + response1 );
                Log.message( "Expected response:" + studentRumbaIds1 );
                Log.testCaseInfo( "Verify the Student details( id, firstName, middleName, lastName, username, studentid,grade,studentDistrictId) are displayed correctly" );
                Log.testCaseInfo( "Verify the Grade details(GradeId and Grade Name) are displayed correctly" );
                Log.testCaseInfo( "Verify the response student district id fields are returned correctly" );
                Log.testCaseInfo( "Verify the API success message is displayed correctly" );

                verifyResponse( response1, studentRumbaIds1 );
                String classDataFromCMS;
                Log.testCaseInfo( "Verify the student details are reflected correctly in CMS" );

                Log.pass( "Create Group - " + response1.get( Constants.REPORT_BODY ) );

                // Schema validation
                Log.assertThat( new SMAPIProcessor().isSchemaValid( studentsNotPartofGroupsAPIConstants.STUDENT_DETAILS_SCHEMA, statusCode, response1.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

               
              

                break;

            case "SHARED STUDENT GROUP":
                HashMap<String, String> studentDetails3 = new HashMap<String, String>();
                HashMap<String, String> viewGroupDetails2 = new HashMap<String, String>();
                List<String> studentRumbaIds2 = new ArrayList<>();
                HashMap<String, String> userDetails2 = new HashMap<>();
                HashMap<String, String> groupDetails2 = new HashMap<>();
                HashMap<String, String> response2 = new HashMap<>();
                HashMap<String, String> createResponse2 = new HashMap<>();
                
                Log.testCaseInfo( "Verify the Response if the group have duplicate names" );
                String sharedTeacher = "SharedTeacher" + System.nanoTime();
                String sharedStudent = "SharedStudent" + System.nanoTime();

                userDetails2.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails2.put( RBSDataSetupConstants.USERNAME, sharedTeacher );
                userDetails2.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                userDetails2.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );

                String sharedTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails2 ), RBSDataSetupConstants.USERID );

                studentDetails3 = generateRequestValues( studentDetails3, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails3 = updateRequestBodyValues( studentDetails3, RBSDataSetupConstants.FIRSTNAME, RBSDataSetupConstants.FIRSTNAME + specialCharacter );
                studentDetails3 = updateRequestBodyValues( studentDetails3, RBSDataSetupConstants.MIDDLENAME, RBSDataSetupConstants.MIDDLENAME );
                studentDetails3 = updateRequestBodyValues( studentDetails3, RBSDataSetupConstants.LASTNAME, RBSDataSetupConstants.LASTNAME + specialCharacter );
                studentDetails3 = updateRequestBodyValues( studentDetails3, RBSDataSetupConstants.USERNAME, RBSDataSetupConstants.USERNAME + System.nanoTime() );
                studentDetails3 = updateRequestBodyValues( studentDetails3, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER + specialCharacter );
                studentDetails3 = updateRequestBodyValues( studentDetails3, UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                studentDetails3 = updateRequestBodyValues( studentDetails3, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails3 = updateRequestBodyValues( studentDetails3, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( secondTeacher, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                studentDetails3 = updateRequestBodyValues( studentDetails3, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( secondTeacher, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                createStudentResponse = new UserAPI().createStudent( smUrl, studentDetails3 );
                String sharedStudentID = SMUtils.getKeyValueFromResponse( createStudentResponse.get( Constants.REPORT_BODY ), Constants.PERSON_ID_DATAVALUE );

                studentRumbaIds2.add( sharedStudentID );

                groupDetails2.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( secondTeacher, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( secondTeacher, RBSDataSetupConstants.USERID ) );
                groupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails2.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                createResponse2 = createGroup( smUrl, groupDetails2, studentRumbaIds2 );
                String sharedstudgrp = SMUtils.getKeyValueFromResponse( createResponse2.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                String sharedstudgrp2 = SMUtils.getKeyValueFromResponse( createResponse2.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                viewGroupDetails2.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                viewGroupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                viewGroupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                viewGroupDetails2.put( CreateGroupAPIConstants.GROUP_ID, sharedstudgrp );
                withStudent = true;
                
                response2 = getStudentDetailsforGroup( smUrl, viewGroupDetails2 );
                Log.assertThat( response2.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response2.get( Constants.STATUS_CODE ) );

                Log.message( "Actual response:" + response2 );
                Log.message( "Expected response:" + studentRumbaIds2 );
                Log.testCaseInfo( "Verify the Student details( id, firstName, middleName, lastName, username, studentid,grade,studentDistrictId) are displayed correctly" );
                Log.testCaseInfo( "Verify the Grade details(GradeId and Grade Name) are displayed correctly" );
                Log.testCaseInfo( "Verify the response student district id fields are returned correctly" );
                Log.testCaseInfo( "Verify the API success message is displayed correctly" );

                verifyResponse( response2, studentRumbaIds2 );
                Log.testCaseInfo( "Verify the student details are reflected correctly in CMS" );

                Log.pass( "Create Group - " + response2.get( Constants.REPORT_BODY ) );

                // Schema validation
                Log.assertThat( new SMAPIProcessor().isSchemaValid( studentsNotPartofGroupsAPIConstants.STUDENT_DETAILS_SCHEMA, statusCode, response2.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );


                break;

            case "GROUP WITH MULTI STUDENTS":
                
                HashMap<String, String> studentDetails4 = new HashMap<String, String>();
                HashMap<String, String> viewGroupDetails3 = new HashMap<String, String>();
                List<String> studentRumbaIds3 = new ArrayList<>();
                HashMap<String, String> userDetails3 = new HashMap<>();
                HashMap<String, String> groupDetails3 = new HashMap<>();
                HashMap<String, String> response3 = new HashMap<>();
                HashMap<String, String> createResponse3 = new HashMap<>();

                Log.testCaseInfo( "Verify the response when the students have same student id field in group" );

                String sameStudentId = "SamestudentId";
                // empty group
                studentDetails4 = generateRequestValues( studentDetails4, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails4 = updateRequestBodyValues( studentDetails4, RBSDataSetupConstants.FIRSTNAME, RBSDataSetupConstants.FIRSTNAME + specialCharacter );
                studentDetails4 = updateRequestBodyValues( studentDetails4, RBSDataSetupConstants.MIDDLENAME, RBSDataSetupConstants.MIDDLENAME );
                studentDetails4 = updateRequestBodyValues( studentDetails4, RBSDataSetupConstants.LASTNAME, RBSDataSetupConstants.LASTNAME + specialCharacter );
                studentDetails4 = updateRequestBodyValues( studentDetails4, RBSDataSetupConstants.USERNAME, RBSDataSetupConstants.USERNAME + System.nanoTime() );
                studentDetails4 = updateRequestBodyValues( studentDetails4, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, sameStudentId );
                studentDetails4 = updateRequestBodyValues( studentDetails4, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails4 = updateRequestBodyValues( studentDetails4, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                studentDetails4 = updateRequestBodyValues( studentDetails4, UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                studentDetails4 = updateRequestBodyValues( studentDetails4, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                createStudentResponse = new UserAPI().createStudent( smUrl, studentDetails4 );
                studentId = SMUtils.getKeyValueFromResponse( createStudentResponse.get( Constants.REPORT_BODY ), Constants.PERSON_ID_DATAVALUE );

                // creating one more student
                
                HashMap<String, String> studentDetails5 = new HashMap<String, String>();
                studentDetails5 = generateRequestValues( studentDetails5, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails5 = updateRequestBodyValues( studentDetails5, RBSDataSetupConstants.FIRSTNAME, RBSDataSetupConstants.FIRSTNAME + specialCharacter );
                studentDetails5 = updateRequestBodyValues( studentDetails5, RBSDataSetupConstants.MIDDLENAME, RBSDataSetupConstants.MIDDLENAME );
                studentDetails5 = updateRequestBodyValues( studentDetails5, RBSDataSetupConstants.LASTNAME, RBSDataSetupConstants.LASTNAME + specialCharacter );
                studentDetails5 = updateRequestBodyValues( studentDetails5, RBSDataSetupConstants.USERNAME, RBSDataSetupConstants.USERNAME + System.nanoTime() );
                studentDetails5 = updateRequestBodyValues( studentDetails5, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, sameStudentId );
                studentDetails5 = updateRequestBodyValues( studentDetails5, UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                studentDetails5 = updateRequestBodyValues( studentDetails5, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails5 = updateRequestBodyValues( studentDetails5, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                studentDetails5 = updateRequestBodyValues( studentDetails5, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                createStudentResponse = new UserAPI().createStudent( smUrl, studentDetails5 );
                secondStudentId = SMUtils.getKeyValueFromResponse( createStudentResponse.get( Constants.REPORT_BODY ), Constants.PERSON_ID_DATAVALUE );

                // creating one more student
                HashMap<String, String> studentDetails6 = new HashMap<String, String>();

                studentDetails6 = generateRequestValues( studentDetails6, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails6 = updateRequestBodyValues( studentDetails6, RBSDataSetupConstants.FIRSTNAME, RBSDataSetupConstants.FIRSTNAME + specialCharacter );
                studentDetails6 = updateRequestBodyValues( studentDetails6, RBSDataSetupConstants.MIDDLENAME, RBSDataSetupConstants.MIDDLENAME );
                studentDetails6 = updateRequestBodyValues( studentDetails6, RBSDataSetupConstants.LASTNAME, RBSDataSetupConstants.LASTNAME + specialCharacter );
                studentDetails6 = updateRequestBodyValues( studentDetails6, RBSDataSetupConstants.USERNAME, RBSDataSetupConstants.USERNAME + System.nanoTime() );
                studentDetails6 = updateRequestBodyValues( studentDetails6, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, sameStudentId );
                studentDetails6 = updateRequestBodyValues( studentDetails6, UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                studentDetails6 = updateRequestBodyValues( studentDetails6, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails6 = updateRequestBodyValues( studentDetails6, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                studentDetails6 = updateRequestBodyValues( studentDetails6, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                createStudentResponse = new UserAPI().createStudent( smUrl, studentDetails6 );
                thirdStudentId = SMUtils.getKeyValueFromResponse( createStudentResponse.get( Constants.REPORT_BODY ), Constants.PERSON_ID_DATAVALUE );

                studentRumbaIds3.add( studentId );
                studentRumbaIds3.add( secondStudentId );
                studentRumbaIds3.add( thirdStudentId );

                groupDetails3.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails3.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails3.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails3.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                createResponse3 = createGroup( smUrl, groupDetails3, studentRumbaIds3);

                String groupWithMultiStud = SMUtils.getKeyValueFromResponse( createResponse3.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                new RBSUtils().addProduct( groupWithMultiStud, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

                viewGroupDetails3.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                viewGroupDetails3.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                viewGroupDetails3.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                viewGroupDetails3.put( CreateGroupAPIConstants.GROUP_ID, groupWithMultiStud );
                withStudent = true;

                response3 = getStudentDetailsforGroup( smUrl, viewGroupDetails3 );
                Log.assertThat( response3.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response3.get( Constants.STATUS_CODE ) );

                Log.message( "Actual response:" + response3 );
                Log.message( "Expected response:" + studentRumbaIds3 );
                Log.testCaseInfo( "Verify the Student details( id, firstName, middleName, lastName, username, studentid,grade,studentDistrictId) are displayed correctly" );
                Log.testCaseInfo( "Verify the Grade details(GradeId and Grade Name) are displayed correctly" );
                Log.testCaseInfo( "Verify the response student district id fields are returned correctly" );
                Log.testCaseInfo( "Verify the API success message is displayed correctly" );

                verifyResponse( response3, studentRumbaIds3 );
                Log.testCaseInfo( "Verify the student details are reflected correctly in CMS" );

                Log.pass( "Create Group - " + response3.get( Constants.REPORT_BODY ) );

                // Schema validation
                Log.assertThat( new SMAPIProcessor().isSchemaValid( studentsNotPartofGroupsAPIConstants.STUDENT_DETAILS_SCHEMA, statusCode, response3.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

            case "SHARED GROUP":
                HashMap<String, String> studentDetails7 = new HashMap<String, String>();
                HashMap<String, String> viewGroupDetails4 = new HashMap<String, String>();
                List<String> studentRumbaIds4 = new ArrayList<>();
                HashMap<String, String> userDetails4 = new HashMap<>();
                HashMap<String, String> groupDetails4 = new HashMap<>();
                HashMap<String, String> response4 = new HashMap<>();
                HashMap<String, String> createResponse4 = new HashMap<>();

                Log.testCaseInfo( "Verify the student details are not repeated in the API response(There should not be duplicate entries" );

                String className1 = "Customize Shared Group " + System.currentTimeMillis();
                // String orgId1 = RBSDataSetup.organizationIDs.get( school );

                List<String> teachers = new ArrayList<String>();
                teachers.add( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                teachers.add( SMUtils.getKeyValueFromResponse( secondTeacher, RBSDataSetupConstants.USERID ) );

                List<String> stuIDs = new ArrayList<String>();

                studentDetails7 = generateRequestValues( studentDetails7, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails7 = updateRequestBodyValues( studentDetails7, RBSDataSetupConstants.FIRSTNAME, RBSDataSetupConstants.FIRSTNAME + specialCharacter );
                studentDetails7 = updateRequestBodyValues( studentDetails7, RBSDataSetupConstants.MIDDLENAME, RBSDataSetupConstants.MIDDLENAME );
                studentDetails7 = updateRequestBodyValues( studentDetails7, RBSDataSetupConstants.LASTNAME, RBSDataSetupConstants.LASTNAME + specialCharacter );
                studentDetails7 = updateRequestBodyValues( studentDetails7, RBSDataSetupConstants.USERNAME, RBSDataSetupConstants.USERNAME + System.nanoTime() );
                studentDetails7 = updateRequestBodyValues( studentDetails7, CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, "ID" + specialCharacter );
                studentDetails7 = updateRequestBodyValues( studentDetails7, UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                studentDetails7 = updateRequestBodyValues( studentDetails7, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails7 = updateRequestBodyValues( studentDetails7, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                studentDetails7 = updateRequestBodyValues( studentDetails7, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                createStudentResponse = new UserAPI().createStudent( smUrl, studentDetails7 );
                String sharedStudentID2 = SMUtils.getKeyValueFromResponse( createStudentResponse.get( Constants.REPORT_BODY ), Constants.PERSON_ID_DATAVALUE );

                studentRumbaIds4.add( sharedStudentID2 );

                // group created with Third party application
                groupDetails4.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
                groupDetails4.put( RBSDataSetupConstants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails4.put( RBSDataSetupConstants.SECTION_NAME, className1 );
                groupDetails4.put( RBSDataSetupConstants.STUDENT_PI_ID, sharedStudentID2 );

                String createClassWithMultipleTeacher1 = rbs.createClassWithMultipleTeacher( groupDetails4, teachers, studentRumbaIds4);
                JSONObject jsonnObject2 = new JSONObject( createClassWithMultipleTeacher1 );
                String classId2 = jsonnObject2.getJSONObject( CreateGroupAPIConstants.DATA ).getJSONObject( CreateGroupAPIConstants.SECTION ).get( CreateGroupAPIConstants.ID ).toString();

                viewGroupDetails4.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                viewGroupDetails4.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                viewGroupDetails4.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                viewGroupDetails4.put( CreateGroupAPIConstants.GROUP_ID, classId2 );
                withStudent = true;
                
                response4 = getStudentDetailsforGroup( smUrl, viewGroupDetails4 );
                Log.assertThat( response4.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response4.get( Constants.STATUS_CODE ) );

                Log.message( "Actual response:" + response4 );
                Log.message( "Expected response:" + studentRumbaIds4 );
                Log.testCaseInfo( "Verify the Student details( id, firstName, middleName, lastName, username, studentid,grade,studentDistrictId) are displayed correctly" );
                Log.testCaseInfo( "Verify the Grade details(GradeId and Grade Name) are displayed correctly" );
                Log.testCaseInfo( "Verify the response student district id fields are returned correctly" );
                Log.testCaseInfo( "Verify the API success message is displayed correctly" );

                verifyResponse( response4, studentRumbaIds4 );
                Log.testCaseInfo( "Verify the student details are reflected correctly in CMS" );

                Log.pass( "Create Group - " + response4.get( Constants.REPORT_BODY ) );

                // Schema validation
                Log.assertThat( new SMAPIProcessor().isSchemaValid( studentsNotPartofGroupsAPIConstants.STUDENT_DETAILS_SCHEMA, statusCode, response4.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );


                break;

        }

             // HashMap<String, String> expResponse = new
        // BaseAPITest().getStudentDetailsByStudentId( studentId,
        // SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID
        // ), RBSDataSetup.organizationIDs.get( school ), token );
       
        // Log.testCaseResult();
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "viewGroupPositiveScenariosData" )
    public Object[][] createGroupData() {

        Object[][] inputData = { { "Verify the API response for valid data", "GROUP WITH STUDENTS", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the API response after one student is deleted from the group", "REMOVE STUDENT FROM GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the response when the group have shared students", "SHARED STUDENT GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can able to see the students part of group that has two teachers.", "SHARED GROUP", CommonAPIConstants.STATUS_CODE_OK },

        };
        return inputData;
    }

    /**
     * To test the negative scenarios of create group API
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( dataProvider = "viewGroupNegativeScenariosData", groups = { "SMK-50857", "Group", "View Group", "P2", "API" } )
    public void tcViewGroup002( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> viewGroupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> userDetails = new HashMap<>();
        HashMap<String, String> createGroupResponse = new HashMap<>();

        String groupName = "Successmaker API Test Group " + System.nanoTime();
        String exception = null;
        boolean status = false;
        String message = null;

        switch ( scenario ) {

            case "STUDENT AUTHORIZATION":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                createGroupResponse = createGroup( smUrl, groupDetails, studentRumbaIds );
                String sharedstudgrp = SMUtils.getKeyValueFromResponse( createGroupResponse.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( studentUsername1, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, studentId1 );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, sharedstudgrp );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "INVALID GROUPID":
                String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                String emptygroupId = createEmptyGroup( groupName, teacherId, orgId, token );

                viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, getGroupListAPIConstants.INVALID_INPUT );
                exception = CommonAPIConstants.NO_CMS_CLASS_EXCEPTION;
                message = CommonAPIConstants.SECTION_ID_NOTFOUND_MESSAGE;
                status = true;
                break;

            case "INVALID TOKEN":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                createGroupResponse = createGroup( smUrl, groupDetails, studentRumbaIds );
                String InvalidTokengroupId = SMUtils.getKeyValueFromResponse( createGroupResponse.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, getGroupListAPIConstants.INVALID_INPUT );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, InvalidTokengroupId );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "EMPTY GROUPID":

                Log.testCaseInfo( "Verify the API response when student data is not available for the given groupId" );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                createGroupResponse = createGroup( smUrl, groupDetails, studentRumbaIds );
                String emptygroupId2 = SMUtils.getKeyValueFromResponse( createGroupResponse.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, emptygroupId2 );
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.STUDENT_LIST_NOT_FOUND;
                status = true;
                break;

            case "OTHER TEACHER GROUPID":

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                createGroupResponse = createGroup( smUrl, groupDetails, studentRumbaIds );
                String emptygroupId3 = SMUtils.getKeyValueFromResponse( createGroupResponse.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, emptygroupId3 );
                exception = CommonAPIConstants.NO_CMS_CLASS_EXCEPTION;
                message = CommonAPIConstants.SECTION_ID_NOTFOUND_MESSAGE;
                status = true;
                break;

            case "NO_SM_PRODCUT":
                String className = "ClasstoNoSMprod" + System.nanoTime();
                String accessCode = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                String orphanStudent = "orphanStudent" + System.nanoTime();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, orphanStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                String noProdStud = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                String noProdGrp = new RBSUtils().CreateClassWithoutSMProdcut( className, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ), noProdStud, RBSDataSetup.organizationIDs.get( school ), accessCode );
                viewGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                viewGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, noProdGrp );
                exception = CommonAPIConstants.NULL_POINTER_EXCEPTION;
                message = CommonAPIConstants.EMPTY_STRING;
                status = true;
                break;

        }

        HashMap<String, String> response = getStudentDetailsforGroup( smUrl, viewGroupDetails );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + response.get( Constants.REPORT_BODY ) );
        verifyException( response.get( Constants.REPORT_BODY ), exception, status, message );

        // Schema validation
        if ( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_OK ) ) {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( studentsNotPartofGroupsAPIConstants.STUDENT_DETAILS_SCHEMA, CommonAPIConstants.STATUS_CODE_BAD_REQUEST, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.",
                    "Schema is not as expected." );
        } else {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( studentsNotPartofGroupsAPIConstants.STUDENT_DETAILS_SCHEMA, statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        }
        Log.testCaseResult();
    }

    /**
     * Data provider to give the data of negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "viewGroupNegativeScenariosData" )
    public Object[][] createGroupDataInvalid() {

        // Commented cases are has future backlog tickets since its excluded from
        // execution
        Object[][] inputData = {

                { "Verify the API returning 403 when the authentications is invalid.", "STUDENT AUTHORIZATION", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the API when invalid group Id is passed", "INVALID GROUPID", CommonAPIConstants.STATUS_CODE_NOTFOUND },
                { "Verify the API throwing exception when the authorization is invalid.", "INVALID TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the API throwing exception when the authorization is invalid.", "EMPTY GROUPID", CommonAPIConstants.STATUS_CODE_OK },
                // { "Verify the API throwing exception when the authorization is invalid.",
                // "OTHER TEACHER GROUPID", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                // { "Verify the API response, if the group with students doesn't have the
                // SuccessMaker product", "NO_SM_PRODCUT", CommonAPIConstants.STATUS_CODE_OK },

        };
        return inputData;
    }

    /**
     * Verify the response data
     * 
     * @param expectedResponse
     * @param actualResponse
     * @param withStudent
     * @return
     */
    public void verifyResponse( HashMap<String, String> response, List<String> studentRumbaIds ) {
        // User Details

        boolean isVerified = false;
        try {
            List<String> actStudentIds = new SMAPIProcessor().getKeyValues( new JSONObject( response.get( DeleteGroupAPIConstants.BODY_FIELD ) ), StudentDetailsForStudentIdAPIConstants.ID_STUDENT );
            Log.message( "actual:" + actStudentIds );
            Log.message( "exp:" + studentRumbaIds );
            if ( ( actStudentIds.size() == studentRumbaIds.size() ) ) {
                isVerified = true;
                Log.assertThat( ( isVerified ), "The User Details is  matched ", "The User Details is not  matched" );
                getExpectedUserDetailsHashMap( studentRumbaIds, response );

            } else {
                getExpectedUserDetailsHashMap( studentRumbaIds, response );

            }

        } catch ( Exception e ) {

        }
    }

    /**
     * To validate the student fields from response
     * 
     * @param userIds
     * @param response
     * @throws Exception
     * 
     * 
     */

    public void getExpectedUserDetailsHashMap( List<String> userIds, HashMap<String, String> response ) throws Exception {

        List<String> firstNameExpValue = new ArrayList<>();
        List<String> middleNameExpValue = new ArrayList<>();
        List<String> lastNameExpValue = new ArrayList<>();
        List<String> userNameExpValue = new ArrayList<>();
        List<String> studentIdExpValue = new ArrayList<>();
        List<String> personIdExpValue = new ArrayList<>();

        JSONObject userJsonObjectAct = new JSONObject( response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) );

        List<String> firstNameActValue = new ArrayList<>();
        List<String> middleNameActValue = new ArrayList<>();
        List<String> lastNameActValue = new ArrayList<>();
        List<String> userNameActValue = new ArrayList<>();
        List<String> studentIdActValue = new ArrayList<>();
        List<String> personIdActValue = new ArrayList<>();

        firstNameActValue = new SMAPIProcessor().getKeyValues( userJsonObjectAct, StudentDetailsForStudentIdAPIConstants.FIRST_NAME );
        middleNameActValue = new SMAPIProcessor().getKeyValues( userJsonObjectAct, StudentDetailsForStudentIdAPIConstants.MIDDLE_NAME );
        lastNameActValue = new SMAPIProcessor().getKeyValues( userJsonObjectAct, StudentDetailsForStudentIdAPIConstants.LAST_NAME );
        userNameActValue = new SMAPIProcessor().getKeyValues( userJsonObjectAct, StudentDetailsForStudentIdAPIConstants.USERNAME.toLowerCase() );
        studentIdActValue = new SMAPIProcessor().getKeyValues( userJsonObjectAct, StudentDetailsForStudentIdAPIConstants.STUDENT_ID );
        personIdActValue = new SMAPIProcessor().getKeyValues( userJsonObjectAct, StudentDetailsForStudentIdAPIConstants.ID_STUDENT );

        for ( String userId : userIds ) {
            String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
            HashMap<String, String> expResponse = new UserAPI().getStudentDetailsByStudentId( userId, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ), RBSDataSetup.organizationIDs.get( school ), token );
            JSONObject userJsonObjectExp = new JSONObject( expResponse.get( Constants.REPORT_BODY ) );

            String classDataFromCMS = new RBSUtils().getUser( userId );

            firstNameExpValue.add( new SMAPIProcessor().getKeyValues( userJsonObjectExp, StudentDetailsForStudentIdAPIConstants.FIRST_NAME ).get( 0 ) );
            lastNameExpValue.add( new SMAPIProcessor().getKeyValues( userJsonObjectExp, StudentDetailsForStudentIdAPIConstants.LAST_NAME ).get( 0 ) );
            middleNameExpValue.add( new SMAPIProcessor().getKeyValues( userJsonObjectExp, StudentDetailsForStudentIdAPIConstants.MIDDLE_NAME ).get( 0 ) );
            userNameExpValue.add( new SMAPIProcessor().getKeyValues( userJsonObjectExp, StudentDetailsForStudentIdAPIConstants.USERNAME ).get( 0 ) );
            studentIdExpValue.add( new SMAPIProcessor().getKeyValues( userJsonObjectExp, StudentDetailsForStudentIdAPIConstants.STUDENT_IDENTIFICATION_NO ).get( 0 ) );
            personIdExpValue.add( new SMAPIProcessor().getKeyValues( userJsonObjectExp, StudentDetailsForStudentIdAPIConstants.PERSON_ID ).get( 0 ) );

            // Grade Values
            String expGrade;
            String actGrade = new SMAPIProcessor().getKeyValues( userJsonObjectAct, StudentDetailsForStudentIdAPIConstants.GRADE_NAME_STRING ).get( 0 );
            String gradeName = null;

            try {
                expGrade = new SMAPIProcessor().getKeyValues( userJsonObjectExp, StudentDetailsForStudentIdAPIConstants.GRADE ).get( 0 );
            } catch ( Exception e ) {
                expGrade = null;
            }
            if ( expGrade != null ) {
                int indexOfGrade = StudentDetailsForStudentIdAPIConstants.GRADE_NAME.indexOf( expGrade );
                Log.message( "exp:" +StudentDetailsForGivenTeacherConstants.GRADE_NAMES_DROPDOWN.get( indexOfGrade ));
                Log.message( "act:" +actGrade);
                Log.assertThat( StudentDetailsForGivenTeacherConstants.GRADE_NAMES_DROPDOWN.get( indexOfGrade ).equals( actGrade.trim() ), "The Grade value is matching", "The grade value is not matching" );
            } else {
                Log.assertThat( actGrade.equals( StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED ), "The Grade value is NOT_SPECIFIED", "The grade value is not NOT_SPECIFIED" );
            }

            // student district id
            String actDistrictId = new SMAPIProcessor().getKeyValues( userJsonObjectAct, StudentDetailsForStudentIdAPIConstants.STUDENT_DISTRICT_ID ).get( 0 );
            String expDistrictId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );

            if ( actDistrictId != null ) {
                Log.message( "exp:" + expDistrictId + "act:" + actDistrictId );
                Log.assertThat( actDistrictId.trim().equals( expDistrictId.trim()), "The Student District id value is matched", "The Student District id value is not matched" );

            }

        }

        if ( personIdExpValue.size() == personIdActValue.size() ) {
            Log.assertThat( SMUtils.compareTwoList( firstNameExpValue, firstNameActValue ), "The firstName is matching as expected!", "The firstName is not matching" );
            Log.assertThat( SMUtils.compareTwoList( lastNameExpValue, lastNameActValue ), "The lastName is matching as expected!", "The lastName is not matching" );
            Log.assertThat( SMUtils.compareTwoList( userNameExpValue, userNameActValue ), "The userName is matching as expected!", "The userName is not matching" );
            Log.assertThat( SMUtils.compareTwoList( studentIdExpValue, studentIdActValue ), "The studentId is matching as expected!", "The studentId is not matching" );
            Log.assertThat( SMUtils.compareTwoList( personIdExpValue, personIdActValue ), "The personId is matching as expected!", "The personId is not matching" );
        }
    }

    /**
     * This methods will update the details whatever given in Key and value
     * 
     * @param studentDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> updateRequestBodyValues( HashMap<String, String> studentDetails, String key, String value ) {
        HashMap<String, String> generatedStudentDetails = studentDetails;
        if ( generatedStudentDetails.containsKey( key ) ) {
            generatedStudentDetails.put( key, value );
        } else {
            generatedStudentDetails.put( key, value );
        }
        return generatedStudentDetails;
    }

    /**
     * This method used to generate the intial values for the request
     * 
     * @param studentDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> generateRequestValues( HashMap<String, String> studentDetails, String key, String value ) {
        HashMap<String, String> generatedStudentDetails = studentDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, new Faker().name().firstName() );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, new Faker().name().firstName().substring( 1 ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, new Faker().name().lastName() );
        generatedStudentDetails.put( CreateStudentAPIConstants.GRADE, grade.FIRST.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, new Faker().name().username() );
        generatedStudentDetails.put( CreateStudentAPIConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( CreateStudentAPIConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.ETHINICITY, ethnicity.NOT_SPECIFIED.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( GetUserDetailsUsingUserServiceAPIConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        return generatedStudentDetails;
    }

}
