package com.savvas.sm.teacher.ui.tests.MasterySuite;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

public class MasteryScreenChangesTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String username = null;
    private String password = DataSetupConstants.DEFAULT_PASSWORD;
    private static String teacherDetails;
    private static String studentDetails;
    private static String studentOne;
    private static String studentTwo;
    private static String studentThree;
    private static String studentFour;
    private static String studentFive;
    private static String studentSix;
    private static String studentSeven;
    private String chromePlatform = "Windows_10_Chrome_latest"; // for Simulator
                                                                // Execution
    String teacherId;
    String orgId;
    List<WebElement> masteredProgressBars;
    String testMethodName;

    @BeforeClass
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher89" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        studentDetails = DataSetup.teacherStudentMap.get( username ).get( "Student1" );
        studentOne = ( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student2" ), "data,userName" ) );
        studentTwo = ( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student3" ), "data,userName" ) );
        studentThree = ( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student4" ), "data,userName" ) );
        studentFour = ( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student5" ), "data,userName" ) );
        studentFive = ( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student6" ), "data,userName" ) );
        studentSix = ( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student7" ), "data,userName" ) );
        studentSeven = ( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student8" ), "data,userName" ) );
        // to create data
        attendCourseAsStudent();
    }

    @Test ( description = "On clicking 'Apply Filters' button on Mastery Page, verify teacher is able to see the 'Mastered', 'At Risk', 'Not Mastered', and 'Unassessed' breakdown per skills progress bar", groups = { "SMK-42845", "mastery",
            "Mastery Screen Changes" }, priority = 1 )
    public void tcMasteryScreens001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( "tcMasteryScreens001:On clicking 'Apply Filters' button on Mastery Page, verify teacher is able to see the 'Mastered', 'At Risk', 'Not Mastered', and 'Unassessed' breakdown per skills progress bar  <small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            List progressBar = masterySummaryComponent.getAvailableProgressBarShadow();

            Log.assertThat( masterySummaryComponent.isSkillDetailsPresentInProgressBarToolTip(), "Teacher is able to see skill in tool tip as Mastered', 'At Risk', 'Not Mastered', and 'Unassessed' ",
                    "Teacher is able to see skill in tool tip as Mastered', 'At Risk', 'Not Mastered', and 'Unassessed'" );
            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify total number of the students assessement taken is equal to the sum of 'Mastered', 'At Risk' and 'Not Mastered' students ", groups = { "SMK-42845", "mastery", "Mastery Screen Changes" }, priority = 1 )
    public void tcMasteryScreens002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( "tcMasteryScreens002: Verify total number of the students assessement taken is equal to the sum of 'Mastered', 'At Risk' and 'Not Mastered' students <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );
            SMUtils.nap( 3 );
            List<String> studentAssement = masterySummaryComponent.getStudentAssessmentOfLeafNodeLO();

            List<String> listassesmentcount = masterySummaryComponent.getStudentAssessmentCount();

            Log.assertThat( studentAssement.equals( listassesmentcount ),
                    "The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar ",
                    " The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is not matching with TOTAL count of students have taken assessment displayed above the progress bar" );
            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "On Mouse hovering on Progress bar, Verify tooltip message is displaying", groups = { "SMK-42844", "mastery", "Mastery Screen Changes" }, priority = 1 )
    public void tcMasteryScreens003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( "tcMasteryScreens003: On Mouse hovering on Progress bar, Verify tooltip message is displaying <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
            masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            Log.assertThat( masterySummaryComponent.isSkillDetailsPresentInProgressBarToolTip(), "On Mouse hovering on Progress bar-Tool-tip is present", "On Mouse hovering on Progress bar-Tool-tip is present" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public void attendCourseAsStudent() throws Exception {
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);
        try {
            BaseAPITest baseApiObject = new BaseAPITest();
            String sessionCookie = baseApiObject.getJessionCookie( smUrl, username, password );
            String teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" );
            List<String> studentIdList = new ArrayList<>();
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails, "data,personId" ) );
            baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.MATH, DataSetup.organizationId.toString(), teacherId, "1", studentIdList );
            baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.READING, DataSetup.organizationId.toString(), teacherId, "2", studentIdList );

            LoginPage smLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentsPage = smLoginPage.loginToSMasStudent( SMUtils.getKeyValueFromResponse( studentDetails, "data,userName" ), password, false );
            studentsPage.executeMathCourse( username, Constants.MATH, "100", "2", "20" );
            studentsPage.executeMathCourse( username, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 89 ), "100", "2", "20" );
            studentsPage.executeMathCourse( username, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, 89 ), "100", "2", "20" );
            studentsPage.executeReadingCourse( username, Constants.READING, "100", "2", "20" );
            studentsPage.executeReadingCourse( username, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, 89 ), "100", "2", "20" );
            studentsPage.executeReadingCourse( username, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, 89 ), "100", "2", "20" );
            studentsPage.logout();
        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        } finally {
            chromeDriver.quit();
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the color code on mastery status  ", groups = { "SMK-42844", "mastery", "Mastery Screen Changes" }, priority = 1 )
    public void tcMasteryScreens004() throws Exception {
        // Get driver
        EventFiringWebDriver driver = null;
        EventFiringWebDriver chromeDriver; // for simulator run
        testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( "tcMasteryScreens004: Verify on progress bar, Respective colours is filled fully if all students are 'Mastered', 'Not Mastered', ' At Risk' in that skill <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Login as student1 to the executeCourses
    		chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		EventListener eventListner = new EventListener();
    		chromeDriver.register(eventListner);

            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage = smStudentLoginPage.loginToSMasStudent( studentTwo, password, true );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 89 ), "100", "2", "15" );
            studentOneDashboardPage.logout();
            chromeDriver.quit();

            // Login as student2 to the executeCourses
            Log.message( "Executing the courses using simulator for student2" );
    		chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            LoginPage smStudentLoginPage2 = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage2 = smStudentLoginPage2.loginToSMasStudent( studentThree, password, true );
            studentOneDashboardPage2.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 89 ), "25", "3", "10" );
            studentOneDashboardPage2.logout();
            chromeDriver.quit();

            // Login as student3 to the executeCourses
            Log.message( "Executing the courses using simulator for student3" );
    		chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            LoginPage smStudentLoginPage3 = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage3 = smStudentLoginPage3.loginToSMasStudent( studentFour, password, true );
            studentOneDashboardPage3.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 89 ), "20", "8", "10" );
            studentOneDashboardPage3.logout();
            chromeDriver.quit();

            // Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
            masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            Log.assertThat( masterySummaryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.MASTERED_COLOR_CODE.toLowerCase() ), "Mastered status is indicated by Green color in the progress bar ",
                    "Mastered status is not indicated by Green color in the progress bar " );

            SMUtils.logDescriptionTC( "Verify the progress bar, 'At Risk' status is indicated by Yellow color" );
            Log.assertThat( masterySummaryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.ATRISK_COLOR_CODE.toLowerCase() ), "At Risk status is indicated by Yellow color in the progress bar ",
                    "At Risk status is not indicated by Yellow color in the progress bar " );
            SMUtils.logDescriptionTC( "Verify the progress bar, 'At Risk' status is indicated by Yellow color" );
            Log.assertThat( masterySummaryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.UNASSESSED_COLOR_CODE.toLowerCase() ), "Unassessed status is indicated by grey color in the progress bar ",
                    "Unassessed status is not indicated by grey color in the progress bar " );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 3, groups = { "SMK-42844", "mastery", "Mastery Screen Changes" } )
    public void tcMasteryScreens005() throws Exception {
        // Get driver
        EventFiringWebDriver driver = null;
        EventFiringWebDriver chromeDriver; // for simulator run
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Login as student4 to the executeCourses
    		chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		EventListener eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            LoginPage smStudentLoginPage4 = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage4 = smStudentLoginPage4.loginToSMasStudent( studentFive, password, true );
            studentOneDashboardPage4.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 89 ), "100", "2", "15" );
            studentOneDashboardPage4.logout();
            chromeDriver.quit();

            // Login as student5 to the executeCourses
            Log.message( "Executing the courses using simulator for student2" );
    		chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            LoginPage smStudentLoginPage5 = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage5 = smStudentLoginPage5.loginToSMasStudent( studentSix, password, true );
            studentOneDashboardPage5.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 89 ), "25", "3", "10" );
            studentOneDashboardPage5.logout();
            chromeDriver.quit();

            // Login as student6 to the executeCourses
            Log.message( "Executing the courses using simulator for student3" );
    		chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            LoginPage smStudentLoginPage6 = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage6 = smStudentLoginPage6.loginToSMasStudent( studentSeven, password, true );
            studentOneDashboardPage6.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, 89 ), "20", "8", "10" );
            studentOneDashboardPage6.logout();
            chromeDriver.quit();

            // Get driver
            // Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
            masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            SMUtils.nap( 3 );
            List<String> studentAssement = masterySummaryComponent.getStudentAssessmentOfLeafNodeLO();
            List<String> listassesmentcount = masterySummaryComponent.getStudentAssessmentCount();

            Log.assertThat( studentAssement.equals( listassesmentcount ),
                    "The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar ",
                    " The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is not matching with TOTAL count of students have taken assessment displayed above the progress bar" );

            SMUtils.logDescriptionTC( "Verify the detailed mastery status link is available next to the progress bar" );
            Log.assertThat( !masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED ).isEmpty(), "The detailed Mastery status link is available next to the progress bar",
                    "The detailed Mastery status link is not available next to the progress bar!" );

            SMUtils.logDescriptionTC( " Verify the number of students mastery status and progress bar is displaying for each skill/standard" );
            SMUtils.logDescriptionTC( " Verify the number of students mastery status is displaying for each skill/standard" );
            Log.assertThat( masterySummaryComponent.getStudentAssessmentOfLeafNodeLO().stream().allMatch( studentCount -> !studentCount.isEmpty() ), "The number of students mastery status is displaying for each skill/standard",
                    "The number of students mastery status is not getting displayed for each skill/standard" );

            SMUtils.logDescriptionTC( "Verify the progress bar is displayed for the skill/standards avaialble" );
            List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );
            Log.assertThat( !masteredProgressBars.isEmpty(), "Progress bar is getting displayed for the skills/standards available", "Progress bar is not getting displayed for the skills/standards available!" );

            // Sign Out
            // signOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
