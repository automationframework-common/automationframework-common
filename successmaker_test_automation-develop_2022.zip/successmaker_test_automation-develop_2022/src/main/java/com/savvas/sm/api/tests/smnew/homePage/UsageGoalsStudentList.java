package com.savvas.sm.api.tests.smnew.homePage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.restoreassignment.RestoreAssignment;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.homepage.HomePage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.*;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class UsageGoalsStudentList extends EnvProperties {
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String teacherUsername;
    private String teacherAccessToken;
    private String mathAssignmentId;
    private String firstMathAssignmentUserId;
    private String secondMathAssignmentUserId;
    private String readingAssignmentId;
    private String firstReadingAssignmentUserId;
    private String secondReadingAssignmentUserId;
    private String firstStudentUserName;
    private String secondStudentUserName;

    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private static HashMap<String, String> mathAssignmentDetails = new HashMap<>();
    private static HashMap<String, String> readingAssignmentDetails = new HashMap<>();

    private Map<String, String> response = new HashMap<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    AssignmentAPI assign = new AssignmentAPI();
    HomePage homePage = new HomePage();

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        // Getting teacher details
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, password );
        Log.message( "Teacher access token: " + teacherAccessToken );

        // getting student details
        String studentDetails1 = RBSDataSetup.getMyStudent( school, teacherUsername );
        String studentDetails2 = RBSDataSetup.getMyStudent( school, teacherUsername );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails1, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails2, "userId" ) );

        firstStudentUserName = SMUtils.getKeyValueFromResponse( studentDetails1, "userName" );
        secondStudentUserName = SMUtils.getKeyValueFromResponse( studentDetails2, "userName" );

        // Getting group details
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" + System.nanoTime() );
        // Creating a group
        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        // Assigning Math assignment
        mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        mathAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
        HashMap<String, String> mathRssignmentResponse = assign.assignMultipleAssignments( smUrl, mathAssignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );
        Log.message( mathRssignmentResponse.toString() );

        // Getting assignment id
        JSONObject mathAssignmentDetailsJson = new JSONObject( mathRssignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject mathAssignmentInfo = new JSONObject( mathAssignmentList.get( 0 ).toString() );
        mathAssignmentId = mathAssignmentInfo.get( "assignmentId" ).toString();
        firstMathAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), mathAssignmentId );
        secondMathAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 1 ), mathAssignmentId );

        // Assigning Reading assignment
        readingAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        readingAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        readingAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
        readingAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
        HashMap<String, String> readingAssignmentResponse = assign.assignMultipleAssignments( smUrl, readingAssignmentDetails, studentRumbaIds, Arrays.asList( "2" ) );

        // Getting assignment id
        JSONObject readingAssignmentDetailsJson = new JSONObject( readingAssignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray readingAssignmentList = readingAssignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject readingAssignmentInfo = new JSONObject( readingAssignmentList.get( 0 ).toString() );
        readingAssignmentId = readingAssignmentInfo.get( "assignmentId" ).toString();
        firstReadingAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), readingAssignmentId );
        secondReadingAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 1 ), readingAssignmentId );

    }

    @Test ( dataProvider = "getMathDataforPostive", priority = 1, groups = { "smoke_test_case", "SMK-51805", "Dashboard", "UsageGoal", "API" } )
    public void getUsageGoal_Positive_Math( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseID + " - " + testDescription );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, teacherId );
        headers.put( UserConstants.ORGID, orgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken );

        switch ( scenario ) {
            case "MULTI_STUDENT_MATH":
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstMathAssignmentUserId, secondMathAssignmentUserId ), "1" );
                break;

            case "NOT_ATTENDED_MATH":
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstMathAssignmentUserId ), "1" );
                break;

            case "EDIT_USAGE_MATH":
                new HomePage().putEditUsageGoal( smUrl, teacherAccessToken, orgId, teacherId, "2022-08-25", "10", Arrays.asList( firstMathAssignmentUserId ), "" );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstMathAssignmentUserId ), "1" );
                break;

            case "EDIT_STUDENT_NAME":
                UserAPI userAPI = new UserAPI();
                String firstName = new Faker().name().firstName();
                String lastName = new Faker().name().lastName();

                HashMap<String, String> studentInfo = new HashMap<>();
                studentInfo = generateRequestValues( new RBSUtils().getUser( studentRumbaIds.get( 0 ) ), studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                // Updating student first and last name
                String responce = userAPI.updateStudentProfile( smUrl, studentInfo ).get( Constants.STATUS_CODE );

                Log.assertThat( responce.equalsIgnoreCase( "200" ), "Student name is updated successfully", "There is an error on updating Student name" );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstReadingAssignmentUserId ), "2" );

                String studentDetail = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,student" );
                Log.assertThat( !SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ).equals( firstName ), "First name is updated successfully!", "First name is not updated" );
                Log.assertThat( !SMUtils.getKeyValueFromResponse( studentDetail, "lastName" ).equals( lastName ), "Last name is updated successfully!", "Last name is not updated" );
                break;

            case "ATTEND_MATH_ASSIGNMENT":
                // Executing assignment in simulator
                executeSimulator( firstStudentUserName, Constants.MATH, true, "20" );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstMathAssignmentUserId ), "1" );
                break;

            case "RESTORE_MATH_ASSIGNMENT":
                // Removing math assignment
                HashMap<String, String> assignmentDetailMath = new HashMap<>();
                assignmentDetailMath.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetailMath.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetailMath.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentDetailMath.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, firstMathAssignmentUserId );
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetailMath, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

                //Restore Math assignmnet
                HashMap<String, String> userDetail = new HashMap<>();
                userDetail.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
                userDetail.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                userDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, firstMathAssignmentUserId );
                Log.assertThat( new RestoreAssignment().restoreDeletedAssignment( smUrl, userDetail, CourseAPIConstants.NULL ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment restored sucessfully!", "Issue in restoring the assignment!" );

                // Get Usage Goal Student list
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstMathAssignmentUserId ), "1" );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,assignmentUserId" ).equals( firstMathAssignmentUserId ), "Math assginment is restored successfuly", "Math assginment is not restored" );
                break;

            case "MATH_IPM_COMPLETED":
                // Executing assignment in simulator
                executeSimulator( firstStudentUserName, Constants.MATH, true, "95" );
                FixupFunction.executeFixupFunctions( orgId );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstMathAssignmentUserId ), "1" );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,ipmStatus" ).equals( "complete" ), "IPM is displayed as complete", "IPM is not displayed as complete" );
                break;

        }

        // Validating Status Code
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        //Schema Validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "usageGoalStudentList", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
        // Data Validation
        String goalBucket = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,goalBucket" );
        String ipmStatus = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,ipmStatus" );
        if ( !( scenario.equals( "MATH_IPM_COMPLETED" ) || scenario.equals( "READING_IPM_COMPLETED" ) ) ) {
            Log.assertThat( goalBucket.equals( "NA" ) || ipmStatus.equalsIgnoreCase( "pending" ), "goalBucket and ipmStatus are same as excepted", "goalBucket and ipmStatus are not same as excepted" );
        }

    }

    @Test (enabled=false, dataProvider = "getReadingDataforPostive", priority = 1, groups = { "smoke_test_case", "SMK-51805", "Dashboard", "UsageGoal", "API" } )
    public void getUsageGoal_Positive_Reading( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseID + " - " + testDescription );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, teacherId );
        headers.put( UserConstants.ORGID, orgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken );

        switch ( scenario ) {
            case "SINGLE_STUDENT_READING":
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstReadingAssignmentUserId ), "2" );
                break;

            case "MULTI_STUDENT_READING":
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstReadingAssignmentUserId, secondReadingAssignmentUserId ), "2" );
                break;

            case "NOT_ATTENDED_READING":
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstReadingAssignmentUserId ), "2" );
                break;

            case "EDIT_USAGE_READING":
                new HomePage().putEditUsageGoal( smUrl, teacherAccessToken, orgId, teacherId, "2022-08-25", "10", Arrays.asList( firstReadingAssignmentUserId ), "" );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstReadingAssignmentUserId ), "2" );
                break;

            case "ATTEND_READING_ASSIGNMENT":
                // Executing assignment in simulator
                executeSimulator( firstStudentUserName, Constants.MATH, true, "5" );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstReadingAssignmentUserId ), "2" );
                break;

            case "RESTORE_READING_ASSIGNMENT":
                //remove Reading assignment for student
                HashMap<String, String> assignmentDetailReading = new HashMap<>();
                assignmentDetailReading.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetailReading.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetailReading.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
                assignmentDetailReading.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, firstReadingAssignmentUserId );
                Log.assertThat( new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetailReading, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "student assignment removed sucessfully!", "Issue in removing the student assignment" );

                //Restore Reading assignmnet
                HashMap<String, String> adminUserDetail = new HashMap<>();
                adminUserDetail.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
                adminUserDetail.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                adminUserDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                adminUserDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, firstReadingAssignmentUserId );
                Log.assertThat( new RestoreAssignment().restoreDeletedAssignment( smUrl, adminUserDetail, CourseAPIConstants.NULL ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment restored sucessfully!", "Issue in restoring the assignment!" );

                // Get Usage Goal Student list
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstReadingAssignmentUserId ), "2" );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,assignmentUserId" ).equals( firstReadingAssignmentUserId ), "Reading assginment is restored successfuly", "Reading assginment is not restored" );
                break;

            case "READING_IPM_COMPLETED":
                // Executing assignment in simulator
                executeSimulator( firstStudentUserName, Constants.READING, true, "95" );
                FixupFunction.executeFixupFunctions( orgId );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstReadingAssignmentUserId ), "2" );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,ipmStatus" ).equals( "complete" ), "IPM is displayed as complete", "IPM is not displayed as complete" );
                break;

        }

        // Validating Status Code
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        //Schema Validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "usageGoalStudentList", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
        // Data Validation
        String goalBucket = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,goalBucket" );
        String ipmStatus = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,ipmStatus" );
        if ( !( scenario.equals( "MATH_IPM_COMPLETED" ) || scenario.equals( "READING_IPM_COMPLETED" ) ) ) {
            Log.assertThat( goalBucket.equals( "NA" ) || ipmStatus.equalsIgnoreCase( "pending" ), "goalBucket and ipmStatus are same as excepted", "goalBucket and ipmStatus are not same as excepted" );
        }

    }

    @Test ( priority = 2, dataProvider = "getDataforNegative", groups = { "SMK-52120", "Students", "Student Usage", "P2", "API" } )
    public void tcNegativeTestcases( String tcId, String description, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        switch ( scenario ) {

            case "INVALID_TOKEN":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken + "Invalid" );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstMathAssignmentUserId ), "1" );
                break;

            case "STUDENT_AUTHORIZATION":
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstMathAssignmentUserId ), "1" );
                break;

            case "INVALID_END_POINT":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId + "/invalid", Arrays.asList( firstMathAssignmentUserId ), "1" );
                break;

            case "INVALID_ORGID":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId + "Invalid", Arrays.asList( firstMathAssignmentUserId ), "1" );
                break;

            case "INVALID_USERID":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId + "Invalid", orgId, Arrays.asList( firstMathAssignmentUserId ), "1" );
                break;

            case "EMPTY_ASSIGNMENT_USERID":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList(), "1" );
                break;

            case "INVALID_ASSIGNMENT_USERID":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( "Invalid" ), "1" );
                break;

            case "EMPTY_SUBJECT_TYPE_ID":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList(), "" );
                break;

            case "INVALID_SUBJECT_TYPE_ID":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + teacherAccessToken );
                response = homePage.getUsageGoalStudentList( smUrl, headers, teacherId, orgId, Arrays.asList( firstMathAssignmentUserId ), "3" );
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;

        }
        Log.message( response.get( Constants.STATUS_CODE ) );
        //Status code validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        if ( !( scenario.equals( "INVALID_END_POINT" ) || scenario.equals( "INVALID_ASSIGNMENT_USERID" ) ) ) {
            //Schema Validation
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "usageGoalStudentList", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        }

    }

    @DataProvider ( name = "getMathDataforPostive" )
    public Object[][] getMathDataforPostive() {

        Object[][] data = { { "tcUsageGoalFullList001", "Verify the status code is 200 for fetching Full list of Usage Goals for Math Default Course if teacher having more than one student.", "200", "MULTI_STUDENT_MATH" },
                { "tcUsageGoalFullList002", "verify the Status Code is 200 and IPM Status is Pending, when the student is not attended the Math session so far.", "200", "NOT_ATTENDED_MATH" },
                { "tcUsageGoalFullList003", "After edit the Usage Goal for student, Verify the status code is 200 and Response body have edited Goal End Date and Target hours for Math Default Course", "200", "EDIT_USAGE_MATH" },
                { "tcUsageGoalFullList004", "After edit the First name and Last name for student, Verify the status code is 200 and Response body have edited first name and Last name.", "200", "EDIT_STUDENT_NAME" },
                { "tcUsageGoalFullList005",
                        "After Attended Some Sessions of Math Assignments for students, Verify the status code is 200 and Verify the actualMinutesInCourse, percentageActualTimeInCourse, averageMinutesPerWeek and AdditionalMinutesPerWeek in Response body",
                        "200", "ATTEND_MATH_ASSIGNMENT" },
                { "tcUsageGoalFullList006", "Verify the status code is 200 with response body when restored Math assignmentUserId is given in request body.", "200", "RESTORE_MATH_ASSIGNMENT" },
                { "tcUsageGoalFullList007", "verify the Status Code is 200 and IPM Status is Complete, when the student is Crossed the IPM for Math session.", "200", "MATH_IPM_COMPLETED" }, };
        return data;
    }

    @DataProvider ( name = "getReadingDataforPostive" )
    public Object[][] getReadingDataforPostive() {

        Object[][] data = { { "tcUsageGoalFullList008", "Verify the status code is 200 for fetching Full list of Usage Goals for Reading Default Courseif teacher having one student.", "200", "SINGLE_STUDENT_READING" },
                { "tcUsageGoalFullList009", "Verify the status code is 200 for fetching Full list of Usage Goals for Reading Default Course if teacher having more than one student.", "200", "MULTI_STUDENT_READING" },
                { "tcUsageGoalFullList010", "verify the Status Code is 200 and IPM Status is Pending, when the student is not attended the Reading session so far.", "200", "NOT_ATTENDED_READING" },
                { "tcUsageGoalFullList011", "After edit the Usage Goal for student, Verify the status code is 200 and Response body have edited Goal End Date and Target hours for Reading Default Course", "200", "EDIT_USAGE_READING" },
                { "tcUsageGoalFullList012",
                        "After Attended Some Sessions of Reading Assignments for students, Verify the status code is 200 and Verify the actualMinutesInCourse, percentageActualTimeInCourse, averageMinutesPerWeek and AdditionalMinutesPerWeek in Response body",
                        "200", "ATTEND_READING_ASSIGNMENT" },
                { "tcUsageGoalFullList013", "Verify the status code is 200 with response body when restored Reading assignmentUserId is given in request body.", "200", "RESTORE_READING_ASSIGNMENT" },
                { "tcUsageGoalFullList014", "verify the Status Code is 200 and IPM Status is Complete, when the student is Crossed the IPM for Reading session.", "200", "READING_IPM_COMPLETED" }, };
        return data;
    }

    @DataProvider ( name = "getDataforNegative" )
    public Object[][] getDataforNegative() {

        Object[][] data = { { "tcUsageGoalFullList015", "Verify the status code is 401 for invalid Authentication", "401", "INVALID_TOKEN" },
                { "tcUsageGoalFullList016", "Verify the status code is 403 for Student's Authorization.", "403", "STUDENT_AUTHORIZATION" },
                { "tcUsageGoalFullList017", "Verify the status code is 404 appears when wrong end point is given", "404", "INVALID_END_POINT" },
                { "tcUsageGoalFullList018", "Verify the status code is 400 appears when wrong organization Id are given", "400", "INVALID_ORGID" },
                { "tcUsageGoalFullList019", "Verify the status code is 400 appears when wrong staffID are given", "400", "INVALID_USERID" },
                { "tcUsageGoalFullList020", "Verify the status code is 400 appears when assignmnetUserId field is not given in the request body.", "400", "EMPTY_ASSIGNMENT_USERID" },
                { "tcUsageGoalFullList021", "Verify the status code is 400 appears when invalid assignmnetUserId is given in the request body.", "400", "INVALID_ASSIGNMENT_USERID" },
                { "tcUsageGoalFullList022", "Verify the status code is 400 appears when subjectTypeId field is not given in the request body.", "400", "EMPTY_SUBJECT_TYPE_ID" },
                { "tcUsageGoalFullList023", "Verify the status code is 400 appears when invalid subjectTypeId is given in the request body.", "400", "INVALID_SUBJECT_TYPE_ID" } };
        return data;
    }

    /**
     * Generating request values
     * 
     * @param studentExistingData
     * @param newDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeSimulator( String studentUserName, String courseName, boolean isMath, String Los ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "2", Los );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "2", Los );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        }
    }
}