package com.savvas.sm.teacher.ui.tests.HomeSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.HomePageWidgetConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * The JIRA ID of the story in this java class is SMK-43625
 * 
 * @author sandeep.pillai
 *
 */

@Listeners ( EmailReport.class )
public class HomePageMasteryFilters extends BaseTest {
    private String smUrl;
    private String browser;
    private String username = null;
    private String password = null;
    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    //Change this index if you want to select teacher other than "Teacher56"
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String staticCourseName = null;
    String teacherId;
    String studentDetails;
    String teacherDetails;
    String orgId;
    Set<String> commonPerformanceTitles = new HashSet<>();

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        password = DataSetupConstants.DEFAULT_PASSWORD;
        studentDetails = RBSDataSetup.getMyStudent( school, username );
        orgId = RBSDataSetup.organizationIDs.get( school );
    }

    @Test ( description = "Verify the teacher is able to delete the custom courses", groups = { "SMK-43625", "HomePage", "HomePage - Mastery Filter" }, priority = 1 )
    public void verifyMasteryFilters_001() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Verify the teacher is able to delete the custom courses" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            //Sign In
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            CoursesPage customCourses = new CoursesPage( driver );
            AssignmentsPage assignmentsPage = new AssignmentsPage( driver );
            List<String> assignmentNames = new ArrayList<>();
            //Navigate to assignment listing page
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Get all the assignments in the assignment tab
            assignmentNames = assignmentsPage.getAllAssignmentNames();

            assignmentNames.forEach( assignment -> {
                //Traverse to Assignment Tab
                tHomePage.topNavBar.navigateToAssignmentsPage();

                //Click on the Assignment
                customCourses.clickOnTheHoveredAssignment( assignment );

                //Delete the Assignment
                assignmentDetailsPage.assignmentLevelEllipsis();

                // Click on removeAssignmets
                assignmentDetailsPage.deleteAssignmenttab();

                // CLick on Delete button for the assignment
                assignmentDetailsPage.deleteAssignmentButton();

            } );

            //Navigate to assignment listing page
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Get all the assignments in the assignment tab
            assignmentNames = assignmentsPage.getAllAssignmentNames();

            //Verify if the courses are sorted in the Descending order
            Log.softAssertThat( Boolean.TRUE.equals( assignmentNames.isEmpty() ), "Assigned custom course is deleted", "Assigned custom course is not deleted" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the mastery filters on the home page withou the mastery data", groups = { "SMK-43625", "HomePage", "HomePage - Mastery Filter" }, priority = 1 )
    public void verifyMasteryFilters_002() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Verify the mastery filters on the home page withou the mastery data" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            MasteryPage masterypage = new MasteryPage( driver );
            List<String> mathSkills = new ArrayList<>();
            List<String> readingSkills = new ArrayList<>();

            //Sign In
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the mastery filter components
            MasteryFiltersComponent masteryFiltersComponent = masterypage.getMasteryFilterComponent();

            //Navigate to home tab
            tHomePage.topNavBar.navigateToHomeTab();

            //TC1
            SMUtils.logDescriptionTC( "SMK-12876_Verify default value for Subject dropdown on Mastery Card" );

            //Select Math subject
            masteryFiltersComponent.selectSubject( Constants.MATH );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.MATH ) ), "Math is selected as Subject Dropdown", "Math is not selected as Subject Dropdown" );

            //Math Skills
            mathSkills = masteryFiltersComponent.getAllSkillStandardsDropDownValues();

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.MATH ) ), "By default 'Math' is selected for Subject Dropdown", "By default 'Math' is not selected for Subject Dropdown" );

            //TC2
            SMUtils.logDescriptionTC( "SMK-12877_Verify default value for Skills/Standards dropdown on Mastery Card" );

            //Compare it with the constants file
            Log.softAssertThat( Boolean.TRUE.equals( SMUtils.compareTwoList( Constants.MATH_SKILLS_DROPDOWN_LIST, mathSkills ) ), "All the Skills/Standards of Math are present in the Skills/Standards dropdown",
                    "All the Skills/Standards of Math are not present in the Skills/Standards dropdown" );

            //Select Reading subject
            masteryFiltersComponent.selectSubject( Constants.READING );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.READING ) ), "Reading is selected as Subject Dropdown", "Reading is not selected as Subject Dropdown" );

            //Reading Skills
            readingSkills = masteryFiltersComponent.getAllSkillStandardsDropDownValues();

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.READING ) ), "'Reading' is selected for Subject Dropdown", "'Reading' is not selected for Subject Dropdown" );

            //TC3
            SMUtils.logDescriptionTC( "SMK-12886_Verify based on selected 'Subject', 'Skills/Standards' dropdown values are loaded" );

            //Compare it with the constants file
            Log.softAssertThat( Boolean.TRUE.equals( SMUtils.compareTwoList( Constants.READING_SKILLS_DROPDOWN_LIST, readingSkills ) ), "All the Skills/Standards of Reading are present in the Skills/Standards dropdown",
                    "All the Skills/Standards of Reading are not present in the Skills/Standards dropdown" );

            //TC4
            SMUtils.logDescriptionTC( "SMK-12889_Verify 'Subject' dropdown has 'Math' and 'Reading' options and ensure both options can not be selected at a time" );

            //Check whether 'No Assignment Found' is displayed
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getVisibleAssignmentName().equals( Constants.NO_ASSIGNMENTS_FOUND ) ), "Assignment dropdown is not having any assignments", "Assignment dropdown is having some assignments" );

            //TC5
            SMUtils.logDescriptionTC( "SMK-12878_Verify default value for Assignment dropdown on Mastery Card" );

            //Check whether 'No Assignment Found' is displayed
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getVisibleAssignmentName().equals( Constants.NO_ASSIGNMENTS_FOUND ) ), "Assignment dropdown is not having any assignments", "Assignment dropdown is having some assignments" );

            //TC6
            SMUtils.logDescriptionTC( "SMK-12879_Verify default value for Assignment dropdown on Mastery Card, if teacher doesnt have any assignment" );

            //Check for the zero state message for Top Performing
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getZeroStateMessage( Constants.TOP_PERFORMING ).equals( Constants.ZERO_STATE_MESSAGE_HOME_PAGE ) ), "Assignment dropdown is not having any assignments",
                    "Assignment dropdown is having some assignments" );

            //TC7
            SMUtils.logDescriptionTC( "SMK-12900_Verify when Assignment count is zero, zero state message is displayed" );

            //Check for the zero state message for Low Performing
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getZeroStateMessage( Constants.LOW_PERFORMING ).equals( Constants.ZERO_STATE_MESSAGE_HOME_PAGE ) ), "Assignment dropdown is not having any assignments",
                    "Assignment dropdown is having some assignments" );

            //TC8
            SMUtils.logDescriptionTC( "SMK-12880_Verify Zero state message is displaying on Mastery Card, if teacher doesn't have Assignment" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher is able to create custom course and the teacher is able to assign custom and default courses to student", groups = { "SMK-43625", "HomePage", "HomePage - Mastery Filter" }, priority = 1 )
    public void verifyMasteryFilters_003() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Verify the teacher is able to create custom course and the teacher is able to assign custom and default courses to student" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            //Sign In
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
            List<String> studentList = new ArrayList<>();
            staticCourseName = customCourses.generateRandomCourseName();

            //Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.MATH );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Verify Edit & Remove button presence
            customCourses.verifyEditAndRemoveBtnPresent();

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Assert Statement
            Log.softAssertThat( Boolean.TRUE.equals( studentList.size() == studentListFromTheAssignmentPopup.size() ), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
                    Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //To assign default Math course to the Student traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the default Math course
            customCourses.clickFromCourseListingPage( Constants.MATH );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Assert Statement
            Log.softAssertThat( Boolean.TRUE.equals( studentList.size() == studentListFromTheAssignmentPopup.size() ), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
                    Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //To assign default Reading course to the Student traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the default Reading course
            customCourses.clickFromCourseListingPage( Constants.READING );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.READING );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Assert Statement
            Log.softAssertThat( Boolean.TRUE.equals( studentList.size() == studentListFromTheAssignmentPopup.size() ), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
                    Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the student is able to attend the Math course via simulator", groups = { "SMK-43625", "HomePage", "HomePage - Mastery Filter" }, priority = 1 )
    public void verifyMasteryFilters_004() throws Exception {
        Log.testCaseInfo( "Verify the student is able to attend the Math course via simulator" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        try {
            Log.message( "The subject name is " + Constants.MATH );
            //Executing math assignments in student dashboard
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, Constants.USER_NAME );
            LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
            studentsPage.executeMathCourse( teacherId, Constants.MATH, "95", "5", "5" );
            studentsPage.logout();
            driver.quit();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the master data for Math course is visible on the home page for the students who have attempted the course", groups = { "SMK-43625", "HomePage", "HomePage - Mastery Filter" }, priority = 2 )
    public void verifyMasteryFilters_005() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Verify the master data for Math is visible on the home page for the students who have attempted the course" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            AssignmentsPage assignmentsPage = new AssignmentsPage( driver );
            MasteryPage masterypage = new MasteryPage( driver );
            List<String> assignmentNames = new ArrayList<>();
            List<String> mathAssignmentNamesFromDropDown = new ArrayList<>();
            List<String> readingAssignmentNamesFromDropDown = new ArrayList<>();
            List<String> lowPerformanceList = new ArrayList<>();
            List<String> highPerformanceList = new ArrayList<>();

            //Sign In
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the mastery filter components
            MasteryFiltersComponent masteryFiltersComponent = masterypage.getMasteryFilterComponent();

            //Navigate to assignment listing page
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Get all the assignments in the assignment tab
            assignmentNames = assignmentsPage.getAllAssignmentNames();

            //Navigate to home tab
            tHomePage.topNavBar.navigateToHomeTab();

            //Select subject
            masteryFiltersComponent.selectSubject( Constants.MATH );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.MATH ) ), "Math is selected as Subject Dropdown", "Math is not selected as Subject Dropdown" );

            //Math Assignments
            mathAssignmentNamesFromDropDown = tHomePage.getAllAssignments();

            Log.softAssertThat( Boolean.TRUE.equals( mathAssignmentNamesFromDropDown.contains( staticCourseName ) ), "Created custom Math course is present", "Created custom Math course is absent" );

            //TC13
            SMUtils.logDescriptionTC( "SMK-12887_Verify based on selected 'Subject', 'Assignments' dropdown values are loaded" );

            //Click assignment dropdown
            tHomePage.clickAssignmentDropdown();

            //Click on the checkboxes of the assignments
            tHomePage.clickOnAssignmentCheckboxes();

            //TC12
            SMUtils.logDescriptionTC( "SMK-12893_Verify filter options shows a single select drop down and ensure teacher will be able to select multiple options from 'Assignments' dropdown" );

            //Select subject
            masteryFiltersComponent.selectSubject( Constants.READING );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.READING ) ), "Reading is selected as Subject Dropdown", "Reading is not selected as Subject Dropdown" );

            //TC13
            SMUtils.logDescriptionTC( "SMK-12892_Verify based on selected 'Subject', 'Assignments' dropdown values are loaded" );

            //Get all the Reading Assignments
            readingAssignmentNamesFromDropDown = tHomePage.getAllAssignments();

            //TC10
            SMUtils.logDescriptionTC( "SMK-12888_Verify the Assignment dropdown contains all the assignments assigned by the logged in teacher" );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( SMUtils.compareTwoList( SMUtils.mergeList( mathAssignmentNamesFromDropDown, readingAssignmentNamesFromDropDown ), assignmentNames ) ), "Assignment dropdown contains all the assignments",
                    "Assignment dropdown does not contain all the assignments" );

            //TC9
            SMUtils.logDescriptionTC( "SMK-12890_Copy a course and assign to a student, verify newly assigned assignment is displaying under 'Assignments' dropdown on Home Page Mastery Card" );

            //TC11
            SMUtils.logDescriptionTC( "SMK-12892_Verify the applied filters can be modified" );

            //TC14
            SMUtils.logDescriptionTC( "SMK-12874_Verify on Mastery Card 'Subject', 'Skill/Standars' and 'Assignments' filter options with Apply Filter button present" );

            //Traverse to Assignment Tab
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Click on the Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Delete the Assignment
            assignmentDetailsPage.assignmentLevelEllipsis();

            // Click on removeAssignmets
            assignmentDetailsPage.deleteAssignmenttab();

            // CLick on Delete button for the assignment
            assignmentDetailsPage.deleteAssignmentButton();

            //Traverse to Student Tab 
            tHomePage.topNavBar.navigateToStudentsTab();

            //Traverse to the Courseware
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course name
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Remove the course
            customCourses.removeCourse();

            //Traverse to Courseware
            tHomePage.topNavBar.getCourseListingPage();

            //Verify if the courses are sorted in the Descending order
            Log.softAssertThat( Boolean.TRUE.equals( customCourses.verifyCourseRemovedSuccessfully( staticCourseName ) ), "Created custom math course is deleted", "Created custom math course is not deleted" );

            //Navigate to home tab
            tHomePage.topNavBar.navigateToHomeTab();

            //Select subject
            masteryFiltersComponent.selectSubject( Constants.MATH );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.MATH ) ), "Math is selected as Subject Dropdown", "Math is not selected as Subject Dropdown" );

            //Math Assignments
            mathAssignmentNamesFromDropDown = tHomePage.getAllAssignments();

            Log.softAssertThat( Boolean.FALSE.equals( mathAssignmentNamesFromDropDown.contains( staticCourseName ) ), "Created custom Math course is absent as expected", "Created custom Math course is present even after the course is deleted" );

            //TC15
            SMUtils.logDescriptionTC( "SMK-12891_Verify removed/deleted assignments are not displaying under 'Assignments' dropdown on Home Page Mastery Card" );

            //Select subject
            masteryFiltersComponent.selectSubject( Constants.READING );

            //Click on the Apply filter button
            tHomePage.clickApplyFilter();

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.READING ) ), "Reading is selected as Subject Dropdown", "Reading is not selected as Subject Dropdown" );

            //Traverse to the Courseware
            tHomePage.topNavBar.getCourseListingPage();

            //Traverse to Home page
            tHomePage.topNavBar.navigateToHomeTab();

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.MATH ) ), "Math is visible as Subject Dropdown", "Math is not visible selected as Subject Dropdown" );

            //TC19
            SMUtils.logDescriptionTC( "SMK-12898_Verify previously loaded Mastery Data are getting cleared on navigating back to home page" );

            //Select subject
            masteryFiltersComponent.selectSubject( Constants.READING );

            tHomePage.getAllAssignments();

            //Click on the Apply filter button
            tHomePage.clickApplyFilter();

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.READING ) ), "Reading is visible as Subject Dropdown", "Reading is not visible selected as Subject Dropdown" );

            //Check for the zero state message for Top Performing
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getZeroStateMessage( Constants.TOP_PERFORMING ).equals( Constants.ZERO_STATE_MESSAGE_HOME_PAGE ) ), "Assignment dropdown is not having any assignments",
                    "Assignment dropdown is having some assignments" );

            //Check for the zero state message for Low Performing
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getZeroStateMessage( Constants.LOW_PERFORMING ).equals( Constants.ZERO_STATE_MESSAGE_HOME_PAGE ) ), "Assignment dropdown is not having any assignments",
                    "Assignment dropdown is having some assignments" );

            //TC16
            SMUtils.logDescriptionTC( "SMK-12894_Modify the filters on Mastery Card and verify before clicking on 'Apply Filter' button, Mastery data not loading for modified filters value" );

            //Select subject
            masteryFiltersComponent.selectSubject( Constants.MATH );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.MATH ) ), "Math is visible as Subject Dropdown", "Math is not visible selected as Subject Dropdown" );

            //Click on the Apply filter button
            tHomePage.clickApplyFilter();

            SMUtils.logDescriptionTC( "SMK-12896_Verify Mastery Card shows the 'Top Performing' (up to 3) and 'Low Performing' (up to 3) skills" );

            //Top performing list
            highPerformanceList = tHomePage.getPerformanceList( Constants.TOP_PERFORMING );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( SMUtils.sortList( highPerformanceList ).equals( highPerformanceList ) ), "High Performing column is present", "High Performing column is absent" );

            //Top performing list
            lowPerformanceList = tHomePage.getPerformanceList( Constants.LOW_PERFORMING );

            //TC18
            SMUtils.logDescriptionTC( "SMK-12895_Verify on Mastery Card 'Top Performing' and 'Low Performing' title is displaying in two column" );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( SMUtils.sortList( lowPerformanceList ).equals( lowPerformanceList ) ), "Low Performing column is present", "Low Performing column is absent" );

            //TC21
            SMUtils.logDescriptionTC( "SMK-12872_Verify Mastery Card is displaying on Home page" );

            //Select subject
            masteryFiltersComponent.selectSubject( Constants.READING );

            //Click on the Apply filter button
            tHomePage.clickApplyFilter();

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.READING ) ), "Reading is selected as Subject Dropdown", "Reading is not selected as Subject Dropdown" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the student is able to attempt the Reading course", groups = { "SMK-43625", "HomePage", "HomePage - Mastery Filter" }, priority = 1 )
    public void verifyMasteryFilters_006() throws Exception {
        Log.testCaseInfo( "Verify the student is able to attempt the Reading course" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        try {
            Log.message( "The subject name is " + Constants.READING );
            //Executing Reading in student dashboard
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, Constants.USER_NAME );
            LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
            studentsPage.executeReadingCourse( teacherId, Constants.READING, "95", "1", "2" );
            studentsPage.logout();
            driver.quit();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the master data for Reading course is visible on the home page for the students who have attempted the course", groups = { "SMK-43625", "HomePage", "HomePage - Mastery Filter" }, priority = 3 )
    public void verifyMasteryFilters_007() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Verify the master data for Reading course is visible on the home page for the students who have attempted the course" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            MasteryPage masterypage = new MasteryPage( driver );
            List<String> lowPerformanceList = new ArrayList<>();
            List<String> highPerformanceList = new ArrayList<>();

            //Sign In
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the mastery filter components
            MasteryFiltersComponent masteryFiltersComponent = masterypage.getMasteryFilterComponent();

            //Navigate to home tab
            tHomePage.topNavBar.navigateToHomeTab();

            //Select subject
            masteryFiltersComponent.selectSubject( Constants.MATH );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getHomePageSubjectDropdownOption().equals( Constants.MATH ) ), "Math is selected as Subject Dropdown", "Math is not selected as Subject Dropdown" );

            //TC19
            SMUtils.logDescriptionTC( "SMK-12899_Verify previously loaded Mastery Data are getting cleared by logout and login again." );

            //Top performing list
            highPerformanceList = tHomePage.getPerformanceList( Constants.TOP_PERFORMING );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( SMUtils.sortList( highPerformanceList ).equals( highPerformanceList ) ), "High Performing column is present", "High Performing column is absent" );

            //Top performing list
            lowPerformanceList = tHomePage.getPerformanceList( Constants.LOW_PERFORMING );

            //TC22
            SMUtils.logDescriptionTC( "SMK-12881_Verify by default mastery data is loaded on Mastery card" );

            //Assertion
            Log.softAssertThat( Boolean.TRUE.equals( SMUtils.sortList( lowPerformanceList ).equals( lowPerformanceList ) ), "Low Performing column is present", "Low Performing column is absent" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the student is able to attend the Math course via simulator", groups = { "SMK-43625", "HomePage", "HomePage - Mastery Filter" }, priority = 1 )
    public void verifyMasteryFilters_008() throws Exception {
        Log.testCaseInfo( "Verify the student is able to attend the Math course via simulator" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        try {
            Log.message( "The subject name is " + Constants.MATH );
            //Executing math assignments in student dashboard
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, Constants.USER_NAME );
            LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
            studentsPage.executeMathCourse( teacherId, Constants.MATH, "95", "5", "30" );
            studentsPage.logout();
            driver.quit();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the mastery filters on the home page with and without the mastery data", groups = { "SMK-43625", "HomePage", "HomePage - Mastery Filter" }, priority = 2 )
    public void verifyMasteryFilters_010() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Verify the mastery filters on the home page with and without the mastery data" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            StudentsPage studentsPageObject;
            studentsPageObject = new StudentsPage( driver );
            UserSqlHelper userSqlHelper = new UserSqlHelper();
            List<String> finalLoList = new ArrayList<>();
            List<String> finalTopPerformanceTitles = new ArrayList<>();
            finalTopPerformanceTitles.addAll( commonPerformanceTitles );
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            //Sign In
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Navigate to home tab
            tHomePage.topNavBar.navigateToHomeTab();

            finalLoList = SMUtils.mergeList( tHomePage.getMasteryLoDetails( HomePageWidgetConstants.TOP_PERFORMING ), tHomePage.getMasteryLoDetails( HomePageWidgetConstants.LOW_PERFORMING ) );

            SMUtils.logDescriptionTC( "SMK-12873_Verify alignment of Mastery Card on Home page for longer LO/skills title" );

            Log.softAssertThat( finalLoList.containsAll( finalTopPerformanceTitles ), "The LO titles are appearing as expected", "The LO titles are not appearing as expected" );

            tHomePage.topNavBar.navigateToStudentsTab();

            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

            groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetails.put( GroupConstants.STAFF_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );

            HashMap<String, String> groupListingForTeacherID = new GroupAPI().getGroupListingForTeacherID( smUrl, groupDetails );
            new RBSDataSetup().deleteAllGroupUnderTeacher( groupListingForTeacherID.get( Constants.REPORT_BODY ), groupDetails.get( GroupConstants.GROUP_OWNER_ID ), groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ),
                    new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

            SMUtils.logDescriptionTC( "SMK-12882_Verify the Mastery filters are not shown if the teacher doesn't have any students assigned" );

            //Navigate to home tab
            tHomePage.topNavBar.navigateToHomeTab();

            //Tried with WebDriver wait but its required for the page to load
            SMUtils.nap( 5 );

            //Check for the zero state message for Top Performing
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getZeroStateMessage( Constants.TOP_PERFORMING ).equals( Constants.ZERO_STATE_MESSAGE_HOME_PAGE ) ), "Zero state message for Top Performing is appearing as expected",
                    "Zero state message for Top Performing is not appearing as expected" );

            SMUtils.logDescriptionTC( "SMK-12875_Verify Zero state message is displaying on Mastery Card, if selected filters doesn't have mastery data" );

            //Check for the zero state message for Low Performing
            Log.softAssertThat( Boolean.TRUE.equals( tHomePage.getZeroStateMessage( Constants.LOW_PERFORMING ).equals( Constants.ZERO_STATE_MESSAGE_HOME_PAGE ) ), "Zero state message for Low Performing is appearing as expected",
                    "Zero state message for Low Performing is not appearing as expected" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}