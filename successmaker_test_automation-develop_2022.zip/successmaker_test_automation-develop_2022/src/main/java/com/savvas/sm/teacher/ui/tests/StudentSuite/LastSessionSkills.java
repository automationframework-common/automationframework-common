package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentSkillAssesedConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

public class LastSessionSkills extends BaseTest {

    private String teacherDetails;
    private String studentID;
    private String assignmentId;
    private String assignmentUserId;
    private String studentFNLN;
    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    private String teacherId;
    private String orgId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    List<String> studentIdList = null;
    List<String> studentUserNames = null;
    ArrayList<String> studentDetails = null;
    private AtomicReference<String> schoolUsed = new AtomicReference<>();

    @BeforeClass
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        studentDetails = new ArrayList<>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<>();
        studentUserNames = new ArrayList<>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

    }

    @Test ( description = "Validate the zero state in Last Session Skills present in students page", groups = { "Students", "SMK-43901" }, priority = 1 )
    public void tcLastSessionSkills001( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcLastSessionSkills001: Validate the zero state in Last Session Skills present in students page. <small><b><i>[" + browser + "]</b></i></small>" );
        studentID = SMUtils.getKeyValueFromResponse( studentDetails.get( 0 ), RBSDataSetupConstants.USERNAME );
        Log.message( "studentID: " + studentID );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Students tab
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );

            SMUtils.logDescriptionTC( "SMK-11855 : Verify the zero state page for last session skills in student details page" );

            SMUtils.logDescriptionTC( "SMK-11856 : Verify the zero state page message for last session skills in student details page" );

            SMUtils.logDescriptionTC( "SMK-11859 : Verify that if there are no skills tested yet for this particular assignment, for the given student, zero state page is displayed" );

            Log.assertThat( studentsPage.verifyZeroStateForLastSessionSkills(), "Zero State is displayed successfully in Last Session Skills present in Students page", "Zero State is not displayed in Last Session Skills present in Students page" );
            // perform signout action
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-42901", "Students, Last_session_skill_tested" } )
    public void tcLastSessionSkills002( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcLastSessionSkills002 : Validate the last session skills section in students page for Math related courses" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );
            String courseName = Constants.Students.MATH_CUSTOM_BY_STANDARDS + RandomStringUtils.randomAlphanumeric( 5 );
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            //Assign Focus course to students
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            coursePage.clickCourseName( Constants.Students.FOCUS_COURSE_MATH );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();
            //Math Course and assigning to student
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            coursePage.createCustomByStandardCourse( courseName, Constants.MATH );
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            coursePage.clickCourseName( courseName );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();
            // Take all Math assignments
            AssignmentsPage navigateToAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentsList = navigateToAssignmentsPage.getAssignmentListBasedOnSubject( Constants.MATH );

            driver.quit();

            driver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUserNames.get( 0 ), password, true );

            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), Constants.MATH, "80", "5", "5" );

            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentsList.get( 0 ), "80", "5", "5" );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentsList.get( 1 ), "80", "5", "5" );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), courseName, "80", "5", "5" );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), Constants.Students.FOCUS_COURSE_MATH, "80", "5", "5" );

            driver.quit();

         // Get driver
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
            driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            SMUtils.logDescriptionTC( "SMK-11860 : Verify the last session skills , selected student skills data alone displayed " );

            studentsPage.clickviewStudentByEllipsis( studentID );

            SMUtils.logDescriptionTC( "SMK-11843 : Verify the dropdown displays in Last Session skills section" );

            Log.assertThat( ( studentsPage.verifyDropdownLastSession() ), "Dropdown is displayed in Last Session Skills sectionn", "Dropdown is not displayed in Last Session Skills section" );

            SMUtils.logDescriptionTC( "SMK-11831 : Verify the progress bar displays for last session skills in student details page" );

            SMUtils.logDescriptionTC( "SMK-11826 : Verify the last session skills graph in student details page for default Math Assignment" );

            SMUtils.logDescriptionTC( "SMK-11838 : Verify the progress bar represents number of correct attempts / number of total attempts displayed for Math/Reading in students details page" );

            SMUtils.logDescriptionTC( "SMK-11850 : Verify the number of correct attempts / number of total attempts is displayed to the right of Progress bar " );

            SMUtils.logDescriptionTC( "SMK-11833 : Verify the progress bar represents green color for math skill in student details page" );

            SMUtils.logDescriptionTC( "SMK-11834 : Verify the progress bar only represents green color along with % correct (i.e:80%,70%,30%) for math skill in student details page" );

            SMUtils.logDescriptionTC( "SMK-11848 : Verify the % percentage correct text (i.e:80%,70%) color for Math in progress bar" );

            Log.assertThat( studentsPage.skillTestedProgressBarAndTextColor( Constants.MATH_COLOR_STRING, Constants.LastSessionSkillTested.COLOR_BLACK ), "Progress Bar color & text color is displayed as expected",
                    "Progress Bar color & text color is not displayed as expected" );

            SMUtils.logDescriptionTC( "SMK-11851 : Verify the font color of number of correct attempts / number of total attempts" );

            Log.assertThat( studentsPage.skillTestedAttemptColor( Constants.ATTEMPT_COLOR_CODE ), "No of attempts color is displayed as expected", "No of attempts color is not displayed as expected" );

            studentsPage.clickDropDownForLastSession();
            studentsPage.selectSubjectFromLastSessionDropDown( ( Constants.Students.DEFAULT_MATH ) );
            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + Constants.Students.DEFAULT_MATH,
                    "Skill link not displayed for " + Constants.Students.DEFAULT_MATH );

            studentsPage.clickDropDownForLastSession();

            SMUtils.logDescriptionTC( "SMK-11845 : Verify the different assignment is selectable in dropdown ,update the graph for last session skills" );

            SMUtils.logDescriptionTC( "SMK-11844 : Verify the assignment is selectable in dropdown for last session skills" );

            studentsPage.selectSubjectFromLastSessionDropDown( ( assignmentsList.get( 1 ) ) );

            SMUtils.logDescriptionTC( "SMK-11829 : Verify the last session skills graph for Math custom by settings in student details page" );

            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + assignmentsList.get( 3 ),
                    "Skill link not displayed for " + assignmentsList.get( 1 ) );
            studentsPage.clickDropDownForLastSession();
            studentsPage.selectSubjectFromLastSessionDropDown( ( assignmentsList.get( 2 ) ) );

            SMUtils.logDescriptionTC( "SMK-11828 : Verify the last session skills graph for Math custom by skills in student details page" );

            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + assignmentsList.get( 4 ),
                    "Skill link not displayed for " + assignmentsList.get( 2 ) );

            studentsPage.clickDropDownForLastSession();
            studentsPage.selectSubjectFromLastSessionDropDown( ( courseName ) );

            SMUtils.logDescriptionTC( "SMK-11830 : Verify the last session skills graph for Math custom by standards in student details page" );

            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + courseName, "Skill link not displayed for " + courseName );

            studentsPage.clickDropDownForLastSession();
            studentsPage.selectSubjectFromLastSessionDropDown( ( Constants.Students.FOCUS_COURSE_MATH ) );

            SMUtils.logDescriptionTC( "SMK-11827 : Verify the last session skills graph for Math focus course in student details page" );

            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + Constants.Students.FOCUS_COURSE_MATH,
                    "Skill link not displayed for " + Constants.Students.FOCUS_COURSE_MATH );

            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-42901", "Students, Last_session_skill_tested" } )
    public void tcLastSessionSkills003( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Validate the last session skills section in students page for Reading related courses" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );
            String courseName = Constants.Students.READ_CUSTOM_BY_STANDARDS + RandomStringUtils.randomAlphabetic( 7 );
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            //Assign Focus course to students
            coursePage.clickCourseName( Constants.Students.FOCUS_COURSE_READING );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();
            //Math Course and assigning to student
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            coursePage.createCustomByStandardCourse( courseName, Constants.READING );
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            coursePage.clickCourseName( courseName );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();

            // Take all Reading assignments
            AssignmentsPage navigateToAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentsList = navigateToAssignmentsPage.getAssignmentListBasedOnSubject( Constants.READING );
            driver.quit();

            // Get driver
    		driver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUserNames.get( 0 ), password, true );

            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), Constants.READING, "80", "1", "1" );
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentsList.get( 0 ), "90", "1", "1" );
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentsList.get( 1 ), "95", "2", "3" );
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), courseName, "90", "3", "3" );
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), Constants.Students.FOCUS_COURSE_READING, "90", "2", "2" );
            driver.quit();

            // Get driver
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
            driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );

            Log.assertThat( ( studentsPage.verifyDropdownLastSession() ), "Dropdown is displayed in Last Session Skills sectionn", "Dropdown is not displayed in Last Session Skills section" );

            SMUtils.logDescriptionTC( "SMK-11831 : Verify the progress bar displays for last session skills in student details page" );

            SMUtils.logDescriptionTC( "SMK-11826 : Verify the last session skills graph in student details page for default Reading Assignment" );

            SMUtils.logDescriptionTC( "SMK-11838 : Verify the progress bar represents number of correct attempts / number of total attempts displayed for Reading in students details page" );

            studentsPage.clickDropDownForLastSession();
            studentsPage.selectSubjectFromLastSessionDropDown( ( Constants.Students.DEFAULT_READING ) );
            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + Constants.Students.DEFAULT_READING,
                    "Skill link not displayed for " + Constants.Students.DEFAULT_READING );

            SMUtils.logDescriptionTC( "SMK-11836 : Verify the progress bar represents blue color for reading skill in student details page" );

            SMUtils.logDescriptionTC( "SMK-11837 : Verify the progress bar only represents blue color along with % correct (i.e:80%,70%,30%) for reading skill in student details page" );

            SMUtils.logDescriptionTC( "SMK-11849 : Verify the % percentage correct text (i.e:80%,70%) color for Reading in progress bar" );

            Log.assertThat( studentsPage.skillTestedProgressBarAndTextColor( Constants.READ_COLOR_STRING, Constants.READ_PERCENT_TEXT_COLOR ), "Progress Bar color & text color is displayed as expected",
                    "Progress Bar & text color is not displayed as expected" );

            studentsPage.clickDropDownForLastSession();

            SMUtils.logDescriptionTC( "SMK-11845 : Verify the different assignment is selectable in dropdown ,update the graph for last session skills" );

            studentsPage.selectSubjectFromLastSessionDropDown( ( assignmentsList.get( 0 ) ) );

            SMUtils.logDescriptionTC( "SMK-11829 : Verify the last session skills graph for Reading custom by settings in student details page" );

            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + assignmentsList.get( 0 ),
                    "Skill link not displayed for " + assignmentsList.get( 0 ) );
            studentsPage.clickDropDownForLastSession();
            studentsPage.selectSubjectFromLastSessionDropDown( ( assignmentsList.get( 1 ) ) );

            SMUtils.logDescriptionTC( "SMK-11828 : Verify the last session skills graph for Reading custom by skills in student details page" );

            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + assignmentsList.get( 1 ),
                    "Skill link not displayed for " + assignmentsList.get( 1 ) );

            studentsPage.clickDropDownForLastSession();
            studentsPage.selectSubjectFromLastSessionDropDown( ( courseName ) );

            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + courseName, "Skill link not displayed for " + courseName );

            studentsPage.clickDropDownForLastSession();
            studentsPage.selectSubjectFromLastSessionDropDown( ( Constants.Students.FOCUS_COURSE_READING ) );

            SMUtils.logDescriptionTC( "SMK-11827 : Verify the last session skills graph for Reading focus course in student details page" );

            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + Constants.Students.FOCUS_COURSE_READING,
                    "Skill link not displayed for " + Constants.Students.FOCUS_COURSE_READING );

            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( groups = { "Students", "SMK-43901" }, priority = 1, dataProvider = "getMathSkillDataFromAPI" )
    public void tcLastSessionSkills004( Map<String, String> skillDetails ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	Log.testCaseInfo( "tcLastSessionSkills004: Validate the Last Session Skills section display after performing pause and resume assignment . <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Students tab
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );

            SMUtils.logDescriptionTC( "SMK-11846 : Verify that for the dropdown default assignment selected is either the default Math assignment or the default Reading assignment, if they have one" );

            Log.assertThat( studentsPage.verifySubjectTextInLastSession( Constants.MATH ), "Math subject is selected by default", "Math subject is not selected by default" );
            studentsPage.clickDropDownForLastSession();
            studentsPage.selectSubjectFromLastSessionDropDown( ( Constants.Students.DEFAULT_MATH ) );
            studentsPage.clickSkillNameInSkillTested( skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) );

            //Verify skill tested popup header
            SMUtils.logDescriptionTC( "SMK-11854 : Verify the last session skills,when click the skill title, SCO viewer popup is displayed" );

            Log.assertThat( studentsPage.verifySkillTestedPopupHeaderAndButtons( Constants.MATH ), "Skill tested popup header and buttons displayed properly", "Skill tested popup header and buttons not displayed properly" );
            studentsPage.clickCloseIconInPopup();

            SMUtils.logDescriptionTC( "SMK-11839 : Verify the view details option in student details page" );

            SMUtils.logDescriptionTC( "SMK-11840 : Verify the view details option color in student details page" );

            Log.assertThat( studentsPage.verifyViewDetailsOption_ColorCodeInLastSession(), "View Details link & colour code is displayed in Last Session Skills", "View Details link & color code is not displayed in Last Session Skills" );

            SMUtils.logDescriptionTC( "SMK-11841 : Verify the assignment details page of the selected assignment with the student automatically expanded, when click on view details" );
            studentsPage.clickViewDetails();
            AssignmentsPage navigateToAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentsList = navigateToAssignmentsPage.assignmentsList();
            String textInAssignmentDetailsPage = studentsPage.getSkillsTestedTextInAssignmentDetailsPage();

            // Validating the view details link navigating to the assignment details page with expanded
            Log.assertThat( textInAssignmentDetailsPage.equals( "Skills Tested" ), "View Details Link navigated the user to the Assignment Details Page of the " + textInAssignmentDetailsPage + " Successfully ",
                    "View Details Link Not working as Expected" );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver ).get();
            Log.assertThat( assignmentDetailsPage.isSkillTestedExpanded(), "Skills are expanded in Assignment Details page", "Skills are not expanded in Assignment details page" );

            SMUtils.logDescriptionTC( "Verify the last session skills,When the assignment paused for the student" );

            assignmentDetailsPage.pauseAllStudent();
            assignmentDetailsPage.clickPauseButtononPopUpPage();
            assignmentDetailsPage.clickBackfromAssignmentDetails();
            studentsPage.selectSubjectFromLastSessionDropDown( ( Constants.Students.DEFAULT_MATH ) );
            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + Constants.Students.DEFAULT_MATH,
                    "Skill link not displayed for " + Constants.Students.DEFAULT_MATH );

            studentsPage.clickViewDetails();
            assignmentDetailsPage = new AssignmentDetailsPage( driver ).get();

            SMUtils.logDescriptionTC( "Verify the last session skills,When the assignment is paused and then resumed again" );

            assignmentDetailsPage.resumeAssignment();
            assignmentDetailsPage.clickResumeButtononPopUpPage();
            assignmentDetailsPage.clickBackfromAssignmentDetails();
            studentsPage.selectSubjectFromLastSessionDropDown( ( Constants.Students.DEFAULT_MATH ) );
            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + Constants.Students.DEFAULT_MATH,
                    "Skill link not displayed for " + Constants.Students.DEFAULT_MATH );
            HashMap<String, HashMap<String, String>> eachPercent = studentsPage.getSkillsTestedValues();

            SMUtils.logDescriptionTC( "SMK-11832 : Verify the progress bar along with % correct (i.e:80%,70%,30%) displays for last session skills in student details page" );

            Log.assertThat( skillDetails.get( Constants.LastSessionSkillTested.PERCENTAGE_CORRECT ).equals( eachPercent.get( skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) ).get( StudentsPage.SKILL_PERCENT_VALUE ).replace( "%", "" ) ),
                    "Progress bar value is displayed as expected", "Progress bar value is not displayed as expected" );

            SMUtils.logDescriptionTC( "SMK-11852 : Verify the skill title is displayed above the progrees bar in last session skills" );

            Log.assertThat( Objects.nonNull( eachPercent.get( skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) ) ), "'Skill title is displayed as expected", "Skill title is not displayed as expected" );

            SMUtils.logDescriptionTC( "SMK-11853 : Verify the skill text color in last session skills in student details page" );

            Log.assertThat( studentsPage.skillNameLinkColor( Constants.MasteryUI.LO_ID_COLOR_CODE ), "Skill name color is displayed as expected", "Skill name color is not displayed as expected" );

            SMUtils.logDescriptionTC( "SMK-11866 : Verify the last session skills, when the student has more than 5 skills tested" );

            Log.assertThat( eachPercent.size() == 3, "Three skills are displayed in Last Session Skills section", "Three skills are not displayed in Last Session Skills section" );

            List<String> actualList = studentsPage.getProgressPercentage();
            List<String> expectedList = actualList;
            Collections.sort( expectedList );
            Collections.sort( expectedList, (Comparator<String>) ( String a, String b ) -> Integer.parseInt( a.replace( "%", "" ) ) - Integer.parseInt( b.replace( "%", "" ) ) );
            Collections.reverse( expectedList );

            SMUtils.logDescriptionTC( "SMK-11842 : Verify the default sort order for presenting the last skills tested is % correct in descending order." );

            Log.assertThat( SMUtils.compareTwoList( expectedList, actualList ), "Default sorting order is displayed in descending order", "Default sorting order is not displayed in descending order" );

            AssignmentsPage assignmentsPage = studentsPage.topNavBar.navigateToAssignmentsPage().get();
            assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentsList.get( 3 ) );
            assignmentDetailsPage.deleteAssignment();
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickDropDownForLastSession();

            SMUtils.logDescriptionTC( "SMK-11867 : Verify the last session skills ,when the assignment is deleted" );

            Log.assertThat( !studentsPage.getAssignmentFromLastSessionDropDown().contains( assignmentsList.get( 3 ) ), assignmentsList.get( 3 ) + "Assignment is not present in Last Session Dropdown", "Assignment is present in Last Session dropdown" );
            assignmentsPage = studentsPage.topNavBar.navigateToAssignmentsPage();
            assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentsList.get( 4 ) );

            SMUtils.logDescriptionTC( "SMK-11868 : Verify the last session skills ,When the assignment is removed from particular student" );

            assignmentDetailsPage.removeStudentFromAssignment( studentFNLN );
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickDropDownForLastSession();
            Log.assertThat( !studentsPage.getAssignmentFromLastSessionDropDown().contains( assignmentsList.get( 4 ) ), assignmentsList.get( 4 ) + "Assignment is not present in Last Session Dropdown", "Assignment is present in Last Session dropdown" );
            // perform signout action
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( groups = { "Students", "SMK-43901" }, priority = 1 )
    public void tcLastSessionSkills005( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcLastSessionSkills005: Validate the Last Session Skills section display when student attended more than one session & remove all the assignments for students . <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUserNames.get( 0 ), password, true );

            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), Constants.MATH, "80", "1", "1" );
            driver.quit();

            // Get driver
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
            driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            //Navigate to Students tab
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );

            SMUtils.logDescriptionTC( "SMK-11864 : Verify the last session skills, when student have more than one session " );

            Log.assertThat( studentsPage.isSkillNameLinkDisplayed( studentsPage.getSkillsListFromMap( studentsPage.getSkillsTestedValues() ).get( 0 ) ), "Skill link displayed successfully for " + Constants.Students.DEFAULT_MATH,
                    "Skill link not displayed for " + Constants.Students.DEFAULT_MATH );
            AssignmentsPage assignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            assignmentsPage.deleteAllAssignments();
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );

            SMUtils.logDescriptionTC( "SMK-11858 : Verify that the dropdown is not displayed in the zero state last session skills section, when the student does not have any assignment" );

            Log.assertThat( studentsPage.verifyZeroStateForLastSessionSkills(), "Zero state message is displayed after all assignments are deleted", "Zero state message is not displayed after all assignments are deleted" );

            // perform signout action
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @DataProvider ( name = "getMathSkillDataFromAPI" )
    public Object[][] getMathSkillDataFromAPI() throws Exception {

        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        String endpoint = "null";
        Log.message( "username = " + username );
        String token = new RBSUtils().getAccessToken( username, password );
        studentRumbaIds.add( studentIdList.get( 0 ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        assignmentDetails.put( AssignmentAPIConstants.STUDENT_ID, studentRumbaIds.get( 0 ) );
        endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
        endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{studentID}",
                assignmentDetails.get( AssignmentAPIConstants.STUDENT_ID ) );

        HashMap<String, String> studnetAssignmentDetailsByStudnetID = new AssignmentAPI().getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );

        IntStream.rangeClosed( 1, SMUtils.getWordCount( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( Constants.READING ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "assignmentId", index );
                assignmentUserId = SMUtils.getKeyValueFromJsonArray( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "studentAssignmentId", index );
            }
        } );

        HashMap<String, String> apiDetails = new HashMap<>();
        apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
        apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        apiDetails.put( Constants.STUDENT_ID, studentIdList.get( 0 ) );
        apiDetails.put( Constants.ASSIGNMENT_ID, assignmentId );
        apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, AssignmentAPIConstants.READING );
        apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
        apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
        apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );

        HashMap<String, String> studentSkillTested = new UserAPI().getStudentSkillTested( smUrl, apiDetails );

        //getting data from API
        String response = studentSkillTested.get( Constants.BODY );

        HashMap<String, String> skillDetails = new HashMap<>();
        skillDetails.put( Constants.LastSessionSkillTested.SKILL_NAME, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.SKILL_NAME ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) );
        skillDetails.put( Constants.LastSessionSkillTested.PERCENTAGE_CORRECT, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.PERCENTAGE_CORRECT ) );

        Object[][] result = { { skillDetails } };
        return result;

    }

}