package com.savvas.sm.api.tests.smnew.courses;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicReference;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class PutCustomByStandards extends CourseAPI {

	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	private String smUrl;
	private String teacherDetails = null;
	private String flexSchoolTeacherDetails = null;
	private String flexSchool = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String token = null;
	String customCourseId = null;
	String sessionLengthName = null;
	Long sessionLengthId = null;
	String sessionLengthValue = null;
	String idleTimeName = null;
	Long idleTimeId = null;
	String idleTimeValue = null;
	String orgID = null;
	String userID = null;
	String endpoint;
	HashMap<String, String> mathGradeStandardDetails = new HashMap<String, String>();
	HashMap<String, String> readingGradeStandardDetails = new HashMap<String, String>();
	public String isItMt = "";

	@BeforeClass(alwaysRun = true)
	public void BeforeTest() {
		smUrl = configProperty.getProperty("SMAppUrl");
		flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher(flexSchool);
		orgID = RBSDataSetup.organizationIDs.get(flexSchool);
		userID = SMUtils.getKeyValueFromResponse(flexSchoolTeacherDetails, "userId");
		isItMt = configProperty.getProperty( "isMTExecution" );

		// To get Random Skill and Standard ID's for Math and Reading Courses
		mathGradeStandardDetails = SqlHelperCourses.getGradeStandardID(Constants.MATH, isItMt.equalsIgnoreCase( "true" ));
		readingGradeStandardDetails = SqlHelperCourses.getGradeStandardID(Constants.READING, isItMt.equalsIgnoreCase( "true" ));
	}

	@Test(priority = 1, dataProvider = "putCustomByStandardsPositiveScenarios", groups = { "SMK-52080",
			"Update Custom by standards course", "Course", "P1", "API", "smoke_test_case" })
	public void createCourseAndUpdateCustomByStandardsPositiveScenarios(String description, String scenario,
			String statusCode, String gradeId, String courseId, String contentBaseId, String standardFrmeworkId,
			String parentNode, String ChildNode, String level, String includeLOS, String message) throws Exception {
		Log.testCaseInfo(description);
		HashMap<String, String> apiResponse = new HashMap<>();
		HashMap<String, String> courseDetails = new HashMap<>();
		HashMap<String, String> headers = new HashMap<>();

		// Authorization
		tokenCreation(CommonAPIConstants.FLEX_LICENSE_SCHOOL);

		// Create Custom course by standards
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.AUTHORIZATION, "Bearer " + token);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.USERID_SM_HEADER, userID);

		courseDetails.put(Constants.GRADE_VALUE, gradeId);
		courseDetails.put(Constants.STANDARD_FRAMEWORK_VALUE, standardFrmeworkId);
		courseDetails.put(CourseAPIConstants.COURSE_ID, courseId);
		courseDetails.put(CourseAPIConstants.PARENT_NODE, parentNode);
		courseDetails.put(CourseAPIConstants.CHILD_NODE, ChildNode);
		courseDetails.put(Constants.COURSE_NAME, "Skills" + System.nanoTime());
		apiResponse = createCourseByStandard(smUrl, headers, courseDetails, scenario);
		Log.message("response from POST Call - " + apiResponse);

		customCourseId = SMUtils.getKeyValueFromResponse(apiResponse.get(Constants.REPORT_BODY), "data,id");

		// Get Settings
		HashMap<String, String> courseSettings = new HashMap<>();
		HashMap<String, String> apiResponseGetSettings = new HashMap<>();

		courseSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		courseSettings.put(CourseAPIConstants.TEACHER_ID, userID);
		courseSettings.put(CourseAPIConstants.ORG_ID, orgID);
		courseSettings.put(CourseAPIConstants.COURSE_ID, customCourseId);
		courseSettings.put(CourseAPIConstants.BANK_ID, gradeId);
		courseSettings.put(CourseAPIConstants.CONTENT_BASE_ID, contentBaseId);
		courseSettings.put(CourseAPIConstants.LEVEL, level);
		courseSettings.put(CourseAPIConstants.INCLUDE_LOS, includeLOS);
		apiResponseGetSettings = getCoursesSettings(smUrl, courseSettings, "false", customCourseId);
		Log.message("Get Settings : " + apiResponseGetSettings);

		JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj(
				apiResponseGetSettings.get(Constants.REPORT_BODY).toString(), Constants.REPORT_BODY_DATA, null, null,
				null);

		JSONObject data2 = getSettingsResp.getJSONObject(CourseAPIConstants.SESSION_LENGTH);
		sessionLengthName = data2.getString(CourseAPIConstants.NAME);
		sessionLengthId = data2.getLong(CourseAPIConstants.ID);
		sessionLengthValue = data2.getString(CourseAPIConstants.CURRENT_VALUE);
		Log.message("Name of the session length : " + sessionLengthName);
		Log.message("Id of the session length : " + sessionLengthId);
		Log.message("CurrentValue of the session length : " + sessionLengthValue);

		JSONObject data3 = getSettingsResp.getJSONObject(CourseAPIConstants.IDLE_TIME);
		idleTimeName = data3.getString(CourseAPIConstants.NAME);
		idleTimeId = data3.getLong(CourseAPIConstants.ID);
		idleTimeValue = data3.getString(CourseAPIConstants.CURRENT_VALUE);
		Log.message("Name of the idleTime : " + idleTimeName);
		Log.message("Id of the idleTime : " + idleTimeId);
		Log.message("CurrentValue of the idleTime : " + idleTimeValue);

		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf(sessionLengthId));
		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName);
		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
		courseSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
		courseSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
		courseSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue);

		if (scenario.contains("INVALIDURL_DEFAULTMATH")) {

			apiResponse = updateCustomCourseByStandard(smUrl, headers, courseDetails, courseSettings, scenario,
					description);
			Log.message("Update course : " + apiResponse);
			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));
		} else {
			apiResponse = updateCustomCourseByStandard(smUrl, headers, courseDetails, courseSettings, scenario,
					description);
			Log.message("Update course : " + apiResponse);
			// Assertion
			Log.softAssertThat(verifyMessage(apiResponse.get("body"), message), "Message gatting as expected",
					"Message getting as not expected");
			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));
		}

		// Logging final status(pass/fail) for each case
		Log.testCaseResult();
	}

	@Test(priority = 2, dataProvider = "putCustomByStandardsNegativeScenarios", groups = { "SMK-52080",
			"Update Custom by standards course", "Course", "P1", "API" })
	public void createCourseAndUpdateCustomByStandardsNegativeScenarios(String description, String scenario,
			String scenario1, String statusCode, String gradeId, String courseId, String contentBaseId,
			String standardFrmeworkId, String parentNode, String ChildNode, String level, String includeLOS,
			String updateCourseId, String orgId, String staffId, String courseName, String settingsName,
			String settingsId, String currentValue, String exception) throws Exception {
		Log.testCaseInfo(description);
		HashMap<String, String> apiResponse = new HashMap<>();
		HashMap<String, String> courseDetails = new HashMap<>();
		HashMap<String, String> headers = new HashMap<>();

		// Authorization
		tokenCreation(CommonAPIConstants.FLEX_LICENSE_SCHOOL);

		// Create Custom course by standards
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.AUTHORIZATION, "Bearer " + token);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.USERID_SM_HEADER, userID);

		courseDetails.put(Constants.GRADE_VALUE, gradeId);
		courseDetails.put(Constants.STANDARD_FRAMEWORK_VALUE, standardFrmeworkId);
		courseDetails.put(CourseAPIConstants.COURSE_ID, courseId);
		courseDetails.put(CourseAPIConstants.PARENT_NODE, parentNode);
		courseDetails.put(CourseAPIConstants.CHILD_NODE, ChildNode);
		courseDetails.put(Constants.COURSE_NAME, "Skills" + System.nanoTime());
		apiResponse = createCourseByStandard(smUrl, headers, courseDetails, scenario);
		Log.message("response from POST Call - " + apiResponse);

		customCourseId = SMUtils.getKeyValueFromResponse(apiResponse.get(Constants.REPORT_BODY), "data,id");

		// Get Settings
		HashMap<String, String> courseSettings = new HashMap<>();
		HashMap<String, String> apiResponseGetSettings = new HashMap<>();

		courseSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		courseSettings.put(CourseAPIConstants.TEACHER_ID, userID);
		courseSettings.put(CourseAPIConstants.ORG_ID, orgID);
		courseSettings.put(CourseAPIConstants.COURSE_ID, customCourseId);
		courseSettings.put(CourseAPIConstants.BANK_ID, gradeId);
		courseSettings.put(CourseAPIConstants.LEVEL, level);
		courseSettings.put(CourseAPIConstants.INCLUDE_LOS, includeLOS);
		apiResponseGetSettings = getCoursesSettings(smUrl, courseSettings, "false", customCourseId);
		Log.message("Get Settings : " + apiResponseGetSettings);

		JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj(
				apiResponseGetSettings.get(Constants.REPORT_BODY).toString(), Constants.REPORT_BODY_DATA, null, null,
				null);

		JSONObject data2 = getSettingsResp.getJSONObject(CourseAPIConstants.SESSION_LENGTH);
		sessionLengthName = data2.getString(CourseAPIConstants.NAME);
		sessionLengthId = data2.getLong(CourseAPIConstants.ID);
		sessionLengthValue = data2.getString(CourseAPIConstants.CURRENT_VALUE);
		Log.message("Name of the session length : " + sessionLengthName);
		Log.message("Id of the session length : " + sessionLengthId);
		Log.message("CurrentValue of the session length : " + sessionLengthValue);

		JSONObject data3 = getSettingsResp.getJSONObject(CourseAPIConstants.IDLE_TIME);
		idleTimeName = data3.getString(CourseAPIConstants.NAME);
		idleTimeId = data3.getLong(CourseAPIConstants.ID);
		idleTimeValue = data3.getString(CourseAPIConstants.CURRENT_VALUE);
		Log.message("Name of the idleTime : " + idleTimeName);
		Log.message("Id of the idleTime : " + idleTimeId);
		Log.message("CurrentValue of the idleTime : " + idleTimeValue);

		HashMap<String, String> updateSettings = new HashMap<>();

		switch (scenario1) {
		case "NegativeScenariosForCourse":

			updateSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
			updateSettings.put(CourseAPIConstants.TEACHER_ID, userID);
			updateSettings.put(CourseAPIConstants.ORG_ID, orgID);
			updateSettings.put(CourseAPIConstants.COURSE_ID, updateCourseId);
			updateSettings.put(CourseAPIConstants.BANK_ID, gradeId);
			updateSettings.put(CourseAPIConstants.CONTENT_BASE_ID, contentBaseId);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf(sessionLengthId));
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
			updateSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue);

			apiResponse = updateCustomCourseByStandard(smUrl, headers, courseDetails, updateSettings, scenario,
					description);
			Log.message("Update course : " + apiResponse);

			// Assertion

			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));

			break;

		case "NegativeScenariosForOrgAndStaffAndContentBaseId":

			updateSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
			updateSettings.put(CourseAPIConstants.TEACHER_ID, staffId);
			updateSettings.put(CourseAPIConstants.ORG_ID, orgId);
			updateSettings.put(CourseAPIConstants.COURSE_ID, customCourseId);
			updateSettings.put(CourseAPIConstants.BANK_ID, gradeId);
			updateSettings.put(CourseAPIConstants.CONTENT_BASE_ID, contentBaseId);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf(sessionLengthId));
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
			updateSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue);

			apiResponse = updateCustomCourseByStandard(smUrl, headers, courseDetails, updateSettings, scenario,
					description);
			Log.message("Update course : " + apiResponse);

			// Assertion

			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));

			break;
		case "InvalidCourseName":

			updateSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
			updateSettings.put(CourseAPIConstants.TEACHER_ID, staffId);
			updateSettings.put(CourseAPIConstants.ORG_ID, orgId);
			updateSettings.put(CourseAPIConstants.COURSE_ID, customCourseId);
			updateSettings.put(CourseAPIConstants.COURSE_NAME, courseName);
			updateSettings.put(CourseAPIConstants.BANK_ID, gradeId);
			updateSettings.put(CourseAPIConstants.CONTENT_BASE_ID, contentBaseId);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf(sessionLengthId));
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
			updateSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue);

			apiResponse = updateCustomCourseByStandard(smUrl, headers, courseDetails, updateSettings, scenario,
					description);
			Log.message("Update course : " + apiResponse);

			// Assertion

			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));

			break;

		case "InvalidNameForSettings":

			updateSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
			updateSettings.put(CourseAPIConstants.TEACHER_ID, staffId);
			updateSettings.put(CourseAPIConstants.ORG_ID, orgId);
			updateSettings.put(CourseAPIConstants.COURSE_ID, customCourseId);
			updateSettings.put(CourseAPIConstants.BANK_ID, gradeId);
			updateSettings.put(CourseAPIConstants.CONTENT_BASE_ID, contentBaseId);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf(sessionLengthId));
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, settingsName);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
			updateSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue);

			apiResponse = updateCustomCourseByStandard(smUrl, headers, courseDetails, updateSettings, scenario,
					description);
			Log.message("Update course : " + apiResponse);

			// Assertion

			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));

			break;

		case "InvalidIdForSettings":

			updateSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
			updateSettings.put(CourseAPIConstants.TEACHER_ID, staffId);
			updateSettings.put(CourseAPIConstants.ORG_ID, orgId);
			updateSettings.put(CourseAPIConstants.COURSE_ID, customCourseId);
			updateSettings.put(CourseAPIConstants.BANK_ID, gradeId);
			updateSettings.put(CourseAPIConstants.CONTENT_BASE_ID, contentBaseId);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, settingsId);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
			updateSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue);

			apiResponse = updateCustomCourseByStandard(smUrl, headers, courseDetails, updateSettings, scenario,
					description);
			Log.message("Update course : " + apiResponse);

			// Assertion

			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));

			break;

		case "InvalidCurrentValueForIdelTime":

			updateSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
			updateSettings.put(CourseAPIConstants.TEACHER_ID, staffId);
			updateSettings.put(CourseAPIConstants.ORG_ID, orgId);
			updateSettings.put(CourseAPIConstants.COURSE_ID, customCourseId);
			updateSettings.put(CourseAPIConstants.BANK_ID, gradeId);
			updateSettings.put(CourseAPIConstants.CONTENT_BASE_ID, contentBaseId);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf(sessionLengthId));
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
			updateSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, currentValue);

			apiResponse = updateCustomCourseByStandard(smUrl, headers, courseDetails, updateSettings, scenario,
					description);
			Log.message("Update course : " + apiResponse);

			// Assertion

			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));

			break;

		case "InvalidAuthentication":

			HashMap<String, String> headersInvalidToken = new HashMap<>();

			headersInvalidToken.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
			headersInvalidToken.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
			headersInvalidToken.put(Constants.AUTHORIZATION, "Bearer " + "112ffffff3fhhh4hh");
			headersInvalidToken.put(Constants.ORGID_SM_HEADER, orgID);
			headersInvalidToken.put(Constants.USERID_SM_HEADER, userID);

			updateSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
			updateSettings.put(CourseAPIConstants.TEACHER_ID, staffId);
			updateSettings.put(CourseAPIConstants.ORG_ID, orgId);
			updateSettings.put(CourseAPIConstants.COURSE_ID, customCourseId);
			updateSettings.put(CourseAPIConstants.BANK_ID, gradeId);
			updateSettings.put(CourseAPIConstants.CONTENT_BASE_ID, contentBaseId);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf(sessionLengthId));
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
			updateSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue);

			apiResponse = updateCustomCourseByStandard(smUrl, headersInvalidToken, courseDetails, updateSettings,
					scenario, description);
			Log.message("Update course : " + apiResponse);

			// Assertion

			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));

			break;

		case "updateDefaultMathCourse":

			updateSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
			updateSettings.put(CourseAPIConstants.TEACHER_ID, userID);
			updateSettings.put(CourseAPIConstants.ORG_ID, orgID);
			updateSettings.put(CourseAPIConstants.COURSE_ID, updateCourseId);
			updateSettings.put(CourseAPIConstants.BANK_ID, gradeId);
			updateSettings.put(CourseAPIConstants.CONTENT_BASE_ID, contentBaseId);

			apiResponse = updateDefaultCourseByStandard(smUrl, headers, courseDetails, updateSettings, scenario);
			Log.message("Update course : " + apiResponse);

			// Assertion

			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));

			break;

		case "invalidConentBaseId":

			updateSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
			updateSettings.put(CourseAPIConstants.TEACHER_ID, staffId);
			updateSettings.put(CourseAPIConstants.ORG_ID, orgId);
			updateSettings.put(CourseAPIConstants.COURSE_ID, customCourseId);
			updateSettings.put(CourseAPIConstants.BANK_ID, gradeId);
			updateSettings.put(CourseAPIConstants.CONTENT_BASE_ID, contentBaseId);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf(sessionLengthId));
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName);
			updateSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
			updateSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
			updateSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue);

			apiResponse = updateCustomCourseByStandard(smUrl, headers, courseDetails, updateSettings, scenario,
					description);
			Log.message("Update course : " + apiResponse);

			// Assertion

			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));

			break;

		}
		// Logging final status(pass/fail) for each case
		Log.testCaseResult();
	}

	/**
	 * Data provider for Custom Course positive scenarios
	 * 
	 * @return
	 */
	@DataProvider(name = "putCustomByStandardsPositiveScenarios")
	public Object[][] createCourseAndUpdateCustomByStandards() {
		Object[][] inputData = {
				{ "TC001 Update default custom by standards math course ", "DEFAULTMATH", "200",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						"Course updated successfully" },
				{ "TC002 Update default custom by standards reading course", "DEFAULTREADING", "200",
						readingGradeStandardDetails.get("GradeID"), "2", "4",
						readingGradeStandardDetails.get("StandardID"), readingGradeStandardDetails.get("bankID"),
						readingGradeStandardDetails.get("scoID"), "0", "true", "Course updated successfully" },
				{ "TC003 Update custom by standards focus math", "FOCUSMATH", "200",
						mathGradeStandardDetails.get("GradeID"), "3", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						"Course updated successfully" },
				{ "TC004 Update custom by standards focus reading", "READING", "200",
						readingGradeStandardDetails.get("GradeID"), "15", "4",
						readingGradeStandardDetails.get("StandardID"), readingGradeStandardDetails.get("bankID"),
						readingGradeStandardDetails.get("scoID"), "0", "true", "Course updated successfully" },
				{ "TC030 invalid URL", "INVALIDURL_DEFAULTMATH", "404", mathGradeStandardDetails.get("GradeID"), "1",
						"4", mathGradeStandardDetails.get("StandardID"), mathGradeStandardDetails.get("bankID"),
						mathGradeStandardDetails.get("scoID"), "0", "true", "Course updated successfully" }, };
		return inputData;
	}

	@DataProvider(name = "putCustomByStandardsNegativeScenarios")
	public Object[][] updateCustomByStandardsNegativeScenarios() {
		Object[][] inputData = {
				{ "TC08 invalid course id abc ", "DEFAULTMATH", "NegativeScenariosForCourse", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						"abc", orgID, userID, null, null, null, null,
						"org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
				{ "TC09 non existing course id ", "DEFAULTMATH", "NegativeScenariosForCourse", "200",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						"7123", orgID, userID, null, null, null, null,
						"com.savvas.core.exceptions.DataNotFoundException" },
				{ "TC10 invalid org id as abc ", "DEFAULTMATH", "NegativeScenariosForOrgAndStaffAndContentBaseId",
						"400", mathGradeStandardDetails.get("GradeID"), "1", "4",
						mathGradeStandardDetails.get("StandardID"), mathGradeStandardDetails.get("bankID"),
						mathGradeStandardDetails.get("scoID"), "0", "true", null, "abc", userID, null, null, null, null,
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC11 defferent org id ", "DEFAULTMATH", "NegativeScenariosForOrgAndStaffAndContentBaseId", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, "8a7209eb7f65705b017f65738c010000", userID, null, null, null, null,
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC13 defferent teacher id ", "DEFAULTMATH", "NegativeScenariosForOrgAndStaffAndContentBaseId", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, "ffffffff627e5b0c3f948a002f1ecd2e", null, null, null, null,
						"com.savvas.core.exceptions.BusinessRuleViolationException" },

				{ "TC14 invalid content base id ", "DEFAULTMATH", "NegativeScenariosForOrgAndStaffAndContentBaseId",
						"400", mathGradeStandardDetails.get("GradeID"), "1", "abc",
						mathGradeStandardDetails.get("StandardID"), mathGradeStandardDetails.get("bankID"),
						mathGradeStandardDetails.get("scoID"), "0", "true", null, orgID, userID, null, null, null, null,
						"org.springframework.http.converter.HttpMessageNotReadableException" },
				{ "TC15 null for content base id ", "DEFAULTMATH", "NegativeScenariosForOrgAndStaffAndContentBaseId",
						"400", mathGradeStandardDetails.get("GradeID"), "1", "null",
						mathGradeStandardDetails.get("StandardID"), mathGradeStandardDetails.get("bankID"),
						mathGradeStandardDetails.get("scoID"), "0", "true", null, orgID, userID, null, null, null, null,
						"com.pst.exceptions.ValidationException" },
				{ "TC16 InvalidCourseName: Existing Courese name ", "DEFAULTMATH", "InvalidCourseName", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, "Math", null, null, null,
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC18 InvalidCourseName: null Courese name ", "DEFAULTMATH", "InvalidCourseName", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, "", null, null, null,
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC17 InvalidCourseName: Exceeded limit Courese name ", "DEFAULTMATH", "InvalidCourseName", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID,
						"abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz",
						null, null, null, "com.pst.exceptions.ValidationException" },

				{ "TC19 name as integer ", "DEFAULTMATH", "InvalidNameForSettings", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, "3435", null, null, "com.pst.exceptions.ValidationException" },
				{ "TC20 name as null ", "DEFAULTMATH", "InvalidNameForSettings", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, "null", null, null, "com.pst.exceptions.ValidationException" },
				{ "TC21 invalid name ", "DEFAULTMATH", "InvalidNameForSettings", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, "abc", null, null, "com.pst.exceptions.ValidationException" },
				{ "TC22 invalid id ", "DEFAULTMATH", "InvalidIdForSettings", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, null, "1234", null,
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC23 null id ", "DEFAULTMATH", "InvalidIdForSettings", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, null, "null", null, "com.pst.exceptions.ValidationException" },
				{ "TC24 non existing id ", "DEFAULTMATH", "InvalidIdForSettings", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, null, "583", null,
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC25 invalid value ", "DEFAULTMATH", "InvalidCurrentValueForIdelTime", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, null, "583", "abc",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC26 null value ", "DEFAULTMATH", "InvalidCurrentValueForIdelTime", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, null, "583", "",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC27 beyond range value above max", "DEFAULTMATH", "InvalidCurrentValueForIdelTime", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, null, "583", "10",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC28 beyond range value below min ", "DEFAULTMATH", "InvalidCurrentValueForIdelTime", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, null, "583", "1",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC06 when change values ", "DEFAULTMATH", "InvalidCurrentValueForIdelTime", "200",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, null, "583", "4", "null" },
				{ "TC29 Verify 401 for invalid authentication ", "DEFAULTMATH", "InvalidAuthentication", "401",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true",
						null, orgID, userID, null, null, null, null, "java.lang.Exception" },
				{ "TC31 Verify 400 for invalid ConentBase Id ", "DEFAULTMATH", "invalidConentBaseId", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "1156",
						mathGradeStandardDetails.get("StandardID"), mathGradeStandardDetails.get("bankID"),
						mathGradeStandardDetails.get("scoID"), "0", "true", null, orgID, userID, null, null, null, null,
						"com.savvas.core.exceptions.BusinessRuleViolationException" },

				{ "TC32 Verify 400 for Default Math update ", "DEFAULTMATH_UPDATE", "updateDefaultMathCourse", "400",
						mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"),
						mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "0", "true", "1",
						orgID, userID, null, null, null, null,
						"com.savvas.core.exceptions.BusinessRuleViolationException" }

		};
		return inputData;
	}

	// Token creation
	public void tokenCreation(String school) {
		try {

			teacherDetails = flexSchoolTeacherDetails;

			token = new RBSUtils().getAccessToken(
					SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME),
					RBSDataSetupConstants.DEFAULT_PASSWORD);

		} catch (Exception e) {
			Log.message("Issue occured in tokenCreation");
		}
	}

	/**
	 * Verifying the Exception information
	 * 
	 * @param actualResponse
	 * @param exception
	 * @return boolean
	 * @throws IOException
	 */
	public boolean verifyExceptionMessage(String actualResponse, String exception) throws IOException {

		boolean flag = false;
		if (SMUtils.getKeyValueFromResponse(actualResponse, "messages,exception").equalsIgnoreCase(exception)) {
			Log.message("Exception Verified successfully!");
			flag = true;
		} else {
			Log.message("Issue in displaying exception!");
		}
		return flag;
	}

	/**
	 * Verifying the message
	 * 
	 * @param actualResponse
	 * @param message
	 * @return boolean
	 * @throws IOException
	 */
	public boolean verifyMessage(String actualResponse, String message) throws IOException {

		boolean flag = false;
		if (SMUtils.getKeyValueFromResponse(actualResponse, "messages,message").equalsIgnoreCase(message)) {
			Log.message("status Verified successfully!");
			flag = true;
		} else {
			Log.message("Issue in displaying status!");
		}
		return flag;
	}

	/**
	 * Get response for the Create Course By Skill API
	 *
	 * @param envUrl
	 * @param headers
	 * @param courseDetails
	 * @param scenario
	 * @return
	 */
	public HashMap<String, String> createCourseByStandard(String envUrl, HashMap<String, String> headers,
			HashMap<String, String> courseDetails, String scenario) {
		try {

			String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
			Log.message("createCourseBySkill= " + endpoint);
			endpoint = endpoint.replace(Constants.ORG_ID, headers.get(Constants.ORGID_SM_HEADER));
			endpoint = endpoint.replace(Constants.STAFF_ID, headers.get(Constants.USERID_SM_HEADER));
			endpoint = endpoint.replace(Constants.COURSE_ID, courseDetails.get(CourseAPIConstants.COURSE_ID));
			Log.message("endpoint=" + endpoint);
			AtomicReference<String> requestBody = new AtomicReference<>();
			if (scenario.contains("DEFAULTREADING")) {
				requestBody.set(
						SMUtils.convertFileToString(configProperty.getProperty("createCustomCourseByStandardReading")));

			} else if (scenario.contains("DEFAULTMATH")) {
				requestBody.set(
						SMUtils.convertFileToString(configProperty.getProperty("createCustomCourseByStandardMath")));
			} else if (scenario.contains("FOCUSMATH")) {
				requestBody.set(SMUtils
						.convertFileToString(configProperty.getProperty("createCustomCourseByStandardsFocusMath")));
			} else {
				requestBody.set(SMUtils
						.convertFileToString(configProperty.getProperty("createCustomCourseByStandardsFocusReading")));
			}
			requestBody.set(requestBody.get().replace(Constants.GRADE_ID, courseDetails.get(Constants.GRADE_VALUE)));
			requestBody.set(requestBody.get().replace(Constants.STANDARDFRAMEWORK_ID,
					courseDetails.get(Constants.STANDARD_FRAMEWORK_VALUE)));
			requestBody.set(
					requestBody.get().replace(Constants.COURSENAME_VALUE, courseDetails.get(Constants.COURSE_NAME)));
			requestBody.set(requestBody.get().replace(CourseAPIConstants.PARENT_NODE,
					courseDetails.get(CourseAPIConstants.PARENT_NODE)));
			requestBody.set(requestBody.get().replace(CourseAPIConstants.CHILD_NODE,
					courseDetails.get(CourseAPIConstants.CHILD_NODE)));
			return RestHttpClientUtil.POST(envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get());

		} catch (Exception e) {
			Log.message("Error in createCourseByStandard method");
			return null;
		}
	}

	/**
	 * Get response for the update Course By Skill API
	 *
	 * @param envUrl
	 * @param headers
	 * @param courseDetails
	 * @param scenario
	 * @return
	 */
	public HashMap<String, String> updateCustomCourseByStandard(String envUrl, HashMap<String, String> headers,
			HashMap<String, String> courseDetails, HashMap<String, String> updateSettings, String scenario,
			String description) {
		try {

			if (scenario.contains("INVALIDURL_DEFAULTMATH")) {
				endpoint = CourseAPIConstants.UPDATE_CUSTOM_COURSE_BY_STANDARDS_INVALID;
			} else {
				endpoint = CourseAPIConstants.UPDATE_CUSTOM_COURSE_BY_STANDARDS;
			}
			Log.message("update custom course by standard= " + endpoint);
			endpoint = endpoint.replace(Constants.ORG_ID, updateSettings.get(CourseAPIConstants.ORG_ID));
			endpoint = endpoint.replace(Constants.STAFF_ID, updateSettings.get(CourseAPIConstants.TEACHER_ID));
			endpoint = endpoint.replace(Constants.COURSE_ID, updateSettings.get(CourseAPIConstants.COURSE_ID));
			Log.message("endpoint=" + envUrl + endpoint);
			AtomicReference<String> requestBody = new AtomicReference<>();
			if (scenario.contains("READING")) {
				requestBody.set(
						SMUtils.convertFileToString(configProperty.getProperty("updateCustomCourseByStandardReading")));
			} else {
				requestBody.set(
						SMUtils.convertFileToString(configProperty.getProperty("updateCustomCourseByStandardMath")));
			}
			requestBody.set(requestBody.get().replace(Constants.GRADE_ID, courseDetails.get(Constants.GRADE_VALUE)));
			requestBody.set(requestBody.get().replace(Constants.STANDARDFRAMEWORK_ID,
					courseDetails.get(Constants.STANDARD_FRAMEWORK_VALUE)));
			if (description.contains("InvalidCourseName:")) {
				requestBody.set(requestBody.get().replace(Constants.COURSENAME_VALUE,
						updateSettings.get(CourseAPIConstants.COURSE_NAME)));
			} else {
				requestBody.set(requestBody.get().replace(Constants.COURSENAME_VALUE,
						courseDetails.get(Constants.COURSE_NAME)));
			}
			requestBody.set(requestBody.get().replace(Constants.CONTENTBASE_ID,
					updateSettings.get(CourseAPIConstants.CONTENT_BASE_ID)));
			requestBody.set(requestBody.get().replace(Constants.SESSION_LENGTH_ID,
					updateSettings.get(CourseAPIConstants.SESSION_STRENGTH_ID)));
			requestBody.set(requestBody.get().replace(Constants.SESSION_LENGTH_NAME,
					updateSettings.get(CourseAPIConstants.SESSION_STRENGTH_NAME)));
			requestBody.set(requestBody.get().replace(Constants.SESSION_LENGTH_VALUE,
					updateSettings.get(CourseAPIConstants.SESSION_STRENGTH_VALUE)));
			requestBody.set(requestBody.get().replace(Constants.IDLE_TIME_ID,
					updateSettings.get(CourseAPIConstants.IDLE_TIME_ID)));
			requestBody.set(requestBody.get().replace(Constants.IDLE_TIME_NAME,
					updateSettings.get(CourseAPIConstants.IDLE_TIME_NAME)));
			requestBody.set(requestBody.get().replace(Constants.IDLE_TIME_VALUE,
					updateSettings.get(CourseAPIConstants.IDLE_TIME_VALUE)));
			requestBody.set(requestBody.get().replace(CourseAPIConstants.PARENT_NODE,
					courseDetails.get(CourseAPIConstants.PARENT_NODE)));
			requestBody.set(requestBody.get().replace(CourseAPIConstants.CHILD_NODE,
					courseDetails.get(CourseAPIConstants.CHILD_NODE)));

			Log.message("payload : " + requestBody.get());
			Log.message(headers.toString());

			return RestHttpClientUtil.PUT(envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get());

		} catch (Exception e) {
			Log.message("Error in updating the Course method");
			return null;
		}
	}

	public HashMap<String, String> updateDefaultCourseByStandard(String envUrl, HashMap<String, String> headers,
			HashMap<String, String> courseDetails, HashMap<String, String> updateSettings, String scenario) {
		try {

			String endpoint = CourseAPIConstants.UPDATE_CUSTOM_COURSE_BY_STANDARDS;

			Log.message("update custom course by standard= " + endpoint);
			endpoint = endpoint.replace(Constants.ORG_ID, updateSettings.get(CourseAPIConstants.ORG_ID));
			endpoint = endpoint.replace(Constants.STAFF_ID, updateSettings.get(CourseAPIConstants.TEACHER_ID));
			endpoint = endpoint.replace(Constants.COURSE_ID, updateSettings.get(CourseAPIConstants.COURSE_ID));
			Log.message("endpoint=" + envUrl + endpoint);
			AtomicReference<String> requestBody = new AtomicReference<>();

			requestBody
					.set(SMUtils.convertFileToString(configProperty.getProperty("updateCourseByStandardsDefaultMath")));

			requestBody.set(requestBody.get().replace(Constants.GRADE_ID, courseDetails.get(Constants.GRADE_VALUE)));
			requestBody.set(requestBody.get().replace(Constants.STANDARDFRAMEWORK_ID,
					courseDetails.get(Constants.STANDARD_FRAMEWORK_VALUE)));
			requestBody.set(
					requestBody.get().replace(Constants.COURSENAME_VALUE, courseDetails.get(Constants.COURSE_NAME)));
			requestBody.set(requestBody.get().replace(Constants.CONTENTBASE_ID,
					updateSettings.get(CourseAPIConstants.CONTENT_BASE_ID)));
			requestBody.set(requestBody.get().replace(CourseAPIConstants.PARENT_NODE,
					courseDetails.get(CourseAPIConstants.PARENT_NODE)));
			requestBody.set(requestBody.get().replace(CourseAPIConstants.CHILD_NODE,
					courseDetails.get(CourseAPIConstants.CHILD_NODE)));

			Log.message("payload : " + requestBody.get());
			Log.message(headers.toString());

			return RestHttpClientUtil.PUT(envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get());

		} catch (Exception e) {
			Log.message("Error in updating the Course method");
			return null;
		}
	}
}