package com.savvas.sm.ui.tests.smnew.TeacherDashBoard;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

/*
 * @author madhan.nagarathinam This class test whether the courses are getting
 * displayed in the teacher dashboard and coursewareListing with respect to the
 * licenses purchased for the org
 */
public class ZeroStateInTeacherDashBoardHomePageTest extends BaseTest {
    private String smUrl;
    private String browser;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
    }

    @Test ( priority = 1, groups = { "SMK-52283", "license", "licensing_zero_state", "P1", "UI" } )
    public void tcTeacherDashboardZeroState001( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "Verify the Teacher should see a zero state error message in course page if no license exists for the organization" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // Logging in as basic teacher without any license for the teacher's org
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, LoginConstants.DIFF_LICENSE_STATE_TEACHER_USERS.NO_LICENSE_TEACHER, password );
            Log.assertThat( teacherHomePage.getZeroStateContentMessage().contentEquals( Constants.HomePageWidgetConstants.ZERO_STATE_DASHBOARD_MESSAGE ), "Teacher is able to see zero state error message in Teacher Dashboard",
                    "Teacher is not able to see zero state error message in Teacher Dashboard!" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-52283", "license", "licensing_zero_state", "P1", "UI" } )
    public void tcTeacherDashboardZeroState002( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "Verify the Teacher dashboard if SuccessMaker Flex license is expired for the organization" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // Logging in as basic teacher without any license for the teacher's org
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, LoginConstants.DIFF_LICENSE_STATE_TEACHER_USERS.TEACHER_WITH_EXPIRED_LICENSE, password );
            Log.assertThat( teacherHomePage.getZeroStateContentMessage().contentEquals( Constants.HomePageWidgetConstants.ZERO_STATE_DASHBOARD_MESSAGE ), "Teacher is able to see zero state error message in Teacher Dashboard",
                    "Teacher is not able to see zero state error message in Teacher Dashboard!" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-52283", "license", "licensing_zero_state", "P1", "UI" } )
    public void tcTeacherDashboardZeroState003( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "Verify the Teacher dashboard if SuccessMaker Flex license is set for future date" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // Logging in as basic teacher without any license for the teacher's org
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, LoginConstants.DIFF_LICENSE_STATE_TEACHER_USERS.TEACHER_WITH_FUTURE_LICENSE, password );
            Log.assertThat( teacherHomePage.getZeroStateContentMessage().contentEquals( Constants.HomePageWidgetConstants.ZERO_STATE_DASHBOARD_MESSAGE ), "Teacher is able to see zero state error message in Teacher Dashboard",
                    "Teacher is not able to see zero state error message in Teacher Dashboard!" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-52283", "license", "licensing_zero_state", "P1", "UI" } )
    public void tcTeacherDashboardZeroState004( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "Verify the Teacher dashboard if any of the SM Product is exists for the organization" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // Logging in as basic teacher without any license for the teacher's org
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, LoginConstants.DIFF_LICENSE_STATE_TEACHER_USERS.TEACHER_WITH_ACTIVE_LICENSE, password );
            Log.assertThat( teacherHomePage.isCoursesWidgetDisplayed(), "Teacher is not able to see the zero state content message in the homepage when the org has any active SM license",
                    "Teacher is able to see the zero state content message in the homepage when the org has any active SM license!" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
