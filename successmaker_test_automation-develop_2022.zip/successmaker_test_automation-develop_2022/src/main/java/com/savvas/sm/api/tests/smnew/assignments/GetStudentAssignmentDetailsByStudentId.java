package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class GetStudentAssignmentDetailsByStudentId extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String teacherUsername;
    List<String> studentRumbaIds = new ArrayList<>();
    RBSUtils rbsutils = new RBSUtils();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    /**
     * Tests the Positive scenarios of Get Student Assignment Details By
     * StudentId
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "getStudnetAssignmentDetailsByStudnetID_PositiveFlow", groups = { "SMK-51989", "smoke_test_case", "Assignments", "GetStudentAssignmentDetailsByStudentId", "P1", "API" } )
    public void tcgetStudnetAssignmentDetailsByStudnetID_PositiveFlow_01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        String endpoint = "null";

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        switch ( scenario ) {
            case "Get Student Assignment Details with Valid Data":
                assignmentDetails.put( AssignmentAPIConstants.STUDENT_ID, studentRumbaIds.get( 0 ) );
                endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{studentID}",
                        assignmentDetails.get( AssignmentAPIConstants.STUDENT_ID ) );
                Log.message( assignmentDetails.toString() );
                Log.message( endpoint.toString() );
                break;
            default:
                Log.fail( "Case is invalid" );
                break;
        }
        HashMap<String, String> getresponse = getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );
        Log.message( "StatusCode: " + getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
        Log.testCaseResult();
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "getStudnetAssignmentDetailsByStudnetID_PositiveFlow" )
    public Object[][] getStudnetAssignmentDetailsByStudnetID_PositiveFlow() {

        Object[][] inputData = { { "Verify the status code as 200 and response body - with valid data To Get Assignment Details by Student Id", "Get Student Assignment Details with Valid Data", CommonAPIConstants.STATUS_CODE_OK } };
        return inputData;
    }

    /**
     * Tests the Negative scenarios of Get Student Assignment Details By
     * StudentId
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( dataProvider = "getStudnetAssignmentDetailsByStudnetID_NegativeFlow", priority = 2, groups = { "SMK-51989", "Assignments", "GetStudentAssignmentDetailsByStudentId", "P2", "API" } )
    public void tcgetStudnetAssignmentDetailsByStudnetID_NegativeFlow_02( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        String endpoint = "null";

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( AssignmentAPIConstants.STUDENT_ID, studentRumbaIds.get( 0 ) );

        String exception = null;
        boolean status = false;
        String message = null;

        switch ( scenario ) {
            case "Incorrect orgId in Headers":
                endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{studentID}",
                        assignmentDetails.get( AssignmentAPIConstants.STUDENT_ID ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, "1234$" );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;
            case "Invalid Staff-Id in headers":
                endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{studentID}",
                        assignmentDetails.get( AssignmentAPIConstants.STUDENT_ID ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, "1234$" );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            case "Incorrect URL":
                endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{studentID}",
                        assignmentDetails.get( AssignmentAPIConstants.STUDENT_ID ) ).replace( "organizations", "organizationssss" );
                break;
            case "Invalid Bearer Token":
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            case "Invalid organisationId in the path params":
                endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
                endpoint = endpoint.replace( "{orgID}", "1234$" ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{studentID}", assignmentDetails.get( AssignmentAPIConstants.STUDENT_ID ) );
                exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                status = true;
                break;
            case "Invalid staffId in path params":
                endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", "123" ).replace( "{studentID}", assignmentDetails.get( AssignmentAPIConstants.STUDENT_ID ) );
                exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                status = true;
                break;
            case "Invalid studentID in path params":
                endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{studentID}", "1234$" );
                exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                status = true;
                break;
            case "Path parameters with Invalid Datatype":
                endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
                endpoint = endpoint.replace( "{orgID}", "aa" ).replace( "{teacherID}", "bb" ).replace( "{studentID}", "cc" );
                exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                status = true;
                break;
            default:
                Log.fail( "Case is invalid" );
                break;
        }

        HashMap<String, String> getresponse = getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );
        Log.message( "StatusCode: " + getresponse.get( "statusCode" ) );
        Log.message( "Response: " + getresponse.get( "body" ) );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
        if ( message != null ) {
            verifyException( getresponse.get( "body" ), exception, status, message );
        }

        Log.testCaseResult();
    }

    /**
     * Data provider for Negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "getStudnetAssignmentDetailsByStudnetID_NegativeFlow" )
    public Object[][] getStudnetAssignmentDetailsByStudnetID_NegativeFlow() {

        Object[][] inputData = { { "Verify the status code is 403 and response body - Incorrect orgId in Headers", "Incorrect orgId in Headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code is 401 and response body - invalid Staff-Id in headers", "Invalid Staff-Id in headers", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code is 404 when the URL is wrong", "Incorrect URL", CommonAPIConstants.STATUS_CODE_NOTFOUND },
                { "Verify the response body of 401 and response body - Invalid Bearer Token", "Invalid Bearer Token", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify 400 status code and response body, with invalid organisationId in the path params", "Invalid organisationId in the path params", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify 400 status code and response body, with Invalid staffId in path params", "Invalid staffId in path params", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify 400 status code and response body, with Invalid studentID in path params", "Invalid studentID in path params", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify 400 status code and response body, for Path parameters with Invalid Datatype", "Path parameters with Invalid Datatype", CommonAPIConstants.STATUS_CODE_BAD_REQUEST }, };
        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }
}