/**
 * Method for testing the students mastery Page
 *
 * @author Sudarshan.Govindarajan
 */

package com.savvas.sm.ui.tests.smnew.Mastery;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants.Students.Mastery_DropDowns;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.HelpPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.mastery.pages.MasteryDetailsPage;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasterySummaryComponent;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.ui.pages.MasteryMfePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class MasteryReportTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static WebDriver driver;
    private static String multiUsername;
    private static String singleUsername;
    private static String password;
    private static String username;

    List<String> studentIDList = null;
    List<String> studentNames = new ArrayList<>();
    BaseAPITest baseApiObject = new BaseAPITest();
    UserSqlHelper userSqlHelper = new UserSqlHelper();
    SqlHelperOrganization sqlHelperOrganization = new SqlHelperOrganization();
    HelpPage helpPage;

    StudentsPage smnewStudentsPage;
    AssignmentsPage assignmentsPage;
    AssignmentDetailsPage assignmentDetailsPage;
    MasteryDetailsPage masteryDetailsPage;

    String teacherDetails;
    String studentUserName1;
    String studentUserName2;
    String studentUserName3;
    String studentUserName4;
    String assignmentName;
    private String masteryAdminSingleMfeUrl;
    private String masteryAdminMultiMfeUrl;

    String school = RBSDataSetup.getSchools( RBSDataSetupConstants.Schools.FLEX_SCHOOL );

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        singleUsername = MasteryDataSetup.schoolAdminUserName;
        multiUsername = MasteryDataSetup.multiSchoolAdminUserName;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        studentUserName1 = MasteryDataSetup.studentUserName1;
        studentUserName2 = MasteryDataSetup.studentUserName2;
        studentUserName3 = MasteryDataSetup.studentUserName3;
        assignmentName = MasteryDataSetup.math_Assignment;
        username = MasteryDataSetup.teacherUserName;
        masteryAdminSingleMfeUrl = configProperty.getProperty( "MasteryAdminSingleMfe" );
        masteryAdminMultiMfeUrl = configProperty.getProperty( "MasteryAdminMultiMfe" );
        

    }

    @Test ( description = "Verify Mastery for single org District admin", priority = 1, groups = {"SMK-66580" , "Groups" , "GroupsSmokeTest"} )
    public void testCaseAdmin_TC45() throws Exception {

    	 WebDriver selDriver = WebDriverFactory.get( browser );
         // Get driver
         EventFiringWebDriver driver = new EventFiringWebDriver( selDriver );
         EventListener eventListner = new EventListener();
         driver.register( eventListner );
         Log.testCaseInfo( "Verify Mastery for single org District admin" + "<small><b><i>[" + browser + "]</b></i></small>" );
         try {

             // TC_ 1
             SMUtils.logDescriptionTC( "Verify the filter components and reset button" );
             MasteryMfePage masteryMfePage = LoginWrapper.loginToMasteryMfe( driver, masteryAdminSingleMfeUrl, singleUsername, password );
             
             //verify Apply Filter button is present
             Log.assertThat( masteryMfePage.getMasteryFilterComponent().isApplyFilterButtonPresent(), "Apply Filter Button is present ",
                     "Apply Filter Button is not present!" );
             
             //verify Reset button is present
             Log.assertThat( masteryMfePage.getMasteryFilterComponent().isResetFilterButtonPresent(), "Reset Filter Button is present",
                     "Apply Filter Button is not present" );
             
             //verify skills dropdown is visible
             Log.assertThat( masteryMfePage.getMasteryFilterComponent().isSubjectDropDownCollapsed(), "Subject dropdown is present",
                     "Subject dropdown  is not present" );
             
             //verify standards dropdown is visible
             Log.assertThat( masteryMfePage.getMasteryFilterComponent().isSkillsStandardsDropdownPresent(), "Standards dropdown Button is present",
                     "Standards dropdown Button is not present" );
             
             

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
   
    @Test ( description = "Verify Mastery for multi org District admin", priority = 1, groups = {"SMK-66580" , "Groups" , "GroupsSmokeTest"} )
    public void testCaseAdmin_TC45_2() throws Exception {

    	 WebDriver selDriver = WebDriverFactory.get( browser );
         // Get driver
         EventFiringWebDriver driver = new EventFiringWebDriver( selDriver );
         EventListener eventListner = new EventListener();
         driver.register( eventListner );
         Log.testCaseInfo( "Verify Mastery for multi org District admin" + "<small><b><i>[" + browser + "]</b></i></small>" );
         try {

             
             SMUtils.logDescriptionTC( "Verify the filter components and reset button" );
             MasteryMfePage masteryMfePage = LoginWrapper.loginToMasteryMfe( driver, masteryAdminMultiMfeUrl, multiUsername, password );
             
             //verify Apply Filter button is present
             Log.assertThat( masteryMfePage.getMasteryFilterComponent().isApplyFilterButtonPresent(), "Apply Filter Button is present ",
                     "Apply Filter Button is not present!" );
             
             //verify Reset button is present
             Log.assertThat( masteryMfePage.getMasteryFilterComponent().isResetFilterButtonPresent(), "Reset Filter Button is present",
                     "Apply Filter Button is not present" );
             
             //verify skills dropdown is visible
             Log.assertThat( masteryMfePage.getMasteryFilterComponent().isSubjectDropDownCollapsed(), "Subject dropdown Button is present",
                     "Subject dropdown is not present" );
             
             //verify standards dropdown is visible
             Log.assertThat( masteryMfePage.getMasteryFilterComponent().isSkillsStandardsDropdownPresent(), "Standards dropdown Button is present",
                     "Standards dropdown is not present" );
             
             //verify Organization dropdown is visible
             //Missing Multi-org admin due to data setup issue

             

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    

    
    @Test ( description = "Verify Mastery Summary page", priority = 1, groups = {"SMK-66580" , "Groups" , "GroupsSmokeTest"} )
    public void testCaseAdmin_TC46() throws Exception {

    	 WebDriver selDriver = WebDriverFactory.get( browser );
         // Get driver
         EventFiringWebDriver driver = new EventFiringWebDriver( selDriver );
         EventListener eventListner = new EventListener();
         driver.register( eventListner );
         Log.testCaseInfo( "Verify Mastery Summary page" + "<small><b><i>[" + browser + "]</b></i></small>" );
         try {

             // TC_ 1
             SMUtils.logDescriptionTC( "Verify the filter components and reset button" );
             MasteryMfePage masteryMfePage = LoginWrapper.loginToMasteryMfe( driver, masteryAdminSingleMfeUrl, singleUsername, password );
             masteryMfePage.getMasteryFilterComponent().applyFilter();
             
             
             
             //verify strand name and standard name are present
             Log.assertThat( masteryMfePage.getMasterySummaryComponent().verifySkillHeadingIsDisplayed(), "Strand name and Standard name are present ",
                     "Strand name and Standard name are not present!" );
             
             //verify % of mastered bar is present
             Log.assertThat( !masteryMfePage.getMasterySummaryComponent().getStatusColor(browser).isEmpty(), "% of mastered bar is present ",
                     "% of mastered bar is not present!" );
             
             //Verify arrow is present
             Log.assertThat( !masteryMfePage.getMasterySummaryComponent().verifyArrowIsPresent(), "Arrow is present ",
                     "Arrow is not present!" );

             
             

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
   
    @Test ( description = "Verify the mastery listing displayed in the Student details Page", priority = 1, groups = {"SMK-66580" , "Groups" , "GroupsSmokeTest"} )
    public void testCaseAdmin_TC50() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "testCaseAdmin_TC50: Verify the mastery listing displayed in the Student details Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            smnewStudentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            // Getting Student data to navigate to the respective Mastery details
            // Navigate to Student detail Page
            smnewStudentsPage.clickviewStudentByEllipsis( studentUserName1 );
            SMUtils.logDescriptionTC( "Verify the Mastery Sub Nav is present on the Student Details Page" );
            for ( WebElement webElement : smnewStudentsPage.listSideNvaBar ) {
                String subNav = "Mastery";
                if ( webElement.getText().trim().equals( subNav ) ) {
                    SMUtils.scrollIntoView( driver, webElement );
                    Log.assertThat( webElement.isDisplayed(), "Mastery is present on the sub nav", "Mastery is not present on the sub nav" );
                }
            }

            SMUtils.logDescriptionTC( "Verify Teacher able to view Mastery header on clicking Mastery sub tab" );
            smnewStudentsPage.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            Log.assertThat( smnewStudentsPage.isMasteryDisplayed(), "The Mastery sub-navigation is displayed", "The Mastery sub-navigation is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the subject dropdown is present" );
            Log.assertThat( smnewStudentsPage.isStaticDropDownPresent( Mastery_DropDowns.SUBJECT ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );



            SMUtils.logDescriptionTC( "Verify the Assignment Select box is present with total number of assignments" );
            Log.assertThat( smnewStudentsPage.isStaticDropDownPresent( Mastery_DropDowns.ASSIGNMENTS ), "The Assignments drop down is displayed", "The Assignments drop down is not displayed" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "Verify the Legends and its colors in students > Mastery" );
            Log.assertThat( smnewStudentsPage.checkElementPresence( Constants.Students.LEGENDS ), "The Legends are displayed in the mastery Page", "The Legends are not displayed in the mastery Page" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "Verify the skills\\standards dropdown is present" );
            Log.assertThat( smnewStudentsPage.isStaticDropDownPresent( Mastery_DropDowns.MASTERY_SKILL ), "The Skill/Standard drop down is displayed", "The Skill/Standard drop down is not displayed" );
            Log.testCaseResult();




            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    
    @Test ( description = "Verify the mastery listing displayed in the Student details Page", priority = 2, groups = {"SMK-66580" , "Groups" , "GroupsSmokeTest"} )
    public void testCaseAdmin_TC50_2() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            smnewStudentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            // Getting Student data to navigate to the respective Mastery details
            // Navigate to Student detail Page
            smnewStudentsPage.clickviewStudentByEllipsis( studentUserName1 );

            SMUtils.logDescriptionTC( "Verify the mastery listing displayed in the Student details Page" );

            smnewStudentsPage.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            
            Log.assertThat(smnewStudentsPage.checkElementPresence(Constants.Students.LEGENDS),"Assessed Objectives bar is visible",
            		"Assessed Objectives bar is not visible!");

            SMUtils.logDescriptionTC( "Verify the grade in Student-Mastery tab." );
            Log.softAssertThat( smnewStudentsPage.isGradeDisplayed(), "Grade is displayed under mastery tab in the Student mastery page", "Grade is not displayed under mastery tab in the Student mastery page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the presence of the Strand Name in the student Mastery tab." );
            Log.assertThat( smnewStudentsPage.checkElementPresence(Constants.Students.TOPLEVELHIERARCY), "Strand Name is displayed in the Student mastery page",
                    "Strand Name is not displayed in the Student mastery page!" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "Verify the presence of the Strand Name in the student Mastery tab." );
            Log.assertThat( smnewStudentsPage.checkElementPresence(Constants.Students.LODESCRIPTION), "LO is displayed in the Student mastery page",
                    "LO is not displayed in the Student mastery page!" );
            Log.testCaseResult();

            // Check corresponding LO page appears on clicking LO number from skills popup
            SMUtils.logDescriptionTC( "SMK-11768 : Verify the clicking LO number link from Skill popup navigates to corresponding LO viewer -" );
            smnewStudentsPage.clickFirstLO();
            //Log.assertThat( smnewStudentsPage.getLONumberfromUrl().contains( loNumber ), "Corresponding LO viewer page displays on clicking LO number", "Corresponding LO page is not displaying" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Assignment's Mastery Summary Page", priority = 3, groups = {"SMK-66580" , "Groups" , "GroupsSmokeTest"} )
    public void testCaseAdmin_TC57() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
	    SMUtils.logDescriptionTC( "Verify Assignment's Mastery Summary Page" );
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            assignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            assignmentDetailsPage = assignmentsPage.clickViewAssignment();
            assignmentDetailsPage.clickMasteryToggleButton();
            
            //Verify Strand is visible
            Log.softAssertThat(assignmentDetailsPage.verifyMasteryStrand(), "Verified Mastery Strand is visible", 
            		"Mastery Strand is not visible!");
            
            //Verify Mastery bar, Skills and Standards
            Log.softAssertThat( !assignmentDetailsPage.getSkillsCorrectCountAndPercentage().isEmpty(),"Verified Skills and Standards are present",
            		"Skills and Standards are not present!");
            
            
            //Verify LO presence
            Log.softAssertThat( assignmentDetailsPage.verifyArrow(),"Verified LO Arrow is present",
            		"LO Arrow is not present!");
            
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Mastery LO Details in Student view page", priority = 4, groups = {"SMK-66580" , "Groups" , "GroupsSmokeTest"} )
    public void testCaseAdmin_TC58() throws Exception {

		// Get driver

		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        try {
	     SMUtils.logDescriptionTC( "Verify Assignment's LO Details Page" );
       	     TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, "smautoregtestautosch5t1@regressionautomation_ui", "testing123$" );

             assignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
             assignmentDetailsPage = assignmentsPage.clickViewAssignment();
             assignmentDetailsPage.clickMasteryToggleButton();
             
             //navigate to and verify the LO details page has loaded
             Log.softAssertThat(assignmentDetailsPage.navigateToLoViewPage(), "Pass", "Fail");
             
             //Verify Strand Name
             Log.softAssertThat(assignmentDetailsPage.verifyStrand(), "Pass", "Fail");
             
             //Verify Skills/standards name
             Log.softAssertThat(assignmentDetailsPage.verifyStandard(), "Pass", "Fail");
             
             //Verify Progress Bar
             Log.softAssertThat(assignmentDetailsPage.verifyProgressBar(), "Pass", "Fail");
             
             //verify student name column
             Log.softAssertThat(assignmentDetailsPage.verifyStudentNameColumn(), "Pass", "Fail");
             
             //verify mastery status column
             Log.softAssertThat(assignmentDetailsPage.verifyMasteryStatusColumn(), "Pass", "Fail");
             
             //verify skills evaluated column
             Log.softAssertThat(assignmentDetailsPage.verifySkillsColumn(), "Pass", "Fail");   
             
             //verify Attempts column
             Log.softAssertThat(assignmentDetailsPage.verifyStudentAttemptsColumn(), "Pass", "Fail"); 
                         
             Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
    
}
