package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;

import LSTFAI.customfactories.EventFiringWebDriver;

public class StudentProgressGraph extends BaseTest {

    private String teacherID;
    private String studentID2;
    private String assignmentId = null;

    private String teacherId;
    private String orgId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    List<String> studentIdList = null;
    List<String> studentUserNames = null;
    List<String> dates = new ArrayList<>();
    List<String> ValuesOfYAxis = new ArrayList<>();
    String teacherDetails = null;
    String customBySettingsMathCourse;
    String customBySettingsReadingCourse;
    String customCustomCourseReading;
    String customCustomCourseMath;

    private AtomicReference<String> schoolUsed = new AtomicReference<String>();

    @BeforeClass
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        orgId = RBSDataSetup.organizationIDs.get( schoolUsed.get() );

        teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        ArrayList<String> studentDetails = new ArrayList<String>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<String>();
        studentUserNames = new ArrayList<String>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

    }

    @Test ( description = "Verify the Zero state Message in Student Progress Graph", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress001( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14453 : Validate the Zero State Message on the Student Progress Graph" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab 
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Validating the No Data Text for student who has no progress in the Assignment
            Log.assertThat( studentPage.getNoDataTextFromStudentProgress().equals( Constants.Students.NO_DATA_MESSAGE ), "Zero State Message Displayed Successfuly", "Zero State Message Not Displayed" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Course Execution Method", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress002() throws Exception {

        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = new RBSDataSetup().generateRequestValues( new RBSUtils().getUser( studentIdList.get( 0 ) ), studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( schoolUsed ) );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.GRADE, grade.FOURTH.toString() );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            customBySettingsMathCourse = Constants.Students.MATH_CUSTOM_BY_SETTINGS + RandomStringUtils.randomAlphabetic( 5 );
            customBySettingsReadingCourse = Constants.Students.READING_CUSTOM_BY_SETTINGS + RandomStringUtils.randomAlphabetic( 5 );
            // create Math custom course by settings
            coursePage.createCustomBySettingCourseWithIPOff( customBySettingsMathCourse, Constants.Students.DEFAULT_MATH );
            // create Reading custom course by settings
            coursePage.createCustomBySettingCourseWithIPOff( customBySettingsReadingCourse, Constants.Students.DEFAULT_READING );
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Assigning Course to student
            coursePage.clickCourseName( customBySettingsMathCourse );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            // Assigning Course to student
            coursePage.clickCourseName( customBySettingsReadingCourse );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            // SignOut 
            tHomePage.topNavBar.signOutfromSM();
            driver.quit();

            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
    		driver.register(eventListner);
            LoginPage smLoginPage1 = new LoginPage( driver, smUrl ).get();

            // Login as Student into Student dashBoard
            smLoginPage1.loginToSMasStudent( studentUserNames.get( 0 ), password, true );

            StudentDashboardPage stuPage = new StudentDashboardPage( driver );

            Log.message( "Math Custom Course Execution" );
            stuPage.executeMathCourse( teacherID, customBySettingsMathCourse, "100", "2", "20" );

            Log.message( "Reading Custom Course Execution" );
            stuPage.executeReadingCourse( teacherID, customBySettingsReadingCourse, "100", "2", "10" );

            // Course Execution
            int j = 1;
            // Need to attend 150 questions to clear ip. Each interation 50 Questions. So Gave count as 4 and total ques is 200.
            while ( j <= 4 ) {
                Log.message( "Reading Course Execution" );
                stuPage.executeReadingCourse( teacherID, Constants.Students.DEFAULT_READING, "100", "2", "10" );
                j++;
            }

            // Course Execution
            int i = 1;
            // Need to attend 150 questions to clear ip. Each interation 50 Questions. So Gave count as 4 and total ques is 200.
            while ( i <= 4 ) {
                Log.message( "Math Course Execution" );
                stuPage.executeMathCourse( teacherID, Constants.Students.DEFAULT_MATH, "100", "2", "25" );
                i++;
            }

            // Logout
            stuPage.logout();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the view details link for Student Progress Graph in student details page", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress004( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14448 : Verify the \"view details\" link for Student Progress Graph in student details page" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab 
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            studentPage.clickDropDownInStudentProgressgraph();

            studentPage.selectSubjectFromStudentProgressDropDown( Constants.Students.DEFAULT_MATH );

            // View Details Link Clicked for the above Subject
            studentPage.clickViewDetails();

            // Get the skills tested heading From the Assigment Details Page 
            String textInAssignmentDetailsPage = studentPage.getSkillsTestedTextInAssignmentDetailsPage();

            // Validating the view details link navigating to the assignment details page with expanded 
            Log.assertThat( textInAssignmentDetailsPage.equals( "Skills Tested" ), "View Details Link navigated the user to the Assignment Details Page of the " + textInAssignmentDetailsPage + " Successfully ",
                    "View Details Link Not working as Expected" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Yaxis has 5 Values", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress005( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	SMUtils.logDescriptionTC( "SMK-14504 : Verify the Yaxis has 5 Values" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab 
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Click DropDown
            studentPage.clickDropDownInStudentProgressgraph();

            // Select Course From the DropDown
            studentPage.selectSubjectFromStudentProgressDropDown( Constants.MATH );

            //  Get the Sixw of the Y axis in the student progress graph
            int sizeOfYAxisValues = studentPage.getSizeOfYAxisValues();

            // validate whether Y axis Displays all the Values in the graph as Expected
            Log.assertThat( sizeOfYAxisValues == Constants.Students.SIZE_OF_YAXIS, "Y axis Displays the " + sizeOfYAxisValues + " Values as expected ", " Y axis Displays the " + sizeOfYAxisValues + " Values As not expected " );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Custom By Settings based on default Maths and default Reading should display in the Student progress Graph Drop Down. ", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress006( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14462 : Verify the Custom By Settings based on default Maths should display in the Student progress Graph Drop Down." );
        SMUtils.logDescriptionTC( "SMK-14463 : Verify the Custom By Settings based on default Reading should display in the Student progress Graph Drop Down" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigating to the Student tab 
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Click the DropDown
            studentPage.clickDropDownInStudentProgressgraph();

            //To check custom by settings maths course is available in the dropdown
            Boolean isMathCustomAvailable = studentPage.isSubjectAvailableFromTheProgressDropDown( customBySettingsMathCourse );

            //To  check custom by Settings Reading Course is available in the dropdown
            Boolean isReadingCustomAvailable = studentPage.isSubjectAvailableFromTheProgressDropDown( customBySettingsReadingCourse );

            //  Validating the Custom By Setting Math is Available on the Drop Down
            Log.assertThat( isMathCustomAvailable, "Math Custom By Setting Course is showing on the Drop Down", "Math Custom By Setting Course is not showing on the Drop Down" );

            // Validating the Custom By Setting Reading is Available on the Drop Down
            Log.assertThat( isReadingCustomAvailable, "Reading Custom By Setting Course is showing on the Drop Down", "Math Custom By Setting Course is not showing on the Drop Down" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Focused and other custom course will not listed on dropdown", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress007( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14464 : Verify the Focused and other custom course will not listed on dropdown" );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            customCustomCourseReading = Constants.Students.SKILL_COURSE + RandomStringUtils.randomAlphabetic( 5 );
            customCustomCourseMath = Constants.Students.STANDARD_COURSE + RandomStringUtils.randomAlphabetic( 5 );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            // Creating and assigning reading skill custom course
            coursePage.copyOfCourse( customCustomCourseReading, "Skills", Constants.Students.DEFAULT_READING );
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( customCustomCourseReading );
            coursePage.clickAssignBtn();
            coursePage.addCourseToOneStudent( studentUserNames.get( 0 ) );

            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            // Creating and assigning reading standard custom course
            coursePage.copyOfCourse( customCustomCourseMath, "Standards", Constants.Students.DEFAULT_MATH );
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( customCustomCourseMath );
            coursePage.clickAssignBtn();
            coursePage.addCourseToOneStudent( studentUserNames.get( 0 ) );
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            // Assigning Focus Course
            coursePage.clickCourseName( Constants.Students.FOCUS_COURSE_MATH );
            coursePage.clickAssignBtn();
            coursePage.addCourseToOneStudent( studentUserNames.get( 0 ) );

            // Navigating to the Student tab 
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Click the DropDown 
            studentPage.clickDropDownInStudentProgressgraph();

            //To check custom by Skill course is available in the dropdown 
            Boolean isCustomBySkillAvailable = studentPage.isSubjectAvailableFromTheProgressDropDown( customCustomCourseReading );

            //To check custom by Standard Course is available in the dropdown 
            Boolean isCustomByStandardAvailable = studentPage.isSubjectAvailableFromTheProgressDropDown( customCustomCourseMath );

            //To check custom by Standard Course is available in the dropdown 
            Boolean isFocusCourseAvailable = studentPage.isSubjectAvailableFromTheProgressDropDown( Constants.Students.FOCUS_COURSE_MATH );

            // Validating the Custom By SKill is Available on the Drop Down
            Log.assertThat( !isCustomBySkillAvailable, "Custom By Skill Course is not showing on the Drop Down as Expected", "Custom By Skill Course is showing on the Drop Down as not Expected" );

            // Validating the Custom By Standard is Available on the Drop Down
            Log.assertThat( !isCustomByStandardAvailable, "Custom By Standard Course is not showing on the Drop Down as Expected", "Custom By Standrad Course is not showing on the Drop Down as not Expected" );

            // Validating the Focus Course is Available on the Drop Down
            Log.assertThat( !isFocusCourseAvailable, "Focus Course is not showing on the Drop Down as Expected", "Custom By Skill Course is showing on the Drop Down as not Expected" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the IP level,Curent level,Gain is displayed on the Student progress graph", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress008( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14467 : Verify the IP level is displayed on the Student progress graph " );
        SMUtils.logDescriptionTC( "SMK-14468 : Verify the Curent level is displayed on the Student progress graph " );
        SMUtils.logDescriptionTC( "SMK-14469 : Verify the Gain is displayed on the Student progress graph " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab 
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Click the DropDown 
            studentPage.clickDropDownInStudentProgressgraph();

            // Select Course From the DropDown
            studentPage.selectSubjectFromStudentProgressDropDown( Constants.Students.DEFAULT_MATH );

            // Validating the Gain Field on the Progress Graph 
            Log.assertThat( studentPage.verifyLeftSideFieldsOnProgressGraph( Constants.Students.GAIN_FIELD ), "Gain Field is Present on the Progress Graph", "Gain Field is not Present on the Progress Graph" );

            // Validating the Current Level Field on the Progress Graph
            Log.assertThat( studentPage.verifyLeftSideFieldsOnProgressGraph( Constants.Students.CURRENT_LEVEL_FIELD ), "Current Level Field is Present on the Progress Graph", "Current Level Field is not Present on the Progress Graph" );

            // Validating the IP Level Field on the Progress Graph 
            Log.assertThat( studentPage.verifyLeftSideFieldsOnProgressGraph( Constants.Students.IP_LEVEL ), "IP Level Field is Present on the Progress Graph", "IP Level Field is not Present on the Progress Graph" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Assigned level field for custom by setting IPM off assignment.", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress009( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14491 : Verify the Assigned level field for custom by setting IPM off assignment. " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab 
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // click Dropdown
            studentPage.clickDropDownInStudentProgressgraph();

            // Select Subject
            studentPage.selectSubjectFromStudentProgressDropDown( customBySettingsMathCourse );

            // Validating Assigned Level Field on the Progress Graph 
            Log.assertThat( studentPage.verifyLeftSideFieldsOnProgressGraph( Constants.Students.ASSIGNED_LEVEL ), "Assigned Level Field is Present on the Progress Graph", "Assigned Level Field is not Present on the Progress Graph" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the assigned level is the Starting level for IPM off courses.", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress010( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14490 : Verify the assigned level is the Starting level for IPM off courses." );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab 
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // click Dropdown
            studentPage.clickDropDownInStudentProgressgraph();

            // Select Course From the DropDown
            studentPage.selectSubjectFromStudentProgressDropDown( customBySettingsMathCourse );

            // Get Assigned Level Value 
            double AssignedLevel = studentPage.getTheValueOfTheField( Constants.Students.ASSIGNED_LEVEL );

            // Click View Details Link 
            studentPage.clickViewDetails();

            // Get Starting Level on the Y axis 
            double startingLevelOfCourse = studentPage.getStartingLevelYAxisInStudentProgressGraph();

            // Validating Assigned Level Field is the starting level of the course on the Progress Graph
            Log.assertThat( startingLevelOfCourse == AssignedLevel, " Assigned Level Field  is the starting level of the course on the Progress Graph", " Assigned Level Field is not the starting level of the course on the Progress Graph" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Gain is difference of ip level and current level", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress011( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-14445 : Verify the Gain is difference of ip level and current level" );
        SMUtils.logDescriptionTC( "SMK-14461 : Verify the dropdown value selected as reading in Student Progress Graph" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab 
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Click the DropDown 
            studentPage.clickDropDownInStudentProgressgraph();

            // Case 1

            // Select Course From the DropDown
            studentPage.selectSubjectFromStudentProgressDropDown( Constants.Students.DEFAULT_MATH );

            // verify the Gain Field for Default Math
            Boolean GainField = studentPage.verifyTheGainField();

            // Validating the Gain is the Difference of IP Level and Current Level
            Log.assertThat( GainField, "The Gain is the Difference of IP Level and Current Level as Expected", "The Gain is not the Difference of IP Level and Current Level as Expected" );

            // Click the DropDown 
            studentPage.clickDropDownInStudentProgressgraph();

            // Case 2 Drop Down value selected as Rreading and validated Gain field additionally

            // Select Course From the DropDown
            studentPage.selectSubjectFromStudentProgressDropDown( Constants.Students.DEFAULT_READING );

            //verify the Gain Field for Default Reading
            Boolean GainFields = studentPage.verifyTheGainField();

            // Validating the Gain is the Difference of IP Level and Current Level
            Log.assertThat( GainFields, "The Gain is the Difference of IP Level and Current Level as Expected", "The Gain is not the Difference of IP Level and Current Level as Expected" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Tool Tip for the Course name in the Drop down", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress012( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14501 : Verify the Tool Tip for the Course name in the Drop down" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            // Creating and assigning reading skill custom course
            String courseNameWithEllipses = "CourseForToolTipVerification" + System.nanoTime();
            coursePage.createCustomBySettingCourseWithIPOff( courseNameWithEllipses, Constants.Students.DEFAULT_MATH );
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( courseNameWithEllipses );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            // Navigating to the Student tab 
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Click the DropDown 
            studentPage.clickDropDownInStudentProgressgraph();

            // Verify the presence of tool tip
            Boolean isToolTipPresent = studentPage.verifyToolTip( courseNameWithEllipses );

            // Validating the tool tip for the Assignment in the DropDown
            Log.assertThat( isToolTipPresent, "Tool Tip is present in the DropDown for the newlyCreatedCourseForToolTipVerification ", "Tool Tip is Not present" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verified the Student 's Student Progress Graph when the assignment is paused", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress013( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14480 : Verified the Student 's Student Progress Graph when the assignment is paused" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Clicking Assignment from the side nav Bar option
            studentPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT );

            // Click Ellipsis Button for the Selected assignment
            studentPage.clickElipsisButtonOfAssignment( customBySettingsMathCourse );

            // Click Pause Button option on the the list
            studentPage.clickPauseButtonOptionOnAssignmentTab( customBySettingsMathCourse );

            // Object creation for AssignmentDetailsPage
            AssignmentDetailsPage assignPage = new AssignmentDetailsPage( driver );

            // Click Pause Button on the Pop Up
            assignPage.clickPauseButtononPopUpPage();

            tHomePage.topNavBar.navigateToHomeTab();

            tHomePage.topNavBar.navigateToStudentsTab();

            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Click the DropDown studentPage.clickDropDown();
            studentPage.clickDropDownInStudentProgressgraph();

            //Select Course from the Dropdown
            studentPage.selectSubjectFromStudentProgressDropDown( customBySettingsMathCourse );

            // Validate Student Progress graph is showing for paused ssignment\
            Log.assertThat( studentPage.verifyLeftSideFieldsOnProgressGraph( Constants.Students.CURRENT_LEVEL_FIELD ), "Progress Graph is Displayed for Paused Assignment", "Progress Graph Not Displayed" );
            Log.assertThat( studentPage.verifyLeftSideFieldsOnProgressGraph( Constants.Students.GAIN_FIELD ), "Progress Graph is Displayed for Paused Assignment", "Progress Graph Not Displayed" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the different assignment is selectable in dropdown and Graph should be updated according to the Assignment selected.", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress014( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14458 : Verify the different assignment is selectable in dropdown and Graph should be updated according to the Assignment selected." );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Select Student
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Click the DropDown studentPage.clickDropDown();
            studentPage.clickDropDownInStudentProgressgraph();

            // Select Assignment from the dropdown
            studentPage.selectSubjectFromStudentProgressDropDown( Constants.Students.DEFAULT_MATH );

            // Get IP Level value of Math course
            double theValueOfCurrentLevelMath = studentPage.getTheValueOfTheField( Constants.Students.CURRENT_LEVEL_FIELD );

            // Click the DropDown studentPage.clickDropDown();
            studentPage.clickDropDownInStudentProgressgraph();

            // Select Assignment from the dropdown
            studentPage.selectSubjectFromStudentProgressDropDown( customBySettingsMathCourse );

            // Get IP Level value of Reading course
            double theValueOfCurrentLevelReading = studentPage.getTheValueOfTheField( Constants.Students.CURRENT_LEVEL_FIELD );

            // Validating  courses is selectable in dropdown and the graph updated according to the assignment selected
            Log.assertThat( !( theValueOfCurrentLevelMath == theValueOfCurrentLevelReading ), " selected different assignments in the drop down and Graph changed according to the selection", "Graph not changed according to the selection" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verified the Prgress Monitoring graph when the Assignment was deleted", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress015( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14476 : Verified the Prgress Monitoring graph when the Assignment was deleted" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to the Assignment Details Page
            AssignmentsPage assignPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            assignPage.viewAssignmentDetailsByAssignmentName( customBySettingsReadingCourse );

            AssignmentDetailsPage assignDePage = new AssignmentDetailsPage( driver );
            assignDePage.assignmentLevelEllipsis();
            assignDePage.deleteAssignmenttab();
            assignDePage.deleteAssignmentButton();
            assignPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Navigating to the Student tab
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click Ellipsis and View Student Button
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Click the DropDown
            studentPage.clickDropDownInStudentProgressgraph();

            //To check custom by  Standard Course is available in the dropdown
            Boolean isCustomByStandardAvailable = studentPage.isSubjectAvailableFromTheProgressDropDown( customBySettingsReadingCourse );

            //  validate whether Y axis Displays all the Values in the graph as Expected
            Log.assertThat( !isCustomByStandardAvailable, " " + customBySettingsReadingCourse + " is Deleted and Not present in the Student Progress DropDown",
                    " " + customBySettingsReadingCourse + " is Present in the DropDown After Removing the Course " );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verified the Prgress Monitoring graph when the student was deleted", groups = { "SMK-39159", "Teacher", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress016( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	SMUtils.logDescriptionTC( "SMK-14476 : Verified the Prgress Monitoring graph when the student was deleted" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            // Login as teacher
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 1 ) );
            studentPage.removeStudentFromAllGroup();

            // Find that student not present
            Boolean studentNotPresent = studentPage.isStudentNotPresent( studentUserNames.get( 1 ) );

            // Validating the deleted studnet is present in the Student Listing
            Log.assertThat( studentNotPresent, "Student is Deleted and details not found so there is no pregress graph for deleted student", "Not as Expected" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the default Course if Dropdown have multiple assignments", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )

    public void tcStudentProgress017( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	SMUtils.logDescriptionTC( "SMK-14460 : Verify the default Course if Dropdown have multiple assignments " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            // Login
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click student 
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // Get Default Subject from the Dropdown
            String defaultSubjectFromProgressDropDown = studentPage.getDefaultSubjectFromProgressDropDown();

            // Validating the deleted studnet is present in the Student Listing
            Log.softAssertThat( defaultSubjectFromProgressDropDown.equals( Constants.Students.DEFAULT_MATH ), "Math is Selected as Default assignment in the DropDown as Expected", "Not Shown as Expected" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the X and Y Axis Values in the Student Progress Graph", groups = { "SMK-39159", "Student", "StudentProgressGraph" }, priority = 1 )
    public void tcStudentProgress018() throws Exception {
        // Get driver 
        getAssignmentID();
        getProgressMonitoringDetailFromAPI();
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14471 : Verify the X axis display date values for Student progress graph" );
        SMUtils.logDescriptionTC( "SMK-14475 : Verify the Y axis values display course level values" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            // Login
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Student tab
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Click student 
            studentPage.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );

            // click Dropdown
            studentPage.clickDropDownInStudentProgressgraph();

            // Select Subject
            studentPage.selectSubjectFromStudentProgressDropDown( customBySettingsMathCourse );

            // Get API dates
            List<String> apiXAxisDate = studentPage.convertEpochDateToNormalDate( dates );

            // Get X Axis Dates in UI
            List<String> xAxisDateOnUI = studentPage.getXAxisDatesinStudentProgressGraph();

            // Validating the X axis date in UI with API response
            Log.assertThat( apiXAxisDate.equals( xAxisDateOnUI ), "API X Axis Date is matching with the UI date ", "API X Axis Date is not matching with the UI date" );

            // Validating the Y axis value in UI with API response
            Log.assertThat( studentPage.isYAxisFirstAndLastValueSame( ValuesOfYAxis ), "API Y Axis Value is matching with the UI Y Axis Value ", "API Y Axis Value is not matching with the UI Y Axis Value" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public void getAssignmentID() throws Exception {
        HashMap<String, String> assignmentDetails = new HashMap<>();
        String endpoint = "null";
        Log.message( "username = " + username );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );

        assignmentDetails.put( AssignmentAPIConstants.STUDENT_ID, studentIdList.get( 0 ) );
        endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
        endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) );
        endpoint = endpoint.replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
        endpoint = endpoint.replace( "{studentID}", assignmentDetails.get( AssignmentAPIConstants.STUDENT_ID ) );

        HashMap<String, String> studnetAssignmentDetailsByStudnetID = new AssignmentAPI().getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );

        assignmentId = null;
        IntStream.rangeClosed( 1, SMUtils.getWordCount( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( customBySettingsMathCourse ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( studnetAssignmentDetailsByStudnetID.get( Constants.BODY ), "assignmentId", index );
            }
        } );
    }

    public void getProgressMonitoringDetailFromAPI() throws Exception {

        HashMap<String, String> apiDetails = new HashMap<>();
        apiDetails.put( Constants.USERID, teacherId );
        apiDetails.put( Constants.GROUP_ORG_ID, orgId );
        apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        apiDetails.put( Constants.ORGANIZATION_ID, orgId );
        apiDetails.put( Constants.TEACHER_ID, teacherId );
        apiDetails.put( Constants.ASSIGNMENT_ID, assignmentId );
        apiDetails.put( Constants.STUDENT_ID, studentIdList.get( 0 ) );
        apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
        apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );

        HashMap<String, String> response = new UserAPI().studentProgressGraphAPI( smUrl, apiDetails );
        Log.message( "Progress Monitoring Report: " + response );
        // Getting Date value from response        
        String reponseData = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data" );
        JSONObject jsonObj = new JSONObject( reponseData );
        JSONArray ja = jsonObj.getJSONArray( "courseLevel" );
        for ( int eachdate = 0; eachdate <= 3; eachdate++ ) {
            JSONObject jObj = ja.getJSONObject( eachdate );
            String dateValueFromResponse = jObj.get( "date" ).toString();
            String courseValueFromResponse = jObj.get( "courseValue" ).toString();
            NumberFormat formatter = new DecimalFormat( "#0.00" );
            String formatedCourseValue = formatter.format( Double.parseDouble( courseValueFromResponse ) );
            dates.add( dateValueFromResponse );
            ValuesOfYAxis.add( formatedCourseValue );
        }

    }

}
