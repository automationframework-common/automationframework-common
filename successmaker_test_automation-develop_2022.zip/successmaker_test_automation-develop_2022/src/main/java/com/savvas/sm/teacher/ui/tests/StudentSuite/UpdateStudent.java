package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

public class UpdateStudent extends BaseTest {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String teacherDetails = null;
    public String USERNAME_ERROR_MESSAGE = "Username already exists";
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String studentUsed;
    String studentUsername;
    String studentUsed2;
    String studentUsername2;

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );

        // String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher1" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentUsed = RBSDataSetup.getMyStudent( school, username );
        studentUsed2 = RBSDataSetup.getMyStudent( school, username );
        studentUsername2 = SMUtils.getKeyValueFromResponse( studentUsed2, "userName" );

        studentUsername = SMUtils.getKeyValueFromResponse( studentUsed, "userName" );
    }

    @Test ( description = "Verify First Name is enabled and able to edit the value in the field", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS001( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS001: Verify First Name is enabled and able to edit the value in the field <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            //LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );
            Log.message( "g" + studentUsed );
            //TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            //TeacherHomePage tHomePage = smLoginPage.lo( "nk_usage_t1", "testing123$", true );

            // String studentID = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,userName" );
            //String studentID = "stud_5777";
            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.scrollDownPage( driver );

            // Update the First Name
            studentsPage.changeFirstName( Constants.Students.UPDATE_FIRSTNAME );
            Log.message( studentsPage.getFirstName() );
            Log.message( Constants.Students.UPDATE_FIRSTNAME );
            Log.assertThat( studentsPage.getFirstName().trim().equals( Constants.Students.UPDATE_FIRSTNAME ), "First Name updated", "First name not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Middle Name is enabled and able to edit the value in the field", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS002( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS002: Verify Middle Name is enabled and able to edit the value in the field <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu

            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.scrollDownPage( driver );

            //Update the Middle Name
            studentsPage.changeMiddleName( Constants.Students.UPDATE_MIDDLENAME );
            Log.assertThat( studentsPage.getMiddleName().trim().equals( Constants.Students.UPDATE_MIDDLENAME ), "Middle Name updated", "Middle name not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Last Name is enabled and able to edit the value in the field", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS003( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS003: Verify Last Name is enabled and able to edit the value in the field <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.scrollDownPage( driver );

            // Update the Last Name
            studentsPage.changeLastName( Constants.Students.UPDATE_LASTNAME );
            Log.message( studentsPage.getLastName() );
            Log.message( Constants.Students.UPDATE_LASTNAME );
            Log.assertThat( studentsPage.getLastName().trim().equals( Constants.Students.UPDATE_LASTNAME ), "last Name updated", "last name not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify student id is enabled and able to edit the value in the field", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS004( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS004: Verify student id is enabled and able to edit the value in the field <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.scrollDownPage( driver );

            // Update the Student ID
            String studentID = Constants.Students.UPDATE_STUDENTID;
            studentsPage.changeStudentId( studentID );
            studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.scrollDownPage( driver );

            Log.assertThat( studentsPage.getStudentId().trim().equals( studentID ), "Student Id updated", "Student Id not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verfiy Grade drop down allows the user to select other options to select", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS005( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	// Get Test Data
        Log.testCaseInfo( "tcSMUS005: Verfiy Grade drop down allows the user to select other options to select <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            Log.message( "studname" + studentUsername );
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.scrollDownPage( driver );

            // Update the Grade value
            SMUtils.waitForElement( driver, studentsPage.ddGradeSelectionUpdateStudent );
            SMUtils.clickJS( driver, studentsPage.ddGradeSelectionUpdateStudent );
            studentsPage.selectGrade( Constants.Students.GRADE_5 );
            studentsPage.clickSaveButtoninUserProfile();
            Log.assertThat( studentsPage.getGradeValue().equals( Constants.Students.GRADE_5 ), "Grade updated", "Grade Id not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify username is enabled and able to edit the value in the field", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS006( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS006: Verify username is enabled and able to edit the value in the field <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu

            Log.message( "studname" + studentUsername2 );
            studentsPage.clickviewStudentByEllipsis( studentUsername2 );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.scrollDownPage( driver );

            // Update the User name
            studentsPage.changeUserName( Constants.Students.UPDATE_USERNAME );
            Log.assertThat( studentsPage.getUserName().trim().equals( Constants.Students.UPDATE_USERNAME ), "User Name updated", "User Name not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Grade drop down displays all grades as option with not specified", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS007( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS007: Verify Grade drop down displays all grades as option with not specified <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );
            SMUtils.nap( 2 );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.scrollDownPage( driver );

            //Get List of Grade values
            List<String> gradeListing = studentsPage.getAllGradeValuesinUserProfile();
            //studentsPage.ddGradeSelectionUpdateStudent.click();
            //List<String> allGrades = new ArrayList<>( Arrays.asList( "Grade K", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12", "Not Specified" ) );
            Log.assertThat( gradeListing.containsAll( Constants.Students.ALL_GRADES ), "Grades are listing", "Grades are not listing properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Grade drop down displays all grades as option with not specified", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS008( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS008: Verify Date of Birth is enabled and able to edit the value in the field <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.scrollDownPage( driver );

            // Update the Date of Birth
            studentsPage.updateDateOfBirth( Constants.Students.DOB_UPDATE );
            Log.assertThat( studentsPage.getDateOfBirth().equals( Constants.Students.DOB_UPDATE ), "Date Of Birth updated", "Date Of Birth not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify password is enabled and able to edit the value in the field", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS009( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data
        Log.testCaseInfo( "tcSMUS009: Verify password is enabled and able to edit the value in the field <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );
            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );

            // Update the User Password
            studentsPage.changePassword( Constants.Students.UPDATE_PASSWORD );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            driver.quit();
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            LoginPage studentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentHomePage = LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, LoginConstants.UserType.PLUS, null, studentUsername, Constants.Students.UPDATE_PASSWORD );

            studentHomePage.logout();
            Log.message( "password updated" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Ethncity drop down displays all values as option with not specified", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS010( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS010: Verify Race/Ethncity drop down displays all values as option with not specified <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.waitForElement( driver, studentsPage.ddEthnicitySelectionUpdateStudent );

            // Update the EthnicityValues
            List<String> ethnicityValues = studentsPage.getEthnicityValues();
            studentsPage.ddEthnicitySelectionUpdateStudent.click();
            Log.assertThat( ethnicityValues.equals( Constants.Students.ETHNICITY_LISTING ), "EthnicityValues are updated", "EthnicityValues are not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify special services drop down displays all values as option with not specified ", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS011( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS011: Verify special services drop down displays all values as option with not specified <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.waitForElement( driver, studentsPage.ddSpecialServicesnUpdateStudent );

            // Update the Special Service Values
            List<String> specialServiceValues = studentsPage.getSpecialServiceValues();
            studentsPage.ddSpecialServicesnUpdateStudent.click();
            Log.assertThat( specialServiceValues.containsAll( Constants.Students.SPL_SERVICE_LISTING ), "specialServiceValues are updated", "specialServiceValues are not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify disabilityStatus drop down displays all values as option with not specified", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS012( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	// Get Test Data
        Log.testCaseInfo( "tcSMUS012: Verify disabilityStatus drop down displays all values as option with not specified <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.waitForElement( driver, studentsPage.ddSpecialServicesnUpdateStudent );

            // Update the Disability values
            List<String> disabilityStatusValues = studentsPage.getDisabilityStatusValues();
            Log.assertThat( disabilityStatusValues.containsAll( Constants.Students.DISSABILITY_LISTING ), "DisabilityStatusValues are updated", "DisabilityStatusValues are not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify gender drop down displays all values as option with not specified", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS013( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS013: Verify gender drop down displays all values as option with not specified <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.waitForElement( driver, studentsPage.ddSpecialServicesnUpdateStudent );

            // Update the Gender values
            List<String> genderValues = studentsPage.getGenderValues();
            SMUtils.clickJS( driver, studentsPage.ddGenderUpdateStudent );
            Log.assertThat( genderValues.containsAll( Constants.Students.GENDER_LISTING ), "GenderValues are updated", "GenderValues are not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Socioeconomic Status drop down displays all values as option with not specified", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS014( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS014: Verify Socioeconomic Status drop down displays all values as option with not specified <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.waitForElement( driver, studentsPage.ddSpecialServicesnUpdateStudent );

            // Update the Economic values
            List<String> economicValues = studentsPage.getEconomicValues();
            SMUtils.clickJS( driver, studentsPage.ddEconomicStatusUpdateStudent );
            Log.assertThat( economicValues.containsAll( Constants.Students.ECONOMIC_LISTING ), "EconomicValues are updated", "EconomicValues are not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify English Language drop down displays all values as option with not specified", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS015( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS015: Verify English Language drop down displays all values as option with not specified <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.waitForElement( driver, studentsPage.ddSpecialServicesnUpdateStudent );

            // Update the English values
            List<String> hasEnglishValues = studentsPage.getHasEnglishValues();
            SMUtils.clickJS( driver, studentsPage.ddEnglishUpdateStudent );
            Log.assertThat( hasEnglishValues.containsAll( Constants.Students.ENGLISH_LISTING ), "hasEnglishValues are updated", "hasEnglishValues are not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Migrant Status drop down displays all values as option with not specified", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS016( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "tcSMUS016: Verify Migrant Status drop down displays all values as option with not specified <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.waitForElement( driver, studentsPage.ddSpecialServicesnUpdateStudent );

            // Update the Migrant values
            List<String> migrantValues = studentsPage.getMigrantValues();
            SMUtils.clickJS( driver, studentsPage.ddMigrantUpdateStudent );
            Log.assertThat( migrantValues.equals( Constants.Students.MIGRANT_LISTING ), "migrantValues are updated", "migrantValues are not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Race drop down displays all values as option with not specified", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS017( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	// Get Test Data
        Log.testCaseInfo( "tcSMUS017: Verify Race drop down displays all values as option with not specified <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUsername );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.waitForElement( driver, studentsPage.ddRaceSelectionUpdateStudent );

            // Update the raceValues
            List<String> raceValues = studentsPage.getRaceValues();
            studentsPage.ddRaceSelectionUpdateStudent.click();
            Log.assertThat( raceValues.equals( Constants.Students.RACE_LISTING ), "RaceValues are displaying as expected", "RaceValues are not listed properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher able to update Demographic values for suspended student", groups = { "SMK-39171", "student", "Details", "User Profile", "Updatestudent" }, priority = 1 )
    public void tcSMUS018( ITestContext context ) throws Exception {

        String student = RBSDataSetup.getMyStudent( school, username );
        String studentId = SMUtils.getKeyValueFromResponse( student, RBSDataSetupConstants.USERID );
        new RBSUtils().suspendUser( Arrays.asList( studentId ) );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);

        // Get Test Data
        Log.testCaseInfo( "Verify the teacher able to update Demographic values for suspended student. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper loginpage = new LoginWrapper();
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            String studentUserName = SMUtils.getKeyValueFromResponse( student, RBSDataSetupConstants.USERNAME );
            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentUserName );

            // Navigate to User profile option
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.waitForElement( driver, studentsPage.ddRaceSelectionUpdateStudent );
            studentsPage.selectDemographicValues( UserConstants.GENDER_FIELD, "Not Specified" );
            studentsPage.clickSaveButtoninUserProfile();

            tHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentUserName );
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.waitForElement( driver, studentsPage.ddRaceSelectionUpdateStudent );

            Log.assertThat( studentsPage.getSelectedValues( UserConstants.GENDER_FIELD ).equalsIgnoreCase( "Not Specified" ), "Demographics values are updated for suspended students!",
                    "Demographics values are not updated for suspended students!Expected - Not Specified. Actual - " + studentsPage.getSelectedValues( UserConstants.GENDER_FIELD ) );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
