package com.savvas.sm.api.tests.smnew.students;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.grade;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.student.api.licenses.StudentDashboardAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.response.Response;

public class AssignmentSkillLevel extends EnvProperties {
    private static List<String> studentRumbaIds = new ArrayList<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();
    private List<String> courseIDs = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String teacherUsername;
    private String teacherAccessToken;
    private String readingAssignmentId;
    private String readingAssignmentUserId1;
    private String studentUserName1;
    private String readingCustomByUserId;
    private String readingCustomByAssignmentUserId;

    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private static HashMap<String, String> readingAssignmentDetails = new HashMap<>();
    HashMap<String, String> userDetails = null;

    private HashMap<String, String> groupDetails = new HashMap<>();
    AssignmentAPI assign = new AssignmentAPI();
    UserAPI userAPI = new UserAPI();

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        // Getting teacher details
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, password );
        Log.message( "Teacher access token: " + teacherAccessToken );

        String studentDetail = RBSDataSetup.getMyStudent( school, teacherUsername );
        // getting student details
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetail, "userId" ) );

        studentUserName1 = SMUtils.getKeyValueFromResponse( studentDetail, "userName" );

        // Getting group details
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" + System.nanoTime() );
        // Creating a group
        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        //Updating grade6 for student1
        String firstName = new Faker().name().firstName();
        String lastName = new Faker().name().lastName();
        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = generateRequestValues( new RBSUtils().getUser( studentRumbaIds.get( 0 ) ), studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ), grade.FIRST.toString() );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        // Updating student grade
        String studentResponce = userAPI.updateStudentProfile( smUrl, studentInfo ).get( Constants.STATUS_CODE );
        Log.message( studentResponce );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        // Assigning Reading assignment
        readingAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        readingAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        readingAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
        HashMap<String, String> readingAssignmentResponse = assign.assignMultipleAssignments( smUrl, readingAssignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details" + readingAssignmentResponse );

        // Getting assignment id
        JSONObject readingAssignmentDetailsJson = new JSONObject( readingAssignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray readingAssignmentList = readingAssignmentDetailsJson.getJSONArray( Constants.DATA );
        for ( Object assignment : readingAssignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }
        //        JSONObject readingAssignmentInfo = new JSONObject( readingAssignmentList.get( 0 ).toString() );

        readingAssignmentId = assignmentIds.get( AssignmentAPIConstants.READING_COURSE );
        readingAssignmentUserId1 = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), readingAssignmentId );

        readingCustomByUserId = assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );
        readingCustomByAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), readingCustomByUserId );
    }

    @Test ( dataProvider = "getDataforPostive", priority = 1, groups = { "smoke_test_case", "SMK-67546", "Reading", "assignmentSkill", "API" } )
    public void scoStart( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        String studentToken = new RBSUtils().getAccessToken( studentUserName1, password );
        StudentDashboardAPI studentAPI = new StudentDashboardAPI();
        AssignmentAPI assignmentSkill = new AssignmentAPI();
        String payload = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "assignmentSkillLevel.json" );
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, studentRumbaIds.get( 0 ) );
        headers.put( UserConstants.ORGID, orgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + studentToken );

        switch ( scenario ) {

            case "reading assignment":
                headers.put( "session-id", studentAPI.getSessionId( smUrl, studentRumbaIds.get( 0 ), orgId, studentUserName1, password, readingAssignmentUserId1 ) );
                Response getResponse = assignmentSkill.skillLevel( smUrl, headers );
                String body = getResponse.getBody().asString();
                Log.message( body );

                if ( body.contains( "\"ids\":[\"392\",\"337\"]" ) ) {
                    body = body.replace( "\"ids\":[\"392\",\"337\"]", "\"ids\":[\"337\",\"392\"]" );
                }
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode actualResponse = objectMapper.readTree( body );
                JsonNode expectedResponse = objectMapper.readTree( payload );

                try {
                    Assert.assertEquals( actualResponse, expectedResponse );
                    Log.pass( "Response body returned as expected!" );
                } catch ( AssertionError e ) {
                    Log.fail( "Issue in returning the response body " );
                }
                Log.assertThat( statusCode.equals( String.valueOf( getResponse.getStatusCode() ) ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );

                break;
        }
        switch ( scenario ) {

            case "reading custom by setting":
                headers.put( "session-id", studentAPI.getSessionId( smUrl, studentRumbaIds.get( 0 ), orgId, studentUserName1, password, readingCustomByAssignmentUserId ) );
                Response getResponse = assignmentSkill.skillLevel( smUrl, headers );
                String body = getResponse.getBody().asString();
                Log.message( body );

                if ( body.contains( "\"ids\":[\"392\",\"337\"]" ) ) {
                    body = body.replace( "\"ids\":[\"392\",\"337\"]", "\"ids\":[\"337\",\"392\"]" );
                }
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode actualResponse = objectMapper.readTree( body );
                JsonNode expectedResponse = objectMapper.readTree( payload );

                try {
                    Assert.assertEquals( actualResponse, expectedResponse );
                    Log.pass( "Response body returned as expected!" );
                } catch ( AssertionError e ) {
                    Log.fail( "Issue in returning the response body " );
                }
                Log.assertThat( statusCode.equals( String.valueOf( getResponse.getStatusCode() ) ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );

                break;
        }
    }

    @DataProvider ( name = "getDataforPostive" )
    public Object[][] getDataforPostive() {

        Object[][] data = { { "tcAssignmentSkillLevel001", "Verify the status code as 200 for valid data for reading assignment", "200", "reading assignment" },
                { "tcAssignmentSkillLevel002", "Verify the status code as 200 for valid data for reading custom by setting assignment", "200", "reading custom by setting" }, };
        return data;

    }

    /**
     * Generating request values
     * 
     * @param studentExistingData
     * @param newDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value, String grade ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }
}
