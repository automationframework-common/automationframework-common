package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class AssignmentSetting {
    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;
    private String username = null;
    private String password = null;
    String staticCourseName = null;
    String studentDetails;
    private static String teacherDetails;
    private String token = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private HashMap<String, String> groupDetails = new HashMap<>();
    List<String> studentRumbaIds = new ArrayList<>();
    private String organizationId = null;
    
    @BeforeClass (alwaysRun = true)
    public void initTest( ITestContext context ) throws Exception {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        //Student Details
        studentDetails = RBSDataSetup.getMyStudent( school, username );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        organizationId = RBSDataSetup.organizationIDs.get( school );

        GroupAPI groupAPI = new GroupAPI();
        String groupName = "GroupNo_" + System.nanoTime();

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );

        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

    }

    @Test ( description = "Verify the teacher is able to delete the custom courses", groups = { "SMK-45611", "Assignments", "PMG_EditTargets" }, priority = 1 )
    public void tcSMAssignmentSettings001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


        Log.testCaseInfo( "Verify the teacher is able to delete the custom courses" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            CoursesPage customCourses = new CoursesPage( driver );
            AssignmentsPage assignmentsPage = new AssignmentsPage( driver );
            List<String> assignmentNames = new ArrayList<>();
            //Navigate to assignment listing page
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Get all the assignments in the assignment tab
            assignmentNames = assignmentsPage.getAllAssignmentNames();

            assignmentNames.forEach( assignment -> {
                //Traverse to Assignment Tab
                tHomePage.topNavBar.navigateToAssignmentsPage();

                //Click on the Assignment
                customCourses.clickOnTheHoveredAssignment( assignment );

                //Delete the Assignment
                assignmentDetailsPage.assignmentLevelEllipsis();

                // Click on removeAssignmets
                assignmentDetailsPage.deleteAssignmenttab();

                // CLick on Delete button for the assignment
                assignmentDetailsPage.deleteAssignmentButton();
            } );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify for Default Math course", priority = 1, groups = { "SMK-54707", "Assignments", "AssignmentSetting" } )
    public void tcSMAssignmentSettings002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify for Default Math course<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-25198 - TC001_Verify the assignment settings are getting retained at the assignment level for Default Math assignment in the Courseware>Assignments page" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            coursePage.clickCourseName( Constants.MATH );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Get Assignments Page
            AssignmentsPage assignmentsPage = new AssignmentsPage( driver );

            assignmentsPage.clickAssignmentSubMenu();
            coursePage.clickOnTheHoveredAssignment( Constants.MATH );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHOW_ANSWER_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SCRATCH_PAD_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHOW_ANSWER_LABEL ), "Settings applied successfully for show answer", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SCRATCH_PAD_LABEL ), "Settings applied successfully for scratch pad", "Settings not saved successfully" );

            SMUtils.nap( 10 );

            // Clicking on Ellipsis at studentLevel and AssignmentSettings option
            assignmentDetailsPage.clickAssignmentSetting();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHARE_AT_DISTRICT_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.CALCULATOR_LABEL ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL ), "Settings applied successfully for exit course",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHARE_AT_DISTRICT_LABEL ), "Settings applied successfully for share at district level",
                    "Settings not saved successfully" );

            SMUtils.logDescriptionTC( "SMK-25208 - TC010_Verify the assignment settings changes done at the student level are getting retained for Default Math assignment in the Courseware>Assignments page" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify for Custom Math course", priority = 1, groups = { "SMK-54707", "Assignments", "AssignmentSetting" } )
    public void tcSMAssignmentSettings003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify for Custom Math course<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-25199 - TC002_Verify the assignment settings are getting retained at the assignment level for Custom Math in the Courseware>Assignments page" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.SETTINGS, Constants.MATH );

            // Get Assignments Page
            AssignmentsPage assignmentsPage = new AssignmentsPage( driver );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Click on the default Math course
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            //Click on the assignment
            coursePage.clickAssignBtn();

            //Assign the course to the student
            coursePage.addCourseToStudents();

            assignmentsPage.clickAssignmentSubMenu();
            coursePage.clickOnTheHoveredAssignment( newlyCreatedCourse );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHOW_ANSWER_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SCRATCH_PAD_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHOW_ANSWER_LABEL ), "Settings applied successfully for show answer", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SCRATCH_PAD_LABEL ), "Settings applied successfully for scratch pad", "Settings not saved successfully" );

            SMUtils.nap( 10 );

            // Clicking on Ellipsis at studentLevel and AssignmentSettings option
            assignmentDetailsPage.clickAssignmentSetting();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHARE_AT_DISTRICT_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.CALCULATOR_LABEL ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL ), "Settings applied successfully for exit course",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHARE_AT_DISTRICT_LABEL ), "Settings applied successfully for share at district level",
                    "Settings not saved successfully" );

            SMUtils.logDescriptionTC( "SMK-25209 - TC011_Verify the assignment settings changes done at the student level are getting retained for Custom Math in the Courseware>Assignments page" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify for Focus Math course", priority = 1, groups = { "SMK-54707", "Assignments", "AssignmentSetting" } )
    public void tcSMAssignmentSettings004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify for Focus Math course<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-25200 - TC003_Verify the assignment settings are getting retained at the assignment level for Focus Math in the Courseware>Assignments page" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.SM_FOCUS_MATH_GRADE1 );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Click on the default Math course
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            //Click on the assignment
            coursePage.clickAssignBtn();

            //Assign the course to the student
            coursePage.addCourseToStudents();

            // Get Assignments Page
            AssignmentsPage assignmentsPage = new AssignmentsPage( driver );

            assignmentsPage.clickAssignmentSubMenu();
            coursePage.clickOnTheHoveredAssignment( newlyCreatedCourse );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHOW_ANSWER_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SCRATCH_PAD_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHOW_ANSWER_LABEL ), "Settings applied successfully for show answer", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SCRATCH_PAD_LABEL ), "Settings applied successfully for scratch pad", "Settings not saved successfully" );

            SMUtils.nap( 10 );

            // Clicking on Ellipsis at studentLevel and AssignmentSettings option
            assignmentDetailsPage.clickAssignmentSetting();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHARE_AT_DISTRICT_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.CALCULATOR_LABEL ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL ), "Settings applied successfully for exit course",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.ON_CAPS, Constants.SHARE_AT_DISTRICT_LABEL ), "Settings applied successfully for share at district level",
                    "Settings not saved successfully" );

            SMUtils.logDescriptionTC( "SMK-25210 - TC012_Verify the assignment settings changes done at the student level are getting retained for Custom Focus Math in the Courseware>Assignments page" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify for Default Reading course", priority = 1, groups = { "SMK-54707", "Assignments", "AssignmentSetting" } )
    public void tcSMAssignmentSettings005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify for Default Reading course<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-25201 - TC004_Verify the assignment settings are getting retained at the assignment level for Default Reading in the Courseware>Assignments page" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            coursePage.clickCourseName( Constants.READING );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Get Assignments Page
            AssignmentsPage assignmentsPage = new AssignmentsPage( driver );

            assignmentsPage.clickAssignmentSubMenu();
            coursePage.clickOnTheHoveredAssignment( Constants.READING );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION ), "Settings applied successfully for displya Lo information",
                    "Settings not saved successfully" );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            SMUtils.nap( 10 );

            // Clicking on Ellipsis at studentLevel and AssignmentSettings option
            assignmentDetailsPage.clickAssignmentSetting();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.DISPLAY_LO_INFORMATION ), "Settings applied successfully for display lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.HELP_ICON_ACIVE ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            SMUtils.logDescriptionTC( "SMK-25211 - TC013_Verify the assignment settings changes done at the student level are getting retained for Default Reading in the Courseware>Assignments page" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify for Custom Reading course", priority = 1, groups = { "SMK-54707", "Assignments", "AssignmentSetting" } )
    public void tcSMAssignmentSettings006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify for Custom Reading course<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-25202 - TC005_Verify the assignment settings are getting retained at the assignment level for Custom Reading in the Courseware>Assignments page" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName() + System.nanoTime();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.SETTINGS, Constants.READING );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Click on the default Math course
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            //Click on the assignment
            coursePage.clickAssignBtn();

            //Assign the course to the student
            coursePage.addCourseToStudents();

            // Get Assignments Page
            AssignmentsPage assignmentsPage = new AssignmentsPage( driver );

            assignmentsPage.clickAssignmentSubMenu();
            coursePage.clickOnTheHoveredAssignment( newlyCreatedCourse );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.DISPLAY_LO_INFORMATION ), "Settings applied successfully for displya Lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.HELP_ICON_ACIVE ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            SMUtils.nap( 10 );

            // Clicking on Ellipsis at studentLevel and AssignmentSettings option
            assignmentDetailsPage.clickAssignmentSetting();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION ), "Settings applied successfully for display lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            SMUtils.logDescriptionTC( "SMK-25212 - TC014_Verify the assignment settings changes done at the student level are getting retained for Custom Reading in the Courseware>Assignments page" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify for Focus Reading course", priority = 1, groups = { "SMK-54707", "Assignments", "AssignmentSetting" } )
    public void tcSMAssignmentSettings007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify for Focus Reading course<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-25203 - TC006_Verify the assignment settings are getting retained at the assignment level for Focus Reading in the Courseware>Assignments page" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.SM_FOCUS_READING_GRADE1 );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Click on the default Math course
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            //Click on the assignment
            coursePage.clickAssignBtn();

            //Assign the course to the student
            coursePage.addCourseToStudents();

            // Get Assignments Page
            AssignmentsPage assignmentsPage = new AssignmentsPage( driver );

            assignmentsPage.clickAssignmentSubMenu();
            coursePage.clickOnTheHoveredAssignment( newlyCreatedCourse );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            assignmentDetailsPage.assignmentLevelEllipsis();

            assignmentDetailsPage.allAssignmenttSettingTab();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.DISPLAY_LO_INFORMATION ), "Settings applied successfully for displya Lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.HELP_ICON_ACIVE ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            SMUtils.nap( 10 );

            // Clicking on Ellipsis at studentLevel and AssignmentSettings option
            assignmentDetailsPage.clickAssignmentSetting();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );
            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX_MINUTES ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheDropdownValue( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO_MINUTES ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION ), "Settings applied successfully for display lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            SMUtils.logDescriptionTC( "SMK-25213 - TC015_Verify the assignment settings changes done at the student level are getting retained for Custom Focus Reading in the Courseware>Assignments page" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
