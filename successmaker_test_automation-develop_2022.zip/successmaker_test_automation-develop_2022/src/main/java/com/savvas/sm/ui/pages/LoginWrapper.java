package com.savvas.sm.ui.pages;

import org.openqa.selenium.WebDriver;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;

/**
 * Decides the user(admin, teacher and student) logs in to SM app
 *
 * @author magesh.nagamani
 *
 */
public class LoginWrapper {

    /**
     * Login to SM app with any type of teacher user
     *
     * @param driver
     * @param appUrl
     * @param userType
     * @param districtName
     * @param username
     * @param password
     * @return TeacherHomePage
     */
    public static TeacherHomePage loginToSuccessMakerAsTeacher( WebDriver driver, String appUrl, String userType, String districtName, String username, String password ) {

        TeacherHomePage teacherHomePage = null;
        EBPlusAndAutoSignInPage eBPlusAndAutoSignInPage = null;
        PowerSchoolSsoPage psloginPage = null;
        PowerSchoolTeacherLoginPage psTeacherLoginPage = null;

        // open the SuccessMaker launcher page in browser
        LauncherPage launcherPage = new LauncherPage( driver, appUrl ).get();
        eBPlusAndAutoSignInPage = launcherPage.navigateToEBPlusAndAutoLoginPage();

        // check the user type and decide on login methods
        if ( LoginConstants.UserType.BASIC.equalsIgnoreCase( userType ) ) {

            teacherHomePage = eBPlusAndAutoSignInPage.signInToSuccessMaker( username, password );
        } else if ( LoginConstants.UserType.AUTO.equalsIgnoreCase( userType ) ) {

            if ( districtName == null )
                teacherHomePage = eBPlusAndAutoSignInPage.signInToSuccessMaker( username, password );
            else if ( districtName != null && !( username.contains( "@" ) ) ) {
                Log.message( "Sign in via choosing District first and entering user details" );
                EBPlusAndAutoDistrictPage eBPlusAndAutoDistrictPage = eBPlusAndAutoSignInPage.navigateToEBPlusAndAutoLink();

                // choose district
                eBPlusAndAutoSignInPage = eBPlusAndAutoDistrictPage.chooseDistrict( districtName );
                teacherHomePage = eBPlusAndAutoSignInPage.signInToSuccessMaker( username, password );
            } else
                Log.fail( "Either district name or username with appending district should be given. Given District name is- " + districtName + " and Username is- " + username );

        } else if ( LoginConstants.UserType.PLUS.equalsIgnoreCase( userType ) ) {
            if ( districtName == null && ( username.contains( "@" ) ) )
                teacherHomePage = eBPlusAndAutoSignInPage.signInToSuccessMaker( username, password );
            else if ( districtName != null && !( username.contains( "@" ) ) ) {
                Log.message( "Sign in via choosing District first and entering user details" );
                EBPlusAndAutoDistrictPage eBPlusAndAutoDistrictPage = eBPlusAndAutoSignInPage.navigateToEBPlusAndAutoLink();

                // choose district
                psloginPage = eBPlusAndAutoDistrictPage.chooseDistrictName( districtName );
                psTeacherLoginPage = psloginPage.navigateToPowerSchoolTeacherLoginPage( false );
                teacherHomePage = psTeacherLoginPage.signInToSuccessMakerTeacher( username, password );
            } else
                Log.fail( "Either district name or username with appending district should be given. Given District name is- " + districtName + " and Username is- " + username );
        }

        return teacherHomePage;

    }

    /**
     * Login to SM app with any type of student user
     *
     * @param driver
     * @param appUrl
     * @param userType
     * @param districtName
     * @param username
     * @param password
     * @return studentHomePage
     */

    public static StudentDashboardPage loginToSuccessMakerAsStudent( WebDriver driver, String appUrl, String userType, String districtName, String username, String password ) {
        StudentDashboardPage studentHomePage = null;
        EBPlusAndAutoSignInPage eBPlusAndAutoSignInPage = null;
        PowerSchoolSsoPage psloginPage = null;
        PowerSchoolStudentLoginPage psStudentLoginPage = null;

        // open the SuccessMaker launcher page in browser
        LauncherPage launcherPage = new LauncherPage( driver, appUrl ).get();
        eBPlusAndAutoSignInPage = launcherPage.navigateToEBPlusAndAutoLoginPage();

        // check the user type and decide on login methods
        if ( LoginConstants.UserType.BASIC.equalsIgnoreCase( userType ) ) {
            studentHomePage = eBPlusAndAutoSignInPage.signInToSuccessMakerAsStudent( username, password );
        } else if ( LoginConstants.UserType.AUTO.equalsIgnoreCase( userType ) ) {

            if ( districtName == null && ( username.contains( "@" ) ) ) {
                studentHomePage = eBPlusAndAutoSignInPage.signInToSuccessMakerAsStudent( username, password );
            } else if ( districtName != null && !( username.contains( "@" ) ) ) {
                Log.message( "Sign in via choosing District first and entering user details" );
                EBPlusAndAutoDistrictPage eBPlusAndAutoDistrictPage = eBPlusAndAutoSignInPage.navigateToEBPlusAndAutoLink();

                // choose district
                eBPlusAndAutoSignInPage = eBPlusAndAutoDistrictPage.chooseDistrict( districtName );
                studentHomePage = eBPlusAndAutoSignInPage.signInToSuccessMakerAsStudent( username, password );
            } else
                Log.fail( "Either district name or username with appending district should be given. Given District name is- " + districtName + " and Username is- " + username );

        } else if ( LoginConstants.UserType.PLUS.equalsIgnoreCase( userType ) ) {
            if ( districtName == null && ( username.contains( "@" ) ) )
                studentHomePage = eBPlusAndAutoSignInPage.signInToSuccessMakerAsStudent( username, password );
            else if ( districtName != null && !( username.contains( "@" ) ) ) {
                Log.message( "Sign in via choosing District first and entering user details" );
                EBPlusAndAutoDistrictPage eBPlusAndAutoDistrictPage = eBPlusAndAutoSignInPage.navigateToEBPlusAndAutoLink();

                // choose district
                psloginPage = eBPlusAndAutoDistrictPage.chooseDistrictName( districtName );
                psStudentLoginPage = psloginPage.navigateToPowerSchoolStudentLoginPage( false );
                studentHomePage = psStudentLoginPage.signInToSuccessMakerAsStudent( username, password );
            } else
                Log.fail( "Either district name or username with appending district should be given. Given District name is- " + districtName + " and Username is- " + username );
        }

        return studentHomePage;
    }

    /**
     * Log in to the mastery mfe- Teacher/Admin
     *
     * @param driver
     * @param appUrl
     * @param username
     * @param password
     */
    public static MasteryMfePage loginToMasteryMfe( WebDriver driver, String appUrl, String username, String password ) {

        // loads the mfe url
        driver.get( appUrl );

        EBPlusAndAutoSignInPage eBPlusAndAutoSignInPage = new EBPlusAndAutoSignInPage( driver ).get();

        eBPlusAndAutoSignInPage.signInToMasteryMfe( username, password );

        return new MasteryMfePage( driver ).get();
    }

    /**
     * Login to SM app with any type of teacher user for unauthorized entry
     *
     * @param driver
     * @param appUrl
     * @param userType
     * @param districtName
     * @param username
     * @param password
     * @return unauthorizedPageForTeacher
     */

    public static UnauthorizedModal loginToSuccessMakerAsUnauthorized( WebDriver driver, String appUrl, String userType, String districtName, String username, String password ) {

        UnauthorizedModal unauthorizedPagePopupWindow = null;
        EBPlusAndAutoSignInPage eBPlusAndAutoSignInPage = null;

        // open the SuccessMaker launcher page in browser
        LauncherPage launcherPage = new LauncherPage( driver, appUrl ).get();
        eBPlusAndAutoSignInPage = launcherPage.navigateToEBPlusAndAutoLoginPage();

        // check the user type and decide on login methods
        if ( LoginConstants.UserType.BASIC.equalsIgnoreCase( userType ) ) {

            unauthorizedPagePopupWindow = eBPlusAndAutoSignInPage.signInToSuccessMakerUnauthorized( username, password );
        } else if ( LoginConstants.UserType.AUTO.equalsIgnoreCase( userType ) ) {

            if ( districtName == null )
                unauthorizedPagePopupWindow = eBPlusAndAutoSignInPage.signInToSuccessMakerUnauthorized( username, password );
            else if ( districtName != null && !( username.contains( "@" ) ) ) {
                Log.message( "Sign in via choosing District first and entering user details" );
                EBPlusAndAutoDistrictPage eBPlusAndAutoDistrictPage = eBPlusAndAutoSignInPage.navigateToEBPlusAndAutoLink();

                // choose district
                eBPlusAndAutoSignInPage = eBPlusAndAutoDistrictPage.chooseDistrict( districtName );
                unauthorizedPagePopupWindow = eBPlusAndAutoSignInPage.signInToSuccessMakerUnauthorized( username, password );
            } else
                Log.fail( "Either district name or username with appending district should be given. Given District name is- " + districtName + " and Username is- " + username );

        } else if ( LoginConstants.UserType.PLUS.equalsIgnoreCase( userType ) ) {
            if ( districtName == null && ( username.contains( "@" ) ) )
                unauthorizedPagePopupWindow = eBPlusAndAutoSignInPage.signInToSuccessMakerUnauthorized( username, password );
            else if ( districtName != null && !( username.contains( "@" ) ) ) {
                Log.message( "Sign in via choosing District first and entering user details" );
            } else
                Log.fail( "Either district name or username with appending district should be given. Given District name is- " + districtName + " and Username is- " + username );
        }

        return unauthorizedPagePopupWindow;

    }

}
