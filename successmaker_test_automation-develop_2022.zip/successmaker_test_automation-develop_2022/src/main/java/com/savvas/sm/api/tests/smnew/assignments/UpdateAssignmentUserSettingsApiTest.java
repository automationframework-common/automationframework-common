package com.savvas.sm.api.tests.smnew.assignments;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.FileNameConstatnts;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.ethnicity;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.gender;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.grade;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasDisability;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEconomicDisadvantage;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEnglishProficiency;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.isMigrant;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.specialServices;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

/**
 * This class used to test the API of PUT method for Update Assignment User
 * Settings
 * 
 * @author dharani.chandrasekar
 *
 */

public class UpdateAssignmentUserSettingsApiTest extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    HashMap<String, String> SchoolCreateStudentResponse = new HashMap<>();
    HashMap<String, String> SchoolAssignmentResponse = new HashMap<>();
    HashMap<String, String> ReadingAssignmentResponse = new HashMap<>();
    String studentUserId;
    String studentUserName;
    String assignmentUserId;
    String readingAssignmentUserId;
    List<String> mathSchoolStudentRumbaIds = new ArrayList<>();
    private String teacherUsername;
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();

        //Students creation using SM students creation api
        HashMap<String, String> mathSchoolStudentDetails = new HashMap<>();
        mathSchoolStudentDetails = generateRequestValues( mathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
        mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
        mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
        mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        studentUserId = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(school , teacherUsername), Constants.USERID_HEADER);			

        HashMap<String, String> mathSchoolGroupDetails = new HashMap<>();
        HashMap<String, String> mathSchoolAssignmentDetails = new HashMap<>();
        HashMap<String, String> readingSchoolAssignmentDetails = new HashMap<>();

        //Group Creation
        mathSchoolStudentRumbaIds.add( studentUserId );
        mathSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( new GroupAPI().createGroup( smUrl, mathSchoolGroupDetails, mathSchoolStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }

        //Math Assignment Creation
        mathSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        mathSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        mathSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
        mathSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        SchoolAssignmentResponse = assignAssignment( smUrl, mathSchoolAssignmentDetails, mathSchoolStudentRumbaIds, "users" );

        //Getting assignmentUserID for Math assignments
        assignmentUserId = SqlHelperAssignment.getAssignmentUserId( SMUtils.getKeyValueFromResponse( SchoolAssignmentResponse.get( Constants.REPORT_BODY ), "data,assignmentId" ) );
        Log.message( assignmentUserId + "AssignmentUserId" );

        //Reading Assignment Creation
        readingSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        readingSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        readingSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_READING );
        readingSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        ReadingAssignmentResponse = assignAssignment( smUrl, readingSchoolAssignmentDetails, mathSchoolStudentRumbaIds, "users" );

        //Getting assignmentUserID for Reading assignments
        readingAssignmentUserId = SqlHelperAssignment.getAssignmentUserId( SMUtils.getKeyValueFromResponse( ReadingAssignmentResponse.get( Constants.REPORT_BODY ), "data,assignmentId" ) );
        Log.message( assignmentUserId + "AssignmentUserId" );

    }

    @Test ( priority = 1, dataProvider = "updateAssignmentUserSettings_PositiveFlow", groups = { "SMK-51900", "smoke_test_case","Assignments", "AssignmentUserSettings", "P1", "API" } )
    public void tc01_UpdateAssignmentUserSettings( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> putCallResponse = new HashMap<>();

        switch ( scenario ) {
            case "TC01_SESSION_LENGTH":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                HashMap<String, String> assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SESSION_LENGTH", "10" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC02_IDLE_TIME":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "IDLE_TIME", "2" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC03_PROGRESS_REPORT_LIMIT":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "PROGRESS_REPORT_LIMIT", "1" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC04_INITIAL_PLACEMENT":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "INITIAL_PLACEMENT", "FALSE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC05_CALCULATOR":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "CALCULATOR", "TRUE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC06_TRANSLATE":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "TRANSLATE", "TRUE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC07_AVAILABLE_LANGUAGES":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "TRANSLATE", "ENGLISH" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC08_DISPLAY_LO_INFORMATION":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "DISPLAY_LO_INFORMATION", "FALSE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC09_SCRATCHPAD":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SCRATCHPAD", "FALSE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC10_SHOW_ANSWER":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SHOW_ANSWER", "FALSE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC011_SHOW_EXIT_BUTTON":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SHOW_EXIT_BUTTON", "FALSE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC12_SHARED_COURSES":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SHARED_COURSES", "TRUE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC13_SPEED_GAMES":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SPEED_GAMES", "FALSE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC14_SPEED_GAMES_TIME_PER_QUESTIOND":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SPEED_GAMES_TIME_PER_QUESTION", "1" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC15_SPEED_GAMES_TOTAL_TIME":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SPEED_GAMES_TOTAL_TIME", "2" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC16_MANUALLY_SET_COURSE_LEVEL":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "MANUALLY_SET_COURSE_LEVEL", "TRUE" );
                assignmentSettings.put( "MANUALLY_SET_COURSE_LEVEL_SLIDER", "3.5" );
                assignmentSettings.put( "LOW", "3.5" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC17_READING_SPAINSH_GLOSSARY":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTREADINGASSIGNMENTSETTINGS;
                assignmentSettings.put( "SPAINSH_GLOSSARY", "TRUE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.READING_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC18_READING_GRAMMER_STRAND":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTREADINGASSIGNMENTSETTINGS;
                assignmentSettings.put( "GRAMMER_STRAND", "TRUE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.READING_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC19_READING_FLUENCY":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTREADINGASSIGNMENTSETTINGS;
                assignmentSettings.put( "FLUENCY", "TRUE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.READING_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC20_READING_HELP_ICON_ACTIVE":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTREADINGASSIGNMENTSETTINGS;
                assignmentSettings.put( "HELP_ICON_ACTIVE", "FALSE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.READING_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC21_READING_READ_TO_ME":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTREADINGASSIGNMENTSETTINGS;
                assignmentSettings.put( "READ_TO_ME", "TRUE" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.READING_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }

        // Verifying Status Code
        Log.assertThat( putCallResponse.get( "statusCode" ).equals( statusCode ), "Status code is matched", "Status code is mismatched" );

        // Verifying schema in Response body
        Log.assertThat( smAPIprocessor.isSchemaValid( FileNameConstatnts.UPDATE_ASSIGNMENT_USER_SETTINGS_SCHEMA_FILE, statusCode, putCallResponse.get( AssignmentAPIConstants.BODY_FIELD ) ), "The schema is valid and mathcing",
                "The schema is not valid and not mathcing for the Status code :" + statusCode );

        Log.testCaseResult();
        Log.endTestCase();

    }

    /**
     * Data provider to give the postive data
     * 
     * @return
     */
    @DataProvider ( name = "updateAssignmentUserSettings_PositiveFlow" )
    public Object[][] updateAssignmentUserSettings_PositiveFlow() {
        Object[][] inputData = { { "Verify the user able to update the user settings for SESSION_LENGTH", "TC01_SESSION_LENGTH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for IDLE_TIME", "TC02_IDLE_TIME", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for PROGRESS_REPORT_LIMIT", "TC03_PROGRESS_REPORT_LIMIT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for INITIAL_PLACEMENT", "TC04_INITIAL_PLACEMENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for CALCULATOR", "TC05_CALCULATOR", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for TRANSLATE", "TC06_TRANSLATE", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for AVAILABLE_LANGUAGES", "TC07_AVAILABLE_LANGUAGES", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for CommonAPIConstants", "TC08_DISPLAY_LO_INFORMATION", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for SCRATCHPAD", "TC09_SCRATCHPAD", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for SHOW_ANSWER", "TC10_SHOW_ANSWER", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for SHOW_EXIT_BUTTON", "TC011_SHOW_EXIT_BUTTON", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for SHARED_COURSES", "TC12_SHARED_COURSES", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for SPEED_GAMES", "TC13_SPEED_GAMES", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for SPEED_GAMES_TIME_PER_QUESTIOND", "TC14_SPEED_GAMES_TIME_PER_QUESTIOND", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for SPEED_GAMES_TOTAL_TIME", "TC15_SPEED_GAMES_TOTAL_TIME", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for MANUALLY_SET_COURSE_LEVEL", "TC16_MANUALLY_SET_COURSE_LEVEL", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for READING_SPAINSH_GLOSSARY", "TC17_READING_SPAINSH_GLOSSARY", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for READING_GRAMMER_STRAND", "TC18_READING_GRAMMER_STRAND", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for READING_FLUENCY", "TC19_READING_FLUENCY", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for READING_HELP_ICON_ACTIVE", "TC20_READING_HELP_ICON_ACTIVE", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the user able to update the user settings for READING_READ_TO_ME", "TC21_READING_READ_TO_ME", CommonAPIConstants.STATUS_CODE_OK }

        };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "updateAssignmentUserSettings_NegativeFlow", groups = { "SMK-51900", "Assignments", "AssignmentUserSettings", "P2", "API" } )
    public void tc02_UpdateAssignmentUserSettings( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> putCallResponse = new HashMap<>();

        switch ( scenario ) {
            case "TC001_INVALID_ORG_ID_IN_HEADER":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) + 1 );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                HashMap<String, String> assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SESSION_LENGTH", "10" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC002_INVALID_STAFF_ID_IN_HEADER":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) + 1 );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SESSION_LENGTH", "10" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC003_INVALID_AUTHORIZATION":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) + 1 );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SESSION_LENGTH", "10" );
                putCallResponse = updateAssignmentUserSettings( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds, AssignmentAPIConstants.MATH_COURSE );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            case "TC004_PASSING_WITH_EMPTY_REQUEST_BODY":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentSettings = AssignmentAPIConstants.DEFAULTMATHSSIGNMENTSETTINGS;
                assignmentSettings.put( "SESSION_LENGTH", "10" );
                putCallResponse = updateAssignmentUserSettingsWithoutBody( smUrl, assignmentDetails, assignmentSettings, mathSchoolStudentRumbaIds );
                Log.message( putCallResponse.get( "statusCode" ) );
                Log.message( putCallResponse.get( "body" ) );
                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }

        // Verifying Status Code
        Log.assertThat( putCallResponse.get( "statusCode" ).equals( statusCode ), "Status code is matched", "Status code is mismatched" );

        Log.testCaseResult();
        Log.endTestCase();

    }

    /**
     * Data provider to give the Negative data
     * 
     * @return
     */
    @DataProvider ( name = "updateAssignmentUserSettings_NegativeFlow" )
    public Object[][] updateAssignmentUserSettings_NegativeFlow() {
        Object[][] inputData = { { "Verify the user able to update the user settings when passing with INVALID_ORG_ID_IN_HEADER", "TC001_INVALID_ORG_ID_IN_HEADER", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the user able to update the user settings when passing with INVALID_STAFF_ID_IN_HEADER", "TC002_INVALID_STAFF_ID_IN_HEADER", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the user able to update the user settings when passing with INVALID_AUTHORIZATION", "TC003_INVALID_AUTHORIZATION", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the user able to update the user settings when passing with EMPTY_REQUEST_BODY", "TC004_PASSING_WITH_EMPTY_REQUEST_BODY", CommonAPIConstants.STATUS_CODE_BAD_REQUEST }, };
        return inputData;
    }

    /**
     * This methods will generate the details whatever given in Key and value
     * 
     * @param studentDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> generateRequestValues( HashMap<String, String> studentDetails, String key, String value ) {
        HashMap<String, String> generatedStudentDetails = studentDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, new Faker().name().firstName() );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, new Faker().name().firstName().substring( 1 ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, new Faker().name().lastName() );
        generatedStudentDetails.put( CreateStudentAPIConstants.GRADE, grade.FIRST.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, new Faker().name().username() );
        generatedStudentDetails.put( CreateStudentAPIConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( CreateStudentAPIConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( GetUserDetailsUsingUserServiceAPIConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        return generatedStudentDetails;
    }

    /**
     * This methods will update the details whatever given in Key and value
     * 
     * @param studentDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> updateRequestBodyValues( HashMap<String, String> studentDetails, String key, String value ) {
        HashMap<String, String> generatedStudentDetails = studentDetails;
        if ( generatedStudentDetails.containsKey( key ) ) {
            generatedStudentDetails.put( key, value );
        } else {
            generatedStudentDetails.put( key, value );
        }
        return generatedStudentDetails;
    }

}