package com.savvas.sm.teacher.ui.tests.SmokeSuite;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class CoursesTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherID;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify Course Listing", priority = 1 )
    public void tcSMBVT014( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

        Log.testCaseInfo( "tcSMBVT014: Verify Course Listing <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            // Verify courses are listing in Course Listing Page
            Log.assertThat( coursePage.getCourseNameList().size() > 0, "The courses are listing successfully!", "The courses are not listing" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Course Details Page", priority = 1 )
    public void tcSMBVT015( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

        Log.testCaseInfo( "tcSMBVT015: Verify Course Details Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickMathCourse();

            // Verify the left side panel shows strands
            coursePage.verifyLeftStrandsDisplayedForMathCourses();

            // Verify the mid panel shows hierarchy
            coursePage.verifyMiddleHierarchyDisplayedForMathCourses();

            // Verify the right panel shows settings
            coursePage.verifySettingsDisplayedForMathCourses();

            // Verify the Skills drop are showing values
            coursePage.clickSkillsDropDown();
            Log.assertThat( coursePage.getSkillsDroppdownvalues().size() > 0, "Skills DropDown Values are Listed", "Skills DropDown Values are not Listed" );

            // Verify the Grades drop are showing values
            coursePage.clickGradeDropDown();
            Log.assertThat( coursePage.getGradeDroppdownvalues().size() > 0, "Grades DropDown Values are Listed", "Grades DropDown Values are not Listed" );

            // Change Grade and verify course details changing
            String defaultFirstStrandValueBefore = coursePage.getDefaultFirstStrandValueBeforeClicking();
            coursePage.selectGradeDropDownvalue();
            String firstStrandValueAfter = coursePage.getFirstStrandValueAfterClicking();
            Log.assertThat( !defaultFirstStrandValueBefore.equals( firstStrandValueAfter ), defaultFirstStrandValueBefore + " values is changed to " + firstStrandValueAfter + " after changing Grades", "The values are not changed after Grades" );

            // Change Standard and verify course details changing
            String defaultFirstStrandValueBeforeClicking = coursePage.getDefaultFirstStrandValueBeforeClicking();
            coursePage.selectSkillsDropDownvalue();
            String firstStrandValueAfterClicking = coursePage.getFirstStrandValueAfterClicking();
            Log.assertThat( !defaultFirstStrandValueBeforeClicking.equals( firstStrandValueAfterClicking ), defaultFirstStrandValueBeforeClicking + " values is changed to" + firstStrandValueAfterClicking + " after changing standard",
                    "The values are not changed after standard" );

            // Verify Edit/Remove button not present for Math Course
            coursePage.verifyEditAndRemoveBtnNotPresent();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify creating a custom by settings course", priority = 1 )
    public void tcSMBVT016( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

        Log.testCaseInfo( "tcSMBVT016: Verify creating a custom by settings course <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickMathCourse();
            coursePage.clickMakeCopyBtn();
            String courseName = coursePage.generateRandomCourseName();

            coursePage.enterCourseName( courseName );
            coursePage.clickSettingsRadioBtn();
            coursePage.clickNextBtn();

            // Verify that Initial placement is ON by default.
            coursePage.verifyInitialPlacementIsON();

            // Turn OFF Initial placement
            coursePage.turnOffInitialPlacement();

            // Verify Manually set course level is OFF by default
            coursePage.verifyManuallySetCourselevelIsOFF();
            coursePage.turnOnManuallySetCourseLevel();

            // Set course level to 1.75
            coursePage.moveSliderTo( Constants.COURSELEVEL_1_75 );

            // Verifying other options are shown with default values
            coursePage.verifySpeedGamesIsON();

            // Change the other options from its default value
            coursePage.turnOffSpeedGames();
            coursePage.clickCreateBtn();

            context.setAttribute( "CourseName", courseName );

            SMUtils.nap( 10 );

            CourseListingPage courseListingPage = new CourseListingPage( driver );
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            // Verify that the new course showed in course listing page
            Log.assertThat( coursePage.verifyCoursecreated( courseName ), "Course Created Successfully", "Course Not Created" );

            // SignOut from SM

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify creating a custom by skills course", priority = 1 )
    public void tcSMBVT017( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	Log.testCaseInfo( "tcSMBVT017: Verify creating a custom by skills course <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            //coursePage.copyOfDefaultReadingCourse( Constants.CUSTOM_BY_SKILLS_COURSE, Constants.SKILLS );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify creating a custom by standards course", priority = 1 )
    public void tcSMBVT018( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT018: Verify creating a custom by standards course <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String staticCourseName = customCourses.generateRandomCourseName();

            coursePage.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Edit Course", priority = 1 )
    public void tcSMBVT019( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	Log.testCaseInfo( "tcSMBVT019: Verify Edit Course <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            String courseName = (String) context.getAttribute( "CourseName" );
            coursePage.clickCourseName( courseName );
            coursePage.clickEditBtn();
            coursePage.verifyInitialPlacementIsOff();
            coursePage.verifyManuallySetCourselevelIsON();
            Log.assertThat( coursePage.getCourseLevel().equals( Constants.COURSELEVEL_1_75 ), "Course Level is same as excepted", "Course Level is not same as excepted" );
            coursePage.verifySpeedGamesIsOFF();
            Log.message( "Verified all the setting options are same as created" );

            // Change IP from OFF to ON
            coursePage.turnONInitialPlacement();
            coursePage.clickSaveBtn();
            Log.assertThat( coursePage.verifyInitialPlacementStatus().equals( Constants.ON ), "Initial placement status in ON as excepted", "Initial placement status in OFF. Excepted status is ON" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Remove Course", priority = 1 )
    public void tcSMBVT020( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMBVT020: Verify Remove Course <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( (String) context.getAttribute( "CourseName" ) );
            coursePage.removeCourse();

            // To Verify that course is removed from course listing page
            coursePage.verifyCourseRemovedSuccessfully( (String) context.getAttribute( "CourseName" ) );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Course Assignment", priority = 1 )
    public void tcSMBVT021( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMBVT021: Verify Course Assignment <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
    		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( Constants.CUSTOM_BY_SETTINGS_COURSE );
            coursePage.clickAssignBtn();

            // Adding Custom courses to Groups
            List<String> allStudentNameFromAssignPopUp = coursePage.getAllStudentNameFromAssignPopUp();

            coursePage.addCourseToGroups();

            // Adding Custom courses to Students
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Verify all students (in group and outside group) got assignments
            coursePage.clickAssignmentSubMenu();
            coursePage.clickViewAssignment( Constants.CUSTOM_BY_SETTINGS_COURSE );
            List<String> studentListfromAssignementDetailsTable = coursePage.getStudentListfromAssignementDetailsTable();

            int sizeOfList = Math.min( allStudentNameFromAssignPopUp.size(), studentListfromAssignementDetailsTable.size() );
            for ( int i = 0; i < sizeOfList; i++ ) {
                allStudentNameFromAssignPopUp.get( i ).startsWith( studentListfromAssignementDetailsTable.get( i ) );
            }
            Log.message( "Course is allocated to all Students" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}