package com.savvas.sm.api.tests.smnew.users;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

public class GetUserDetailsUsingUserServiceAPITest extends UserAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    String sessionCookie;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String reqBodyTemplate = null;

    // Teacher variable used for this class
    private String orgUsed = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String org2Used = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String teacherUsed;
    private String studentUsed;
    private String teacher2Used;
    private String otherSchoolTeacher;
    String studentName1;
    String studentIds1;
    String orgId;
    String teacherId;
    String username;
    String org1TeacherId2;
    String otherSchoolTeacherId;
    String otherSchoolTeacherUsername;
    String org1TeacherUsername2;
    private ArrayList<String> studentRumbaIds;

    // other school teacher details
    String org2Id;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {

        String envUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        // Teacher used Details
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        teacherUsed = RBSDataSetup.getMyTeacher( orgUsed );
        teacherId = SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERID );
        username = SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME );

        // Teacher 2 Details
        teacher2Used = RBSDataSetup.getMyTeacher( orgUsed );
        org1TeacherId2 = SMUtils.getKeyValueFromResponse( teacher2Used, RBSDataSetupConstants.USERID );
        org1TeacherUsername2 = SMUtils.getKeyValueFromResponse( teacher2Used, RBSDataSetupConstants.USERNAME );

        // Other School Details
        org2Id = RBSDataSetup.organizationIDs.get( org2Used );
        otherSchoolTeacher = RBSDataSetup.getMyTeacher( org2Used );
        otherSchoolTeacherId = SMUtils.getKeyValueFromResponse( otherSchoolTeacher, RBSDataSetupConstants.USERID );
        otherSchoolTeacherUsername = SMUtils.getKeyValueFromResponse( teacher2Used, RBSDataSetupConstants.USERNAME );

        studentRumbaIds = new ArrayList<String>();
        // Student Creation 
        studentUsed = RBSDataSetup.getMyStudent( orgUsed, username );
        studentIds1 = SMUtils.getKeyValueFromResponse( studentUsed, RBSDataSetupConstants.USERID );
        studentName1 = SMUtils.getKeyValueFromResponse( studentUsed, RBSDataSetupConstants.USERNAME );

        studentRumbaIds.add( studentIds1 );

    }

    @Test ( priority = 1, groups = { "smoke_test_case", "Smoke_tcGetUserDetailsUsingUserService_001", "SMK-52414", "getUsers", "Users", "P1", "API" } )
    public void tcGetUserDetailsUsingUserService_001() throws Exception {
        Log.testCaseInfo( "SMK-16160 - Verify the response displayed correctly for admin user" );
        String adminUsernameNew = "admin" + System.nanoTime();
        String adminDetails = createUserWithCustomization( adminUsernameNew, RBSDataSetupConstants.ADMIN_ROLE, Arrays.asList( orgId ) );
        String adminIDNew = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        String accessToken = new RBSUtils().getAccessToken( adminUsernameNew, password );
        HashMap<String, String> response = getUserDetailByUserService( adminIDNew, orgId, accessToken );

        // Validations
        VerifyAPI( response, CommonAPIConstants.STATUS_CODE_OK );
        Log.testCaseResult();
    }

    @Test ( priority = 1, groups = { "smoke_test_case", "Smoke_tcGetUserDetailsUsingUserService_002", "SMK-52414", "getUsers", "Users", "P1", "API" } )
    public void tcGetUserDetailsUsingUserService_002() throws Exception {
        Log.testCaseInfo( "SMK-16172 - Verify the reponse with Student id" );
        String studentUsernameNew = "student" + System.nanoTime();
        String studentDetails = createUserWithCustomization( studentUsernameNew, RBSDataSetupConstants.ADMIN_ROLE, Arrays.asList( orgId ) );
        String studentIDNew = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
        String accessToken = new RBSUtils().getAccessToken( studentUsernameNew, password );
        HashMap<String, String> response = getUserDetailByUserService( studentIDNew, orgId, accessToken );

        // Validations
        VerifyAPI( response, CommonAPIConstants.STATUS_CODE_OK );
        Log.testCaseResult();
    }

    @Test ( priority = 1, groups = { "smoke_test_case", "Smoke_tcGetUserDetailsUsingUserService_003", "SMK-52414", "getUsers", "Users", "P1", "API" } )
    public void tcGetUserDetailsUsingUserService_003() throws Exception {
        Log.testCaseInfo( "SMK-16165- Verify the details for the Google User ID" );

        String gcusername = configProperty.getProperty( ConfigConstants.GC_BASIC_USER );
        String gcpassword = RBSDataSetupConstants.DEFAULT_PASSWORD;
        String gcorgId = configProperty.getProperty( ConfigConstants.GC_BASIC_SCHOOL );
        String rumbaId = configProperty.getProperty( ConfigConstants.GC_BASIC_TEACHER_ID );
        String accessToken = new RBSUtils().getAccessToken( gcusername, gcpassword );
        HashMap<String, String> response = getUserDetailByUserService( rumbaId, gcorgId, accessToken );

        // Validations
        VerifyAPI( response, CommonAPIConstants.STATUS_CODE_OK );
        Log.testCaseResult();
    }

    @Test ( priority = 1, description = "Verify the Username is updated in A& E ", groups = { "smoke_test_case", "Smoke_tcGetUserDetailsUsingUserService_007", "SMK-52414", "getUsers", "Users", "P1", "API" }, enabled = false )
    public void tcGetUserDetailsUsingUserService_007() throws Exception {
        // Can be done in manual only
        String userName = "teacher" + System.nanoTime();

        String teacherId = createMultiOrgTeacher( Arrays.asList( orgId ), userName );
        String accessToken = new RBSUtils().getAccessToken( userName, password );
        HashMap<String, String> response = getUserDetailByUserService( teacherId, orgId, accessToken );

        VerifyTitle( response );
        HashMap<String, String> userDetails = new HashMap<String, String>();

        userDetails.put( RBSDataSetupConstants.USERNAME, userName );
        userDetails.put( RBSDataSetupConstants.USERID, teacherId );
        userDetails.put( RBSDataSetupConstants.PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        userDetails.put( RBSDataSetupConstants.DISPLAY_NAME, "Teacher by user serive" );
        userDetails.put( RBSDataSetupConstants.ORG_ROLE, "T" );
        userDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
        userDetails.put( RBSDataSetupConstants.TITLE, "Dr." );

        new RBSUtils().updateUserByUserService( userDetails );

        //  = new RBSUtils().createUserByUserService( userDetails );
        // new RBSUtils().resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, teacherId);

        accessToken = new RBSUtils().getAccessToken( userName, password );
        response = getUserDetailByUserService( teacherId, orgId, accessToken );
        userDetails.clear();

        String userNameupdated = "updatedteacher" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.USERNAME, userNameupdated );
        userDetails.put( RBSDataSetupConstants.USERID, teacherId );
        userDetails.put( RBSDataSetupConstants.PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        userDetails.put( RBSDataSetupConstants.DISPLAY_NAME, "Teacher by user serive" );
        userDetails.put( RBSDataSetupConstants.ORG_ROLE, "T" );
        userDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
        userDetails.put( RBSDataSetupConstants.TITLE, "Dr." );

        new RBSUtils().updateUserByUserService( userDetails );
        VerifyAPI( response, CommonAPIConstants.STATUS_CODE_OK );
        Log.testCaseResult();
    }

    @Test ( priority = 1, groups = { "SMK-52414", "getUsers", "Users", "P1", "API", "smoke_test_case", "Smoke_tcGetUserDetailsUsingUserService_004" }, dataProvider = "getUserDetailsValidData" )
    public void tcGetUserDetailsUsingUserService_004( String description, String scenario, String expStatusCode ) throws Exception {

        String teacherUsernameNew;
        String teacherDetails;
        String teacherIDNew = null;
        String className = null;
        String classId = null;
        HashMap<String, String> response = null;
        Log.testCaseInfo( description );
        Log.testCaseInfo( "SMK-16173 - Verify the person id field shows the rumba id of the teacher" );
        Log.testCaseInfo( "SMK-16174 - Verify the first name field shows proper value" );
        Log.testCaseInfo( "SMK-16175 - Verify the Last name field shows proper value" );
        Log.testCaseInfo( "SMK-16176 - Verify the gender filed value shows as NOT_SPECIFIED" );
        Log.testCaseInfo( "SMK-16177 - Verify the title field shows the appropriate title" );
        Log.testCaseInfo( "SMK-16178 - Verify the Username field from the response" );
        Log.testCaseInfo( "SMK-16179 - Verfy the Organizatio field value shows single org id when teacher is part of one school" );

        switch ( scenario ) {
            case "VALID_TEACHER_USER":
                Log.testCaseInfo( "SMK-16161- Verify the response displayed correctly for teacher user" );
                Log.testCaseInfo( "SMK-16151 - Verify the user data is returned correctly for the valid user for user profile API" );
                SMUtils.logDescriptionTC( "SMK-16181 - Verify the response when the teacher without class." );
                teacherUsernameNew = "teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                String accessToken = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                response = getUserDetailByUserService( teacherIDNew, orgId, accessToken );

                break;

            case "SHARED_STUDENT":

                teacherUsernameNew = "shared_student_teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                String accessToken1 = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                // Create a student present in both org
                String studentName = "sharedstudent" + System.nanoTime();
                String studentId = createMultiOrgStudent( Arrays.asList( orgId, org2Id ), studentName );
                className = "Group with Shared student " + System.nanoTime();
                classId = new GroupAPI().createGroupWithCustomization( className, teacherIDNew, Arrays.asList( studentId ), orgId, accessToken1 );
                response = getUserDetailByUserService( teacherIDNew, orgId, accessToken1 );
                break;

            case "MULTIPLE_STUDENTS":

                teacherUsernameNew = "multple_student_teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                String accessToken2 = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                className = "Group with Multiple Students " + System.nanoTime();
                classId = new GroupAPI().createGroupWithCustomization( className, teacherId, studentRumbaIds, orgId, accessToken2 );
                response = getUserDetailByUserService( teacherIDNew, orgId, accessToken2 );
                break;

            case "NO_STUDENTS":

                teacherUsernameNew = "no_student_teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                String accessToken3 = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                className = "No_Students_Group" + System.nanoTime();
                classId = new GroupAPI().createGroupWithCustomization( "Group - with no student", teacherIDNew, new ArrayList<String>(), orgId, accessToken3 );
                response = getUserDetailByUserService( teacherIDNew, orgId, accessToken3 );
                break;

            case "NO_SM_PRODUCT":

                teacherUsernameNew = "no_sm_teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                String accessToken4 = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                className = "No_SM_Class" + System.nanoTime();
                new RBSUtils().CreateClassWithoutSMProdcut( className, teacherIDNew, studentRumbaIds.get( 0 ), orgId, accessToken4 );
                response = getUserDetailByUserService( teacherIDNew, orgId, accessToken4 );
                break;

            case "SHARED_TEACHER":
                Log.testCaseInfo( "SMK-16166- Verify the details for the Shared Teacher ID" );
                teacherUsernameNew = "shared_teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                String accessToken5 = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                className = "Group with Shared Teachers " + System.nanoTime();
                classId = new RBSUtils().createClassWithMultipleTeacher( className, Arrays.asList( teacherIDNew, teacherId ), Arrays.asList( studentRumbaIds.get( 0 ) ), orgId, accessToken5 );
                response = getUserDetailByUserService( teacherIDNew, orgId, accessToken5 );
                break;

            case "SUSPENDED_USER":

                teacherUsernameNew = "suspended_teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                String accessToken6 = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                new RBSUtils().suspendUser( Arrays.asList( teacherIDNew ) );
                response = getUserDetailByUserService( teacherIDNew, orgId, accessToken6 );
                break;

            case "MULTI_ORG_TEACHER":

                teacherUsernameNew = "multi_org_teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId, org2Id ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                String accessToken7 = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                response = getUserDetailByUserService( teacherIDNew, org2Id, accessToken7 );
                break;

            case "NUMERIC_USERNAME":

                teacherUsernameNew = "12345" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                String accessToken8 = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                response = getUserDetailByUserService( teacherIDNew, orgId, accessToken8 );
                break;

            case "INTEGRATED_ENV_ON_BASIC":

                String accessToken9 = new RBSUtils().getAccessToken( configProperty.getProperty( ConfigConstants.AUTO__TEACHER_USER_NAME ), password );
                response = getUserDetailByUserService( GetUserDetailsUsingUserServiceAPIConstants.AUTO_USER_USER_ID, GetUserDetailsUsingUserServiceAPIConstants.AUTO_USER_ORG_ID, accessToken9 );

                break;

            case "SYSTEM_ADMIN":

                teacherUsernameNew = "admin" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.PEARSON_ADMIN_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                String details = new RBSUtils().getUser( teacherIDNew );
                HashMap<Admins, String> adminDetails = RBSDataSetup.adminDetails;
                String accessToken11 = new RBSUtils().getAccessToken( teacherUsernameNew, password );

                response = getUserDetailByUserService( teacherIDNew, orgId, accessToken11 );
                break;

            case "USERNAME_SPECIAL_CHARACTER":

                String teacherUserName = "test@#$test" + System.nanoTime();
                HashMap<String, String> userDetails = new HashMap<>();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, teacherUserName );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
                userDetails.put( RBSDataSetupConstants.EMAIL, GetUserDetailsUsingUserServiceAPIConstants.SPCL_CHARACTER_USER_EMAIL_ID );
                String sharedTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                new RBSUtils().resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, sharedTeacherID );
                String accessCode = new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                response = getUserDetailByUserService( sharedTeacherID, orgId, accessCode );
                break;

            default:
                break;

        }
        // Validating Response Code, Schema and User details
        if ( scenario.equals( "MULTI_ORG_TEACHER" ) ) {
            VerifyResponseCode( response, CommonAPIConstants.STATUS_CODE_OK );
            VerifyResponseMessage( response, "User Details returned Successfully" );
        } else {
            VerifyAPI( response, CommonAPIConstants.STATUS_CODE_OK );
            Log.testCaseResult();
        }
    }

    @DataProvider ( name = "getUserDetailsValidData" )
    public Object[][] getUserDetailsValidData() {
        Object[][] inputData = { { "SMK-16146 - Verify the status code is 200 for valid data for user profile API", "VALID_TEACHER_USER", "200" }, { "SMK-16167- Verify the details for the Teacher with Shared students", "SHARED_STUDENT", "200" },
                { "SMK-16168- Verify the details for the teacher with No students", "NO_STUDENTS", "200" }, { "SMK-16183 - Verify the response when the teacher class has only non-Successmaker product", "NO_SM_PRODUCT", "200" },
                { "SMK-16166- Verify the details for the Shared Teacher ID", "SHARED_TEACHER", "200" }, { "SMK-16163 - Verify the valid response for numerical username", "NUMERIC_USERNAME", "200" },

                { "SMK-16148- Verify the Response for the suspended user id", "SUSPENDED_USER", "200" }, { "SMK-16180 - Verfy the Organization field value shows Multiple org id when teacher is part of Multi school", "MULTI_ORG_TEACHER", "200" },
                { "SMK-16156- Verify the response displayed correctly for System admin user", "SYSTEM_ADMIN", "200" }, { "SMK-16164 - Verify the response when the username has special characters", "USERNAME_SPECIAL_CHARACTER", "200" },
                { "SMK-16170 - Verify the details for the Auto user id in Basic Instance and MSMN Instance", "INTEGRATED_ENV_ON_BASIC", "200" }

        };

        return inputData;
    }

    @Test ( priority = 1, description = "Admin Verification", groups = { "smoke_test_case", "Smoke_tcGetUserDetailsUsingUserService_006", "SMK-52414", "getUsers", "Users", "P1", "API" } )
    public void tcGetUserDetailsUsingUserService_006() throws Exception {
        Log.testCaseInfo( "SMK-16157- Verify the response displayed correctly for District admin user" );
        Log.testCaseInfo( "SMK-16158- Verify the response for Sub district admin user" );
        Log.testCaseInfo( "SMK-16159 - Verofy the response for multi school associated admin" );
        String adminDetails;
        String adminUserName = null;
        String adminUserId;
        String adminOrgId;
        String accessToken;
        HashMap<String, String> response = null;
        String innerJson;

        JSONObject affliation;

        // District Admin    
        //adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        adminDetails = new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ) ) );
        adminUserName = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), RBSDataSetupConstants.USERNAME ).get( 0 );
        adminUserId = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), RBSDataSetupConstants.USERID ).get( 0 );
        innerJson = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), GetUserDetailsUsingUserServiceAPIConstants.AFFILIATION ).get( 0 );
        affliation = new JSONObject( "{ \"data\":" + innerJson + "}" );
        adminOrgId = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), GetUserDetailsUsingUserServiceAPIConstants.PRIMARY_ORGANIZATIONID_FIELD ).get( 0 );
        accessToken = new RBSUtils().getAccessToken( adminUserName, password );

        // Validating API
        response = getUserDetailByUserService( adminUserId, adminOrgId, accessToken );
        VerifyAPI( response, CommonAPIConstants.STATUS_CODE_OK );

        // Sub-district Admin
        //adminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        adminDetails = new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN ) ) );
        adminUserName = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), RBSDataSetupConstants.USERNAME ).get( 0 );
        adminUserId = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), RBSDataSetupConstants.USERID ).get( 0 );
        innerJson = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), GetUserDetailsUsingUserServiceAPIConstants.AFFILIATION ).get( 0 );
        affliation = new JSONObject( "{ \"data\":" + innerJson + "}" );
        adminOrgId = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), GetUserDetailsUsingUserServiceAPIConstants.PRIMARY_ORGANIZATIONID_FIELD ).get( 0 );
        accessToken = new RBSUtils().getAccessToken( adminUserName, password );

        // Validating API
        response = getUserDetailByUserService( adminUserId, adminOrgId, accessToken );
        VerifyAPI( response, CommonAPIConstants.STATUS_CODE_OK );

        // School Admin
        //adminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
        adminDetails = new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ) ) );
        adminUserName = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), RBSDataSetupConstants.USERNAME ).get( 0 );
        adminUserId = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), RBSDataSetupConstants.USERID ).get( 0 );
        innerJson = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), GetUserDetailsUsingUserServiceAPIConstants.AFFILIATION ).get( 0 );
        affliation = new JSONObject( "{ \"data\":" + innerJson + "}" );
        adminOrgId = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), GetUserDetailsUsingUserServiceAPIConstants.PRIMARY_ORGANIZATIONID_FIELD ).get( 0 );
        accessToken = new RBSUtils().getAccessToken( adminUserName, password );

        // Validating API
        response = getUserDetailByUserService( adminUserId, adminOrgId, accessToken );
        VerifyAPI( response, CommonAPIConstants.STATUS_CODE_OK );

        // Multi School Admin
        //adminDetails = RBSDataSetup.adminDetails.get( Admins.MULTI_SCHOOL_ADMIN );
        adminDetails = new RBSUtils().getUser( new RBSUtils().getUserIDByUserName( RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN ) ) );
        adminUserName = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), RBSDataSetupConstants.USERNAME ).get( 0 );
        adminUserId = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), RBSDataSetupConstants.USERID ).get( 0 );
        innerJson = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), GetUserDetailsUsingUserServiceAPIConstants.AFFILIATION ).get( 0 );
        affliation = new JSONObject( "{ \"data\":" + innerJson + "}" );
        //adminOrgId = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), GetUserDetailsUsingUserServiceAPIConstants.ORGANIZATIONID_FIELD ).get( 0 );
        //adminOrgId = adminOrgId.replaceAll( "\"", "" ).replaceAll("\\[", "").replaceAll("\\]","");
        adminOrgId = new SMAPIProcessor().getKeyValues( new JSONObject( adminDetails ), GetUserDetailsUsingUserServiceAPIConstants.PRIMARY_ORGANIZATIONID_FIELD ).get( 0 );
        accessToken = new RBSUtils().getAccessToken( adminUserName, password );

        // Validating API
        response = getUserDetailByUserService( adminUserId, adminOrgId, accessToken );
        VerifyAPI( response, CommonAPIConstants.STATUS_CODE_OK );

        Log.testCaseResult();
    }

    @Test ( priority = 1, groups = { "SMK-52414", "getUsers", "Users", "P1", "API" }, dataProvider = "getUserDetailsInvalidData" )
    public void tcGetUserDetailsUsingUserService_005( String description, String scenario, String expStatusCode ) throws Exception {

        String accessToken;
        String teacherUsernameNew = null;
        String expectedResponse = null;
        String teacherDetails = null;
        String teacherIDNew = null;
        String endPoint = null;
        HashMap<String, String> response = null;
        Map<String, String> headers = null;
        Map<String, String> params = null;
        Log.testCaseInfo( scenario );

        if ( scenario.equalsIgnoreCase( "INVALID_TOKEN" ) || scenario.equalsIgnoreCase( "DELETED_USER" ) ) {
            expectedResponse = CommonAPIConstants.STATUS_CODE_UNAUTHORIZED;

        } else if ( scenario.equalsIgnoreCase( "STUDENT_AUTHORIZATION" ) ) {
            expectedResponse = CommonAPIConstants.STATUS_CODE_FORBIDDAN;
        } else if ( scenario.equalsIgnoreCase( "INVALID_URL" ) ) {
            expectedResponse = CommonAPIConstants.STATUS_CODE_NOTFOUND;
        } else {
            expectedResponse = CommonAPIConstants.STATUS_CODE_BAD_REQUEST;

        }

        switch ( scenario ) {
            case "INVALID_TOKEN":

                Log.testCaseInfo( "SMK-16154- Verify the invalid response body for invalid headers for user profile API" );
                teacherUsernameNew = "teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                accessToken = CommonAPIConstants.INVALID_ACCESS_TOKEN;
                response = getUserDetailByUserService( teacherIDNew, orgId, accessToken );
                break;

            case "STUDENT_AUTHORIZATION":

                Log.testCaseInfo( "SMK-16153- Verify the response body as AccessDeniedException for the students for user profile API" );
                //String studUsername = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( orgUsed ).get( "Student1" ), StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.USERNAME );
                accessToken = new RBSUtils().getAccessToken( studentName1, password );
                response = getUserDetailByUserService( studentRumbaIds.get( 0 ), orgId, accessToken );
                break;

            case "INVALID_URL":

                teacherUsernameNew = "invalid_url_teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                accessToken = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                // Endpoint
                endPoint = GetUserDetailsUsingUserServiceAPIConstants.INVALID_GET_USER_DETAILS;
                endPoint = endPoint.replace( UserAPIConstants.USERID, teacherIDNew );
                // headers
                headers = new HashMap<String, String>();
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                headers.put( UserAPIConstants.ORGID, orgId );
                headers.put( UserAPIConstants.USERID, teacherIDNew );
                // InputParams
                params = new HashMap<>();
                Log.message( "Making GET Call to return user details using User Service API - " + configProperty.getProperty( "SMAppUrl" ) + endPoint );
                response = RestHttpClientUtil.GET( configProperty.getProperty( "SMAppUrl" ), endPoint, headers, params );
                break;

            case "INVALID_ID":

                teacherUsernameNew = "invalid_id_teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                accessToken = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                // Endpoint
                endPoint = GetUserDetailsUsingUserServiceAPIConstants.GET_USER_DETAILS;
                endPoint = endPoint.replace( UserAPIConstants.USERID, UserAPIConstants.INVALID_USER_ID );
                // headers
                headers = new HashMap<String, String>();
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                headers.put( UserAPIConstants.ORGID, orgId );
                headers.put( UserAPIConstants.USERID, teacherIDNew );
                // InputParams
                params = new HashMap<>();
                Log.message( "Making GET Call to return user details using User Service API - " + configProperty.getProperty( "SMAppUrl" ) + endPoint );
                response = RestHttpClientUtil.GET( configProperty.getProperty( "SMAppUrl" ), endPoint, headers, params );
                break;

            case "UPPER_CASE_USERID":
                teacherUsernameNew = "uppercase_id_teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                accessToken = new RBSUtils().getAccessToken( teacherUsernameNew, password );
                // Endpoint
                endPoint = GetUserDetailsUsingUserServiceAPIConstants.GET_USER_DETAILS;
                endPoint = endPoint.replace( UserAPIConstants.USERID, teacherIDNew.toUpperCase() );
                // headers
                headers = new HashMap<String, String>();
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                headers.put( UserAPIConstants.ORGID, orgId );
                headers.put( UserAPIConstants.USERID, teacherIDNew );
                // InputParams
                params = new HashMap<>();
                Log.message( "Making GET Call to return user details using User Service API - " + configProperty.getProperty( "SMAppUrl" ) + endPoint );
                response = RestHttpClientUtil.GET( configProperty.getProperty( "SMAppUrl" ), endPoint, headers, params );
                break;
            case "DELETED_USER":
                teacherUsernameNew = "teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
                accessToken = new RBSUtils().getAccessToken( username, password );

                // Deleting user
                new RBSUtils().deleteUser( Arrays.asList( teacherIDNew ) );
                response = getUserDetailByUserService( teacherIDNew, orgId, accessToken );

                break;

            default:
                break;

        }
        // Validating Response Code, Schema and User details
        VerifyResponseCode( response, expectedResponse );
        VerifySchema( expectedResponse, response );

        Log.testCaseResult();
    }

    @DataProvider ( name = "getUserDetailsInvalidData" )
    public Object[][] getUserDetailsInvalidData() {

        Object[][] inputData = { { "SMK-16147 - Verify the status code is 401 for wrong credentials for user profile API", "INVALID_TOKEN", "401" },
                { "SMK-16149- Verify the status code is 403 when the autorization is wrong for user profile API -Student session accessing teacher", "STUDENT_AUTHORIZATION", "403" },
                { "SMK-16155 - Verify the status code is 404 when the URL is wrong for user profile API", "INVALID_URL", "404" }, { "SMK-16150- Verify the status code is 400 when invalid user for user profile API", "INVALID_ID", "400" },
                { "SMK-16152 - Verify the response body returned as empty for the non existance users for user profile API", "DELETED_USER", "401" },
                { "SMK-16162- Verify the 400 response for upper case in userID(Passing the uppercase userid for alphabets in the endpoint)", "UPPER_CASE_USERID", "400" }

        };

        return inputData;
    }

    public HashMap<String, String> getExpectedUserDetailsHashMap( String userId ) {

        HashMap<String, String> userDetails = new HashMap<String, String>();
        JSONObject userJsonObject = new JSONObject( new RBSUtils().getUser( userId ) );
        JSONObject emailAddressJson = new JSONObject( "{ \"data\":" + new SMAPIProcessor().getKeyValues( userJsonObject, GetUserDetailsUsingUserServiceAPIConstants.EMAIL_INFO_FIELD ).get( 0 ) + "}" );
        userDetails.put( GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, new SMAPIProcessor().getKeyValues( userJsonObject, GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD ).get( 0 ) );
        userDetails.put( GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, new SMAPIProcessor().getKeyValues( userJsonObject, GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD ).get( 0 ) );
        userDetails.put( GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, new SMAPIProcessor().getKeyValues( userJsonObject, RBSDataSetupConstants.USERNAME ).get( 0 ) );
        userDetails.put( GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, userId );
        userDetails.put( GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, new SMAPIProcessor().getKeyValues( userJsonObject, GetUserDetailsUsingUserServiceAPIConstants.EMAIL_ADDRESS_FIELD ).get( 0 ) );
        return userDetails;
    }

    public HashMap<String, String> getActualUserDetailsInHashMap( HashMap<String, String> response ) {

        HashMap<String, String> userDetails = new HashMap<String, String>();
        JSONObject userJsonObject = new JSONObject( response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) );
        userDetails.put( GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_DATAVALUE ) );
        userDetails.put( GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_DATAVALUE ) );
        userDetails.put( GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), GetUserDetailsUsingUserServiceAPIConstants.USERNAME_DATAVALUE ) );
        userDetails.put( GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), GetUserDetailsUsingUserServiceAPIConstants.PERSONID_DATAVALUE ) );
        userDetails.put( GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), GetUserDetailsUsingUserServiceAPIConstants.EMAIL_DATAVALUE ) );

        return userDetails;
    }

    public void VerifyOrganizationDetails( HashMap<String, String> response ) {

        JSONObject userJsonObject = new JSONObject( new RBSUtils().getUser( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), GetUserDetailsUsingUserServiceAPIConstants.PERSONID_DATAVALUE ) ) );
        String innerJSON = new SMAPIProcessor().getKeyValues( userJsonObject, GetUserDetailsUsingUserServiceAPIConstants.PRIMARY_ORGANIZATIONID_FIELD ).get( 0 );
        List<String> expOrgId = Arrays.asList( innerJSON );
        //innerJSON= innerJSON.replaceAll("\\[", "").replaceAll("\\]","");
        innerJSON = innerJSON.replaceAll( "\"", "" ).replaceAll( "\\s+", "" );
        Log.message( innerJSON );

        String orgIdValue = SMUtils.getKeyValueFromResponse( response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ), GetUserDetailsUsingUserServiceAPIConstants.ORGANIZATIONID_DATAVALUE );
        orgIdValue = orgIdValue.substring( 1, orgIdValue.length() - 1 );

        List<String> actOrgIds = new ArrayList<>();
        List<String> jsonArray = Arrays.asList( orgIdValue.split( "," ) );
        Log.message( jsonArray.toString() );

        jsonArray.forEach( orgId -> {
            Log.message( orgId );
            actOrgIds.add( orgId.substring( 1, orgId.length() - 1 ) );
        } );

        Log.assertThat( SMUtils.compareTwoList( expOrgId, actOrgIds ), "The organizaiton Id fiels is matching", "The organizaion field is not matching" + "Actual " + actOrgIds.toString() + "Expected" + expOrgId );

    }

    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = new SMAPIProcessor().isSchemaValid( "GetUserDetailsSchema", StatusCode, response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
    }

    public void VerifyResponseCode( HashMap<String, String> response, String expectedCode ) {
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( expectedCode ), "Response status code is as expected - " + expectedCode,
                "Response status code is not as expected - Actual " + response.get( "statusCode" ) + " Expected " + expectedCode );
    }

    public void VerifyAPI( HashMap<String, String> response, String expectedCode ) {

        // Verifying status code
        VerifyResponseCode( response, expectedCode );
        Log.message( response.toString() );
        String userId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), GetUserDetailsUsingUserServiceAPIConstants.PERSONID_DATAVALUE );

        // Verifying  Details of user 
        Log.assertThat( new SMUtils().compareTwoHashMap( getActualUserDetailsInHashMap( response ), getExpectedUserDetailsHashMap( userId ) ), "The user Details is matching as expected!", "The user Details is not matching" );

        // Middle Name validation
        VerifyMiddleName( response );

        // Verifying Title
        VerifyTitle( response );

        //Gender Validation
        String genderValue = SMUtils.getKeyValueFromResponse( response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ), GetUserDetailsUsingUserServiceAPIConstants.GENDER_DATAVALUE );
        Log.assertThat( genderValue.equals( GetUserDetailsUsingUserServiceAPIConstants.NOT_SPECIFIED ), "Gender is returned correctly", "Gender is not returned correctly" );

        // Organization Field is matching
        VerifyOrganizationDetails( response );

    }

    public void VerifyResponseMessage( HashMap<String, String> response, String expectedMessage ) {
        if ( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( expectedMessage ) ) {
            Log.pass( "Message Verified successfully!" );
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + expectedMessage + " Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ) );
        }

    }

    public void VerifyMiddleName( HashMap<String, String> response ) {

        String userId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), GetUserDetailsUsingUserServiceAPIConstants.PERSONID_DATAVALUE );
        HashMap<String, String> userDetails = new HashMap<String, String>();
        JSONObject userJsonObject = new JSONObject( new RBSUtils().getUser( userId ) );
        String expMiddleName = new SMAPIProcessor().getKeyValues( userJsonObject, GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD ).get( 0 );
        String actMiddleName = new SMAPIProcessor().getKeyValues( userJsonObject, GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD ).get( 0 );

        if ( expMiddleName == null ) {
            Log.assertThat( actMiddleName.equals( "" ), "The Middle Name field is Matches!", "The Middle Name field is not Matches!" );

        } else {
            Log.assertThat( expMiddleName.equals( actMiddleName ), "The Middle Name field is Matches!", "The Middle Name field is not Matches!" );
        }

    }

    public void VerifyTitle( HashMap<String, String> response ) {

        String userId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), GetUserDetailsUsingUserServiceAPIConstants.PERSONID_DATAVALUE );
        JSONObject userJsonObject = new JSONObject( new RBSUtils().getUser( userId ) );
        JSONObject emailAddressJson = new JSONObject( "{ \"data\":" + new SMAPIProcessor().getKeyValues( userJsonObject, GetUserDetailsUsingUserServiceAPIConstants.EMAIL_INFO_FIELD ).get( 0 ) + "}" );

        String expTitleName = new SMAPIProcessor().getKeyValues( userJsonObject, GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD ).get( 0 );

        try {
            String actTitleName = new SMAPIProcessor().getKeyValues( new JSONObject( response.get( Constants.REPORT_BODY ) ), GetUserDetailsUsingUserServiceAPIConstants.TITLE_NAME ).get( 0 );
            Log.assertThat( expTitleName.equals( actTitleName ), "The title field matches", "The title field not matches" );
        } catch ( Exception e ) {
            Log.assertThat( true, "The title field is not available in response as expected ", "The title field is available  as not expected " );
        }
    }
}
