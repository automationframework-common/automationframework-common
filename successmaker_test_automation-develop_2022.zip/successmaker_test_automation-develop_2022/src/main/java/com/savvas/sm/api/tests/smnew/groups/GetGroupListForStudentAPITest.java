package com.savvas.sm.api.tests.smnew.groups;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.DeleteGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.getGroupListAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

/**
 * This class used to test the API of get group listing for Given student
 * 
 * @author ajith.mohan
 *
 */
public class GetGroupListForStudentAPITest extends GroupAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String teacherUsername = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String student1Id;
    String student2Id;
    String student3Id;
    String student4Id;
    private String student1Detail = null;
    private String student2Detail = null;
    private String student3Detail = null;
    private String student4Detail = null;
    @BeforeClass(alwaysRun = true)
    public void BeforeClass() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        student1Detail=RBSDataSetup.getMyStudent( school, teacherUsername );
        student2Detail=RBSDataSetup.getMyStudent( school, teacherUsername );
        student3Detail=RBSDataSetup.getMyStudent( school, teacherUsername );
        student4Detail=RBSDataSetup.getMyStudent( school, teacherUsername );
        student1Id= SMUtils.getKeyValueFromResponse( student1Detail, Constants.USERID_HEADER );
        student2Id= SMUtils.getKeyValueFromResponse( student2Detail, Constants.USERID_HEADER );
        student3Id= SMUtils.getKeyValueFromResponse( student3Detail, Constants.USERID_HEADER );
        student4Id= SMUtils.getKeyValueFromResponse( student4Detail, Constants.USERID_HEADER );
        
    }

    @Test ( priority = 1, dataProvider = "getGroupListPositive", groups = { "SMK-50610", "Group","smoke_test_case", "GroupListForStudents_TC01","GroupListForStudents", "P1", "API" } )
    public void tcGetGroupListPositive01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> studentDetails = new HashMap<>();
        HashMap<String, String> userDetails = new HashMap<>();
        List<String> schools = new ArrayList<>();
        String groupName = "Successmaker API Test Group " + System.nanoTime();

        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        String finalSchool = "";

        switch ( scenario ) {
            case "HAPPY PATH":
                studentRumbaIds.add( student1Id );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                HashMap<String, String> createGroup = createGroup( smUrl, groupDetails, studentRumbaIds );
                if ( createGroup.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                } else {
                    Log.message( "Issue in creating group - " + createGroup.get( Constants.REPORT_BODY ) );
                }

                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, student1Id );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                break;

            case "MULTIPLE STUDENT GROUPS":
                studentRumbaIds.clear();
                studentRumbaIds.add( student1Id );
                studentRumbaIds.add( student2Id );
                studentRumbaIds.add( student3Id );
                studentRumbaIds.add( student4Id );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                if ( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, student1Id );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                break;
            case "SHARED STUDENT GROUP":
                studentRumbaIds.clear();
                String sharedTeacher = "SharedTeacher" + System.nanoTime();
                String sharedStudent = "SharedStudent" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, sharedTeacher );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );

                String sharedTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                userDetails.put( RBSDataSetupConstants.USERNAME, sharedStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                String sharedStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                studentRumbaIds.add( sharedStudentID );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, sharedTeacherID );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                if ( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                if ( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, sharedStudentID );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                break;
            case "MULTIPLE SCHOOL STUDENT GROUP":
                studentRumbaIds.clear();
                String multiSchoolStudent = "MultiSchStudent" + System.nanoTime();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );

                for ( String school : schools ) {
                    finalSchool += school.concat( "\",\"" );
                }
                finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
                String multiSchoolStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                Log.message( "Created student with multiple schools " + finalSchool + " Student Id - " + multiSchoolStudentID );
                studentRumbaIds.add( multiSchoolStudentID );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                if ( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                Log.message( "Created group in School - " + groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgTeacherDetails.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ).get( "Teacher1" ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgTeacherDetails.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ).get( "Teacher1" ), "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                if ( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                Log.message( "Created group in School - " + groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, multiSchoolStudentID );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                break;
            case "STUDENT NOT PART OF THE GROUP":
                studentRumbaIds.clear();
                studentRumbaIds.add( student1Id );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                if ( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                studentRumbaIds.clear();
                if ( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, student1Id );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                break;

            case "SUSPENDED STUDENT GROUP":
                studentRumbaIds.clear();
                studentRumbaIds.add( student1Id );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                if ( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                new RBSUtils().suspendUser( studentRumbaIds );
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, student1Id );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                break;
            case "DELETED STUDENT GROUP":
                studentRumbaIds.clear();
                studentRumbaIds.add( student2Id );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                if ( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                new RBSUtils().deleteUser( studentRumbaIds );
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, student2Id );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                break;
            case "TRANSFERRED STUDENT GROUP":
                studentRumbaIds.clear();
                HashMap<String, String> orgDetails = new HashMap<>();
                orgDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, RBSDataSetupConstants.ORGANIZATION_NAME_VALUE + System.currentTimeMillis() );
                orgDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SCHOOL );
                orgDetails.put( RBSDataSetupConstants.SCHOOL_ID, new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                orgDetails.put( RBSDataSetupConstants.DISTRICT_ID, configProperty.getProperty( "district_ID" ) );

                new RBSUtils().relateOrganization( orgDetails );

                studentRumbaIds.add( student3Id );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY );

                new RBSUtils().resetPassword( orgDetails.get( RBSDataSetupConstants.SCHOOL_ID ), RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student3" ), "userId" ) );
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, student3Id );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                break;
            case "GOOGLE CLASS":
                
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, configProperty.getProperty( "GC_Student_ID_Basic" ) );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( DeleteGroupAPIConstants.GC_USER_BASIC, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, DeleteGroupAPIConstants.GC_USER_ID_BASIC );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, DeleteGroupAPIConstants.GC_SCHOOL_BASIC );
                break;

            case "MULTIPLE SCHOOL TEACHER STUDENT GROUP":
                studentRumbaIds.clear();
                String multiSchoolS = "MultiSchStudent" + System.nanoTime();
                String multiSchoolT = "MultiSchTeacher" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                String multipleSchools = "";
                for ( String school : schools ) {
                    multipleSchools += school.concat( "\",\"" );
                }
                multipleSchools = multipleSchools.substring( 0, multipleSchools.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, multipleSchools );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolS );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                String multiSchoolSID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolT );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                String multiSchoolTID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                Log.message( "StudentID: " + multiSchoolSID , "TeacherID " +multiSchoolTID);
                new RBSUtils().resetPassword( multipleSchools, RBSDataSetupConstants.DEFAULT_PASSWORD, multiSchoolTID );

                studentRumbaIds.add( multiSchoolSID );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolT, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multiSchoolTID );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                if ( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName + System.currentTimeMillis() );

                if ( createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolT, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multiSchoolTID );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, multiSchoolSID );
                break;
        }

        HashMap<String, String> apiResponse = getGroupsForStudentID( smUrl, studentDetails );
        Log.pass( "Returned Group Response - " + apiResponse.get( Constants.REPORT_BODY ) );
        Log.assertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected! - " + apiResponse.get( Constants.STATUS_CODE ),
                "Issue in returning status code! Expected - " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
        String cmsResponse = new RBSUtils().getClassForStudent( studentDetails.get( getGroupListAPIConstants.STUDENT_ID ) );
        Log.assertThat( validateResponse( apiResponse.get( Constants.REPORT_BODY ), cmsResponse, studentDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ), studentDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ID ) ),
                "Response returned as expected", "Issue in response" );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "getGroupListingForStudentID", statusCode, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        Log.testCaseResult();
    }

    /**
     * Data provider to give the positive data
     * 
     * @return
     */
    @DataProvider ( name = "getGroupListPositive" )
    public Object[][] groupListPositive() {

        Object[][] inputData = { { "Verify the teacher can able to see the group when the student is part of that group.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can able to see the group when the student is part of the group which having multiple students.", "MULTIPLE STUDENT GROUPS", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify both teacher can able to see group when the student is shared by 2 teachers.", "SHARED STUDENT GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can able to see the group when the student is part of the group and the group associated with successmaker product.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can able to see the group from particuler school when the student part of multiple school.", "MULTIPLE SCHOOL STUDENT GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher cannot able to see the group when the student is not part of the group.", "STUDENT NOT PART OF THE GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the API returning the group ID as A&E ID.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the API retuning the organizaiton ID correctly when the student is part of multiple school.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the API returning the group owner ID as A&E ID.", "HAPPY PATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can able to see the groups of suspended students.", "SUSPENDED STUDENT GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teaher cannot see the groups for deleted students.(Only Basic district)", "DELETED STUDENT GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher when the student org ID is changed.", "TRANSFERRED STUDENT GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can able to see the single school groups if the student and teacher part of multiple schools.", "MULTIPLE SCHOOL TEACHER STUDENT GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can able to see the google classes when the student is associated with google classess.", "GOOGLE CLASS", CommonAPIConstants.STATUS_CODE_OK } };

        return inputData;
    }

    @Test ( priority = 2, dataProvider = "getGroupListNegative", groups = { "SMK-50610", "Group", "GroupListForStudents", "P1", "API" } )
    public void tcGetGroupListNegative01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> studentDetails = new HashMap<>();
        HashMap<String, String> userDetails = new HashMap<>();

        String exception = null;
        String message = null;

        switch ( scenario ) {
            case "NO SM PRODUCT GROUP":

                String withoutProductStudent = "noSMProductStudent" + System.nanoTime();
                String withoutProduct = "noSMProductGroup" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, withoutProductStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                String noProdStudent = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                HashMap<String, String> classDetails = new HashMap<>();
                classDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ) );
                classDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                classDetails.put( RBSDataSetupConstants.STAFF_PI_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                classDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, noProdStudent );
                classDetails.put( RBSDataSetupConstants.SECTION_NAME, withoutProduct );
                new RBSUtils().createClass( classDetails );

                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, noProdStudent );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.GROUP_LIST_DATA_NOT_FOUND_EXCEPTION_MESSAGE;
                break;

            case "ORPHAN STUDENT":
                String orphanStudent = "orphanStudent" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, orphanStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                String orphanStudentId = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, orphanStudentId );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.GROUP_LIST_DATA_NOT_FOUND_EXCEPTION_MESSAGE;
                break;

            case "INVALID TEACHER":
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student4" ), "userId" ) );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails.put( CreateGroupAPIConstants.INVALID_TEACHER, getGroupListAPIConstants.INVALID_INPUT );
                studentDetails.put( CreateGroupAPIConstants.INVALID_ORG, getGroupListAPIConstants.INVALID_INPUT );

                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.GROUP_LIST_DATA_NOT_FOUND_EXCEPTION_MESSAGE;
                break;

            case "INVALID STUDENT":
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student4" ), "userId" ) );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails.put( getGroupListAPIConstants.INVALID_STUDENT, getGroupListAPIConstants.INVALID_INPUT );
                exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                message = CommonAPIConstants.GROUP_LIST_INVALID_STUDENT_EXCEPTION_MESSAGE;
                break;
            case "STUDENT CREDENTIALS":
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student4" ), "userId" ) );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student4" ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student4" ), "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                break;
            case "INVALID CREDENTIALS":
                studentDetails.put( getGroupListAPIConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student4" ), "userId" ) );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, getGroupListAPIConstants.INVALID_INPUT );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                studentDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                break;
        }
        HashMap<String, String> apiResponse = getGroupsForStudentID( smUrl, studentDetails );
        Log.pass( "Returned Group - " + apiResponse.get( Constants.REPORT_BODY ) );
        Log.assertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected! - " + apiResponse.get( Constants.STATUS_CODE ),
                "Issue in returning status code! Expected - " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
        if ( statusCode.equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_OK ) ) {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "getGroupListingForStudentID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
        } else {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "getGroupListingForStudentID", statusCode, apiResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
        }

        verifyException( apiResponse.get( Constants.REPORT_BODY ), exception, true, message );

        Log.testCaseResult();
    }

    /**
     * Data provider to give the negative data
     * 
     * @return
     */
    @DataProvider ( name = "getGroupListNegative" )
    public Object[][] groupListInvalid() {

        Object[][] inputData = { { "Verify the teacher cannot able to see the group when the student is part of the group but the successmaker product is not associated.", "NO SM PRODUCT GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the API returning exception when the teacher ID is invalid.", "INVALID TEACHER", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the API returning exception when the student ID is invalid.", "INVALID STUDENT", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API returning 401 when the authentications is invalid.", "INVALID CREDENTIALS", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the API returning 403 when the authorization is wrong.", "STUDENT CREDENTIALS", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the API retuning null pointer exception when the student is not associated with any of the group from the teacher.", "ORPHAN STUDENT", CommonAPIConstants.STATUS_CODE_OK } };

        return inputData;
    }

    /**
     * To validate the response data with CMS response data
     * 
     * @param actualResponse
     * @param expectedResponse
     * @param schooId
     * @param teacherId
     * @return
     */
    public boolean validateResponse( String actualResponse, String expectedResponse, String schooId, String teacherId ) {
        boolean isVerified = false;
        try {
            JSONArray expectedJsonArray = new JSONArray( expectedResponse );
            JSONArray actualJsonArray = new JSONArray( SMUtils.getKeyValueFromResponse( actualResponse, Constants.DATA ) );

            HashMap<String, HashMap<String, String>> groupDetailsSM = new HashMap<>();
            List<String> groupList = new ArrayList<>();
            IntStream.range( 0, actualJsonArray.length() ).forEach( count -> {
                JSONObject jsonObj = actualJsonArray.getJSONObject( count );
                HashMap<String, String> classAttibutes = new HashMap<>();
                classAttibutes.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( jsonObj.toString(), CreateGroupAPIConstants.GROUP_ID ) );
                classAttibutes.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, SMUtils.getKeyValueFromResponse( jsonObj.toString(), CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );
                classAttibutes.put( CreateGroupAPIConstants.GROUP_NAME, SMUtils.getKeyValueFromResponse( jsonObj.toString(), CreateGroupAPIConstants.GROUP_NAME ) );
                classAttibutes.put( getGroupListAPIConstants.STUDENT_COUNT, SMUtils.getKeyValueFromResponse( jsonObj.toString(), getGroupListAPIConstants.STUDENT_COUNT ) );
                groupDetailsSM.put( classAttibutes.get( CreateGroupAPIConstants.GROUP_ID ), classAttibutes );
                groupList.add( classAttibutes.get( CreateGroupAPIConstants.GROUP_ID ) );
            } );

            HashMap<String, HashMap<String, String>> groupDetailsCMS = new HashMap<>();
            IntStream.range( 0, expectedJsonArray.length() ).forEach( count -> {
                JSONObject jsonObj = expectedJsonArray.getJSONObject( count );
                String productDetails = SMUtils.getKeyValueFromResponse( jsonObj.getJSONObject( Constants.DATA ).getJSONObject( RBSDataSetupConstants.SECTION ).getJSONObject( Constants.DATA ).toString(), "sectionProductsAssociationList" );
                if ( productDetails.contains( "successmaker" ) ) {
                    HashMap<String, String> classAttibutes = new HashMap<>();
                    JSONObject firstLevel = jsonObj.getJSONObject( Constants.DATA ).getJSONObject( RBSDataSetupConstants.SECTION ).getJSONObject( Constants.DATA ).getJSONObject( "sectionInfo" );
                    if ( firstLevel.get( RBSDataSetupConstants.ORGANIZATION_ID ).toString().equalsIgnoreCase( schooId ) ) {

                        JSONArray secondLevel = jsonObj.getJSONObject( Constants.DATA ).getJSONObject( RBSDataSetupConstants.SECTION ).getJSONObject( Constants.DATA ).getJSONObject( "sectionInfo" ).getJSONArray( "staff" );

                        IntStream.range( 0, secondLevel.length() ).forEach( child -> {

                            if ( secondLevel.get( child ).toString().contains( teacherId ) ) {
                                JSONArray students = new JSONArray( jsonObj.getJSONObject( Constants.DATA ).getJSONObject( RBSDataSetupConstants.SECTION ).getJSONObject( Constants.DATA ).getJSONObject( "sectionInfo" ).getJSONArray( "students" ) );
                                Integer studentCount = students.length();
                                classAttibutes.put( CreateGroupAPIConstants.GROUP_ID, jsonObj.getJSONObject( Constants.DATA ).getJSONObject( RBSDataSetupConstants.SECTION ).get( "id" ).toString() );
                                classAttibutes.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, firstLevel.get( RBSDataSetupConstants.ORGANIZATION_ID ).toString() );
                                classAttibutes.put( CreateGroupAPIConstants.GROUP_NAME, firstLevel.get( RBSDataSetupConstants.SECTION_NAME ).toString() );
                                classAttibutes.put( getGroupListAPIConstants.STUDENT_COUNT, studentCount.toString() );
                                groupDetailsCMS.put( classAttibutes.get( CreateGroupAPIConstants.GROUP_ID ), classAttibutes );
                            }

                        } );

                    }
                }
            } );

            if ( groupDetailsCMS.keySet().equals( groupDetailsSM.keySet() ) ) {
                isVerified = true;
            } else {
                Log.fail( "Actual data - " + groupDetailsSM + "Expected Data - " + groupDetailsCMS );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isVerified;

    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) {
        boolean isVerified = false;

        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }
}
