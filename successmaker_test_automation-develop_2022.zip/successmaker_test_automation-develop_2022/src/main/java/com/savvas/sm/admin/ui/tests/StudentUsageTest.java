package com.savvas.sm.admin.ui.tests;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants.Dashboard;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class StudentUsageTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify the Student Usage in admin dashboard", groups = { "SMK-52245", "adminDashboard", "studentUsage" }, priority = 1 )
    public void tcSMStudentUsage001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMStudentUsage001: Verify the Student Usage in admin dashboard. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify the headers of the student usage chart in admin dashboard." );
            Log.assertThat( dashBoardPage.verifyCardHeaderIsPresent( Dashboard.ORGANIZATION_USAGE ), "Organization Usage header is present in dashboard page", "Organization Usage header is not present in dashboard page" );
            Log.assertThat( dashBoardPage.verifyStudentUsageBtnIsSelected(), "Student Usage button is selected as default", "Student Usage button is not selected as default" );
            Log.assertThat( dashBoardPage.getStudentUsageHeader().equals( Dashboard.STUDENT_AVERAGES ), "Student Averages header is present under Student Usage", "Student Averages header is present under Student Usage" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the legends in student usage chart in admin dashboard." );
            Log.assertThat( dashBoardPage.getStudentUsageLegends().containsAll( Constants.Reports.SUBJECTS ), "Legends are present in Student Usage", "Legends are present in Student Usage" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the student average fields in student usage chart in admin dashboard." );
            Log.assertThat( dashBoardPage.getStudentAverageWeeks().containsAll( Dashboard.STUDENT_AVERAGE_WEEK_HEADERS ), "Week headers are present in Student Average", "Week headers are not present in Student Average" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify student usage chart if admin selected single organization in org dropdown." );
            //get organization from organizations dropdown
            List<String> organizations = dashBoardPage.getAllOrganizationsFromOrgDropdown();

            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( organizations.get( 0 ) ) );
            dashBoardPage.clickApplySelectionButton();
            Log.assertThat( dashBoardPage.isStudentChartPresent(), "Student usage chart is present if admin select single organization in org dropdown.", "Student usage chart is not present if admin select single organization in org dropdown." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the '# organizations selected' is displayed at the bottom of the card" );
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equals( organizations.get( 0 ) ), "Organization name is displayed when admin select single org", "Organization name is not displayed when admin select single org" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify student usage chart if admin selected multiple organization in org dropdown." );
            dashBoardPage.clickAllOptionsInOrganizationDropdown();
            dashBoardPage.selectOrganizationsFromOrgDropdown( Arrays.asList( organizations.get( 0 ), organizations.get( 1 ) ) );
            dashBoardPage.clickApplySelectionButton();
            Log.assertThat( dashBoardPage.isStudentChartPresent(), "Student usage chart is present if admin select multiple organization in org dropdown.", "Student usage chart is not present if admin select multiple organization in org dropdown." );
            Log.assertThat( dashBoardPage.getNoOfOrganizationSelectedText().equals( String.format( Dashboard.SELECTED_ORGANIZATIONS_COUNT, 2 ) ), "Organization name is displayed when admin select multiple org",
                    "Organization name is not displayed when admin select multiple org" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if school admin associated with multiple school.", groups = { "SMK-52245", "adminDashboard", "studentUsage" }, priority = 1 )
    public void tcSMStudentUsage002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMStudentUsage002: Verify Student usage chart if school admin associated with multiple school.. <small><b><i>[" + browser + "]</b></i></small>" );
        username = RBSDataSetup.adminUserNames.get( Admins.MULTI_SCHOOL_ADMIN );

        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify Student usage chart if school admin associated with multiple school." );
            Log.assertThat( dashBoardPage.verifyCardHeaderIsPresent( Dashboard.ORGANIZATION_USAGE ) && dashBoardPage.verifyStudentUsageBtnIsSelected() && dashBoardPage.getStudentUsageHeader().equals( Dashboard.STUDENT_AVERAGES )
                    && dashBoardPage.isStudentChartPresent(), "Student Usage details are displayed for school admin associated with multiple school", "Student Usage details are not displayed for school admin associated with multiple school" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the x-axis label in student usage in admin dashboard." );
            SMUtils.logDescriptionTC( "Verify the y-axis labels in student usage in admin dashboard." );
            SMUtils.logDescriptionTC( "Verify the y-axis intervals in student usage in admin dashboard." );
            Log.assertThat( dashBoardPage.getWeeksAndHoursHeader().containsAll( Dashboard.X_AND_Y_AXIS_HEADERS ), "X and Y axis headers are displayed in Student Usage chart", "X and Y axis headers are not displayed in Student Usage chart" );
            Log.assertThat( dashBoardPage.isWeeksAndHoursLblPresent(), "X and Y axis values are displayed in Student Usage chart", "X and Y axis values are not displayed in Student Usage chart" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify when hovering the mouse over each week chart the total time spent for the assignment is shown" );
            Log.assertThat( dashBoardPage.isStudentUsageTooltipDiaplayed(), "Student Usage tooltip is displayed in Student Usage chart", "Student Usage tooltip is not displayed in Student Usage chart" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if school admin associated with one school.", groups = { "SMK-52245", "adminDashboard", "studentUsage" }, priority = 1 )
    public void tcSMStudentUsage003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMStudentUsage003: Verify Student usage chart if school admin associated with one school. <small><b><i>[" + browser + "]</b></i></small>" );
        username = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );

        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify Student usage chart if school admin associated with one school." );
            Log.assertThat( dashBoardPage.verifyCardHeaderIsPresent( Dashboard.ORGANIZATION_USAGE ) && dashBoardPage.verifyStudentUsageBtnIsSelected() && dashBoardPage.getStudentUsageHeader().equals( Dashboard.STUDENT_AVERAGES )
                    && dashBoardPage.isStudentChartPresent(), "Student Usage details are displayed for school admin associated with one school", "Student Usage details are not displayed for school admin associated with one school" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the chart columns for each week which shows reading at the bottom and math at the top" );
            Log.assertThat( dashBoardPage.verifyMathAndReadingColor(), "Color code for math and reading are same as exceoted", "Color code for math and reading are not same as exceoted" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student usage chart if sub-district admin associated with subdistrict.", groups = { "SMK-52245", "adminDashboard", "studentUsage" }, priority = 1 )
    public void tcSMStudentUsage004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMStudentUsage003: Verify Student usage chart if sub-district admin associated with subdistrict. <small><b><i>[" + browser + "]</b></i></small>" );
        username = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );

        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            SMUtils.logDescriptionTC( "Verify Student usage chart if school admin associated with one school." );
            Log.assertThat( dashBoardPage.verifyCardHeaderIsPresent( Dashboard.ORGANIZATION_USAGE ) && dashBoardPage.verifyStudentUsageBtnIsSelected() && dashBoardPage.getStudentUsageHeader().equals( Dashboard.STUDENT_AVERAGES )
                    && dashBoardPage.isStudentChartPresent(), "Student Usage details are displayed for sub-district admin associated with one school", "Student Usage details are not displayed for sub-district admin associated with one school" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
