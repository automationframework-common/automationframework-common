package com.savvas.sm.api.tests.smnew.users;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.StopWatch;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.GetGroupListAPI;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.getGradeListConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.UpdateStudentProfileConstants;

/**
 * To test the Grade list
 * 
 * @author suriya.kumar
 */

public class GetGradeListAPITest extends UserAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String classId = null;
    String className = null;

    // Teacher variable used for this class

    private String teacherUsed;
    private String orgId;
    private String teacherId;
    private String username;

    // other school constants
    private String readingSchoolId;
    private String readingSchoolTeacherId;
    private String readingSchoolTeacherUsername;

    // Second Teacher
    private String secondTeacherId;
    private String secondTeacherUsername;

    //Student that is updated
    String updatedStudentId;
    String updatedStudentUsename;

    // Object 
    AtomicReference<String> readingSchool = new AtomicReference<String>();
    AtomicReference<String> schoolUsed = new AtomicReference<String>();
    private long startTime;
    private ArrayList<String> studentIdList;
    private ArrayList<String> studentUserNames;
    GroupAPI groupApi = new GroupAPI();
    private ArrayList<String> teacherGroupNames;
    private ArrayList<String> teacherGroupId;

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() {

        startTime = StopWatch.startTime();
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        // Teacher used Details
        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        orgId = RBSDataSetup.organizationIDs.get( schoolUsed.get() );

        String teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        // Getting student details for the Teacher
        ArrayList<String> studentDetails = new ArrayList<String>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<String>();
        studentUserNames = new ArrayList<String>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

        // Getting GroupId of the Teacher
        HashMap<String, String> response = new HashMap<String, String>();
        HashMap<String, String> apiDetails = new HashMap<String, String>();
        try {
            String accessToken = new RBSUtils().getAccessToken( username, password );
            apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
            apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            apiDetails.put( GroupConstants.STAFF_ID, teacherId );
            response = groupApi.getGroupListingForTeacherID( smUrl, apiDetails );
            Log.message( "GroupListing respone: " + response.toString() );

            JSONObject jsonObject = new JSONObject( response.get( Constants.REPORT_BODY ) );
            JSONArray array = jsonObject.getJSONArray( CreateGroupAPIConstants.DATA );

            teacherGroupNames = new ArrayList<String>();
            teacherGroupId = new ArrayList<String>();

            IntStream.range( 0, array.length() ).forEach( iter -> {
                String eachObject = array.getJSONObject( iter ).toString();
                teacherGroupNames.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_NAME ) );
                teacherGroupId.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_ID ) );
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        // Second Teacher for Data Setup purposes
        secondTeacherUsername = "teacher1654573526769" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        String teacherdetailsCreate = null;
        try {
            if ( !new RBSUtils().isUserExits( secondTeacherUsername, orgId ) ) {
                teacherdetailsCreate = new UserAPI().createUserWithCustomization( secondTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
            }
            secondTeacherId = new RBSUtils().getUserIDByUserName( secondTeacherUsername );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        // Other School Details
        readingSchool.set( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) );
        readingSchoolId = RBSDataSetup.organizationIDs.get( readingSchool.get() );

        //teacher create       
        readingSchoolTeacherUsername = "teacher1654573712481" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        readingSchoolTeacherId = null;
        try {
            if ( !new RBSUtils().isUserExits( readingSchoolTeacherUsername, readingSchoolId ) ) {
                teacherdetailsCreate = new UserAPI().createUserWithCustomization( readingSchoolTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( readingSchoolId ) );
            }
            readingSchoolTeacherId = new RBSUtils().getUserIDByUserName( readingSchoolTeacherUsername );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }
    }

    @AfterClass
    public void enofExecution() {
        long totalTime = StopWatch.elapsedTime( startTime );
        long sec = totalTime % 60;
        long min = ( totalTime / 60 ) % 60;
        Log.message( "=====================================================" );
        Log.message( " Student Listing class ran for: " + min + " minute (s)" + ":" + sec + " seconds (s)" );
    }

    @Test ( priority = 1, description = "Valid with all Data", groups = { "smoke_test_case", "Smoke_tcGet_GradeList_01", "SMK-52001", "Students", "StudentDetailsForStudentId", "API" } )
    public void tcGet_GradeList_01() throws Exception {

        String accessToken = new RBSUtils().getAccessToken( username, password );
        String groupName = "Group_" + System.nanoTime();

        // Student Creation
        String studentName = "student" + System.nanoTime();
        String studentId = createStudentAndResetPassword( orgId, studentName );

        // Enrolling student into the class
        classId = createGroup( groupName, teacherId, Arrays.asList( studentId ), orgId, accessToken );

        //Hitting api

        HashMap<String, String> response = null;

        // InputParams
        HashMap<String, String> params = new HashMap<>();

        // headers
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
        headers.put( UserConstants.StudentDetailsForGivenTeacherConstants.user_id_TEXT, teacherId );
        headers.put( UserConstants.StudentDetailsForGivenTeacherConstants.ORG_ID, orgId );

        // Endpoints
        String endPoint = getGradeListConstants.endpoint;

        try {
            response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
        } catch ( Exception e ) {
            Log.message( response.toString() );
            e.printStackTrace();
        }

        ArrayList<String> Grade_Names = new SMAPIProcessor().getKeyValues( new JSONObject( response.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ), getGradeListConstants.GRADE_NAME );
        ArrayList<String> Grade_values = new SMAPIProcessor().getKeyValues( new JSONObject( response.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ), getGradeListConstants.GRADE_VALUE );

        ArrayList<String> expGradeNames = new ArrayList<String>( Arrays.asList( "Grade K", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12", "Not Specified" ) );

        // verifying API 

        Log.assertThat( response.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.STATUS_CODE_STRING ).equals( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.STATUS_CODE_200 ), "The response code Matches!",
                "The response code doesnot Matches" );
        Log.assertThat(
                new SMAPIProcessor().getKeyValues( new JSONObject( response.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ), StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.MESSAGE_STRING ).get( 0 ).equals(
                        "Operation succeeded!" ),
                "The success message matches!", "The success message doesnot matches" );
        Log.assertThat( new SMUtils().compareTwoList( expGradeNames, Grade_Names ), "The grade Name  value matching", "The grade name values is not matching" );
        Log.assertThat( new SMUtils().compareTwoList( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.GRADE_NAME, Grade_values ), "The grade value is matching", "The grade values is not matching" );

        // update Details
        Faker randomName = new Faker( new Locale( "en-IN" ) );
        String orgIdToTest = orgId;
        String accessTokenToTest = accessToken;

        HashMap<String, String> userDetails = new HashMap<String, String>();

        userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );

        userDetails.put( UserConstants.SCHOOLID, orgId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, studentId );

        userDetails.put( UserConstants.UpdateStudentProfileConstants.TEACHERID_REQBODY, teacherId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.USERNAME_REQBODY, studentName );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.USERPASSWORD_REQBODY, RBSDataSetupConstants.DEFAULT_PASSWORD );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.PERSONID_REQBODY, studentId );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.FIRSTNAME_REQBODY, randomName.name().firstName() );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.MIDDLENAME_REQBODY, randomName.name().name() );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.LASTNAME_REQBODY, randomName.name().lastName() );

        userDetails.put( UserConstants.UpdateStudentProfileConstants.BIRTHDAY_REQBODY, "1994-02-12" );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_IDENTIFICATION_NUMBER_REQBODY, "Id" + studentId );

        userDetails.put( UserConstants.UpdateStudentProfileConstants.GRADE_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.GENDER_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.SPECIAL_SERVICES_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ECONONMIC_DISADVANTAGED_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_ENGLISH_PROFICIENCY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.HAS_DISABILITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.ISMIGRANT_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        userDetails.put( UserConstants.UpdateStudentProfileConstants.ETHINICITY_REQBODY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );

        // Each Grade update 
        Grade_values.forEach( value -> {
            Log.message( "Verifying with the value '" + value + "'" );
            HashMap<String, String> data = new HashMap<String, String>( userDetails );
            data.replace( UserConstants.UpdateStudentProfileConstants.GRADE_REQBODY, value );
            Log.assertThat( new SMAPIProcessor().getKeyValues( new JSONObject( updateStudentProfile( smUrl, data ).get( Constants.BODY ) ), UpdateStudentProfileConstants.GRADE_REQBODY ).get( 0 ).equals( value ), "The Grade value is matches",
                    "The Grade value is not matches" );
        } );
    }

    public String createGroup( String groupName, String teacherId, List<String> studentRumbaIds, String orgId, String access_Token ) {
        HashMap<String, String> groupDetails = new HashMap<String, String>();
        HashMap<String, String> groupDetail = null;
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, access_Token );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
        try {
            groupDetail = groupApi.createGroup( smUrl, groupDetails, studentRumbaIds );
        } catch ( Exception e ) {}

        return new SMAPIProcessor().getKeyValues( new JSONObject( groupDetail.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ), StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );

    }
}
