package com.savvas.sm.ui.tests.smnew.Mastery;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasterySummaryComponent;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class AssignmentMasteryTest extends BaseTest {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    String assignment = null;

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = MasteryDataSetup.teacherUserName;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        assignment = MasteryDataSetup.math_Assignment;

    }

    @Test ( priority = 1, groups = { "SMK-56721", "assignments", "Assignments-Mastery" } )
    public void tcAssignmentMastery001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcAssignmentMastery001: Verify the zero state message displayed when No students have taken the assignment or they have not been assessed any of the skills in the assignment. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "TC:01- Verify the zero state message displayed when No students have taken the assignment or they have not been assessed any of the skills in the assignment." );

            // navigate to Assignment page
            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName( assignment );

            // Navigate to Mastery sub-tab
            assignmentDetailsPage.clickMasteryToggleButton();

            // Verify zero state message for student usage chart
            Log.assertThat( assignmentDetailsPage.verifyMasteryZeroState(), "Zero state message is displayed sucessfully for mastery!", "Zero state message is displayed sucessfully for mastery!" );

            // signOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-56721", "assignments", "Assignments-Mastery" } )
    public void tcAssignmentMastery002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcAssignmentMastery002: Verify Mastery tab in assignment details page. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // login to the app
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // navigate to Assignment page
            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName( assignment );

            SMUtils.logDescriptionTC( "TC:02 - Verify the teacher can able to view the mastery tab of that particular assignment." );
            Log.assertThat( assignmentDetailsPage.getMasteryToggleButton().contains( Constants.MASTERY ), "Mastery tab is present for the viewed assignment", "Mastery tab is not present for the viewed assignment" );
            SMUtils.logDescriptionTC( "TC:03 - Verify the teacher can able to click the mastery tab of that particular assignment." );
            SMUtils.logDescriptionTC( "TC:04 - Verify the teacher can able to navigate to the mastery tab page of that particular assignment." );

            // Navigate to Mastery sub-tab
            assignmentDetailsPage.clickMasteryToggleButton();

            SMUtils.logDescriptionTC( "TC:05 - Verify the Teacher can view the assignment name on the assignment display page." );
            Log.assertThat( assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals( assignment ), "Assignment name is displayed in the assignment details page", "Assignment name is not displayed in the assignment details page" );
            SMUtils.logDescriptionTC( "TC:06 - Verify the teacher can able to view the assessed objectives legends ( Mastered, At Risk, Not Mastered, Unassessed ) of that particular assignment." );
            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );
            Log.assertThat( masteryComponent.getAssessedObjectivesHeaders(), "Assessed objectives are present", "Assessed objectives are not present" );
            SMUtils.logDescriptionTC( "TC:07 - Verify the grade is displayed under mastery tab in the assignment page." );
            Log.assertThat( masteryComponent.verifyGradeIsDisplayed(), "Grade is displayed under mastery tab in the assignment page", "Grade is not displayed under mastery tab in the assignment page" );

            // signOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( priority = 1, groups = { "SMK-56721", "assignments", "Assignments-Mastery" } )
    public void tcAssignmentMastery003() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcAssignmentMastery003: Verify the count of students assessed for the corresponding LO under mastery tab of that particular assignment. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // login to the app
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );
            // navigate to Assignment page
            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName( assignment );
            SMUtils.logDescriptionTC( "TC:08- Verify the teacher is able to see the count of students assessed for the corresponding LO under mastery tab of that particular assignment" );
            SMUtils.logDescriptionTC( "TC:09- Verify the text displayed as #Student Assessments above the progress bar if more than one student has taken assessment corresponding to the LO only" );

            // Navigate to Mastery sub-tab
            assignmentDetailsPage.clickMasteryToggleButton();
            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );

            SMUtils.logDescriptionTC( "TC:10 - Verify the teacher able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only" );
            Log.assertThat( masterySummaryComponent.getStudentAssessmentOfLeafNodeLO().stream().allMatch( studentCount -> !studentCount.isEmpty() ),
                    "The teacher is able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only",
                    "The teacher is not able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO" );
            SMUtils.logDescriptionTC( "TC:11 - Verify the text displayed as Numbers Student Assessments above the progress bar if more than one student has taken assessment corresponding to the LO only" );
            String singleStudentAssessCount = Constants.MasteryUI.STUDENT_ASSESSMENT_COUNT.replace( "studentCount ", "" );
            String multiStudentAssessCount = Constants.MasteryUI.STUDENT_ASSESSMENTS_COUNT.replace( "studentCount ", "" );

            Log.assertThat( masterySummaryComponent.getStudentAssessmentOfLeafNodeLO().stream().allMatch( list -> list.endsWith( singleStudentAssessCount ) || list.endsWith( multiStudentAssessCount ) ),
                    "Student assessed count is displayed if one or more student has taken an assessment", "Student assessed count is not displayed if one or more student has taken an assessment" );

            // signOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( priority = 1, groups = { "SMK-56721", "assignments", "Assignments-Mastery" } )
    public void tcAssignmentMastery004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcAssignmentMastery004: Verify Skills/Standards dropdown functionality. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );
            // navigate to Assignment page
            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName( assignment );

            // Navigate to Mastery sub-tab
            assignmentDetailsPage.clickMasteryToggleButton();
            MasteryFiltersComponent masteryPage = new MasteryFiltersComponent( driver );
            SMUtils.logDescriptionTC( "TC:12 Verify the skills/standard dropdown is present und" );
            Log.assertThat( masteryPage.isSkillsStandardsDropdownPresent(), "Skills/Standards dropdown is present under assignment details page", "Skills/Standards dropdown is not present under assignment details page" );
            SMUtils.logDescriptionTC( "TC:13 Verify teacher able to see Skills/Standards dropdown options clearly (without overlap or data missing)" );
            Log.assertThat(
                    masteryPage.getAllSkillStandardsDropDownValues().stream().map( String::toLowerCase ).collect( Collectors.toList() ).containsAll( Constants.MATH_SKILLS_DROPDOWN_LIST.stream().map( String::toLowerCase ).collect( Collectors.toList() ) ),
                    "All skills are present in Skills/Standards dropdown", "All skills are not present in Skills/Standards dropdown" );
            SMUtils.logDescriptionTC( "TC:14 - Verify the skills/standard dropdown can be modified in the assignment details page" );
            SMUtils.logDescriptionTC( "TC:15 - Verify the correct details is displayed based on the skills/standard dropdown selection in the assignment details page" );
            teacherHomePage.topNavBar.navigateToAssignmentsPage();
            assignmentPage.viewAssignmentDetailsByAssignmentName( assignment );
            assignmentDetailsPage.clickMasteryToggleButton();
            masteryPage.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 0 ) );
            Log.assertThat( masteryPage.getSelectedValueFromSkillStandardsDropDown().equalsIgnoreCase( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 0 ) ), "Selected Skills/Standards name is displayed in Skills/Standards dropdown",
                    "Selected Skills/Standards name is not displayed in Skills/Standards dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-56721", "assignments", "Assignments-Mastery" } )
    public void tcAssignmentMastery005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcAssignmentMastery005: Verify the functionality of LO in mastery tab of assignment detail page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // login to the app
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // navigate to Assignment page
            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName( assignment );

            // Navigate to Mastery sub-tab
            assignmentDetailsPage.clickMasteryToggleButton();
            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );
            SMUtils.logDescriptionTC( "TC:16 - Verify the teacher is able to see the LO as a blue link for math related assignments under mastery tab of the assignments page" );
            Log.assertThat( masteryComponent.verifyLOColor( browser ), "Teacher is able to see the LO as a blue link", "Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills" );
            SMUtils.logDescriptionTC( "TC:17 - Verify the teacher is able to see the LO description corrsponding to the LO id for math related assignments under mastery tab of that particular assignment" );
            Log.assertThat( masteryComponent.getLeafNodeContent().stream().allMatch( loDescription -> !loDescription.isEmpty() ), "LO description is displayed for math related assignments ",
                    "LO description is not displayed for math related assignments " );
            SMUtils.logDescriptionTC( "TC:18 - Verify the skill heading is displayed under domain and cluster in mastery tab of the assignment page" );
            Log.assertThat( masteryComponent.verifySkillHeadingIsDisplayed(), "Skill heading is displayed under domain and cluster in mastery tab of the assignment page",
                    "Skill heading is not displayed under domain and cluster in mastery tab of the assignment page" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-56721", "assignments", "Assignments-Mastery" } )
    public void tcAssignmentMastery006() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcAssignmentMastery006: Verify Mastery status colour indicator order in the progress bar. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // login to the app
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // navigate to Assignment page
            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName( assignment );
            // Navigate to Mastery sub-tab
            assignmentDetailsPage.clickMasteryToggleButton();
            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );
            SMUtils.logDescriptionTC( "TC:19 - Verify the progress bar, 'Mastered' status is indicated by Green color" );
            Log.assertThat( masteryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.MASTERED_COLOR_CODE.toLowerCase() ), "Mastered status is indicated by Green color in the progress bar ",
                    "Mastered status is not indicated by Green color in the progress bar " );
            SMUtils.logDescriptionTC( "TC:20 - Verify the progress bar, 'At Risk' status is indicated by Yellow color" );
            Log.assertThat( masteryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.ATRISK_COLOR_CODE.toLowerCase() ), "At Risk status is indicated by Yellow color in the progress bar ",
                    "At Risk status is not indicated by Yellow color in the progress bar " );
            SMUtils.logDescriptionTC( "TC:21 - Verify the progress bar, total number of students 'Mastered'/Not Mastered/At Risk with respect to that skill is displaying inside Green/Yellow/red colour." );
            Log.assertThat( masteryComponent.getStudentAssessmentOfLeafNodeLO().containsAll( masteryComponent.getStudentAssessmentCount() ), "Total number of student assessment is displayed in progress bar",
                    "Total number of student assessment is not displayed in progress bar" );

            // signOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-56721", "assignments", "Assignments-Mastery" } )
    public void tcAssignmentMastery007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcAssignmentMastery007: Verify total number of the students assessement taken is equal to the sum of 'Mastered', 'At Risk' and 'Not Mastered' students <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            // navigate to Assignment page
            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName( assignment );
            // Navigate to Mastery sub-tab
            assignmentDetailsPage.clickMasteryToggleButton();
            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );
            List<WebElement> masteredProgressBars = masteryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );
            SMUtils.nap( 3 );
            List<String> studentAssement = masteryComponent.getStudentAssessmentOfLeafNodeLO();
            List<String> listassesmentcount = masteryComponent.getStudentAssessmentCount();
            SMUtils.logDescriptionTC( "TC:22 - Verify total number of the students assessement taken is equal to the sum of 'Mastered', 'At Risk' and 'Not Mastered' students " );
            Log.assertThat( studentAssement.equals( listassesmentcount ),
                    "The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar ",
                    " The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is not matching with TOTAL count of students have taken assessment displayed above the progress bar" );
            // Sign Out
            // signOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}