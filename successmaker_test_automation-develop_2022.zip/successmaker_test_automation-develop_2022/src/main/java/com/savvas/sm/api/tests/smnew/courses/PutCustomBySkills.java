package com.savvas.sm.api.tests.smnew.courses;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * This class is used to test the PUT API for Custom Course by Skill
 *
 * @author Subbu
 */

public class PutCustomBySkills extends CourseAPI {
	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	private final String orgUsed = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	String smUrl;
	String teacherUsed;
	String username;
	String accessCode;
	RBSUtils rbsutils = new RBSUtils();
	String createcourseId = null;
	Map<String, String> response = null;
	String orgId;
	String teacherId;
	String endpoint;
	HashMap<String, String> mathGradeSkillDetails = new HashMap<String, String>();
	HashMap<String, String> readingGradeSkillDetails = new HashMap<String, String>();

	@BeforeClass(alwaysRun = true)
	public void InitializedSchoolData() throws IOException {

		smUrl = configProperty.getProperty("SMAppUrl");
		orgId = RBSDataSetup.organizationIDs.get(orgUsed);
		teacherUsed = RBSDataSetup.getMyTeacher(orgUsed);
		JSONObject teacherJson = new JSONObject(teacherUsed);
		teacherId = new SMAPIProcessor().getKeyValues(teacherJson, RBSDataSetupConstants.USERID).get(0);
		username = new SMAPIProcessor().getKeyValues(teacherJson, RBSDataSetupConstants.USERNAME).get(0);

		// To get Random Standard ID's for Math and Reading Courses
		mathGradeSkillDetails = SqlHelperCourses.getSCOIDsOfRandomSkillID(Constants.MATH);
		while( readingGradeSkillDetails.get("LOName")==null || readingGradeSkillDetails.get("LOName").isEmpty() || readingGradeSkillDetails.get("LOName").startsWith("_") ) {
        	readingGradeSkillDetails = SqlHelperCourses.getSCOIDsOfRandomSkillID(Constants.READING); 
        	}

	}

	@Test(dataProvider = "UpdateCustomCourseBySkillPositiveScenarios", groups = { "SMK-52087",
			"Update Custom Course By Skill", "Course", "P1", "API", "smoke_test_case" })
	public void updateCustomCourseBySkillPositiveScenarios(String description, String scenario, String statusCode,
			String gradeId, String courseId, String parentNode, String ChildNode, String status, String message)
			throws Exception {
		Log.testCaseInfo(description);

		Map<String, String> courseDetails = new HashMap<>();
		Map<String, String> headers = new HashMap<>();
		Map<String, String> apiResponse = new HashMap<>();
		// Authorization
		accessCode = rbsutils.getAccessToken(
				SMUtils.getKeyValueFromResponse(teacherUsed, RBSDataSetupConstants.USERNAME),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.AUTHORIZATION, "Bearer " + accessCode);
		headers.put(Constants.ORGID_SM_HEADER, orgId);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		courseDetails.put(Constants.GRADE_VALUE, gradeId);
		courseDetails.put(Constants.CONTENT_BASE_ID_ENDPOINT, CourseAPIConstants.STRING_THREE);
		courseDetails.put(CourseAPIConstants.COURSE_ID, courseId);
		courseDetails.put(CourseAPIConstants.PARENT_NODE, parentNode);
		courseDetails.put(CourseAPIConstants.CHILD_NODE, ChildNode);
		courseDetails.put(Constants.COURSE_NAME, "Skills" + System.nanoTime());
		response = createCourseBySkill(smUrl, headers, courseDetails, scenario);
		Log.message("response from POST Call - " + response);
		createcourseId = SMUtils.getKeyValueFromResponse(response.get(Constants.REPORT_BODY), "data,id");
		Log.message("createcourseId=" + createcourseId);
		HashMap<String, String> apiResponseGetSettings = new HashMap<>();
		HashMap<String, String> courseSettings = new HashMap<>();
		courseSettings.put(CourseAPIConstants.ORG_ID, orgId);
		courseSettings.put(CourseAPIConstants.TEACHER_ID, teacherId);
		courseSettings.put(RBSDataSetupConstants.BEARER_TOKEN, accessCode);
		apiResponseGetSettings = getCoursesSettings(smUrl, courseSettings, "false", createcourseId);
		Log.message("Get Settings : " + apiResponseGetSettings);
		JSONObject postResp = SMUtils.convertResponseAsJsonObj(
				apiResponseGetSettings.get(Constants.REPORT_BODY).toString(), Constants.REPORT_BODY_DATA, null, null,
				null);
		JSONObject data2 = postResp.getJSONObject("SESSION_LENGTH");
		String sessionLengthName = data2.getString("name");
		Long sessionLengthId = data2.getLong("id");
		String sessionLengthValue = data2.getString("currentValue");
		String idleTimeId1 = SMUtils.getKeyValueFromResponse(apiResponseGetSettings.get(Constants.REPORT_BODY),
				"data,IDLE_TIME,id");
		String idleTimeName1 = SMUtils.getKeyValueFromResponse(apiResponseGetSettings.get(Constants.REPORT_BODY),
				"data,IDLE_TIME,name");
		String idleTimeValue1 = SMUtils.getKeyValueFromResponse(apiResponseGetSettings.get(Constants.REPORT_BODY),
				"data,IDLE_TIME,currentValue");
		JSONObject data3 = postResp.getJSONObject("IDLE_TIME");
		String idleTimeName = data3.getString("name");
		Long idleTimeId = data3.getLong("id");
		String idleTimeValue = data3.getString("currentValue");
		courseSettings.put(CourseAPIConstants.COURSE_ID, createcourseId);
		courseSettings.put(Constants.GRADE_VALUE, gradeId);
		courseSettings.put(CourseAPIConstants.PARENT_NODE, parentNode);
		courseSettings.put(CourseAPIConstants.CHILD_NODE, ChildNode);
		courseSettings.put(Constants.COURSE_NAME, "Skills" + System.nanoTime());
		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf(sessionLengthId));
		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName);
		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
		courseSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
		courseSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
		courseSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue);
		apiResponse = updateCourseBySkill(smUrl, headers, courseDetails, courseSettings, scenario);
		Log.message("response from Put Custom Course Update by Skill - " + apiResponse);
		// Assertion
		verifyResponse(apiResponse, message, statusCode);
		Log.testCaseResult();
	}

	@Test(dataProvider = "UpdateCustomCourseBySkillNegativeScenarios", groups = { "SMK-52087",
			"Update Custom Course By Skill", "Course", "P1", "API" })
	public void updateCustomCourseBySkillNegativeScenarios(String description, String scenario, String statusCode,
			String gradeId, String courseId, String parentNode, String ChildNode, String status, String message)
			throws Exception {
		Log.testCaseInfo(description);

		Map<String, String> courseDetails = new HashMap<>();
		Map<String, String> headers = new HashMap<>();
		Map<String, String> apiResponse = new HashMap<>();

		// Authorization
		accessCode = rbsutils.getAccessToken(
				SMUtils.getKeyValueFromResponse(teacherUsed, RBSDataSetupConstants.USERNAME),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.AUTHORIZATION, "Bearer " + accessCode);
		headers.put(Constants.ORGID_SM_HEADER, orgId);
		headers.put(Constants.USERID_SM_HEADER, teacherId);
		courseDetails.put(Constants.GRADE_VALUE, gradeId);
		courseDetails.put(Constants.CONTENT_BASE_ID_ENDPOINT, CourseAPIConstants.STRING_THREE);
		courseDetails.put(CourseAPIConstants.COURSE_ID, courseId);
		courseDetails.put(CourseAPIConstants.PARENT_NODE, parentNode);
		courseDetails.put(CourseAPIConstants.CHILD_NODE, ChildNode);
		courseDetails.put(Constants.COURSE_NAME, "Skills" + System.nanoTime());

		if (scenario.contains("MATHSTANDARD")) {
			courseDetails.put(Constants.STANDARD_FRAMEWORK_VALUE, "504");
			response = createCourseByStandard(smUrl, headers, courseDetails, scenario);

		} else {
			response = createCourseBySkill(smUrl, headers, courseDetails, scenario);
		}
		Log.message("response from POST Call - " + response);
		createcourseId = SMUtils.getKeyValueFromResponse(response.get(Constants.REPORT_BODY), "data,id");
		Log.message("createcourseId=" + createcourseId);
		HashMap<String, String> apiResponseGetSettings = new HashMap<>();
		HashMap<String, String> courseSettings = new HashMap<>();
		courseSettings.put(CourseAPIConstants.ORG_ID, orgId);
		courseSettings.put(CourseAPIConstants.TEACHER_ID, teacherId);
		courseSettings.put(RBSDataSetupConstants.BEARER_TOKEN, accessCode);
		apiResponseGetSettings = getCoursesSettings(smUrl, courseSettings, "false", createcourseId);
		Log.message("Get Settings : " + apiResponseGetSettings);
		JSONObject postResp = SMUtils.convertResponseAsJsonObj(
				apiResponseGetSettings.get(Constants.REPORT_BODY).toString(), Constants.REPORT_BODY_DATA, null, null,
				null);
		JSONObject data2 = postResp.getJSONObject("SESSION_LENGTH");
		String sessionLengthName = data2.getString("name");
		Long sessionLengthId = data2.getLong("id");
		String sessionLengthValue = data2.getString("currentValue");
		String idleTimeId1 = SMUtils.getKeyValueFromResponse(apiResponseGetSettings.get(Constants.REPORT_BODY),
				"data,IDLE_TIME,id");
		String idleTimeName1 = SMUtils.getKeyValueFromResponse(apiResponseGetSettings.get(Constants.REPORT_BODY),
				"data,IDLE_TIME,name");
		String idleTimeValue1 = SMUtils.getKeyValueFromResponse(apiResponseGetSettings.get(Constants.REPORT_BODY),
				"data,IDLE_TIME,currentValue");
		JSONObject data3 = postResp.getJSONObject("IDLE_TIME");
		String idleTimeName = data3.getString("name");
		Long idleTimeId = data3.getLong("id");
		String idleTimeValue = data3.getString("currentValue");
		courseSettings.put(CourseAPIConstants.COURSE_ID, createcourseId);
		courseSettings.put(Constants.GRADE_VALUE, gradeId);
		courseSettings.put(CourseAPIConstants.PARENT_NODE, parentNode);
		courseSettings.put(CourseAPIConstants.CHILD_NODE, ChildNode);
		courseSettings.put(Constants.COURSE_NAME, "Skills" + System.nanoTime());
		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf(sessionLengthId));
		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName);
		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
		courseSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
		courseSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
		courseSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue);

		if (scenario.equalsIgnoreCase("MATHINVALIDCOURSEID")) {
			courseSettings.put(CourseAPIConstants.COURSE_ID, CourseAPIConstants.INVALID_COURSE_ID);

		} else if (scenario.equalsIgnoreCase("NONEXISTINGDCOURSEID")) {
			courseSettings.put(CourseAPIConstants.COURSE_ID, CourseAPIConstants.NON_EXISTING_COURSE_ID);

		} else if (scenario.equalsIgnoreCase("INVALIDORG")) {
			headers.put(Constants.ORGID_SM_HEADER, CourseAPIConstants.NON_EXISTING_ORGANIZATION_ID);
		} else if (scenario.equalsIgnoreCase("DifferentOrg")) {
			headers.put(Constants.ORGID_SM_HEADER, CourseAPIConstants.DEFFERENT_ORGANIZATION_ID);
		} else if (scenario.equalsIgnoreCase("INVALIDSTAFF")) {
			headers.put(Constants.USERID_SM_HEADER, CourseAPIConstants.NON_EXISTING_STAFF_ID);
		} else if (scenario.equalsIgnoreCase("DifferentStaffId")) {
			headers.put(Constants.USERID_SM_HEADER, CourseAPIConstants.DIFFERENT_STAFF_ID);
		} else if (scenario.equalsIgnoreCase("InvalidAuthorization")) {
			headers.put(Constants.AUTHORIZATION, CourseAPIConstants.INVALID_AUTHORIZATION_ID);
		} else if (scenario.equalsIgnoreCase("INVALIDCONTENTBASETYPE")) {
			courseDetails.put(Constants.CONTENT_BASE_ID_ENDPOINT, CourseAPIConstants.INVALID_CONTENT_BASE_TYPE);
		} else if (scenario.equalsIgnoreCase("NULLCONTENTBASEID")) {
			courseDetails.put(Constants.CONTENT_BASE_ID_ENDPOINT, CourseAPIConstants.NULL);
		} else if (scenario.equalsIgnoreCase("NULLCOURSENAME")) {
			courseDetails.put(Constants.COURSE_NAME, "");
		} else if (scenario.equalsIgnoreCase("NUMERICENROLLMENTNAME")) {
			courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, CourseAPIConstants.STRING_NINE);
		} else if (scenario.equalsIgnoreCase("NULLENROLLMENTNAME")) {
			courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, CourseAPIConstants.NULL);
		} else if (scenario.equalsIgnoreCase("INVALIDENROLLMENTNAME")) {
			courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, CourseAPIConstants.INVALID);
		} else if (scenario.equalsIgnoreCase("INVALIDENROLLMENTID")) {
			courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, CourseAPIConstants.INVALID);
		} else if (scenario.equalsIgnoreCase("NULLENROLLMENTID")) {
			courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, CourseAPIConstants.NULL);
		} else if (scenario.equalsIgnoreCase("NONEXISTINGENROLLMENTID")) {
			courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, CourseAPIConstants.NON_EXISTING);
		} else if (scenario.equalsIgnoreCase("INVALIDENROLLMENTVALUE")) {
			courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, CourseAPIConstants.INVALID);
		} else if (scenario.equalsIgnoreCase("NULLENROLLMENTVALUE")) {
			courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, CourseAPIConstants.NULL);
		} else if (scenario.equalsIgnoreCase("MAXIMUMENROLLMENTVALUE")) {
			courseSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, CourseAPIConstants.STRING_NINE);
		} else if (scenario.equalsIgnoreCase("MINIMUMENROLLMENTVALUE")) {
			courseSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, CourseAPIConstants.STRING_ONE);
		} else if (scenario.equalsIgnoreCase("DEFAULTCOURSES")) {
			courseSettings.put(CourseAPIConstants.COURSE_ID, CourseAPIConstants.STRING_ONE);
		} else if (scenario.equalsIgnoreCase("FOCUSCOURSES")) {
			courseSettings.put(CourseAPIConstants.COURSE_ID, CourseAPIConstants.STRING_THREE);
		}
		switch (scenario) {
		case "InvalidURL":
			apiResponse = updateCourseBySkill(smUrl, headers, courseDetails, courseSettings, scenario);
			Log.message("response from Put Custom Course Update by Skill - " + apiResponse);
			// Assertion
			Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
					"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - "
							+ apiResponse.get(Constants.STATUS_CODE));
		default:
			apiResponse = updateCourseBySkill(smUrl, headers, courseDetails, courseSettings, scenario);
			Log.message("response from Put Custom Course Update by Skill - " + apiResponse);
			// Assertion

				Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
						"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
						"Status code is not returned as expected and the same is " + statusCode + " Actual - "
								+ apiResponse.get(Constants.STATUS_CODE));
			
		}
		Log.testCaseResult();
	}

	@DataProvider(name = "UpdateCustomCourseBySkillPositiveScenarios")
	public Object[][] UpdateCustomCoursevalidData() {
		Object[][] inputData = { {
				"TC_001 Verify the response is 200 and API will update the values of existing Math course of type Custom By Skill",
				"MATH", "200", mathGradeSkillDetails.get("GradeID"), "1", mathGradeSkillDetails.get("ParentNode"),
				mathGradeSkillDetails.get("LOName"), "success", "Course updated successfully" },
				{ "TC_002 Verify the response is 200 and API will update the values of existing Reading course of type Custom By Skill",
						"READING", "200", readingGradeSkillDetails.get("GradeID"), "2",
						readingGradeSkillDetails.get("ParentNode"), readingGradeSkillDetails.get("LOName"), "success",
						"Course updated successfully" }, };
		return inputData;
	}

	@DataProvider(name = "UpdateCustomCourseBySkillNegativeScenarios")
	public Object[][] UpdateCustomCourseInvalidData() {

		Object[][] inputData = { {
				"TC_004 Verify the response is 400 when we update the values of existing course of type Custom By Standards",
				"MATHSTANDARD", "400", "684", "2", "686", "smre_di_00128_686", "failure",
				"New Course type: 3 is different from custom source course type: 4" },
				{ "TC_006 Verify the status code is 400 when the invalid Course Id(@#/abc) is given",
						"MATHINVALIDCOURSEID", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"invalidcourseid" },
				{ "TC_007 Verify the status code is 200 when non existing Course Id(-999999) is given",
						"NONEXISTINGDCOURSEID", "200", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Course 10001 is not associated with given organization" },
				{ "TC_008 Verify the status code is 403 when the invalid organization Id(@#/abc) is given",
						"INVALIDORG", "403", "6", "1", "533", "SMMA_LO_01771_533", "success", "Access is denied" },
				{ "TC_009 Verify the status code is 400 when different organization Id(org 2) is given.",
						"DifferentOrg", "403", "6", "1", "533", "SMMA_LO_01771_533", "success", "Access is denied" },
				{ "TC_010 Verify the status code is 401 when the invalid staff Id(@#/abc) is given", "INVALIDSTAFF",
						"401", "6", "1", "533", "SMMA_LO_01771_533", "success", "Authentication Failed" },
				{ "TC_011 Verify the status code is 200 when different staff Id(teacher 2) is given.",
						"DifferentStaffId", "401", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Authentication Failed" },
				{ "TC_025 Verify the status code is 401 when the invalid authorization is given",
						"InvalidAuthorization", "401", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Authentication Failed" },
				{ "TC_026 Verify the status code is 404 when the invalid url is given", "InvalidURL", "404", "6", "1",
						"533", "SMMA_LO_01771_533", "success", "Authentication Failed" },

				{ "TC_012 Verify the response is 400 when we pass invalid data(@$/abc) for 'ContentBaseType' in request body",
						"INVALIDCONTENTBASETYPE", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"JSON parse error: Cannot deserialize value of type" },
				{ "TC_013 Verify the response is 400 when we pass value as Null for 'ContentBaseTypeID' and in request body",
						"NULLCONTENTBASEID", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"contentBaseTypeId can not be null" },
				{ "TC_014 Verify the response is 400 when we pass value as Null for 'New Course Name' and in request body' and in request body",
						"NULLCOURSENAME", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"A course with given courseName :null already exists.." },
				{ "TC_015 Verify the response is 400 when we pass numerical value for 'name' (enrollment option ) in request body",
						"NUMERICENROLLMENTNAME", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Name should be valid" },
				{ "TC_016 Verify the response is 400 when we pass value as Null for 'name' (enrollment option ) and in request body",
						"NULLENROLLMENTNAME", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Name should be valid" },
				{ "TC_017 Verify the response is 400 when we pass invalid data for 'name' (enrollment option ) and in request body.",
						"INVALIDENROLLMENTNAME", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Name should be valid" },
				{ "TC_018 Verify the response when is 400 we pass invalid value for setting id (enrollment option ) in request body",
						"INVALIDENROLLMENTID", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"JSON parse error: Cannot deserialize value of type" },
				{ "TC_019 Verify the response when we pass value as Null for setting id (enrollment option ) in request body",
						"NULLENROLLMENTID", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Id should not be null" },
				{ "TC_020 Verify the response when we pass non existing id for setting id (enrollment option ) in request body",
						"NONEXISTINGENROLLMENTID", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"JSON parse error: Cannot deserialize value of type" },
				{ "TC_021 Verify the response when we pass invalid data for \"current value\" (enrollment option ) in request body",
						"INVALIDENROLLMENTVALUE", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Value should be number for enrollment option :pst.enrollment_option.session_length" },
				{ "TC_022 Verify the response when we keep \"current value\" (enrollment option ) as a null in request body",
						"NULLENROLLMENTVALUE", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Value should be number for enrollment option :pst.enrollment_option.session_length" },
				{ "TC_023 Verify the response is 400 when we exceeding the limit of Max value in request body.Ex.Idle time",
						"MAXIMUMENROLLMENTVALUE", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Value is not in the range for enrollment option :pst.enrollment_option.idle_time" },
				{ "TC_024 Verify the response is 400 when we pass value below the limit of minimum value in request body.Ex.Idle time (min value=1)",
						"MINIMUMENROLLMENTVALUE", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Value is not in the range for enrollment option :pst.enrollment_option.idle_time" },

				{ "TC_028 Verify the response is 400 when we update the values of default courses", "DEFAULTCOURSES",
						"400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"Default course update not allowed for given id : 1 " },
				{ "TC_029 Verify the response is 400 when we update the values of existing course of focus courses.",
						"FOCUSCOURSES", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"SM focus course update not allowed for given id : " },
				{ "TC_029 Verify the response is 400 when we update the values of existing course of focus courses.",
						"FOCUSCOURSES", "400", "6", "1", "533", "SMMA_LO_01771_533", "success",
						"SM focus course update not allowed for given id : " }, };

		return inputData;
	}

	/**
	 * Get response for the Create Course By Skill API
	 *
	 * @param envUrl
	 * @param headers
	 * @param courseDetails
	 * @param scenario
	 * @return
	 */
	public Map<String, String> createCourseBySkill(String envUrl, Map<String, String> headers,
			Map<String, String> courseDetails, String scenario) {
		try {

			String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
			endpoint = endpoint.replace(Constants.ORG_ID, headers.get(Constants.ORGID_SM_HEADER));
			endpoint = endpoint.replace(Constants.STAFF_ID, headers.get(Constants.USERID_SM_HEADER));
			endpoint = endpoint.replace(Constants.COURSE_ID, courseDetails.get(CourseAPIConstants.COURSE_ID));
			Log.message("createCourseBySkill= " + envUrl + endpoint);
			String requestBody;
			if (scenario.contains("READING")) {
				Log.message("createCourseBySkill= READING");

				requestBody = SMUtils
						.convertFileToString(configProperty.getProperty("createCustomCourseBySkillsReading"));

			} else {
				Log.message("MATH");
				requestBody = SMUtils.convertFileToString(configProperty.getProperty("createCustomCourseBySkillsMath"));

			}
			requestBody = requestBody.replace(Constants.GRADE_ID, courseDetails.get(Constants.GRADE_VALUE));
			requestBody = requestBody.replace(Constants.COURSENAME_VALUE, courseDetails.get(Constants.COURSE_NAME));
			requestBody = requestBody.replace(CourseAPIConstants.PARENT_NODE,
					courseDetails.get(CourseAPIConstants.PARENT_NODE));
			requestBody = requestBody.replace(CourseAPIConstants.CHILD_NODE,
					courseDetails.get(CourseAPIConstants.CHILD_NODE));
			requestBody = requestBody.replace(Constants.CONTENT_BASE_ID_ENDPOINT,
					courseDetails.get(Constants.CONTENT_BASE_ID_ENDPOINT));

			Log.message("requestBody in create course=" + requestBody);
			Log.message("END POINT for create course=" + envUrl + endpoint);
			return RestHttpClientUtil.POST(envUrl, headers, new HashMap<String, String>(), endpoint, requestBody);

		} catch (Exception e) {
			Log.message("Error in createCourseBySkill method");
			return null;
		}
	}

	public void verifyResponse(Map<String, String> actualResponse, String message, String status) {

		try {
			Log.message("statuscode=" + actualResponse.get(Constants.STATUS_CODE));
			Log.message("statuscode1=" + status);
			if (SMUtils.getKeyValueFromResponse(actualResponse.get(Constants.RESPONSE_BODY), "messages,message")
					.contains(message)) {
				Log.pass(CommonAPIConstants.COURSE_DELETE_SUCCESS_MESSAGE);
			} else {
				Log.fail(CommonAPIConstants.COURSE_DELETE_FAILURE_MESSAGE);
			}
			if (actualResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(status)) {
				Log.pass(CommonAPIConstants.COURSE_DELETE_SUCCESS_STATUS);
			} else {
				Log.fail(CommonAPIConstants.COURSE_DELETE_FAILURE_STATUS);
			}

		} catch (Exception e) {
			Log.message("Error in verifyResponse method");
		}

	}

	public HashMap<String, String> updateCourseBySkill(String envUrl, Map<String, String> headers,
			Map<String, String> courseDetails, HashMap<String, String> courseSettings, String scenario) {
		try {

			if (scenario.contains("InvalidURL")) {
				endpoint = CourseAPIConstants.UPDATE_CUSTOM_COURSE_BY_STANDARDS_INVALID;
			} else {
				endpoint = CourseAPIConstants.UPDATE_CUSTOM_COURSE_BY_STANDARDS;
			}
			Log.message("update custom course by Skill= " + endpoint);
			endpoint = endpoint.replace(Constants.ORG_ID, headers.get(Constants.ORGID_SM_HEADER));
			endpoint = endpoint.replace(Constants.STAFF_ID, headers.get(Constants.USERID_SM_HEADER));
			endpoint = endpoint.replace(Constants.COURSE_ID, courseSettings.get(CourseAPIConstants.COURSE_ID));
			Log.message("endpoint=" + envUrl + endpoint);
			String requestBody;
			if (scenario.contains("READING")) {
				requestBody = SMUtils
						.convertFileToString(configProperty.getProperty("updateCustomCourseBySkillReading"));
			} else {
				requestBody = SMUtils
						.convertFileToString(configProperty.getProperty("updateCustomCourseBySkillReading"));
			}
			requestBody = requestBody.replace(Constants.COURSENAME_VALUE, courseDetails.get(Constants.COURSE_NAME));
			requestBody = requestBody.replace(Constants.GRADE_ID, courseDetails.get(Constants.GRADE_VALUE));
			requestBody = requestBody.replace(Constants.SESSION_LENGTH_ID,
					courseSettings.get(CourseAPIConstants.SESSION_STRENGTH_ID));
			requestBody = requestBody.replace(Constants.SESSION_LENGTH_NAME,
					courseSettings.get(CourseAPIConstants.SESSION_STRENGTH_NAME));
			requestBody = requestBody.replace(Constants.SESSION_LENGTH_VALUE,
					courseSettings.get(CourseAPIConstants.SESSION_STRENGTH_VALUE));
			requestBody = requestBody.replace(Constants.IDLE_TIME_ID,
					courseSettings.get(CourseAPIConstants.IDLE_TIME_ID));
			requestBody = requestBody.replace(Constants.IDLE_TIME_NAME,
					courseSettings.get(CourseAPIConstants.IDLE_TIME_NAME));
			requestBody = requestBody.replace(Constants.IDLE_TIME_VALUE,
					courseSettings.get(CourseAPIConstants.IDLE_TIME_VALUE));
			requestBody = requestBody.replace(CourseAPIConstants.PARENT_NODE,
					courseDetails.get(CourseAPIConstants.PARENT_NODE));
			requestBody = requestBody.replace(CourseAPIConstants.CHILD_NODE,
					courseDetails.get(CourseAPIConstants.CHILD_NODE));
			requestBody = requestBody.replace(Constants.CONTENT_BASE_ID_ENDPOINT,
					courseDetails.get(Constants.CONTENT_BASE_ID_ENDPOINT));

			Log.message("payload : " + requestBody);

			return RestHttpClientUtil.PUT(envUrl, headers, new HashMap<String, String>(), endpoint, requestBody);

		} catch (Exception e) {
			Log.message("Error in updating the Course method");
			return null;
		}
	}

	public HashMap<String, String> createCourseByStandard(String envUrl, Map<String, String> headers,
			Map<String, String> courseDetails, String scenario) {
		try {

			String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
			endpoint = endpoint.replace(Constants.ORG_ID, headers.get(Constants.ORGID_SM_HEADER));
			endpoint = endpoint.replace(Constants.STAFF_ID, headers.get(Constants.USERID_SM_HEADER));
			endpoint = endpoint.replace(Constants.COURSE_ID, courseDetails.get(CourseAPIConstants.COURSE_ID));
			String requestBody;
			requestBody = SMUtils
					.convertFileToString(configProperty.getProperty("createCustomCourseByStandardReading"));
			requestBody = requestBody.replace(Constants.GRADE_ID, courseDetails.get(Constants.GRADE_VALUE));
			requestBody = requestBody.replace(Constants.STANDARDFRAMEWORK_ID,
					courseDetails.get(Constants.STANDARD_FRAMEWORK_VALUE));
			requestBody = requestBody.replace(Constants.COURSENAME_VALUE, courseDetails.get(Constants.COURSE_NAME));
			requestBody = requestBody.replace(CourseAPIConstants.PARENT_NODE,
					courseDetails.get(CourseAPIConstants.PARENT_NODE));
			requestBody = requestBody.replace(CourseAPIConstants.CHILD_NODE,
					courseDetails.get(CourseAPIConstants.CHILD_NODE));
			return RestHttpClientUtil.POST(envUrl, headers, new HashMap<String, String>(), endpoint, requestBody);

		} catch (Exception e) {
			Log.message("Error in createCourseBySkill method");
			return null;
		}
	}

}