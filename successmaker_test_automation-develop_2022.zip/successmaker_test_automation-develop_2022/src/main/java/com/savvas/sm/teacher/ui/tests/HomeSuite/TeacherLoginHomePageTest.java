package com.savvas.sm.teacher.ui.tests.HomeSuite;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.teacher.ui.pages.TopNavBar;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class TeacherLoginHomePageTest {

    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String browser;
    private String smUrl;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String schoolID;
    private String teacherID;
    private static String username = null;
    private static String password = null;
    String teacherDetails;

    @BeforeTest
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify the teacher able to login and view the Teacher Dashboard via Lanching screen", priority = 1, groups = { "SMK-42103", "loginPage" } )
    public void tc_TeacherLoginHomePage001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_TeacherLoginHomePage001: SMK-7474 : Verify the teacher able to login and view the Teacher Dashboard via Lanching screen. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            TopNavBar topNavBar = tHomePage.topNavBar;

            // Verify the presence of top left SM logo and bottom right Savvas Logo
            Log.assertThat( topNavBar.isSuccessMakerLogoDisplayed(), "SuccessMaker Logo is displayed in TopNavBar", "SuccessMaker Logo is not displayed in TopNavBar" );

            // Verification for tabs availability in Homepage
            Log.assertThat( topNavBar.isHomeTabDisplayed(), "Home Tab is displayed in TopNavBar", "Home Tab is not displayed in TopNavBar" );
            Log.assertThat( topNavBar.isStudentsTabDisplayed(), "Students Tab is displayed in TopNavBar", "Students Tab is not displayed in TopNavBar" );
            Log.assertThat( topNavBar.isGroupsTabDisplayed(), "Groups Tab is displayed in TopNavBar", "Groups Tab is not displayed in TopNavBar" );
            Log.assertThat( topNavBar.isCoursewareDisplayed(), "Courseware Tab is displayed in TopNavBar", "Courseware Tab is not displayed in TopNavBar" );
            Log.assertThat( topNavBar.isMasteryTabDisplayed(), "Mastery Tab is displayed in TopNavBar", "Mastery Tab is not displayed in TopNavBar" );
            Log.assertThat( topNavBar.isReportsTabDisplayed(), "Reports Tab is displayed in TopNavBar", "Reports Tab is not displayed in TopNavBar" );

            // Verify Announcement Icon, Help Icon, UserProfile menu
            Log.assertThat( topNavBar.isAnnouncementDisplayed(), "Announcement Icon is displayed in TopNavBar", "Announcement Icon is not displayed in TopNavBar" );
            Log.assertThat( topNavBar.isHelpDisplayed(), "Help Icon is displayed in TopNavBar", "Help Icon is not displayed in TopNavBar" );

            // Expand user profile Dropdown
            topNavBar.expandUserDropdown();
            Log.assertThat( topNavBar.isUserDropdownExpanded(), "User Icon dropdown is displayed in TopNavBar", "User Icon dropdown is not displayed in TopNavBar" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
