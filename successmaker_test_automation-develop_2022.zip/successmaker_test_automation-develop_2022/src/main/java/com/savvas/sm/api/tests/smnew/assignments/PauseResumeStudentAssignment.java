package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

public class PauseResumeStudentAssignment extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String assignmentID;
    private String AssignmentUserId;
    private String CourseId;
    private String teacherUsername;
    List<String> studentRumbaIds = new ArrayList<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    /**
     * Tests the positive scenarios of Pause Resume Student Assignment.
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( dataProvider = "PauseResumeStudentAssignmentPositiveScenariosData", priority = 1, groups = { "SMK-51891", "smoke_test_case", "Assignments", "PauseResumeStudentAssignment", "P1", "API" } )
    public void tcPauseResumeAssignment001( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> GroupDetails = new HashMap<>();
        String endpoint = "null";

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

        HashMap<String, String> Response = new HashMap<>();

        GroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( groupAPI.createGroup( smUrl, GroupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }
        switch ( scenario ) {
            case "Default Math Assignment Resume":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                break;

            case "Default Math Assignment Pause":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "INACTIVE" );
                break;
            case "Default Reading Assignment Resume":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );

                break;
            case "Default Reading Assignment Pause":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "INACTIVE" );
                break;
            case "Focus Math Assignment Resume":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "3" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                break;
            case "Focus Math Assignment Pause":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "3" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "INACTIVE" );
                break;
            case "Focus Reading Assignment Resume":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "5" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                break;
            case "Focus Reading Assignment Pause":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "5" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "INACTIVE" );
                break;

            case "Custom By Skills - Math Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                break;

            case "Custom By Skills - Math Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "INACTIVE" );
                break;
            case "Custom By Settings - Math Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                break;
            case "Custom By Settings - Math Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "INACTIVE" );
                break;
            case "Custom By Standard - Math Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                break;
            case "Custom By Standard - Math Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "INACTIVE" );
                break;
            case "Custom By Skills - Reading Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                break;
            case "Custom By Skills - Reading Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "INACTIVE" );
                break;
            case "Custom By Settings - Reading Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                break;
            case "Custom By Settings - Reading Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "INACTIVE" );
                break;
            case "Custom By Standard - Reading Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                break;
            case "Custom By Standard - Reading Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "INACTIVE" );
                break;
            default:
                Log.message( "Case is invalid" );
                break;

        }

        HashMap<String, String> response = changeAssignmentStatus( smUrl, assignmentDetails, assignmentDetails.get( AssignmentAPIConstants.STATUS ), endpoint );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + response.get( "body" ) );
        Log.testCaseResult();
    
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "PauseResumeStudentAssignmentPositiveScenariosData" )
    public Object[][] PauseResumeStudentAssignmentDataValid() {

        Object[][] inputData = { { "Validate 200 for Math Positive flow - Activating assignment", "Default Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Math Positive flow - In-Activating assignment", "Default Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Reading Positive flow - Activating assignment", "Default Reading Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Reading Positive flow - In-Activating assignment", "Default Reading Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Focus Course - Math- Activating assignment", "Focus Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Focus Course - Math- In-Activating assignment", "Focus Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Focus Course - Reading- Activating assignment", "Focus Reading Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Focus Course - Reading-  In-Activating assignment", "Focus Reading Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Standard - Math -  Activating assignment", "Custom By Standard - Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Skills - Math - Activating assignment", "Custom By Skills - Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Settings - Math- Activating assignment", "Custom By Settings - Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Standard - Math -  In-Activating assignment", "Custom By Standard - Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Skills - Math - In-Activating assignment", "Custom By Skills - Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Settings - Math- In-Activating assignment", "Custom By Settings - Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Standard - Reading -  Activating assignment", "Custom By Standard - Reading Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Skills - Reading - Activating assignment", "Custom By Skills - Reading Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Settings - Reading- Activating assignment", "Custom By Settings - Reading Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Standard - Reading -  In-Activating assignment", "Custom By Standard - Reading Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Skills - Reading - In-Activating assignment", "Custom By Skills - Reading Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Settings - Reading- In-Activating assignment", "Custom By Settings - Reading Assignment Pause", CommonAPIConstants.STATUS_CODE_OK }

        };
        return inputData;
    }

    /**
     * Tests the Negative scenarios of Pause Resume Student Assignment.
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( dataProvider = "PauseResumeStudentAssignmentNegativeScenariosData", priority = 2, groups = { "SMK-51891", "Assignments", "PauseResumeStudentAssignment", "P2", "API" } )
    public void tcPauseResumeAssignment002( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> GroupDetails = new HashMap<>();
        String endpoint = "null";

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

        HashMap<String, String> Response = new HashMap<>();

        GroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( groupAPI.createGroup( smUrl, GroupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }

        String exception = null;
        boolean status = false;
        String message = null;

        switch ( scenario ) {
            case "Invalid assignmentuserid":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, "ABCD" );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
                message = CommonAPIConstants.INVALID_COURSEID_EXP;
                status = true;
                break;
            case "payload status as active in lower case":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "active" );
                exception = CommonAPIConstants.HTTP_MESSAGE_NOTREADABLE_EXCEPTION;
                message = CommonAPIConstants.JSON_PARSE_ERROR;
                status = true;
                break;
            case "payload status as inactive in lower case":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "inactive" );
                exception = CommonAPIConstants.HTTP_MESSAGE_NOTREADABLE_EXCEPTION;
                message = CommonAPIConstants.JSON_PARSE_ERROR;
                status = true;
                break;
            case "payload status as ACTIVES":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVES" );
                exception = CommonAPIConstants.HTTP_MESSAGE_NOTREADABLE_EXCEPTION;
                message = CommonAPIConstants.JSON_PARSE_ERROR;
                status = true;
                break;
            case "invalid authorization (Bearer token)":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            case "Invalid OrgID":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, "ABCD" );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;
            case "Invalid StaffId":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, "ABCD" );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            case "Invalid assignmentUserId but in valid format":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, "121212" );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.ASSIGNMENT_USER_NOT_FOUND;
                status = true;
                break;
            case "valid OrgId and Invalid StaffId":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_API;
                endpoint = endpoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", "ABCD" ).replace( "{AssignmentUserId}", AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = CommonAPIConstants.USER_ID_MISMATCH_MESSAGE;
                status = true;
                break;
            case "Invalid OrgId and valid StaffId":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_API;
                endpoint = endpoint.replace( "{orgID}", "ABCD" ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) ).replace( "{AssignmentUserId}", AssignmentUserId );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "ACTIVE" );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = CommonAPIConstants.INVALID_ORG_PARTIAL_ERROR_MESSAGE;
                status = true;
                break;
            default:
                Log.message( "Case is invalid" );
                break;
        }

        HashMap<String, String> response = changeAssignmentStatus( smUrl, assignmentDetails, assignmentDetails.get( AssignmentAPIConstants.STATUS ), endpoint );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + response.get( "body" ) );
        if ( message != null ) {
            verifyException( response.get( "body" ), exception, status, message );
        }
        
        Log.testCaseResult();
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "PauseResumeStudentAssignmentNegativeScenariosData" )
    public Object[][] PauseResumeStudentAssignmentDataInvalid() {

        Object[][] inputData = { { "Validate 400 Bad Request for Invalid assignmentuserid as string", "Invalid assignmentuserid", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Validate 400 Bad Request for payload status as active in lower case", "payload status as active in lower case", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Validate 400 Bad Request for payload status as inactive in lower case", "payload status as inactive in lower case", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Validate 400 Bad Request for payload status as ACTIVES", "payload status as ACTIVES", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Validate 401 for request with invalid/expired authorization (Bearer token)", "invalid authorization (Bearer token)", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Validate 403 for Invalid OrgID and valid StaffId in Header parameter", "Invalid OrgID", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Validate 401 for valid OrgID and Invalid StaffId in Header parameter", "Invalid StaffId", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Validate 200 Data Not Found Exception for Invalid assignmentUserId but in valid format", "Invalid assignmentUserId but in valid format", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 Data Not Found Exception for valid OrgId and Invalid StaffId", "valid OrgId and Invalid StaffId", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Validate 400 Bad Request for Invalid OrgId and valid StaffId", "Invalid OrgId and valid StaffId", CommonAPIConstants.STATUS_CODE_BAD_REQUEST } };
        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    /**
     * Verify the schema for the api
     * 
     * @param StatusCode
     * @param Body
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = smAPIprocessor.isSchemaValid( "PauseResumeStudentAssignment", StatusCode, response.get( "body" ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
        Log.assertThat( isValid, "The schema is valid and mathcing", "The schema is not valid and not  mathcing for the Status code :" + StatusCode );
    }

}