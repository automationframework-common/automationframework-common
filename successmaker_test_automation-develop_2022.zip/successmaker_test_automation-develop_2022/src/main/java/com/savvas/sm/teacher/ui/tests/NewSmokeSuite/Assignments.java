package com.savvas.sm.teacher.ui.tests.NewSmokeSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Assignments extends EnvProperties{
	
    private String smUrl;
    private String browser;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    String studentDetails;
    String studentDetailsSecond;
    String studentDetailsThree;
    String studentSMDetails;
    String studentSMDetailsSecond;
    String studentSMDetailsThree;
    String teacherDetails;
    String courseName;
    private HashMap<String, String> groupDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String token = null;
    List<String> expectedCourseTypesInDropdown = Arrays.asList( "Focus Courses", "Default Courses", "Custom Courses",
			"All Courses", "My Custom Courses" );
	
	  @BeforeTest
	    public void initTest( ITestContext context ) throws Exception {
	        smUrl = configProperty.getProperty( "SMAppUrl" );
	        browser = configProperty.getProperty( "BrowserPlatformToRun" );
	        teacherDetails = RBSDataSetup.getMyTeacher( school );
	        username = SMUtils.getKeyValueFromResponse(  teacherDetails, RBSDataSetupConstants.USERNAME );
	        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

	        studentDetails = RBSDataSetup.getMyStudent(school, username);
	        studentDetailsSecond = RBSDataSetup.getMyStudent(school, username);
	        studentDetailsThree = RBSDataSetup.getMyStudent(school, username);

	        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
	        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ) );
	        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsThree, "userId" ) );

	      //token creation
	        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

	      //Group
	        String groupName = "GroupNo_" + System.nanoTime();
	        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
	        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
	        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
	        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
	        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

	    }
	 	  
	  @Test ( description = "Verify Student Tab", enabled = true, priority = 1, groups = { "smoke_test_case", "Assignments", "Teacher_TC01", "P1" } )
	    public void tc_Assignments001() throws Exception {
			// Get driver
//			EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
//			EventListener eventListner = new EventListener();
//			driver.register(eventListner);
			
			WebDriverManager chromedriver = WebDriverManager.chromedriver();
	        chromedriver.setup();
	        ChromeDriver driver = new ChromeDriver();
	        driver.get( smUrl );
			
	        Log.testCaseInfo( "tc_Assignments001: Verify Student Tab. <small><b><i>[" + browser + "]</b></i></small>" );
	        try {
	        	

	            String studentDetails = RBSDataSetup.teacherStudentMap.get( username ).get( "Student1" );
	            System.out.println( "studentDetails: " + studentDetails );
	            String stuUserName = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );
	            String teacherDetails = RBSDataSetup.getMyTeacher( school );
	            System.out.println( "teacherDetails : " + teacherDetails );

	            // Login to the SM_Application
	            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
	         	TeacherHomePage tHomePage = new TeacherHomePage(driver);

	         	 // Navigating to the student tab
	            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
	            Log.assertThat( studentsPage.addStudentElement().isDisplayed(), "Add student button is displayed", "Add student button is not displayed" );

	            Log.assertThat( !studentsPage.groupAssignmentIsEnable(), "Group & Assignment button is disabled", "Group & Assignment button is Enabled" );
	            SMUtils.nap( 5 );
	            studentsPage.selectStudentByUsername( stuUserName );
	            SMUtils.nap( 5 );
	            Log.assertThat( studentsPage.groupAssignmentIsEnable(), "Group & Assignment button is enabled", "Group & Assignment button is disabled" );

	            List<String> textOfEllipsesOptions = studentsPage.getTextOfEllipsesOptions(stuUserName);
	            Log.assertThat(textOfEllipsesOptions.equals(Constants.Students.ELLIPSES_OPTIONS), "Ellipses options is present", "Ellipses options is not present");
	            
	            // Sign out from the SM_Application
	            tHomePage.topNavBar.signOutfromSM();

	            Log.testCaseResult();

	        } catch ( Exception e ) {
	            Log.exception( e, driver );
	        } finally {
	            Log.endTestCase();
	            driver.quit();
	        }
	    }
	  
	  @Test ( description = "Remove student in view assignmnet details page", enabled = true, priority = 1, groups = { "smoke_test_case", "Assignments", "Teacher_TC02", "P1" } )
	    public void tc_Assignments002() throws Exception {
			// Get driver
//			EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
//			EventListener eventListner = new EventListener();
//			driver.register(eventListner);
		  
		  WebDriverManager chromedriver = WebDriverManager.chromedriver();
	        chromedriver.setup();
	        ChromeDriver driver = new ChromeDriver();
	        driver.get( smUrl );
			
	        Log.testCaseInfo( "tc_Assignments002: Remove student in view assignmnet details page. <small><b><i>[" + browser + "]</b></i></small>" );
	        try {

	            // Login to the SM_Application
	            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
	         	TeacherHomePage tHomePage = new TeacherHomePage(driver);

	         	boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
	         	Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

	            String studentFNLN = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetails, "lastName" );
	            CoursesPage coursepage = tHomePage.topNavBar.navigateToCourseListingPage();
	            Log.message("page landed");
	            coursepage.clickCourseName( Constants.SM_FOCUS_READING_GRADE3 );// Select Focus course

	            // Clicking on 'Assign-Widget' and assigning
	            coursepage.clickAssignBtn();
	            coursepage.addCourseToStudents();

	            // Navigate 'CourseWare' tab and select the 'Assignments' option
	            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

	            // Clicking on View Assignment
	            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_READING_GRADE3 );

	            assignmentDetailsPage.removeStudentTab();
	            Log.assertThat( assignmentDetailsPage.checkCancelbuttonremoveStudent(), "Remove Student option is clickable", "Remove Student option is not clickable" );

	            assignmentDetailsPage.removeStudentFromCourse();
	            Log.assertThat( !assignmentDetailsPage.checkRemoveStudent(), "Student removed successfully", "Student not removed successfully" );

	            String getactivePausedText = assignmentDetailsPage.getactivePausedText();
	            Log.message(getactivePausedText);
	            
	            // Sign out from the SM_Application
	            tHomePage.topNavBar.signOutfromSM();

	            Log.testCaseResult();

	        } catch ( Exception e ) {
	            Log.exception( e, driver );
	        } finally {
	            Log.endTestCase();
	            driver.quit();
	        }
	    }	 
	 
	  @Test ( description = "Verify assignment details page", enabled = true, priority = 1, groups = { "smoke_test_case", "Assignments", "Teacher_TC03", "P1" } )
	    public void tc_Assignments003() throws Exception {
			// Get driver
//			EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
//			EventListener eventListner = new EventListener();
//			driver.register(eventListner);
		  
		  WebDriverManager chromedriver = WebDriverManager.chromedriver();
	        chromedriver.setup();
	        ChromeDriver driver = new ChromeDriver();
	        driver.get( smUrl );
			
	        Log.testCaseInfo( "tc_Assignments003: Verify assignment details page.<small><b><i>[" + browser + "]</b></i></small>" );
	        try {
	        	 LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
	             TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

	             // Get Assignments Page
	             AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

	             AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.clickViewAssignment();

	             Log.assertThat( ( assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage().contains( Constants.ACTIVE_STUDENTS_ASSIGMENT_SUBTITILE )
	                     && assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage().contains( Constants.PAUSED_STUDENTS_ASSIGMENT_SUBTITILE ) ), "Assignment SubTitle is displayed", "Assignment SubTitle is not displayed" );

	             Log.assertThat( assignmentDetailsPage.assignElement().isDisplayed(), "Assign button is displayed", "Assign button is not displayed" );

	             Log.assertThat( assignmentDetailsPage.getColumnName().trim().equals( Constants.NAME ), "NAME Column is displayed in the Assignment_Details_Page", "NAME Column is not displayed in the Assignment_Details_Page" );
	             Log.assertThat( assignmentDetailsPage.getColumnLastSession().trim().equals( Constants.LAST_SESSION ), "LAST_SESSION Column is displayed in the Assignment_Details_Page", "LAST_SESSION Column is not displayed in the Assignment_Details_Page" );
	             Log.assertThat( assignmentDetailsPage.getColumnIPLevel().trim().equals( Constants.IP_LEVEL ), "IP_LEVEL Column is displayed in the Assignment_Details_Page", "IP_LEVEL Column is not displayed in the Assignment_Details_Page" );
	             Log.assertThat( assignmentDetailsPage.getColumnAssignedLevel().trim().equals( Constants.ASSIGNED_LEVEL ), "ASSIGNED_LEVEL Column is displayed in the Assignment_Details_Page",
	                     "ASSIGNED_LEVEL Column is not displayed in the Assignment_Details_Page" );
	             Log.assertThat( assignmentDetailsPage.getColumnCurrentLevel().trim().equals( Constants.CURRENT_LEVEL ), "CURRENT_LEVEL Column is displayed in the Assignment_Details_Page",
	                     "CURRENT_LEVEL Column is not displayed in the Assignment_Details_Page" );
	             Log.assertThat( assignmentDetailsPage.getColumnGain().trim().equals( Constants.GAIN ), "GAIN Column is displayed in the Assignment_Details_Page", "GAIN Column is not displayed in the Assignment_Details_Page" );
	             Log.assertThat( assignmentDetailsPage.getColumnPercentageCorrect().trim().equals( Constants.PERCENTAGE ), "Percentage Column is displayed in the Assignment_Details_Page", "Percentage Column is not displayed in the Assignment_Details_Page" );
	             
	            tHomePage.topNavBar.signOutfromSM();

	            Log.testCaseResult();

	        } catch ( Exception e ) {
	            Log.exception( e, driver );
	        } finally {
	            Log.endTestCase();
	            driver.quit();
	        }
	    }
	  
	  @Test ( description = "Verify assign existing assignment", enabled = true, priority = 1, groups = { "smoke_test_case", "Assignments", "Teacher_TC04", "P1" } )
	    public void tc_Assignments004() throws Exception {
			// Get driver
//			EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
//			EventListener eventListner = new EventListener();
//			driver.register(eventListner);
		  
		  WebDriverManager chromedriver = WebDriverManager.chromedriver();
	        chromedriver.setup();
	        ChromeDriver driver = new ChromeDriver();
	        driver.get( smUrl );
			
	        Log.testCaseInfo( "tc_Assignments004: Verify assign existing assignment.<small><b><i>[" + browser + "]</b></i></small>" );
	        try {

	        	 // Login to the SM_Application
	            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
	         	TeacherHomePage tHomePage = new TeacherHomePage(driver);

	         	boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
	         	Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

//	            String studentFNLN = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetails, "lastName" );
	            CoursesPage coursepage = tHomePage.topNavBar.navigateToCourseListingPage();
//	            Log.message("page landed");
	         	
	         	StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
	            Map<String, List<String>> studentDetailsFromStudentTab = studentsPage.getColumnDetailsAsList();
	            List<String> studenListFromStudentTab = new ArrayList<>();
	            for (int studentValue = 0; studentValue < studentDetailsFromStudentTab.get(Constants.FIRSTNAME)
	                    .size(); studentValue++) {
	                String studentFN = studentDetailsFromStudentTab.get(Constants.FIRSTNAME).get(studentValue);
	                String studentLN = studentDetailsFromStudentTab.get(Constants.LASTNAME).get(studentValue);
	                studenListFromStudentTab.add(coursepage.completeStudentName(studentFN, "", studentLN));
	            }
	            String[] FNLN = studenListFromStudentTab.get(0).split(" ");
	            String studentFNLN = FNLN[0].concat(FNLN[1]);

	            
	            courseName=coursepage.generateRandomCourseName();
	            CourseListingPage coursePage = tHomePage.topNavBar.getCourseListingPage();
	            coursePage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
	            coursepage.copyOfCourse(courseName, Constants.SETTINGS, Constants.MATH);
	            SMUtils.waitForSpinnertoDisapper(driver);
	            coursepage.clickCourseName( courseName); 
	            
	            // Clicking on 'Assign-Widget' and assigning
	            coursepage.clickAssignBtn();
	       //     coursepage.addCourseToStudents();
	            coursepage.addCourseToOneStudent(studentFNLN);
	            
	            // Get Assignments Page
	            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

	            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( courseName );
	  //          AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.clickViewAssignment();
	            AssignAssignmentPopup assigAssignmentPopup = assignmentDetailsPage.clickAssignButton();
	            assigAssignmentPopup.assignMultipleStudentsToCourse();
	            assigAssignmentPopup.getStudentListFromPopUp();
	     //       assigAssignmentPopup.getStudentListFromPopUp();
	            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );
	            assigAssignmentPopup.clickAssignButtonOnPopup();
	            Log.message( "Successfully Assigned Multiple Students To Course" );

	            Log.assertThat( assignmentDetailsPage.getStudentListfromAssignementDetailsTable().containsAll( assigAssignmentPopup.getStudentListFromPopUp() ), "Added students are displayed in Assignments Table",
	                    "Added students are not displayed in Assignments Table" );
	            Log.testCaseResult();
	          
	            // Sign out from the SM_Application
	            tHomePage.topNavBar.signOutfromSM();

	            Log.testCaseResult();

	        } catch ( Exception e ) {
	            Log.exception( e, driver );
	        } finally {
	            Log.endTestCase();
	            driver.quit();
	        }
	    }
	  
	 
}
