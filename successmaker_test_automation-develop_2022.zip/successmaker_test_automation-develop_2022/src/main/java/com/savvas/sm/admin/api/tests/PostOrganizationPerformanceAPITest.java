package com.savvas.sm.admin.api.tests;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationPerformance;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;

/**
 * This class is used to test the admin's organization performance API test
 * 
 * @author madhan.nagarathinam
 *
 */

public class PostOrganizationPerformanceAPITest extends EnvProperties {
    private static String smUrl;
    private String browser;
    private static String districtAdminDetails, districtAdminUserName, districtAdminUserId;
    String teacherDetails = null;
    String teacherUserName, teacherUserId;
    String teacherDetails2 = null;
    String teacherUserName2, teacherUserId2;
    String studentDetailst2 = null;
    String studentUserNamet2, studentUserIdt2;

    String studentDetails1 = null;
    String studentUserName1, studentUserId1;
    String studentDetails2 = null;
    String studentUserName2, studentUserId2;
    String studentDetails3 = null;
    String studentUserName3, studentUserId3;
    String studentDetails4 = null;
    String studentUserName4, studentUserId4;
    String orgId;
    String orgId2;
    String parentOrgId;
    private static String school2 = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    RBSUtils rbsUtils = new RBSUtils();
    
    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        districtAdminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        
        districtAdminUserName = SMUtils.getKeyValueFromResponse( districtAdminDetails, "userName" );
        districtAdminUserId = SMUtils.getKeyValueFromResponse( districtAdminDetails, "userId" );

        parentOrgId = configProperty.getProperty( "district_ID" );
        orgId = rbsUtils.getOrganizationIDByName( parentOrgId ,school );
        orgId2 = rbsUtils.getOrganizationIDByName( parentOrgId, school2 );

        // Get Teacher and Student details for Flex school
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUserName = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );

        studentDetails1 = RBSDataSetup.getMyStudent( school, teacherUserName );
        studentUserName1 = SMUtils.getKeyValueFromResponse( studentDetails1, "userName" );
        studentUserId1 = SMUtils.getKeyValueFromResponse( studentDetails1, "userId" );

        studentDetails2 = RBSDataSetup.getMyStudent( school, teacherUserName );
        studentUserName2 = SMUtils.getKeyValueFromResponse( studentDetails2, "userName" );
        studentUserId2 = SMUtils.getKeyValueFromResponse( studentDetails2, "userId" );

        studentDetails3 = RBSDataSetup.getMyStudent( school, teacherUserName );
        studentUserName3 = SMUtils.getKeyValueFromResponse( studentDetails3, "userName" );
        studentUserId3 = SMUtils.getKeyValueFromResponse( studentDetails3, "userId" );

        studentDetails4 = RBSDataSetup.getMyStudent( school, teacherUserName );
        studentUserName4 = SMUtils.getKeyValueFromResponse( studentDetails4, "userName" );
        studentUserId4 = SMUtils.getKeyValueFromResponse( studentDetails4, "userId" );

        // Get Teacher and Student details for Math school
        teacherDetails2 = RBSDataSetup.getMyTeacher( school2 );
        teacherUserName2 = SMUtils.getKeyValueFromResponse( teacherDetails2, "userName" );
        teacherUserId2 = SMUtils.getKeyValueFromResponse( teacherDetails2, "userId" );

        studentDetailst2 = RBSDataSetup.getMyStudent( school2, teacherUserName2 );
        studentUserIdt2 = SMUtils.getKeyValueFromResponse( studentDetailst2, "userId" );
        studentUserNamet2 = SMUtils.getKeyValueFromResponse( studentDetailst2, "userName" );
        
        HashMap<String, String> assignmentDetailsT1 = new HashMap<>();
        assignmentDetailsT1.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetailsT1.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        assignmentDetailsT1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUserName, password ) );
        
        Log.message( "Assignment Details: " + assignmentDetailsT1 );
        Log.message( "Student 1 Details: " + studentDetails1 );
        Log.message( "Student 2 Details: " + studentDetails2 );
        Log.message( "Student 3 Details: " + studentDetails3 );
        Log.message( "Student 4 Details: " + studentDetails4 );
        
        new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetailsT1, Arrays.asList( studentUserId1, studentUserId2, studentUserId3, studentUserId4 ),
                Arrays.asList( Constants.MATH_SUBJECT_ID_VALUE ) );
        Log.message( assignmentDetailsT1+"" );

        executeCourse( studentUserName1, Constants.MATH, true, "100", "1", "20" );

    }

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "smoke_test_case", "SMK-51752", "(SQE) (API) Logged In Organization Performance Report This Week", "API" }, priority = 1 )
    public void postAdminOrganizationPerformanceTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        Log.testCaseInfo( testcaseName + testcaseDescription );
        HashMap<String, String> headers = new HashMap<String, String>();
        Map<String, Object> payload = new HashMap<>();

        HashMap<String, List<String>> orgIdStudents = new HashMap<String, List<String>>();
        List<String> stuentIds = new ArrayList<String>();
        List<String> studentIds2 = new ArrayList<String>();

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
        headers.put( AdminAPIConstants.ORGID, parentOrgId );
        headers.put( AdminAPIConstants.USERID, districtAdminUserId );

        LocalDate now = LocalDate.now();
        LocalDate tmrwDate = LocalDate.now().plusDays( 1 );
        LocalDate firstMonday = now.with( TemporalAdjusters.previous( DayOfWeek.MONDAY ) );
        String thisWeekStartDay = firstMonday.toString();
        String thisWeekEndDay = tmrwDate.toString();
        LocalDate lastWeekStartDay1 = firstMonday.minusDays( 7 );
        String lastWeekStartDay = lastWeekStartDay1.toString();
        LocalDate lastWeekEndDay1 = firstMonday.minusDays( 1 );
        String lastWeekEndDay = lastWeekEndDay1.toString();

        switch ( scenarioType ) {
            case "WITH_MANDATORY_FILEDS":

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );
                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "WITH_SINGLE_ORG_STUDENT_IDS":

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );
                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "WITH_MULTIPLE_ORG_STUDENT_IDS":

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );
                studentIds2.add( studentUserIdt2 );
                orgIdStudents.put( orgId2, studentIds2 );
                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "VALID_RESPONSE_WITH_RESPECT_TO_DATE_GIVEN":

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );
                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, thisWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, lastWeekEndDay );
                break;

            case "EMPTY_DATA":
                stuentIds.add( studentUserId4 );
                orgIdStudents.put( orgId, stuentIds );
                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, thisWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, lastWeekEndDay );
                break;

        }

        Response response = new OrganizationPerformance().PostAdminOrganizationPerfomance( smUrl, headers, payload );
        int actualstatuscode = response.getStatusCode();
        Log.message( response.getBody().asString() );
        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
        if ( !scenarioType.equalsIgnoreCase( "EMPTY_DATA" ) )
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "PostMasteryAdminOrgPerformance", expected_StatusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );

    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { 
                { "TC:01", "200", "Verify 200 status code and response when valid header, authorization and request payload are provided", "WITH_MANDATORY_FILEDS" },
                { "TC:02 ", "200", "Verify 200 status code and response body when valid student-id's and org-id is provided in the request payload", "WITH_SINGLE_ORG_STUDENT_IDS" },
                { "TC:03 ", "200", "Verify 200 status code and response body when valid org-id with respective multi-school customer id is provided in the headers with different org's and respective studentId's", "WITH_MULTIPLE_ORG_STUDENT_IDS" },
                { "TC:04 ", "200", "Verify 200 status code and response body with respect to the selected dates when valid last week start date & last week end date and this week start date & this week end date is provided in the request payload",
                        "VALID_RESPONSE_WITH_RESPECT_TO_DATE_GIVEN" },
                { "TC:05 ", "200", "Verify 200 status code and  'No Data Found for Admin Performance' message in response body when the admin's organization has no Organization's performance report ", "EMPTY_DATA" },

        };
        return data;
    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51752", "(SQE) (API) Logged In Organization Performance Report This Week", "API" }, priority = 1 )
    public void postAdminOrganizationPerformanceTest002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        Log.testCaseInfo( testcaseName + testcaseDescription );
        HashMap<String, String> headers = new HashMap<String, String>();
        Map<String, Object> payload = new HashMap<>();

        HashMap<String, List<String>> orgIdStudents = new HashMap<String, List<String>>();
        List<String> stuentIds = new ArrayList<String>();

        LocalDate now = LocalDate.now();
        Date date = new Date();
        LocalDate firstMonday = now.with( TemporalAdjusters.previous( DayOfWeek.MONDAY ) );
        String thisWeekStartDay = firstMonday.toString();
        String thisWeekEndDay = new SimpleDateFormat( "yyyy-MM-dd" ).format( date );
        LocalDate lastWeekStartDay1 = firstMonday.minusDays( 7 );
        String lastWeekStartDay = lastWeekStartDay1.toString();
        LocalDate lastWeekEndDay1 = firstMonday.minusDays( 1 );
        String lastWeekEndDay = lastWeekEndDay1.toString();

        switch ( scenarioType ) {
            case "INVALID_AUTH":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, districtAdminUserId );

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "INVALID_CONTENT_TYPE":
                headers.put( Constants.CONTENT_TYPE, Constants.FORM_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, districtAdminUserId );

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "INVALID_USER_ID":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, districtAdminUserId + 1 );

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "INVALID_ORG_ID":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId + 1 );
                headers.put( AdminAPIConstants.USERID, districtAdminUserId );

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "INVALID_STUDENTS_ID_PAYLOAD":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, districtAdminUserId );

                stuentIds.add( studentUserId1 + 1 );
                stuentIds.add( studentUserId2 + 1 );
                orgIdStudents.put( orgId, stuentIds );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "NULL_STUDENT_ID_PAYLOAD":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, districtAdminUserId );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, null );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "INVALID_LASTWEEK_START_DATE_AND_END_DATE":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, districtAdminUserId );

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "NULL_LASTWEEK_START_DATE_AND_END_DATE":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, districtAdminUserId );

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, null );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, null );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "INVALID_THISWEEK_START_DATE_AND_END_DATE":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, districtAdminUserId );

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "NULL_THISWEEK_START_DATE_AND_END_DATE":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, districtAdminUserId );

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, null );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, null );
                break;

            case "TEACHER":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( teacherUserName, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, teacherUserId );

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

            case "STUDENT":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( studentUserName2, password ) );
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, studentUserId2 );

                stuentIds.add( studentUserId1 );
                stuentIds.add( studentUserId2 );
                orgIdStudents.put( orgId, stuentIds );

                payload.put( AdminAPIConstants.ORG_STUDENTS_MAP, orgIdStudents );
                payload.put( AdminAPIConstants.LAST_WEEK_START_DATE, lastWeekStartDay );
                payload.put( AdminAPIConstants.LAST_WEEK_END_DATE, lastWeekEndDay );
                payload.put( AdminAPIConstants.THIS_WEEK_START_DATE, thisWeekStartDay );
                payload.put( AdminAPIConstants.THIS_WEEK_END_DATE, thisWeekEndDay );
                break;

        }
        Response response = new OrganizationPerformance().PostAdminOrganizationPerfomance( smUrl, headers, payload );
        int actualstatuscode = response.getStatusCode();
        Log.message( response.getBody().asString() );
        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );

    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC:06 ", "401", "Verify 401 status code and response body when invalid authorization is provided", "INVALID_AUTH" },
                { "TC:07 ", "415", "Verify 415 status code and response body when invalid content-type is provided in the headers", "INVALID_CONTENT_TYPE" },
                { "TC:08 ", "401", "Verify 401 status code and response body when invalid userId is provided in the headers", "INVALID_USER_ID" },
                { "TC:09 ", "403", "Verify 403 status code and response body when invalid orgId is provided in the headers", "INVALID_ORG_ID" },
                { "TC:10 ", "200", "Verify 403 status code and response body when invalid stuentId's is provided in the request payload", "INVALID_STUDENTS_ID_PAYLOAD" },
                { "TC:11 ", "400", "Verify 400 status code and respective validation error message in the response body when orgStudentsMap in request payload is given as 'null'", "NULL_STUDENT_ID_PAYLOAD" },
                { "TC:12 ", "400", "Verify 400 status code and response body when invalid last week start date and last week end date is provided in the request payload", "INVALID_LASTWEEK_START_DATE_AND_END_DATE" },
                { "TC:13 ", "400", "Verify 400 status code and response body when null is provided in last week start date and last week end date is provided in the request payload", "NULL_LASTWEEK_START_DATE_AND_END_DATE" },
                { "TC:14 ", "400", "Verify 400 status code and response body when  invalid this week end date and this week start date are provided in the request payload", "INVALID_THISWEEK_START_DATE_AND_END_DATE" },
                { "TC:15 ", "403", "Verify 403 status code and response body when valid org-id wth Teacher user id is provided in the headers", "TEACHER" },
                { "TC:16 ", "403", "Verify 403 status code and response body when valid org-id wth Student user id is provided in the headers", "STUDENT" } };
        return data;
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, String percent, String session, String LO ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username- " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, percent, session, LO );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, percent, session, LO );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }
}
