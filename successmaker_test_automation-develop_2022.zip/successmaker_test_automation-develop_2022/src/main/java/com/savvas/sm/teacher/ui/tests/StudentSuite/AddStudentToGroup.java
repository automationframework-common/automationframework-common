package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class AddStudentToGroup extends BaseTest {

    List<String> expectedCourseTypesInDropdown = Arrays.asList( "Focus Courses", "Default Courses", "Custom Courses", "All Courses" );

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    private String teacherId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private String teacherDetails;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    List<String> studentIdList = null;
    List<String> studentUserNames = null;
    ArrayList<String> studentDetails = null;
    private AtomicReference<String> schoolUsed = new AtomicReference<>();

    @BeforeClass
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        studentDetails = new ArrayList<>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<>();
        studentUserNames = new ArrayList<>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

    }

    @Test ( description = "Verify Add Student to Group functionality in Students tab", groups = { "Students", "SMK-39138" }, priority = 1 )
    public void tcAddStuToGroup001( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcAddStuToGroup: Verify Add Student to Group functionality in Students tab. <small><b><i>[" + browser + "]</b></i></small>" );
        String studentID = SMUtils.getKeyValueFromResponse( studentDetails.get( 0 ), RBSDataSetupConstants.USERNAME );
        Log.message( "studentID: " + studentID );

        HashMap<String, String> groupDetailsMap = new HashMap<>();
        groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, "SM Regression Group" + System.nanoTime() );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentIdList );
        String groupDetails = SMUtils.getKeyValueFromResponse( createGroup.get( Constants.BODY ), "data" );

        String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "groupName" );
        String newGroupName = "Reg_Automation_" + System.nanoTime();
        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Groups tab
            GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupPage.createGroupWithoutStudent( newGroupName );
            // Navigate to Students tab
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickAddStudentToGroupByEllipsis( studentID );

            SMUtils.logDescriptionTC( "Validate the label of the pop up with an i button is displayed on the left top corner of the pop up" );
            String textofHeaderPopup = studentsPage.getTextofHeaderPopup();
            Log.assertThat( textofHeaderPopup.equalsIgnoreCase( "Add Students to Group(s)" ), "Add student to group popup verified successfully!", "Add student to group popup is not displayed!" );

            //SMUtils.nap( 4 );
            SMUtils.logDescriptionTC( "SMK-8066: Validate the functionality of adding a student to a group in SM application" );
            SMUtils.logDescriptionTC( "SMK-8060 : Validate the Group names in the pop up displays only the groups that is created by that teacher and able to select them" );
            studentsPage.clickAddButtonInAddStudentToGroup( newGroupName );
            Log.assertThat( studentsPage.isGroupExistInAddStuToGroup( newGroupName ), "Successfully clicked on Add button for Group " + newGroupName, "Failed to Click on Add button for Group " + newGroupName );

            SMUtils.logDescriptionTC( "SMK-8062: Validate the funcitonality of Remove Button in the Add student list to Group pop up" );
            Log.assertThat( studentsPage.clickRemoveButtoninAddStudentToGroupPopup( newGroupName ).getText().trim().equals( Constants.Students.removeText ), "Remove button is displayed for the group" + newGroupName,
                    "Remove button is not displayed for the group" + newGroupName );
            studentsPage.clickXinChipAreaForGroup( newGroupName );

            SMUtils.logDescriptionTC( "SMK-8061: Validate the funcitonality of X Button in the Add student list to Group pop up" );
            Log.assertThat( studentsPage.getAddButtonForGroupinAddStudentToGroup( newGroupName ).getText().trim().equals( Constants.Students.ADD_TEXT ), "Add button is displayed after clicking X icon for the group" + newGroupName,
                    "Add button is not displayed after clicking X icon for the group" + newGroupName );

            SMUtils.logDescriptionTC( "SMK-8064: Validate the functionality of Cancel Button in the Add student list to Group pop up" );
            studentsPage.clickCancelButtonInAddStuPopup();
            studentsPage.clickviewStudentByEllipsis( studentID );
            Log.assertThat( !studentsPage.isGroupnamePresent( newGroupName ), "Group name " + newGroupName + " is not present in Students page", "Group name " + newGroupName + " is present in the page" );
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            SMUtils.logDescriptionTC( "SMK-8063: Validate the functionality of Save Button in the Add student list to Group pop up" );
            studentsPage.clickAddStudentToGroupByEllipsis( studentID );
            studentsPage.clickAddButtonInAddStudentToGroup( newGroupName );
            studentsPage.clickSaveButtonInAddStuPopup();
            studentsPage.clickviewStudentByEllipsis( studentID );
            Log.assertThat( studentsPage.isGroupnamePresent( newGroupName ), "Group name " + newGroupName + " is present in Students page", "Group name " + groupName + " is not present in the page" );

            SMUtils.logDescriptionTC( "Verify that the group is displayed for the student, when the student removed from a group." );
            //studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.removeStudentFromGroup( newGroupName );
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickAddStudentToGroupByEllipsis( studentID );

            List<String> listOfGroupName = studentsPage.getListOfGroupName();
            Log.assertThat( listOfGroupName.contains( newGroupName ), "Group name displayed after student removed from group " + newGroupName, "Group name not displayed after student removed from group  " + newGroupName );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Add Student to Group functionality in Students tab", groups = { "Students", "SMK-39138", "P3" }, priority = 1 )
    public void tcAddStuToGroup002( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcAddStuToGroup: Verify Add Student to Group functionality in Students tab. <small><b><i>[" + browser + "]</b></i></small>" );
        String studentID1 = studentUserNames.get( 0 );
        String studentID2 = studentUserNames.get( 1 );

        HashMap<String, String> groupDetailsMap = new HashMap<>();
        groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, "SM Regression Group" + System.nanoTime() );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentIdList );
        String groupDetails = SMUtils.getKeyValueFromResponse( createGroup.get( Constants.BODY ), "data" );

        String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "groupName" );
        String newGroupName = "Reg_Automation_" + System.nanoTime();

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Groups tab
            GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupPage.createGroupWithoutStudent( newGroupName );
            groupPage.viewGroup( newGroupName );
            groupPage.clickOnTheHoveredGroup( groupName );
            Log.assertThat( groupPage.verifyGroupNameInProfile( newGroupName ), "Longer group is displayed perfectly in groups page", "Longer group name is not displayed as expected in Groups page" );
            // Navigate to Students tab
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.selectStudentByUsername( studentID1 );

            SMUtils.logDescriptionTC( "SMK-8058 : Validate the Group button is enabled in the Students tab after selecting a student in SM non-integrated application" );
            Log.assertThat( studentsPage.groupAssignmentIsEnable(), "Group button is enabled after student is selected", "Group button is not enabled after student is selected" );
            studentsPage.clickGroupButtoninStudentLisitngPage();

            SMUtils.logDescriptionTC( "SMK-8059 : Validate the label of the pop up with an i button is displayed on the left top corner of the pop up" );
            Log.assertThat( studentsPage.verifyHelpIcon(), "Help icon is displayed successfully in Add Students to Groups popup", "Help icon is not displayed in Add Students to Group popup" );
            studentsPage.clickCancelButtonInAddStuPopup();
            studentsPage.clickGroupButtoninStudentLisitngPage();
            studentsPage.clickAddButtonInAddStudentToGroup( newGroupName );
            studentsPage.clickSaveButtonInAddStuPopup();

            groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupPage.createGroupWithoutStudent( newGroupName + System.nanoTime() );
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            SMUtils.logDescriptionTC( "SMK-8071 : Validate the students are unchecked after adding them the groups" );
            Log.assertThat( !studentsPage.isCheckBoxSelected( studentID1 ), "Checkbox is not selected after student " + studentID1 + "added to the group", "Checkbox is selected after student " + studentID1 + "added to the group" );
            studentsPage.clickviewStudentByEllipsis( studentID1 );

            SMUtils.logDescriptionTC( "Validate the Group names in the pop up displays only Successmaker groups and able to select them." );
            Log.assertThat( studentsPage.isGroupnamePresent( newGroupName ), "Group name " + newGroupName + " is present in Students page", "Group name " + groupName + " is not present in the page" );
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.selectStudentByUsername( studentID1 );
            studentsPage.clickGroupButtoninStudentLisitngPage();
            Log.assertThat( !studentsPage.isGroupnamePresentInAddStudentPopup( newGroupName ), "Group name " + newGroupName + " is not present in Students page", "Group name " + groupName + " is not present in the page" );
            studentsPage.clickCancelButtonInAddStuPopup();
            studentsPage.selectStudentByUsername( studentID2 );
            studentsPage.clickGroupButtoninStudentLisitngPage();
            studentsPage.clickAddButtonInAddStudentToGroup( newGroupName );
            studentsPage.clickSaveButtonInAddStuPopup();

            SMUtils.logDescriptionTC( "Verify that when multiple students who belongs to different groups are selected, the groups that all the students selected does not belong are displayed." );
            SMUtils.logDescriptionTC( "SMK-8067 : Validate the functionality of adding multiple/all students to a group in SM application" );
            studentsPage.clickviewStudentByEllipsis( studentID1 );
            Log.assertThat( studentsPage.isGroupnamePresent( newGroupName ), "Group name " + newGroupName + " is present in Students page", "Group name " + groupName + " is not present in the page" );
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID2 );
            Log.assertThat( studentsPage.isGroupnamePresent( newGroupName ), "Group name " + newGroupName + " is present in Students page", "Group name " + groupName + " is not present in the page" );
            groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupPage.viewGroup( newGroupName );
            SMUtils.logDescriptionTC( "Verify the group is not displayed in the list, when the student is already added in the group." );
            SMUtils.logDescriptionTC( "SMK-8068 : Validate the functionality of adding the same student multiple times in the same group will not make duplicate entry in SM application" );
            SMUtils.logDescriptionTC( "Validate the functionality of adding same student to multiple groups in SM application" );
            Set<String> studentNames = new HashSet<>();
            HashMap<String, HashMap<String, String>> allStudentDetails = groupPage.getStudentDetailsBasedOnGroup( newGroupName );
            boolean result = IntStream.rangeClosed( 1, allStudentDetails.size() ).allMatch( studentCount -> studentNames.add( allStudentDetails.get( "Student" + studentCount ).get( Constants.USER_NAME ) ) );
            Log.assertThat( result, "Duplicate entry of student is not present in Groups page", "Duplicate entry of student is present in Groups page" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Add Student to Group functionality in Students tab", groups = { "Students", "SMK-39138", "P1" }, priority = 1 )
    public void tcAddStuToGroup003( ITestContext context ) throws Exception {

        //Creating class without sm Product
        String withoutProduct = "noSMProductGroup" + System.nanoTime();
        HashMap<String, String> classDetails = new HashMap<>();
        classDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        classDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
        classDetails.put( RBSDataSetupConstants.STAFF_PI_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        classDetails.put( RBSDataSetupConstants.SECTION_NAME, withoutProduct );
        classDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, studentIdList.get( 1 ) );
        new RBSUtils().createClass( classDetails );
        String withSMProductGroup = "withSMProductGroup" + System.nanoTime();
        classDetails.put( RBSDataSetupConstants.SECTION_NAME, withSMProductGroup );
        String createClass = new RBSUtils().createClass( classDetails );
        String withSmProductClassID = new JSONObject( createClass ).getJSONObject( "data" ).getJSONObject( "section" ).get( "id" ).toString();

        String adminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        String addProductToClassGraphQL = new RBSUtils().addProductToClassGraphQL( classDetails.get( RBSDataSetupConstants.ORGANIZATION_ID ), withSmProductClassID, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ), adminToken,
                SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );

        Log.message( addProductToClassGraphQL );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            Log.testCaseInfo( "tcAddStuToGroup: Verify Add Student to Group functionality in Students tab. <small><b><i>[" + browser + "]</b></i></small>" );

            // Navigate to Students tab
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.selectStudentByUsername( studentUserNames.get( 0 ) );
            studentsPage.clickGroupButtoninStudentLisitngPage();
            SMUtils.logDescriptionTC( "Verify if the class is having success maker product " );
            Log.assertThat( studentsPage.isGroupnamePresentInAddStudentPopup( withSMProductGroup ), "With successmaker product group is  displayed!", "With successmaker product group is not displayed!" );
            SMUtils.logDescriptionTC( "Verify if the class is not having success maker product will not display" );
            Log.assertThat( !studentsPage.isGroupnamePresentInAddStudentPopup( withoutProduct ), "Without successmaker product group is not displayed!", "Without successmaker product group is displayed!" );

        } catch ( Exception e ) {
            e.printStackTrace();
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
