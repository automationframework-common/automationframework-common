package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.homepage.HomePage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sql.helper.FixupFunction;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.response.Response;

public class GetIpmAssessments extends EnvProperties {

    private String smUrl;
    private String teacherDetails;
    private String teacherUsername;
    private String teacherUserId;
    private String orgId;
    private String studentDetails;
    private String studentUsername;
    private String studentUserId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private List<String> studentRumbaIds = new ArrayList<>();
    private Map<String, String> courseName = new HashMap<>();
    private Map<String, String> courseIds = new HashMap<>();
    private Map<String, String> assignmentIds = new HashMap<>();
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String browser;
    String assignmentUserId;

    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {
        // Retrieving URL from Config.properites
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        studentDetails = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );

        //Reading Course Names
        courseName.put( Constants.READING, AssignmentAPIConstants.READING_COURSE );
        courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );

        String teacherAccessToken = null;
        try {
            teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Issue in get the accces token - " + e.getMessage() );
            try {
                Log.message( "Retrying to get the access token!!!!" );
                teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            } catch ( Exception e1 ) {
                Log.fail( "Unable to create the access token for the teacher - " + teacherUsername );
            }
        }

        //Reading course Ids
        courseIds.put( Constants.READING, AssignmentAPIConstants.READING );
        courseIds.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        courseIds.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE,
                new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SKILL, courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );

        courseIds.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE,
                new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
        try {
            courseIds.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );

        } catch ( Exception e ) {
            Log.message( "Issue in Reading Custom course creation!! - " + e.getMessage() );
        }

        Log.message( "Course Ids for " + school + ": " + courseIds );

        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        staffDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        try {
            //Assigning Assignment
            Log.message( "Assigning assignment..." );

            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, studentRumbaIds, new ArrayList<>( courseIds.values() ) );
            Log.message( "Assignment Response : " + assignmentResponse );

            JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
            JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

            for ( Object assignment : assignmentList ) {
                JSONObject assignmentInfo = new JSONObject( assignment.toString() );
                assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
            }
            Log.message( "Assignment IDs - " + assignmentIds );
        } catch ( Exception e ) {
            Log.fail( "Issue in Assigning the assignment to the student!! - " + e.getMessage() );
        }
    }

    @Test ( priority = 1, dataProvider = "studentUsagePositive", groups = { "smoke_test_case", "SMK-67544", "Students", "k2ipm", "P1", "API" } )
    public void tcPositiveTestcases( String tcId, String description, String scenario, String statusCode ) throws Throwable {
        Log.testCaseInfo( tcId + ":-" + description );
       // Response response = null;
        String body = "";
      Map<String, String> response = new HashMap<>();
        String sessionId;
        String apiResponse ="";
        String assementIPMDB ="";
        switch ( scenario ) {
            case "VALID__DEFAULTREADING":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.READING ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = ipmReadingAssessmentsGet( smUrl, studentUserId, orgId, sessionId );
                Log.message(response.get("body"));
                new RBSUtils().getAccessToken( studentUsername, password );
                Log.message("**The Acutal Status code is**" +""+response.get( Constants.STATUS_CODE ) );
                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                apiResponse = response.get("body").toString().replaceAll("\"", "");
                assementIPMDB = getDBassementIPMData();
                Log.assertThat(apiResponse.contains( assementIPMDB ), "IPM Assesment data is matching with DB", "IPM Assesment data is not matching with DB" );
                break;
                   
            case "VALID__SETTINGSREADING":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = ipmReadingAssessmentsGet( smUrl, studentUserId, orgId, sessionId );
                Log.message(response.get("body"));
                Log.message("**The Acutal Status code is**" +""+response.get( Constants.STATUS_CODE ) );
                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                apiResponse = response.get("body").toString().replaceAll("\"", "");
                assementIPMDB = getDBassementIPMData();
                Log.assertThat(apiResponse.contains( assementIPMDB ), "IPM Assesment data is matching with DB", "IPM Assesment data is not matching with DB" );
                break;

            case "VALID__SKILLREADING":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = ipmReadingAssessmentsGet( smUrl, studentUserId, orgId,  sessionId );
                Log.message(response.get("body"));
                Log.message("**The Acutal Status code is**" +""+response.get( Constants.STATUS_CODE ) );
                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                apiResponse = response.get("body").toString().replaceAll("\"", "");
                assementIPMDB = getDBassementIPMData();
                Log.assertThat(apiResponse.contains( assementIPMDB ), "IPM Assesment data is matching with DB", "IPM Assesment data is not matching with DB" );
                break;

            case "VALID__STANDARDSREADING":

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = ipmReadingAssessmentsGet( smUrl, studentUserId, orgId,  sessionId );
                Log.message(response.get("body"));
                Log.message("**The Acutal Status code is**" +""+response.get( Constants.STATUS_CODE ) );
                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                apiResponse = response.get("body").toString().replaceAll("\"", "");
                assementIPMDB = getDBassementIPMData();
                Log.assertThat(apiResponse.contains( assementIPMDB ), "IPM Assesment data is matching with DB", "IPM Assesment data is not matching with DB" );
                break;
                 
        }

    }

    @DataProvider ( name = "studentUsagePositive" )
    public Object[][] studentUsagePositive() {

        Object[][] inputData = {
                { "TC_001GETIpmReading", "Verify the status code is 200 when valid data is given for assignment which has been created from Custom Reading(custom by setting) for GET Method.", "VALID__DEFAULTREADING", CommonAPIConstants.STATUS_CODE_OK },
                { "TC_002GETIpmReading", "Verify the status code is 200 when valid data is given for assignment which has been created from Deafult Reading for GET Method.", "VALID__SETTINGSREADING", CommonAPIConstants.STATUS_CODE_OK },
                { "TC_003GETIpmReading", "Verify the status code is 200 when valid data is given for assignment which has been created from Custom Reading(custom by skills) for GET Method.", "VALID__SKILLREADING", CommonAPIConstants.STATUS_CODE_OK },
                { "TC_004GETIpmReading", "Verify the status code is 200 when valid data is given for assignment which has been created from Custom Reading(custom by Standard) for GET Method.", "VALID__STANDARDSREADING",
                        CommonAPIConstants.STATUS_CODE_OK }};

        return inputData;
    }

    /**
     * To Create and get the session Id for given student
     *
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @return
     */
    public String getSessionId( String smUrl, String userId, String orgId, String studentUsername, String password, String assignmentUserId ) {
        String endPoint1 = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        List<String> pathParamsList = new ArrayList<>();
        HashMap<String, String> header = new HashMap<>();
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( LicenseAPIConstants.USERID, userId );
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        pathParamsList.add( assignmentUserId );
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint1, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, header, endPoint1, pathParams );
        Log.message( response.getBody().asString() );
        String sessionId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "sessionId" );
        Log.message( "Session ID  - " + sessionId );
        return sessionId;
    }

    /**
     * To get IPM complete student completed the assignment
     * 
     * @param smUrl
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @param sessionId
     * @return
     * @throws Throwable 
     */
    public HashMap<String, String> ipmReadingAssessmentsGet( String smUrl, String userId, String orgId, String sessionId ) throws Throwable {
        String endPoint = LicenseAPIConstants.GET_K2IPM_ASSESSMENTS;
        Log.message("The endpoint is ****" +endPoint);
        //Parameters
        HashMap<String, String> params = new HashMap<>();
        Map<String, String> header = new HashMap<>();
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + "" + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            Log.fail( "Issue in getting the accesstoken for student - " + studentUsername );
        }
        header.put( LicenseAPIConstants.USERID, userId );
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( "session-id", sessionId );
        params.put("_", String.valueOf(System.nanoTime()));
        return RestHttpClientUtil.GET( smUrl,endPoint, header, params );
       
    }
    
    public static String getDBassementIPMData() {
        String queryString = "SELECT string_agg(assessment_item_name,',' order by assessment_item_name) FROM assessment_item ai WHERE ai.k2ipm_inclusion_assessment_item = 1";
        List<Object[]> result = SQLUtil.executeQuery( queryString );
        String details = null;        
        for ( Object[] list : result ) {
            details = list[0].toString();
       }
        return details;
    }

}
