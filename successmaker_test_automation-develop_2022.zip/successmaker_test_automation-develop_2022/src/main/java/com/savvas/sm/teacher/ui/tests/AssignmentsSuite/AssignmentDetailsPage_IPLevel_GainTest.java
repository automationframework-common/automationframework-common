package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

@Listeners(EmailReport.class)
public class AssignmentDetailsPage_IPLevel_GainTest extends BaseTest {

	private String smUrl;
	private String browser;
	private String staticCourseName = null;
	private static String username = null;
	private static String password = DataSetupConstants.DEFAULT_PASSWORD;
	private String flexSchoolTeacherDetails = null;
	private String token = null;
	private static String teacherDetails;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String teacherID;
	private String schoolID;
	String studentDetails;
	String studentDetailsSecond;
	String studentUsername;
	String customSkillCourseMath = Constants.CUSTOM_BY_SKILLS_MATH_COURSE + System.nanoTime();
	String customStandardsReading = Constants.CUSTOM_BY_STANDARDS_READING_COURSE + System.nanoTime();
	String customStandardsMath = Constants.CUSTOM_BY_STANDARDS_MATH_COURSE + System.nanoTime();
	CoursesPage coursepage;

	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");

		teacherDetails = RBSDataSetup.getMyTeacher(school);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		studentDetails = RBSDataSetup.getMyStudent(school, username);
		studentDetailsSecond = RBSDataSetup.getMyStudent(school, username);
		studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, "userName");

	}

	@Test(description = "Verify the columns displayed in the assignment details page", groups = { "Assignments",
			"SMK-44523", "Assignment_Details" }, priority = 1)
	public void tcAssignmentDetailsIPGain001() throws Throwable {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data

		Log.testCaseInfo("tcAssignmentDetailsIPGain001: SMK-11003: Verify the columns displayed in the assignment details page. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			customCourses.verifyCourseRemovedSuccessfully(staticCourseName);
			customCourses.clickCourseName(staticCourseName);
			customCourses.clickAssignBtn();
			customCourses.addCourseToGroups();
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			List<String> columnNamesFromPage = assignmentDetailsPage.getNamesFromAssignmentDetailsPage();
			Log.message(columnNamesFromPage.toString());
			Log.assertThat((columnNamesFromPage).equals(Constants.ASSIGNMENT_DETAILS),"Columns are displayed correctly", "Columns are not displayed correctly");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that Assign button is available in the assignment details page under the assignment title", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 2)
	public void tcAssignmentDetailsIPGain002() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain002: SMK-11006: Verify that Assign button is available in the assignment details page under the assignment title. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName()+System.nanoTime();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			customCourses.verifyCourseRemovedSuccessfully(staticCourseName);
			customCourses.clickCourseName(staticCourseName);
			customCourses.clickAssignBtn();
			customCourses.addCourseToGroups();
			
			
		// Navigate to Courseware tab
		    AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();
			Log.assertThat(assignmentDetailsPage.assignElement().isDisplayed(), "Assign button is displayed","Assign button is not displayed");
			
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that you are able to assign the assignment to students or groups when you click on the Assign button", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 3)
	public void tcAssignmentDetailsIPGain003() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain003: SMK-11007: Verify that you are able to assign the assignment to students or groups when you click on the Assign button. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName()+System.nanoTime();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			customCourses.verifyCourseRemovedSuccessfully(staticCourseName);
			customCourses.clickCourseName(staticCourseName);
			customCourses.clickAssignBtn();
			customCourses.addCourseToGroups();
			
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
		//	AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();
			Log.assertThat(assignmentDetailsPage.assignElement().isDisplayed(), "Assign button is displayed","Assign button is not displayed");
			assignmentDetailsPage.clickAssignButton();
			assignmentDetailsPage.assignAssignmentToStudents();
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the options available when you click on the Ellipses(...) available for assignment available near the Assign button", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 4)
	public void tcAssignmentDetailsIPGain004() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain004: SMK-11008: Verify the options available when you click on the Ellipses(...) available for assignment available near the Assign button. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName()+System.nanoTime();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			customCourses.verifyCourseRemovedSuccessfully(staticCourseName);
			customCourses.clickCourseName(staticCourseName);
			customCourses.clickAssignBtn();
			customCourses.addCourseToGroups();
			
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),"Assignment Title is displayed", "Assignment Title is not displayed");
//			AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();
			// Click on Dot ellipsis
			assignmentDetailsPage.assignmentLevelEllipsis();
			Log.assertThat(assignmentDetailsPage.assignmenttSettingTabTopEllipsis().equals(Constants.ASSIGMENT_SETTINGS),
					"Assignment Settings is displayed", "Assignment Settings is not displayed");
			Log.assertThat(assignmentDetailsPage.pauseAllStudentTopEllipsis().equals(Constants.PAUSED_ALL_STUDENTS),
					"Pause All Students is displayed", "Pause All Students is not displayed");
			Log.assertThat(assignmentDetailsPage.deleteAssignmenttabTopEllipsis().equals(Constants.DELETED_ASSIGNMENT),
					"Delete Assignment is displayed", "Delete Assignment is not displayed");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the options available when you click on the Ellipses(...) available for each student listed in the assignment details page", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 5)
	public void tcAssignmentDetailsIPGain005() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain005: SMK-11009: Verify the options available when you click on the Ellipses(...) available for each student listed in the assignment details page<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName()+System.nanoTime();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			customCourses.verifyCourseRemovedSuccessfully(staticCourseName);
			customCourses.clickCourseName(staticCourseName);
			customCourses.clickAssignBtn();
			customCourses.addCourseToGroups();
			
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),"Assignment Title is displayed", "Assignment Title is not displayed");
		//	AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();
			// Clicking on Ellipsis icon at the student level
			assignmentDetailsPage.clickDotEllipsisButton();
			Log.assertThat(assignmentDetailsPage.fluencyFilesInEllipsis().contains(Constants.FLUENCY_FILES),"Fluency Files option is displayed", "Fluency_Files option is not displayed");
			Log.assertThat(assignmentDetailsPage.assignmentSettingInEllipsis().equals(Constants.ASSIGMENT_SETTINGS),"Assignment Settings option is displayed", "Assignment Settings option is not displayed");
			Log.assertThat(assignmentDetailsPage.pauseAssignmentForStudentTabInEllipsis().equals(Constants.PAUSE_ASSIGNMENT_FOR_STUDENTS),
					"Pause Assignment For Student option is displayed",
					"Pause_Assignment_For_Student option is not displayed");
			Log.assertThat(assignmentDetailsPage.removeStudentTabInEllipsis().equals(Constants.REMOVE_STUDENTS),
					"Remove Student option is displayed", "Remove Student option is not displayed");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify when you click on the Edit Assignment Settings option from the Ellipsis menu for a student, Edit Assignment Settings is displayed.", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 6)
	public void tcAssignmentDetailsIPGain006() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain006: SMK-11012: Verify when you click on the Edit Assignment Settings option from the Ellipsis menu for a student, Edit Assignment Settings is displayed.<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName()+System.nanoTime();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			customCourses.verifyCourseRemovedSuccessfully(staticCourseName);
			customCourses.clickCourseName(staticCourseName);
			customCourses.clickAssignBtn();
			customCourses.addCourseToGroups();
			
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),"Assignment Title is displayed", "Assignment Title is not displayed");
		//	AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();
			String firstStudentsName = assignmentDetailsPage.getFirstStudentsName();
			assignmentDetailsPage.clickEllipsesOfStudent(firstStudentsName);
			assignmentDetailsPage.assignmentSettingStudentTab();
			Log.assertThat(assignmentDetailsPage.getEditSettingsPopupTitle().equals(Constants.EDIT_SETTINGS_POPUP_TITLE),"Edit Settings Popup is displayed", "Edit Settings Popup is not displayed");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify when you click on the Pause/Resume Assignment for Student option from the Ellipsis menu for a student, Pause/Resume Assignment Confirmation popup is displayed.", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 7)
	public void tcAssignmentDetailsIPGain007() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain007: SMK-11013: Verify when you click on the Pause/Resume Assignment for Student option from the Ellipsis menu for a student, Pause/Resume Assignment Confirmation popup is displayed.<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName()+System.nanoTime();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			customCourses.verifyCourseRemovedSuccessfully(staticCourseName);
			customCourses.clickCourseName(staticCourseName);
			customCourses.clickAssignBtn();
			customCourses.addCourseToGroups();
			
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),"Assignment Title is displayed", "Assignment Title is not displayed");
			
	//		AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();
			String firstStudentsName = assignmentDetailsPage.getFirstStudentsName();
			assignmentDetailsPage.clickEllipsesOfStudent(firstStudentsName);
			assignmentDetailsPage.pauseAssignmentStudentTab();
			Log.assertThat(assignmentDetailsPage.isPauseStudentPopUpDisplayed(), "Pause Student Popup is displayed","Pause Student Popup is not displayed");
			assignmentDetailsPage.clickPauseButtononPopUpPage();
		//	assignmentDetailsPage.popupClose();
			SMUtils.nap(5);
			assignmentDetailsPage.clickEllipsesOfStudent(firstStudentsName);
			assignmentDetailsPage.resumeAssignmentStudentTab();
			Log.assertThat(assignmentDetailsPage.isResumeStudentPopUpDisplayed(), "Resume Student Popup is displayed","Resume Student Popup is not displayed");
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify when you click on the Remove Student option from the Ellipsis menu for a student, Remove Student Confirmation popup is displayed.", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 8)
	public void tcAssignmentDetailsIPGain008() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain008: SMK-11014: Verify when you click on the Remove Student option from the Ellipsis menu for a student, Remove Student Confirmation popup is displayed.<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName()+System.nanoTime();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			customCourses.verifyCourseRemovedSuccessfully(staticCourseName);
			customCourses.clickCourseName(staticCourseName);
			customCourses.clickAssignBtn();
			customCourses.addCourseToGroups();
			
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),	"Assignment Title is displayed", "Assignment Title is not displayed");
			
		//	assignmentDetailsPage = page.clickViewAssignment();
			// Click on Assignment Settings for first student
			String firstStudentsName = assignmentDetailsPage.getFirstStudentsName();
			assignmentDetailsPage.clickEllipsesOfStudent(firstStudentsName);
			assignmentDetailsPage.removeStudentTab();
			Log.assertThat(assignmentDetailsPage.isRemoveStudentPopUpDisplayed(), "Remove Student Popup is displayed","Remove Student Popup is not displayed");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that when you click on the + icon near the Student name you are able to see the skills tested tab for the student.", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 9)
	public void tcAssignmentDetailsIPGain009() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain009: SMK-11015: Verify that when you click on the + icon near the Student name you are able to see the skills tested tab for the student<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName()+System.nanoTime();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			customCourses.verifyCourseRemovedSuccessfully(staticCourseName);
			customCourses.clickCourseName(staticCourseName);
			customCourses.clickAssignBtn();
			customCourses.addCourseToGroups();
			
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),"Assignment Title is displayed", "Assignment Title is not displayed");
		//	AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();
			String firstStudentsName = assignmentDetailsPage.getFirstStudentsName();
			assignmentDetailsPage.clickStudentAccordionButton(firstStudentsName);
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(), "Skills Tested Tab is displayed","Skills Tested Tab is not displayed");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the IP level is NA for the Reading Focus course when the student has not started working on the assignment.", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 10)
	public void tcAssignmentDetailsIPGain010() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain010: SMK-11018: Verify that the IP level is NA for the Reading Focus course when the student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickCourseName(Constants.SM_FOCUS_READING_GRADE2);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page
					.viewAssignmentDetailsByAssignmentName(Constants.READING_FOCUS_COURSE_TITLE);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(Constants.READING_FOCUS_COURSE_TITLE),
					"Assignment Title is displayed", "Assignment Title is not displayed");
			Log.assertThat(assignmentDetailsPage.ipLevelValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"IP level is NA for the Reading Focus course when the student has not started working on the assignment",
					"IP level is not NA for the Reading Focus course when the student has not started working on the assignment");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the IP level is NA for the Math Focus course when the student has not started working on the assignment.", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 11)
	public void tcAssignmentDetailsIPGain011() throws Throwable {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain011: SMK-11019: Verify that the IP level is NA for the Math Focus course when the student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickCourseName(Constants.SM_FOCUS_MATH_GRADE1);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(Constants.MATH_FOCUS_COURSE_TITLE);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(Constants.MATH_FOCUS_COURSE_TITLE),
					"Assignment Title is displayed", "Assignment Title is not displayed");
			Log.assertThat(assignmentDetailsPage.ipLevelValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"IP level is NA for the Math Focus course when the student has not started working on the assignment",
					"IP level is not NA for the Math Focus course when the student has not started working on the assignment");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the IP level is NA for the Reading Custom course by Skills when the student has not started working on the assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 12)
	public void tcAssignmentDetailsIPGain012() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain012: SMK-11020: Verify that the IP level is NA for the Reading Custom course by Skills when the student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			
			String Custom_By_Skills_Course = Constants.CUSTOM_BY_SKILLS_COURSE + System.nanoTime();
			// Make a copy of the course
			customCourses.copyOfCourse(Custom_By_Skills_Course, Constants.SKILLS, Constants.READING);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			customCourses.verifyCourseRemovedSuccessfully(Custom_By_Skills_Course);
			customCourses.clickCourseName(Custom_By_Skills_Course);
			customCourses.clickAssignBtn();
			customCourses.addCourseToStudents();
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page
					.viewAssignmentDetailsByAssignmentName(Custom_By_Skills_Course);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.ipLevelValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"IP level is NA for the Reading Custom By Skills course when the student has not started working on the assignment",
					"IP level is not NA for the Reading Custom By Skills course when the student has not started working on the assignment");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the IP level is NA for the Math Custom course by Skills when the student has not started working on the assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 13)
	public void tcAssignmentDetailsIPGain013() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain013: SMK-11021: Verify that the IP level is NA for the Math Custom course by Skills when the student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(customSkillCourseMath, Constants.SKILLS, Constants.MATH);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(Constants.CUSTOM_BY_SKILLS_MATH_COURSE);
			coursePage.clickCourseName(customSkillCourseMath);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page
					.viewAssignmentDetailsByAssignmentName(customSkillCourseMath);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.ipLevelValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"IP level is NA for the Math Custom By Skills course when the student has not started working on the assignment",
					"IP level is not NA for the Math Custom By Skills course when the student has not started working on the assignment");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the IP level is NA for the Reading Custom course by Standards when the student has not started working on the assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 14)
	public void tcAssignmentDetailsIPGain014() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain014: SMK-11022: Verify that the IP level is NA for the Reading Custom course by Standards when the student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(customStandardsReading, Constants.STANDARDS, Constants.READING);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			customCourses.verifyCourseRemovedSuccessfully(customStandardsReading);
			customCourses.clickCourseName(customStandardsReading);
			customCourses.clickAssignBtn();
			customCourses.addCourseToStudents();
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(customStandardsReading);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.ipLevelValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"IP level is NA for the Reading Custom By Standards course when the student has not started working on the assignment",
					"IP level is not NA for the Reading Custom By Standards course when the student has not started working on the assignment");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the IP level is NA for the Math Custom course by Standards when the student has not started working on the assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 15)
	public void tcAssignmentDetailsIPGain015() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain015: SMK-11023: Verify that the IP level is NA for the Math Custom course by Standards when the student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			// Make a copy of the course
			customCourses.copyOfCourse(customStandardsMath, Constants.STANDARDS, Constants.MATH);
			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);
			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);
			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(customStandardsMath);
			coursePage.clickCourseName(customStandardsMath);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(customStandardsMath);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.ipLevelValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"IP level is NA for the Math Custom By Standards course when the student has not started working on the assignment",
					"IP level is not NA for the Math Custom By Standards course when the student has not started working on the assignment");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the IP level is -- for the Default and Custom course by settings when the Initial Placement(IP) setting is ON and student has not started working on the assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 16)
	public void tcAssignmentDetailsIPGain016() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain016: SMK-11027: Verify that the IP level is -- for the Default and Custom course by settings when the Initial Placement(IP) setting is ON and student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName  = customCourses.generateRandomCourseName() + System.nanoTime();
			coursePage.clickReadingCourse();
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(Constants.READING);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.ipLevelValueChecking(firstStudentName).equals(Constants.NOT_STARTED_VALUE),
					"IP level is -- for the Default courses when the Initial Placement(IP) setting is ON and student has not started working on the assignment",
					"IP level is not -- for the Default courses when the Initial Placement(IP) setting is ON and student has not started working on the assignment");
			tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickMathCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(staticCourseName);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();
			// Verify that Initial placement is ON by default.
			coursePage.verifyInitialPlacementIsON();
			coursePage.clickCreateBtn();
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(assignmentDetailsPage.ipLevelValueChecking(firstStudentName).equals(Constants.NOT_STARTED_VALUE),
					"IP level is -- for the Custom course by settings when the Initial Placement(IP) setting is ON and student has not started working on the assignment",
					"IP level is not -- for the Custom course by settings when the Initial Placement(IP) setting is ON and student has not started working on the assignment");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the IP level is -- for the Custom course by settings when the Initial Placement(IP) setting is OFF and student has not started working on the assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 17)
	public void tcAssignmentDetailsIPGain017() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain017: SMK-11028: Verify that the IP level is -- for the Custom course by settings when the Initial Placement(IP) setting is OFF and student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			coursePage.clickReadingCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(staticCourseName);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();
			// Verify that Initial placement is ON by default.
			coursePage.verifyInitialPlacementIsON();
			// Turn OFF Initial placement
			coursePage.turnOffInitialPlacement();
			coursePage.clickCreateBtn();
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			SMUtils.nap(3);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.ipLevelValueChecking(firstStudentName).equals(Constants.NOT_STARTED_VALUE),
					"IP level is -- for the Custom course by settings when the Initial Placement(IP) setting is OFF and student has not started working on the assignment",
					"IP level is not -- for the Custom course by settings when the Initial Placement(IP) setting is OFF and student has not started working on the assignment");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the Gain is NA for the Focus courses, custom courses by skills and custom courses by standard when the student has not started working on the assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 18)
	public void tcAssignmentDetailsIPGain018() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain018: SMK-11026: Verify that the Gain is NA for the Focus courses, custom courses by skills and custom courses by standard when the student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickCourseName(Constants.SM_FOCUS_MATH_GRADE1);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page
					.viewAssignmentDetailsByAssignmentName(Constants.MATH_FOCUS_COURSE_TITLE);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(Constants.MATH_FOCUS_COURSE_TITLE),
					"Assignment Title is displayed", "Assignment Title is not displayed");
			Log.assertThat(assignmentDetailsPage.gainValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),"Gain is NA for the Focus courses, when the student has not started working on the assignment",
					"Gain is not NA for the Focus courses, when the student has not started working on the assignment");
			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			page.viewAssignmentDetailsByAssignmentName(customSkillCourseMath);
			Log.assertThat(assignmentDetailsPage.gainValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),"Gain is NA for the Custom By Skills course when the student has not started working on the assignment",
					"Gain is not NA for the Custom By Skills course when the student has not started working on the assignment"); 
																																	
			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			page.viewAssignmentDetailsByAssignmentName(customStandardsMath);
			Log.assertThat(assignmentDetailsPage.gainValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),"Gain is NA for the Custom By Standards course when the student has not started working on the assignment",
					"Gain is not NA for the Custom By Standards course when the student has not started working on the assignment");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the Gain is -- for the Default courses, custom course by settings when the Initial Placement(IP) setting is ON and student has not started working on the assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 19)
	public void tcAssignmentDetailsIPGain019() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain019: SMK-11030: Verify that the Gain is -- for the Default courses, custom course by settings when the Initial Placement(IP) setting is ON and student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName()+System.nanoTime();
			coursePage.clickMathCourse();
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(Constants.READING);
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.gainValueChecking(firstStudentName).equals(Constants.NOT_STARTED_VALUE),"Gain is -- for the Default courses when the Initial Placement(IP) setting is ON and student has not started working on the assignment",
					"Gain is not -- for the Default courses when the Initial Placement(IP) setting is ON and student has not started working on the assignment");
			tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickReadingCourse();
			coursePage.clickMakeCopyBtn();
			coursePage.enterCourseName(staticCourseName);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();
			// Verify that Initial placement is ON by default.
			coursePage.verifyInitialPlacementIsON();
			coursePage.clickCreateBtn();
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			SMUtils.nap(3);
			page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(assignmentDetailsPage.gainValueChecking(firstStudentName).equals(Constants.NOT_STARTED_VALUE),
					"Gain is -- for the Custom course by settings when the Initial Placement(IP) setting is ON and student has not started working on the assignment",
					"Gain is not -- for the Custom course by settings when the Initial Placement(IP) setting is ON and student has not started working on the assignment");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the Current level is NA for the Focus Courses when the student has not started working on the assignment", groups = {
			"Assignments", "SMK-44523", "Assignment_Details" }, priority = 20)
	public void tcAssignmentDetailsIPGain020() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo("tcAssignmentDetailsIPGain020: SMK-11043: Verify that the Current level is NA for the Focus Courses when the student has not started working on the assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			// Navigate to Courseware tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(Constants.READING_FOCUS_COURSE_TITLE);

			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(Constants.READING_FOCUS_COURSE_TITLE),
					"Assignment Title is displayed", "Assignment Title is not displayed");
			String firstStudentName = assignmentDetailsPage.getFirstStudentsName();
			Log.assertThat(assignmentDetailsPage.currentLevelValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),
					"Current Level is NA for the Focus courses when the student has not started working on the assignment",
					"Current Level is not NA for the Focus courses when the student has not started working on the assignment");
			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(customSkillCourseMath);
			Log.assertThat(assignmentDetailsPage.currentLevelValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),"Current Level is NA for the Custom By Skills course when the student has not started working on the assignment",
					"Current Level is not NA for the Custom By Skills course when the student has not started working on the assignment");
			// Navigate to Courseware tab
			tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			page.viewAssignmentDetailsByAssignmentName(customStandardsMath);
			Log.assertThat(assignmentDetailsPage.currentLevelValueChecking(firstStudentName).equals(Constants.NOT_APPLICABLE_VALUE),"Current Level is NA for the Custom By Standards course when the student has not started working on the assignment",
					"Current Level is not NA for the Custom By Standards course when the student has not started working on the assignment");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}
}
