package com.savvas.sm.api.tests.smnew.groups;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.getGroupListAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

/**
 * To test the create group API
 * 
 * @author nishanth.kamaraj
 *
 */

public class UpdateGroupAPITest extends GroupAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    // Teacher variable used for this class
    private String orgUsed = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String orgUsed2 = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String teacherUsed;
    private String studentUsed;
    private String studentUsed1;
    private String studentUsed2;
    private String teacherUsed2;
    private String otherSchoolTeacherUsed;
    String orgId;
    String teacherId;
    String teacherUsername;
    String username;
    String org1TeacherId2;
    String org1TeacherUsername;

    // other school teacher details
    private String org2Id;
    private String org2TeacherId1;
    private String org2TeacherUsername1;

    public String teacherDetails1;
    public String teacherDetails2;
    public String teacherDetails3;
    public String teacherDetails4;

    RBSUtils rbs = new RBSUtils();

    public String teacherDetailsOne;
    public String teacherDetailsTwo;
    public String teacherDetailsThree;

    public String userId;
    public String userId2;
    public String userId3;
    public String username2;
    public String product;
    public String stuId;
    public String stuUsername;
    public String stuId1;
    public String stuId2;
    public String stuId3;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        // Teacher used Details
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        teacherUsed = RBSDataSetup.getMyTeacher( orgUsed );
        teacherId = SMUtils.getKeyValueFromResponse( teacherUsed, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherUsed, "userName" );

        // Teacher 2 Details
        teacherUsed2 = RBSDataSetup.getMyTeacher( orgUsed );
        org1TeacherId2 = SMUtils.getKeyValueFromResponse( teacherUsed2, "userId" );
        org1TeacherUsername = SMUtils.getKeyValueFromResponse( teacherUsed2, "userName" );
        // Other School Details
        org2Id = RBSDataSetup.organizationIDs.get( orgUsed2 );
        otherSchoolTeacherUsed = RBSDataSetup.getMyTeacher( orgUsed2 );
        org2TeacherId1 = SMUtils.getKeyValueFromResponse( otherSchoolTeacherUsed, "userId" );
        org2TeacherUsername1 = SMUtils.getKeyValueFromResponse( otherSchoolTeacherUsed, "userName" );

        product = configProperty.getProperty( "mathOnlyProduct" );

        studentUsed = RBSDataSetup.getMyStudent( orgUsed, teacherUsername );
        stuId = SMUtils.getKeyValueFromResponse( studentUsed, "userId" );
        stuUsername = SMUtils.getKeyValueFromResponse( studentUsed, "userName" );
        studentUsed1 = RBSDataSetup.getMyStudent( orgUsed, teacherUsername );
        stuId1 = SMUtils.getKeyValueFromResponse( studentUsed1, "userId" );
        studentUsed2 = RBSDataSetup.getMyStudent( orgUsed, teacherUsername );
        stuId2 = SMUtils.getKeyValueFromResponse( studentUsed2, "userId" );
    }

    @Test ( dataProvider = "updateGroupPositiveScenariosData", groups = { "smoke_test_case", "Smoke TC001_UpdateGroup", "upadate Group", "P1", "SMK-50200", "Group", "upadate Group", "P1", "API" } )
    public void tcUpdategroup001( String description, String scenario, String statusCode ) throws Exception {
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        List<String> schools = new ArrayList<>();
        String multiSchoolTeacher = null;
        HashMap<String, String> response1;

        String groupName = "Successmaker API Test Group " + System.nanoTime();
        // String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        HashMap<String, String> userDetails = new HashMap<>();
        switch ( scenario ) {

            case "VALID SCENARIO":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                studentRumbaIds.add( stuId );
                HashMap<String, String> response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, groupId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );
                break;

            case "GROUP WITH SHARED STUDENT":
                String multiSchoolStudent = "MultiSchStudent" + System.nanoTime();
                studentRumbaIds.add( stuId );

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

                schools.add( RBSDataSetup.organizationIDs.get( school ) );
                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                String finalSchool = "";
                for ( String school : schools ) {
                    finalSchool += school.concat( "\",\"" );
                }
                finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
                String multiSchoolStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( multiSchoolStudentID );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String sharedStudentGroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, sharedStudentGroupId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                break;

            case "GROUP WITH MULTIPLE SCHOOL TEACHER":
                multiSchoolTeacher = "MultiSchTeacher" + System.nanoTime();

                studentRumbaIds.add( stuId );

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                String listString = "";
                for ( String school : schools ) {
                    listString += school.concat( "\",\"" );
                }
                listString = listString.substring( 0, listString.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
                String multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );

                String MultiGrpId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );

                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, MultiGrpId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );
                break;

            case "GROUP WITHOUT STUDENT":

                Log.message( "Verify the Group if it is not associated with any product" );
                Log.message( "Verify the Group is updated if it have No Students" );
                studentRumbaIds.add( stuId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String emptygroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, emptygroupId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                break;

            case "GROUP WITH STUDENTS":
                studentRumbaIds.add( stuId );
                studentRumbaIds.add( stuId1 );
                studentRumbaIds.add( stuId2 );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String multipleStudWthgroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, multipleStudWthgroupId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );

                break;

            case "GROUP WITH ONE STUDENT":
                studentRumbaIds.add( stuId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String oneStudWithgroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, oneStudWithgroupId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                break;

            case "GROUP WITH DUPLICATE NAME":
                String duplicateName = "SuccessMakerDuplicate Group Test";
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, duplicateName );

                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String duplicateGroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, duplicateGroupId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, duplicateName );
                break;

            case "GROUP NAME WITH 3 CHAR":
                studentRumbaIds.add( stuId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String minCharGroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, minCharGroupId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.GROUP_NAME_WITH_MIN );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                break;

            case "GROUP NAME WITH 75 CHAR":
                studentRumbaIds.add( stuId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String maxCharGroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, maxCharGroupId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.GROUP_NAME_WITH_MAX );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );

                break;

            case "SHARED GROUP":

                String className1 = "Customize Shared Group " + System.currentTimeMillis();
                // String orgId1 = RBSDataSetup.organizationIDs.get( school );

                List<String> teachers = new ArrayList<String>();
                teachers.add( teacherId );
                teachers.add( org1TeacherId2 );

                List<String> stuIDs = new ArrayList<String>();
                stuIDs.add( stuId );
                stuIDs.add( stuId2 );

                // group created with Third party application
                groupDetails.put( RBSDataSetupConstants.USERNAME, org1TeacherUsername );
                groupDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                // groupDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                groupDetails.put( RBSDataSetupConstants.SECTION_NAME, className1 );
                String createClassWithMultipleTeacher1 = rbs.createClassWithMultipleTeacher( groupDetails, teachers, stuIDs );
                JSONObject jsonnObject2 = new JSONObject( createClassWithMultipleTeacher1 );
                String classId2 = jsonnObject2.getJSONObject( CreateGroupAPIConstants.DATA ).getJSONObject( CreateGroupAPIConstants.SECTION ).get( CreateGroupAPIConstants.ID ).toString();

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, classId2 );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, className1 + CreateGroupAPIConstants.UPDATED );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );

                break;

        }
        HashMap<String, String> putResponse = updateGroup( smUrl, groupDetails );
        Log.message( putResponse.toString() );
        Log.message( "Verify the updated group name should reflects in the CATCMS" );
        Log.assertThat( putResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + putResponse.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + putResponse.get( Constants.REPORT_BODY ) );
        String classDataFromCMS;
        if ( scenario.equalsIgnoreCase( "GROUP WITH MULTIPLE SCHOOL TEACHER" ) ) {
            classDataFromCMS = new RBSUtils().getClass( groupDetails.get( CreateGroupAPIConstants.GROUP_ID ) );
        } else {
            classDataFromCMS = new RBSUtils().getClass( groupDetails.get( CreateGroupAPIConstants.GROUP_ID ) );
        }
        Log.message( "cms response: " + classDataFromCMS );

        verifyResponse( classDataFromCMS, putResponse.get( Constants.REPORT_BODY ), groupDetails.get( CreateGroupAPIConstants.GROUP_NAME ) );

        //Schema validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "UpdateGroupSchemaSMK-51109", statusCode, putResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        Log.testCaseResult();

    }

    /**
     * Data provider to give the data of negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "updateGroupPositiveScenariosData" )
    public Object[][] updateGroupDataValid() {

        //Commented cases are has future backlog tickets since its excluded from execution
        Object[][] inputData = { { "Verify the response for Invalid Group id", "VALID SCENARIO", "200" }, { " Verify the group is updated if group is belonged to teacher who is part of multiple school", "GROUP WITH MULTIPLE SCHOOL TEACHER", "200" },
                { "Verify the Group is updated if it have multiple students", "GROUP WITH STUDENTS", "200" }, { "Verify the Group if it is not associated with successmaker product", "GROUP WITHOUT STUDENT", "200" },
                { "Verify the Group is updated if it have one students", "GROUP WITH ONE STUDENT", "200" }, { "Verify the group name is updated with duplicate group name", "GROUP WITH DUPLICATE NAME", "200" },
                { "Verify the Minimum 3 charac  can be given for group name", "GROUP NAME WITH 3 CHAR", "200" }, { "Verify the MinimMaximum 75 charac  can be given for group name", "GROUP NAME WITH 75 CHAR", "200" },
                { "Verify Group is Updated if group is shared group", "SHARED GROUP", "200" }, { "verify the Group is updated if the group has shared student", "GROUP WITH SHARED STUDENT", "200" }, };
        return inputData;
    }

    @Test ( dataProvider = "updateGroupNegativeScenariosData", groups = { "Smoke TC002_UpdateGroup", "upadate Group", "P1", "SMK-50200", "Group", "upadate Group", "P1", "API" } )
    public void tcUpdategroup002( String description, String scenario, String statusCode ) throws Exception {
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        HashMap<String, String> response = new HashMap<>();
        //String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        String exception = null;
        boolean status = false;
        String message = null;
        String groupName = "SM TEST UPDATE CLASS";

        switch ( scenario ) {

            case "INVALID GROUPID":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String emptygroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, getGroupListAPIConstants.INVALID_INPUT );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );
                exception = CommonAPIConstants.NO_CMS_CLASS_EXCEPTION;
                message = CommonAPIConstants.SECTION_ID_NOTFOUND_MESSAGE;
                status = true;
                break;

            case "STUDENT AUTHORIZATION":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( stuUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, stuId );

                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, groupId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );

                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "INVALID TEACHER":
                studentRumbaIds.add( stuId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String minCharGroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, minCharGroupId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );
                groupDetails.put( CreateGroupAPIConstants.INVALID_GROUP_OWNER_ID, getGroupListAPIConstants.INVALID_INPUT );
                exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                message = CommonAPIConstants.INVALID_UPDATED_MESSAGE;
                status = true;
                break;

            case "DELETED CLASS":

                Log.message( "Verify the API retuning data not found exception when the class is deleted from Easybridge. " );

                String className2 = "Deleted class" + System.currentTimeMillis();

                List<String> teachers2 = new ArrayList<String>();
                teachers2.add( teacherId );

                List<String> stuIDs2 = new ArrayList<String>();
                stuIDs2.add( stuId );

                // group created with Third party application

                groupDetails.put( RBSDataSetupConstants.USERNAME, teacherUsername );
                groupDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                groupDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, stuId );
                groupDetails.put( RBSDataSetupConstants.SECTION_NAME, className2 );

                String createClassWithMultipleTeacher3 = rbs.createClassWithMultipleTeacher( groupDetails, teachers2, stuIDs2 );
                JSONObject jsonnObject4 = new JSONObject( createClassWithMultipleTeacher3 );
                String classId = jsonnObject4.getJSONObject( CreateGroupAPIConstants.DATA ).getJSONObject( CreateGroupAPIConstants.SECTION ).get( CreateGroupAPIConstants.ID ).toString();
                rbs.deleteClass( classId, rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ), teacherId );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );

                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, classId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );

                exception = CommonAPIConstants.NO_CMS_CLASS_EXCEPTION;
                message = CommonAPIConstants.SECTION_ID_NOTFOUND_MESSAGE;
                status = true;
                break;

            case "OTHER GROUP WITH OTHER TEACHER ID":
                Log.message( "Verify the response if use Other teacher Group id" );
                Log.message( "Verify other school group is getting updated" );
                String groupName2 = "Class_otherteacher";
                List<String> teachers3 = new ArrayList<String>();
                teachers3.add( teacherId );
                teachers3.add( org1TeacherId2 );

                studentRumbaIds.add( stuId );

                groupDetails.put( RBSDataSetupConstants.USERNAME, org2TeacherUsername1 );
                groupDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, org2Id );
                groupDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, stuId );
                groupDetails.put( RBSDataSetupConstants.SECTION_NAME, groupName2 );
                String createClassWithMultipleTeacher4 = rbs.createClassWithMultipleTeacher( groupDetails, teachers3, studentRumbaIds );

                JSONObject jsonnObject5 = new JSONObject( createClassWithMultipleTeacher4 );
                String classIdDifferTeacher = jsonnObject5.getJSONObject( "data" ).getJSONObject( "section" ).get( "id" ).toString();

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, classIdDifferTeacher );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                break;

            case "INVALID TOKEN":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String InvalidTokengroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, getGroupListAPIConstants.INVALID_INPUT );

                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, InvalidTokengroupId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, CreateGroupAPIConstants.UPDATED_NAME_GRP );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

        }
        HashMap<String, String> putResponse = updateGroup( smUrl, groupDetails );
        Log.message( putResponse.toString() );
        Log.assertThat( putResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + putResponse.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + putResponse.get( Constants.REPORT_BODY ) );

        verifyException( putResponse.get( Constants.REPORT_BODY ), exception, status, message );
        //Schema validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "UpdateGroupSchemaSMK-51109", statusCode, putResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        Log.testCaseResult();

    }

    /**
     * Data provider to give the data of negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "updateGroupNegativeScenariosData" )
    public Object[][] updateGroupDataInvalid() {

        //Commented cases are has future backlog tickets since its excluded from execution
        Object[][] inputData = { { "Verify the response for Invalid Group id", "INVALID GROUPID", "404" }, { "Verify the Invalid Teacher id in the request body", "INVALID TEACHER", "400" },
                { "Verify the response for Expired Session", "INVALID TOKEN", "401" }, { "Verify the response for invalid authorization", "STUDENT AUTHORIZATION", "403" }, { "Verify the response if use deleted Group id", "DELETED CLASS", "404" },
                // { "Verify the response if use Other teacher Group id", "OTHER GROUP WITH OTHER TEACHER ID", "200" } 
        };
        return inputData;
    }

    /**
     * Verify the response data
     * 
     * @param expectedResponse
     * @param actualResponse
     * @param withStudent
     * @return
     */
    public boolean verifyResponse( String expectedResponse, String actualResponse, String newgroupname ) {
        boolean isVerified = false;
        try {

            if ( newgroupname.equals( SMUtils.getKeyValueFromResponse( expectedResponse, "roster,className" ) ) ) {
                // Log.message( newgroupname );
                Log.pass( "Group Name  verified as Expected!" );
                isVerified = true;
            } else {
                Log.fail( "Group Name is not returned as expected! Expected - " + SMUtils.getKeyValueFromResponse( expectedResponse, "roster,className" ) + "Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "data,groupName" ) );
            }
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).equalsIgnoreCase( "Group updated successfully" ) ) {
                Log.pass( "Message verified sucessfully" );
            } else {
                Log.pass( "Message is not verified  sucessfully" );
            }

            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "success" ) ) {
                Log.pass( "status verified sucessfully" );
            } else {
                Log.fail( "status is not verified  sucessfully" );
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isVerified;
    }

    /**
     * Verify the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) {
        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

}
