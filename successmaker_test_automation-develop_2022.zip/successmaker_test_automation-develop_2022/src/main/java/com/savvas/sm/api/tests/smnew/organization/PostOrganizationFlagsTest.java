package com.savvas.sm.api.tests.smnew.organization;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.OrganizationAPIConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

public class PostOrganizationFlagsTest extends UserAPI {

    private String smUrl;
    private String username;
    private String password;
    private String orgId;
    private String userId;
    private Map<String, String> response;

    @BeforeClass (alwaysRun = true)
    public void beforeTest() throws Exception {
        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty( Constants.APP_URL_FROM_CONFIG );
        orgId = configProperty.getProperty( Constants.ORG_ID_FROM_CONFIG );

        HashMap<String, String> userDetails = new HashMap<>();

        // Creating Admin user data to login
        String districtAdmin = "District_Admin" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_FROM_CONFIG ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, districtAdmin );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.ADMIN_ROLE );
        // Creating District Admin
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
        String adminDetails = new RBSUtils().createUser( userDetails );
        // Retrieving username and resetting password from the response
        username = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERNAME );
        new RBSUtils().resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID ) );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( dataProvider = "getData", groups = { "smoke_test_case","Smoke setOrganizationFlags001","post organization flags","P1","SMK-52630", "Set Organizations Flags", "API" }, priority = 1 )
    public void setOrganizationFlags001( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {

        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> params = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        // End point for API
        String endPoint = OrganizationAPIConstants.POST_ORGANIZATION_FLAGS;
        String responseMessage;
        Log.testCaseInfo( testcaseName + testcaseDescription );

        JSONObject requestBody = new JSONObject();
        requestBody.put( OrganizationAPIConstants.IS_DIAGNOSTIC_ENABLED, Boolean.TRUE );
        requestBody.put( OrganizationAPIConstants.IS_AUTOASSIGN_ENABLED, Boolean.TRUE );

        switch ( scenarioType ) {
            case "VALID":
                // Headers
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.USERID, userId );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody.toString() );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                Log.assertThat( responseMessage.equals( OrganizationAPIConstants.FLAGS_CREATED ), OrganizationAPIConstants.VALID_RESPONSE_MSG, OrganizationAPIConstants.INVALID_RESPONSE_MSG );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "postOrganizationFlags_SMK-52630", statusCode, response.get( Constants.BODY ) ), "Schema Validated for status code " + statusCode,
                        "Schema Validation failed for status code " + statusCode );
                break;
            case "SSO TOKEN NOT GIVEN":
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.USERID, userId );

                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody.toString() );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                // Validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "INVALID SSO TOKEN GIVEN":
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.USERID, userId );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) + Constants.INVALID );

                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody.toString() );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                // Validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "WITHOUT ORG_ID":
                headers.put( OrganizationAPIConstants.USERID, userId );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody.toString() );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                // Validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "WITHOUT USER_ID":
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody.toString() );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                // Validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "WITHOUT ORG_ID AND USER_ID":
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody.toString() );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                // Validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "INVALID USER_ID":
                // Headers
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.USERID, userId + Constants.INVALID );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody.toString() );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                // Validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "INVALID ORG_ID":
                // Headers
                headers.put( OrganizationAPIConstants.ORGID, orgId + Constants.INVALID );
                headers.put( OrganizationAPIConstants.USERID, userId );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody.toString() );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                // Validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();
                break;
            case "NO BODY":
                // Headers
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.USERID, userId );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, null );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                // Validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                Log.testCaseResult();

                break;
            case "NULL SET":
                // Headers
                headers.put( OrganizationAPIConstants.ORGID, orgId );
                headers.put( OrganizationAPIConstants.USERID, userId );
                headers.put( OrganizationAPIConstants.AUTHORISATION, OrganizationAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );

                requestBody = new JSONObject();
                requestBody.put( OrganizationAPIConstants.IS_DIAGNOSTIC_ENABLED, JSONObject.NULL );
                requestBody.put( OrganizationAPIConstants.IS_AUTOASSIGN_ENABLED, JSONObject.NULL );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody.toString() );
                String keyValueFromResponse = SMUtils.getKeyValueFromResponseWithArray( response.get( "body" ), "success" );
                responseMessage = new JSONArray( SMUtils.getKeyValueFromResponseWithArray( response.get( Constants.BODY ), Constants.MESSAGES ) ).getJSONObject( 0 ).get( Constants.MESSAGE ).toString();
                Log.assertThat( responseMessage.equals( OrganizationAPIConstants.INVALID_BODY_VALUE ), OrganizationAPIConstants.VALID_RESPONSE_MSG, OrganizationAPIConstants.INVALID_RESPONSE_MSG );
                Log.assertThat( Boolean.FALSE.toString().equals( keyValueFromResponse ), "Values for Organization Settings are invalid", "Values for Organization Settings are valid" );
                break;
        }
        Log.message( response.toString() );
        // Validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData() {
        return new Object[][] { { "TC001: ", "200", "Verify all the flags are successfully saved with response 200 response code for given district", "VALID" },
                { "TC002: ", "401", "Verify status code 401 when SSO token  is not passed in header parameter", "SSO TOKEN NOT GIVEN" },
                { "TC003: ", "401", "Verify status code 401 when invalid SSO token  is passed in header parameter", "INVALID SSO TOKEN GIVEN" }, { "TC004: ", "400", "Verify status code 400 when org_id not passed in header", "WITHOUT ORG_ID" },
                { "TC005: ", "401", "Verify status code 401 when user_id not passed in header", "WITHOUT USER_ID" }, { "TC006: ", "401", "Verify status code 401 when org_id and user_id not passed in header", "WITHOUT ORG_ID AND USER_ID" },
                { "TC007: ", "401", "Verify status code 401 when invalid user_id passed in header", "INVALID USER_ID" }, { "TC008: ", "403", "Verify status code 403 when invalid org_id passed in header", "INVALID ORG_ID" },
                { "TC009: ", "400", "Verify status code 400 when body not passed", "NO BODY" }, { "TC010: ", "200", "Verify status code 200 when flag set to null", "NULL SET" } };
    }
}