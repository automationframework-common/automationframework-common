package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class TopNavBar extends LoadableComponent<TopNavBar> {

    private WebDriver driver;
    boolean isPageLoaded;
    
    public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();

    private String logoSuccessMakerCSS = "#platformNavLogo img[src='./assets/sm_logo_colored.svg']";

    private String topNavHomeMenuCSSSelector = "#Home";
    private String topNavStudentsMenuCSSSelector = "#Students";
    private String topNavGroupsMenuCSSSelector = "#Groups";

    private String topNavCoursewareMenuCSSSelector = "a#Courseware";
    private String coursewareMenuItemsCSSSelectorwithShadow = "cel-dropdown-menu-box.hydrated";
    private String coursesSubMenuItemCSSSelector = "ul li:nth-child(2) a";

    private String topNavMasteryMenuCSSSelector = "#Mastery";

    private String topNavReportsMenuCSSSelector = "#Reports";
    private String reportsMenuItemsCSSSelectorwithShadow = "cel-dropdown-menu-box.hydrated";
    private String allReportSubMenuItemCSSSelector = "ul li a";
    private String cumulativePerformanceSubMenuItemCSSSelector = "ul li:nth-child(1) a";
    private String lastSessionSubMenuItemCSSSelector = "ul li:nth-child(2) a";
    private String studentPerformanceSubMenuItemCSSSelector = "ul li:nth-child(3) a";
    private String areaOfDifficultySubMenuItemCSSSelector = "ul li[aria-label='Areas of Difficulty'] a";

    private String userProfileMenuCSSSelector = ".platform__navbar--dropdown-menu";
    private String userProfileDropdownTriggerCSSSelector = ".dropdown-trigger";
    private String userProfileDropdownMenuItemsCSSSelector = "cel-dropdown-menu-box.hydrated";
    private String myProfileMenuItemCSSSelector = "ul li:nth-child(4)";
    private String signOutMenuItemCSSSelector = "ul li:nth-child(5)";

    private String announcementIconShadowCSS = ".platform__navbar--announcementLink";
    private String announcementIconCSS = "#userAnnouncementLink";
    private String helpIconShadowCSS = ".platform__navbar--userContextualHelpLink";
    private String helpIconCSS = "#userContextualHelpLink";
    private String activeTabCSS = ".platform__navbar--itemNameActive";
    private String activeTabColor = "#0072ee";

    // ********* SuccessMaker Home Page Elements ***************

    @IFindBy (how = How.CSS,using = "cel-platform-navbar.hydrated",AI=false )
    public WebElement topNavBarwithShadow;

    @IFindBy (how=How.CLASS_NAME, using = "logo-icon",AI=false )
    public WebElement footerSavvasLogoShadow;

    private String logoSavvasCSS = "img[src='./assets/logo_savvas.svg']";
    private String newLogoSucessmaker = "img[src='./assets/sm_logo_colored.svg']";

    public TopNavBar()
    {}
    
    public TopNavBar( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
    	PageFactory.initElements(finder, this);
    	elementLayer = new ElementLayer(driver);

    }

    @Override
    protected void isLoaded() {
        if ( !isPageLoaded ) {

            Assert.fail();
        }

        if ( SMUtils.waitForElement( driver, topNavBarwithShadow, 10 ) ) {
            Log.message( "SM Teacher home page loaded successfully." );
        } else {
            Log.fail( "SM Teacher home page did not load." );
        }
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, topNavBarwithShadow );
    }

    /***
     * Checks whether SM logo is displayed
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isSuccessMakerLogoDisplayed() throws InterruptedException {
        new SMUtils();
        SMUtils.waitForSpinnertoDisapper( driver );
        // Require time to load
        Thread.sleep( 2000 );
        WebElement smLogo = SMUtils.getWebElement( driver, topNavBarwithShadow, logoSuccessMakerCSS );
        SMUtils.scrollIntoView( driver, smLogo );
        return smLogo.isDisplayed();
    }

    /***
     * Checks whether Savvas logo is displayed
     *
     * @return
     */
    public boolean isSavvasLogoDisplayed() {
        WebElement savvasLogo = SMUtils.getWebElement( driver, footerSavvasLogoShadow, logoSavvasCSS );
        return savvasLogo.isDisplayed();
    }

    /***
     * Checks whether SM logo is displayed
     *
     * @return
     */
    public boolean isNewSuccessmakerLogoDisplayed() {
        SMUtils.waitForElement( driver, topNavBarwithShadow );
        WebElement savvasLogo = SMUtils.getWebElement( driver, topNavBarwithShadow, newLogoSucessmaker );
        return savvasLogo.isDisplayed();
    }

    /***
     * Checks and return Home Tab visibility
     *
     * @return
     */
    public boolean isHomeTabDisplayed() {
        WebElement homeTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavHomeMenuCSSSelector );
        return homeTab.isDisplayed();
    }

    /***
     * Navigate to Home Tab
     *
     * @return
     */
    public void navigateToHomeTab() {

        SMUtils.waitForElement( driver, topNavBarwithShadow );
        WebElement homeTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavHomeMenuCSSSelector );
        // Using Click JS Method for Safari Browser
        SMUtils.clickJS( driver, homeTab );
        Log.message( "Navigate to home tab" );

    }

    /***
     * Checks and return Courseware Tab visibility
     *
     * @return
     */
    public boolean isCoursewareDisplayed() {
        WebElement couserwareMenu = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavCoursewareMenuCSSSelector );
        return couserwareMenu.isDisplayed();
    }

    /***
     * Checks and return Courseware Tab active or not
     *
     * @return
     */
    public boolean isCoursewareActive() {
        WebElement couserwareMenu = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavCoursewareMenuCSSSelector );
        try {
            WebElement activeTab = couserwareMenu.findElement( By.cssSelector( activeTabCSS ) );
            if ( activeTab.isDisplayed() ) {
                return SMUtils.checkColor( activeTab, activeTabColor );
            } else {
                Log.message( "Color is not Blue" );
                return false;
            }
        } catch ( Exception e ) {
            Log.message( "Can not find Courseware active tab" );
            return false;
        }
    }

    public AssignmentsPage navigateToAssignmentsPage() {
        SMUtils.nap( 0.2 );
        WebElement couserwareMenu = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavCoursewareMenuCSSSelector );
        SMUtils.waitForElementToBeClickable( couserwareMenu, driver );

        SMUtils.clickJS( driver, couserwareMenu );

        SMUtils.clickJS( driver, couserwareMenu );
        //couserwareMenu.click();
        //couserwareMenu.click();
        SMUtils.nap( 0.2 );
        WebElement assignmentsMenuItemsWithShadow = SMUtils.getWebElement( driver, topNavBarwithShadow, coursewareMenuItemsCSSSelectorwithShadow );
        WebElement assignmentsMenuItemToClick = SMUtils.getWebElement( driver, assignmentsMenuItemsWithShadow, "ul li:nth-child(1) a" );
        SMUtils.clickJS( driver, assignmentsMenuItemToClick );
        SMUtils.nap( 2 );
        AssignmentsPage assignmentsPage = new AssignmentsPage( driver ).get();
        Log.message( "Navigated to Assignmentspage" );
        return assignmentsPage;

    }

    /***
     * Navigate to Courseware->Courses Tab
     *
     * @return
     */
    public CourseListingPage getCourseListingPage() {
        WebElement couserwareMenu = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavCoursewareMenuCSSSelector );
        SMUtils.clickJS( driver, couserwareMenu );
        SMUtils.clickJS( driver, couserwareMenu );
        SMUtils.nap( 0.2 );
        WebElement coursesMenuItemsWithShadow = SMUtils.getWebElement( driver, topNavBarwithShadow, coursewareMenuItemsCSSSelectorwithShadow );
        WebElement coursesMenuItemToClick = SMUtils.getWebElement( driver, coursesMenuItemsWithShadow, coursesSubMenuItemCSSSelector );
        SMUtils.clickJS( driver, coursesMenuItemToClick );
        SMUtils.nap( 2 );
        CourseListingPage courseListingPage = new CourseListingPage( driver ).get();
        Log.message( "Navigated to course listing page" );
        return courseListingPage;
    }

    /***
     * Checks and return Students Tab visibility
     *
     * @return
     */
    public boolean isStudentsTabDisplayed() {
        WebElement studentsTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavStudentsMenuCSSSelector );
        return studentsTab.isDisplayed();
    }

    /***
     * Navigate to Students Tab
     *
     * @return
     */
    public StudentsPage navigateToStudentsTab() {
        SMUtils.waitForElement( driver, topNavBarwithShadow, 10 );
        WebElement studentsTab = SMUtils.getWebElementDirect( driver, topNavBarwithShadow, topNavStudentsMenuCSSSelector );
        // TO execute in Safari using JS Click method
        SMUtils.clickJS( driver, studentsTab );

        StudentsPage studentsPage = new StudentsPage( driver ).get();

        Log.message( "Navigated to Student Tab" );

        return studentsPage;
    }

    /***
     * Navigate to Courseware->Courses Tab
     *
     * @return
     */
    public CoursesPage navigateToCourseListingPage() {
        SMUtils.nap( 0.2 );
        WebElement couserwareMenu = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavCoursewareMenuCSSSelector );
        SMUtils.clickJS( driver, couserwareMenu );
        SMUtils.clickJS( driver, couserwareMenu );
        //couserwareMenu.click();
        // couserwareMenu.click();
        SMUtils.nap( 0.2 );
        WebElement coursesMenuItemsWithShadow = SMUtils.getWebElement( driver, topNavBarwithShadow, coursewareMenuItemsCSSSelectorwithShadow );
        WebElement coursesMenuItemToClick = SMUtils.getWebElement( driver, coursesMenuItemsWithShadow, coursesSubMenuItemCSSSelector );
        // coursesMenuItemToClick.click();
        SMUtils.clickJS( driver, coursesMenuItemToClick );
        SMUtils.nap( 2 );
        CoursesPage CoursesPage = new CoursesPage( driver ).get();

        Log.message( "Navigated to course page" );

        return CoursesPage;

    }

    /***
     * Checks and return Groups Tab visibility
     *
     * @return
     */
    public boolean isGroupsTabDisplayed() {
        WebElement groupsTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavGroupsMenuCSSSelector );
        return groupsTab.isDisplayed();
    }

    /***
     * Navigate to Groups Tab
     *
     * @return
     */
    public GroupPage navigateToGroupsTab() {
        WebElement groupsTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavGroupsMenuCSSSelector );
        SMUtils.clickJS( driver, groupsTab );
        GroupPage groupPage = new GroupPage( driver ).get();

        Log.message( "Navigated to Groups Tab" );

        return groupPage;
    }

    /***
     * Checks and return Mastery Tab visibility
     *
     * @return
     */
    public boolean isMasteryTabDisplayed() {
        WebElement masteryTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavMasteryMenuCSSSelector );
        return masteryTab.isDisplayed();
    }

    /***
     * Navigate to Mastery Tab
     *
     * @return
     */
    public MasteryPage navigateToMasteryTab() {
        WebElement masteryTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavMasteryMenuCSSSelector );
        masteryTab.click();

        return new MasteryPage( driver ).get();

    }

    /***
     * Checks and return Reports Tab visibility
     *
     * @return
     */
    public boolean isReportsTabDisplayed() {
        WebElement Reports = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavReportsMenuCSSSelector );
        return Reports.isDisplayed();
    }

    /***
     * Checks and return Reports name Visibility
     *
     * @return
     */
    public boolean isReportNameDisplayed( String reportName ) throws InterruptedException {
        WebElement reportsTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavReportsMenuCSSSelector );
        reportsTab.click();
        reportsTab.click();
        SMUtils.nap( 1 );//required for options load

        WebElement reportMenuItemswithShadow = SMUtils.getWebElements( driver, topNavBarwithShadow, reportsMenuItemsCSSSelectorwithShadow ).get( 1 );

        List<WebElement> allReportsSubMenu = SMUtils.getWebElements( driver, reportMenuItemswithShadow, allReportSubMenuItemCSSSelector );

        for ( WebElement reportsSubMenuItem : allReportsSubMenu ) {
            if ( reportsSubMenuItem.getText().equals( reportName ) ) {
                return true;
            }
        }
        return false;
    }

    /***
     * Navigate to Reports-Cumulative Performance Tab
     *
     * @return
     */
    public CPRPage navigateToReportsCummulativePerformanceTab() {
        SMUtils.waitForElement( driver, topNavBarwithShadow );
        WebElement reportsTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavReportsMenuCSSSelector );
        reportsTab.click();
        reportsTab.click();
        SMUtils.nap( 1 );

        WebElement reportsMenuItemsWithShadow = SMUtils.getWebElements( driver, topNavBarwithShadow, reportsMenuItemsCSSSelectorwithShadow ).get( 1 );

        WebElement reportsCumulativePerformanceTab = SMUtils.getWebElement( driver, reportsMenuItemsWithShadow, cumulativePerformanceSubMenuItemCSSSelector );

        SMUtils.clickJS( driver, reportsCumulativePerformanceTab );
        CPRPage reportsPage = new CPRPage( driver ).get();
        Log.message( "Navigated to Cumulative performance report Page." );
        return reportsPage;
    }

    /***
     * Navigate to Reports-Last Session Tab
     *
     * @return
     */
    public LSRPage navigateToReportsLastSessionTab() {
        WebElement reportsTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavReportsMenuCSSSelector );
        reportsTab.click();
        reportsTab.click();
        SMUtils.nap( 2 ); // Page to be loaded
        WebElement reportsMenuItemsWithShadow = SMUtils.getWebElements( driver, topNavBarwithShadow, reportsMenuItemsCSSSelectorwithShadow ).get( 1 );
        WebElement reportsLastSessionTab = SMUtils.getWebElement( driver, reportsMenuItemsWithShadow, lastSessionSubMenuItemCSSSelector );
        SMUtils.waitForElement( driver, reportsLastSessionTab );
        SMUtils.clickJS( driver, reportsLastSessionTab );
        LSRPage reportPage = new LSRPage( driver ).get();
        Log.message( "Navigated to Last Session report Page." );
        return reportPage;
    }

    /***
     * Navigate to Reports-Student Performance Tab
     *
     * @return
     */

    public SPRPage navigateToReportsStudentPerformanceTab() {
        WebElement reportsTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavReportsMenuCSSSelector );
        // WebElement reportsStudentPerformanceTab;
        SMUtils.nap( 0.3 );
        SMUtils.clickJS( driver, reportsTab );
        SMUtils.clickJS( driver, reportsTab );
        SMUtils.nap( 0.3 );

        WebElement reportsMenuItemsWithShadow = SMUtils.getWebElements( driver, topNavBarwithShadow, reportsMenuItemsCSSSelectorwithShadow ).get( 1 );

        WebElement reportsStudentPerformanceTab = SMUtils.getWebElement( driver, reportsMenuItemsWithShadow, studentPerformanceSubMenuItemCSSSelector );
        SMUtils.clickJS( driver, reportsStudentPerformanceTab );
        SPRPage reportsPage = new SPRPage( driver ).get();
        Log.message( "Navigated to Student performance report Page." );
        return reportsPage;

    }

    /***
     * Checks and return Announcement visibility
     *
     * @return
     */
    public boolean isAnnouncementDisplayed() {
        WebElement announcementIconShadowElement = SMUtils.getWebElement( driver, topNavBarwithShadow, announcementIconShadowCSS );
        WebElement announcementIcon = SMUtils.getWebElement( driver, announcementIconShadowElement, announcementIconCSS );
        return announcementIcon.isDisplayed();
    }

    /***
     * Navigate to Announcement page
     *
     * @return
     */
    public void navigateToAnnouncementPage() {
        WebElement announcementIconShadowElement = SMUtils.getWebElement( driver, topNavBarwithShadow, announcementIconShadowCSS );
        WebElement announcementIcon = SMUtils.getWebElement( driver, announcementIconShadowElement, announcementIconCSS );

        announcementIcon.click();
    }

    /***
     * Checks and return Help visibility
     *
     * @return
     */
    public boolean isHelpDisplayed() {
        WebElement helpIconShadowElement = SMUtils.getWebElement( driver, topNavBarwithShadow, helpIconShadowCSS );
        WebElement helpIcon = SMUtils.getWebElement( driver, helpIconShadowElement, helpIconCSS );
        return helpIcon.isDisplayed();
    }

    /***
     * Navigate to Help page
     *
     * @return
     */
    public void navigateToHelpPage() {
        WebElement helpIconShadowElement = SMUtils.getWebElement( driver, topNavBarwithShadow, helpIconShadowCSS );
        WebElement helpIcon = SMUtils.getWebElement( driver, helpIconShadowElement, helpIconCSS );
        SMUtils.click( driver, helpIcon );
    }

    /**
     * Checks and returns the expand state of User dropdown
     *
     * @return
     */
    public boolean isUserDropdownExpanded() {
        new SMUtils();
        SMUtils.waitForElement( driver, topNavBarwithShadow );
        WebElement userProfileMenuWithShadow = SMUtils.getWebElement( driver, topNavBarwithShadow, userProfileMenuCSSSelector );

        boolean returnParam = SMUtils.getWebElements( driver, userProfileMenuWithShadow, userProfileDropdownMenuItemsCSSSelector ).size() > 0;

        return returnParam;
    }

    /**
     * Expand User dropdown
     */
    public void expandUserDropdown() {
        WebElement userProfileMenuWithShadow = SMUtils.getWebElement( driver, topNavBarwithShadow, userProfileMenuCSSSelector );
        WebElement userProfileDropdownTrigger = SMUtils.getWebElement( driver, userProfileMenuWithShadow, userProfileDropdownTriggerCSSSelector );
        // userProfileDropdownTrigger.click();
        // TO execute in Safari using JS Click method
        SMUtils.clickJS( driver, userProfileDropdownTrigger );
        Log.message( "User profile dropdown expanded successfully" );
    }

    /**
     * Navigate to My Profile
     */
    public MyProfilePage navigateToMyProfile() {
        try {
            if ( !isUserDropdownExpanded() )
                expandUserDropdown();

            WebElement userProfileMenuWithShadow = SMUtils.getWebElement( driver, topNavBarwithShadow, userProfileMenuCSSSelector );
            SMUtils.waitForElementToBeClickable( userProfileMenuWithShadow, driver );

            WebElement userProfileDropdownMenuItemsWithShadow = SMUtils.getWebElement( driver, userProfileMenuWithShadow, userProfileDropdownMenuItemsCSSSelector );
            WebElement myProfileMenuItem = SMUtils.getWebElement( driver, userProfileDropdownMenuItemsWithShadow, myProfileMenuItemCSSSelector );
            // myProfileMenuItem.click();
            SMUtils.clickJS( driver, myProfileMenuItem );
            new SMUtils();
            SMUtils.waitForSpinnertoDisapper( driver );
        } catch ( InterruptedException e ) {
            Log.message( e.getMessage() );
        }
        return new MyProfilePage( driver );
    }

    /**
     * Sign out from SM
     */
    public void signOutfromSM() {

        if ( !isUserDropdownExpanded() )
            expandUserDropdown();

        WebElement userProfileMenuWithShadow = SMUtils.getWebElement( driver, topNavBarwithShadow, userProfileMenuCSSSelector );
        SMUtils.waitForElementToBeClickable( userProfileMenuWithShadow, driver );

        WebElement userProfileDropdownMenuItemsWithShadow = SMUtils.getWebElement( driver, userProfileMenuWithShadow, userProfileDropdownMenuItemsCSSSelector );

        WebElement signOutMenuItem = SMUtils.getWebElement( driver, userProfileDropdownMenuItemsWithShadow, signOutMenuItemCSSSelector );

        // TO execute in Safari using JS Click method
        SMUtils.clickJS( driver, signOutMenuItem );
        // signOutMenuItem.click();

        Log.message( "Clicked sign out button" );
    }

    /**
     * Created this method for running in local for validation purpose. Above
     * SignOut Method will fail sometimes in local due to Synchronization
     * issues.
     */
    public void clickSignOut() {
        if ( !isUserDropdownExpanded() )
            expandUserDropdown();
        WebElement userProfileMenuWithShadow = SMUtils.getWebElement( driver, topNavBarwithShadow, userProfileMenuCSSSelector );
        SMUtils.waitForElementToBeClickable( userProfileMenuWithShadow, driver );
        WebElement userProfileDropdownMenuItemsWithShadow = SMUtils.getWebElement( driver, userProfileMenuWithShadow, userProfileDropdownMenuItemsCSSSelector );
        int i = 0;
        while ( i < 5 ) {
            if ( userProfileDropdownMenuItemsWithShadow != null ) {
                break;
            } else {
                try {
                    userProfileDropdownMenuItemsWithShadow = SMUtils.getWebElement( driver, userProfileMenuWithShadow, userProfileDropdownMenuItemsCSSSelector );

                } catch ( Exception e ) {
                    i++;
                }

            }
        }

        WebElement signOutMenuItem = SMUtils.getWebElement( driver, userProfileDropdownMenuItemsWithShadow, signOutMenuItemCSSSelector ); //
        // TO execute in Safari using JS Click method

        SMUtils.clickJS( driver, signOutMenuItem ); // signOutMenuItem.click();

        Log.message( "Clicked sign out button" );
    }

    /***
     * Navigate to Reports-Prescriptive scheduling report
     *
     *
     * @return
     */
    public PSRPage navigateToPrescriptiveSchedulingReportPage() {
        WebElement reportsTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavReportsMenuCSSSelector );
        reportsTab.click();
        reportsTab.click();

        WebElement reportMenuItemswithShadow = SMUtils.getWebElements( driver, topNavBarwithShadow, reportsMenuItemsCSSSelectorwithShadow ).get( 1 );
        List<WebElement> allReportsSubMenu = SMUtils.getWebElements( driver, reportMenuItemswithShadow, allReportSubMenuItemCSSSelector );
        for ( WebElement reportsSubMenuItem : allReportsSubMenu ) {
            if ( reportsSubMenuItem.getText().equals( Constants.Reports.PSR_REPORT ) ) {
                SMUtils.clickJS( driver, reportsSubMenuItem );
                break;
            }
        }
        PSRPage reportPage = new PSRPage( driver ).get();
        Log.message( "Navigated to Prescriptive scheduling report Page." );
        return reportPage;
    }

    /***
     * Navigate to Reports-Areas of Difficulty Tab
     *
     * @return
     *
     * @return
     */
    public AODPage navigateToReportsAreasofDifficultyTab() {
        SMUtils.waitForElement( driver, topNavBarwithShadow );
        WebElement reportsTab = SMUtils.getWebElement( driver, topNavBarwithShadow, topNavReportsMenuCSSSelector );
        SMUtils.clickJS( driver, reportsTab );
        SMUtils.clickJS( driver, reportsTab );
        SMUtils.nap( 1 );

        WebElement reportsMenuItemsWithShadow = SMUtils.getWebElements( driver, topNavBarwithShadow, reportsMenuItemsCSSSelectorwithShadow ).get( 1 );

        WebElement reportsAreasofDifficultyTab = SMUtils.getWebElement( driver, reportsMenuItemsWithShadow, areaOfDifficultySubMenuItemCSSSelector );
        SMUtils.clickJS( driver, reportsAreasofDifficultyTab );

        AODPage reportsPage = new AODPage( driver ).get();
        Log.message( "Navigated to Areas of Difficulty report Page." );
        return reportsPage;
    }

    /**
     * Get web element for student tab sub menu
     *
     * @return
     */
    public WebElement getStudentSubMenu() {
        SMUtils.waitForElement( driver, topNavBarwithShadow, 10 );
        WebElement studentsTab = SMUtils.getWebElementDirect( driver, topNavBarwithShadow, topNavStudentsMenuCSSSelector );
        return studentsTab;
    }

    /**
     * Returns the Top navigation bar Shadow
     *
     * @return WebElement
     */
    public WebElement getTopNavBarwithShadow() {
        return topNavBarwithShadow;
    }

    /**
     * Returns the CSS for the Help Icon in the String for the Shadow element
     *
     * @return String
     */
    public String getHelpIconShadowCSS() {
        return helpIconShadowCSS;
    }

    /**
     * Returns the CSS for the Help Icon
     *
     * @return String
     */
    public String getHelpIconCSS() {
        return helpIconCSS;
    }

    /**
     * Returns the Annoucement Icon CSS in the String for the Shadow element
     *
     * @return String
     */
    public String getAnnouncementIconShadowCSS() {
        return announcementIconShadowCSS;
    }

    /**
     * Returns the Annoucement Icon css
     *
     * @return String
     */
    public String getAnnouncementIconCSS() {
        return announcementIconCSS;
    }

}
