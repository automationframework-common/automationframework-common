package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class UpdateReadingLoCompleteAPI extends EnvProperties {

	private String smUrl;
	private String browser;
	private String school;
	private String orgId;
	
	private String teacherDetails = null;
	private String teacherDetails1 = null;
	
	private String teacherUserId= null;
	private String teacherUserId1= null;
	private String teacherUsername= null;
	private String teacherUsername1= null;
	
	private String studentDetail= null;
	private String studentUsername= null;
	private String studentUserID= null;
	private String stuFName;
	private String stuLName; 
	
	private String studentDetail1= null;
	private String studentUsername1= null;
	private String studentUserID1= null;
	private String stuFName1;
	private String stuLName1;
	
//	private String studentDetail2= null;
//	private String studentUsername2= null;
//	private String studentUserID2= null;
//	private String stuFName2;
//	private String stuLName2; 
	
	private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
	private List<String> studentRumbaIds = new ArrayList<>();
	private List<String> allCourseIds = new ArrayList<>();
	private static String skillCourseName = "Custom_Reading_Skills_AllLOs" + System.nanoTime();
	private static String standardCourseName = "Custom_Reading_Standards_AllLOs" + System.nanoTime();

	//
	private static HashMap<String, String> assignmentDetails = new HashMap<>();
	private static HashMap<String, String> assignmentDetails1 = new HashMap<>();
	HashMap<String, String> studentHeaders = new HashMap<>();
	private String  skillAssignmentUserID;
	private String  skillAssignmentUserID1;
	private String  standardAssignmentUserID;
	GroupAPI groupAPI;
	CourseAPI courseAPI;
	SMAPIProcessor smAPIprocessor;
	SqlHelperAssignment sqlHelperAssignment;

	@BeforeClass ( alwaysRun = true )
	public void init() throws Exception {
		smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
		browser = configProperty.getProperty( "BrowserPlatformToRun" );
		school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
		orgId = RBSDataSetup.organizationIDs.get( school );
		groupAPI = new GroupAPI();
		courseAPI = new CourseAPI();
		smAPIprocessor = new SMAPIProcessor();
		sqlHelperAssignment = new SqlHelperAssignment();

		//Teacher Details 1
		teacherDetails = RBSDataSetup.getMyTeacher( school );
		teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
		teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
		Log.message("Teacher Username: " +teacherUsername );
		Log.message("Teacher User ID: " +teacherUserId );

		//		//Teacher Details 2
		//		teacherDetails1 = RBSDataSetup.getMyTeacher( school );
		//		teacherUsername1 = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
		//		teacherUserId1 = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

		//Student Details 1
		studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
		studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
		studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
		Log.message("Student Username: " + studentUsername );
		Log.message("Student User ID: " + studentUserID );
		stuFName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ).toString();
		stuLName = SMUtils.getKeyValueFromResponse( studentDetail, "lastName" ).toString();

		//Student Details 2
		studentDetail1 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
		studentUserID1 = SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USERID_HEADER );
		studentUsername1 = SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USER_NAME );
		Log.message("Student Username1: " + studentUsername1 );
		Log.message("Student User ID1: " + studentUserID1 );
		stuFName1 = SMUtils.getKeyValueFromResponse( studentDetail1, "firstName" ).toString();
		stuLName1 = SMUtils.getKeyValueFromResponse( studentDetail1, "lastName" ).toString();

		//Student Details 3
//		studentDetail2 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
//		studentUserID2 = SMUtils.getKeyValueFromResponse( studentUserID2, Constants.USERID_HEADER );
//		studentUsername2 = SMUtils.getKeyValueFromResponse( studentUserID2, Constants.USER_NAME );
//		Log.message("Student Username2: " + studentUsername2 );
//		Log.message("Student User ID2: " + studentUserID2 );
//		stuFName2 = SMUtils.getKeyValueFromResponse( studentDetail2, "firstName" ).toString();
//		stuLName2 = SMUtils.getKeyValueFromResponse( studentDetail2, "lastName" ).toString();

		studentRumbaIds.add(studentUserID);
		studentRumbaIds.add(studentUserID1);


		// Creating a Reading Custom By Skill Course with 1LO
		createReadingAllSkillCourse();
		createReadingAllStandardCourse();

		String skillCourseId = SqlHelperCourses.getContenBaseIdByName(skillCourseName);
		Log.message("Course Id for Skill course is : " + skillCourseId);

		assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
		assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
		assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

		//Assignment ID
		String skillAssignmentID = SMUtils.getKeyValueFromResponse(new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails,
				Arrays.asList(studentUserID) ,Arrays.asList(skillCourseId) ).get(Constants.REPORT_BODY), "data,assignmentId");


		//Assignment User ID 
		skillAssignmentUserID = SqlHelperAssignment.getAssignmentUserID(studentUserID, skillAssignmentID);
//		skillAssignmentUserID1 = SqlHelperAssignment.getAssignmentUserID(studentUserID1, skillAssignmentID);
		Log.message("Assigment User ID for R-Skill Course: " + skillAssignmentUserID + "  Assignemnt User ID for R-Standard Course: " + "skillAssignmentUserID1" );

//		launchCourse(studentUsername, skillCourseName, "50", "1", "30");
//
//		sessionId = new SqlHelperAssignment().getSessionId( skillAssignmentUserID );
//		Log.message("TheSessionId : "+ sessionId);

	}  

	@Test ( priority = 1, dataProvider = "readingLOCompletePositive", groups = { "SMK-52036", "SMK-66851", "StudentAssignmentAPI", "Reading_LO_Complete", "P1", "API" ,"smoke_test_case" } )
	public void tcPositiveTestcases( String description, String scenario, String statusCode ) throws Exception {

		Log.testCaseInfo( description );
		HashMap<String, String> Response = new HashMap<>();
		HashMap<String, String> apiResponse = new HashMap<>();

		switch ( scenario ) {
		case "CUSTOM_BY_SKILL":

			Log.testCaseInfo("Verify the Response code is 200 while completing Reading LO with rewardCourseLevel 1");
			launchCourse(studentUsername, skillCourseName, "50", "1", "30");

			String sessionId = new SqlHelperAssignment().getSessionId( skillAssignmentUserID );
			Log.message("TheSessionId : "+ sessionId);

			HashMap<String, String> header = new HashMap<>();
			header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			header.put( Constants.AUTHORIZATION,  "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetail, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			header.put( Constants.ORGID_SM_HEADER, orgId );
			header.put( Constants.USERID_SM_HEADER, studentUserID );
			header.put( AssignmentAPIConstants.SESSION_ID_HEADER, sessionId );

			String  requestPayload = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "PutAPIReadingLOCompletePayload.json" );
			requestPayload = requestPayload.replaceAll("auId", skillAssignmentUserID);
			requestPayload = requestPayload.replace("FName", stuFName);
			requestPayload = requestPayload.replace("LName" , stuLName);
			requestPayload = requestPayload.replace("rewardValue" , "1");

			Log.message("Final Payload : " + requestPayload);

			HashMap<String, String>  apiResponses = readingLOCompleteStudent(smUrl, header, skillAssignmentUserID, requestPayload);
			Log.message("API Status Code:" + apiResponses );
			Log.softAssertThat( apiResponses.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponses.get( Constants.STATUS_CODE ),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponses.get( Constants.STATUS_CODE ) );

			break;


		case "CUSTOM_BY_STANDARD":

			Log.testCaseInfo("Verify the Response code is 200 while completing Reading LO with rewardCourseLevel -1");
			String standardCourseId = SqlHelperCourses.getContenBaseIdByName(standardCourseName);
			Log.message("Course Id for Standard course is : " + standardCourseId);
			
			assignmentDetails1.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails1.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			assignmentDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

			String standardAssignmentID = SMUtils.getKeyValueFromResponse(new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails,
					Arrays.asList(studentUserID1) ,Arrays.asList(standardCourseId) ).get(Constants.REPORT_BODY), "data,assignmentId");

			//Assignment User ID 
			standardAssignmentUserID = SqlHelperAssignment.getAssignmentUserID(studentUserID1, standardAssignmentID);
			Log.message( "  Assignemnt User ID for R-Standard Course: " + standardAssignmentUserID );

			launchCourse(studentUsername1, standardCourseName, "50", "1", "30");

			String sessionId2 = new SqlHelperAssignment().getSessionId( standardAssignmentUserID );
			Log.message("TheSessionId : "+ sessionId2);

			HashMap<String, String> header2 = new HashMap<>();
			header2.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			header2.put( Constants.AUTHORIZATION,  "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetail1, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			header2.put( Constants.ORGID_SM_HEADER, orgId );
			header2.put( Constants.USERID_SM_HEADER, studentUserID1 );
			header2.put( AssignmentAPIConstants.SESSION_ID_HEADER, sessionId2 );

			String  requestPayload2 = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "PutAPIReadingLOCompletePayload.json" );
			requestPayload2 = requestPayload2.replaceAll("auId", standardAssignmentUserID);
			requestPayload2 = requestPayload2.replace("FName", stuFName1);
			requestPayload2 = requestPayload2.replace("LName" , stuLName1);
			requestPayload2 = requestPayload2.replace("rewardValue" , "-1");
			Log.message("Final Payload : " + requestPayload2);

			HashMap<String, String>  apiResponses2 = readingLOCompleteStudent(smUrl, header2, standardAssignmentUserID, requestPayload2);
			Log.message("API Status Code:" + apiResponses2 );
			Log.softAssertThat( apiResponses2.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponses2.get( Constants.STATUS_CODE ),
					"Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponses2.get( Constants.STATUS_CODE ) );

			break;
		}

		Log.testCaseResult();
	}


	@DataProvider ( name = "readingLOCompletePositive" )
	public Object[][] readingLOCompletePositive() {

		Object[][] inputData = {
				{ "Verify the Response code is 200 while completing Reading LO with Custom By Skill course", "CUSTOM_BY_SKILL", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify the Response code is 200 while completing Reading LO with Custom By Standard Course", "CUSTOM_BY_STANDARD", CommonAPIConstants.STATUS_CODE_OK },

				
		};
		return inputData;
	}



	/**
	 * This method is used to select the course based on courseName.
	 * 
	 * @param studentUsername
	 * @param courseName
	 */
	public void selectCourse(String studentUsername, String courseName ) throws IOException {
		final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );
		Log.message( "Student username :" + studentUsername );
		LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
		SMUtils.nap( 30 );
		StudentDashboardPage studentPage = new StudentDashboardPage( driver );
		studentPage.selectAssignmentByName(courseName);
	}


	public HashMap<String, String> readingLOCompleteStudent( String envUrl, HashMap<String, String> studentHeaders, String assignmentUserID,String requestPayload ) {
		try {

			String endpoint = StudentDetailsForGivenTeacherConstants.READING_LO_COMPLETE_ENDPOINT + "/" + assignmentUserID ;
			Log.message("Final Endpoint: " + endpoint);

			//Parameters
			HashMap<String, String> params = new HashMap<>();

			Log.message( studentHeaders.toString() );

			HashMap<String, String> responseReadingLOComplete = RestHttpClientUtil.PUT( envUrl, studentHeaders, params, endpoint, requestPayload );

			return responseReadingLOComplete;

		} catch ( Exception e ) {
			Log.message( "Error in getting the API response" );
			return null;
		}
	}

	/**
	 * This method is used to create a Reading Skill Course with All LO 
	 * 
	 */
	public void createReadingAllSkillCourse() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get( browser );
		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
		TeacherHomePage tHomePage = smLoginPage.loginToSM( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD, true );
		Log.message("Logged into SM as Teacher: " + teacherUsername);
		// Navigate to Courses Tab
		tHomePage.topNavBar.navigateToCourseListingPage();
		CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
		courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

		CoursesPage coursePage = new CoursesPage( driver );
		try {
			coursePage.createReadingCustomCourseWithAllSkills(skillCourseName, teacherUsername, smUrl);

			// Sign out
			tHomePage.topNavBar.signOutfromSM();
		} catch (Exception e) {
			// TODO: handle exception
		}

	}
	
	
	/**
	 * This method is used to create a Reading Standard Course with All LO 
	 * 
	 */
	public void createReadingAllStandardCourse() throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get( browser );
		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
		TeacherHomePage tHomePage = smLoginPage.loginToSM( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD, true );
		Log.message("Logged into SM as Teacher: " + teacherUsername);
		// Navigate to Courses Tab
		tHomePage.topNavBar.navigateToCourseListingPage();
		CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
		courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

		CoursesPage coursePage = new CoursesPage( driver );
		try {
			coursePage.createReadingCustomCourseWithAllStandards(standardCourseName, teacherUsername, smUrl);

			// Sign out
			tHomePage.topNavBar.signOutfromSM();
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	/**
	 * To execute the course
	 *
	 * @param studentUserName
	 * @param courseName
	 * @throws IOException
	 */
	public void launchCourse(String studentUserName, String courseName, String percentage, String numberOfSession,
			String loCount) throws IOException {
	    WebDriver driver =null;
	    boolean flagIsExecutionSuccessfull =false;
	    try {
	        for ( int i = 0; i <3; i++ ) {
                try {
                    driver = WebDriverFactory.get(configProperty.getProperty("BrowserPlatformToRun"));
                    Log.message("Student username " + studentUserName);
                  
                    try {
                        LoginWrapper.loginToSuccessMakerAsStudent(driver, smUrl, UserType.BASIC, null, studentUserName,
                                RBSDataSetupConstants.DEFAULT_PASSWORD);
                        StudentDashboardPage studentsPage = new StudentDashboardPage(driver);
                        studentsPage.launchReadingCourse( courseName, percentage, numberOfSession, loCount);
                        flagIsExecutionSuccessfull =true;
                        break;

                    } catch ( Exception e ) {
                        Log.message( "Issue occurrred at Login and execution , reattempting : "+ i );
                        continue;
                    }
                } catch ( Exception e ) {
                    Log.message( "Issue occurrred at driver creation , reattempting : "+ i );
                    continue;
                }
                
            }
	        	        
        }finally {
            if( flagIsExecutionSuccessfull) {
                Log.message( "Course executed successfully" );
            }else {
                Log.message( "Course execution failed after reattempting : 3");
            }
            driver.quit();
            
        }
	}


}