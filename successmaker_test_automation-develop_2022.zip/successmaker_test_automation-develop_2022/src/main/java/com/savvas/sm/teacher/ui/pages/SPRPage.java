package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class SPRPage extends LoadableComponent<SPRPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    private WebDriver driver;
    boolean isPageLoaded;
    
    public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();

    // ********* SuccessMaker SPR Page Elements ***************

    @IFindBy(how = How.CSS, using="p.description", AI = false)
    public WebElement SPRDescriptionText;

    @IFindBy(how = How.CSS, using="section.page-title div h1", AI = false)
    public WebElement lbSPRHeader;

    @IFindBy(how = How.CSS, using="div.col-md-2 label.title-label", AI = false)
    public WebElement lblSubjectDropdownHeader;

    @IFindBy(how = How.CSS, using="div.step2 div.col-md-6 label", AI = false)
    public WebElement lblAssignemntDropdownHeader;

    @IFindBy(how = How.CSS, using="cel-checkbox.hydrated", AI = false)
    public WebElement lblMaskStudentDisplayTextRoot;

    @IFindBy(how = How.CSS, using="report-options div.form-group div.col-md-3 label", AI = false)
    public WebElement lblSavedOptionHeading;

    @IFindBy(how = How.CSS, using="cel-button.run-button ", AI = false)
    public WebElement runReportBtnRoot;

    @IFindBy(how = How.CSS, using="cel-button.save-button", AI = false)
    public WebElement saveReportBtnRoot;

    @FindBy ( css = "div.form-group label.form-label" )
    List<WebElement> rbHeaderforAllPerformce;

    @IFindBy(how = How.CSS, using="#dateAtRisk", AI = false)
    public WebElement lbldateAtRisk;

    // Subject filter
    @IFindBy(how = How.CSS, using="div.col-md-2 cel-multi-check-dropdown", AI = false)
    public WebElement lblsubjectfilterroot;

    @IFindBy(how = How.CSS, using="cel-multi-check-dropdown.ng-cel-multi-check-dropdown", AI = false)
    public WebElement math_readingCheckboxInsideSubjectFilterGrandRoot;

    @IFindBy(how = How.CSS, using="div.radio__wrapper label[for='cel-rb-2']", AI = false)
    public WebElement performanceSummaryYesRB;

    @IFindBy(how = How.CSS, using="div.radio__wrapper label[for='cel-rb-3']", AI = false)
    public WebElement performanceSummaryNoRB;

    @IFindBy(how = How.CSS, using="div.radio__wrapper label[for='cel-rb-4']", AI = false)
    public WebElement performanceByStrandYesRB;

    @IFindBy(how = How.CSS, using="div.radio__wrapper label[for='cel-rb-5']", AI = false)
    public WebElement performanceByStrandNoRB;

    @IFindBy(how = How.CSS, using="div.radio__wrapper label[for='cel-rb-6']", AI = false)
    public WebElement areaOfDifficultyYesRB;

    @IFindBy(how = How.CSS, using="div.radio__wrapper label[for='cel-rb-7']", AI = false)
    public WebElement areaOfDifficultyNoRB;

    @IFindBy(how = How.CSS, using="section.page-title div h1", AI = false)
    public WebElement studentPerformanceHeader;

    @IFindBy(how = How.CSS, using=".contextual-help-icon.hydrated", AI = false)
    public WebElement studentPerformancePageHelpIcon;

    @IFindBy(how = How.CSS, using="#mc-main-content > h1", AI = false)
    public WebElement studentPerformanceHelpPageHeader;

    // *******Child Elements***************
    // subject filter child

    private static String lblRemoveMaskStudentDiplayText = "label.checkbox__label";
    private static String maskStudentcheckbox = "label.checkbox__container input";
    private static String runReportBtnchild = ".primary_button";
    private static String saveReportoptionsBtnchild = ".secondary_button";
    // Select All Checkbox inside dropdown
    private static String chbxSelectALLParentRoot = "cel-checkbox.hydrated";
    private static String chbxDropdownMS = "label.checkbox__container";
    // Math and Reading check box inside subject check box

    public SPRPage() {}
    /**
     * Constructor to load driver and components
     *
     * @param driver
     */
    public SPRPage( WebDriver driver ) {
        this.driver = driver;
        // Have Top bar here and init
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
    	PageFactory.initElements(finder, this);
    	elementLayer = new ElementLayer(driver);
    }

    /**
     * Verify the page load
     */
    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, lbSPRHeader );
    }

    /**
     * Verifying the page is loaded.
     */
    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( SMUtils.waitForElement( driver, lbSPRHeader ) ) {
            Log.message( "SM Student performance report page loaded successfully." );
        } else {
            Log.fail( "SM Student performance report page did not load." );
        }

    }

    /**
     * get SPR description text
     */
    public Boolean reportDescriptionText( String descriptionText ) {
        Log.message( "Getting SPR Description" );
        if ( SPRDescriptionText.getText().equalsIgnoreCase( descriptionText ) ) {
            return true;

        }
        return false;
    }

    /**
     * Mask Student Display field validation
     */
    public boolean isMaskStudentDisplayed( String maskStudent ) {
        Log.message( "Validate mask student" );
        SMUtils.waitForElement( driver, lblMaskStudentDisplayTextRoot );
        WebElement maskStudentHeader = SMUtils.getWebElement( driver, lblMaskStudentDisplayTextRoot, lblRemoveMaskStudentDiplayText );
        if ( maskStudentHeader.getText().trim().equals( maskStudent ) ) {

            return true;
        }
        return false;
    }

    /**
     * Run Report field validation
     */
    public boolean isRunReportDisplayed() {
        SMUtils.waitForElement( driver, runReportBtnRoot );
        WebElement runReportBtnText = SMUtils.getWebElement( driver, runReportBtnRoot, runReportBtnchild );
        if ( runReportBtnText.isDisplayed() ) {
            Log.message( "Run Report is displaying" );
            return true;
        }
        return false;
    }

    /**
     * Save Report Options validation
     */
    public boolean isSaveReportDisplayed() {
        SMUtils.waitForElement( driver, saveReportBtnRoot );
        WebElement saveReportBtnText = SMUtils.getWebElement( driver, saveReportBtnRoot, saveReportoptionsBtnchild );
        if ( saveReportBtnText.isDisplayed() ) {
            Log.message( "Save Report is displaying" );
            return true;
        }
        return false;
    }

    /**
     * Is SELECT ALLL Radio button selected
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isSelectALLChecked() throws InterruptedException {
        SMUtils.nap( 0.5 );// This wait will required to load the page
        ReportComponent reportComponent = new ReportComponent( driver );
        reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
        reportComponent.expandDropDownMS();
        WebElement chbxSelectAllRoot = SMUtils.getWebElement( driver, reportComponent.shadowTree, chbxSelectALLParentRoot );
        Log.message( "Validate Select all check box selected " );
        return SMUtils.getWebElement( driver, chbxSelectAllRoot, chbxDropdownMS ).isSelected();
    }

    /**
     * Include Performace Summary
     */
    public void clickIncludePerformaceSummaryradioButton() {
        SMUtils.waitForElement( driver, performanceSummaryYesRB );
        if ( performanceSummaryYesRB.isSelected() ) {
            performanceSummaryNoRB.click();
            Log.message( "Include Performace Summary is selected as No" );
            performanceSummaryYesRB.click();

        } else {
            Log.message( "Include Performace Summary is selected as No" );
        }
    }

    /**
     * Is Include Performance Summary is Yes
     *
     * @return
     */

    public boolean isPerformanceSummaryYes() {
        Log.message( "Validate Performance summary is Yes" );
        return performanceSummaryYesRB.isSelected();
    }

    /**
     * Area Of Difficulty
     */
    public void clickAODRdiobutton() {
        SMUtils.waitForElement( driver, areaOfDifficultyYesRB );
        if ( areaOfDifficultyYesRB.isSelected() ) {
            areaOfDifficultyNoRB.click();
            Log.message( "Areas of Difficulty is selected as No" );
            areaOfDifficultyYesRB.click();
        } else {
            Log.message( "Areas of Difficulty is selected as No" );
        }
    }

    /**
     * Area of difficulty is selected as Yes
     *
     * @return
     */
    public boolean isAODAsYes() {
        Log.message( "Validate AOD is Yes" );
        return areaOfDifficultyYesRB.isSelected();
    }

    /**
     * Area of difficulty is selected as No
     *
     * @return
     */
    public boolean isAODAsNo() {
        Log.message( "Validate AOD is No" );
        return !areaOfDifficultyYesRB.isSelected();
    }

    /**
     * Include Performace By Stard
     */
    public void clickIncludePerformaceByStarndRadioButton() {
        SMUtils.waitForElement( driver, performanceByStrandYesRB );
        if ( performanceByStrandYesRB.isSelected() ) {
            performanceByStrandNoRB.click();
            Log.message( "Include Performace Summary is selected as No" );
            performanceByStrandYesRB.click();
        } else {
            Log.message( "Include Performace Summary is selected as No" );
        }
    }

    /**
     * IncludePerformance By Strad is Yes
     *
     * @return
     */
    public boolean isPerformanceByStrandYes() {
        Log.message( "Validate Performance by strand is Yes" );
        return performanceByStrandYesRB.isSelected();
    }

    /**
     * Is Date at Risk is displaying when AOD is No
     */
    public boolean isDateAtRiskDisplaying() {
        performanceByStrandNoRB.click();
        Log.message( "Validate Date at risk is displaying" );
        return ( !lbldateAtRisk.isDisplayed() );
    }

    /**
     * Mask Student
     *
     */
    public Boolean isMaskStudentSelected() {

        WebElement maskStudentCheckBox = SMUtils.getWebElement( driver, lblMaskStudentDisplayTextRoot, maskStudentcheckbox );
        Log.message( "Validate Mask Student is selected" );
        return maskStudentCheckBox.isSelected();
    }

    /**
     * Click On Mask Student
     */
    public void clickMaskStudentCB() {

        WebElement maskStudentCheckBox = SMUtils.getWebElement( driver, lblMaskStudentDisplayTextRoot, maskStudentcheckbox );
        SMUtils.scrollIntoView( driver, maskStudentCheckBox );
        SMUtils.clickJS( driver, maskStudentCheckBox );
        Log.message( "Mask Student selected successfully" );
    }

    /**
     * To get all Selected Filters in CPR Page
     *
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getAllSelectedFilters( ReportComponent reportComponent ) throws Exception {

        SMUtils.nap( 0.5 ); // It is required to load all element after saving report

        HashMap<String, String> selectedFilters = new HashMap<>();
        if ( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.GROUP_DROPDOWN ) ) {
            selectedFilters.put( Constants.Reports.GROUP_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.GROUP_DROPDOWN ) );
        } else {
            selectedFilters.put( Constants.Reports.STUDENTS_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.STUDENTS_DROPDOWN ) );
        }
        selectedFilters.put( Constants.Reports.SUBJECT_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.SUBJECT_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.ASSIGNMENTS_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.DISPLAY_DROPDOWN, reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.SPR_DATEATRISK_DROPDOWN, reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SPR_DATEATRISK_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.SPR_LANGUAGE_DROPDOWN, reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SPR_LANGUAGE_DROPDOWN ) );

        if ( isMaskStudentSelected() )
            selectedFilters.put( Constants.Reports.MASK_STUDENT_DISPLAY, "Checked" );
        else
            selectedFilters.put( Constants.Reports.MASK_STUDENT_DISPLAY, "unchecked" );
        if ( isPerformanceByStrandYes() )
            selectedFilters.put( Constants.Reports.SPR_INCLUDEPERFORMANCESTRAND, "Yes" );
        else
            selectedFilters.put( Constants.Reports.MASK_STUDENT_DISPLAY, "No" );
        if ( isAODAsYes() )
            selectedFilters.put( Constants.Reports.SPR_INCLUDEAOD, "Yes" );
        else
            selectedFilters.put( Constants.Reports.SPR_INCLUDEAOD, "No" );
        if ( isPerformanceSummaryYes() )
            selectedFilters.put( Constants.Reports.SPR_INCLUDEPERFORMANCE, "Yes" );
        else
            selectedFilters.put( Constants.Reports.SPR_INCLUDEPERFORMANCE, "No" );
        Log.message( "Got all selected filters" );
        return selectedFilters;
    }

    /**
     * Click On SPR Field to validate dropdown is closing after clicking on
     * Anywhere on page
     */
    public void collapseFilterButton() {
        SMUtils.clickJS( driver, SPRDescriptionText );
        Log.message( "Dropdown closed successfully" );
    }

    /**
     * Validate student dropdown heading
     *
     * @return
     * @throws InterruptedException
     */
    public boolean islabelOfperforamanceSummaryStarndAndAODHeadingPresent( String dropdownName ) throws InterruptedException {
        boolean isHeaderPresent = false;
        for ( WebElement lbldropdownHeader : rbHeaderforAllPerformce ) {
            if ( lbldropdownHeader.getText().trim().equals( dropdownName ) ) {
                isHeaderPresent = true;
                break;
            }
        }
        Log.message( "Verified " + dropdownName + " dropdown header" );
        return isHeaderPresent;
    }

    /**
     * Return the Student Peformance Page Help Icom
     *
     * @return WebElement
     */
    public WebElement getStudentPerformancePageHelpIcon() {
        return studentPerformancePageHelpIcon;
    }

    /**
     * function that returns the Student Performance Page Header
     *
     * @return WebElement
     */
    public WebElement getStudentPerformanceHeader() {
        return studentPerformanceHelpPageHeader;
    }

}
