package com.savvas.sm.common.utils.apiconstants;

public interface LicenseAPIConstants {

    public static Integer LICENSE_COUNT = 500;
    public static String MATH = "Math";
    public static String READING = "Reading";
    public static String FLEX = "Flex";
    public static String MATH_FOCUS = "MathFocus";
    public static String READING_FOCUS = "ReadingFocus";

    //MATH_PRODUCT is refers Math and focus product together
    public static String MATH_PRODUCT = "mathOnlyProduct";

    //READING_PRODUCT is refers Reading and focus product together
    public static String READING_PRODUCT = "readingOnlyProduct";

    //Only Focus products
    public static String MATH_FOCUS_ONLY_PRODUCT = "mathFocusOnlyProduct";
    public static String READING_FOCUS_ONLY_PRODUCT = "readingFocusOnlyProduct";

    //Flexible license
    public static String FLEX_PRODUCT = "flexProduct";

    // Constants - API
    public static String ORGID = "org-id";
    public static String USERID = "user-id";
    public static String AUTHORIZATION = "Authorization";
    public static String BEARER = "Bearer ";

    // Constants - Endpoints
    public static String GET_LICENSESERVICE_ENDPOINT = "/lms/web/api/v2/license/getUserLicenses";

    //Static test data for LMS testing
    public static String password = "password1";
    public static String valid_Teacher_OrgId = "8a720bec7e850e85017e8bfe61e00260";
    public static String valid_Teacher_UserId = "ffffffff61ee9739af88cb00305cd4eb";
    public static String Teacher_UserName = "smautoteacherbasic333450856255100";
    public static String valid_Student_OrgId = "8a720bec7e850e85017e90a6d2e10342";
    public static String valid_Student_UserId = "ffffffff61efc87caf88cb00305cec79";
    public static String Student_UserName = "smuserrumba411598580885800";
    public static String valid_District_CustomerAdmin_OrgId = "8a7200f77de565ac017e1ec313f1047e";
    public static String valid_District_CustomerAdmin_UserId = "ffffffff61d58f4d03bb160030ec4bac";
    public static String valid_District_CustomerAdmin_UserName = "customeradmin3";
    public static String valid_School_CustomerAdmin_OrgId = "8a7200f77de565ac017e24857949068c";
    public static String valid_School_CustomerAdmin_UserId = "ffffffff61f2a6d74def5600303134bc";
    public static String valid_School_CustomerAdmin_UserName = "kb_multi_school_admin_auto";
    public static String valid_SavvasAdmin_OrgId = "8a7200f77de565ac017e1ec313f1047e";
    public static String valid_SavvasAdmin_UserId = "ff8080812b39eae8012b3a4e88250020";
    public static String savvasAdmin_UserName = "radmin";
    public static String savvasAdmin_Password = "abcd1234!";

    public static String invalid_User_Id = "ffffffff61f2a46f4def5600303134b1";
    public static String invalid_Org_Id = "8a7200f77de565ac017e1ec313f10471";

    public static String GET_TEACHER_LICENSE_USAGE = "/lms/web/api/v2/license/subjects";
    public static String GET_STUDENT_ASSIGNMENT_LICENSE_USAGE = "/lms/web/assignments/launchdata/{auId}";
    public static String GET_STUDENT_MATH_IPM ="/lms/web/assignments/math/ipm/adjustment/{auId}";
    public static String CHECK_MULTI_ASSIGNMENT_SESSION = "/lms/web/assignments/multiple/session/{auId}";
    public static String GET_K2IPM_ASSESSMENTS = "/lms/web/assignments/k2ipm/assessments/";

    public static String GET_FOCUS_LICENSE_USAGE = "/lms/web/license/organization/allFocusLicenses";
    public static String EXPIRED_LICENSE_ORG_ID = "8a7206a97f2c9d3a017f4e6eaabd0812";
    public static String FUTURE_LICENSE_ORG_ID = "8a720abd7f5136d0017f64a68bae0e35";
    public static String ZERO_LICENSE_ORG_ID = "8a7206a97f2c9d3a017f4b848c6f077d";

    public static String EXPIRED_LICENSE_USER_ID = "ffffffff62206c1e4d2d9c00307de60b";
    public static String FUTURE_LICENSE_USER_ID = "ffffffff62260e87e81708003048cd0b";
    public static String ZERO_LICENSE_USER_ID = "ffffffff621f9f4931cf15002fbe6b5b";

    public static String EXPIRED_LICENSE_TEACHER_USERNAME = "jesko_teacher_exp";
    public static String FUTURE_LICENSE_TEACHER_USERNAME = "jesko_teacher_futurelic";
    public static String ZERO_LICENSE_TEACHER_USERNAME = "as_jesko_teacher";

    public static String MATH_SUBJECT_ID = "[1]";
    public static String READING_SUBJECT_ID = "[2]";
    public static String FLEX_SUBJECT_ID = "[1,2]";
    public static String ZERO_LICENSE_STATE_MESSAGE = "No Data Found";

    public static String focus_License_Password = "testing123$";

   

    //Constant for Save Math Motion Log
    public static String ASSIGNMENTTYPE = "assignmentType";
    public static String CURRETNT_ATTEMPT_NUMBER = "currentCumulativeAttemptNumber";
    public static String SESSION_NUMBER = "sessionNumber";
    public static String SESSION_ATTEMPT_NUMBER = "currentSessionAttemptNumber";

    public static String SME_ID_NUMBER = "smeIdValue";
    public static String LO_VALUE = "smngLoValue";
    public static String MASTERY_TABLE_VALUE = "masteryTableValue";
    public static String LO_ATTEMPT_NUMBER = "loAttemptNumber";
    public static String INTREACTION_RESULT = "interactionResult";
    public static String JUDGEMENT = "judgment";
    public static String PROBABILITY_VAL = "probabilityValue";
    public static String MOTION_DECISION = "motionDecision";
    public static String COMMENT = "comment";
    public static String PHASE = "phase";
    public static String MOTION_TYPE = "motionType";
    public static String LATENCY_TYME = "latencyTime";
    public static String TIMES_TAMP = "interactionTimestamp";
    public static String TOTAL_COURSE_TIME = "totalCourseTime";
    public static String TOTAK_IPM_TIME = "totalIpmTime";
    public static String IPM_STATUS = "ipmStatus";
    public static String IPM_LEVEL = "ipmLevel";
    public static String COURSE_AVERAGE = "courseAverage";
    public static String TOTAKSKILL_COMPLETED = "totalSkillsCompleted";
    public static String TOTAK_SKILL_MASTERED = "totalSkillsMastered";
    public static String DOMAIN_NAME = "domainName";
    public static String DEFAULT = "default";
    
  //Constant for Save Reading Motion Log
    
    public static String IPM_MINUTUES  ="ipmMinutes";
    public static String IPM_ATTEMPTS="ipmAttempts";
    public static String IPM_CORRECTS="ipmCorrects";
    public static String IPM_GP_LEVEL="ipmGPLevel";
    public static String STRAND_ID="strandId";
    public static String LESSON_ID="lessonId";
    public static String LESSON_SCORE="lessonScore";
    public static String LESSON_STATUS="lessonStatus";
    public static String LO_ID="loId";
    public static String ROLE="role";
    public static String SCO_ID="scoId";
    public static String SCO_ORDER="scoOrder";
    public static String ASSESSMENT_ITEM="assessmentItem";
    public static String SKILL_OBJECTIVEID="skillObjectiveId";
    public static String ASSESSMENT_ITEM_RESULT="assessmentItemResult";
    public static String LEARNER_RESPONSE="learnerResponse";
    public static String CORRECT_RESPONSE="correctResponse";
    public static String PROBABLITYOFGUESSING="probabilityOfGuessing";
    public static String INTERACTION_TYPE="interactionType";
    public static String INTERACTION_TIME="interactionLatencyTime";
    public static String TIMES_STAMP  = "interactionTimestamp";
    public static String JUDGEMENT_RATIONALE  = "judgmentRationale";
    public static String GPL  ="gpl";
    public static String COURSE_LEVEL  = "courseLevel";
    public static String COGNITI_LEVEL="cognitiveLevel";
    public static String FLUENCY_STATUS  ="fluencyStatus";
}
