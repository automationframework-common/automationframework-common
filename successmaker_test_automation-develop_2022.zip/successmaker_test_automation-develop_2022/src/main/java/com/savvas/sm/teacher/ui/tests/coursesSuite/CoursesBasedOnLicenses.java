package com.savvas.sm.teacher.ui.tests.coursesSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants.UserType;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class CoursesBasedOnLicenses extends BaseTest {
    private String smUrl;
    private String browser;
    private String staticCourseName = null;
    private String username = null;
    private String password = null;
    private String teacherID;
    private int courseNameListSize;
    private String newlyCreatedCourse = null;
    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    private static String teacherDetails;
    private String token = null;
    private static String studentDetails;
    BaseAPITest baseApiObject = new BaseAPITest();
    UserSqlHelper userSqlHelper = new UserSqlHelper();
    SqlHelperOrganization sqlHelperOrganization = new SqlHelperOrganization();
    Set<String> teacherNames = new HashSet<>();

    //SM Schools
    String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    String readingSchool = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    String mathFocusSchool = RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL );
    String readingFocusSchool = RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL );
    List<String> teacherUserName = new ArrayList<>();

    String flexTeacher = null;
    String mathTeacher = null;
    String readingTeacher = null;
    String mathFocusTeacher = null;
    String readingFocusTeacher = null;

    GroupAPI groupAPI = new GroupAPI();
    List<String> studentRumbaIds = new ArrayList<>();
    AssignmentAPI assignment = new AssignmentAPI();
    private HashMap<String, String> groupDetails = new HashMap<>();
    String organizationId = null;
    String userId = null;
    String groupName = null;
    String studentSMDetails;

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        List<String> schools = new ArrayList<>( Arrays.asList( flexSchool, mathSchool, readingSchool, mathFocusSchool, readingFocusSchool ) );

        /** For All License **/
        schools.forEach( element -> {
            try {
                getTestData( element );
            } catch ( Exception e ) {
                Log.message( "Issue while fetching the test data. Please check!!" );
            }
        } );

        //SM Teacher
        flexTeacher = teacherUserName.get( 0 );
        mathTeacher = teacherUserName.get( 1 );
        readingTeacher = teacherUserName.get( 2 );
        mathFocusTeacher = teacherUserName.get( 3 );
        readingFocusTeacher = teacherUserName.get( 4 );

    }

    @Test ( description = "Verify if All Courses are displayed", groups = { "SMK-57395", "Courses", "Courses - Based On License" }, priority = 1 )
    public void verifyCoursesBasedOnLicenses_001() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "TC006_Verify if All Courses are displayed." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage allCourses = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, flexTeacher, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            SMUtils.logDescriptionTC( "SMK-5358 - TC007_Verify if all courses are displayed" );

            //Select All Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            courseNameListSize = allCourses.getCourseListForCustomCourse().size();

            int courseWidgetSize = allCourses.getCourseTypesFromCoursesWidgetFromCourses().size();

            SMUtils.logDescriptionTC( "SMK-22444 - TC001_Verify the teacher is able to see all the course in Courseware>Courses page" );

            // Verify if All Courses are present
            Log.softAssertThat( Boolean.TRUE.equals( courseNameListSize >= courseWidgetSize && courseNameListSize >= Constants.FOCUS_AND_DEFAULT_COURSE_SIZE ), "All courses are present", "All courses are not present" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC002_Verify the teacher is able to see the Default Reading course in Courseware>Courses page ", groups = { "SMK-57395", "Courses", "Courses - Based On License" }, priority = 1 )
    public void verifyCoursesBasedOnLicenses_002() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "TC002_Verify the teacher is able to see the Default Reading course in Courseware>Courses page " + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage coursePage = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, readingTeacher, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            SMUtils.logDescriptionTC( "SMK-22445 - TC002_Verify the teacher is able to see the Default Reading course in Courseware>Courses page " );

            //Select All Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyCourseRemovedSuccessfully( Constants.READING ) ), "Reading course is presnet", "Reading course is absent" );

            String customByStandardReading = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( customByStandardReading, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyCourseRemovedSuccessfully( customByStandardReading ) ), "Course is created successfully", "Course is not created" );

            SMUtils.logDescriptionTC( "SMK-22462 - TC019_Verify the teacher is able to create Custom By Standards course based on Default Reading and the same is getting listed in the Courseware>Courses page" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC003_Verify the teacher is able to see the Default Math course in Courseware>Courses page", groups = { "SMK-57395", "Courses", "Courses - Based On License" }, priority = 1 )
    public void verifyCoursesBasedOnLicenses_003() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "TC003_Verify the teacher is able to see the Default Math course in Courseware>Courses page" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage coursePage = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, mathTeacher, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            SMUtils.logDescriptionTC( "SMK-22446 - TC003_Verify the teacher is able to see the Default Math course in Courseware>Courses page " );

            //Select All Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyCourseRemovedSuccessfully( Constants.MATH ) ), "Math course is presnet", "Math course is absent" );

            String customByStandardMath = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( customByStandardMath, Constants.STANDARDS, Constants.MATH );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyCourseRemovedSuccessfully( customByStandardMath ) ), "Course is created successfully", "Course is not created" );

            SMUtils.logDescriptionTC( "SMK-22459 - TC016_Verify the teacher is able to create Custom By Standards course based on Default Math and the same is getting listed in the Courseware>Courses page" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC004_Verify the teacher is able to see all the 8 Focus Math course in Courseware>Courses page ", groups = { "SMK-57395", "Courses", "Courses - Based On License" }, priority = 1 )
    public void verifyCoursesBasedOnLicenses_004() throws Exception {
        //Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "TC004_Verify the teacher is able to see all the 8 Focus Math course in Courseware>Courses page " + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage coursePage = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, mathFocusTeacher, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            SMUtils.logDescriptionTC( "SMK-22447 - TC004_Verify the teacher is able to see all the 8 Focus Math course in Courseware>Courses page" );

            //Select All Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            int courseWidgetSize = coursePage.getCourseTypesFromCoursesWidgetFromCourses().size();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( Boolean.TRUE.equals( courseWidgetSize == Constants.FOCUS_MATH_COURSE_SIZE ), "All Focus Math course is present", "Focus Math courses is absent" );

            //Traverse to Home Page
            tHomePage.topNavBar.navigateToHomeTab();

            //Check Reading or Math is present or not
            Log.softAssertThat( Boolean.TRUE.equals( coursePage.verifyCourseRemovedSuccessfully( Constants.MATH ) ), "Math course is not presnet", "Math course is present" );

            //Check Reading or Reading is present or not
            Log.softAssertThat( Boolean.TRUE.equals( coursePage.verifyCourseRemovedSuccessfully( Constants.READING ) ), "Reading course is not presnet", "Reading course is present" );

            SMUtils.logDescriptionTC( "SMK-22452 - TC009_Verify the teacher is not able to see any course at the home page untill and unless teacher has assigned any other course to the student" );

            SMUtils.logDescriptionTC( "SMK-22453 - TC010_Verify the teacher is not able to see any course at the home page untill and unless teacher has assigned any other course to the student" );

            tHomePage.topNavBar.getCourseListingPage();

            SMUtils.waitForSpinnertoDisapper( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            String customMathFocusCourse = coursePage.generateRandomCourseName();
            //Make a copy of the course
            coursePage.copyOfCourse( customMathFocusCourse, Constants.STANDARDS, Constants.SM_FOCUS_MATH_GRADE1 );

            tHomePage.topNavBar.getCourseListingPage();

            SMUtils.waitForSpinnertoDisapper( driver );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Click on the default Math course
            coursePage.clickFromCourseListingPage( customMathFocusCourse );

            //Click on the assignment
            coursePage.clickAssignBtn();

            //Assign the course to the student
            coursePage.addCourseToStudents();

            SMUtils.logDescriptionTC( "SMK-22463 - TC020_Verify the teacher is able to create Custom By Standard course based on the SM Focus Math: Grade 1 and the same is getting listed in the Courseware>Courses page" );

            tHomePage.topNavBar.navigateToHomeTab();

            //Click on the course
            coursePage.clickFromCourseListingPage( customMathFocusCourse );
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickAssignBtn();

            SMUtils.logDescriptionTC( "SMK-22455 - TC012_Verify the teacher is able to see the to latest created courses at the home page" );

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyAssignTo() ), "Assign To Modal appears for Default Math course", "Assign To modal not getting appeared" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC005_Verify the teacher is able to see all the 8 Focus Reading course Courseware>Courses page ", groups = { "SMK-57395", "Courses", "Courses - Based On License" }, priority = 1 )
    public void verifyCoursesBasedOnLicenses_005() throws Exception {
        //Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "TC005_Verify the teacher is able to see all the 8 Focus Reading course Courseware>Courses page " + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage coursePage = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, readingFocusTeacher, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            SMUtils.logDescriptionTC( "SMK-22448 - TC005_Verify the teacher is able to see all the 8 Focus Reading course Courseware>Courses page " );

            //Select All Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            int courseWidgetSize = coursePage.getCourseTypesFromCoursesWidgetFromCourses().size();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.assertThat( Boolean.TRUE.equals( courseWidgetSize == Constants.FOCUS_READING_COURSE_SIZE ), "All Focus Reading course is present", "Focus Reading courses is absent" );

            tHomePage.topNavBar.getCourseListingPage();

            SMUtils.waitForSpinnertoDisapper( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            String customReadingFocusCourse = coursePage.generateRandomCourseName();
            //Make a copy of the course
            coursePage.copyOfCourse( customReadingFocusCourse, Constants.STANDARDS, Constants.SM_FOCUS_READING_GRADE1 );

            tHomePage.topNavBar.getCourseListingPage();

            SMUtils.waitForSpinnertoDisapper( driver );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Click on the default Math course
            coursePage.clickFromCourseListingPage( customReadingFocusCourse );

            //Click on the assignment
            coursePage.clickAssignBtn();

            //Assign the course to the student
            coursePage.addCourseToStudents();

            SMUtils.logDescriptionTC( "SMK-22464 - TC021_Verify the teacher is able to create Custom By Standard course based on the SM Focus Reaidng : Grade 1 and the same is getting listed in the Courseware>Courses page" );

            tHomePage.topNavBar.navigateToHomeTab();

            //Click on the course
            coursePage.clickFromCourseListingPage( customReadingFocusCourse );
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickAssignBtn();

            SMUtils.logDescriptionTC( "SMK-22456 - TC013_Verify the teacher is able to see the to latest created courses at the home page" );

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyAssignTo() ), "Assign To Modal appears for Default Math course", "Assign To modal not getting appeared" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC006_Verify the Teacher is able to see Default Math course at the home page", priority = 1, groups = { "SMK-57395", "Courses", "Courses - Based On License" } )
    public void verifyCoursesBasedOnLicenses_006() throws Exception {
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "TC006_Verify the Teacher is able to see Default Math course at the home page<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, mathTeacher, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = new CoursesPage( driver );

            SMUtils.logDescriptionTC( "SMK-22449 - TC006_Verify the Teacher is able to see Default Math course at the home page" );

            coursePage.clickMathCourse();
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickAssignBtn();

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyAssignTo() ), "Assign To Modal appears for Default Math course", "Assign To modal not getting appeared" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC007_Verify the Teacher is able to see Default Reading course at the home page", priority = 1, groups = { "SMK-57395", "Courses", "Courses - Based On License" } )
    public void verifyCoursesBasedOnLicenses_007() throws Exception {
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "TC007_Verify the Teacher is able to see Default Reading course at the home page<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, readingTeacher, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = new CoursesPage( driver );

            SMUtils.logDescriptionTC( "SMK-22450 - TC007_Verify the Teacher is able to see Default Reading course at the home page" );

            coursePage.clickReadingCourse();
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickAssignBtn();

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyAssignTo() ), "Assign To Modal appears for Default Reading course", "Assign To modal not getting appeared" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC008_Verify the teacher is able to see Default Math and Default Reading course at the home page", priority = 1, groups = { "SMK-57395", "Courses", "Courses - Based On License" } )
    public void verifyCoursesBasedOnLicenses_008() throws Exception {
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "TC008_Verify the teacher is able to see Default Math and Default Reading course at the home page<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, flexTeacher, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = new CoursesPage( driver );

            SMUtils.logDescriptionTC( "SMK-22451 - TC008_Verify the teacher is able to see Default Math and Default Reading course at the home page" );

            coursePage.clickReadingCourse();
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickAssignBtn();

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyAssignTo() ), "Assign To Modal appears for Default Reading course", "Assign To modal not getting appeared" );

            //Assign the course to the student
            coursePage.addCourseToStudents();

            tHomePage.topNavBar.navigateToHomeTab();

            coursePage.clickMathCourse();
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.clickAssignBtn();

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyAssignTo() ), "Assign To Modal appears for Default Math course", "Assign To modal not getting appeared" );

            //Assign the course to the student
            coursePage.addCourseToStudents();

            /** Creating and assigning Custom Math course to student **/

            String mathCustomCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( mathCustomCourse, Constants.SETTINGS, Constants.MATH );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            coursePage.clickFromCourseListingPage( mathCustomCourse );

            //Click on the assignment
            coursePage.clickAssignBtn();

            //Assign the course to the student
            coursePage.addCourseToStudents();

            /** Creating and assigning Custom Reading course to student **/
            String readingCustomCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( readingCustomCourse, Constants.SETTINGS, Constants.READING );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            coursePage.clickFromCourseListingPage( readingCustomCourse );

            //Click on the assignment
            coursePage.clickAssignBtn();

            //Assign the course to the student
            coursePage.addCourseToStudents();

            /** Navigating to home page and checking **/
            tHomePage.topNavBar.navigateToHomeTab();

            //Click on the course
            coursePage.clickFromCourseListingPage( readingCustomCourse );
            SMUtils.waitForSpinnertoDisapper( driver );

            //coursePage.clickAssignBtn();
            AssignmentDetailsPage assignmentdetailspage = new AssignmentDetailsPage( driver );
            assignmentdetailspage.clickAssignButton();

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyAssignTo() ), "Assign To Modal appears for Custom Reading course", "Assign To modal not getting appeared" );

            /** Navigating to home page and checking **/
            tHomePage.topNavBar.navigateToHomeTab();

            SMUtils.waitForSpinnertoDisapper( driver );

            //Click on the course
            coursePage.clickFromCourseListingPage( mathCustomCourse );
            SMUtils.waitForSpinnertoDisapper( driver );

            //coursePage.clickAssignBtn();
            assignmentdetailspage.clickAssignButton();

            Log.assertThat( Boolean.TRUE.equals( coursePage.verifyAssignTo() ), "Assign To Modal appears for Custom Reading course", "Assign To modal not getting appeared" );

            SMUtils.logDescriptionTC( "SMK-22454 - TC011_Verify the teacher is able to see the to latest created courses along with Math and Reading at the home page" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public void getTestData( String school ) throws Exception {
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserName.add( username );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        CourseAPI coursesMethod = new CourseAPI();
        AssignmentAPI assignmentMethod = new AssignmentAPI();
        UserAPI userAPIMethod = new UserAPI();

        //Student Details
        studentDetails = RBSDataSetup.getMyStudent( school, username );
        ;
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        organizationId = RBSDataSetup.organizationIDs.get( school );

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Student SM Details
        studentSMDetails = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( school ), token ).get( Constants.REPORT_BODY );

        //Group creation
        groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );

        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

        Log.message( "Group details are" + groupDetails.toString() );

        Log.message( "Group id is " + groupId );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> Response = new HashMap<>();

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );

        Response = assignment.assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
    }

}