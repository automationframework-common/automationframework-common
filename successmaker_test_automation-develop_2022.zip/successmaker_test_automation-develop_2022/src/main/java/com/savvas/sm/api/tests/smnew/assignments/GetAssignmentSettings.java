package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class GetAssignmentSettings extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String courseName;
    private String CourseId;
    private String assignmentID;
    private String teacherUsername;
    List<String> studentRumbaIds = new ArrayList<>();

    RBSUtils rbsutils = new RBSUtils();
    GroupAPI groupAPI;
	CourseAPI courseAPI;
	SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(school , teacherUsername), Constants.USERID_HEADER) );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();

    }

    @Test ( priority = 1, dataProvider = "getRecentAssignmentsListing_PositiveFlow", groups = { "SMK-51887", "smoke_test_case", "AssignmentsSettings", "AssignmentsListing", "P1", "API" } )
    public void tcGetRecentAssignment_01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        HashMap<String, String> response = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        switch ( scenario ) {

            case "TEACHER ASSIGNED DEFAULT MATH":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                courseName = Constants.MATH;
                break;

            case "TEACHER ASSIGNED DEFAULT READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                courseName = Constants.READING;

                break;

            case "TEACHER ASSIGNED FOCUS READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                courseName = "FOCUS_READING";

                break;

            case "TEACHER ASSIGNED FOCUS MATH":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                courseName = "FOCUS_MATH";
                break;

            case "CUSTOM SETTINGS MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                courseName = "MATH";
                break;

            case "CUSTOM SKILL MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                courseName = "MATH";
                break;

            case "CUSTOM STANDARD MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                courseName = "MATH";
                break;

            case "CUSTOM SETTINGS READING":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                courseName = "READING";
                break;

            case "CUSTOM SKILL READING":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                courseName = "READING";
                break;

            case "CUSTOM STANDARD READING":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                courseName = "READING";
                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }

        HashMap<String, String> getresponse = getAssignmentSettings( smUrl, assignmentDetails );
        Log.message( getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );

        if ( courseName.contains( Constants.MATH ) ) {
            Log.assertThat( smAPIprocessor.isSchemaValid( "getAssignmentSettingsMath", CommonAPIConstants.STATUS_CODE_OK, getresponse.get( Constants.REPORT_BODY ).replace( "chinese traditional", "chinesetraditional" ) ),
                    "Schema is returned as expected.", "Schema is not as expected." );
        } else if ( courseName.contains( Constants.READING ) ) {
            Log.assertThat( smAPIprocessor.isSchemaValid( "getAssignmentSettingsReading", CommonAPIConstants.STATUS_CODE_OK, getresponse.get( Constants.REPORT_BODY ).replace( "chinese traditional", "chinesetraditional" ) ),
                    "Schema is returned as expected.", "Schema is not as expected." );
        } else if ( courseName.contains( "FOCUS_READING" ) ) {
            Log.assertThat( smAPIprocessor.isSchemaValid( "getAssignmentSettingsFocusReading", CommonAPIConstants.STATUS_CODE_OK, getresponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
        } else if ( courseName.contains( "FOCUS_MATH" ) ) {
            Log.assertThat( smAPIprocessor.isSchemaValid( "getAssignmentSettingsMath", CommonAPIConstants.STATUS_CODE_OK, getresponse.get( Constants.REPORT_BODY ).replace( "chinese traditional", "chinesetraditional" ) ),
                    "Schema is returned as expected.", "Schema is not as expected." );
        }
        Log.testCaseResult();
    }

    @Test ( priority = 2, dataProvider = "getRecentAssignmentsListing_NegativeFlow", groups = { "SMK-51887", "AssignmentsSettings", "AssignmentsListing", "P1", "API" } )
    public void tcGetRecentAssignment_02( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        String message = null;
        String exception = null;

        boolean status = false;
        HashMap<String, String> response = new HashMap<>();

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );

        switch ( scenario ) {
            case "NON EXISTING COURSEID MATH":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "10000" );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.NONEXIST_COURSEID_MATH;
                status = true;
                break;

            case "NON EXISTING COURSEID READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "20000" );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.NONEXIST_COURSEID_READING;
                status = true;
                break;

            case "INVALID ORGANIZATION":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, "AZ" );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "INVALID AUTHORIZATION":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "INVALID COURSE_ID":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "$#$" );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                message = null;
                status = true;
                break;

            case "INVALID COURSE_ID_STRING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "rr" );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                message = null;
                status = true;
                break;

            case "NULL COURSE_ID":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, " " );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );

                Log.message( response.get( "body" ) );
                exception = CommonAPIConstants.NULL_EXCEPTION;
                message = CommonAPIConstants.NULL_MESSAGE;
                status = true;
                break;

            default:
                Log.message( "Case is invalid" );
                break;

        }
        HashMap<String, String> getresponse = getAssignmentSettings( smUrl, assignmentDetails );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
        Log.message( getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        if ( message != null ) {
            verifyException( response.get( "body" ), exception, status, message );
        }



    }

    /**
     * Data provider to give the postive data
     * 
     * @return
     */
    @DataProvider ( name = "getRecentAssignmentsListing_PositiveFlow" )
    public Object[][] getRecentAssignmentsListing_PositiveFlow() {

        Object[][] inputData = {

                { "Verify the valid data To Get Assignment settings API for default Math", "TEACHER ASSIGNED DEFAULT MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get Assignment settings API for default Reading", "TEACHER ASSIGNED DEFAULT READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get Assignment settings API for Focus Reading", "TEACHER ASSIGNED FOCUS READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get Assignment settings API for Focus Math", "TEACHER ASSIGNED FOCUS MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get Assignment settings API for Custom Settings Math", "CUSTOM SETTINGS MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get Assignment settings API for Custom Skill Math", "CUSTOM SKILL MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get Assignment settings API for Custom Standards Math", "CUSTOM STANDARD MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get Assignment settings API for Custom Settings Reading", "CUSTOM SETTINGS READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get Assignment settings API for Custom Skill Reading", "CUSTOM SKILL READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid data To Get Assignment settings API for Custom Standards Reading", "CUSTOM STANDARD READING", CommonAPIConstants.STATUS_CODE_OK }, };

        return inputData;
    }

    /**
     * Data provider to give the postive data
     * 
     * @return
     */
    @DataProvider ( name = "getRecentAssignmentsListing_NegativeFlow" )
    public Object[][] getRecentAssignmentsListing_NegativeFlow() {

        Object[][] inputData = { { "Verify the non existing course id for Math", "NON EXISTING COURSEID MATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the non existing course id for Reading.", "NON EXISTING COURSEID READING", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the API returns exception when the organization is invalid.", "INVALID ORGANIZATION", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the API throwing exception when the authorization is invalid.", "INVALID AUTHORIZATION", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the API throwing exception when the Course id is invalid. ", "INVALID COURSE_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API throwing exception when the Course id is String. ", "INVALID COURSE_ID_STRING", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the API throwing exception when the Course id is non null ", "NULL COURSE_ID", CommonAPIConstants.STATUS_EMPTY },

        };
        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    /**
     * Verify the schema for the api
     * 
     * @param StatusCode
     * @param Body
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = smAPIprocessor.isSchemaValid( "/successmaker_test_automation/src/main/resources/testdata/schemaJson/getAssignmentSettingsFocusReading", StatusCode, response.get( "body" ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
        Log.assertThat( isValid, "The schema is valid and matching", "The schema is not valid and not  matching for the Status code :" + StatusCode );
    }

}