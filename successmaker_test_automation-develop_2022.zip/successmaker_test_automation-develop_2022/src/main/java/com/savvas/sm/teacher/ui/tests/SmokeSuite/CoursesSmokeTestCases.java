package com.savvas.sm.teacher.ui.tests.SmokeSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.IntStream;

import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants.UserType;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EditCourseSettingPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MyProfilePage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class CoursesSmokeTestCases extends BaseTest {

	private String smUrl;
	private String browser;
	private static String username = null;
	private static String password = DataSetupConstants.DEFAULT_PASSWORD;
	private String school;
	private String mathFocusSchool;
	private String readingFocusSchool;
	String mathFocusTeacher = null;
	String readingFocusTeacher = null;
	String studentDetails;
	String studentFirstName;
	String studentMiddleName;
	String studentLastName;
	String studentUsername;
	private String teacherID;

	@BeforeClass(alwaysRun = true)
	public void initTest(ITestContext context) {

		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
		mathFocusSchool = RBSDataSetup.getSchools(Schools.MATH_FOCUS_SCHOOL);
		readingFocusSchool = RBSDataSetup.getSchools(Schools.READING_FOCUS_SCHOOL);
		String teacherDetails = RBSDataSetup.getMyTeacher(school);
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		String teacherDetailsMathFocus = RBSDataSetup.orgTeacherDetails.get(mathFocusSchool).get("Teacher1");
		String teacherDetailsReadingFocus = RBSDataSetup.orgTeacherDetails.get(readingFocusSchool).get("Teacher1");
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		studentDetails = RBSDataSetup.getMyStudent(school, username);
		studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, "userName");

		mathFocusTeacher = SMUtils.getKeyValueFromResponse(teacherDetailsMathFocus, RBSDataSetupConstants.USERNAME);

		readingFocusTeacher = SMUtils.getKeyValueFromResponse(teacherDetailsReadingFocus,
				RBSDataSetupConstants.USERNAME);
	}

    @Test ( description = "Verify Course Listing", groups= { "Teacher Dashboard - Smoke Cases", "Teacher_TC13", "Courses", "smoke_test_case", "Admin_TC50", "P1" }, priority = 1 )
	public void tcCourseTabSmokeTest013_ATC050(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data

		Log.testCaseInfo(
				"tcCourseTabSmokeTest013_ATC050: Verify Course Listing <small><b><i>[" + browser + "]</b></i></small>");

		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			CourseListingPage courseListingPage = new CourseListingPage(driver);

			// Select All Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.ALL_COURSES);

			// Verify courses are listing in Course Listing Page
			Log.assertThat(coursePage.getCourseNameList().size() > 0, "The courses are listing successfully!",
					"The courses are not listing");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Course Details Page", groups = { "Teacher Dashboard - Smoke Cases", "Teacher_TC14", "P1", 
			"Courses", "smoke_test_case" }, priority = 1)
	public void tcCourseTabSmokeTest014(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data

		Log.testCaseInfo(
				"tcCourseTabSmokeTest014: Verify Course Details Page <small><b><i>[" + browser + "]</b></i></small>");

		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickMathCourse();

			// Verify the left side panel shows strands
			coursePage.verifyLeftStrandsDisplayedForMathCourses();

			// Verify the mid panel shows hierarchy
			coursePage.verifyMiddleHierarchyDisplayedForMathCourses();

			// Verify the right panel shows settings
			coursePage.verifySettingsDisplayedForMathCourses();

			// Verify the Skills drop are showing values
			coursePage.clickSkillsDropDown();
			Log.assertThat(coursePage.getSkillsDroppdownvalues().size() > 0, "Skills DropDown Values are Listed",
					"Skills DropDown Values are not Listed");

			// Verify the Grades drop are showing values
			coursePage.clickGradeDropDown();
			Log.assertThat(coursePage.getGradeDroppdownvalues().size() > 0, "Grades DropDown Values are Listed",
					"Grades DropDown Values are not Listed");

			// Change Grade and verify course details changing
			String defaultFirstStrandValueBefore = coursePage.getDefaultFirstStrandValueBeforeClicking();
			coursePage.selectGradeDropDownvalue();
			String firstStrandValueAfter = coursePage.getFirstStrandValueAfterClicking();
			Log.assertThat(
					!defaultFirstStrandValueBefore.equals(firstStrandValueAfter), defaultFirstStrandValueBefore
							+ " values is changed to " + firstStrandValueAfter + " after changing Grades",
					"The values are not changed after Grades");

			// Change Standard and verify course details changing
			String defaultFirstStrandValueBeforeClicking = coursePage.getDefaultFirstStrandValueBeforeClicking();
			coursePage.selectSkillsDropDownvalue();
			String firstStrandValueAfterClicking = coursePage.getFirstStrandValueAfterClicking();
			Log.assertThat(!defaultFirstStrandValueBeforeClicking.equals(firstStrandValueAfterClicking),
					defaultFirstStrandValueBeforeClicking + " values is changed to" + firstStrandValueAfterClicking
							+ " after changing standard",
					"The values are not changed after standard");

			// Verify Edit/Remove button not present for Math Course
			coursePage.verifyEditAndRemoveBtnNotPresent();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

    @Test ( description = "Verify creating a custom by settings course", groups= { "Teacher Dashboard - Smoke Cases", "Teacher_TC15", "Courses", "smoke_test_case", "P1"  }, priority = 1 )
	public void tcCourseTabSmokeTest015(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data

		Log.testCaseInfo("tcCourseTabSmokeTest015: Verify creating a custom by settings course <small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			coursePage.clickMathCourse();
			coursePage.clickMakeCopyBtn();
			String courseName = coursePage.generateRandomCourseName();

			coursePage.enterCourseName(courseName);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();

			// Verify that Initial placement is ON by default.
			coursePage.verifyInitialPlacementIsON();

			// Turn OFF Initial placement
			coursePage.turnOffInitialPlacement();

			// Verify Manually set course level is OFF by default
			coursePage.verifyManuallySetCourselevelIsOFF();
			coursePage.turnOnManuallySetCourseLevel();

			// Set course level to 1.75
			coursePage.moveSliderTo(Constants.COURSELEVEL_1_75);

			// Verifying other options are shown with default values
			coursePage.verifySpeedGamesIsON();

			// Change the other options from its default value
			coursePage.turnOffSpeedGames();
			coursePage.clickCreateBtn();

			context.setAttribute("CourseName", courseName);

			SMUtils.nap(30);

			CourseListingPage courseListingPage = new CourseListingPage(driver);
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			// Verify that the new course showed in course listing page
			Log.assertThat(coursePage.verifyCoursecreated(courseName), "Course Created Successfully",
					"Course Not Created");

			// SignOut from SM

			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

    @Test ( description = "Verify creating a custom by skills course", groups= { "Teacher Dashboard - Smoke Cases", "Teacher_TC16", "Courses", "smoke_test_case", "P2"  }, priority = 1 )
	public void tcCourseTabSmokeTest016(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tcCourseTabSmokeTest016: Verify creating a custom by skills course <small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			String staticCourseName = coursePage.generateRandomCourseName();

			coursePage.copyOfCourse(staticCourseName, Constants.SKILLS, Constants.READING);

			// Verify that the new course showed in course listing page
			Log.assertThat(coursePage.verifyCoursecreated(staticCourseName), "Course Created Successfully",
					"Course Not Created");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

    @Test ( description = "Verify creating a custom by standards course", groups= { "Teacher Dashboard - Smoke Cases", "Teacher_TC17", "Courses", "smoke_test_case", "P1" }, priority = 1 )
	public void tcCourseTabSmokeTest017(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tcCourseTabSmokeTest017: Verify creating a custom by standards course <small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			CoursesPage coursePage = new CoursesPage(driver);
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);
			// Navigate to Courses Tab
			tHomePage.topNavBar.navigateToCourseListingPage();
			String staticCourseName = coursePage.generateRandomCourseName() + System.nanoTime();

			Log.assertThat(coursePage.verifyCourseAlreadyExistsError(Constants.READING),
					"Error Message Displayed when duplicate name is provided",
					"Error Message not shown when duplicate name is provided");

			Log.assertThat(
					coursePage.verifyMakeACopyOfCourseHeader(coursePage.generateRandomCourseName() + System.nanoTime(),
							Constants.STANDARDS, Constants.READING),
					"Make A Copy Header is displayed as expected", "Make A Copy Header is not displayed as expected");

			coursePage.copyOfCourse(staticCourseName, Constants.STANDARDS, Constants.READING);

			// Verify that the new course showed in course listing page
			Log.assertThat(coursePage.verifyCoursecreated(staticCourseName), "Course Created Successfully",
					"Course Not Created");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Remove Course", groups = { "Teacher Dashboard - Smoke Cases", "Teacher_TC18", "Courses", "P2",
			"smoke_test_case" }, priority = 1)
	public void tcCourseTabSmokeTest018(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		Log.testCaseInfo(
				"tcCourseTabSmokeTest018: Verify Remove Course <small><b><i>[" + browser + "]</b></i></small>");

		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			coursePage.clickCourseName((String) context.getAttribute("CourseName"));
			coursePage.removeCourse();

			// To Verify that course is removed from course listing page
			coursePage.verifyCourseRemovedSuccessfully((String) context.getAttribute("CourseName"));

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

    @Test ( description = "Verify Course Assignment", groups= { "Teacher Dashboard - Smoke Cases", "Teacher_TC19", "Courses", "smoke_test_case", "P1" }, priority = 1 )
	public void tcCourseTabSmokeTest019(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		Log.testCaseInfo( "tcCourseTabSmokeTest019: Verify Course Assignment <small><b><i>[" + browser + "]</b></i></small>");
		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			coursePage.clickCourseName(Constants.CUSTOM_BY_SETTINGS_COURSE);
			coursePage.clickAssignBtn();

			// Adding Custom courses to Groups
			List<String> allStudentNameFromAssignPopUp = coursePage.getAllStudentNameFromAssignPopUp();

			coursePage.addCourseToGroups();

			// Adding Custom courses to Students
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Verify all students (in group and outside group) got assignments
			coursePage.clickAssignmentSubMenu();
			coursePage.clickViewAssignment(Constants.CUSTOM_BY_SETTINGS_COURSE);
			List<String> studentListfromAssignementDetailsTable = coursePage
					.getStudentListfromAssignementDetailsTable();

			int sizeOfList = Math.min(allStudentNameFromAssignPopUp.size(),
					studentListfromAssignementDetailsTable.size());
			for (int i = 0; i < sizeOfList; i++) {
				allStudentNameFromAssignPopUp.get(i).startsWith(studentListfromAssignementDetailsTable.get(i));
			}
			Log.message("Course is allocated to all Students");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the teacher is able to see all the 8 Focus Math course in Courseware>Courses page ", groups = { "Courses", "Courses - Based On License", "Admin Dashboard - Smoke Cases", "Admin_TC49", "smoke_test_case", "P2" }, priority = 1)
	public void tcCourseTabSmokeTestAdminMathFocus049() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Verify the teacher is able to see all the 8 Focus Math course in Courseware>Courses page "
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			CoursesPage coursePage = new CoursesPage(driver);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, mathFocusTeacher, password);

			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Page loading takes more time than expected. Hence providing the wait.
			SMUtils.nap(5);

			SMUtils.logDescriptionTC(
					"Verify the teacher is able to see all the 8 Focus Math course in Courseware>Courses page");

			// Select All Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.FOCUS_COURSES);

			int courseWidgetSize = coursePage.getCourseTypesFromCoursesWidgetFromCourses().size();

			// Wait for spinner to go away
			SMUtils.waitForSpinnertoDisapper(driver);

			Log.assertThat(Boolean.TRUE.equals(courseWidgetSize == Constants.FOCUS_MATH_COURSE_SIZE),
					"All Focus Math course is present", "Focus Math courses is absent");

			// Traverse to Home Page
			tHomePage.topNavBar.navigateToHomeTab();

			// Check Math is present or not
			Log.softAssertThat(Boolean.TRUE.equals(coursePage.verifyCourseRemovedSuccessfully(Constants.MATH)),
					"Math course is not presnet", "Math course is present");

			// Check Reading is present or not
			Log.softAssertThat(Boolean.TRUE.equals(coursePage.verifyCourseRemovedSuccessfully(Constants.READING)),
					"Reading course is not presnet", "Reading course is present");

			// Sign out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the teacher is able to see all the 8 Focus Reading course Courseware>Courses page ", groups = { "Courses", "Courses - Based On License", "Admin Dashboard - Smoke Cases", "Admin_TC49", "smoke_test_case", "P2" }, priority = 1)
	public void tcCourseTabSmokeTestAdminReadingFocus049() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Verify the teacher is able to see all the 8 Focus Reading course Courseware>Courses page "
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			CoursesPage coursePage = new CoursesPage(driver);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, readingFocusTeacher,
					password);

			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Page loading takes more time than expected. Hence providing the wait.
			SMUtils.nap(5);

			SMUtils.logDescriptionTC(
					"Verify the teacher is able to see all the 8 Focus Reading course Courseware>Courses page ");

			// Select All Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.FOCUS_COURSES);

			int courseWidgetSize = coursePage.getCourseTypesFromCoursesWidgetFromCourses().size();

			// Wait for spinner to go away
			SMUtils.waitForSpinnertoDisapper(driver);

			Log.assertThat(Boolean.TRUE.equals(courseWidgetSize == Constants.FOCUS_READING_COURSE_SIZE),
					"All Focus Reading course is present", "Focus Reading courses is absent");

			// Sign out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify if teacher is able to see Student's progress in a graphical view for a particular assignment", groups = { "Teacher Dashboard - Smoke Cases", "Teacher_TC51", "Courses", "smoke_test_case", "Progress_Monitoring_Graph", "P1" }, priority = 1)
	public void tcCourseTabSmokeTest046() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data
		Log.testCaseInfo(
				"tcCourseTabSmokeTest046: Verify if teacher is able to see Student's progress in a graphical view for a particular assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			// Get CourseLising Page
			CourseListingPage courseListingPage = new CourseListingPage(driver);

			String Custom_Settings_Reading = Constants.CUSTOM_READING_ASSIGMENT_TITLE + System.nanoTime();
			// create Reading custom course by settings
			coursePage.createCustomBySettingCourseWithIPOff(Custom_Settings_Reading, Constants.READING);
			
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			// Assigning Course to student
			coursePage.clickFromCourseListingPage(Custom_Settings_Reading);
			SMUtils.waitForSpinnertoDisapper(driver);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			// SignOut
			tHomePage.topNavBar.signOutfromSM();

			// Get driver
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUsername,
					password);

			StudentDashboardPage stuPage = new StudentDashboardPage(studentDriver);
			// Course Execution
			IntStream.rangeClosed(1, 4).forEach(value -> {
				Log.message("Reading Custom Course Execution");
				try {
					stuPage.executeReadingCourse(teacherID, Custom_Settings_Reading, "95", "2", "25");
				} catch (IOException e) {
					Log.message("Error occurred while running the simulator");
				}

			});
			// Logout
			SMUtils.nap(10);
			stuPage.logout();
			studentDriver.quit();

			// Navigate to teacher page again
			driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");
			// Navigate to Courseware tab
			SMUtils.nap(10);
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Custom_Settings_Reading);
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			String studentName = assignmentDetailsPage.getStudentName(
					SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));
			assignmentDetailsPage.clickStudentAccordionButton(studentName);
			Log.assertThat(assignmentDetailsPage.isProgressMonitoringGraphDisplayed(),
					"Progress Monitoring Graph Displayed Successfuly", "Progress Monitoring Graph Not Displayed");
			SMUtils.logDescriptionTC(
					"Verify if the all the Legend details are displayed to the right side of the graph<small><b><i>["
							+ browser + "]</b></i></small>");
			Log.assertThat(assignmentDetailsPage.isLegendsDisplayed(), "Legends Displayed Successfuly",
					"Legends Not Displayed");
			SMUtils.logDescriptionTC(
					"Verify if teacher is able to see Primary Target<small><b><i>[" + browser + "]</b></i></small>");
			Log.assertThat(assignmentDetailsPage.checkLegendNames(Constants.PRIMARY_TARGET),
					"Primary Target Displayed Successfuly", "Primary Target Not Displayed");
			SMUtils.logDescriptionTC(
					"Verify if teacher is able to see Secondary Target<small><b><i>[" + browser + "]</b></i></small>");
			Log.assertThat(assignmentDetailsPage.checkLegendNames(Constants.SECONDARY_TARGET),
					"Secondary Target Displayed Successfuly", "Secondary Target Not Displayed");
			// Sign Out
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Custom Reading courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button.", groups = {	"Teacher Dashboard - Smoke Cases", "Teacher_TC51", "Courses", "smoke_test_case", "View Assigned By Pop up", "P2" }, priority = 1)
	public void tcCourseTabSmokeTest051() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		Log.testCaseInfo(
				"Verify the Custom Reading courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			CoursesPage customCourses = new CoursesPage(driver);
			
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);

			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			List<String> studentList = new ArrayList<>();
			List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
			EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage(driver);
			
			String staticCourseName = customCourses.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.STANDARDS, Constants.READING);

			SMUtils.logDescriptionTC(
					"Verify the Custom Reading courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button.");

			SMUtils.logDescriptionTC(
					"Verify the course owner teacher is able to see the name of the teacher in the 'Assigned By' popup who has assigned the shared custom Reading course created by the course owner teacher");

			SMUtils.logDescriptionTC(
					"Verify the course owner teacher is able to see the name of the teacher in the 'Assigned By' popup who has assigned the shared custom focus Reading course created by the course owner teacher");

			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();

			// Page loading takes more time than expected. Hence providing the wait.
			SMUtils.nap(5);

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DESCENDING_ORDER);

			// Click on the course
			customCourses.clickFromCourseListingPage(staticCourseName);
			
			//To verify edit button & Ellipis icon
			Log.assertThat(customCourses.isEditBtnDisplayed(), "Edit button is displayed", "Edit button is not displayed");
			
			// Click on the assignment
			customCourses.clickAssignBtn();

			// Get the count of the student from the assignment pop up
			studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

			// Assign the course to the student
			customCourses.addCourseToStudents();

			// Traverse to the assignment
			customCourses.clickAssignmentSubMenu();

			// Click on the View Assignment
			customCourses.clickOnTheHoveredAssignment(staticCourseName);

			// Verify whether the student is present in the particular assignment
			studentList = customCourses.getStudentListfromAssignementDetailsTable();

			// Traverse to Courseware>Courses
			tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DESCENDING_ORDER);

			// Click on the course
			customCourses.clickFromCourseListingPage(staticCourseName);
			
			// Click on the ellipses icon
			customCourses.clickEllipsisIcon();

			// Click on the View Assigned pop up
			customCourses.clickViewAssignedByButton();

			// Verify whether the 'Assigned By' text is present
			customCourses.viewAssignedByPopupTitle();

			// Verify whether the 'Close' button is present
			customCourses.viewAssignedByPopupCloseButton();

			// Sign out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Teacher who created the course is able to 'Remove' the course from the Dashboard Courseware Widget>Courses section once all the listed teachers in the Assigned By popup have removed the students from the shared course", groups = { "Teacher Dashboard - Smoke Cases", "Teacher_TC51", "Courses", "smoke_test_case",	"View Assigned By Pop up", "P2" }, priority = 1)
	public void tcCourseTabSmokeTest052() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		Log.testCaseInfo(
				"Verify the Teacher who created the course is able to 'Remove' the course from the Dashboard Courseware Widget>Courses section once all the listed teachers in the Assigned By popup have removed the students from the shared course."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			CoursesPage customCourses = new CoursesPage(driver);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);

			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
			EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage(driver);

			String staticCourseName = customCourses.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.STANDARDS, Constants.MATH);

			SMUtils.logDescriptionTC(
					"Verify the unshared Custom Math courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button.");

			SMUtils.logDescriptionTC(
					"Verify the Teacher who created the course is able to 'Remove' the course from the Dashboard Courseware Widget>Courses section once all the listed teachers in the Assigned By popup have removed the students from the shared course");

			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();

			// Page loading takes more time than expected. Hence providing the wait.
			SMUtils.nap(5);

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DESCENDING_ORDER);

			// Click on the course
			customCourses.clickFromCourseListingPage(staticCourseName);

			// Click on the assignment
			customCourses.clickAssignBtn();

			// Get the count of the student from the assignment pop up
			studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

			// Assign the course to the student
			customCourses.addCourseToStudents();

			// Traverse to the assignment
			customCourses.clickAssignmentSubMenu();

			// Traverse to Assignment Tab
			tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on the Assignment
			customCourses.clickOnTheHoveredAssignment(staticCourseName);

			// Traverse to the Courseware
			tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DESCENDING_ORDER);

			// Click on the course name
			customCourses.clickFromCourseListingPage(staticCourseName);

			// Assertion
			Log.softAssertThat(!editCourseSettingPage.isEditButtonDisplayed(), "Edit button is not displayed!",
					"Edit button is displayed");

			// Sign out
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

}
