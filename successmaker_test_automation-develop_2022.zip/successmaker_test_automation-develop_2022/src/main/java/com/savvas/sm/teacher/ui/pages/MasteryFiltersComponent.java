package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class MasteryFiltersComponent {

    private WebDriver driver;
    public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();
    WebElement shadowTree = null;

    // ********* Mastery Filters Component Elements ***************
    @IFindBy ( how = How.CSS, using = "mastery-filters-container .card button[aria-expanded='false'],admin-mastery-container .card button[aria-expanded='false']" , AI=false)
    public WebElement btnExpandFilter;

    @IFindBy ( how = How.CSS, using = "mastery-filters-container .card button[aria-expanded='true'],admin-mastery-container .card button[aria-expanded='true']" , AI=false)
    public WebElement btnCollapseFilter;

    @IFindBy ( how = How.CSS, using = "mastery-filters-container .card .accordion-data >div:nth-of-type(1) #cel-rb-0" , AI=false)
    public WebElement rbGroupDropdown;

    @IFindBy ( how = How.CSS, using = "mastery-filters-container .card .accordion-data >div:nth-of-type(1) #cel-rb-1" , AI=false)
    public WebElement rbStudentsDropdown;

    @FindBy ( css = ".disable-dropdown-groups" )
    List<WebElement> drdGroupDisabled;

    @FindBy ( css = ".disable-dropdown-students" )
    List<WebElement> drdStudentsDisabled;

    /***** Start - Locators for Subject/Skill&Standard Drop down *****/

    @IFindBy ( how = How.CSS, using = ".step-2>div:nth-of-type(1) cel-dropdown-select button[aria-expanded='false']" , AI=false)
    public WebElement drdExpandSubject;

    @IFindBy ( how = How.CSS, using = ".step-2>div:nth-of-type(1) cel-dropdown-select button[aria-expanded='true']" , AI=false)
    public WebElement drdCollapseSubject;

    @IFindBy ( how = How.CSS, using = ".skills-dropdown cel-dropdown-select button[aria-expanded='false']" , AI=false)
    public WebElement drdExpandSkillStandards;

    @IFindBy ( how = How.CSS, using = ".skills-dropdown cel-dropdown-select button[aria-expanded='true']" , AI=false)
    public WebElement drdCollapseSkillStandards;

    @IFindBy ( how = How.CSS, using = "mastery-filter-organizations .dropdown-select-options-wrapper[aria-hidden='false']" , AI=false)
    public WebElement drdExpandOrganization;

    @IFindBy ( how = How.CSS, using = "mastery-filter-organizations .dropdown-select-options-wrapper[aria-hidden='true']" , AI=false)
    public WebElement drdCollapseOrganization;

    @IFindBy ( how = How.CSS, using = ".step-2>div:nth-of-type(1) cel-dropdown-select .dropdown-select-label" , AI=false)
    public WebElement lblSelectedValueSubject;

    @IFindBy ( how = How.CSS, using = ".step-2>div:nth-of-type(2) cel-dropdown-select .dropdown-select-label" , AI=false)
    public WebElement lblSelectedValueSkillStandard;

    @IFindBy ( how = How.CSS, using = "mastery-filter-organizations .dropdown-select-label" , AI=false)
    public WebElement lblSelectedValueOrganization;

    @FindBy ( css = ".step-2>div:nth-of-type(1) cel-dropdown-select div[aria-hidden='false'] li" )
    List<WebElement> dropDownSubjectItems; // List<WebElement>

    @FindBy ( css = ".skills-dropdown cel-dropdown-select div[aria-hidden='false'] li" )
    List<WebElement> dropDownSkillStandardsItems; // List<WebElement>

    @FindBy ( css = "mastery-filter-organizations .dropdown-select-options li span" )
    List<WebElement> dropDownOrganizationItems; // List<WebElement>

    @IFindBy ( how = How.CSS, using = ".skills-dropdown button.dropdown-select-trigger" , AI=false)
    public WebElement skillsStandardsDropdown;

    @IFindBy ( how = How.CSS, using = ".assignments-select cel-multi-check-dropdown" , AI=false)
    public WebElement assignmentsDropdown;

    @IFindBy ( how = How.CSS, using = "div.accordion-wrapper button.accordion-header.clickable" , AI=false)
    public WebElement toogleExpandOrCollapse;

    @IFindBy ( how = How.CSS, using = "div.accordion-wrapper button.accordion-header.clickable>span.toggle-btn" , AI=false)
    public WebElement toogleBtn;

    @IFindBy(how = How.CSS, using = "div.header-title>span", AI = false)
	public WebElement headerMasteryText;

    @FindBy ( css = "div label" )
    List<WebElement> dropdownLabels;
    
    @FindBy ( css = "div.report-body-wrapper cel-accordion-item" )
    WebElement optionalFilterRoot;
    
    String txtDropDownValue = "a span"; // used with dropDownSubjectItem and dropDownSkillStandardItem

    String tickMark = "cel-icon"; // used with dropDownSubjectItem and dropDownSkillStandardItem

    /***** End - Locators for Subject/Skill&Standard Drop down *****/

    /***** Start- Locators should be used with shadow root element *****/

    /*****
     * Start - Locators related to Group/Students/Assignments Drop down
     *****/

    String selectAllOptionChild1 = "div.dropdown-list cel-checkbox";

    String selectAllOptionChild2 = "div span";

    String assignmentDrpdownChild1 = "cel-icon";

    String assignmentDrpdownChild2 = "img.icon-inner";

    String shadowRootForGroups = "mastery-step-one-filters .form-row>div:nth-of-type(1) .step-1-dropdown-width cel-multi-check-dropdown";

    String shadowRootForStudents = "mastery-step-one-filters .form-row>div:nth-of-type(2) .step-1-dropdown-width cel-multi-check-dropdown";

    String shadowRootForAssignments = ".step-2>div:nth-of-type(3) cel-multi-check-dropdown";

    String drpSelectedValueDropDownMS = ".dropdown-head";

    String expandDropDownMS = ".multi-check-dropdown-container .head-icons>cel-icon[aria-pressed='false']";

    String collapseDropDownMS = ".multi-check-dropdown-container .head-icons>cel-icon[aria-pressed='true']";

    String shadowRootSelectAllDropDownMS = ".multi-check-dropdown-container .dropdown-list .dropdown-list-head cel-checkbox";

    String shadowRootSelectDropDownMS = ".multi-check-dropdown-container .dropdown-list .dropdown-scroll .dropdown-list-items .dropdown-single-select cel-checkbox";// List<WebElement>

    String txtDropDownMSValue = ".primary__checkbox";// Get the text from MS_dropdown options

    String chxSelectDropDownMS = "input";// Get the text from MS_dropdown options
    
    private String singleSelectDropdownRoot = "cel-single-select.hydrated";


    /***** End - Locators related to Group/Students/Assignments Drop down *****/

    /***** End- Locators should be used with shadow root element *****/

    @IFindBy ( how = How.CSS, using = ".apply-button" , AI=false)
    public WebElement btnApplyFilterRoot;

    @IFindBy ( how = How.CSS, using = ".reset-button" , AI=false)
    public WebElement btnResetFilterRoot;

    public static String btnApplyFilterChild = ".primary_button";
    public static String btnResetFilterChild = ".secondary_button";

    //Filters
    @IFindBy ( how = How.CSS, using = "button[aria-expanded='false'] cel-icon" , AI=false)
    public WebElement filtersShodowHost;

    //Filters child css
    public static String filtersCss = "img[alt='icon caret right']";

    @IFindBy ( how = How.CSS, using = "form.ng-valid.ng-touched.ng-dirty" , AI=false)
    public WebElement formAllFiltersOptions;
 // Mastery tool tip
 	@IFindBy(how = How.CSS, using = "div cel-multi-part-progress-bar[title]", AI = false)
 	public WebElement skillDetailsInProgressBarToolTip;
    public MasteryFiltersComponent() {}
    /**
     *
     * Constructor class for Mastery Filters Component and initializing the
     * driver for page factory objects.
     *
     * @param driver
     * @param url
     */
    public MasteryFiltersComponent( WebDriver driver ) {
        this.driver = driver;
        // Have Topbar here and init
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
    	PageFactory.initElements(finder, this);
    	elementLayer = new ElementLayer(driver);
        SMUtils.fluentWaitForElement( driver, btnCollapseFilter );
    }

    /***** Start - Multi-Select Dropdown methods *****/

    /***
     * Set the multi-select dropdown
     *
     * @param ms_dropdown
     */
    public void setDropDownMS( String ms_dropdown ) {
        if ( ms_dropdown.toLowerCase().equals( Constants.MasteryUI.GROUPS ) ) {
            shadowTree = driver.findElement( By.cssSelector( shadowRootForGroups ) );
            // select group radio button
            checkGroupsRB();
        } else if ( ms_dropdown.toLowerCase().equals( Constants.MasteryUI.STUDENTS ) ) {
            shadowTree = driver.findElement( By.cssSelector( shadowRootForStudents ) );
            // select students radio button
            checkStudentsRB();
        } else if ( ms_dropdown.toLowerCase().equals( Constants.MasteryUI.ASSIGNMENTS ) )
            shadowTree = driver.findElement( By.cssSelector( shadowRootForAssignments ) );

        // scroll the respective drop down into the view
        // SMUtils.scrollWebElementToView(driver, shadowTree);
    }

    /**
     * Click Apply filter button
     */

    public MasterySummaryComponent applyFilter() throws Exception {
        Thread.sleep( 2000 ); //Page refresh is happening while switching between dropdown. Sometimes dynamic wait is not working.
        WebElement applyBtn = SMUtils.getWebElementDirect( driver, btnApplyFilterRoot, btnApplyFilterChild );
        SMUtils.waitForElement( driver, applyBtn );
        SMUtils.clickJS( driver, applyBtn );
        Log.message( "Clicked apply filter!", driver );
        Thread.sleep( 5000 );
        return new MasterySummaryComponent( driver );
    }

    /**
     * Click on Apply filter button
     */
    public void clickApplyFilter() {

        WebElement actualElement = SMUtils.getWebElementDirect( driver, btnApplyFilterRoot, btnApplyFilterChild );
        SMUtils.waitForElement( driver, actualElement );
        SMUtils.clickJS( driver, actualElement );
        Log.message( "Clicked apply filter!", driver );
    }

    /**
     * Click Reset filter button
     */
    public void resetFilter() {
        WebElement resetBtn = SMUtils.getWebElementDirect( driver, btnResetFilterRoot, btnResetFilterChild );
        SMUtils.clickJS( driver, resetBtn );
        Log.message( "Clicked reset filter!", driver );

        SMUtils.scrollWebElementToView( driver, btnCollapseFilter );
    }

    /**
     * To expand Filters
     */
    public void clickFilters() {
        WebElement actualFilterElement = SMUtils.getWebElementDirect( driver, filtersShodowHost, filtersCss );
        SMUtils.waitForElement( driver, actualFilterElement, 5 );
        SMUtils.clickJS( driver, actualFilterElement );
        Log.message( "clicked on Filters" );
    }

    /***
     * Checks whether groups radio button is selected or not
     *
     * @return
     */
    public boolean isGroupsChecked() {
        boolean isChecked = false;

        isChecked = rbGroupDropdown.isSelected();

        return isChecked;
    }

    /***
     * Checks the Groups Radio button
     */
    public void checkGroupsRB() {
        if ( !isGroupsChecked() ) {
            rbGroupDropdown.click();
        }
    }

    /***
     * Checks whether groups dropdown is disabled
     *
     * @return
     */
    public boolean isGroupsDropDownDisabled() {
        boolean isDisabled = false;

        isDisabled = drdGroupDisabled.size() > 0;
        return isDisabled;
    }

    /***
     * Checks whether students radio button is selected or not
     *
     * @return
     */
    public boolean isStudentsChecked() {
        boolean isChecked = false;

        isChecked = rbStudentsDropdown.isSelected();

        return isChecked;
    }

    /***
     * Checks the Students Radio button
     */
    public void checkStudentsRB() {
        SMUtils.scrollIntoView( driver, rbStudentsDropdown );
        if ( !isStudentsChecked() ) {
            SMUtils.click( driver, rbStudentsDropdown );
        }
    }

    /***
     * Checks whether students dropdown is disabled
     *
     * @return
     */
    public boolean isStudentsDropDownDisabled() {
        boolean isDisabled = false;

        isDisabled = drdStudentsDisabled.size() > 0;

        return isDisabled;
    }

    /***
     * Gets the selected value from DropDown_MS
     *
     * @return String of selected value from DropDown_MS
     */
    public String getDropDownMSSelectedValue() {
        WebElement getSelectedValueFromGroup = SMUtils.getWebElement( driver, shadowTree, drpSelectedValueDropDownMS );
        String returnString = getSelectedValueFromGroup.getText();
        return returnString;
    }

    /***
     * Checks and return the Collapsed state as boolean for Multi-Select drop
     * down
     *
     * @return
     */
    public boolean isDropDownMSCollapsed() {
        boolean isDropDownMSCollapsed = false;

        List<WebElement> dropDownMS_Expanded = SMUtils.getWebElements( driver, shadowTree, expandDropDownMS );
        isDropDownMSCollapsed = dropDownMS_Expanded.size() > 0;
        return isDropDownMSCollapsed;
    }

    /***
     * Checks and return the Expanded state as boolean for Multi-Select drop
     * down
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isDropDownMSExpanded() throws InterruptedException {
        boolean isDropDownMSExpanded = false;

        SMUtils.nap( 1 ); // remove before commit
        List<WebElement> dropDownMS_Collapsed = SMUtils.getWebElements( driver, shadowTree, collapseDropDownMS );
        isDropDownMSExpanded = dropDownMS_Collapsed.size() > 0;
        return isDropDownMSExpanded;
    }

    /***
     * Get values from Multi-Select drop down
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getValuesFromDropDownMS() throws Exception {

        List<String> msDropDownValues = new ArrayList<>();

        if ( Objects.isNull( shadowTree ) )
            throw new Exception( "Set DropdownMS value first" );

        // is Dropdown selected - TODO

        // expand ms drop down
        expandDropDownMS();

        // get values from ms drop down
        List<WebElement> msValuesList = SMUtils.getWebElements( driver, shadowTree, shadowRootSelectDropDownMS );

        for ( WebElement value : msValuesList ) {
            WebElement txtGroupStudents = SMUtils.getWebElement( driver, value, txtDropDownMSValue );
            msDropDownValues.add( txtGroupStudents.getText() );
        }
        return msDropDownValues;
    }

    /***
     * Get selected values from Multi-Select drop down
     *
     * @return List<String>
     * @throws Exception
     */
    public List<String> getSelectedValuesFromDropDownMS() throws Exception {

        List<String> msDropDownValues = new ArrayList<>();

        if ( Objects.isNull( shadowTree ) )
            throw new Exception( "Set DropdownMS value first" );

        // is Dropdown selected - TODO

        // expand ms drop down
        expandDropDownMS();

        // get values from ms drop down
        List<WebElement> msValuesList = SMUtils.getWebElements( driver, shadowTree, shadowRootSelectDropDownMS );

        for ( WebElement value : msValuesList ) {
            if ( SMUtils.getWebElement( driver, value, chxSelectDropDownMS ).isSelected() ) {
                WebElement txtGroupStudents = SMUtils.getWebElement( driver, value, txtDropDownMSValue );
                msDropDownValues.add( txtGroupStudents.getText() );
            }
        }
        return msDropDownValues;
    }

    public Integer getSelectedCountFromDropDownMs() throws Exception {
        int dataToReturn;
        List<String> msDropDownValues = new ArrayList<>();

        if ( Objects.isNull( shadowTree ) )
            throw new Exception( "Set DropdownMS value first" );

        // is Dropdown selected - TODO

        // expand ms drop down
        expandDropDownMS();

        // get values from ms drop down
        List<WebElement> msValuesList = SMUtils.getWebElements( driver, shadowTree, shadowRootSelectDropDownMS );

        for ( WebElement value : msValuesList ) {
            if ( SMUtils.getWebElement( driver, value, chxSelectDropDownMS ).isSelected() ) {
                WebElement txtGroupStudents = SMUtils.getWebElement( driver, value, txtDropDownMSValue );
                msDropDownValues.add( txtGroupStudents.getText() );
            }
        }

        if ( msDropDownValues.size() > 0 ) {
            dataToReturn = msDropDownValues.size();
        } else
            dataToReturn = 0;
        return dataToReturn;
    }

    /***
     * expand multi-select drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void expandDropDownMS() throws InterruptedException {

        if ( isDropDownMSCollapsed() ) {
            WebElement btnDropDownExpand = SMUtils.getWebElement( driver, shadowTree, expandDropDownMS );
            SMUtils.click( driver, btnDropDownExpand );

            if ( !isDropDownMSExpanded() ) {
                SMUtils.click( driver, btnDropDownExpand );
                Log.message( "DropDown Expand- Successful" );
            }
        }
    }

    /***
     * collapse multi-select drop down
     *
     * @return
     */
    public void collapseDropDownMS() {

        if ( isDropDownMSCollapsed() ) {
            WebElement btnDropDownCollapse = SMUtils.getWebElement( driver, shadowTree, collapseDropDownMS );
            btnDropDownCollapse.click();
        }

        Log.assertThat( isDropDownMSCollapsed(), "DropDown Collapsed-Successful", "DropDown Collapsed-Not Successful" );
    }

    /***
     * Get the Select All Checkbox
     *
     * @return WebElement
     * @throws InterruptedException
     */
    private WebElement getSelectAllCheckboxElementForDropDownMS() throws InterruptedException {

        // expand ms dropdown
        expandDropDownMS();
        WebElement selectAllWrapper = SMUtils.getWebElement( driver, shadowTree, shadowRootSelectAllDropDownMS );
        WebElement selectAllCheckboxWrapper = SMUtils.getWebElement( driver, selectAllWrapper, txtDropDownMSValue );
        WebElement selectAllCheckbox = SMUtils.getChildWebElementFromParent( selectAllCheckboxWrapper, chxSelectDropDownMS );

        SMUtils.scrollWebElementToView( driver, shadowTree );
        return selectAllCheckbox;
    }

    /***
     * Get the Multi-select drop down checkboxs label
     *
     * @return WebElement
     * @throws InterruptedException
     */
    private List<WebElement> getCheckboxLabelElementsForDropDownMS() throws InterruptedException {
        List<WebElement> selectCheckboxWrapper = new ArrayList<>();
        // expand ms dropdown
        expandDropDownMS();

        List<WebElement> selectValueWrappers = SMUtils.getWebElements( driver, shadowTree, shadowRootSelectDropDownMS );

        for ( WebElement selectValueWrapper : selectValueWrappers ) {
            selectCheckboxWrapper.add( SMUtils.getWebElement( driver, selectValueWrapper, txtDropDownMSValue ) );
        }

        SMUtils.scrollWebElementToView( driver, shadowTree );
        return selectCheckboxWrapper;
    }

    /***
     * un-check the select all checkbox for multi-select drop down
     *
     * @throws InterruptedException
     */
    public void unCheckSelectAllDropdownMS() throws InterruptedException {

        List<String> defaultValuesDropDownMS = new ArrayList<>();
        defaultValuesDropDownMS.add( "Select Group(s)" );
        defaultValuesDropDownMS.add( "Select Student(s)" );
        defaultValuesDropDownMS.add( "Select Assignment(s)" );

        WebElement selectAllCheckbox = getSelectAllCheckboxElementForDropDownMS();

        // uncheck -1
        if ( selectAllCheckbox.isSelected() )
            SMUtils.clickJS( driver, selectAllCheckbox );
        else if ( !defaultValuesDropDownMS.contains( getDropDownMSSelectedValue() ) )
            SMUtils.clickJS( driver, selectAllCheckbox );

        Log.assertThat( !selectAllCheckbox.isSelected(), "Successful_Uncheck->Select All-Checkbox", "Unsuccessful_Uncheck->Select All-Checkbox" );
    }

    /***
     * check the select all checkbox for multi-select drop down
     *
     * @throws InterruptedException
     */
    public void checkSelectAllDropdownMS() throws InterruptedException {
        SMUtils.scrollIntoView( driver, btnCollapseFilter );
        WebElement selectAllCheckbox = getSelectAllCheckboxElementForDropDownMS();
        // uncheck -1
        if ( !selectAllCheckbox.isSelected() )
            SMUtils.click( driver, selectAllCheckbox );

        Log.assertThat( selectAllCheckbox.isSelected(), "Successful_Check->Select All-Checkbox", "Unsuccessful_Check->Select All-Checkbox" );
    }

    /***
     * Select given values from multi-select drop down for multi-select drop
     * down
     *
     * @param valuesToSelect
     * @throws InterruptedException
     */
    public void selectValuesFromDropDownMS( List<String> valuesToSelect ) throws InterruptedException {
        // uncheck all
        unCheckSelectAllDropdownMS();
        List<WebElement> selectValueWrapperElements = getCheckboxLabelElementsForDropDownMS();

        for ( WebElement selectValueWrapperElement : selectValueWrapperElements ) {
            String selectCheckboxValue = selectValueWrapperElement.getText();
            if ( valuesToSelect.contains( selectCheckboxValue.trim() ) ) {
                WebElement selectCheckbox = SMUtils.getChildWebElementFromParent( selectValueWrapperElement, chxSelectDropDownMS );
                SMUtils.scrollIntoView( driver, selectCheckbox );
                SMUtils.clickJS( driver, selectCheckbox );
            }
        }
    }

    /***
     * Select values based on the given index from multi-select drop down for
     * multi-select drop down
     *
     * @param valuesToSelect
     * @throws InterruptedException
     */
    public void selectValuesByIndexFromDropDownMS( List<Integer> indexToSelect ) throws InterruptedException {
        // uncheck all
        unCheckSelectAllDropdownMS();
        List<WebElement> selectValueWrapperElements = getCheckboxLabelElementsForDropDownMS();

        for ( int i = 0; i < selectValueWrapperElements.size(); i++ ) {
            WebElement selectValueWrapperElement = selectValueWrapperElements.get( i );
            if ( indexToSelect.contains( i ) ) {
                WebElement selectCheckbox = SMUtils.getChildWebElementFromParent( selectValueWrapperElement, chxSelectDropDownMS );
                SMUtils.scrollIntoView( driver, selectCheckbox );
                SMUtils.clickJS( driver, selectCheckbox );
            }
        }
    }

    /***** End - Multi-Select Dropdown methods *****/

    /***** Start - Single-Select Dropdown methods *****/

    /***
     * Gets the selected value from Subject DropDown
     *
     * @return String of selected value from DropDown_MS
     */
    public String getSubjectDropDownSelectedValue() {
        String returnString = lblSelectedValueSubject.getText().trim();
        return returnString;
    }

    /***
     * Gets the selected value from SkillStandard DropDown
     *
     * @return String of selected value from DropDown_MS
     */
    public String getSkillStandardDropDownSelectedValue() {
        SMUtils.waitForElement( driver, lblSelectedValueSkillStandard );
        return lblSelectedValueSkillStandard.getText().trim();
    }

    /***
     * Gets the selected value from Organization DropDown
     *
     * @return String of selected value from DropDown_MS
     */
    public String getOrganizationDropDownSelectedValue() {
        String returnString = lblSelectedValueOrganization.getText().trim();
        return returnString;
    }

    /***
     * Checks and return the Collapsed state as boolean for Subject drop down
     *
     * @return
     */
    public boolean isSubjectDropDownCollapsed() {
        boolean isSubjectDropDownCollapsed = false;

        // isSubjectDropDownCollapsed = drdExpandSubject.size() > 0;
        isSubjectDropDownCollapsed = SMUtils.fluentWaitForElement( driver, drdExpandSubject, 1 );

        return isSubjectDropDownCollapsed;
    }

    /***
     * Checks and return the Expanded state as boolean for Subject drop down
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isSubjectDropDownExpanded() throws InterruptedException {
        boolean isSubjectDropDownExpanded = false;

        // isSubjectDropDownExpanded = drdCollapseSubject.size() > 0;
        isSubjectDropDownExpanded = SMUtils.fluentWaitForElement( driver, drdCollapseSubject, 1 );
        return isSubjectDropDownExpanded;
    }

    /***
     * Checks and return the Collapsed state as boolean for SkillStandards drop
     * down
     *
     * @return
     */
    public boolean isSkillStandardsDropDownCollapsed() {
        boolean isSkillStandardsDropDownCollapsed = false;

        // isSkillStandardsDropDownCollapsed = drdExpandSkillStandards.size() > 0;
        isSkillStandardsDropDownCollapsed = SMUtils.fluentWaitForElement( driver, drdExpandSkillStandards, 3 );

        return isSkillStandardsDropDownCollapsed;
    }

    /***
     * Checks and return the Expanded state as boolean for SkillStandards drop
     * down
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isSkillStandardsDropDownExpanded() throws InterruptedException {
        boolean isSkillStandardsDropDownExpanded = false;

        // isSkillStandardsDropDownExpanded = drdCollapseSkillStandards.size() > 0;
        isSkillStandardsDropDownExpanded = SMUtils.fluentWaitForElement( driver, drdCollapseSkillStandards, 3 );

        return isSkillStandardsDropDownExpanded;
    }

    /***
     * Checks and return the Collapsed state as boolean for Organization drop
     * down
     *
     * @return
     */
    public boolean isOrganizationDropDownCollapsed() {
        boolean isOrganizationDropDownCollapsed = false;

        isOrganizationDropDownCollapsed = SMUtils.fluentWaitForElement( driver, drdExpandOrganization, 1 );

        return isOrganizationDropDownCollapsed;
    }

    /***
     * Checks and return the Expanded state as boolean for Organization drop
     * down
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isOrganizationDropDownExpanded() throws InterruptedException {
        boolean isOrganizationDropDownExpanded = false;

        isOrganizationDropDownExpanded = SMUtils.fluentWaitForElement( driver, drdCollapseOrganization, 1 );
        return isOrganizationDropDownExpanded;
    }

    /***
     * expand subject drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void expandSubjectDropDown() throws InterruptedException {

        if ( isSubjectDropDownCollapsed() ) {
            // drdExpandSubject.get(0).click();
            SMUtils.fluentWaitForElement( driver, drdExpandSubject, 3 );
            SMUtils.click( driver, drdExpandSubject );
        }

        if ( !isSubjectDropDownExpanded() ) {
            SMUtils.click( driver, drdExpandSubject );
            Log.message( "DropDown Expand- Successful" );
        }
    }

    /***
     * collapse subject drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void collapseSubjectDropDown() throws InterruptedException {

        if ( isSubjectDropDownExpanded() ) {
            // drdCollapseSubject.get(0).click();
            SMUtils.fluentWaitForElement( driver, drdCollapseSubject, 3 );
            SMUtils.click( driver, drdCollapseSubject );
        }

        if ( !isSubjectDropDownCollapsed() ) {
            SMUtils.click( driver, drdCollapseSubject );
            Log.message( "DropDown Collapse- Successful" );
        }
    }

    /***
     * expand Organization drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void expandOrganizationDropDown() throws InterruptedException {

        if ( isOrganizationDropDownCollapsed() ) {
            // drdExpandSubject.get(0).click();
            SMUtils.fluentWaitForElement( driver, drdExpandOrganization, 3 );
            SMUtils.click( driver, drdExpandOrganization );
        }

        if ( !isOrganizationDropDownExpanded() ) {
            SMUtils.click( driver, drdExpandOrganization );
            Log.message( "DropDown Expand- Successful" );
        }
    }

    /***
     * collapse Organization drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void collapseOrganizationtDropDown() throws InterruptedException {

        if ( isOrganizationDropDownExpanded() ) {
            // drdCollapseSubject.get(0).click();
            SMUtils.fluentWaitForElement( driver, drdCollapseOrganization, 3 );
            SMUtils.click( driver, drdCollapseOrganization );
        }

        if ( !isOrganizationDropDownCollapsed() ) {
            SMUtils.click( driver, drdCollapseOrganization );
            Log.message( "DropDown Collapse- Successful" );
        }
    }

    /***
     * expand SkillStandards drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void expandSkillStandardsDropDown() throws InterruptedException {

        if ( isSkillStandardsDropDownCollapsed() ) {
            // drdExpandSkillStandards.get(0).click();
            SMUtils.fluentWaitForElement( driver, drdExpandSkillStandards, 3 );
            SMUtils.click( driver, drdExpandSkillStandards );
            if ( !isSkillStandardsDropDownExpanded() )
                SMUtils.click( driver, drdExpandSkillStandards );
        }

        if ( !isSkillStandardsDropDownExpanded() ) {
            SMUtils.click( driver, drdExpandSkillStandards );
            Log.message( "DropDown Expand- Successful" );
        }
    }

    /***
     * collapse SkillStandards drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void collapseSkillStandardsDropDown() throws InterruptedException {

        if ( isSkillStandardsDropDownExpanded() ) {
            // drdCollapseSkillStandards.get(0).click();
            SMUtils.fluentWaitForElement( driver, drdCollapseSkillStandards, 3 );
            SMUtils.click( driver, drdCollapseSkillStandards );
        }
        if ( !isSkillStandardsDropDownCollapsed() ) {
            SMUtils.click( driver, drdCollapseSkillStandards );
            Log.message( "DropDown Collapse- Successful" );
        }
    }

    /***
     * Gets the subject dropdown values
     *
     * @return
     * @throws InterruptedException
     */
    public List<String> getAllSubjectDropDownValues() throws InterruptedException {
        List<String> subjectsAvaialble = new ArrayList<>();

        // expand subject drop down
        expandSubjectDropDown();

        for ( WebElement dropDownSubjectItem : dropDownSubjectItems ) {
            WebElement dropDownSubjectItemLabel = SMUtils.getChildWebElementFromParent( dropDownSubjectItem, txtDropDownValue );
            subjectsAvaialble.add( dropDownSubjectItemLabel.getText() );
        }

        return subjectsAvaialble;
    }

    /***
     * Gets the selected value from subject drop down
     *
     * @return
     * @throws InterruptedException
     */
    public String getSelectedValueFromSubjectDropDown() throws InterruptedException {
        String subjectsSelected = null;

        // expand subject drop down
        expandSubjectDropDown();

        for ( WebElement dropDownSubjectItem : dropDownSubjectItems ) {
            List<WebElement> dropDownSubjectSelectedItem = SMUtils.getChildWebElementsFromParent( dropDownSubjectItem, tickMark );
            if ( dropDownSubjectSelectedItem.size() > 0 ) {
                WebElement dropDownSubjectItemLabel = SMUtils.getChildWebElementFromParent( dropDownSubjectItem, txtDropDownValue );
                subjectsSelected = dropDownSubjectItemLabel.getText();
                break;
            }
        }

        // collapse subject drop down
        collapseSubjectDropDown();

        return subjectsSelected;
    }

    /***
     * select value from subject drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void selectSubject( String subjectValue ) throws InterruptedException {

        // expand subject drop down
        expandSubjectDropDown();

        for ( WebElement dropDownSubjectItem : dropDownSubjectItems ) {
            WebElement dropDownSubjectItemLabel = SMUtils.getChildWebElementFromParent( dropDownSubjectItem, txtDropDownValue );
            if ( subjectValue.equalsIgnoreCase( dropDownSubjectItemLabel.getText().trim() ) ) {
                dropDownSubjectItemLabel.click();
                // SMUtils.nap(1); // need to remove this in sprint 231
                Log.message( "Selected the subject- " + subjectValue );
                break;
            }
        }
    }

    /***
     * Gets the SkillStandards dropdown values
     *
     * @return
     * @throws InterruptedException
     */
    public List<String> getAllSkillStandardsDropDownValues() throws InterruptedException {
        List<String> SkillStandardssAvaialble = new ArrayList<>();

        // expand SkillStandards drop down
        expandSkillStandardsDropDown();

        for ( WebElement dropDownSkillStandardsItem : dropDownSkillStandardsItems ) {
            WebElement dropDownSkillStandardsItemLabel = SMUtils.getChildWebElementFromParent( dropDownSkillStandardsItem, txtDropDownValue );
            SkillStandardssAvaialble.add( dropDownSkillStandardsItemLabel.getText().trim() );
        }

        // expand SkillStandards drop down
        collapseSkillStandardsDropDown();

        return SkillStandardssAvaialble;
    }

    /***
     * Gets the selected value from SkillStandards drop down
     *
     * @return
     * @throws InterruptedException
     */
    public String getSelectedValueFromSkillStandardsDropDown() throws InterruptedException {
        String skillStandardsSelected = null;

        // expand SkillStandards drop down
        expandSkillStandardsDropDown();

        for ( WebElement dropDownSkillStandardsItem : dropDownSkillStandardsItems ) {
            List<WebElement> dropDownSkillStandardsSelectedItem = SMUtils.getChildWebElementsFromParent( dropDownSkillStandardsItem, tickMark );
            if ( dropDownSkillStandardsSelectedItem.size() > 0 ) {
                WebElement dropDownSkillStandardsItemLabel = SMUtils.getChildWebElementFromParent( dropDownSkillStandardsItem, txtDropDownValue );
                skillStandardsSelected = dropDownSkillStandardsItemLabel.getText();
            }
        }

        // expand SkillStandards drop down
        collapseSkillStandardsDropDown();

        return skillStandardsSelected;
    }

    /***
     * select value from subject drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void selectSkillStandards( String skillStandardsValue ) throws InterruptedException {

        // expand subject drop down
        expandSkillStandardsDropDown();

        for ( WebElement dropDownSkillStandardsValueItem : dropDownSkillStandardsItems ) {
            WebElement dropDownSkillStandardsItemLabel = SMUtils.getChildWebElementFromParent( dropDownSkillStandardsValueItem, txtDropDownValue );
            if ( skillStandardsValue.equalsIgnoreCase( dropDownSkillStandardsItemLabel.getText().trim() ) ) {
                dropDownSkillStandardsItemLabel.click();
                break;
            }
        }
        Log.message( skillStandardsValue + " is selected in Skills/Standards dropdown" );
    }

    /***
     * select value from subject drop down
     *
     * @return
     * @throws InterruptedException
     */
    public void selectSkillStandardsByIndex( Integer index ) throws InterruptedException {

        // expand subject drop down
        expandSkillStandardsDropDown();

        for ( int i = 0; i < dropDownSkillStandardsItems.size(); i++ ) {
            WebElement dropDownSkillStandardsItemLabel = SMUtils.getChildWebElementFromParent( dropDownSkillStandardsItems.get( i ), txtDropDownValue );
            if ( i == index ) {
                dropDownSkillStandardsItemLabel.click();
                break;
            }
        }
    }

    /***** End - Single-Select Dropdown methods *****/

    /**
     * To verify Skills/Standards drop down is present or not
     *
     * @return
     */
    public boolean isSkillsStandardsDropdownPresent() {
        Log.message( "Verifying Skills/Standards dropdown is present or not" );
        SMUtils.waitForElement( driver, skillsStandardsDropdown );
        return ( SMUtils.isElementPresent( skillsStandardsDropdown ) ? true : false );

    }

    /**
     * To verify Assignment drop down is present or not
     *
     * @return
     */
    public boolean isAssignmentDropdownPresent() {
        Log.message( "Verifying Assignments dropdown is present or not" );
        SMUtils.waitForElement( driver, assignmentsDropdown );
        return ( SMUtils.isElementPresent( assignmentsDropdown ) ? true : false );

    }

    /**
     * To verify Apply Filter button is present or not
     *
     * @return
     */
    public boolean isApplyFilterButtonPresent() {
        SMUtils.waitForElement( driver, btnApplyFilterRoot );
        WebElement applyFilterButton = SMUtils.getWebElementDirect( driver, btnApplyFilterRoot, btnApplyFilterChild );
        return ( SMUtils.isElementPresent( applyFilterButton ) ? true : false );

    }
    
    /**
     * To verify Reset Filter button is present or not
     *
     * @return
     */
    public boolean isResetFilterButtonPresent() {
        SMUtils.waitForElement( driver, btnResetFilterRoot );
        WebElement resetFilterButton = SMUtils.getWebElementDirect( driver, btnResetFilterRoot, btnResetFilterChild );
        return ( SMUtils.isElementPresent( resetFilterButton ) ? true : false );

    }

    public void expandToggle() {
        if ( !toogleExpandOrCollapse.getAttribute( "aria-expanded" ).equals( false ) ) {
            SMUtils.clickJS( driver, toogleBtn );
        }
    }

    /**
     * To verify after clicking Apply filter Btn the filter got collapsed
     *
     * @return status
     */
    public boolean isFilterExpanded() {
        boolean status = false;
        try {
            if ( SMUtils.isElementPresent( formAllFiltersOptions ) )
                status = true;
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return status;
    }

    //Clicking on Expand filter options
    public boolean isFilterExpandable() {
        boolean status = false;
        try {
            if ( SMUtils.isElementPresent( btnExpandFilter ) ) {
                SMUtils.clickJS( driver, btnExpandFilter );
                Log.message( "Clicked on Expand filter button " );
                status = true;
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return status;
    }

    /***
     * Select values based on the given index from multi-select drop down for
     * multi-select drop down
     *
     * @param valuesToSelect
     * @throws InterruptedException
     */
    public void selectAssignmentNameFromDropDownMS( String AssignmentName ) throws InterruptedException {
        // uncheck all
        unCheckSelectAllDropdownMS();
        List<WebElement> selectValueWrapperElements = getCheckboxLabelElementsForDropDownMS();
        IntStream.range( 0, selectValueWrapperElements.size() ).forEach( i -> {
            WebElement selectValueWrapperElement = selectValueWrapperElements.get( i );
            if ( selectValueWrapperElement.getText().toString().trim().equals( AssignmentName ) ) {
                WebElement selectCheckbox = SMUtils.getChildWebElementFromParent( selectValueWrapperElement, chxSelectDropDownMS );
                SMUtils.scrollIntoView( driver, selectCheckbox );
                SMUtils.clickJS( driver, selectCheckbox );

            }
        } );
    }
    /**

     * To Verify is Mastery Summary age Loaded
     * 
     * @return
     */

    public Boolean isMasterySummaryPageLoaded() {
        Boolean status = false;
        String text = headerMasteryText.getText();
        if ( text.equals( "Mastery" ) ) {
            status = true;
            Log.message( "Mastery Summary Page Loaded" );
        }
        return status;
    }

    /**
     * Verify tool-tip is present or not
     * 
     * @return
     */
    public Boolean isSkillDetailsPresentInProgressBarToolTip() {
        Boolean status = false;
        SMUtils.waitForElement( driver, skillDetailsInProgressBarToolTip );
        if ( skillDetailsInProgressBarToolTip.isDisplayed() ) {
            status = true;
            Log.message( "Skill Details Present in the Progress Bar Tool Tip" );
        }
        return status;
    }
    /**
    * To verify the Single dropdown is Displaying or not
    * 
    * @return
    */
   public boolean isSingleSelectDropDownDisplayed( String dropdownName ) {
       Log.message( "Verifing " + dropdownName + "Drop Down is displayed" );
       return getRootElementForSingleSelectDropdown( dropdownName ).isDisplayed();
   }

   /**
    * To get the root Element for single-select dropdown
    * 
    * @param dropdownName
    * @return
    */
   public WebElement getRootElementForSingleSelectDropdown( String dropdownName ) {
       SMUtils.waitForElement( driver, optionalFilterRoot );
       return dropdownLabels.stream().filter( element -> element.getText().trim().equalsIgnoreCase( dropdownName ) ).findFirst().orElse( null ).findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( singleSelectDropdownRoot ) );
   }

}
