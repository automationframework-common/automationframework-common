/**
 * Method for testing the students mastery Page
 *
 * @author Sudarshan.Govindarajan
 */

package com.savvas.sm.ui.tests.smnew.Mastery;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants.Students.Mastery_DropDowns;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.HelpPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.mastery.pages.MasteryDetailsPage;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasterySummaryComponent;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class StudentsMastery extends BaseTest {

    private String smUrl;
    private String browser;
    private static WebDriver driver;
    private static String username;
    private static String password;

    List<String> studentIDList = null;
    List<String> studentNames = new ArrayList<>();
    BaseAPITest baseApiObject = new BaseAPITest();
    UserSqlHelper userSqlHelper = new UserSqlHelper();
    SqlHelperOrganization sqlHelperOrganization = new SqlHelperOrganization();
    HelpPage helpPage;

    StudentsPage smnewStudentsPage;

    String teacherDetails;
    String studentUserName1;
    String studentUserName2;
    String studentUserName3;
    String studentUserName4;
    String assignmentName;

    String school = RBSDataSetup.getSchools( RBSDataSetupConstants.Schools.FLEX_SCHOOL );

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = MasteryDataSetup.teacherUserName;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        studentUserName1 = MasteryDataSetup.studentUserName1;
        studentUserName2 = MasteryDataSetup.studentUserName2;
        studentUserName3 = MasteryDataSetup.studentUserName3;
        studentUserName4 = MasteryDataSetup.studentUserName4;
        assignmentName = MasteryDataSetup.math_Assignment;

    }

    @Test ( description = "Verify Mastery Sub- nav Student view page", priority = 1 )
    public void testCaseSMSDMD001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMSDMD001: Verify Mastery Sub- nav Student view page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            smnewStudentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            // Getting Student data to navigate to the respective Mastery details
            // Navigate to Student detail Page
            smnewStudentsPage.clickviewStudentByEllipsis( studentUserName1 );
            SMUtils.logDescriptionTC( "Verify the Mastery Sub Nav is present on the Student Details Page" );
            for ( WebElement webElement : smnewStudentsPage.listSideNvaBar ) {
                String subNav = "Mastery";
                if ( webElement.getText().trim().equals( subNav ) ) {
                    SMUtils.scrollIntoView( driver, webElement );
                    Log.assertThat( webElement.isDisplayed(), "Mastery is present on the sub nav", "Mastery is not present on the sub nav" );
                }
            }

            SMUtils.logDescriptionTC( "Verify Teacher able to view Mastery header on clicking Mastery sub tab" );
            smnewStudentsPage.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            Log.assertThat( smnewStudentsPage.isMasteryDisplayed(), "The Mastery sub-navigation is displayed", "The Mastery sub-navigation is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the subject dropdown is present" );
            Log.assertThat( smnewStudentsPage.isStaticDropDownPresent( Mastery_DropDowns.SUBJECT ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );

            SMUtils.logDescriptionTC( "Verify the skills\\standards dropdown is present" );
            Log.assertThat( smnewStudentsPage.isStaticDropDownPresent( Mastery_DropDowns.MASTERY_SKILL ), "The Skill/Standard drop down is displayed", "The Skill/Standard drop down is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the defalut value for Subject dropdown is 'Math'" );
            String actualText = smnewStudentsPage.getMasterySubjectDropdownDefaultText();
            Log.assertThat( actualText.equalsIgnoreCase( Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 0 ) ), "The default value in the subject drop down is Math", "The default value in the subject drop down is not Math" );

            // Verify the user can select only either Math or Reading
            SMUtils.logDescriptionTC( "Verify teacher is able to select 'Reading' from subject dropdown" );
            smnewStudentsPage.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) );
            actualText = smnewStudentsPage.getMasterySubjectDropdownDefaultText();
            Log.assertThat( actualText.equalsIgnoreCase( Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) ), "The user can able to select only Reading and selected", "The user is unable to select only Reading and not selected" );

            SMUtils.logDescriptionTC( "Verify the Assignment Select box is present with total number of assignments" );
            Log.assertThat( smnewStudentsPage.isStaticDropDownPresent( Mastery_DropDowns.ASSIGNMENTS ), "The Assignments drop down is displayed", "The Assignments drop down is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify help icon (i) is displaying along with Mastery header" );
            smnewStudentsPage.clickMasteryHelpIcon();
            String baseWindow = driver.getWindowHandle();
            SMUtils.switchWindow( driver );
            helpPage = new HelpPage( driver ).get();
            String currentURL = driver.getCurrentUrl();
            String title = driver.getTitle();
            Log.assertThat( currentURL.equalsIgnoreCase( Constants.Students.MASTERYHELPRURL ), "Help window URL is verified", "Help window URL is not verified" );
            Log.assertThat( title.equalsIgnoreCase( Constants.Students.MASTERYHELPTITLE ), "Help window Title is verified", "Help window Title is not verified" );
            driver.switchTo().window( baseWindow );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "On Mastery sub tab, Verify Apply Filter button is present and in grey color and is disabled" );
            Log.assertThat( !smnewStudentsPage.verifyApplyFilterisDisabled(), "The Apply filter button is disabled by default", "The Apply filter button is not disabled by default" );
            smnewStudentsPage.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) );
            Log.assertThat( smnewStudentsPage.verifyApplyFilterButton(), "The Apply filter button is displayed and clickable", "The Apply filter button is not displayed and clickable" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "On Mastery sub tab, Verify Apply Filter button is seen in blue color backgorund when enabled" );
            smnewStudentsPage.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) );
            Log.assertThat( smnewStudentsPage.verifyApplyFilterButton(), "The Apply filter button is displayed and clickable", "The Apply filter button is not displayed and clickable" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the functionality of SELECT ALL check box in assignments drop down" );

            SMUtils.logDescriptionTC( "On Mastery sub tab,Verify the default value for Assignments dropdown is 'All Assignemnts'" );
            Log.assertThat( smnewStudentsPage.checkAllMasteryAssignmentsSelected(), "By default, all the assignments are selected", "By default, all the assignments are not selected" );
            Log.testCaseResult();

            List<String> dropDownOptions = smnewStudentsPage.getDropDownOptions( Mastery_DropDowns.ASSIGNMENTS );
            Log.assertThat( dropDownOptions.get( 0 ).equalsIgnoreCase( Constants.Students.MASTERY_ASSIGNMENTS_SELECT_ALL ), "SELECT ALL option is displayed in the assignments drop down", "SELECT ALL option is not displayed in the assignments drop down" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify SELECT ALL can select/unselect all the assignments in the drop down" );
            smnewStudentsPage.selectMasteryAssignmentSelectAll();
            Log.assertThat( !smnewStudentsPage.checkAllMasteryAssignmentsSelected(), "All the values are not selected", "All the values are selected" );
            Log.testCaseResult();

            /*
             * SMUtils.logDescriptionTC(
             * "Verify the teacher is able to select multiple assignment in the drop down "
             * ); smnewStudentsPage.selectMasteryAssignments(
             * dropDownOptions.get( 1 ), dropDownOptions.get( 2 ) );
             * SMUtils.nap( 2 ); // This nap is for MAC for retrieveing data
             * from the drop down, with webdriver wait it is not achievable
             * List<String> selectedValues =
             * smnewStudentsPage.getAllMasteryAssignmentsSelectedValues();
             * Log.assertThat( selectedValues.contains( dropDownOptions.get( 1 )
             * ) && selectedValues.contains( dropDownOptions.get( 2 ) ),
             * "The multiple assignment is selectable",
             * "The multiple assignment is not selectable" );
             * Log.testCaseResult();
             */
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Mastery Summary Details in  Student view page", priority = 2 )
    public void testCaseSMSDMD002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            smnewStudentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            // Getting Student data to navigate to the respective Mastery details
            // Navigate to Student detail Page
            smnewStudentsPage.clickviewStudentByEllipsis( studentUserName1 );

            SMUtils.logDescriptionTC( "Verify the Mastery Details dropdown is present with respect to students" );

            smnewStudentsPage.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );

            SMUtils.logDescriptionTC( "Verify the Legends and its colors in students > Mastery" );
            Log.assertThat( smnewStudentsPage.checkElementPresence( Constants.Students.LEGENDS ), "The Legends are displayed in the mastery Page", "The Legends are not displayed in the mastery Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the grade in Student-Mastery tab." );
            Log.assertThat( masteryComponent.verifyGradeIsDisplayed(), "Grade is displayed under mastery tab in the Student mastery page", "Grade is not displayed under mastery tab in the Student mastery page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the hierarchy of the Skill or standard in Student-Mastery tab." );
            Log.assertThat( masteryComponent.verifySkillHeadingIsDisplayed(), "Skill heading is displayed under domain and cluster in mastery tab of the Student mastery page",
                    "Skill heading is not displayed under domain and cluster in mastery tab of the Student mastery page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the teacher is able to see the LO as a blue link, when Math subject is chosen with skills" );
            Log.assertThat( masteryComponent.verifyLOColor( browser ), "Teacher is able to see the LO as a blue link on Student mastery page",
                    "Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills on Student mastery page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Skill Description. when Math subject is chosen with skills/standard" );
            smnewStudentsPage.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 0 ) );
            smnewStudentsPage.clickApplyFilter();
            Log.assertThat( masteryComponent.getLeafNodeContent().stream().allMatch( loDescription -> !loDescription.isEmpty() ), "Skill description is displayed for math related assignments ",
                    "LO description is not displayed for math related assignments " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Skill Description. when Reading subject is chosen with skills/standard" );
            smnewStudentsPage.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) );
            smnewStudentsPage.clickApplyFilter();
            Log.assertThat( masteryComponent.getLeafNodeContent().stream().allMatch( loDescription -> !loDescription.isEmpty() ), "Skill description is displayed for reading related assignments ",
                    "LO description is not displayed for math related assignments " );
            Log.testCaseResult();

            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );

            SMUtils.logDescriptionTC( "Verify the teacher can be able to expanded and collapsed the First Level Strand -Math/Reading." );
            smnewStudentsPage.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 0 ) );
            smnewStudentsPage.clickApplyFilter();
            SMUtils.nap( 2 );
            masteryComponent.clickFirstLevelStrandName();
            Log.assertThat( masteryComponent.isStrandCollapsed(), "First Level Strand is expanded and collapsed successfully", "First Level Strand is not expanded and collapsed" );

            SMUtils.logDescriptionTC( "Verify the teacher can be able to expanded and collapsed the Skill name for Subject -Math/Reading." );
            masteryComponent.clickSecondLevelStrandName();
            Log.assertThat( masteryComponent.isStrandCollapsed(), "Strand is expanded and collapsed successfully", "Strand is not expanded and collapsed" );

            SMUtils.logDescriptionTC( "Verify the teacher is not able to see the LO as a blue link, when Math subject is chosen with standard" );
            masteryFilter.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            masteryFilter.applyFilter();
            Log.assertThat( !masteryComponent.verifyLoLinkIsPresent(), "LO is not displayed as blue link when Math subject is chosen with standard", "LO is displayed as blue link when Math subject is chosen with standard" );

            SMUtils.logDescriptionTC( "Verify the teacher is not able to see the SCO number, when Reading subject is chosen with skills" );
            masteryFilter.selectSubject( Constants.READING );
            masteryFilter.applyFilter();
            Log.assertThat( !masteryComponent.verifyLoLinkIsPresent(), "LO is not displayed as blue link when Reading subject is chosen with skills", "LO is displayed as blue link when Reading subject is chosen with skills" );

            SMUtils.logDescriptionTC( "Verify the teacher is not able to see the SCO number, when Reading subject is chosen with standards" );
            masteryFilter.selectSkillStandards( Constants.READING_SKILLS_DROPDOWN_LIST.get( 3 ) );
            masteryFilter.applyFilter();
            Log.assertThat( !masteryComponent.verifyLoLinkIsPresent(), "LO is not displayed as blue link when Reading subject is chosen with standard", "LO is displayed as blue link when Reading subject is chosen with standard" );

            SMUtils.logDescriptionTC( "Verify the Progress bar in right side of the LO Description" );
            Log.assertThat( masteryComponent.isLOviewLinkPresenet(), "Progress bar is present in LO Description", "Progress bar is not present in LO Description" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Mastery status colour indicator order in the progress bar", priority = 3 )
    public void testCaseSMSDMD003() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            smnewStudentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            smnewStudentsPage.clickviewStudentByEllipsis( studentUserName1 );
            smnewStudentsPage.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );

            SMUtils.logDescriptionTC( "Verify the progress bar, 'Mastered' status is indicated by Green color" );
            Log.assertThat( masteryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.MASTERED_COLOR_CODE.toLowerCase() ), "Mastered status is indicated by Green color in the progress bar ",
                    "Mastered status is not indicated by Green color in the progress bar " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the progress bar, 'At Risk' status is indicated by Yellow color" );
            smnewStudentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            smnewStudentsPage.clickviewStudentByEllipsis( studentUserName2 );
            smnewStudentsPage.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            Log.assertThat( masteryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.ATRISK_COLOR_CODE.toLowerCase() ), "At Risk status is indicated by Yellow color in the progress bar ",
                    "At Risk status is not indicated by Yellow color in the progress bar " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the progress bar, 'Not Mastered' status is indicated by Red color" );
            smnewStudentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            smnewStudentsPage.clickviewStudentByEllipsis( studentUserName3 );
            smnewStudentsPage.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            Log.assertThat( masteryComponent.getStatusColor( browser ).contains( Constants.MasteryUI.NOTMASTERED_COLOR_CODE.toLowerCase() ), "Not Mastered status is indicated by Red color in the progress bar ",
                    "Not Mastered status is not indicated by Red color in the progress bar " );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the progress bar, total number of students 'Mastered'/Not Mastered/At Risk with respect to that skill is displaying inside Green/Yellow/red colour." );
            Log.assertThat( masteryComponent.getStudentAssessmentOfLeafNodeLO().containsAll( masteryComponent.getStudentAssessmentCount() ), "Total number of student assessment is didplayed in progress bar",
                    "Total number of student assessment is not didplayed in progress bar" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "On Mouse hovering on Progress bar, Verify tooltip is displaying" );
            Log.assertThat( masteryComponent.getLeafNodeBasedOnMasteryStatus( Constants.MasteryUI.MASTERED ).stream().allMatch( WebElement::isDisplayed ), "Tooltip is present in progress bar", "Tooltip is not present in progress bar" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the zero state message is displayed when all students are removed from the group" );
            smnewStudentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            smnewStudentsPage.clickviewStudentByEllipsis( studentUserName4 );
            smnewStudentsPage.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            Log.assertThat( smnewStudentsPage.getMasteryNoData().equalsIgnoreCase( Constants.Students.MASTERY_NO_DATA_ASSIGNMENT ) && smnewStudentsPage.getMasteryZeroState().equalsIgnoreCase( Constants.Students.MASTERY_ZERO_STATE_ASSIGNMENT ),
                    "No data and Zero State message is verified", "No data and Zero State message is not verified" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Mastery LO Details in  Student view page", priority = 4 )
    public void testCaseSMSDMD004() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        String assignmentToClick = assignmentName; //To change
        try {

            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );

            smnewStudentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            smnewStudentsPage.clickviewStudentByEllipsis( studentUserName1 );
            smnewStudentsPage.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );

            // Selecting subject drop-down as Math with Standards
            masteryFilter.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            MasterySummaryComponent masterySummaryComponent = masteryFilter.applyFilter();

            SMUtils.logDescriptionTC( "Upon clicking the Arrow Head beside the progress bar, then Details Related to specific LO should be accessible" );
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED ).get( 0 ) );
            Log.assertThat( masteryDetailsPage.isDetailsDisplayed(), "Skill Evaluated field is display", "Skill Evaluated field is not display" );
            Log.testCaseResult();
            masteryDetailsPage.clickBackBtn();

            masteryFilter.selectSubject( Constants.MasteryUI.SUBJECT_READING );
            masteryFilter.selectSkillStandards( Constants.READING_SKILLS_DROPDOWN_LIST.get( 0 ) );
            masteryFilter.applyFilter();

            smnewStudentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            smnewStudentsPage.clickviewStudentByEllipsis( studentUserName2 );
            smnewStudentsPage.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Navigating to LO view page
            SMUtils.logDescriptionTC( "Upon clicking the Arrow Head beside the progress bar, then Details Related to Reading should be accessible" );
            masterySummaryComponent.navigateToLoViewPage( masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.AT_RISK ).get( 0 ) );
            Log.assertThat( masteryDetailsPage.isDetailsDisplayed(), "Details filed  is displayed", "Details field is not displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the list of students' names, their mastery status, their number of skills evaluated, and their number of attempts getting displayed corresponding to that assignment on the mastery details" );
            Log.assertThat( Constants.MasteryUI.masteryTableHeaders.equals( masteryDetailsPage.getStudentTableHeaders() ), "The 'Student', 'Mastery','Skills Evaluated','Attempts' are present",
                    "The 'Student', 'Mastery','Skills Evaluated','Attempts' are not present" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC:Verify the Teacher can view the Minus(-) sign corresponding to each assignment in the mastery details page in default" );
            Log.assertThat( masteryDetailsPage.isMinusBtnPresentByDefault(), "Minus Button is getting displayed for each Assignments", "Minus Button is not getting displayed for each Assignments!!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC : 08 - Verify the Teacher can view only the Plus(+) icon and Assignment Name after clicking on (-) icon corresponding to each assignment in the mastery details page" );
            masteryDetailsPage.clickingMinusButton( assignmentToClick );
            Log.assertThat( masteryDetailsPage.getStudentName( assignmentToClick ).isEmpty(), "After clicking [-] minus the all the students details are hidden", "After clicking [-] the students details are getting displayed!" );
            //Verifying after clicking minus button, plus button is getting displayed
            Log.assertThat( masteryDetailsPage.isPlusBtnPresent( assignmentToClick ), "After clicking on Minus button, the plus button is getting displayed", "After clicing on Minus button, the plus button is not getting displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    " Verify the Teacher cannot view the list of students name , their mastery status, their number of skills evaluated and their number of attempts other than assignment name corresponding to each assignment in the mastery details page on clicking the (-) icon" );
            Log.assertThat( masteryDetailsPage.getStudentName( assignmentToClick ).isEmpty(), "After clicking [-] minus the all the students details are hidden", "After clicking [-] the students details are getting displayed!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the text displayed as 1 Student Assessment above the progress bar if only one student has taken assessment corresponding to the LO only in the mastery details page" );
            Log.assertThat( masteryDetailsPage.getStudentCounts().contentEquals( masteryDetailsPage.getNoOfStudentAssessed() ), "The text is displaying as 'number' Student Assessments for more than one student Assessment ",
                    "The text is displaying as 'number' Student Assessment for more than one student Assessment" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "Verify the tootltip text displayed as  Number mastered , Number at risk, Number not mastered  in dark grey color background while hovering the pointer without clicking on the progress bar corresponding to the LO in the mastery details page" );
            //Get Tool Tip Text
            String tooltipOfProgressBar = masteryDetailsPage.getProgressBarToolTipText();
            // Validation 1:
            Log.assertThat( tooltipOfProgressBar.contains( "mastered" ), "Text mastered is present in the Tool tip in the Progress Bar", "Text mastered is not present in the Tool tip in the Progress Bar" );
            // Validation 2:
            Log.assertThat( tooltipOfProgressBar.contains( "at risk" ), "Text at risk is present in the Tool tip in the Progress Bar", "Text At Risk is not present in the Tool tip in the Progress Bar" );
            // Validation 3:
            Log.assertThat( tooltipOfProgressBar.contains( "not mastered" ), "Text not mastered is present in the Tool tip in the Progress Bar", "Text not mastered is not present in the Tool tip in the Progress Bar" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Back is present on the top left corner along with the Head arrow Pointing towards the left side" );
            //WebElement backButton=SMUtils.getWebElementDirect( driver, masteryDetailsPage.getBackBtnRoot(), masteryDetailsPage.getInnerICon() );
            //Log.assertThat(backButton.isDisplayed(),"Back Button is present","Back Button is not present");

            SMUtils.logDescriptionTC( "Upon clicking the Arrow on the LO Detail Page, navigate to the previous page" );
            masteryDetailsPage.clickBackBtn();

            StudentsPage studentsmasterypages = new StudentsPage( driver );
            Log.assertThat( studentsmasterypages.isMasteryDisplayed(), "The teacher is able to navigate back to the Mastery View page when back button is clicked",
                    "The teacher is not able to navigate back to the Mastery View page when back button is clicked" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
