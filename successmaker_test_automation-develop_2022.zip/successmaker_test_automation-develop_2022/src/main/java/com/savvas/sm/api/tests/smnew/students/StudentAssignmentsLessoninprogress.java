package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.SkillTested;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.github.bonigarcia.wdm.WebDriverManager;

public class StudentAssignmentsLessoninprogress extends AssignmentAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String stuFName;
    private String stuLName;
    private String assignmentLevel;
    private String rewardCoursePoints;
    private String assignmentID;
    RBSUtils rbsutils = new RBSUtils();
    private String studentDetail;
    private String studentUserID;
    private String studentUsername;
    private String courseName;
    Map<String, String> response = new HashMap<>();
    Map<String, String> assignmentResponse = new HashMap<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;
    String assignmentUserId;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        stuFName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ).toString();
        stuLName = SMUtils.getKeyValueFromResponse( studentDetail, "lastName" ).toString();
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();

    }

    @Test ( dataProvider = "positiveData", priority = 1, groups = { "SMK-66843", "smoke_test_case", "P1", "API" } )
    public void updateReadingLessonComplete( String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupdetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentUserID );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );

        String CourseId;
        switch ( scenario ) {
            case "Default Reading":
                courseName = Constants.READING;
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                String accessToken = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId );

                SMUtils.logDescriptionTC( "Verify the Response code is 200 while completing Reading lesson" );

                // selectCourse( studentUsername, courseName );
                lunchCourse( studentUsername, courseName, "100", "1", "30" );

                String sessionId = SqlHelperAssignment.getSessionId( assignmentUserId );
                Log.message( "SessionId : " + sessionId );

                response = updateReadingLesson( orgId, studentUserID, accessToken, assignmentUserId, sessionId );
                Log.message( "Response = " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the same is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;
            case "Custom Setting Reading":
                courseName = "CustomSettingReading" + System.nanoTime();
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( courseName ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                String accessToken2 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId2 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId2 );

                SMUtils.logDescriptionTC( "Verify the Response code is 200 while completing Reading lesson with CustomBySettings course and IP OFF" );

                lunchCourse( studentUsername, courseName, "100", "1", "30" );

                String sessionId2 = SqlHelperAssignment.getSessionId( assignmentUserId2 );
                Log.message( "SessionId : " + sessionId2 );

                response = updateReadingLesson( orgId, studentUserID, accessToken2, assignmentUserId2, sessionId2 );
                Log.message( "Response = " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the same is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            default:
                break;
        }
    }

    public HashMap<String, String> updateReadingLesson( String orgId, String studentUserId, String accessToken, String assignmentUserId, String sessionId ) {
        try {
            // headersassignmentUserId
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.USERID_SM_HEADER, studentUserId );
            headers.put( Constants.SESSIONID_HEADER, sessionId );
            headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );

            HashMap<String, String> params = new HashMap<>();

            // Input Path Parameters
            String endPoint = Constants.UPDATE_READING_INPROGRESS;

            endPoint = endPoint.replace( "{assignmentuserId}", assignmentUserId );

            String requestBody = GetRequestBody();
            HashMap<String, String> response = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, requestBody );

            return response;
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    @DataProvider ( name = "positiveData" )
    public Object[][] positiveData() {
        Object[][] data = { { "TC01 Verify the valid response to Default Reading", "Default Reading", CommonAPIConstants.STATUS_CODE_OK },
                { "TC02 Verify the valid response to Custom Setting Reading", "Custom Setting Reading", CommonAPIConstants.STATUS_CODE_OK }, };
        return data;
    }

    /**
     * This method is used to select the course based on courseName.
     *
     * @param studentUserName
     * @param courseName
     */
    public void selectCourse( String studentUserName, String courseName ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );

        Log.message( "Student username :" + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        SMUtils.nap( 30 );
        StudentDashboardPage studentPage = new StudentDashboardPage( driver );
        studentPage.selectAssignmentByName( courseName );
    }

    /**
     * To execute the course
     *
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void lunchCourse( String studentUserName, String courseName, String percentage, String numberOfSession, String loCount ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );

        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
        studentsPage.lunchReadingCourse( studentUserName, courseName, percentage, numberOfSession, loCount );

    }

    public String GetRequestBody() throws Exception {
        String payload = null;

        payload = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "studentLessionInProgress.json" );
        payload = payload.replace( "{scoId}", "\"" + getScoId( assignmentUserId ) + "\"" + ":{}" );

        Log.message( "Payload is : " + payload );
        return payload;
    }

    public String getScoId( String assUId ) {
        String scoHis = getScoHistory( assUId );
        List<Object[]> Sco_Id = SQLUtil.executeQuery( "select exercise_set_sco_name from successmaker.exerset_sco where exercise_set_sco_id='" + scoHis + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : Sco_Id ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String scoIDValue = arrList.get( 0 );
        return scoIDValue;
    }

    public String getScoHistory( String assUId ) {
        List<Object[]> Sco_History = SQLUtil.executeQuery( "select exercise_set_sco_id from school.read_assignment_sco_history WHERE assignment_user_id='" + assUId + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : Sco_History ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String scoHistoryValue = arrList.get( 0 );
        return scoHistoryValue;
    }

}