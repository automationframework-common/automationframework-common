package com.savvas.sm.teacher.ui.tests.MasterySuite;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryDetailsPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This class test the Mastery LO View page UI testing.
 *
 * @author madhan.nagarathinam
 *
 */
@Listeners ( EmailReport.class )
public class MasteryDetailsTest extends BaseTest {
    private String smUrl;
    private String browser;
    private String username = null;
    private String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String studentUsername1 = null;
    private String studentUsername2 = null;
    private String studentUsername3 = null;
    private String studentUsername4 = null;
    String chromePlatform = "Windows_10_Chrome_latest";
    BaseAPITest baseApiObject = new BaseAPITest();
    UserSqlHelper userSqlHelper = new UserSqlHelper();
    String teacherId;
    String orgId;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher44" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        studentUsername1 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,userName" );
        studentUsername2 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student2" ), "data,userName" );
        studentUsername3 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student3" ), "data,userName" );
        studentUsername4 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student4" ), "data,userName" );
        teacherId = userSqlHelper.getPersonID( username );
        orgId = userSqlHelper.getOrgId( teacherId );

    }

    @Test ( priority = 1, description = "Datasetup for Mastery LO View page" )
    public void tcMasteryDataSetup( ITestContext context ) throws Exception {
        String sessionCookie = baseApiObject.getJessionCookie( smUrl, username, password );
        String Math_Assignment = "MathSingleLOCourse1__" + System.nanoTime();
        String Math_Assignment2 = "MathSingleLOCourse2__" + System.nanoTime();
        String Math_Assignment3 = "MathSingleLOCourse3__" + System.nanoTime();
        String course = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.ONE_LO, Math_Assignment );
        String course2 = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.ONE_LO, Math_Assignment2 );
        String course3 = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.ONE_LO, Math_Assignment3 );

		// Get driver
//		EventFiringWebDriver driver=null;
		
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner); //for simulator run
        Log.testCaseInfo( "Test Data generation for Mastery Details LO View Page." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            context.setAttribute( "Math_Assignment", Math_Assignment );
            context.setAttribute( "Math_Assignment2", Math_Assignment2 );
            context.setAttribute( "Math_Assignment3", Math_Assignment3 );

            // Assigning Math Courses to Students
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Math_Assignment );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Assigning Math Courses to Students
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Math_Assignment2 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Assigning Math Courses to Students
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Math_Assignment3 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            chromeDriver.quit();

            Log.message( "Executing the courses using simulator" );

            //Login as student1 to the executeCourses
            Log.message( "Executing the courses using simulator for student1" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername1, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "100", "1", "20" );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment2, "50", "1", "20" );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment3, "100", "1", "20" );

            studentsPage.logout();
            chromeDriver.quit();

            //Login as student2 to the executeCourses
            Log.message( "Executing the courses using simulator for student2" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername2, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "100", "1", "5" );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment2, "90", "1", "5" );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment3, "50", "3", "10" );
            studentsPage.logout();
            chromeDriver.quit();

            //Login as student3 to the executeCourses
            Log.message( "Executing the courses using simulator for student3" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername3, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "40", "1", "20" );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment3, "10", "6", "10" );
            studentsPage.logout();
            chromeDriver.quit();

            //Login as student4 to the executeCourses
            Log.message( "Executing the courses using simulator for student4" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername4, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "50", "1", "20" );
            studentsPage.logout();
            chromeDriver.quit();
        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        }

        finally {
            
            
            Log.endTestCase();
            chromeDriver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-42845", "mastery", "masteryLOview" } )
    public void tcMasteryDetails001( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            SMUtils.logDescriptionTC( "TC :01 - Verify the teacher is able to see the LO as a blue link, when Math subject is chosen with skills" );
            Log.assertThat( masteryDetailsPage.getLOColor( browser ).contentEquals( Constants.MasteryUI.LO_ID_COLOR_CODE ), "Teacher is able to see the LO as a blue link",
                    "Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "TC :02 - Verify the Teacher can view the assessment details ( Students Name, Mastery Status , Skills Evaluated and No of Attempts) of the students based on each assignment in the mastery details page corresponding to the LO" );
            Log.assertThat( masteryDetailsPage.isDetailsDisplayed(), "Teacher can able to view all the details properly", "Teacher is not able to view the details properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "TC :03 - Verify the teacher able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only irrespective of the number of assignments displayed in the mastery details page" );
            Log.assertThat( !masteryDetailsPage.getNoOfStudentAssessed().isEmpty(), "The teacher is able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only",
                    "The teacher is not able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    " TC :04 - Verify the text displayed as Numbers Student Assessments above the progress bar if more than one student has taken assessment corresponding to the LO only irrespective of the number of assignments displayed in the mastery details page " );
            Log.assertThat( masteryDetailsPage.getStudentCounts().contentEquals( masteryDetailsPage.getNoOfStudentAssessed() ), "The text is displaying as 'number' Student Assessments for more than one student Assessment ",
                    "The text is displaying as 'number' Student Assessment for more than one student Assessment" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( " TC :05 - Verify the count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar " );
            Log.assertThat( masteryDetailsPage.getStudentCounts().contentEquals( masteryDetailsPage.getNoOfStudentAssessed() ),
                    "The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar ",
                    " The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is not matching with TOTAL count of students have taken assessment displayed above the progress bar" );
            Log.testCaseResult();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-42845", "mastery", "masteryLOview" } )
    public void tcMasteryDetails002( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        String mathAssignment = context.getAttribute( "Math_Assignment" ).toString();
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masteredProgressBars.get( 0 ) );
            SMUtils.logDescriptionTC( "TC : 06,07 - Verify the Teacher can view the Minus(-) sign corresponding to each assignment in the mastery details page in default" );
            Log.assertThat( masteryDetailsPage.isMinusBtnPresentByDefault(), "Minus Button is getting displayed for each Assignments", "Minus Button is not getting displayed for each Assignments!!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "TC : 08 - Verify the Teacher can view only the Plus(+) icon and Assignment Name after clicking on (-) icon corresponding to each assignment in the mastery details page" );
            masteryDetailsPage.clickingMinusButton( mathAssignment );
            Log.assertThat( masteryDetailsPage.getStudentName( mathAssignment ).isEmpty(), "After clicking [-] minus the all the students details are hidden", "After clicking [-] the students details are getting displayed!" );
            //Verifying after clicking minus button, plus button is getting displayed
            Log.assertThat( masteryDetailsPage.isPlusBtnPresent( mathAssignment ), "After clicking on Minus button, the plus button is getting displayed", "After clicing on Minus button, the plus button is not getting displayed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "TC : 09 - Verify the list of students name , their mastery status, their number of skills evaluated and their number of attempts getting displayed corresponding to that assignment in the mastery details page on clicking the (+) icon" );
            masteryDetailsPage.clickingPlusButton( mathAssignment );
            Log.assertThat( !masteryDetailsPage.getStudentName( mathAssignment ).isEmpty(), "After clicking [+] minus the all the students details are displayed", "After clicking [+] the students details are hidden!" );
            Log.testCaseResult();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( priority = 3, groups = { "SMK-42845", "mastery", "masteryLOview" } )
    public void tcMasteryDetails003( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        String assignmentName = context.getAttribute( "Math_Assignment3" ).toString();
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            masteryFiltersComponent.selectAssignmentNameFromDropDownMS( assignmentName );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            SMUtils.logDescriptionTC( "SMK-11461: Verify the NOT mastered mastery status has red colour background in the mastery details page is displayed" );
            SMUtils.logDescriptionTC( "SMK-11462: Verify the at risk mastery status has yellow colour background in the mastery details page is displayed" );
            SMUtils.logDescriptionTC( "SMK-11463: Verify the mastered mastery status has green colour background in the mastery details page is displayed" );

            Log.assertThat( masteryDetailsPage.verifyMasteryValueBGColor( browser ), "All the mastery status values are displayed with respective color background", "All the mastery status values are not displayed with respective color background!" );

            Log.testCaseResult();
            Log.testCaseResult();
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "SMK-11464: Verify the tootltip text displayed as  Number mastered , Number at risk, Number not mastered  in dark grey color background while hovering the pointer without clicking on the progress bar corresponding to the LO in the mastery details page" );
            //Get Tool Tip Text
            String tooltipOfProgressBar = masteryDetailsPage.getProgressBarToolTipText();
            // Validation 1:
            Log.assertThat( tooltipOfProgressBar.contains( "mastered" ), "Text mastered is present in the Tool tip in the Progress Bar", "Not present in the tool tip" );
            // Validation 2:
            Log.assertThat( tooltipOfProgressBar.contains( "at risk" ), "Text at risk is present in the Tool tip in the Progress Bar", "Not present in the tool tip" );
            // Validation 3:
            Log.assertThat( tooltipOfProgressBar.contains( "not mastered" ), "Text not mastered is present in the Tool tip in the Progress Bar", "Not present in the tool tip" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11468: Verify the teacher is able to view the Students count got mastered from total assessed students in the progress bar for the corresponding LO in green colour background" );
            Map<String, Map<String, Integer>> student_Status = masteryDetailsPage.getCountAndColorInProgressBar( browser );
            Log.assertThat( student_Status.get( Constants.MasteryUI.MASTERED ).containsKey( Constants.MasteryUI.MASTERED_COLOR_CODE ), "The 'Mastered' value in the Mastery Status columnn is displayed in green color",
                    "The 'Mastered' value in the Mastery Status columnn is not displayed as green color" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11469: Verify the teacher is able to view the students count got NOT mastered status from total assessed students in the progress bar for the corresponding LO in red colour background" );
            Log.assertThat( student_Status.get( Constants.MasteryUI.NOT_MASTERED ).containsKey( Constants.MasteryUI.NOTMASTERED_COLOR_CODE ), "The 'NOT Mastered' value in the Mastery Status columnn is displayed in Red color",
                    "The 'Not Mastered' value in the Mastery Status columnn is not displayed as Red color" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11470: Verify the teacher is able to view the students count got At Risk status from total assessed students in the progress bar for the corresponding LO in yellow colur background" );
            Log.assertThat( student_Status.get( Constants.MasteryUI.AT_RISK ).containsKey( Constants.MasteryUI.ATRISK_COLOR_CODE ), "The 'AT Risk' value in the Mastery Status columnn is displayed in Yellow color",
                    "The 'At Risk' value in the Mastery Status columnn is not displayed as Yellow color" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11471: Verify the teacher not able to view the students count got Unassessed in the progress bar for the corresponding LO" );
            SMUtils.logDescriptionTC( "SMK-11472: Verify the teacher able to view the unassessed status in grey colour in the progress bar for the corresponding LO" );
            Log.assertThat( student_Status.get( Constants.MasteryUI.UNASSESSED ).containsKey( Constants.MasteryUI.UNASSESSED_COLOR_CODE ), "The 'Unassessed' value in the Mastery Status columnn is displayed in Grey color",
                    "The 'Unassessed' value in the Mastery Status columnn is not displayed as grey color" );
            Log.testCaseResult();
            Log.testCaseResult();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 3, groups = { "SMK-42845", "mastery", "masteryLOview" } )
    public void tcMasteryDetails004( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        String assignmentName = context.getAttribute( "Math_Assignment3" ).toString();
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            masteryFiltersComponent.selectAssignmentNameFromDropDownMS( assignmentName );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            SMUtils.logDescriptionTC( "SMK-11474: Verify the total count of students having Mastered in the mastery Status column irrespective of assignments displayed is matching with the count present in the progress bar with Green color background" );
            Log.assertThat( masteryDetailsPage.getStatusCount( Constants.MasteryUI.MASTERED ) == masteryDetailsPage.getStudentsCount( Constants.MasteryUI.MASTERED ),
                    "The total count of students having Mastered in the mastery Status column irrespective of assignments displayed is matching with the count present in the progress bar with Green color background",
                    "The total count of students having Mastered in the mastery Status column irrespective of assignments displayed is not matching with the count present in the progress bar with Green color background!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11475: Verify the total count of students having NOT Mastered in the mastery status column irrespective of assignments displayed is matching with the count present in the progress bar with Red color background" );
            Log.assertThat( masteryDetailsPage.getStatusCount( Constants.MasteryUI.NOT_MASTERED ) == masteryDetailsPage.getStudentsCount( Constants.MasteryUI.NOT_MASTERED ),
                    "The total count of students having NOT Mastered in the mastery status column irrespective of assignments displayed is matching with the count present in the progress bar with Red color background",
                    "The total count of students having NOT Mastered in the mastery status column irrespective of assignments displayed is not matching with the count present in the progress bar with Red color background!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11476: Verify the total count of students having at Risk in the mastery status column irrespective of assignments displayed is matching with the count present in the progress bar with Yellow color background" );
            Log.assertThat( masteryDetailsPage.getStatusCount( Constants.MasteryUI.AT_RISK ) == masteryDetailsPage.getStudentsCount( Constants.MasteryUI.AT_RISK ),
                    "The total count of students having at Risk in the mastery status column irrespective of assignments displayed is matching with the count present in the progress bar with Yellow color background",
                    "The total count of students having at Risk in the mastery status column irrespective of assignments displayed is not matching with the count present in the progress bar with Yellow color background!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "SMK-11482: Verify the Teacher cannot view the list of students name , their mastery status, their number of skills evaluated and their number of attempts other than assignment name corresponding to each assignment in the mastery details page on clicking the (-) icon" );
            masteryDetailsPage.clickingMinusButton( assignmentName );
            Log.assertThat( masteryDetailsPage.getStudentName( assignmentName ).isEmpty(), "After clicking [-] minus the all the students details are hidden", "After clicking [-] the students details are getting displayed!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "SMK-11508: Verify the count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar after the same student has been assigned to multiple assignments." );
            Log.assertThat( masteryDetailsPage.getStudentCounts().contentEquals( masteryDetailsPage.getNoOfStudentAssessed() ),
                    "The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar ",
                    " The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is not matching with TOTAL count of students have taken assessment displayed above the progress bar" );
            Log.testCaseResult();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 3, groups = { "SMK-42845", "mastery", "masteryLOview" } )
    public void tcMasteryDetails005( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        String assignmentName = context.getAttribute( "Math_Assignment3" ).toString();
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            masteryFiltersComponent.selectAssignmentNameFromDropDownMS( assignmentName );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            SMUtils.logDescriptionTC( "SMK-11467: Verify the text displayed as 1 Student Assessment above the progress bar if only one student has taken assessment corresponding to the LO only in the mastery details page" );
            Log.assertThat( masteryDetailsPage.getStudentCounts().contentEquals( masteryDetailsPage.getNoOfStudentAssessed() ), "The text is displaying as 'number' Student Assessments for more than one student Assessment ",
                    "The text is displaying as 'number' Student Assessment for more than one student Assessment" );
            Log.testCaseResult();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

}
