package com.savvas.sm.teacher.ui.tests.coursesSuite;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants.UserType;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EditCourseSettingPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.MasteryDetailsPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.MyProfilePage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * The JIRA ID of the stories included in this java class are SMK-38853,
 * SMK-38855, SMK-45032 & SMK-43728.
 *
 * @author sandeep.pillai
 *
 */

@Listeners ( EmailReport.class )
public class CoursesTest extends BaseTest {
    private String smUrl;
    private String browser;
    private String staticCourseName = null;
    private String username = null;
    private String password = null;
    private String teacherID;
    //Change this index if you want to select use teacher other than "Teacher1"
    private int courseNameListSize;
    private String newlyCreatedCourse = null;
    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    private static String teacherDetails;
    private String token = null;
    private static String studentDetails;
    BaseAPITest baseApiObject = new BaseAPITest();
    UserSqlHelper userSqlHelper = new UserSqlHelper();
    SqlHelperOrganization sqlHelperOrganization = new SqlHelperOrganization();
    Set<String> teacherNames = new HashSet<>();
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    GroupAPI groupAPI = new GroupAPI();
    List<String> studentRumbaIds = new ArrayList<>();
    AssignmentAPI assignment = new AssignmentAPI();
    private HashMap<String, String> groupDetails = new HashMap<>();
    String organizationId = null;
    String userId = null;
    String groupName = null;
    String studentSMDetails;

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        // teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher" + teacherIndex );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        CourseAPI coursesMethod = new CourseAPI();
        AssignmentAPI assignmentMethod = new AssignmentAPI();
        UserAPI userAPIMethod = new UserAPI();

        //Student Details
        studentDetails = RBSDataSetup.getMyStudent( school, username );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        organizationId = RBSDataSetup.organizationIDs.get( school );

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Student SM Details
        studentSMDetails = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( school ), token ).get( Constants.REPORT_BODY );

        //Group creation
        groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );

        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

        Log.message( "Group details are" + groupDetails.toString() );

        Log.message( "Group id is " + groupId );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> Response = new HashMap<>();

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );

        Response = assignment.assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );

    }

    @Test ( description = "Verify the teacher is able to delete the custom courses", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 1 )
    public void verifyCourseware_001() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "Verify the teacher is able to delete the custom courses" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );

            newlyCreatedCourse = customCourses.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.MATH );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( newlyCreatedCourse );

            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );

            //Remove the course
            SMUtils.logDescriptionTC( "SMK-10223 : Verify the Remove button color in Remove Course popup for teacher user" );
            customCourses.removeCourse();

            //Traverse to Courseware
            tHomePage.topNavBar.getCourseListingPage();

            //Verify if the courses are sorted in the Descending order
            Log.softAssertThat( !customCourses.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Created custom course is deleted", "Created custom course is not deleted" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if All Courses are displayed", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 1 )
    public void verifyCourseware_002() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC006_Verify if All Courses are displayed." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage allCourses = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            SMUtils.logDescriptionTC( "SMK-5358 - TC007_Verify if all courses are displayed" );

            //Select All Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            courseNameListSize = allCourses.getCourseListForCustomCourse().size();

            int courseWidgetSize = allCourses.getCourseTypesFromCoursesWidgetFromCourses().size();

            SMUtils.logDescriptionTC( "SMK-5364 - CP02_Validate the different course types for given teacher" );

            SMUtils.logDescriptionTC( "SMK-22444 - TC001_Verify the teacher is able to see all the course in Courseware>Courses page" );

            // Verify if All Courses are present
            Log.softAssertThat( ( courseNameListSize >= courseWidgetSize && courseNameListSize >= Constants.FOCUS_AND_DEFAULT_COURSE_SIZE ), "All courses are present", "All courses are not present" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if Custom courses are displayed", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 1 )
    public void verifyCourseware_003() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	int customCourseSize;

        Log.testCaseInfo( "TC004_Verify if Custom courses are displayed." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-5355 - TC004_Verify if Custom courses are displayed" );

            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            SMUtils.logDescriptionTC( "SMK-5364 - CP02_Validate the different course types for given teacher" );

            //Custom course verification check
            customCourseSize = customCourses.getCourseDateListForCustomCourse().size();

            //Verify if all the Custom Courses are present
            Log.softAssertThat( ( customCourseSize > Constants.FOCUS_AND_DEFAULT_COURSE_SIZE ), "All the Custom courses are present", "All the Custom courses are not present" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "CP05_Validate newly added courses are displayed.", groups = { "SMK-45032_Test", "Courses", "Courses - Listing" }, priority = 2 )
    public void verifyCourseware_004() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "CP05_Validate newly added courses are displayed." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            MyProfilePage myProfilePage = new MyProfilePage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> teacherListFromTheAssignmentPopup = new ArrayList<>();
            List<String> studentList = new ArrayList<>();
            List<String> teacherListWhoAssignedTheCourse = new ArrayList<>();
            List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
            List<String> courseLastAssignedDateFromTheAssignmentPopup = new ArrayList<>();
            String courseCreatorName;

            newlyCreatedCourse = customCourses.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.MATH );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( newlyCreatedCourse );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( newlyCreatedCourse );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Assert Statement
            Log.softAssertThat( ( studentList.size() == studentListFromTheAssignmentPopup.size() ), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
                    Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //Traverse to Courseware>Courses
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( newlyCreatedCourse );

            //Click on the ellipses icon
            customCourses.clickEllipsisIcon();

            //Click on the View Assigned pop up
            customCourses.clickViewAssignedByButton();

            //Verify whether the 'Assigned By' text is present
            customCourses.viewAssignedByPopupTitle();

            //Verify whether the 'Close' button is present
            customCourses.viewAssignedByPopupCloseButton();

            //Original List before sorting
            teacherListFromTheAssignmentPopup = customCourses.getTeacherListFromViewAssignedByPopup();

            /*******
             * This is the area to verify the date format of
             * CourseLastAssignedDate
             *******/
            //Original List before sorting
            courseLastAssignedDateFromTheAssignmentPopup = customCourses.getCourseLastAssignedDatesFromViewAssignedByPopup();

            SMUtils.logDescriptionTC( "SMK-18777 - TC019_Verify the course last assigned date format is MM/DD/YYYY" );

            //Get the Course Last Assigned dates
            Log.softAssertThat( customCourses.isValidDateFormat( courseLastAssignedDateFromTheAssignmentPopup ), "CourseLastAssignedDate is in requried format", "CourseLastAssignedDate is not in requried format" );

            //Click on the OK button of View Assigned By pop up
            customCourses.clickViewAssignedByPopupOkBtn();

            //Traverse to Home page
            tHomePage.topNavBar.navigateToMyProfile();

            SMUtils.logDescriptionTC( "SMK-18759 - TC001_Verify the course owner teacher is able to see the name of the teacher in the 'Assigned By' popup who has assigned the unshared custom Math course created by the course owner teacher" );

            SMUtils.logDescriptionTC( "SMK-18761 - TC003_Verify the course owner teacher is able to see the name of the teacher in the 'Assigned By' popup who has assigned the shared custom Math course created by the course owner teacher" );

            //Get Title, FirstName, Middle Name & Last Name from the My Profile page
            courseCreatorName = customCourses.completeTeacherName( myProfilePage.getUserTitle(), myProfilePage.getFirstName(), myProfilePage.getMiddleName(), myProfilePage.getLastName() );

            teacherListWhoAssignedTheCourse.add( courseCreatorName );

            //Verify whether the teacher name is present in the list or not
            Log.softAssertThat( teacherListFromTheAssignmentPopup.containsAll( teacherListWhoAssignedTheCourse ), Constants.SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_PRESENT, Constants.SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_ABSENT );

            //Traverse to Assignment Tab
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Click on the Assignment
            customCourses.clickOnTheHoveredAssignment( newlyCreatedCourse );

            //Delete the Assignment
            assignmentDetailsPage.assignmentLevelEllipsis();

            // Click on removeAssignmets
            assignmentDetailsPage.deleteAssignmenttab();

            // CLick on Delete button for the assignment
            assignmentDetailsPage.deleteAssignmentButton();

            //Traverse to the Courseware
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            SMUtils.logDescriptionTC( "SMK-5367 - CP05_Validate newly added courses are displayed." );

            //Click on the course name
            customCourses.clickFromCourseListingPage( newlyCreatedCourse );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );

            //Assertion
            Log.softAssertThat( !editCourseSettingPage.isEditButtonDisplayed(), "Edit button is not displayed!", "Edit button is displayed" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC027_Verify whether the Teacher who created the course is able to do sorting on the Name and Course Last Assigned Column", groups = { "SMK-45032", "Course", "View Assigned By Pop up" }, priority = 2 )
    public void verifyCourseware_005() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC027_Verify whether the Teacher who created the course is able to do sorting on the Name and Course Last Assigned Column." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            MyProfilePage myProfilePage = new MyProfilePage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> techerListLastNames = new ArrayList<>();
            List<String> teacherListFromTheAssignmentPopup = new ArrayList<>();
            List<String> studentList = new ArrayList<>();
            List<String> teacherListWhoAssignedTheCourse = new ArrayList<>();
            List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
            List<String> techerListAsc = new ArrayList<>();
            List<String> techerListDsc = new ArrayList<>();
            List<String> courseLastAssignedListAsc = new ArrayList<>();
            List<String> courseLastAssignedListDsc = new ArrayList<>();
            List<String> courseLastAssignedDateFromTheAssignmentPopup = new ArrayList<>();
            String courseCreatorName;
            staticCourseName = customCourses.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Assert Statement
            Log.softAssertThat( studentList.size() == studentListFromTheAssignmentPopup.size(), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT, Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //Traverse to Courseware>Courses
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Click on the ellipses icon
            customCourses.clickEllipsisIcon();

            //Click on the View Assigned pop up
            customCourses.clickViewAssignedByButton();

            SMUtils.logDescriptionTC( "SMK-14012 - TC013_Verify if page header 'Assigned By' is displaying in bold font At top left corner of the page." );

            SMUtils.logDescriptionTC( "SMK-18771 - TC013_Verify if page header 'Assigned By' is displaying in bold font At top left corner of the page." );

            //Validate the CSS properties for View Assigned By popup
            customCourses.isViewAssignedByPopupTitleBoldAndLeftAligned();

            SMUtils.logDescriptionTC( "SMK-14028 - TC029_Verify whether the Popup title for Assigned By popup is left aligned as per the UX" );
            SMUtils.logDescriptionTC( "SMK-18787 - TC029_Verify whether the Popup title for Assigned By popup is left aligned as per the UX" );

            //Assertion
            Log.softAssertThat( customCourses.isViewAssignedByPopupTitleBoldAndLeftAligned(), "The CSS properties of the View Assigned By popup is as expected", "The CSS properties of the View Assigned By popup is not as expected" );

            SMUtils.logDescriptionTC( "SMK-14013 - TC014_Verify if Help icon(?) is present beside the header i.e.Assigned By." );

            SMUtils.logDescriptionTC( "SMK-18772 - TC014_Verify if Help icon(?) is present beside the header i.e.Assigned By." );

            //Verify the CSS property of the help icon
            customCourses.isHelpIconHavingExpectedCssProperty();

            SMUtils.logDescriptionTC( "SMK-14015 - TC016_Verify if Help icon(?) color is white and present inside the black circle." );

            SMUtils.logDescriptionTC( "SMK-18774 - TC016_Verify if Help icon(?) color is white and present inside the black circle." );

            //Assertion
            Log.softAssertThat( customCourses.isHelpIconHavingExpectedCssProperty(), "The CSS properties of the help icon is as expected", "The CSS properties of the help icon  is not as expected" );

            SMUtils.logDescriptionTC( "SMK-14016 - TC017_Verify the 'Name' coloumn is dispayed at left side along with teachers name and 'Name' text is bold." );

            SMUtils.logDescriptionTC( "SMK-18775 - TC017_Verify the 'Name' coloumn is dispayed at left side along with teachers name and 'Name' text is bold." );

            //Verify the CSS property of 'View Assigned By' pop up header and individual row
            customCourses.isHeaderAndIndividualRowHavingExpectedCssProperty();

            SMUtils.logDescriptionTC( "SMK-14017 - TC018_Verify the 'Course Last Assigned' coloumn is dispayed at right side along with teachers assigned dates and 'Course Last Assigned' text is bold." );

            SMUtils.logDescriptionTC( "SMK-18776 - TC018_Verify the 'Course Last Assigned' coloumn is dispayed at right side along with teachers assigned dates and 'Course Last Assigned' text is bold." );

            //Assertion
            Log.softAssertThat( customCourses.isHeaderAndIndividualRowHavingExpectedCssProperty(), "The CSS properties of the 'View Assigned By' pop up header and individual row is as expected",
                    "The CSS properties of the 'View Assigned By' pop up header and individual row is not as expected" );

            SMUtils.logDescriptionTC( "SMK-14019 - TC020_Verify 'Name' and 'Course Last Assigned' columns are horizontally aligned and having single horizontal line between each teacher and date." );

            SMUtils.logDescriptionTC( "SMK-18778 - TC020_Verify 'Name' and 'Course Last Assigned' columns are horizontally aligned and having single horizontal line between each teacher and date." );

            customCourses.isHorizonalLinePresent( browser );

            //Assertion
            Log.softAssertThat( customCourses.isHorizonalLinePresent( browser ), "'Name' and 'Course Last Assigned' columns are horizontally aligned and having single horizontal line between each teacher and date.",
                    "'Name' and 'Course Last Assigned' columns are not horizontally aligned and does not have single horizontal line between each teacher and date." );

            //Verify whether the 'Assigned By' text is present
            customCourses.viewAssignedByPopupTitle();

            SMUtils.logDescriptionTC( "SMK-14014 - TC015_Verify the close icon is present At top right corner of the page." );

            SMUtils.logDescriptionTC( "SMK-18773 - TC015_Verify the close icon is present At top right corner of the page." );

            //Verify whether the 'Close' button is present
            customCourses.viewAssignedByPopupCloseButton();

            /******* This is the area for Name sorting verification *******/

            SMUtils.logDescriptionTC( "SMK-14026 - TC027_Verify whether the Teacher who created the course is able to do sorting on the Name and Course Last Assigned Column" );

            SMUtils.logDescriptionTC( "SMK-18785 - TC027_Verify whether the Teacher who created the course is able to do sorting on the Name and Course Last Assigned Column" );

            //Original List before sorting
            teacherListFromTheAssignmentPopup = customCourses.getTeacherListFromViewAssignedByPopup();

            //Filtering the last name
            techerListLastNames = customCourses.returnLastNames( teacherListFromTheAssignmentPopup );

            //Sorting in ascending order
            techerListAsc = customCourses.sortTheList( techerListLastNames, Constants.CHECK_DESCENDING_ORDER );

            //Comparing the original list and the sorted list
            Log.softAssertThat( SMUtils.compareTwoList( techerListLastNames, techerListAsc ), "Teacher name sorted in ascending order", "Teacher name not sorted in ascending order" );

            //Clicking the column Name header for descending order
            customCourses.clickNameColumnHeader();

            ///Original List before sorting
            teacherListFromTheAssignmentPopup = customCourses.getTeacherListFromViewAssignedByPopup();

            //Filtering the last name
            techerListLastNames = customCourses.returnLastNames( teacherListFromTheAssignmentPopup );

            //Sorting in descending order
            techerListDsc = customCourses.sortTheList( techerListLastNames, Constants.CHECK_DESCENDING_ORDER );

            //Comparing the original list and the sorted list
            Log.softAssertThat( SMUtils.compareTwoList( techerListLastNames, techerListDsc ), "Teacher name sorted in descending order", "Teacher name not sorted in descending order" );

            /******* This is the area for Date sorting verification *******/

            //Get the Course Last Assigned dates
            customCourses.clickCourseLastAssignedDateColumn();

            //Original List before sorting
            courseLastAssignedDateFromTheAssignmentPopup = customCourses.getCourseLastAssignedDatesFromViewAssignedByPopup();

            //Sorting in ascending order
            courseLastAssignedListAsc = customCourses.sortTheList( courseLastAssignedDateFromTheAssignmentPopup, Constants.CHECK_DESCENDING_ORDER );

            //Comparing the original list and the sorted list
            Log.softAssertThat( SMUtils.compareTwoList( courseLastAssignedDateFromTheAssignmentPopup, courseLastAssignedListAsc ), "Dates sorted in ascending order", "Dates are not sorted in ascending order" );

            //Get the Course Last Assigned dates for descending order
            customCourses.clickCourseLastAssignedDateColumn();

            //Original List before sorting
            courseLastAssignedDateFromTheAssignmentPopup = customCourses.getCourseLastAssignedDatesFromViewAssignedByPopup();

            //Sorting in descending order
            courseLastAssignedListDsc = customCourses.sortTheList( courseLastAssignedDateFromTheAssignmentPopup, Constants.CHECK_DESCENDING_ORDER );

            //Comparing the original list and the sorted list
            Log.assertThat( SMUtils.compareTwoList( courseLastAssignedDateFromTheAssignmentPopup, courseLastAssignedListDsc ), "Dates sorted in descending order", "Dates are not sorted in descending order" );

            SMUtils.logDescriptionTC( "SMK-14020 - TC021_Verify the 'OK' button is present At bottom right corner of the page." );

            SMUtils.logDescriptionTC( "SMK-18779 - TC021_Verify the 'OK' button is present At bottom right corner of the page." );

            //Click on the OK button of View Assigned By pop up
            customCourses.clickViewAssignedByPopupOkBtn();

            //Traverse to Home page
            tHomePage.topNavBar.navigateToMyProfile();

            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            //Get Title, FirstName, Middle Name & Last Name from the My Profile page
            courseCreatorName = customCourses.completeTeacherName( myProfilePage.getUserTitle(), myProfilePage.getFirstName(), myProfilePage.getMiddleName(), myProfilePage.getLastName() );
            teacherListWhoAssignedTheCourse.add( courseCreatorName );

            //Verify whether the teacher name is present in the list or not
            Log.softAssertThat( teacherListFromTheAssignmentPopup.containsAll( teacherListWhoAssignedTheCourse ), Constants.SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_PRESENT, Constants.SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_ABSENT );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC007_Verify the unshared Custom Focus Math courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button.", groups = { "SMK-45032", "Course",
            "View Assigned By Pop up" }, priority = 2 )
    public void verifyCourseware_006() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC007_Verify the unshared Custom Focus Math courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser
                + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            MyProfilePage myProfilePage = new MyProfilePage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> teacherListFromTheAssignmentPopup = new ArrayList<>();
            List<String> studentList = new ArrayList<>();
            List<String> teacherListWhoAssignedTheCourse = new ArrayList<>();
            List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            String courseCreatorName;
            staticCourseName = customCourses.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-14006 - TC007_Verify the unshared Custom Focus Math courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button." );

            SMUtils.logDescriptionTC( "SMK-18765 - TC007_Verify the course owner teacher is able to see the name of the teacher in the 'Assigned By' popup who has assigned the unshared custom focus Math course created by the course owner teacher" );

            SMUtils.logDescriptionTC( "SMK-18766 - TC008_Verify the course owner teacher is able to see the name of the teacher in the 'Assigned By' popup who has assigned the unshared custom focus Math course created by the course owner teacher" );


            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Make a copy of the course
            customCourses.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.SM_FOCUS_MATH_GRADE1 );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Assert Statement
            Log.softAssertThat( studentList.size() == studentListFromTheAssignmentPopup.size(), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT, Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //Traverse to Courseware>Courses
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Click on the ellipses icon
            customCourses.clickEllipsisIcon();

            //Click on the View Assigned pop up
            customCourses.clickViewAssignedByButton();

            //Verify whether the 'Assigned By' text is present
            customCourses.viewAssignedByPopupTitle();

            //Verify whether the 'Close' button is present
            customCourses.viewAssignedByPopupCloseButton();

            //Original List before sorting
            teacherListFromTheAssignmentPopup = customCourses.getTeacherListFromViewAssignedByPopup();

            //Click on the OK button of View Assigned By pop up
            customCourses.clickViewAssignedByPopupOkBtn();

            //Traverse to Home page
            tHomePage.topNavBar.navigateToMyProfile();

            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            //Get Title, FirstName, Middle Name & Last Name from the My Profile page
            courseCreatorName = customCourses.completeTeacherName( myProfilePage.getUserTitle(), myProfilePage.getFirstName(), myProfilePage.getMiddleName(), myProfilePage.getLastName() );
            teacherListWhoAssignedTheCourse.add( courseCreatorName );

            //Verify whether the teacher name is present in the list or not
            Log.softAssertThat( teacherListFromTheAssignmentPopup.containsAll( teacherListWhoAssignedTheCourse ), Constants.SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_PRESENT, Constants.SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_ABSENT );

            //Traverse to Assignment Tab
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Click on the Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Delete the Assignment
            assignmentDetailsPage.assignmentLevelEllipsis();

            // Click on removeAssignmets
            assignmentDetailsPage.deleteAssignmenttab();

            // CLick on Delete button for the assignment
            assignmentDetailsPage.deleteAssignmentButton();

            //Traverse to the Courseware
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course name
            customCourses.clickFromCourseListingPage( staticCourseName );

            SMUtils.logDescriptionTC( "SMK-14004 - TC005_Verify the unshared Custom focus Math courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button" );

            SMUtils.logDescriptionTC( "SMK-18763 - TC005_Verify the course owner teacher is able to see the name of the teacher in the 'Assigned By' popup who has assigned the shared custom focus Math course created by the course owner teacher" );

            //Assertion
            Log.softAssertThat( !editCourseSettingPage.isEditButtonDisplayed(), "Edit button is not displayed!", "Edit button is displayed" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC006_Verify the unshared Custom Focus Reading courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button.", groups = { "SMK-45032", "Course",
            "View Assigned By Pop up" }, priority = 2 )
    public void verifyCourseware_007() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "TC006_Verify the unshared Custom Focus Reading courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser
                + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            SMUtils.logDescriptionTC( "SMK-18764 - TC006_Verify the course owner teacher is able to see the name of the teacher in the 'Assigned By' popup who has assigned the unshared custom focus Reading course created by the course owner teacher" );

            CoursesPage customCourses = new CoursesPage( driver );
            MyProfilePage myProfilePage = new MyProfilePage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> teacherListFromTheAssignmentPopup = new ArrayList<>();
            List<String> studentList = new ArrayList<>();
            List<String> teacherListWhoAssignedTheCourse = new ArrayList<>();
            List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            String courseCreatorName;
            staticCourseName = customCourses.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Make a copy of the course
            customCourses.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.SM_FOCUS_READING_GRADE1 );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Assert Statement
            Log.softAssertThat( studentList.size() == studentListFromTheAssignmentPopup.size(), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT, Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //Traverse to Courseware>Courses
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Click on the ellipses icon
            customCourses.clickEllipsisIcon();

            //Click on the View Assigned pop up
            customCourses.clickViewAssignedByButton();

            //Verify whether the 'Assigned By' text is present
            customCourses.viewAssignedByPopupTitle();

            //Verify whether the 'Close' button is present
            customCourses.viewAssignedByPopupCloseButton();

            //Original List before sorting
            teacherListFromTheAssignmentPopup = customCourses.getTeacherListFromViewAssignedByPopup();

            //Click on the OK button of View Assigned By pop up
            customCourses.clickViewAssignedByPopupOkBtn();

            //Traverse to Home page
            tHomePage.topNavBar.navigateToMyProfile();

            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            //Get Title, FirstName, Middle Name & Last Name from the My Profile page
            courseCreatorName = customCourses.completeTeacherName( myProfilePage.getUserTitle(), myProfilePage.getFirstName(), myProfilePage.getMiddleName(), myProfilePage.getLastName() );
            teacherListWhoAssignedTheCourse.add( courseCreatorName );

            //Verify whether the teacher name is present in the list or not
            Log.softAssertThat( teacherListFromTheAssignmentPopup.containsAll( teacherListWhoAssignedTheCourse ), Constants.SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_PRESENT, Constants.SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_ABSENT );

            //Traverse to Assignment Tab
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Click on the Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Delete the Assignment
            assignmentDetailsPage.assignmentLevelEllipsis();

            // Click on removeAssignmets
            assignmentDetailsPage.deleteAssignmenttab();

            // CLick on Delete button for the assignment
            assignmentDetailsPage.deleteAssignmentButton();

            //Traverse to the Courseware
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course name
            customCourses.clickFromCourseListingPage( staticCourseName );

            SMUtils.logDescriptionTC( "SMK-14005 - TC006_Verify the unshared Custom Focus Reading courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button." );

            //Assertion
            Log.softAssertThat( !editCourseSettingPage.isEditButtonDisplayed(), "Edit button is not displayed!", "Edit button is displayed" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC039_Verify the Teacher who created the course is able to 'Remove' the course from the Dashboard Courseware Widget>Courses section once all the listed teachers in the Assigned By popup have removed the students from the shared course", groups = {
            "SMK-45032", "Course", "View Assigned By Pop up" }, priority = 3 )
    public void verifyCoursware_008() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo(
                "TC039_Verify the Teacher who created the course is able to 'Remove' the course from the Dashboard Courseware Widget>Courses section once all the listed teachers in the Assigned By popup have removed the students from the shared course."
                        + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            staticCourseName = customCourses.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            SMUtils.logDescriptionTC( "SMK-14000 - TC001_Verify the unshared Custom Math courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button." );

            SMUtils.logDescriptionTC(
                    "SMK-14038 - TC039_Verify the Teacher who created the course is able to 'Remove' the course from the Dashboard Courseware Widget>Courses section once all the listed teachers in the Assigned By popup have removed the students from the shared course" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Traverse to Assignment Tab
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Click on the Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Delete the Assignment
            assignmentDetailsPage.assignmentLevelEllipsis();

            // Click on removeAssignmets
            assignmentDetailsPage.deleteAssignmenttab();

            // CLick on Delete button for the assignment
            assignmentDetailsPage.deleteAssignmentButton();

            //Traverse to the Courseware
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course name
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Assertion
            Log.softAssertThat( !editCourseSettingPage.isEditButtonDisplayed(), "Edit button is not displayed!", "Edit button is displayed" );

            //We are commenting this code because we cannot delete the course once the assignment has been created out of the course.
            /**
             * SMUtils.logDescriptionTC( "SMK-14039 - TC040_Verify the Teacher
             * who created the course is able to 'Edit Settings' of the course
             * from the Dashboard Courseware Widget>Courses section once all the
             * listed teachers in the Assigned By popup have removed the
             * students from the shared course" );
             *
             * //Edit the course settings customCourses.clickEditBtn();
             *
             * SMUtils.logDescriptionTC( "SMK-14010 - TC010_Verify the course
             * should be editable and deletable after the deletion of every
             * assignment" );
             *
             * //Verify Display LO Information is ON
             * customCourses.getTheStatusOfTheDisplayLoInformation(
             * Constants.ON_CAPS );
             *
             * //Change Display LO Information
             * customCourses.changeStatusOfTheDisplayLoInformation(
             * Constants.OFF_CAPS );
             *
             * //Click Save button customCourses.clickSaveBtn();
             *
             * //Verifying whether the Display LO Information is ON/OFF
             * Log.softAssertThat(
             * customCourses.getTheStatusOfTheDisplayLoInformationFromCourseSettings(
             * Constants.OFF_CAPS ).equals( Constants.OFF_CAPS ),
             * Constants.SUCCESS_MESSAGE_FOR_DISPLAY_LO_INFORMATION_TURNED_OFF,
             * Constants.SUCCESS_MESSAGE_FOR_DISPLAY_LO_INFORMATION_TURNED_ON );
             *
             * //Traverse to the Courseware
             * tHomePage.topNavBar.getCourseListingPage();
             *
             * //Select Custom Courses from the first drop down
             * courseListingPage.selectCourseTypeFromDropDown(
             * Constants.CUSTOM_COURSES );
             *
             * //Sort by date descending courseListingPage.selectsortByDropDown(
             * Constants.CHECK_DESCENDING_ORDER );
             *
             * //Click on the course name
             * customCourses.clickFromCourseListingPage( staticCourseName );
             *
             * SMUtils.logDescriptionTC( "SMK-14036 - TC037_Verify the Teacher
             * who created the course is able to remove the course from the
             * Courseware>Courses section once all the listed teachers in the
             * Assigned By popup have removed their students from the shared
             * course assignment" );
             *
             * //Remove the course customCourses.removeCourse();
             *
             * //Traverse to Courseware
             * tHomePage.topNavBar.getCourseListingPage();
             *
             * //Select Custom Courses from the first drop down
             * courseListingPage.selectCourseTypeFromDropDown(
             * Constants.CUSTOM_COURSES );
             *
             * //Sort by date descending courseListingPage.selectsortByDropDown(
             * Constants.CHECK_DESCENDING_ORDER );
             *
             * //Verify if the courses are sorted in the Descending order
             * Log.softAssertThat( Boolean.FALSE.equals(
             * customCourses.verifyCourseRemovedSuccessfully( staticCourseName )
             * ), "The Teacher who created the course is able to 'Remove' the
             * course from the Dashboard Courseware Widget>Courses section once
             * all the listed teachers in the Assigned By popup have removed the
             * students from the shared course", "The Teacher who created the
             * course is unable to 'Remove' the course from the Dashboard
             * Courseware Widget>Courses section once all the listed teachers in
             * the Assigned By popup have removed the students from the shared
             * course" );
             **/
            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC008_Verify the Custom Reading courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button.", groups = { "SMK-45032", "Course", "View Assigned By Pop up" }, priority = 3 )
    public void verifyCoursware_009() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo(
                "TC008_Verify the Custom Reading courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );
            MyProfilePage myProfilePage = new MyProfilePage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> teacherListFromTheAssignmentPopup = new ArrayList<>();
            List<String> studentList = new ArrayList<>();
            List<String> teacherListWhoAssignedTheCourse = new ArrayList<>();
            List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            String courseCreatorName;

            staticCourseName = customCourses.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            SMUtils.logDescriptionTC( "SMK-14007 - TC008_Verify the Custom Reading courses assigned to student, shows the mutual exlusion of the Edit and the 'View Teachers Assigned' button." );

            SMUtils.logDescriptionTC( "SMK-18760 - TC002_Verify the course owner teacher is able to see the name of the teacher in the 'Assigned By' popup who has assigned the shared custom Reading course created by the course owner teacher" );

            SMUtils.logDescriptionTC( "SMK-18762 - TC004_Verify the course owner teacher is able to see the name of the teacher in the 'Assigned By' popup who has assigned the shared custom focus Reading course created by the course owner teacher" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 20 );

            //Assert Statement
            Log.softAssertThat( studentList.size() == studentListFromTheAssignmentPopup.size(), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT, Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //Traverse to Courseware>Courses
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Click on the ellipses icon
            customCourses.clickEllipsisIcon();

            //Click on the View Assigned pop up
            customCourses.clickViewAssignedByButton();

            //Verify whether the 'Assigned By' text is present
            customCourses.viewAssignedByPopupTitle();

            //Verify whether the 'Close' button is present
            customCourses.viewAssignedByPopupCloseButton();

            //Original List before sorting
            teacherListFromTheAssignmentPopup = customCourses.getTeacherListFromViewAssignedByPopup();

            //Click on the OK button of View Assigned By pop up
            customCourses.clickViewAssignedByPopupOkBtn();

            //Traverse to Home page
            tHomePage.topNavBar.navigateToMyProfile();

            SMUtils.waitForSpinnertoDisapper( driver, 30 );

            //Get Title, FirstName, Middle Name & Last Name from the My Profile page
            courseCreatorName = customCourses.completeTeacherName( myProfilePage.getUserTitle(), myProfilePage.getFirstName(), myProfilePage.getMiddleName(), myProfilePage.getLastName() );
            teacherListWhoAssignedTheCourse.add( courseCreatorName );

            SMUtils.logDescriptionTC( "SMK-18790 - TC032_Verify the teacher who created the course are able to see the list of teachers who have assigned their course to their respective students" );

            //Verify whether the teacher name is present in the list or not
            Log.softAssertThat( teacherListFromTheAssignmentPopup.containsAll( teacherListWhoAssignedTheCourse ), Constants.SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_PRESENT, Constants.SUCCESS_MESSAGE_FOR_TEACHER_NAME_IS_ABSENT );

            //Traverse to Assignment Tab
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Click on the Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Delete the Assignment
            assignmentDetailsPage.assignmentLevelEllipsis();

            // Click on removeAssignmets
            assignmentDetailsPage.deleteAssignmenttab();

            // CLick on Delete button for the assignment
            assignmentDetailsPage.deleteAssignmentButton();

            //Traverse to the Courseware
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course name
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Assertion
            Log.softAssertThat( !editCourseSettingPage.isEditButtonDisplayed(), "Edit button is not displayed!", "Edit button is displayed" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC001_Verify the display of 2 new drop down lists in the Courses screen", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 2 )
    public void verifyCourseware_010() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "TC001_Verify the display of 2 new drop down lists in the Courses screen." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-5352 - TC001_Verify the display of 2 new drop down lists in the Courses screen" );

            //Verify whether the Courses Type drop down exist
            Log.softAssertThat( courseListingPage.courseTypeDropDown(), "Course Type Dropdown is present.", "Course Type Dropdown is absent." );

            //Verify whether the Sort By drop down exist
            Log.softAssertThat( courseListingPage.sortByDropDown(), "Sort by Dropdown is present.", "Sort by Dropdown is absent." );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the filter options of Courses drop down list", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 2 )
    public void verifyCourseware_011() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC002_Verify the filter options of Courses drop down list." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-5353 - TC002_Verify the filter options of Courses drop down list" );

            //List containing all the names of the different types of course available in the first drop down
            List<String> actualCourseTypeNamesInDropdwn = courseListingPage.getAllCourseTypeDropDownItems();

            //Verify the Course Type drop down
            Log.softAssertThat( SMUtils.compareTwoList( Constants.COURSE_TYPES, actualCourseTypeNamesInDropdwn ), "Expected course types are present.", "Expected course types are not present." );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the filter options of Sort by drop down list", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 2 )
    public void verifyCourseware_012() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC003_Verify the filter options of Sort by drop down list." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-5354 - TC003_Verify the filter options of Sort by drop down list" );

            //List containing all the names of the different types of sorting available in the second drop down
            List<String> actualSortByNamesInDropdwn = courseListingPage.getAllSortByDropDownItems();

            //Verify the Sort By drop down
            Log.softAssertThat( SMUtils.compareTwoList( Constants.SORT_BY, actualSortByNamesInDropdwn ), "Expected sort By types are present.", "Expected sort By types are not present." );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if Focus courses are displayed", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 2 )
    public void verifyCourseware_013() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "TC005_Verify if Focus courses are displayed" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage focusCourses = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            SMUtils.logDescriptionTC( "SMK-5356 - TC005_Verify if Focus courses are displayed" );

            //Select Focus courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            SMUtils.logDescriptionTC( "SMK-5366 - CP04_Validate the different course types for given teacher" );

            //Verify if all the Focus Courses are present
            Log.softAssertThat( ( focusCourses.getCourseNameList().size() == Constants.FOCUS_COURSE_SIZE && focusCourses.compareNameWithList( focusCourses.getCourseTypesFromCoursesWidget(), Constants.FOCUS_COURSE ) ),
                    "All the Focus courses are present", "All the Focus courses are not present" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if the default are displayed", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 2 )
    public void verifyCourseware_014() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC007_Verify if the default are displayed." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage defaultCourses = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            SMUtils.logDescriptionTC( "SMK-15250 - TC006_Verify if Default courses are displayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            SMUtils.logDescriptionTC( "SMK-5366 - CP04_Validate the different course types for given teacher" );

            //Verify if all the Default Courses are present
            Log.softAssertThat( ( defaultCourses.getCourseNameList().size() == Constants.DEFAULT_COURSE_SIZE && defaultCourses.compareNameWithList( defaultCourses.getCourseTypesFromCoursesWidget(), Constants.FULL_COURSE ) ),
                    "All the Default courses are present", "All the Default courses are not present" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if all courses are displayed by Course Title- alphabetical ascending order", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 2 )
    public void verifyCourseware_015() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "TC008_Verify if all courses are displayed by Course Title- alphabetical ascending order." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage focusCourses = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            SMUtils.logDescriptionTC( "SMK-5359 - TC008_Verify if all courses are displayed by Course Title- alphabetical ascending order" );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Selecting the option 'Course Title (Ascending)' from the sortBy drop down menu
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Verify if all the Focus Courses are present
            Log.softAssertThat( focusCourses.getCourseNameList().size() == Constants.FOCUS_COURSE_SIZE, "All the focus course are present", "All the focus courses are not present" );

            //List containing all the Focus course
            List<String> obtainedList = new ArrayList<>();
            obtainedList = focusCourses.getCourseNameList();

            //Verify if the courses are sorted in the Ascending order
            Log.softAssertThat( focusCourses.sortTheList( obtainedList, Constants.CHECK_DESCENDING_ORDER ).equals( obtainedList ), "All the focus course are sorted in Course Title- alphabetical ascending order",
                    "All the focus course are not sorted in Course Title- alphabetical ascending order" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if all courses are displayed by Course Title- alphabetical descending order", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 2 )
    public void verifyCourseware_016() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC009_Verify if all courses are displayed by Course Title- alphabetical descending order." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage focusCourses = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            SMUtils.logDescriptionTC( "SMK-5360  - TC009_Verify if all courses are displayed by Course Title- alphabetical descending order" );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Selecting the option 'Course Title (Descending)' from the sortBy drop down menu
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Verify if all the Focus Courses are present
            Log.softAssertThat( focusCourses.getCourseNameList().size() == Constants.FOCUS_COURSE_SIZE, "All the focus course are present", "All the focus courses are not present" );

            //List containing all the Focus course
            List<String> obtainedList = new ArrayList<>();
            obtainedList = focusCourses.getCourseNameList();

            //Verify if the courses are sorted in the Descending order
            Log.softAssertThat( focusCourses.sortTheList( obtainedList, Constants.CHECK_DESCENDING_ORDER ).equals( obtainedList ), "All the focus course are sorted in Course Title- alphabetical descending order",
                    "All the focus course are not sorted in Course Title- alphabetical descending order" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC011_Verify if all courses are displayed by Creation Date (Oldest First)", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 2 )
    public void verifyCourseware_017() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC011_Verify if all courses are displayed by Creation Date (Oldest First)." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );

            List<LocalDate> obtainedList = new ArrayList<>();
            List<LocalDate> sortedList = new ArrayList<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-5361 - TC011_Verify if all courses are displayed by Creation Date (Oldest First)" );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Selecting the option 'Course Title (Descending)' from the sortBy drop down menu
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_ASCENDING_ORDER );

            //Get the original list of dates
            obtainedList = customCourses.convertCourseDateToDesiredLocalDate( customCourses.getCourseDateListForCustomCourse() );

            //Getting the original list sorted
            sortedList = customCourses.verifySortingOfCoursesBasedOnCourseDate( obtainedList, Constants.CHECK_DATE_ASCENDING_ORDER );

            //Verify if the courses are sorted in the Ascending order
            Log.softAssertThat( sortedList.equals( obtainedList ), "All courses are displayed by Creation Date (Oldest First)", "All courses are not displayed by Creation Date (Oldest First)" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "TC010_Verify if all courses are displayed by Creation Date (Newest First)", groups = { "SMK-38855", "Courses", "Courses - Filter" }, priority = 2 )
    public void verifyCourseware_018() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC010_Verify if all courses are displayed by Creation Date (Newest First)." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<LocalDate> obtainedList = new ArrayList<>();
            List<LocalDate> sortedList = new ArrayList<>();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 5 );

            SMUtils.logDescriptionTC( "SMK-5362 - TC010_Verify if all courses are displayed by Creation Date (Newest First)" );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Selecting the option 'Course Title (Descending)' from the sortBy drop down menu
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Get the original list of dates
            obtainedList = customCourses.convertCourseDateToDesiredLocalDate( customCourses.getCourseDateListForCustomCourse() );

            //Getting the original list sorted
            sortedList = customCourses.verifySortingOfCoursesBasedOnCourseDate( obtainedList, Constants.CHECK_DESCENDING_ORDER );

            //Verify if the courses are sorted in the Descending order
            Log.softAssertThat( sortedList.equals( obtainedList ), "All courses are displayed by Creation Date (Newest First)", "All courses are not displayed by Creation Date (Newest First)" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify when the teacher clicks on any one of the hovered student,group or Assignment the same is opened", groups = { "SMK-43728", "Assignment", "Hovering effect" }, priority = 2 )
    public void verifyCourseware_019( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "Verify when the teacher clicks on any one of the hovered student,group or Assignment the same is opened." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        String studentDetail = studentSMDetails;

        String studentIdentificationNumber = SMUtils.getKeyValueFromResponse( studentDetail, "data,studentIdentificationNumber" );

        try {
            CoursesPage customCourses = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            GroupPage groupPage = new GroupPage( driver );
            List<String> studentList = new ArrayList<>();
            List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
            staticCourseName = customCourses.generateRandomCourseName();

            //Student Id created using data setup script
            String studentID = studentIdentificationNumber;

            // Navigate to Student Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Sort the Student ID in ascending order
            studentsPage.sortBasedOnStudentId();

            SMUtils.logDescriptionTC( "SMK-11224 - Verify when the teacher clicks on the hovered student name the View Student page is opened" );

            //Click on the Student name
            studentsPage.clickOnTheHoveredStudent( studentID );

            //Click on the User Profile Page for student section
            studentsPage.clickSubNavigation( "User Profile" );

            //Compare it with the name fetched from the student name in the student listing page
            Log.softAssertThat( studentsPage.verifyStudentIdInProfile( studentID ), "Teacher is able to click on the Students name and student details page is visible as expected",
                    "Teacher is unable to click on the Students name and student details page is not visible" );

            //Traverse to the Group section
            tHomePage.topNavBar.navigateToGroupsTab();

            SMUtils.logDescriptionTC( "SMK-11231 - Verify when the teacher clicks on any one of the available groups the View Groups page is open" );
            //Click on the group name
            groupPage.clickOnTheHoveredGroup( groupName );

            //Compare it with the name fetched from the group name in the group listing page
            Log.softAssertThat( groupPage.verifyGroupNameInProfile( groupName ), "Teacher is able to click on the group name and group details page is visible as expected",
                    "Teacher is unable to click on the group name and group details page is not visible" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Verify Edit & Remove button presence
            customCourses.verifyEditAndRemoveBtnPresent();

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            SMUtils.logDescriptionTC( "SMK-11238 - Verify when the teacher clicks on any one of the visible assignment in the Courseware>Assignments section it leads us to the View Assignmens page" );

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Assert Statement
            Log.softAssertThat( studentList.size() == studentListFromTheAssignmentPopup.size(), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT, Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //Verify the Assignment name with that of the heading
            Log.softAssertThat( staticCourseName.equals( customCourses.getAssignmentTitle( staticCourseName ) ), "Teacher clicked on the expected assignment", "Teacher didn't click on the expected assignment" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify when the teacher clicks on the ellipse icon the teacher is able to view the dropdown option", groups = { "SMK-43728", "Assignemnt Details", "Hovering effect" }, priority = 2 )
    public void verifyCourseware_020( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify when the teacher clicks on the ellipse icon the teacher is able to view the dropdown option." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        String studentDetail = studentSMDetails;

        String studentFirstName = SMUtils.getKeyValueFromResponse( studentDetail, "data,firstName" );
        String studentMiddleName = SMUtils.getKeyValueFromResponse( studentDetail, "data,middleName" );
        String studentLastName = SMUtils.getKeyValueFromResponse( studentDetail, "data,lastName" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            CoursesPage customCourses = new CoursesPage( driver );
            List<String> ellipsisOptionAvailableAtStudentLevel = new ArrayList<>();
            List<String> expectedEllipsisOptionAvailableAtStudentLevel = Constants.STUDENT_LEVEL_ASSIGNMENT_ELLIPSIS_OPTION;
            staticCourseName = customCourses.generateRandomCourseName();

            //Student Name(Created using data setup script)
            String studentName = customCourses.completeStudentName( studentFirstName, studentMiddleName, studentLastName );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Verify Edit & Remove button presence
            customCourses.verifyEditAndRemoveBtnPresent();

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Navigate to Assignment
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Click on the Assignment name
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            SMUtils.logDescriptionTC( "SMK-11240 - Verify when the teacher clicks on any one of the available student in the student list of View Assignment page it should expand" );

            //Click on to expand the skill details
            assignmentDetailsPage.clicktoggleButtonForStudent( studentFirstName, studentMiddleName, studentLastName );

            SMUtils.logDescriptionTC( "SMK-11241 - Verify when the teacher clicks on any one of the available student in the student list of View Assignment page for the second time its should collapse" );

            //Click on to shrink the details
            assignmentDetailsPage.skillTestCollapseForStudent( studentFirstName, studentMiddleName, studentLastName );

            //Verify the Assignment name with that of the heading
            Log.softAssertThat( customCourses.getAssignmentTitle().contains( staticCourseName ), "Teacher clicked on the expected assignment", "Teacher didn't click on the expected assignment" );

            SMUtils.logDescriptionTC( "SMK-11242 - Verify when the teacher clicks on the ellipse icon the teacher is able to view the dropdown option" );

            //Get all the ellipsis options
            ellipsisOptionAvailableAtStudentLevel = assignmentDetailsPage.getAllEllipsisOptionAtStudentLevel( studentName );

            //Verify all the options are present in the ellipsis option
            Log.softAssertThat( ellipsisOptionAvailableAtStudentLevel.equals( expectedEllipsisOptionAvailableAtStudentLevel ), "All the ellipsis options are available at the student level",
                    "All the ellipsis options are not available at the student level" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-45032 : Verify View Assigned By table", groups = { "SMK-45032_Test", "Courses", "Courses - Listing" }, priority = 2 )
    public void verifyCourseware_021() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "SMK-14030 : TC031_Verify there is no extra space between 'Make a copy' button and the ellipsis" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage customCourses = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            SMUtils.logDescriptionTC( "SMK- : TC023_Verify 'Name' and 'Course Last Assigned' columns area is in light grey color." );

            SMUtils.logDescriptionTC( "SMK-18789 : TC031_Verify there is no extra space between 'Make a copy' button and the ellipsis" );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            newlyCreatedCourse = customCourses.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.MATH );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( newlyCreatedCourse );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( newlyCreatedCourse );

            //Traverse to Courseware>Courses
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( newlyCreatedCourse );

            //Verify the spacing between ellipsis and make a copy button
            Log.softAssertThat( customCourses.isMarginLeftisZero(), "There is no space between Make a Copy and Ellipsis", "There is space between Make a Copy and Ellipsis" );

            //Click on the ellipses icon
            customCourses.clickEllipsisIcon();

            //Click on the View Assigned pop up
            customCourses.clickViewAssignedByButton();

            //Verify whether the 'Assigned By' text is present
            customCourses.viewAssignedByPopupTitle();

            SMUtils.logDescriptionTC( "SMK-14022 : TC023_Verify 'Name' and 'Course Last Assigned' columns area is in light grey color." );

            SMUtils.logDescriptionTC( "SMK-18781 - TC023_Verify 'Name' and 'Course Last Assigned' columns area is in light grey color." );

            //Verify Colour of Names & Courses Last Assigned row
            Log.softAssertThat( customCourses.isTheHeaderRowGrayColor(), "The color is Gray", "The Color is not Gray" );

            SMUtils.logDescriptionTC( "SMK-14029 : TC030_Verify whether the spacing above the 'Name' & 'Course Last Assigned' column headings of Assigned By popup matches the UX" );
            SMUtils.logDescriptionTC( "SMK-18788 : TC030_Verify whether the spacing above the 'Name' & 'Course Last Assigned' column headings of Assigned By popup matches the UX" );
            //Verify top spacing of Names & Courses last Assigned
            Log.softAssertThat( customCourses.isTheSpacingOfHeadingIsAsExpected(), "The spacing of 'Name' and 'Course Last Assigned' columns are as expected", "The spacing of 'Name' and 'Course Last Assigned' columns are not as expected" );

            SMUtils.logDescriptionTC( "SMK-14032 : TC033_Verify whether the OK button of the Assigned By popup is vertically centre aligned as per the UX" );

            SMUtils.logDescriptionTC( "SMK-18791 : TC033_Verify whether the OK button of the Assigned By popup is vertically centre aligned as per the UX" );
            //Verify OK button is vertically center aligned
            Log.softAssertThat( customCourses.isOKTextCenterAligned(), "OK button is Center Aligned", "OK button is not Center Aligned" );

            SMUtils.logDescriptionTC( "SMK-18792 : TC034_Verify whether the text of 'View Assigned By' pop up such as Teacher Name, Last date assigned are as per shown in the UX" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    // Teachers dynamically created using Rumba since excluding the below code
    /**
     *
     * @Test ( description = "Verify the new teachers are created in the DB and
     *       assign the course created by the Teacher1", groups = { "SMK-45032",
     *       "Course", "View Assigned By Pop up" }, priority = 4 ) public void
     *       verifyTeacherCreation_022() throws Exception { try {
     *       IntStream.range( 0, Constants.TEACHER_INDEX ).forEach( elementIndex
     *       -> { try { String teacherName = "Teacher" + System.nanoTime();
     *       Integer teacherPersonId = userSqlHelper.createTeacher( teacherName,
     *       teacherName, teacherName, Constants.PASSWORD_HASH, (Integer)
     *       orgIdFinal ); if ( Boolean.FALSE.equals( teacherPersonId == null )
     *       ) { Log.message( "Teacher created: " + teacherName ); Log.message(
     *       "Org id is " + orgIdFinal ); } teacherNames.add( teacherName );
     *       String teacherId = userSqlHelper.getPersonID( teacherName ); String
     *       orgId = userSqlHelper.getOrgId( teacherId ); String studentName =
     *       "Student" + System.nanoTime(); String sessionCookie =
     *       baseApiObject.getJessionCookie( smUrl, teacherName, password );
     *       String studentPersonId = baseApiObject.createStudent( smUrl,
     *       sessionCookie, studentName, studentName, studentName, studentName,
     *       teacherId, orgId, Constants.GRADE_NUMBER_3 ); if (
     *       Boolean.FALSE.equals( studentPersonId == null ) ) { Log.message(
     *       "Student created: " + studentName ); } } catch ( Exception e ) {
     *       Log.message( "Error occured while creating Teacher" ); } } );
     *       teacherNames.forEach( teacherName -> { String localTeacherpassword
     *       = DataSetupConstants.DEFAULT_PASSWORD; try { final WebDriver driver
     *       = WebDriverFactory.get( browser ); List<String>
     *       studentListFromTheAssignmentPopup = new ArrayList<>(); List<String>
     *       studentList = new ArrayList<>();
     *
     *       // LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
     *
     *       CoursesPage coursePage = new CoursesPage( driver ); //
     *       TeacherHomePage tHomePage = new TeacherHomePage( driver ); //Get
     *       CourseLising Page CourseListingPage courseListingPage = new
     *       CourseListingPage( driver );
     *
     *       // tHomePage = smLoginPage.loginToSM( teacherName,
     *       localTeacherpassword, true );
     *
     *       LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl,
     *       UserType.BASIC, null, teacherName, localTeacherpassword );
     *       SMUtils.nap( 10 ); SMUtils.waitForSpinnertoDisapper( driver );
     *       TeacherHomePage tHomePage = new TeacherHomePage( driver );
     *
     *       //Get CourseLising Page tHomePage.topNavBar.getCourseListingPage();
     *
     *       //Select Custom Courses from the first drop down
     *       courseListingPage.selectCourseTypeFromDropDown(
     *       Constants.CUSTOM_COURSES );
     *
     *       //Sort by date descending courseListingPage.selectsortByDropDown(
     *       Constants.CHECK_DESCENDING_ORDER );
     *
     *       //Click on the course coursePage.clickFromCourseListingPage(
     *       newlyCreatedCourse );
     *
     *       SMUtils.logDescriptionTC( "TC011_Verify the other teacher should
     *       not be able to see new button 'View Teachers Assigned' for courses
     *       not created by them" );
     *
     *       SMUtils.logDescriptionTC( "TC018_Verify if Teacher2 from same
     *       organization is able to see the course created by Teacher1" );
     *
     *       // Verify Remove button is present Log.assertThat(
     *       Boolean.FALSE.equals( coursePage.verifyRemoveBtnIsPresent() &&
     *       coursePage.verifyEditBtnIsPresent() ), "Other Teacher are not able
     *       to see 'View Assigned By Popup' as expected", "Other Teacher are
     *       not able to see 'View Assigned By Popup'" );
     *
     *       //Click on the assignment coursePage.clickAssignBtn();
     *
     *       //Get the count of the student from the assignment pop up
     *       studentListFromTheAssignmentPopup =
     *       coursePage.getAllStudentNameFromAssignPopUp();
     *
     *       //Assign the course to the student
     *       coursePage.addCourseToStudents();
     *
     *       //Traverse to the assignment coursePage.clickAssignmentSubMenu();
     *
     *       //Click on the View Assignment
     *       coursePage.clickOnTheHoveredAssignment( newlyCreatedCourse );
     *
     *       //Verify whether the student is present in the particular
     *       assignment studentList =
     *       coursePage.getStudentListfromAssignementDetailsTable();
     *
     *       //Assert Statement Log.softAssertThat( Boolean.TRUE.equals(
     *       studentList.size() == studentListFromTheAssignmentPopup.size() ),
     *       Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
     *       Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT
     *       ); //Sign out tHomePage.topNavBar.signOutfromSM(); driver.quit(); }
     *       catch ( Exception e ) { e.printStackTrace(); } } );
     *
     *       Log.testCaseResult();
     *
     *       } catch ( Exception e ) { Log.exception( e ); } finally {
     *       Log.endTestCase(); } }
     **/
    @Test ( description = "Verify if the UX if the Assigned By popup is as expected", groups = { "SMK-45032", "Course", "View Assigned By Pop up" }, priority = 5 )
    public void verifyCourseware_023() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify if the UX if the Assigned By popup is as expected" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            CoursesPage coursePage = new CoursesPage( driver );

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            //Click on the course
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            //Click on the ellipses icon
            coursePage.clickEllipsisIcon();

            //Click on the View Assigned pop up
            coursePage.clickViewAssignedByButton();

            SMUtils.logDescriptionTC( "TC022_Verify the scrollbar is present At right side of the page." );

            SMUtils.logDescriptionTC( "SMK-18780 - TC022_Verify the scrollbar is present At right side of the page." );

            SMUtils.logDescriptionTC( "SMK-18786 - TC028_Verify the column headers of the Assigned By popup should not get scrolled upwards when the teacher is scrolling through the list of names of the teacher" );

            SMUtils.logDescriptionTC( "SMK- - TC028_Verify the column headers of the Assigned By popup should not get scrolled upwards when the teacher is scrolling through the list of names of the teacher" );

            SMUtils.logDescriptionTC( "TC036_Verify the OK button of the 'Assigned By' popup is appearing wihout the need of teacher scrolling down" );

            SMUtils.logDescriptionTC( "SMK-18794 - TC036_Verify the OK button of the 'Assigned By' popup is appearing wihout the need of teacher scrolling down" );

            Log.assertThat( coursePage.scrollTheVerticalScrollBar(), "UX related to scroll bar for View Assigned by popup is as expected", "UX related to scroll bar for View Assigned by popup is not as expected" );

            SMUtils.logDescriptionTC( "SMK-18793 - TC035_Verify the shadow effect for the ellipsis in the Courseware>Courses for the courses is as per the UX and is similar to the other screens" );
            coursePage.verifyTheHoveredColorOfEllipsis( browser );

            SMUtils.logDescriptionTC( "SMK- - TC035_Verify the shadow effect for the ellipsis in the Courseware>Courses for the courses is as per the UX and is similar to the other screens" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Executing Math Course", groups = { "SMK-43728_Test", "Courses", "Mastery" }, priority = 4 )
    public void attendCourseAsStudent() throws Exception {
    	// Get driver
    	EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    	EventListener eventListner = new EventListener();
    	chromeDriver.register(eventListner);
        try {

            String studentDetail = studentSMDetails;
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, "data,userName" );

            LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentUsername, password );

            //Page loading takes more time than expected. Hence providing the wait.
            SMUtils.nap( 30 );
            SMUtils.waitForSpinnertoDisapper( chromeDriver );

            StudentDashboardPage studentsPage = new StudentDashboardPage( chromeDriver );

            studentsPage.executeMathCourse( studentUsername, Constants.MATH, "100", "1", "20" );
            studentsPage.logout();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        } finally {
            chromeDriver.quit();
            Log.endTestCase();
        }
    }

    @Test ( description = "SMK-11243 : Verify whether the teacher is unable to view the hover effect for the Students List in the Assessed Objectives of the Mastery section", priority = 5, groups = { "SMK-43728", "mastery", "masteryStudentsFilter" } )
    public void verifyCourseware_037() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "SMK-11243 : Verify whether the teacher is unable to view the hover effect for the Students List in the Assessed Objectives of the Mastery section" + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Mastery Tab
            MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();

            // Get Mastery Filters Component
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            //Check the bg color of Leaf nodes before and after hover over
            Log.softAssertThat( masterySummaryComponent.isColorChangedOnhoverOverLeafNodeContent(), "There is no change in color on Hover Overing the LO content", "There is change in color on Hover Overing the LO content" );

            //Navigate to Mastery details page
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();

            SMUtils.logDescriptionTC( "SMK-11245 : Verify whether the teacher is unable to view the hover effect for the Students List in the Assessed Objectives of the Mastery section" );
            //Check the background color of students before and after hover over
            Log.softAssertThat( masteryDetailsPage.isColorChangedOnhoverOverStudentName(), "There is no change in color on Hover Overing the Students Name", "There is change in color on Hover Overing the Students Name" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-11244 : Verify whether the teacher is unable to view the hover effect for the Groups List in the Assessed Objectives of the Mastery section", priority = 5, groups = { "SMK-43728", "mastery", "masteryGroupsFilter" } )
    public void verifyCourseware_038() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "SMK-11244 : Verify whether the teacher is unable to view the hover effect for the Groups List in the Assessed Objectives of the Mastery section" + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Mastery Tab
            MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();

            // Get Mastery Filters Component
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.GROUPS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            //Check the bg color of Leaf nodes before and after hover over
            Log.softAssertThat( masterySummaryComponent.isColorChangedOnhoverOverLeafNodeContent(), "There is no change in color on Hover Overing the LO content", "There is change in color on Hover Overing the LO content" );

            //Navigate to Mastery details page
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();

            SMUtils.logDescriptionTC( "SMK-11246 : Verify whether the teacher is unable to view the hover effect for the Groups List in the Assessed Objectives of the Mastery section" );
            //Check the background color of students before and after hover over
            Log.softAssertThat( masteryDetailsPage.isColorChangedOnhoverOverStudentName(), "There is no change in color on Hover Overing the Students Name", "There is change in color on Hover Overing the Students Name" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}