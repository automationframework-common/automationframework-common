package com.savvas.sm.api.tests.smnew.students;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.smnew.users.CreateStudentAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.ReturnStudentListAPI;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentProgressGraphAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.StudentListUsingSolarConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

public class SearchStudentFromOrgUsingSolar extends UserAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;
    private String teacherDetails = null;
    private String teacherDetails2 = null;
    private String studentDetail4 = null;
    private String studentDetail1 = null;
    private String studentDetail2 = null;
    private String studentDetail3 = null;
    private String studentUserID3 = null;
    private String studentUserID4 = null;
    private String studentUserID2 = null;
    private String studentUsername1 = null;
    private String studentUsername2 = null;
    private String studentUsername3 = null;
    private String studentUsername4 = null;
    private String studentUsername5 = null;
    private String studentUserID1 = null;
    private String studentUserID5 = null;
    public Boolean result = null;
    int noOfIterationForMath = 1;
    int noOfIterationForReading = 1;
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String school1 = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public String accessToken;
    RBSUtils rbs = new RBSUtils();
    public String userId;
    public String userId1;
    public String userId2;
    public String orgId;
    public String orgId2;
    public String username;
    public String username2;
    public String mathOnlyProduct;
    public String readingOnlyProduct;
    public String classId;
    public String classId2;
    public String adminToken;
    public HashMap<String, String> assignmentDetails = new HashMap<>();
    public String createTeacher;
    public String multipleSchoolTeacherID;
    public String multipleSchoolTeacherName;
    public String multiOrgStuID;
    public String multiOrgStuUserName;
    public static List<String> orgIDs = new ArrayList<String>();
    HashMap<String, String> classDetails = new HashMap<String, String>();
    GroupAPI gUsage = new GroupAPI();
    List<String> stuIDs = new ArrayList<String>();

    @BeforeClass ( alwaysRun = true )
    public void BeforeSuite() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        mathOnlyProduct = configProperty.getProperty( "mathOnlyProduct" );
        readingOnlyProduct = configProperty.getProperty( "readingOnlyProduct" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherDetails2 = RBSDataSetup.getMyTeacher( school1 );
        userId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        userId2 = SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USERID_HEADER );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );
        username2 = SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USER_NAME );
        studentDetail1 = RBSDataSetup.getMyStudent( school, username );
        studentDetail2 = RBSDataSetup.getMyStudent( school, username );
        studentDetail4 = RBSDataSetup.getMyStudent( school, username );

        studentDetail3 = RBSDataSetup.getMyStudent( school1, username2 );
        studentUsername1 = SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USER_NAME );
        studentUserID1 = SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USERID_HEADER );
        studentUsername2 = SMUtils.getKeyValueFromResponse( studentDetail2, Constants.USER_NAME );
        studentUserID2 = SMUtils.getKeyValueFromResponse( studentDetail2, Constants.USERID_HEADER );

        studentUsername4 = SMUtils.getKeyValueFromResponse( studentDetail4, Constants.USER_NAME );
        studentUserID4 = SMUtils.getKeyValueFromResponse( studentDetail4, Constants.USERID_HEADER );

        studentUsername5 = SMUtils.getKeyValueFromResponse( studentDetail4, Constants.USER_NAME );
        studentUserID5 = SMUtils.getKeyValueFromResponse( studentDetail4, Constants.USERID_HEADER );

        // Org 2
        studentUsername3 = SMUtils.getKeyValueFromResponse( studentDetail3, Constants.USER_NAME );
        studentUserID3 = SMUtils.getKeyValueFromResponse( studentDetail3, Constants.USERID_HEADER );

        orgId = RBSDataSetup.organizationIDs.get( school );
        orgId2 = RBSDataSetup.organizationIDs.get( school1 );
        orgIDs.add( orgId );
        orgIDs.add( orgId2 );
        stuIDs.add( studentUserID1 );
        stuIDs.add( studentUserID2 );
        stuIDs.add( studentUserID3 );
        HashMap<String, String> userDetails = new HashMap<String, String>();
        HashMap<String, String> studentDetails = new HashMap<String, String>();
        List<String> schools = new ArrayList<String>();

        String multiSchoolTeacher = "MultiSchTeacher" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

        schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
        schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
        String listString = "";
        for ( String school : schools ) {
            listString += school.concat( "\",\"" );
        }
        listString = listString.substring( 0, listString.length() - 3 );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
        String createUser = rbs.createUser( userDetails );

        multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERID );
        multipleSchoolTeacherName = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERNAME );
        new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

        studentDetails = new CreateStudentAPITest().generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
        studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
        studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, multipleSchoolTeacherID );
        studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        HashMap<String, String> stuDetails = createStudent( smUrl, studentDetails );
        String responseBody = SMUtils.getKeyValueFromResponse( stuDetails.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA );
        multiOrgStuID = SMUtils.getKeyValueFromResponse( responseBody, Constants.PERSONID );
        multiOrgStuUserName = SMUtils.getKeyValueFromResponse( responseBody, RBSDataSetupConstants.USERNAME );
        rbs.updateUserOrgId( rbs.getUser( multiOrgStuID ), StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );

        String className = "Test Class" + System.nanoTime();
        classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, userId );
        classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
        classDetails.put( CreateGroupAPIConstants.GROUP_NAME, className );
        classId = SMUtils.getKeyValueFromResponse( gUsage.createGroup( smUrl, classDetails, stuIDs ).get( Constants.BODY ), "data,groupId" );

        String className1 = "Test Class" + System.nanoTime();
        classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, userId2 );
        classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId2 );
        classDetails.put( CreateGroupAPIConstants.GROUP_NAME, className1 );
        classId2 = SMUtils.getKeyValueFromResponse( gUsage.createGroup( smUrl, classDetails, stuIDs ).get( Constants.BODY ), "data,groupId" );
    }

    @Test ( priority = 1, dataProvider = "ValidCases", groups = { "SMK-56784", "smoke_test_case", "Solar_Search_TC01", "Group", "StudentSearchSolar", "P1", "API" } )
    public void tcStudentSearchUsingSolar001( String description, String scenario, String statusCode ) throws Exception {
        Log.message( description );
        //        HashMap<String, String> apiDetails = new HashMap<String, String>();
        //        HashMap<String, String> userDetails = new HashMap<String, String>();
        //        Map<String, String> responseBody;
        JSONObject jobj;
        JSONArray jsonArray;
        String userName;

        switch ( scenario ) {

            case "STUDENTS_WHOLE_ORG":
                Log.testCaseInfo( "Verify the teacher can see the students with firstname,lastname,middlename,username,userId, grade." );
                Log.testCaseInfo( "Verify the teacher can able to see newly created student in response." );
                Log.testCaseInfo( "Verify the teacher can able to see the students which is already there in group when the group ID is null" );
                Log.testCaseInfo( "Verify the teacher can able to see the total fetched student count in reponse as totalRecords." );
                Log.testCaseInfo( "Verify the teacher can able to see all the students from all the grades when the grade is empty." );

                HashMap<String, String> apiDetailsWholeOrg = new HashMap<String, String>();

                //                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetailsWholeOrg.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetailsWholeOrg.put( UserConstants.USERID, userId );
                apiDetailsWholeOrg.put( UserConstants.ORGID, orgId );
 //               boolean compareTotalRecordsSameWithNoOfRecordsListed = compareTotalRecordsSameWithNoOfRecordsListed( smUrl, apiDetailsWholeOrg, orgId );
                boolean compareTotalRecordsSameWithNoOfRecordsListed = verifyThereIsStudentInTheResponse( smUrl, apiDetailsWholeOrg, orgId,studentUserID1 );
                Log.assertThat( compareTotalRecordsSameWithNoOfRecordsListed, "Student is available in the Response", "Error : Student is not available in the Response" );
                break;

            case "STUDENTS_EXCEPT_GIVEN_GROUP":
                Log.testCaseInfo( "Verify the teacher can able to see the students who is not part of the group from whole organization." );

                HashMap<String, String> apiDetailsGivenGroup = new HashMap<String, String>();
                HashMap<String, String> userDetailsGivenGroup = new HashMap<String, String>();

                //            	accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetailsGivenGroup.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetailsGivenGroup.put( UserConstants.USERID, userId );
                apiDetailsGivenGroup.put( UserConstants.ORGID, orgId );
                userDetailsGivenGroup.put( Constants.ORGANIZATION_ID, orgId );
                userDetailsGivenGroup.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetailsGivenGroup.put( StudentListUsingSolarConstants.SEARCH_STRING, studentUsername4 );
                userDetailsGivenGroup.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                userDetailsGivenGroup.put( "groupId", "\"" + classId + "\"" );
                Map<String, String> responseBodyGivenGroup = studentSearchUsingSolar( smUrl, apiDetailsGivenGroup, userDetailsGivenGroup );
                Log.assertThat( !verifyThereIsNoStudentInTheResponse( responseBodyGivenGroup ), "Student Not part of the given gorup listed", "Error: Student Part of the Group present in the response" );
                userDetailsGivenGroup.put( Constants.ORGANIZATION_ID, orgId );
                userDetailsGivenGroup.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetailsGivenGroup.put( StudentListUsingSolarConstants.SEARCH_STRING, studentUsername2 );
                userDetailsGivenGroup.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                userDetailsGivenGroup.put( "groupId", "\"" + classId + "\"" );
                responseBodyGivenGroup = studentSearchUsingSolar( smUrl, apiDetailsGivenGroup, userDetailsGivenGroup );
                Log.assertThat( verifyThereIsNoStudentInTheResponse( responseBodyGivenGroup ), "Student part of the given gorup not listed in the response", "Error: Student Part of the Group present in the response" );
                break;

            case "STUDENTS_FROM_WHOLE_ORG_FOR_GIVEN_GRADE":

                HashMap<String, String> apiDetailsGivenGrade = new HashMap<String, String>();
                int grade = 5;
                //                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetailsGivenGrade.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetailsGivenGrade.put( UserConstants.USERID, userId );
                apiDetailsGivenGrade.put( UserConstants.ORGID, orgId );
                Log.assertThat( verifyStudentReturnOnlyforGivenGrade( orgId, apiDetailsGivenGrade, grade ), "Student Returned according to the given grade", "Error : Student returned other than given grade" );
                break;

            case "STUDENTS_FROM_WHOLE_ORG_FOR_GIVEN_NAME":

                Log.testCaseInfo( "Verify the Search results should display if the search string matches anywhere in the name" );
                Log.testCaseInfo( "Verify the teacher can able to see the orphan student(not part of any group) in reponse" );

                HashMap<String, String> apiDetailsGivenName = new HashMap<String, String>();
                HashMap<String, String> userDetailsGivenname = new HashMap<String, String>();

                //                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetailsGivenName.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetailsGivenName.put( UserConstants.USERID, userId );
                apiDetailsGivenName.put( UserConstants.ORGID, orgId );
                userDetailsGivenname.put( Constants.ORGANIZATION_ID, orgId );
                userDetailsGivenname.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetailsGivenname.put( StudentListUsingSolarConstants.SEARCH_STRING, studentUsername1 );
                Log.message( "Student UserName is ---> " + studentUsername1 );
                userDetailsGivenname.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetailsGivenname.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                Map<String, String> responseBodyGivenName = studentSearchUsingSolar( smUrl, apiDetailsGivenName, userDetailsGivenname );
                jobj = new JSONObject( responseBodyGivenName.get( Constants.RESPONSE_BODY ) );
                jsonArray = jobj.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST );
                userName = jobj.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST ).getJSONObject( 0 ).get( StudentListUsingSolarConstants.USERNAME ).toString();
                int length = jsonArray.length();
                Log.message("Student reposne Length: " +length);
                Log.assertThat( userName.equalsIgnoreCase( studentUsername1 ), "Fetched Student For givenName", "Error: Duplicates Students Present" );
                Log.testCaseResult();
                break;

            // Validate Whether Multi Org Teacher able to see students from both org where teacher part of
            case "TEACHER_FROM_MULTIPLE_SCHOOL":

                HashMap<String, String> apiDetailsMutliSch = new HashMap<String, String>();

                apiDetailsMutliSch.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetailsMutliSch.put( UserConstants.USERID, multipleSchoolTeacherID );
                apiDetailsMutliSch.put( UserConstants.ORGID, orgId );
//                Log.assertThat( compareTotalRecordsSameWithNoOfRecordsListed( smUrl, apiDetailsMutliSch, orgId ), "Total Records Matched with the actual Student List for same teacher and org 1", "Error : Total Records Not Matched with the student list" );
                Log.assertThat( verifyThereIsStudentInTheResponse( smUrl, apiDetailsMutliSch, orgId,studentUserID1 ), "Student is available in the Response of org 1", "Error : Student is not available in the Response of org 1" );
                apiDetailsMutliSch.put( UserConstants.ORGID, orgId2 );
//                Log.assertThat( compareTotalRecordsSameWithNoOfRecordsListed( smUrl, apiDetailsMutliSch, orgId2 ), "Total Records Matched with the actual Student List for same teacher and org 2", "Error : Total Records Not Matched with the student list" );
                Log.assertThat( verifyThereIsStudentInTheResponse( smUrl, apiDetailsMutliSch, orgId2,studentUserID3 ), "Student is available in the Response of org 2", "Error : Student is not available in the Response of org 2" );
                break;

            case "STUDENT_WITH_NOTSPECIFIED_GRADE":
                int notSpecifiedgrade = -10;

                HashMap<String, String> apiDetailsNotSpecGrade = new HashMap<String, String>();

                apiDetailsNotSpecGrade.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetailsNotSpecGrade.put( UserConstants.USERID, userId );
                apiDetailsNotSpecGrade.put( UserConstants.ORGID, orgId );
                Log.assertThat( verifyStudentReturnOnlyforGivenGrade( orgId, apiDetailsNotSpecGrade, notSpecifiedgrade ), "Student with Not specified grade alone returned", "Error : Student returned other than given grade" );
                break;

            // Org Should Contain more than 250 Students to test this scenario
            case "SINGLE_PAGE_RECORDS":

                HashMap<String, String> apiDetailsPagerecords = new HashMap<String, String>();
                HashMap<String, String> userDetailsPagerecords = new HashMap<String, String>();

                //                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetailsPagerecords.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetailsPagerecords.put( UserConstants.USERID, userId );
                apiDetailsPagerecords.put( UserConstants.ORGID, orgId );
                userDetailsPagerecords.put( Constants.ORGANIZATION_ID, orgId );
                userDetailsPagerecords.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetailsPagerecords.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
                userDetailsPagerecords.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetailsPagerecords.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                Map<String, String> responseBodyPageRecords = studentSearchUsingSolar( smUrl, apiDetailsPagerecords, userDetailsPagerecords );
                jobj = new JSONObject( responseBodyPageRecords.get( Constants.RESPONSE_BODY ) );
                JSONArray jsonArray1 = jobj.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST );
                Log.assertThat( jsonArray1.length() == StudentListUsingSolarConstants.OFFSET_VALUE, "Single Page Contains 250 Records as expected", "Single Page Not contains 250 records" );
                break;

            case "GROUP_NOT_PART_OF_ORG":
                int sumOfStudentListbeforeClassId = 0;
                int sumOfStudentListafterClassId = 0;
                Map<String, String> responseBodyNotPartOrg;

                HashMap<String, String> apiDetailsNotPartOrg = new HashMap<String, String>();
                HashMap<String, String> userDetailsNotPartOrg = new HashMap<String, String>();

                //                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetailsNotPartOrg.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetailsNotPartOrg.put( UserConstants.USERID, userId2 );
                apiDetailsNotPartOrg.put( UserConstants.ORGID, orgId2 );
                for ( int offset = 0; offset < 100; offset++ ) {
                    userDetailsNotPartOrg.put( Constants.ORGANIZATION_ID, orgId2 );
                    userDetailsNotPartOrg.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                    userDetailsNotPartOrg.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
                    userDetailsNotPartOrg.put( StudentListUsingSolarConstants.GROUP_ID, "\"" + classId2 + "\"" );
                    userDetailsNotPartOrg.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                    String offSetValue = Integer.toString( offset );
                    userDetailsNotPartOrg.put( StudentListUsingSolarConstants.OFFSET, offSetValue );
                    responseBodyNotPartOrg = studentSearchUsingSolar( smUrl, apiDetailsNotPartOrg, userDetailsNotPartOrg );
                    JSONObject jobj1 = new JSONObject( responseBodyNotPartOrg.get( Constants.REPORT_BODY ) );
                    JSONArray jsonArr = new JSONArray();
                    jsonArr = jobj1.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST );
                    int lengthOfList = jsonArr.length();
                    if ( lengthOfList == 0 ) {
                        break;
                    } else {
                        sumOfStudentListafterClassId += lengthOfList;
                    }
                }
                for ( int offset = 0; offset < 100; offset++ ) {
                    userDetailsNotPartOrg.put( Constants.ORGANIZATION_ID, orgId2 );
                    userDetailsNotPartOrg.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                    userDetailsNotPartOrg.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
                    userDetailsNotPartOrg.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                    userDetailsNotPartOrg.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                    String offSetValue = Integer.toString( offset );
                    userDetailsNotPartOrg.put( StudentListUsingSolarConstants.OFFSET, offSetValue );
                    responseBodyNotPartOrg = studentSearchUsingSolar( smUrl, apiDetailsNotPartOrg, userDetailsNotPartOrg );
                    JSONObject jobj1 = new JSONObject( responseBodyNotPartOrg.get( Constants.REPORT_BODY ) );
                    JSONArray jsonArr = new JSONArray();
                    jsonArr = jobj1.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST );
                    int lengthOfList = jsonArr.length();
                    if ( lengthOfList == 0 ) {
                        break;
                    } else {
                        sumOfStudentListbeforeClassId += lengthOfList;
                    }
                }
                Log.assertThat( sumOfStudentListbeforeClassId != sumOfStudentListafterClassId, "Response Showing the Students not part of the group as expected", "Error :Same Class Students listed again" );
                break;

            case "MATCHED_PARTIALLY":

                HashMap<String, String> apiDetailsPartial = new HashMap<String, String>();
                HashMap<String, String> userDetailsPartial = new HashMap<String, String>();

                //                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetailsPartial.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetailsPartial.put( UserConstants.USERID, userId );
                apiDetailsPartial.put( UserConstants.ORGID, orgId );
                userDetailsPartial.put( Constants.ORGANIZATION_ID, orgId );
                userDetailsPartial.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetailsPartial.put( StudentListUsingSolarConstants.SEARCH_STRING, studentUsername1 + "axs" );
                userDetailsPartial.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetailsPartial.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                Map<String, String> responseBodyPartial = studentSearchUsingSolar( smUrl, apiDetailsPartial, userDetailsPartial );
                Log.assertThat( verifyThereIsNoStudentInTheResponse( responseBodyPartial ), "Student not matched for partially correct username", "Error: Student listed for partially correct username" );
                break;

            // To Verify whether the MultiOrg Student Present in all the Org student part of
            case "MULTI_ORG_STUDENT":

                HashMap<String, String> apiDetailsMultiOrgS = new HashMap<String, String>();
                HashMap<String, String> userDetailsMultiOrgS = new HashMap<String, String>();

                String accessToken1 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetailsMultiOrgS.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                apiDetailsMultiOrgS.put( UserConstants.USERID, userId );
                apiDetailsMultiOrgS.put( UserConstants.ORGID, orgId );
                userDetailsMultiOrgS.put( Constants.ORGANIZATION_ID, orgId );
                userDetailsMultiOrgS.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetailsMultiOrgS.put( StudentListUsingSolarConstants.SEARCH_STRING, multiOrgStuUserName );
                userDetailsMultiOrgS.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetailsMultiOrgS.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                Map<String, String> responseBodyMultiOrgS = studentSearchUsingSolar( smUrl, apiDetailsMultiOrgS, userDetailsMultiOrgS );
                while ( responseBodyMultiOrgS.containsKey( "username" ) ) {
                    jobj = new JSONObject( responseBodyMultiOrgS.get( Constants.RESPONSE_BODY ) );
                    jsonArray = jobj.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST );
                    userName = jobj.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST ).getJSONObject( 0 ).get( StudentListUsingSolarConstants.USERNAME ).toString();
                    Log.assertThat( userName.equals( multiOrgStuUserName ) && jsonArray.length() == 1, "Multi Org Student listed properly in Org 1", "Error: Multi Org Student not present in Org 1" );
                }

                // Checking Same Student present in other organization
                Map<String, String> responseBody1;
                String accessToken2 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetailsMultiOrgS.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken2 );
                apiDetailsMultiOrgS.put( UserConstants.USERID, userId2 );
                apiDetailsMultiOrgS.put( UserConstants.ORGID, orgId2 );
                userDetailsMultiOrgS.put( Constants.ORGANIZATION_ID, orgId2 );
                userDetailsMultiOrgS.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetailsMultiOrgS.put( StudentListUsingSolarConstants.SEARCH_STRING, multiOrgStuUserName );
                userDetailsMultiOrgS.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetailsMultiOrgS.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                responseBody1 = studentSearchUsingSolar( smUrl, apiDetailsMultiOrgS, userDetailsMultiOrgS );
                while ( responseBody1.containsKey( "username" ) ) {
                    jobj = new JSONObject( responseBody1.get( Constants.RESPONSE_BODY ) );
                    jsonArray = jobj.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST );
                    userName = jobj.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST ).getJSONObject( 0 ).get( StudentListUsingSolarConstants.USERNAME ).toString();
                    Log.assertThat( userName.equals( multiOrgStuUserName ) && jsonArray.length() == 1, "Multi Org Student listed properly in Org 2", "Error: Multi Org Student not present in Org 2" );

                }
                break;
        }
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "ValidCases" )
    public Object[][] tcStudentSolarSearch() {

        Object[][] data = { { "Verify the teacher can able to see the student from whole school.", "STUDENTS_WHOLE_ORG", "200" },
                //                { "Verify the teacher can see the students with firstname,lastname,middlename,username,userId, grade.", "STUDENTS_WHOLE_ORG", "200" }, 
                //                { "Verify the teacher can able to see newly created student in response.", "STUDENTS_WHOLE_ORG", "200" },
                //                { "Verify the teacher can able to see the students which is already there in group when the group ID is null", "STUDENTS_WHOLE_ORG", "200" },
                //                { "Verify the teacher can able to see the total fetched student count in reponse as totalRecords.", "STUDENTS_WHOLE_ORG", "200" },
                //                { "Verify the teacher can able to see all the students from all the grades when the grade is empty.", "STUDENTS_WHOLE_ORG", "200" },
                { "Verify the teacher can able to see the student from whole org except the group students.", "STUDENTS_EXCEPT_GIVEN_GROUP", "200" },
                //                { "Verify the teacher can able to see the students who is not part of the group from whole organization.", "STUDENTS_EXCEPT_GIVEN_GROUP", "200" },
                { "Verify the teacher can able to see the student from whole org for given grade.", "STUDENTS_FROM_WHOLE_ORG_FOR_GIVEN_GRADE", "200" },
                { "Verify the response body should return this week field", "STUDENTS_FROM_WHOLE_ORG_FOR_GIVEN_NAME", "200" },
                //                { "Verify the Serach results should display if the search string matches anywhere in the name", "STUDENTS_FROM_WHOLE_ORG_FOR_GIVEN_NAME", "200" },
                //                { "Verify the teacher can able to see the orphan student(not part of any group) in reponse", "STUDENTS_FROM_WHOLE_ORG_FOR_GIVEN_NAME", "200" },
                { "Verify the teacher can see the students from multiple school when the teacher part of multiple school.", "TEACHER_FROM_MULTIPLE_SCHOOL", "200" },
                { "Verify the teacher can able to see the students from both the school when the student part of both the school.", "MULTI_ORG_STUDENT", "200" },
                { " Verify the teacher can able to see the students with not specified grade.", "STUDENT_WITH_NOTSPECIFIED_GRADE", "200" }, { "Verify the response returning 250 records in single page response ", "SINGLE_PAGE_RECORDS", "200" },
                { "Verify the teacher can able to see the students from whole org when the group id not part of given org", "GROUP_NOT_PART_OF_ORG", "200" },
                { "Verify Search results should not display if it matches partially (E.g:If name is Garden searching with Gar1 shouldn't return any result)", "MATCHED_PARTIALLY", "200" }, };
        return data;
    }

    @Test ( priority = 1, dataProvider = "InValidCases", groups = { "SMK-56784", "Group", "StudentSearchSolar", "P1", "API" } )
    public void tcStudentSearchUsingSolar002( String description, String scenario, String statusCode ) throws Exception {
        Log.message( description );
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> apiDetails = new HashMap<String, String>();
        HashMap<String, String> userDetails = new HashMap<String, String>();
        HashMap<String, String> response;
        String errorMessage = null;
        String exceptionMessage = null;
        Map<String, String> responseBody;
        switch ( scenario ) {

            // Deleted Student Should not shown in the response
            case "DELETED_STUDENT":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                List<String> toDelete = new ArrayList<>();
                toDelete.add( studentUserID5 );
                rbs.deleteUser( toDelete );
                // After Deleting the Student due to Solar indexing requires 3 minutes to reflect the change Bug No : https://jira.savvasdev.com/browse/SMK-58807
                Thread.sleep( 3 * 60000 );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( UserConstants.USERID, userId );
                apiDetails.put( UserConstants.ORGID, orgId );
                userDetails.put( Constants.ORGANIZATION_ID, orgId );
                userDetails.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.SEARCH_STRING, studentUsername5 );
                userDetails.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                responseBody = studentSearchUsingSolar( smUrl, apiDetails, userDetails );
                Log.assertThat( verifyThereIsNoStudentInTheResponse( responseBody ), "Deleted Student Not Shown in the Response as Expected", "Error : Deleted Student Shown in the Response" );
                break;

            // This case works when there is no student for given grade in the Organization
            case "NO_STUDENT_FOR_GIVEN_GRADE":
                String grade = "7";
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( UserConstants.USERID, userId );
                apiDetails.put( UserConstants.ORGID, orgId );
                userDetails.put( Constants.ORGANIZATION_ID, orgId );
                userDetails.put( StudentListUsingSolarConstants.GRADE_ID, grade );
                userDetails.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
                userDetails.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                responseBody = studentSearchUsingSolar( smUrl, apiDetails, userDetails );
                Log.assertThat( verifyThereIsNoStudentInTheResponse( responseBody ), "Given Grade student is not present in the Organization", "Expected : Given Grade student should not present to check  Actual : Specified Grade student is present" );
                break;

            case "NO_STUDENT_FOR_GIVEN_NAME":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( UserConstants.USERID, userId );
                apiDetails.put( UserConstants.ORGID, orgId );
                userDetails.put( Constants.ORGANIZATION_ID, orgId );
                userDetails.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.SEARCH_STRING, "zq123" );
                userDetails.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                responseBody = studentSearchUsingSolar( smUrl, apiDetails, userDetails );
                Log.assertThat( verifyThereIsNoStudentInTheResponse( responseBody ), "Given Name student is not present in the Organization", "Error : Deleted Student Shown in the Response" );
                break;

            case "INVALID_ORG_ID":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = ReturnStudentListAPI.ACCESS_DENIED_MESSAGE;
                exceptionMessage = ReturnStudentListAPI.ACCESS_DENIED_EXCEPTION;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( UserConstants.USERID, userId );
                apiDetails.put( UserConstants.ORGID, orgId + "$%" );
                userDetails.put( Constants.ORGANIZATION_ID, orgId );
                userDetails.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
                userDetails.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                responseBody = studentSearchUsingSolar( smUrl, apiDetails, userDetails );
                Log.assertThat( validateErrorANDExceptionMessage( responseBody, errorMessage, exceptionMessage, statusCode ), "Proper Exception thrown for Invalid Org Id", "Error : Proper Exception not thrown for invalid org id" );
                break;

            case "INVALID_GRADE_ID":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( UserConstants.USERID, userId );
                apiDetails.put( UserConstants.ORGID, orgId );
                userDetails.put( Constants.ORGANIZATION_ID, orgId );
                userDetails.put( StudentListUsingSolarConstants.GRADE_ID, "78" );
                userDetails.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
                userDetails.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                responseBody = studentSearchUsingSolar( smUrl, apiDetails, userDetails );
                Log.assertThat( verifyThereIsNoStudentInTheResponse( responseBody ), "There is no student for invalid Grade id", "Error : Students returned for invalid grade id" );
                break;

            case "INVALID_AUTH":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = ReturnStudentListAPI.AUTHENTICATION_FAILED_MESSAGE;
                exceptionMessage = ReturnStudentListAPI.EXCEPTION_MESSAGE;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken + 23 );
                apiDetails.put( UserConstants.USERID, userId );
                apiDetails.put( UserConstants.ORGID, orgId );
                userDetails.put( Constants.ORGANIZATION_ID, orgId );
                userDetails.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
                userDetails.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                responseBody = studentSearchUsingSolar( smUrl, apiDetails, userDetails );
                Log.assertThat( validateErrorANDExceptionMessage( responseBody, errorMessage, exceptionMessage, statusCode ), "Proper Error Message Thrown for Invalid Authentication", "Error : Proper Error Message not thrown for invalid auth" );
                break;

            case "STUDENT_AUTHORIZATION":
                accessToken = rbs.getAccessToken( studentUsername2, RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = ReturnStudentListAPI.ACCESS_DENIED_MESSAGE;
                exceptionMessage = ReturnStudentListAPI.ACCESS_DENIED_EXCEPTION;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( UserConstants.USERID, studentUserID2 );
                apiDetails.put( UserConstants.ORGID, orgId );
                userDetails.put( Constants.ORGANIZATION_ID, orgId );
                userDetails.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
                userDetails.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                responseBody = studentSearchUsingSolar( smUrl, apiDetails, userDetails );
                Log.assertThat( validateErrorANDExceptionMessage( responseBody, errorMessage, exceptionMessage, statusCode ), "Teacher Not able to see students using student Auth",
                        "Error : Teacher can be able to see the Result using Student Authorization" );
                break;

            case "HEADER_BODY_ORG_ID_MISMATCH":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = StudentListUsingSolarConstants.INVALID_ORGID_TEXT;
                exceptionMessage = ReturnStudentListAPI.BUSINESS_RULE_EXCEPTION;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( UserConstants.USERID, userId );
                apiDetails.put( UserConstants.ORGID, orgId );
                userDetails.put( Constants.ORGANIZATION_ID, orgId2 );
                userDetails.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
                userDetails.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
                userDetails.put( StudentListUsingSolarConstants.OFFSET, StudentListUsingSolarConstants.ZERO_VALUE );
                responseBody = studentSearchUsingSolar( smUrl, apiDetails, userDetails );
                Log.assertThat( validateErrorANDExceptionMessage( responseBody, errorMessage, exceptionMessage, statusCode ), "Proper Exception thrown for Invalid Org Id", "Error : Proper Exception not thrown for invalid org id" );
                break;

        }

    }

    /**
     * Data provider for Negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "InValidCases" )
    public Object[][] tcGroupsUsagegraph() {

        Object[][] data = { { "Verify the teacher can not see the students when the student is deleted. https://jira.savvasdev.com/browse/SMK-58807", "DELETED_STUDENT", "200" },
                // This test case is commented due to all grades students were availabe 

                /*
                 * {
                 * "Verify the teacher can able to see the zero state when there is no students in given grade."
                 * , "NO_STUDENT_FOR_GIVEN_GRADE", "200" },
                 */

                { "Verify the teacher can able to see zero state message when the organization does not have students name with given search string.", "NO_STUDENT_FOR_GIVEN_NAME", "200" },
                { "Verify the response should return exception when the organization ID is invalid", "INVALID_ORG_ID", "403" }, { "Verify the response should return exception when the grade ID is invalid", "INVALID_GRADE_ID", "200" },
                { "Verify the response should return exception when the authorization is wrong", "INVALID_AUTH", "401" }, { "Verify the response should return exception when the authorization is student authorization.", "STUDENT_AUTHORIZATION", "403" },
                { "Verify the response should return exception when the header orgID and body org ID is different", "HEADER_BODY_ORG_ID_MISMATCH", "400" } };
        return data;
    }

    // Validating the Error Message and Exception
    public Boolean validateErrorANDExceptionMessage( Map<String, String> response, String errorMessage, String exceptionMessage, String statusCode ) {
        Boolean status = false;
        JSONObject jsonObject = new JSONObject( response.get( Constants.REPORT_BODY ) );
        JSONArray array4 = jsonObject.getJSONArray( Constants.REPORT_MESSAGES );
        String exception = array4.getJSONObject( 0 ).get( Constants.EXCEPTION ).toString();
        String message = array4.getJSONObject( 0 ).get( Constants.REPORT_MESSAGE_VALUE ).toString();
        if ( exception.equals( exceptionMessage ) && message.contains( errorMessage ) && response.get( Constants.STATUS_CODE ).equals( statusCode ) ) {
            status = true;
        }
        return status;
    }
/*
    // To Compare the Total records value and count of actual student count in the response
    public boolean compareTotalRecordsSameWithNoOfRecordsListed( String smUrl, HashMap<String, String> apiDetails, String orgId ) throws Exception {
        boolean status = false;
        int sumOfStudentList = 0;
        JSONObject jobj = new JSONObject();
        for ( int offset = 0; offset < 100; offset++ ) {
            HashMap<String, String> userDetail = new HashMap<>();
            userDetail.put( Constants.ORGANIZATION_ID, orgId );
            userDetail.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
            userDetail.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
            userDetail.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
            Map<String, String> responseBody = new HashMap<>();
            String offSetValue = Integer.toString( offset );
            userDetail.put( StudentListUsingSolarConstants.OFFSET, offSetValue );
            responseBody = studentSearchUsingSolar( smUrl, apiDetails, userDetail );
            Log.message( "HashMap" + userDetail.toString() );
            JSONObject jobj1 = new JSONObject( responseBody.get( Constants.REPORT_BODY ) );
            jobj = jobj1;
            JSONArray jsonArray = new JSONArray();
            jsonArray = jobj1.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST );
            int lengthOfList = jsonArray.length();
            if ( lengthOfList == 0 ) {
                break;
            } else {
                sumOfStudentList += lengthOfList;
            }
        }
        int totalRecords = jobj.getJSONObject( Constants.DATA ).getInt( StudentListUsingSolarConstants.TOTAL_RECORDS );
        if ( totalRecords == sumOfStudentList ) {
            status = true;
            Log.message( "Total records Matches with the No of Students Listed" );
        } else {
            Log.fail( "Total record List not matches with the total students listed in the response, Expected: " + totalRecords + ", Actual : " + sumOfStudentList + " " );
        }
        return status;
    }
    */
    
    // To Verify that there is no student present in the given response
    public boolean verifyThereIsNoStudentInTheResponse( Map<String, String> responseBody ) {

        boolean status = false;
        JSONObject jobj = new JSONObject( responseBody.get( Constants.REPORT_BODY ) );
        JSONArray jsonArray = jobj.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST );
        int lengthOfList = jsonArray.length();
        if ( lengthOfList == 0 ) {
            status = true;
            Log.message( "There is No Student in the Response as expected" );
        }
        return status;
    }
    
    // To Compare the Total records value and count of actual student count in the response
    /**
     *  To  verify that the student is available in that response 
     * @param smUrl
     * @param apiDetails
     * @param orgId
     * @param studentId
     * @return
     * @throws Exception
     */
    public boolean verifyThereIsStudentInTheResponse( String smUrl, HashMap<String, String> apiDetails, String orgId ,String studentId) throws Exception {
        boolean status = false;
        JSONObject jobj = new JSONObject();
        String response="";
        Log.message( "Student ID : " +studentId );
        for ( int offset = 0; offset < 100; offset++ ) {
            HashMap<String, String> userDetail = new HashMap<>();
            userDetail.put( Constants.ORGANIZATION_ID, orgId );
            userDetail.put( StudentListUsingSolarConstants.GRADE_ID, StudentListUsingSolarConstants.NULL );
            userDetail.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
            userDetail.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
            Map<String, String> responseBody = new HashMap<>();
            String offSetValue = Integer.toString( offset );
            userDetail.put( StudentListUsingSolarConstants.OFFSET, offSetValue );
            responseBody = studentSearchUsingSolar( smUrl, apiDetails, userDetail );
            Log.message( "HashMap" + userDetail.toString() );
            
            if(responseBody.get( Constants.REPORT_BODY ).contains( studentId ) ) {
                status = true;
                break;
            }
        }
        return status;
    }

    // To Verify Student returned for given grade
    public boolean verifyStudentReturnOnlyforGivenGrade( String orgId, HashMap<String, String> apiDetails, int gradeId ) throws Exception {
        boolean status = false;
        JSONObject jobj = null;
        HashMap<String, String> userDetail = new HashMap<>();
        for ( int offset = 0; offset < 100; offset++ ) {
            userDetail.put( Constants.ORGANIZATION_ID, orgId );
            userDetail.put( StudentListUsingSolarConstants.GRADE_ID, "" + gradeId + "" );
            userDetail.put( StudentListUsingSolarConstants.SEARCH_STRING, "" );
            userDetail.put( StudentListUsingSolarConstants.GROUP_ID, StudentListUsingSolarConstants.NULL );
            Map<String, String> responseBody;
            String offSetValue = Integer.toString( offset );
            userDetail.put( StudentListUsingSolarConstants.OFFSET, offSetValue );
            responseBody = studentSearchUsingSolar( smUrl, apiDetails, userDetail );
            jobj = new JSONObject( responseBody.get( Constants.REPORT_BODY ) );
            JSONArray jsonArray = jobj.getJSONObject( Constants.DATA ).getJSONArray( StudentListUsingSolarConstants.USER_LIST );
            int lengthOfList = jsonArray.length();
            if ( lengthOfList == 0 ) {
                Log.message( "Empty List from the response" );
                break;
            } else {
                for ( Object object : jsonArray ) {

                    JSONObject obj = (JSONObject) object;
                    // JSONObject object1 = new JSONObject( object );
                    String grade = obj.getJSONObject( StudentListUsingSolarConstants.GRADE ).get( StudentListUsingSolarConstants.GRADE_ID ).toString();
                    int gradeIdFromResponse = Integer.parseInt( grade );
                    if ( gradeIdFromResponse != gradeId ) {
                        Log.fail( "Error: Other than given grade id present in the response" );
                        break;
                    } else {
                        status = true;
                    }
                }
            }

        }
        return status;
    }

}