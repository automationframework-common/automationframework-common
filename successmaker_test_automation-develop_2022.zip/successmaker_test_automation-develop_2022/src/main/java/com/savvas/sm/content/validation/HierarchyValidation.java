package com.savvas.sm.content.validation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.w3c.dom.Document;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.opencsv.CSVReader;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;

/**
 * This class used to execute the query and functions in database.
 * 
 * @author manikanda.nagendran
 *
 */
public class HierarchyValidation extends BaseTest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    public String testDatabasePath;
    public static String csvBasePath;
    public static String queriesBasePath;

    @BeforeTest
    public void unZIP() throws IOException {
        testDatabasePath = new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator;
        String targetZipFilePath = testDatabasePath + "hierarchyValidation.zip";
        csvBasePath = testDatabasePath + "hierarchyValidation" + File.separator;
        queriesBasePath = new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator + "DBQueries" + File.separator;
        Path target = Paths.get( csvBasePath );

        try (ZipInputStream zis = new ZipInputStream( new FileInputStream( targetZipFilePath ) )) {

            // list files in zip
            ZipEntry zipEntry = zis.getNextEntry();

            while ( zipEntry != null ) {

                boolean isDirectory = false;

                if ( zipEntry.getName().endsWith( File.separator ) ) {
                    isDirectory = true;
                }

                Path newPath = zipSlipProtect( zipEntry, target );

                if ( isDirectory ) {
                    Files.createDirectories( newPath );
                } else {

                    if ( newPath.getParent() != null ) {
                        if ( Files.notExists( newPath.getParent() ) ) {
                            Files.createDirectories( newPath.getParent() );
                        }
                    }

                    // copy files, nio
                    Files.copy( zis, newPath, StandardCopyOption.REPLACE_EXISTING );

                }

                zipEntry = zis.getNextEntry();

            }
            zis.closeEntry();

        }

    }

    public static Path zipSlipProtect( ZipEntry zipEntry, Path targetDir ) throws IOException {
        Path targetDirResolved = targetDir.resolve( zipEntry.getName() );

        Path normalizePath = targetDirResolved.normalize();
        if ( !normalizePath.startsWith( targetDir ) ) {
            throw new IOException( "Bad zip entry: " + zipEntry.getName() );
        }

        return normalizePath;
    }

    @SuppressWarnings ( "unchecked" )
    @Test ( description = "Verify Alfresco data's are matched with SMDB for MATH", priority = 1 )
    public void TcMathHierarcy001() throws Exception {

        try {
            Log.testCaseInfo( "Verify Alfresco data's are matched with SMDB for MATH" );

            Boolean status = true;
            Log.message( queriesBasePath + "getMathHierarchy.sql" );
            FileReader fr = new FileReader( queriesBasePath + "getMathHierarchy.sql" );

            BufferedReader br = new BufferedReader( fr );

            StringBuilder sb = new StringBuilder();
            String sqlLine;
            while ( ( sqlLine = br.readLine() ) != null ) {
                sb.append( sqlLine );
            }
            br.close();

            String query = sb.toString();
            Log.message( "query: " + query );
            List<Object[]> records = SQLUtil.executeQuery( query );

            List<String> SMDBarrList = new ArrayList<String>();
            for ( Object[] list : records ) {
                if ( list.length > 0 ) {
                    SMDBarrList.add( list[0].toString() );
                }
            }

            Log.message( "Fetching data from CSV" );
            String configFilePath = csvBasePath + configProperty.getProperty( "mathHierarchyCSV" );
            List<String> mathHierarchy = SMUtils.generateMathHierarchy( "MathConceptsHierarchyBulkUpload" );
            Collections.sort( mathHierarchy );
            Log.message( "Fetching data from CSV is completed" );

            String basePath = new File( "." ).getCanonicalPath() + File.separator + "test-output" + File.separator + "HierarchyValidation" + File.separator; // + "Math" + File.separator;
            File dir = new File( basePath );
            dir.mkdir();
            String csvFilePath = basePath + "MismatchedHierarcy_MathData.csv";

            FileWriter csvWriter = new FileWriter( csvFilePath );
            csvWriter.append( "LO" + "," );
            csvWriter.append( "Result" + "," );
            csvWriter.append( "Details" + "," );
            csvWriter.append( "\n" );

            Log.message( "Writing mismatched data into CSV is started" );
            for ( int i = 0; i < mathHierarchy.size(); i++ ) {
                String[] csvsplitLO = mathHierarchy.get( i ).split( "\\|", 0 );
                String[] csvhierarchySplitter = csvsplitLO[1].split( " >> " );

                String errMsg = "";
                Boolean LOAvailable = false;
                for ( int j = 0; j < SMDBarrList.size(); j++ ) {

                    Boolean mismatch = false;
                    String[] dbsplitLO = SMDBarrList.get( j ).split( "\\|", 0 );
                    String[] dbhierarchySplitter = dbsplitLO[1].split( " >> " );
                    if ( csvsplitLO[0].equals( dbsplitLO[0] ) ) {
                        LOAvailable = true;
                        if ( !( csvhierarchySplitter[0].equals( dbhierarchySplitter[0] ) ) ) {
                            errMsg += "csvData Grade = " + csvhierarchySplitter[0] + " *** DBData Grade = " + dbhierarchySplitter[0] + " is not matched.    ";
                            mismatch = true;
                        }
                        if ( !csvhierarchySplitter[1].equals( dbhierarchySplitter[1] ) ) {
                            errMsg += "csvData Strand = " + csvhierarchySplitter[1] + " *** DBData Strand = " + dbhierarchySplitter[1] + " is not matched.  ";
                            mismatch = true;
                        }
                        if ( !csvhierarchySplitter[2].equals( dbhierarchySplitter[2] ) ) {
                            errMsg += "csvData = " + csvhierarchySplitter[2] + " *** DBData = " + dbhierarchySplitter[2] + " is not matched.    ";
                            mismatch = true;
                        }
                        if ( !csvhierarchySplitter[3].equals( dbhierarchySplitter[3] ) ) {
                            errMsg += "csvData Concept= " + csvhierarchySplitter[3] + " *** DBData Concept= " + dbhierarchySplitter[3] + " is not matched.  ";
                            mismatch = true;
                        }
                        if ( !csvhierarchySplitter[4].equals( dbhierarchySplitter[4] ) ) {
                            errMsg += "csvData Topic= " + csvhierarchySplitter[4] + " *** DBData Topic= " + dbhierarchySplitter[4] + " is not matched.  ";
                            mismatch = true;
                        }
                        if ( !csvsplitLO[2].equals( dbsplitLO[2] ) ) {
                            errMsg += "csvData Strand Item= " + csvsplitLO[2] + " *** DBData Strand Item= " + dbsplitLO[2] + " is not matched.  ";
                            mismatch = true;
                        }
                        if ( Integer.parseInt( csvsplitLO[3].substring( 2, 5 ) ) != Integer.parseInt( dbsplitLO[3].substring( 2, 5 ) ) ) {
                            errMsg += "csvData Course Level= " + Integer.parseInt( csvsplitLO[3].substring( 2, 5 ) ) + " *** DBData Course Level= " + Integer.parseInt( dbsplitLO[3].substring( 2, 5 ) ) + " is not matched.    ";
                            mismatch = true;
                        }
                    }
                }
                if ( !LOAvailable || !errMsg.equals( "" ) ) {
                    csvWriter.append( csvsplitLO[0] + "," );
                    if ( !LOAvailable ) {
                        status = false;
                        csvWriter.append( "LO not found in the DB" + "," );
                    }
                    if ( errMsg != "" ) {
                        status = false;
                        csvWriter.append( "Data mismatched" + "," );
                        csvWriter.append( "\"" + errMsg + "\"" + "," );
                        csvWriter.append( "\n" );
                    } else {
                        csvWriter.append( "\n" );
                    }
                }
            }

            if ( mathHierarchy.size() == SMDBarrList.size() ) {
                Log.message( "CSV & SMDB Records are matched" );
            } else {
                for ( int i = 0; i < SMDBarrList.size(); i++ ) {

                    String[] dbsplitLO = SMDBarrList.get( i ).split( "\\|", 0 );
                    String[] dbhierarchySplitter = dbsplitLO[1].split( " >> " );
                    String errMsg = "";
                    Boolean LOAvailable = false;
                    for ( int j = 0; j < mathHierarchy.size(); j++ ) {
                        String[] csvsplitLO = mathHierarchy.get( j ).split( "\\|", 0 );
                        String[] csvhierarchySplitter = csvsplitLO[1].split( " >> " );
                        Boolean mismatch = false;

                        if ( csvsplitLO[0].equals( dbsplitLO[0] ) ) {
                            LOAvailable = true;
                        }
                    }
                    if ( !LOAvailable ) {
                        csvWriter.append( dbsplitLO[0] + "," );
                        csvWriter.append( "LO not found in the CSV" + "\n" );
                    }
                }
            }
            csvWriter.flush();
            csvWriter.close();
            Log.message( "Writing mismatched data into CSV is completed" );
            Log.assertThat( status, "All CSV data's are present in the DB", "Some CSV data's are mismatched / not found the DB." + " Please check \\test-output\\HierarchyValidation\\MismatchedHierarcy_MathData.csv file for the details" );
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify Math motion xml are populated correctly", priority = 1 )
    public void TcMathHierarcy002() throws Exception {

        Log.testCaseInfo( "Verify Math motion xml are populated correctly" );

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse( new URL( configProperty.getProperty( "SMAppUrl" ) + "/content/math/resources/resources.xml" ).openStream() );

        HashMap<String, String> tutorialMap = SMUtils.getMathTutorialMap( doc );

        String[] nextLine;
        Boolean status = true;
        int CSVpositions[] = { 31, 32, 33, 28, 30 }; //{Prerequisite 1,Prerequisite 2,Prerequisite 3, Tutorial, Mastery}	
        String misbasePath = new File( "." ).getCanonicalPath() + File.separator + "test-output" + File.separator + "HierarchyValidation" + File.separator; //+ "Math" + File.separator;

        File dir = new File( misbasePath );
        dir.mkdir();
        String midmatchcsvFilePath = misbasePath + "MismatchedMotion_MathData.csv";

        FileWriter csvWriter = new FileWriter( midmatchcsvFilePath );
        csvWriter.append( "LO" + "," );
        csvWriter.append( "Result" + "," );
        csvWriter.append( "Details" + "," );
        csvWriter.append( "\n" );

        Log.message( "Writing mismatched data into CSV is started" );

        String configFilePath = csvBasePath + configProperty.getProperty( "mathHierarchyCSV" );
        CSVReader reader = new CSVReader( new FileReader( configFilePath ) );

        //Validation Tutorial LO
        List<String> CSVTutorialList = SMUtils.getMathTutorialfromCSV( reader );
        List<String> XMLTutorialList = new ArrayList<String>();

        for ( Map.Entry<String, String> entry : tutorialMap.entrySet() ) {
            XMLTutorialList.add( entry.getKey() );
        }
        Log.message( "Tutorial LO Count in CSV: " + CSVTutorialList.size() );
        Log.message( "Tutorial LO Count in XML: " + XMLTutorialList.size() );

        if ( CSVTutorialList.size() == XMLTutorialList.size() ) {
            for ( int i = 0; i < CSVTutorialList.size(); i++ ) {
                Boolean scoStatus = false;
                for ( int j = 0; j < XMLTutorialList.size(); j++ ) {
                    if ( CSVTutorialList.get( i ).equals( XMLTutorialList.get( j ) ) ) {
                        scoStatus = true;
                        Log.message( "Tutorial LO : " + CSVTutorialList.get( i ) + " Present in the xml" );
                    }
                }
                if ( !scoStatus ) {
                    csvWriter.append( CSVTutorialList.get( i ) + "," );
                    csvWriter.append( "Tutorial LO Not Present in the XML" + "," );
                    csvWriter.append( "\n" );
                }
            }
        } else if ( CSVTutorialList.size() < XMLTutorialList.size() ) {
            List<String> additionalDataInXML = new ArrayList<String>( XMLTutorialList );
            additionalDataInXML.removeAll( CSVTutorialList );
            Log.message( "additional Tutorial LO In XML: " + additionalDataInXML );
            for ( int i = 0; i < additionalDataInXML.size(); i++ ) {
                csvWriter.append( additionalDataInXML.get( i ) + "," );
                csvWriter.append( "Tutorial LO Additionally present in XML" + "," );
                csvWriter.append( "\n" );
            }

        } else {
            List<String> additionalDataInCSV = new ArrayList<String>( CSVTutorialList );
            additionalDataInCSV.removeAll( XMLTutorialList );
            Log.message( "additional Tutorial LO In CSV: " + additionalDataInCSV );
            for ( int i = 0; i < additionalDataInCSV.size(); i++ ) {
                csvWriter.append( additionalDataInCSV.get( i ) + "," );
                csvWriter.append( "Tutorial LO Present in the XML" + "," );
                csvWriter.append( "\n" );
            }
        }

        //Validation the LO information

        HashMap<String, String> LOStrandMap = SMUtils.getMathLOMapStrand( );

        reader = new CSVReader( new FileReader( configFilePath ) );
        nextLine = reader.readNext(); // To Skip headers

        while ( ( nextLine = reader.readNext() ) != null ) {

            Map<String, String> xmlData = new TreeMap<String, String>();
            Map<String, String> csvData = new TreeMap<String, String>();
            String csvLO = nextLine[18];

            Log.message( "Validating for the LO: " + csvLO );

            xmlData = SMUtils.getMathPrerequisiteTable( csvLO, doc );
            if ( !xmlData.isEmpty() ) {
                csvData.put( "Prerequisite_1", nextLine[CSVpositions[0]] );
                csvData.put( "Prerequisite_2", nextLine[CSVpositions[1]] );
                csvData.put( "Prerequisite_3", nextLine[CSVpositions[2]] );
                csvData.put( "Tutorial_1", nextLine[CSVpositions[3]].trim() );
                csvData.put( "mastery", nextLine[CSVpositions[4]] );

                while ( csvData.values().remove( "" ) )
                    ; //Remove empty key/value from the hash

                // Replacing Prerequsite LO name with it corresponding strandItem + courselevel 
                for ( Map.Entry<String, String> item : csvData.entrySet() ) {
                    String key = item.getKey();
                    if ( key.contains( "Pre" ) ) {
                        csvData.replace( key, LOStrandMap.get( item.getValue() ) );
                    } else if ( key.contains( "Tutorial" ) ) {
                        csvData.replace( key, tutorialMap.get( item.getValue() ) );
                    }
                }

                if ( csvData.size() == xmlData.size() ) {
                    String errMsg = "";
                    String[] csvKey = csvData.keySet().toArray( new String[0] );
                    String[] csvVal = csvData.values().toArray( new String[0] );

                    String[] xmlKey = xmlData.keySet().toArray( new String[0] );
                    String[] xmlVal = xmlData.values().toArray( new String[0] );

                    for ( int i = 0; i < csvData.size(); i++ ) {
                        if ( ( csvKey[i].equals( xmlKey[i] ) ) && ( csvVal[i].equals( xmlVal[i] ) ) ) {

                        } else {
                            errMsg += "csvData: " + csvKey[i] + "=> " + csvVal[i] + "****** xmlData: " + xmlKey[i] + "=> " + xmlVal[i] + "*******";
                        }
                    }

                    if ( !errMsg.equals( "" ) ) {
                        status = false;
                        csvWriter.append( csvLO + "," );
                        csvWriter.append( "Data Mismatched" + "," );
                        csvWriter.append( "\"" + errMsg + "\"" + "\n" );
                        errMsg = "";
                    }
                } else {
                    status = false;
                    csvWriter.append( csvLO + "," );
                    csvWriter.append( "Prerequsite or Tutorial Missed" + "," );
                    csvWriter.append( "\"" + "CSV Data: " + csvData + " ******** " + "XML Data: " + xmlData + "\"" + "\n" );
                }
            } else {
                status = false;
                csvWriter.append( csvLO + "," );
                csvWriter.append( "LO not found in the XML" + "\n" );
            }
        }

        Log.message( "LO Validation is completed" );

        csvWriter.append( "\n" );
        csvWriter.append( "\n" );
        csvWriter.append( "\n" );

        csvWriter.append( "Mastery" + "," );
        csvWriter.append( "Result" + "," );
        csvWriter.append( "Details" + "," );
        csvWriter.append( "\n" );

        String[] MasnextLine;
        String masteryFilePath = csvBasePath + "Mastery Data Alfresco.csv";
        CSVReader masteryReader = new CSVReader( new FileReader( masteryFilePath ) );

        MasnextLine = masteryReader.readNext(); // To Skip headers
        while ( ( MasnextLine = masteryReader.readNext() ) != null ) {
            String errMsg = "";
            HashMap<String, String> masteryMap = SMUtils.getMathMasteryMap( MasnextLine[0], doc );

            String masteryID = MasnextLine[0];

            Log.message( "Validating the mastery details of: " + masteryID );

            if ( !masteryMap.isEmpty() ) {
                if ( !MasnextLine[1].equals( masteryMap.get( "min" ) ) ) {
                    errMsg += "CSV Data: " + MasnextLine[1] + "****" + "XML Data: " + masteryMap.get( "min" );
                }
                if ( !MasnextLine[2].equals( masteryMap.get( "max" ) ) ) {
                    errMsg += "CSV Data: " + MasnextLine[2] + "****" + "XML Data: " + masteryMap.get( "max" );
                }
                if ( !MasnextLine[3].equals( masteryMap.get( "pn" ) ) ) {
                    errMsg += "CSV Data: " + MasnextLine[2] + "****" + "XML Data: " + masteryMap.get( "pn" );
                }
                if ( !MasnextLine[4].equals( masteryMap.get( "sn" ) ) ) {
                    errMsg += "CSV Data: " + MasnextLine[4] + "****" + "XML Data: " + masteryMap.get( "sn" );
                }
                if ( !MasnextLine[5].equals( masteryMap.get( "t1" ) ) ) {
                    errMsg += "CSV Data: " + MasnextLine[5] + "****" + "XML Data: " + masteryMap.get( "t1" );
                }
                if ( !MasnextLine[6].equals( masteryMap.get( "t2" ) ) ) {
                    errMsg += "CSV Data: " + MasnextLine[6] + "****" + "XML Data: " + masteryMap.get( "t2" );
                }
                if ( !MasnextLine[7].equals( masteryMap.get( "t3" ) ) ) {
                    errMsg += "CSV Data: " + MasnextLine[7] + "****" + "XML Data: " + masteryMap.get( "t3" );
                }
                if ( !MasnextLine[8].equals( masteryMap.get( "k" ) ) ) {
                    errMsg += "CSV Data: " + MasnextLine[8] + "****" + "XML Data: " + masteryMap.get( "k" );
                }
                if ( !MasnextLine[9].equals( masteryMap.get( "w" ) ) ) {
                    errMsg += "CSV Data: " + MasnextLine[9] + "****" + "XML Data: " + masteryMap.get( "w" );
                }
                if ( !MasnextLine[10].equals( masteryMap.get( "q" ) ) ) {
                    errMsg += "CSV Data: " + MasnextLine[10] + "****" + "XML Data: " + masteryMap.get( "q" );
                }
            } else {
                status = false;
                csvWriter.append( masteryID + "," );
                csvWriter.append( "Mastery Not found in the XML" + "\n" );
            }
            if ( !errMsg.equals( "" ) ) {
                csvWriter.append( masteryID + "," );
                csvWriter.append( "Data Mismatched" + "," );
                csvWriter.append( "\"" + errMsg + "\"" + "\n" );
                errMsg = "";
            }
        }

        csvWriter.flush();
        csvWriter.close();
        Log.message( "Writing mismatched motion data into CSV is completed" );

        Log.softAssertThat( status, "All CSV data's are present in the resources.XML",
                "Some CSV data's are mismatched / not found in the resoruces.XML" + " Please check \\test-output\\HierarchyValidation\\MismatchedMotion_MathData.csv file for the details" );

        Document scoDoc = db.parse( new URL( configProperty.getProperty( "SMAppUrl" ) + "/content/math/resources/mathscos.xml" ).openStream() );
        String midmatchSCOcsvFilePath = misbasePath + "MismatchedSCOXML_MathData.csv";
        reader = new CSVReader( new FileReader( configFilePath ) );

        Boolean scoTestStatus = true;

        csvWriter = new FileWriter( midmatchSCOcsvFilePath );
        csvWriter.append( "SCO" + "," );
        csvWriter.append( "Result" + "," );
        csvWriter.append( "Details" + "," );
        csvWriter.append( "\n" );

        Log.message( "Writing mismatched data into CSV is started" );

        Map<String, String> MotionXMLData = SMUtils.getMathSCOfromMotion( scoDoc );
        List<String> CSVscoList = SMUtils.getMathSCOfromCSV( reader );
        List<String> XMLscoList = new ArrayList<String>();

        for ( Map.Entry<String, String> entry : MotionXMLData.entrySet() ) {
            XMLscoList.add( entry.getKey() );
        }

        Log.message( "SCO Count in CSV: " + CSVscoList.size() );
        Log.message( "SCO Count in XML: " + XMLscoList.size() );

        if ( CSVscoList.size() == XMLscoList.size() ) {
            for ( int i = 0; i < CSVscoList.size(); i++ ) {
                Boolean scoStatus = false;
                for ( int j = 0; j < XMLscoList.size(); j++ ) {
                    if ( CSVscoList.get( i ).equals( XMLscoList.get( j ) ) ) {
                        scoStatus = true;
                        Log.message( "SCO : " + CSVscoList.get( i ) + " Present in the mathscos.xml" );
                    }
                }
                if ( !scoStatus ) {
                    scoTestStatus = false;
                    csvWriter.append( CSVscoList.get( i ) + "," );
                    csvWriter.append( "SCO Not Present in the XML" + "," );
                    csvWriter.append( "\n" );
                }
            }
        } else if ( CSVscoList.size() < XMLscoList.size() ) {
            scoTestStatus = false;
            List<String> additionalDataInXML = new ArrayList<String>( XMLscoList );
            additionalDataInXML.removeAll( CSVscoList );
            Log.message( "additionalSCOInXML: " + additionalDataInXML );
            for ( int i = 0; i < additionalDataInXML.size(); i++ ) {
                csvWriter.append( additionalDataInXML.get( i ) + "," );
                csvWriter.append( "SCO Additionally present in XML" + "," );
                csvWriter.append( "\n" );
            }

        } else if ( CSVscoList.size() > XMLscoList.size() ) {
            scoTestStatus = false;
            List<String> additionalDataInCSV = new ArrayList<String>( CSVscoList );
            additionalDataInCSV.removeAll( XMLscoList );
            Log.message( "additionalDataInCSV: " + additionalDataInCSV );
            for ( int i = 0; i < additionalDataInCSV.size(); i++ ) {
                csvWriter.append( additionalDataInCSV.get( i ) + "," );
                csvWriter.append( "SCO Not Present in the XML" + "," );
                csvWriter.append( "\n" );
            }
        }

        for ( Map.Entry<String, String> entry : MotionXMLData.entrySet() ) {
            String SCOid = entry.getKey();
            Integer scorableVal = Integer.parseInt( entry.getValue() );

            if ( SCOid.contains( "SMMA_LO" ) ) {
                if ( scorableVal == 0 ) {
                    scoTestStatus = false;
                    csvWriter.append( SCOid + "," );
                    csvWriter.append( "isScorable value is 0" + "," );
                    csvWriter.append( "\n" );
                } else {
                    Log.message( "SCOid: " + SCOid + " isScorable value is 1" );
                }
            } else if ( SCOid.contains( "SMMA_TU" ) ) {
                if ( scorableVal == 1 ) {
                    scoTestStatus = false;
                    csvWriter.append( SCOid + "," );
                    csvWriter.append( "isScorable value is 1" + "," );
                    csvWriter.append( "\n" );
                } else {
                    Log.message( "SCOid: " + SCOid + " isScorable value is 0" );
                }
            }
        }
        csvWriter.flush();
        csvWriter.close();

        Log.assertThat( scoTestStatus, "All CSV data's are present in the mathscos.XML",
                "Some CSV data's are mismatched / not found in the mathscos.XML" + " Please check \\test-output\\HierarchyValidation\\MismatchedSCOXML_MathData.csv file for the details" );
    }

    @Test ( description = "Verify state standards data between Alfressco and SMDB for MATH", priority = 1 )
    public void TcMathStateAlignment() throws Exception {

        Log.testCaseInfo( "Verify state standards data between Alfressco and SMDB for MATH" );

        String stateBasePath = csvBasePath + File.separator + "Mathstatestandard" + File.separator;
        String outputbasePath = new File( "." ).getCanonicalPath() + File.separator + "test-output" + File.separator + "HierarchyValidation" + File.separator;

        int failCount = 0;

        FileReader fr = new FileReader( queriesBasePath + "getMathHierarchy.sql" );
        BufferedReader br = new BufferedReader( fr );

        StringBuilder sb = new StringBuilder();
        String sqlLine;
        while ( ( sqlLine = br.readLine() ) != null ) {
            sb.append( sqlLine );
        }
        br.close();

        String query = sb.toString();

        List<Object[]> records = SQLUtil.executeQuery( query );

        List<String> SMDBHiearList = new ArrayList<String>();
        for ( Object[] list : records ) {
            if ( list.length > 0 ) {
                SMDBHiearList.add( list[0].toString() );
            }
        }

        List<String> fileList = new ArrayList<String>();

        File[] files = new File( stateBasePath ).listFiles();
        
        Log.message( "*****************************");
        Log.message( "File size is "+ files.length);
        Log.message( "*****************************");
        for ( File file : files ) {
            if ( file.isFile() ) {
                fileList.add( file.getName() );
            }
        }

        Log.assertThat( fileList.size() != 0, "State Standard CSV file is available in test data folder", "No State standard CSV file for verification in test data folder" );

        //To remove .DS_Store file which might come while unzipping the hierarchyValidation folder
        if ( fileList.contains( ".DS_Store" ) ) {
            fileList.remove( ".DS_Store" );
        }

        for ( int i = 0; i < fileList.size(); i++ ) {
            HashMap<String, String> csvHierarchy = new HashMap<String, String>();
            Map<String, String> csvHierarchyMap = new TreeMap<String, String>();
            HashMap<String, String> dbHierarchy = new HashMap<String, String>();
            Map<String, String> dbHierarchyMap = new TreeMap<String, String>();
            String standardName = "";

            String fileName = fileList.get( i );
            String stateStdcsvFilePath = stateBasePath + fileName;

            Log.message( "Validating the file: " + fileName );

            CSVReader reader = new CSVReader( new FileReader( stateStdcsvFilePath ) );
            String[] nextLine;

            nextLine = reader.readNext(); // To Skip headers
            int columnCount = nextLine.length;

            while ( ( nextLine = reader.readNext() ) != null ) {
                String stateHierarchy = "";
                String loID = nextLine[columnCount - 1];
                standardName = nextLine[0];
                for ( int j = 0; j < columnCount - 1; j++ ) {
                    if ( !nextLine[j].equals( "" ) ) {
                        stateHierarchy = stateHierarchy + nextLine[j].trim() + ">>";
                    }
                }
                stateHierarchy = stateHierarchy.substring( 0, stateHierarchy.length() - 2 );
                csvHierarchy.put( stateHierarchy, loID );
                csvHierarchyMap.putAll( csvHierarchy );
            }
            Log.message( "Validating the standardName: " + standardName );

            fr = new FileReader( queriesBasePath + "getMathStateAlignment.sql" );
            br = new BufferedReader( fr );

            sb = new StringBuilder();
            String sqlLine1;
            while ( ( sqlLine1 = br.readLine() ) != null ) {
                sb.append( sqlLine1 );
            }
            br.close();

            query = sb.toString();

            standardName = standardName.replace( "'", "''" );
            query = query.replace( "<standard_name>", standardName );
            records = SQLUtil.executeQuery( query );

            List<String> SMDBarrList = new ArrayList<String>();
            for ( Object[] list : records ) {
                if ( list.length > 0 ) {
                    dbHierarchy.put( list[0].toString().trim(), list[1].toString() );
                }
            }
            dbHierarchyMap.putAll( dbHierarchy );

            fileName = fileName.replace( " ", "_" );
            File dir = new File( outputbasePath );
            dir.mkdir();
            String csvoutputePath = outputbasePath + "Mismatched_" + fileName;

            FileWriter csvWriter = new FileWriter( csvoutputePath );
            csvWriter.append( "Standards" + "," );
            csvWriter.append( "Grade in Alignment" + "," );
            csvWriter.append( "LO ID" + "," );
            csvWriter.append( "Course Level in DB" + "," );
            csvWriter.append( "\n" );

            String errMsg = "";
            String[] csvKey = csvHierarchyMap.keySet().toArray( new String[0] );
            String[] csvVal = csvHierarchyMap.values().toArray( new String[0] );

            String[] dbKey = dbHierarchyMap.keySet().toArray( new String[0] );
            String[] dbVal = dbHierarchyMap.values().toArray( new String[0] );

            //Validating the course level of LO

            for ( int x = 0; x < csvVal.length; x++ ) {
                String[] loArray = csvVal[x].replace( ";;", ";" ).split( ";" );
                String[] gradeSplit = csvKey[x].split( ">>" );
                String grade = gradeSplit[1];
                if ( grade.equals( "Grade K" ) ) {
                    grade = "Grade 0";
                }

                Float gradeLevel = Float.parseFloat( grade.replaceAll( "[\\D]", "" ) );

                for ( int y = 0; y < loArray.length; y++ ) {
                    String LOinStateCSV = loArray[y].trim();
                    for ( int z = 0; z < SMDBHiearList.size(); z++ ) {
                        String hierarchyRecord = SMDBHiearList.get( z );
                        if ( hierarchyRecord.contains( LOinStateCSV ) ) {
                            Float courseLevel = Float.parseFloat( hierarchyRecord.substring( hierarchyRecord.length() - 3 ) ) / 100;

                            if ( gradeLevel > courseLevel ) {
                                csvWriter.append( "\"" + standardName + "\"" + "," );
                                csvWriter.append( grade + "," );
                                csvWriter.append( LOinStateCSV + "," );
                                csvWriter.append( courseLevel + "\n" );
                            }
                        }
                    }
                }

            }

            csvWriter.append( "\n" );
            csvWriter.append( "\n" );
            csvWriter.append( "\n" );
            csvWriter.append( "\n" );
            csvWriter.append( "Standards" + "," );
            csvWriter.append( "Result" + "," );
            csvWriter.append( "Details" + "," );
            csvWriter.append( "\n" );

            Log.message( "Size: " + "DB Size: " + dbHierarchyMap.size() + "CSV Size: " + csvHierarchyMap.size() );
            Boolean status = true;

            if ( dbHierarchyMap.size() == csvHierarchyMap.size() ) {

                for ( int j = 0; j < dbHierarchyMap.size(); j++ ) {
                    Boolean StandardMatched = false;
                    String csvLOSort = "";
                    String dbLOSort = "";
                    errMsg = "";
                    for ( int k = 0; k < dbHierarchyMap.size(); k++ ) {
                        //CSV with DB
                        if ( ( csvKey[j].trim().equals( dbKey[k] ) ) ) { // && (csvVal[j].trim().equals(dbVal[k]))) {
                            String[] csvValSplit = csvVal[j].split( ";" );
                            String[] dbValValSplit = dbVal[k].split( ";" );

                            Arrays.sort( csvValSplit );
                            Arrays.sort( dbValValSplit );
                            for ( int x = 0; x < csvValSplit.length; x++ ) {
                                if ( !csvValSplit[x].equals( "" ) ) {
                                    csvLOSort = csvLOSort + csvValSplit[x] + ";";
                                }
                            }

                            for ( int y = 0; y < dbValValSplit.length; y++ ) {
                                if ( !dbValValSplit[y].equals( "" ) ) {
                                    dbLOSort = dbLOSort + dbValValSplit[y] + ";";
                                }
                            }
                            if ( csvLOSort.equals( dbLOSort ) ) {
                                StandardMatched = true;
                                break;
                            }
                        }
                    }
                    if ( !StandardMatched ) {
                        errMsg += "csvData: " + csvKey[j] + "=> " + csvLOSort;
                        Log.message( "Data missed in DB: " + errMsg );
                        status = false;
                        failCount++;
                        csvWriter.append( "\"" + standardName + "\"" + "," );
                        csvWriter.append( "Data Missed / Mismatched" + "," );
                        csvWriter.append( "\"" + errMsg + "\"" + "\n" );
                    }

                }

                //DB With CSV

                for ( int j = 0; j < dbHierarchyMap.size(); j++ ) {
                    Boolean StandardMatched = false;
                    String csvLOSort = "";
                    String dbLOSort = "";
                    errMsg = "";
                    for ( int k = 0; k < dbHierarchyMap.size(); k++ ) {
                        //CSV with DB
                        if ( ( dbKey[j].trim().equals( csvKey[k] ) ) ) { // && (csvVal[j].trim().equals(dbVal[k]))) {
                            String[] csvValSplit = csvVal[k].split( ";" );
                            String[] dbValValSplit = dbVal[j].split( ";" );

                            Arrays.sort( csvValSplit );
                            Arrays.sort( dbValValSplit );
                            for ( int x = 0; x < csvValSplit.length; x++ ) {
                                if ( !csvValSplit[x].equals( "" ) ) {
                                    csvLOSort = csvLOSort + csvValSplit[x] + ";";
                                }
                            }

                            for ( int y = 0; y < dbValValSplit.length; y++ ) {
                                if ( !dbValValSplit[y].equals( "" ) ) {
                                    dbLOSort = dbLOSort + dbValValSplit[y] + ";";
                                }
                            }
                            if ( dbLOSort.equals( csvLOSort ) ) {
                                StandardMatched = true;
                                break;
                            }
                        }
                    }
                    if ( !StandardMatched ) {
                        errMsg += "DBData: " + dbKey[j] + "=> " + dbLOSort;
                        Log.message( "Data missed in CSV: " + errMsg );
                        status = false;
                        failCount++;
                        csvWriter.append( "\"" + standardName + "\"" + "," );
                        csvWriter.append( "Data Missed in CSV" + "," );
                        csvWriter.append( "\"" + errMsg + "\"" + "\n" );
                    }

                }

            } else if ( csvHierarchyMap.size() < dbHierarchyMap.size() ) {
                status = false;
                failCount++;
                List<String> CSVList = Arrays.asList( csvKey );
                List<String> DBList = Arrays.asList( dbKey );

                List<String> additionalDataInDB = new ArrayList<String>( DBList );
                additionalDataInDB.removeAll( CSVList );
                Log.failsoft( "Additional Data Present in DB: " + additionalDataInDB );
                csvWriter.append( "\"" + standardName + "\"" + "," );
                csvWriter.append( "Additional Data in DB" + "," );
                csvWriter.append( "\"" + additionalDataInDB + "\"" + "\n" );
            } else {
                status = false;
                failCount++;
                List<String> CSVList = Arrays.asList( csvKey );
                List<String> DBList = Arrays.asList( dbKey );

                List<String> additionalDataInCSV = new ArrayList<String>( CSVList );
                additionalDataInCSV.removeAll( DBList );
                for ( int k = 0; k < additionalDataInCSV.size(); k++ ) {
                    csvWriter.append( "\"" + standardName + "\"" + "," );
                    csvWriter.append( "Data Missed in DB" + "," );
                    csvWriter.append( "\"" + additionalDataInCSV.get( k ) + "\"" + "\n" );
                }
                csvWriter.append( "Data Missed in DB" + "," );
                Log.failsoft( "Data Missed in DB: " + additionalDataInCSV );
            }
            if ( status ) {
                Log.message( "standardName: " + standardName + " all the data matched with DB" );
            }
            //    		Log.softAssertThat(status, fileName + " Data matched with DB", 
            //    				"Some Data mismatched / not found. Please check report and " + csvoutputePath );
            csvWriter.flush();
            csvWriter.close();
        }
        //         Log.assertThat(failCount == 0, "Math State standard data matched with DB", 
        //        		 "Some Sate standard Data mismatched / not found. Please check report and " + outputbasePath + " folder for mismatced information");
    }

    @SuppressWarnings ( "unchecked" )
    @Test ( description = "Verify Alfresco data's are matched with SMDB for READING", priority = 1 )
    public void TcReadingHierarcy001() throws Exception {

        Log.testCaseInfo( "Verify Alfresco data's are matched with SMDB for READING" );
        Boolean status = true;

        FileReader fr = new FileReader( queriesBasePath + "getReadingHierarchy.sql" );
        BufferedReader br = new BufferedReader( fr );

        StringBuilder sb = new StringBuilder();
        String sqlLine;
        while ( ( sqlLine = br.readLine() ) != null ) {
            sb.append( sqlLine );
        }
        br.close();

        String query = sb.toString();
        List<Object[]> records = SQLUtil.executeQuery( query );

        List<String> SMDBarrList = new ArrayList<String>();
        for ( Object[] list : records ) {
            if ( list.length > 0 ) {
                SMDBarrList.add( list[0].toString() );
            }
        }

        Log.message( "Fetching data from CSV" );
        List<String> readHierarchy = SMUtils.generateReadingHierarchy( "SM2021_ConceptsHierarchy" );
        Collections.sort( readHierarchy );

        Log.message( "Fetching data from CSV is completed" );

        String basePath = new File( "." ).getCanonicalPath() + File.separator + "test-output" + File.separator + "HierarchyValidation" + File.separator;
        File dir = new File( basePath );
        dir.mkdir();
        String csvFilePath = basePath + "MismatchedHierarcy_Reading_DB_Data.csv";

        FileWriter csvWriter = new FileWriter( csvFilePath );
        csvWriter.append( "LO" + "," );
        csvWriter.append( "Result" + "," );
        csvWriter.append( "Details" + "," );
        csvWriter.append( "\n" );

        Log.message( "Writing mismatched data into CSV is started" );

        for ( int i = 0; i < readHierarchy.size(); i++ ) {
            String[] csvsplitLO = readHierarchy.get( i ).split( "\\|", 0 );
            String[] csvhierarchySplitter = csvsplitLO[1].split( " >> " );

            String errMsg = "";
            Boolean LOAvailable = false;
            for ( int j = 0; j < SMDBarrList.size(); j++ ) {

                Boolean mismatch = false;
                String[] dbsplitLO = SMDBarrList.get( j ).split( "\\|", 0 );
                String[] dbhierarchySplitter = dbsplitLO[1].split( " >> " );

                if ( csvsplitLO[0].equals( dbsplitLO[0] ) ) {
                    LOAvailable = true;
                    if ( !( csvhierarchySplitter[0].equals( dbhierarchySplitter[1] ) ) ) {
                        errMsg += "csvData Grade = " + csvhierarchySplitter[0] + " *** DBData Grade = " + dbhierarchySplitter[1] + " ";
                        mismatch = true;
                    }
                    if ( !csvhierarchySplitter[1].equals( dbhierarchySplitter[2] ) ) {
                        errMsg += "csvData BenchMark = " + csvhierarchySplitter[1] + " *** DBData BenchMark = " + dbhierarchySplitter[2] + " ";
                        mismatch = true;
                    }
                    if ( !csvhierarchySplitter[2].equals( dbhierarchySplitter[3] ) ) {
                        errMsg += "csvData Unit= " + csvhierarchySplitter[2] + " *** DBData Unit= " + dbhierarchySplitter[3] + " ";
                        mismatch = true;
                    }
                    if ( !csvhierarchySplitter[3].equals( dbhierarchySplitter[4] ) ) {
                        errMsg += "csvData Lesson= " + csvhierarchySplitter[3] + " *** DBData Lesson= " + dbhierarchySplitter[4] + " ";
                        mismatch = true;
                    }
                    if ( !csvhierarchySplitter[4].equals( dbhierarchySplitter[5] ) ) {
                        errMsg += "csvData Title= " + csvhierarchySplitter[4] + " *** DBData Title= " + dbhierarchySplitter[5] + " ";
                        mismatch = true;
                    }
                    if ( !csvhierarchySplitter[5].equals( dbhierarchySplitter[6] ) ) {
                        errMsg += "csvData Title= " + csvhierarchySplitter[5] + " *** DBData Title= " + dbhierarchySplitter[6] + " ";
                        mismatch = true;
                    }
                }
            }
            if ( !LOAvailable || !errMsg.equals( "" ) ) {
                csvWriter.append( csvsplitLO[0] + "," );
                if ( !LOAvailable ) {
                    status = false;
                    csvWriter.append( "LO not found in the DB" + "," );
                }
                if ( !errMsg.equals( "" ) ) {
                    status = false;
                    csvWriter.append( "Data mismatched" + "," );
                    csvWriter.append( "\"" + errMsg + "\"" + "\n" );
                    Log.message( "LO: " + csvsplitLO[0] + " Data mismatched" + " is not matched" );
                }
            } else {
                Log.message( "LO: " + csvsplitLO[0] + " details are matched with DB" );
                csvWriter.append( "\n" );
            }
        }

        if ( readHierarchy.size() == SMDBarrList.size() ) {
            Log.message( "CSV & SMDB Records are matched" );
        } else {
            for ( int i = 0; i < SMDBarrList.size(); i++ ) {

                String[] dbsplitLO = SMDBarrList.get( i ).split( "\\|", 0 );
                String[] dbhierarchySplitter = dbsplitLO[1].split( " >> " );
                String errMsg = "";
                Boolean LOAvailable = false;
                for ( int j = 0; j < readHierarchy.size(); j++ ) {
                    String[] csvsplitLO = readHierarchy.get( j ).split( "\\|", 0 );
                    String[] csvhierarchySplitter = csvsplitLO[1].split( " >> " );
                    Boolean mismatch = false;

                    if ( csvsplitLO[0].equals( dbsplitLO[0] ) ) {
                        LOAvailable = true;
                    }
                }
                if ( !LOAvailable ) {
                    csvWriter.append( dbsplitLO[0] + "," );
                    csvWriter.append( "LO not found in the CSV" + "\n" );
                }
            }
        }
        csvWriter.flush();
        csvWriter.close();
        Log.message( "Writing mismatched data into CSV is completed" );
        Log.softAssertThat( readHierarchy.size() == SMDBarrList.size(), "CSV & DB Record set are equal. DB LO's Count: " + SMDBarrList.size() + " CSV LO's Count: " + readHierarchy.size(),
                "Record set are not equal. DB LO's Count: " + SMDBarrList.size() + "CSV LO's Count: " + readHierarchy.size() );
        Log.assertThat( status, "All CSV data's are present in the DB", "Some CSV data's are mismatched / not found the DB" );

    }

    @Test ( description = "Verify Reading motion xml are populated correctly", priority = 1 )
    public void TcReadingHierarcy002() throws Exception {

        Log.testCaseInfo( "Verify Reading motion xml are populated correctly" );
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();

        /*
         * readingresources.xml Validation
         */

        String[] nextLine;
        Boolean Lessonstatus = true;

        //{skillObjectiveId, lexile, GuidedPractice, RemediationFor68, only68, level, InitialPlacement, isKey, IndependentPractice, RemediationForK5}

        int CSVLOStrandpositions[] = { 39, 32, 25, 28, 30, 31, 26, 29, 24, 27 };
        String CSVLOStrandNames[] = { "skillObjectiveId", "lexile", "GuidedPractice", "RemediationFor68", "only68", "level", "InitialPlacement", "isKey", "IndependentPractice", "RemediationForK5" };

        String misbasePath = new File( "." ).getCanonicalPath() + File.separator + "test-output" + File.separator + "HierarchyValidation" + File.separator;
        File dir = new File( misbasePath );
        dir.mkdir();
        String mismatchResourceFilePath = misbasePath + "ReadingMismatchedMotionResourcesXMLData.csv";

        FileWriter csvWriter = new FileWriter( mismatchResourceFilePath );
        csvWriter.append( "Lesson ID" + "," );
        csvWriter.append( "Result" + "," );
        csvWriter.append( "Details" + "," );
        csvWriter.append( "\n" );

        Log.message( "Writing mismatched data into CSV is started" );

        String configFilePath = csvBasePath + configProperty.getProperty( "readingHierarchyFile" );

        CSVReader CSVLOreader = new CSVReader( new FileReader( configFilePath ) );
        HashMap<String, String> uuidDetails = SMUtils.getReadingLessonUUIDDetails( CSVLOreader );

        Document lobJSDoc = db.parse( csvBasePath + configProperty.getProperty( "reaingTaxonomys" ) );
        Document resourceDoc = db.parse( new URL( configProperty.getProperty( "SMAppUrl" ) + "/content/reading/resources/readingresources.xml" ).openStream() );

        ArrayList<String> unassignedLesson = new ArrayList<>();
        // Validating Lesson & its LO's are matched between CSV & Motion xml
        for ( Map.Entry<String, String> entry : uuidDetails.entrySet() ) {
            String errMsg = "";
            Map<String, String> csvLoRef = new TreeMap<String, String>();
            Map<String, String> XMLLORefDetails = new TreeMap<String, String>();
            String uuid = entry.getKey();
            String lessonName = entry.getValue();
            String[] gradeSplit = uuid.split( "_" );
            String LessonID = SMUtils.getReadingLessonID( lobJSDoc, gradeSplit[1], lessonName );

            CSVReader CSVLessopnreader = new CSVReader( new FileReader( configFilePath ) );
            csvLoRef = SMUtils.getLOByLessonUUID( CSVLessopnreader, gradeSplit[0] );

            if ( LessonID.equals( "" ) ) {
                Log.message( lessonName + "_" + gradeSplit[1] + " Not Present in CURRICULUM_TAXONOMYS_LOBJS" );
                unassignedLesson.add( lessonName + "_" + gradeSplit[1] );
            } else {
                XMLLORefDetails = SMUtils.getReadingLOSByLesson( resourceDoc, LessonID );

                String[] csvKey = csvLoRef.keySet().toArray( new String[0] );
                String[] csvVal = csvLoRef.values().toArray( new String[0] );

                String[] xmlKey = XMLLORefDetails.keySet().toArray( new String[0] );
                String[] xmlVal = XMLLORefDetails.values().toArray( new String[0] );
                Log.message( "Validating the LessonID :" + LessonID );
                if ( csvLoRef.size() == XMLLORefDetails.size() ) {
                    for ( int i = 0; i < csvLoRef.size(); i++ ) {
                        if ( ( csvKey[i].trim().equals( xmlKey[i] ) ) && ( csvVal[i].trim().equals( xmlVal[i] ) ) ) {

                        } else {
                            errMsg += "csvData: " + csvKey[i] + "=> " + csvVal[i] + " * xmlData: " + xmlKey[i] + "=> " + xmlVal[i] + " **";
                        }
                    }
                    if ( !errMsg.equals( "" ) ) {
                        Lessonstatus = false;
                        csvWriter.append( LessonID + "," );
                        csvWriter.append( "Data Mismatched" + "," );
                        csvWriter.append( "\"" + errMsg + "\"" + "\n" );
                    }

                } else if ( csvLoRef.size() < XMLLORefDetails.size() ) {
                    Lessonstatus = false;
                    List<String> CSVLOList = Arrays.asList( csvKey );
                    List<String> XMLLOList = Arrays.asList( xmlKey );
                    List<String> additionalDataInXML = new ArrayList<String>( XMLLOList );
                    additionalDataInXML.removeAll( CSVLOList );
                    if ( csvLoRef.size() == 0 ) {
                        csvWriter.append( LessonID + "," );
                        csvWriter.append( "LessonID not found in XML" + "\n" );
                    } else {
                        csvWriter.append( LessonID + "," );
                        csvWriter.append( "LO not found in CSV" + "," );
                        csvWriter.append( "\"" + "UUID: " + uuid + additionalDataInXML + "\"" + "\n" );
                    }
                } else if ( csvLoRef.size() > XMLLORefDetails.size() ) {
                    Lessonstatus = false;
                    List<String> CSVLOList = Arrays.asList( csvKey );
                    List<String> XMLLOList = Arrays.asList( xmlKey );
                    List<String> additionalDataInCSV = new ArrayList<String>( CSVLOList );
                    additionalDataInCSV.removeAll( XMLLOList );
                    if ( XMLLORefDetails.size() == 0 ) {
                        csvWriter.append( LessonID + "," );
                        csvWriter.append( "LessonID not found in XML" + "\n" );
                    } else {
                        csvWriter.append( LessonID + "," );
                        csvWriter.append( "LO not found in XML" + "," );
                        csvWriter.append( "\"" + "UUID: " + additionalDataInCSV + "\"" + "\n" );
                    }
                }
            }
        }

        csvWriter.append( "\n" );
        csvWriter.append( "\n" );
        csvWriter.append( "\n" );

        csvWriter.append( "Lesson UUID" + "," );
        csvWriter.append( "Result" + "," );
        csvWriter.append( "\n" );

        if ( !unassignedLesson.isEmpty() ) {
            for ( int i = 0; i < unassignedLesson.size(); i++ ) {
                csvWriter.append( "\"" + unassignedLesson.get( i ) + "\"" + "," );
                csvWriter.append( "Lesson ID Not found in CURRICULUM_TAXONOMYS_LOBJS.xml" + "\n" );

            }
        }

        Log.softAssertThat( Lessonstatus, "All the Lessson details and LO's correctly mapped", "Some CSV data's are mismatched / not found in the XML. " + "Please check test-output/HierarcyValidation/ReadingMismatchedMotionData.csv" );

        //Validating LO's IPM Details
        Boolean LOstatus = true;
        csvWriter.append( "\n" );
        csvWriter.append( "\n" );
        csvWriter.append( "\n" );

        csvWriter.append( "LO ID" + "," );
        csvWriter.append( "Result" + "," );
        csvWriter.append( "Details" + "," );
        csvWriter.append( "\n" );
        CSVReader reader = new CSVReader( new FileReader( configFilePath ) );
        nextLine = reader.readNext(); // To Skip headers
        while ( ( nextLine = reader.readNext() ) != null ) {
            String errMsg = "";
            Map<String, String> xmlData = new TreeMap<String, String>();
            Map<String, String> csvData = new TreeMap<String, String>();
            HashMap<String, String> csvLOData = new HashMap<String, String>();
            HashMap<String, String> xmlLOData = new HashMap<String, String>();
            String csvLO = nextLine[18];

            Log.message( "Validating for the LO: " + csvLO );

            if ( !csvLO.contains( "smre_pp" ) ) { //Print type LO's will not be available in motion xml

                //Validation of los section
                xmlLOData = SMUtils.getReadingLOStrandDetails( resourceDoc, csvLO );
                for ( int i = 0; i < CSVLOStrandpositions.length; i++ ) {
                    String val = nextLine[CSVLOStrandpositions[i]];
                    if ( val.equals( "Y" ) ) {
                        val = "true";
                    } else if ( val.equals( "N" ) ) {
                        val = "false";
                    }

                    csvLOData.put( CSVLOStrandNames[i], val );
                }
                if ( !xmlLOData.isEmpty() ) {
                    String[] csvKey = csvLOData.keySet().toArray( new String[0] );
                    String[] csvVal = csvLOData.values().toArray( new String[0] );

                    String[] xmlKey = xmlLOData.keySet().toArray( new String[0] );
                    String[] xmlVal = xmlLOData.values().toArray( new String[0] );

                    for ( int i = 0; i < csvLOData.size(); i++ ) {
                        if ( ( csvKey[i].trim().equals( xmlKey[i] ) ) && ( csvVal[i].trim().equals( xmlVal[i] ) ) ) {

                        } else {
                            errMsg += "csvData: " + csvKey[i] + "=> " + csvVal[i] + " * xmlData: " + xmlKey[i] + "=> " + xmlVal[i] + " **";
                        }
                    }
                } else {
                    LOstatus = false;
                    csvWriter.append( csvLO + "," );
                    csvWriter.append( "LO Not found in XML" + "\n" );
                }

                if ( errMsg != "" ) {
                    LOstatus = false;
                    csvWriter.append( csvLO + "," );
                    csvWriter.append( "Data Mismatced" + "," );
                    csvWriter.append( "\"" + errMsg + "\"" + "\n" );
                }
            }
        }

        Log.softAssertThat( LOstatus, "All the LO details are correctly mapped", "Some CSV data's are mismatched / not found in the XML. " + "Please check test-output/HierarcyValidation/ReadingMismatchedMotionResourcesXMLData.csv" );

        /*
         * skillobjective validation in resources.xml
         */

        Boolean skilObjStatus = true;
        csvWriter.append( "\n" );
        csvWriter.append( "\n" );
        csvWriter.append( "\n" );

        csvWriter.append( "************************** SkillObjective Validation ******************" + "\n" );
        csvWriter.append( "Skill Object ID" + "," );
        csvWriter.append( "Result" + "," );
        csvWriter.append( "Details" + "," );
        csvWriter.append( "\n" );

        String preReqFilePath = csvBasePath + configProperty.getProperty( "readingSkillPrereqFile" );
        CSVReader preReqreader = new CSVReader( new FileReader( preReqFilePath ) );

        nextLine = preReqreader.readNext(); // To Skip headers
        while ( ( nextLine = preReqreader.readNext() ) != null ) {
            String errMsg = "";
            Map<String, String> xmlData = new TreeMap<String, String>();
            Map<String, String> csvData = new TreeMap<String, String>();
            HashMap<String, String> csvLOData = new HashMap<String, String>();
            HashMap<String, String> xmlSkillData = new HashMap<String, String>();
            String ID = nextLine[0];

            xmlSkillData = SMUtils.getReadingSkillObjDetails( resourceDoc, ID );

            if ( !xmlSkillData.isEmpty() ) {
                if ( !nextLine[2].equals( xmlSkillData.get( "support1" ) ) ) {
                    errMsg += "csvData: support1 => " + nextLine[2] + " * xmlData: support1 => " + xmlSkillData.get( "support1" ) + " **";
                }
                if ( !nextLine[3].equals( xmlSkillData.get( "support2" ) ) ) {
                    errMsg += "csvData: support2 => " + nextLine[3] + " * xmlData: support2 => " + xmlSkillData.get( "support2" ) + " **";
                }
                if ( !nextLine[4].equals( xmlSkillData.get( "support3" ) ) ) {
                    errMsg += "csvData: support3 => " + nextLine[4] + " * xmlData: support3 => " + xmlSkillData.get( "support3" ) + " **";
                }
            } else {
                skilObjStatus = false;
                csvWriter.append( ID + "," );
                csvWriter.append( "Skillobjective  Not found in XML" + "\n" );
            }
            if ( !errMsg.isEmpty() ) {
                skilObjStatus = false;
                csvWriter.append( ID + "," );
                csvWriter.append( "Data Mismatced" + "," );
                csvWriter.append( "\"" + errMsg + "\"" + "\n" );
            }
        }

        Log.softAssertThat( skilObjStatus, "All the Skillobjective details are correctly mapped", "Some CSV data's are mismatched / not found in the XML. " + "Please check test-output/HierarcyValidation/ReadingMismatchedMotionResourcesXMLData.csv" );

        csvWriter.flush();
        csvWriter.close();
        /*
         * readingscos.xml Validation
         */

        String mismatchreadingscosFilePath = misbasePath + "ReadingMismatchedMotionreadingscosXMLData.csv";

        csvWriter = new FileWriter( mismatchreadingscosFilePath );
        Boolean readingSCOStatus = true;
        csvWriter.append( "SCO" + "," );
        csvWriter.append( "Result" + "," );
        csvWriter.append( "Details" + "," );
        csvWriter.append( "\n" );

        Document readscoDoc = db.parse( new URL( configProperty.getProperty( "SMAppUrl" ) + "/content/reading/resources/readingscos.xml" ).openStream() );

        String SCOPath = csvBasePath + configProperty.getProperty( "readingSharableObjFile" );
        CSVReader SCOreader = new CSVReader( new FileReader( SCOPath ) );

        nextLine = SCOreader.readNext(); // To Skip headers

        while ( ( nextLine = SCOreader.readNext() ) != null ) {
            String errMsg = "";
            Map<String, String> xmlData = new TreeMap<String, String>();
            Map<String, String> csvData = new TreeMap<String, String>();
            HashMap<String, String> csvSCOData = new HashMap<String, String>();
            HashMap<String, String> xmlSCOData = new HashMap<String, String>();
            String csvSCO = nextLine[0];

            if ( !csvSCO.contains( "smre_pp" ) ) {
                xmlSCOData = SMUtils.getReadingSCODetails( readscoDoc, csvSCO );
                if ( !xmlSCOData.isEmpty() ) {

                    String csvScorable = "";
                    Log.message( csvSCO + ": " + nextLine[1].trim() );
                    if ( nextLine[1].trim().toUpperCase().equals( "FALSE" ) ) {
                        csvScorable = "0";
                    } else {
                        csvScorable = "1";
                    }
                    if ( !csvScorable.equals( xmlSCOData.get( "isScorable" ) ) ) {
                        errMsg += "csvData: isScorable => " + csvScorable + " * xmlData: isScorable => " + xmlSCOData.get( "isScorable" ) + " ** ";
                    }
                    if ( !xmlSCOData.get( "launchData" ).contains( nextLine[3] ) ) {
                        //					if(!nextLine[3].equals(xmlSCOData.get("launchData"))) {
                        errMsg += "csvData: launchData => " + nextLine[3] + " * xmlData: launchData => " + xmlSCOData.get( "launchData" ) + " ** ";
                    }
                } else {
                    readingSCOStatus = false;
                    csvWriter.append( csvSCO + "," );
                    csvWriter.append( "SCO Not found in XML" + "\n" );
                }

                if ( errMsg != "" ) {
                    readingSCOStatus = false;
                    csvWriter.append( csvSCO + "," );
                    csvWriter.append( "Data Mismatced" + "," );
                    csvWriter.append( "\"" + errMsg + "\"" + "\n" );
                }
            }
        }

        Log.softAssertThat( readingSCOStatus, "All the SCO details are correctly mapped", "Some SCO CSV data's are mismatched / not found in the XML. " + "Please check test-output/HierarcyValidation/ReadingMismatchedMotionreadingscosXMLData.csv" );

        csvWriter.flush();
        csvWriter.close();
        /*
         * readingloscos.xml validation
         */
        String mismatchreadingloscosFilePath = misbasePath + "ReadingMismatchedMotionreadingloscosXMLData.csv";

        csvWriter = new FileWriter( mismatchreadingloscosFilePath );
        Boolean loSCOStatus = true;
        csvWriter.append( "LOID" + "," );
        csvWriter.append( "Result" + "," );
        csvWriter.append( "Details" + "," );
        csvWriter.append( "\n" );

        Document readLOSCODoc = db.parse( new URL( configProperty.getProperty( "SMAppUrl" ) + "/content/reading/resources/readingloscos.xml" ).openStream() );

        CSVReader LOSCOSCOreader = new CSVReader( new FileReader( SCOPath ) );

        List<String> LOLIST = SMUtils.getReadingUniqueLOSCODetails( LOSCOSCOreader );

        List<String> XMLLOLIST = SMUtils.getReadingLOSCOList( readLOSCODoc );

        if ( XMLLOLIST.size() > LOLIST.size() ) {
            loSCOStatus = false;
            List<String> differences = new ArrayList<>( XMLLOLIST );
            differences.removeAll( LOLIST );
            for ( int i = 0; i < differences.size(); i++ ) {
                csvWriter.append( differences.get( i ) + "," );
                csvWriter.append( "LO Not found in CSV" + "\n" );
            }
        }

        if ( XMLLOLIST.size() < LOLIST.size() ) {
            loSCOStatus = false;
            List<String> differences = new ArrayList<>( LOLIST );
            differences.removeAll( XMLLOLIST );
            for ( int i = 0; i < differences.size(); i++ ) {
                csvWriter.append( differences.get( i ) + "," );
                csvWriter.append( "LO Not found in XML" + "\n" );
            }
        }

        for ( int i = 0; i < LOLIST.size(); i++ ) {
            String errMsg = "";
            Map<String, String> xmlData = new TreeMap<String, String>();
            Map<String, String> csvData = new TreeMap<String, String>();
            String LOID = LOLIST.get( i );

            CSVReader SCOFetchreader = new CSVReader( new FileReader( SCOPath ) );
            nextLine = SCOFetchreader.readNext(); // To Skip headers
            csvData = SMUtils.getReadingSCOByLO( SCOFetchreader, LOID );

            xmlData = SMUtils.getReadingLOSCOOrderDetails( readLOSCODoc, LOID );

            String[] csvKey = csvData.keySet().toArray( new String[0] );
            String[] csvVal = csvData.values().toArray( new String[0] );

            String[] xmlKey = xmlData.keySet().toArray( new String[0] );
            String[] xmlVal = xmlData.values().toArray( new String[0] );

            if ( csvData.size() == xmlData.size() ) {
                for ( int j = 0; j < csvData.size(); j++ ) {
                    if ( ( csvKey[j].trim().equals( xmlKey[j] ) ) && ( csvVal[j].trim().equals( xmlVal[j] ) ) ) {

                    } else {
                        errMsg += "csvData: " + csvKey[j] + "=> " + csvVal[j] + " * xmlData: " + xmlKey[j] + "=> " + xmlVal[j] + " **";
                    }
                }
                if ( !errMsg.equals( "" ) ) {
                    loSCOStatus = false;
                    csvWriter.append( LOID + "," );
                    csvWriter.append( "Data Mismatched" + "," );
                    csvWriter.append( "\"" + errMsg + "\"" + "\n" );
                }

            } else if ( csvData.size() < xmlData.size() ) {
                loSCOStatus = false;
                List<String> CSVLOList = Arrays.asList( csvKey );
                List<String> XMLLOList = Arrays.asList( xmlKey );
                List<String> additionalDataInXML = new ArrayList<String>( XMLLOList );
                additionalDataInXML.removeAll( CSVLOList );
                if ( csvData.size() == 0 ) {
                    csvWriter.append( LOID + "," );
                    csvWriter.append( "LOID not found in XML" + "\n" );
                } else {
                    csvWriter.append( LOID + "," );
                    csvWriter.append( "SCO not found in CSV" + "," );
                    csvWriter.append( "\"" + additionalDataInXML + "\"" + "\n" );
                }
            } else if ( csvData.size() > xmlData.size() ) {
                loSCOStatus = false;
                List<String> CSVLOList = Arrays.asList( csvKey );
                List<String> XMLLOList = Arrays.asList( xmlKey );
                List<String> additionalDataInCSV = new ArrayList<String>( CSVLOList );
                additionalDataInCSV.removeAll( XMLLOList );
                if ( xmlData.size() == 0 ) {
                    csvWriter.append( LOID + "," );
                    csvWriter.append( "LOID not found in XML" + "\n" );
                } else {
                    csvWriter.append( LOID + "," );
                    csvWriter.append( "SCO not found in XML" + "," );
                    csvWriter.append( "\"" + additionalDataInCSV + "\"" + "\n" );
                }
            }
        }
        //			Log.softAssertThat(loSCOStatus, "All the LO & SCO details are correctly mapped",
        //				"Some LO & SCO CSV data's are mismatched / not found in the XML. "
        //						+ "Please check test-output/HierarcyValidation/ReadingMismatchedMotionreadingloscosXMLData.csv");

        csvWriter.flush();
        csvWriter.close();
    }

    @Test ( description = "Verify state standards data between Alfressco and SMDB for Reading", priority = 1 )
    public void TcReadingStateAlignment() throws Exception {

        Log.testCaseInfo( "Verify state standards data between Alfressco and SMDB for Reading" );
        String stateBasePath = csvBasePath + File.separator + "Readingstatestandard" + File.separator;
        String outputbasePath = new File( "." ).getCanonicalPath() + File.separator + "test-output" + File.separator + "HierarchyValidation" + File.separator;

        int failCount = 0;

        FileReader fr = new FileReader( queriesBasePath + "getMathHierarchy.sql" );
        BufferedReader br = new BufferedReader( fr );

        StringBuilder sb = new StringBuilder();
        String sqlLine;
        while ( ( sqlLine = br.readLine() ) != null ) {
            sb.append( sqlLine );
        }
        br.close();

        String query = sb.toString();

        List<Object[]> records = SQLUtil.executeQuery( query );

        List<String> SMDBHiearList = new ArrayList<String>();
        for ( Object[] list : records ) {
            if ( list.length > 0 ) {
                SMDBHiearList.add( list[0].toString() );
            }
        }

        List<String> fileList = new ArrayList<String>();

        File[] files = new File( stateBasePath ).listFiles();

        for ( File file : files ) {
            if ( file.isFile() ) {
                fileList.add( file.getName() );
            }
        }

        Log.assertThat( fileList.size() != 0, "State Standard CSV file is available in test data folder", "No State standard CSV file for verification in test data folder" );

        //To remove .DS_Store file which might come while unzipping the hierarchyValidation folder
        if ( fileList.contains( ".DS_Store" ) ) {
            fileList.remove( ".DS_Store" );
        }

        for ( int i = 0; i < fileList.size(); i++ ) {
            HashMap<String, String> csvHierarchy = new HashMap<String, String>();
            Map<String, String> csvHierarchyMap = new TreeMap<String, String>();
            HashMap<String, String> dbHierarchy = new HashMap<String, String>();
            Map<String, String> dbHierarchyMap = new TreeMap<String, String>();
            String standardName = "";

            String fileName = fileList.get( i );
            String stateStdcsvFilePath = stateBasePath + fileName;

            Log.message( "Validating the file: " + fileName );

            CSVReader reader = new CSVReader( new FileReader( stateStdcsvFilePath ) );
            String[] nextLine;

            nextLine = reader.readNext(); // To Skip headers
            int columnCount = nextLine.length;

            while ( ( nextLine = reader.readNext() ) != null ) {
                String stateHierarchy = "";
                String loID = nextLine[columnCount - 1];
                standardName = nextLine[0];
                for ( int j = 0; j < columnCount - 1; j++ ) {
                    if ( !nextLine[j].equals( "" ) ) {
                        stateHierarchy = stateHierarchy + nextLine[j].trim() + ">>";
                    }
                }
                stateHierarchy = stateHierarchy.substring( 0, stateHierarchy.length() - 2 );
                csvHierarchy.put( stateHierarchy, loID );
                csvHierarchyMap.putAll( csvHierarchy );
            }
            Log.message( "Validating the standardName: " + standardName );

            fr = new FileReader( queriesBasePath + "getMathStateAlignment.sql" );
            br = new BufferedReader( fr );

            sb = new StringBuilder();
            String sqlLine1;
            while ( ( sqlLine1 = br.readLine() ) != null ) {
                sb.append( sqlLine1 );
            }
            br.close();

            query = sb.toString();

            standardName = standardName.replace( "'", "''" );
            query = query.replace( "<standard_name>", standardName );
            records = SQLUtil.executeQuery( query );

            List<String> SMDBarrList = new ArrayList<String>();
            for ( Object[] list : records ) {
                if ( list.length > 0 ) {
                    dbHierarchy.put( list[0].toString().trim(), list[1].toString() );
                }
            }
            dbHierarchyMap.putAll( dbHierarchy );

            fileName = fileName.replace( " ", "_" );
            File dir = new File( outputbasePath );
            dir.mkdir();
            String csvoutputePath = outputbasePath + "Mismatched_" + fileName;

            FileWriter csvWriter = new FileWriter( csvoutputePath );
            csvWriter.append( "Standards" + "," );
            csvWriter.append( "Grade in Alignment" + "," );
            csvWriter.append( "LO ID" + "," );
            csvWriter.append( "Course Level in DB" + "," );
            csvWriter.append( "\n" );

            String errMsg = "";
            String[] csvKey = csvHierarchyMap.keySet().toArray( new String[0] );
            String[] csvVal = csvHierarchyMap.values().toArray( new String[0] );

            String[] dbKey = dbHierarchyMap.keySet().toArray( new String[0] );
            String[] dbVal = dbHierarchyMap.values().toArray( new String[0] );

            //Validating the course level of LO

            for ( int x = 0; x < csvVal.length; x++ ) {
                String[] loArray = csvVal[x].replace( ";;", ";" ).split( ";" );
                String[] gradeSplit = csvKey[x].split( ">>" );
                String grade = gradeSplit[1];
                if ( grade.equals( "Grade K" ) ) {
                    grade = "Grade 0";
                }

                Float gradeLevel = Float.parseFloat( grade.replaceAll( "[\\D]", "" ) );

                for ( int y = 0; y < loArray.length; y++ ) {
                    String LOinStateCSV = loArray[y].trim();
                    for ( int z = 0; z < SMDBHiearList.size(); z++ ) {
                        String hierarchyRecord = SMDBHiearList.get( z );
                        if ( hierarchyRecord.contains( LOinStateCSV ) ) {
                            Float courseLevel = Float.parseFloat( hierarchyRecord.substring( hierarchyRecord.length() - 3 ) ) / 100;

                            if ( gradeLevel > courseLevel ) {
                                csvWriter.append( "\"" + standardName + "\"" + "," );
                                csvWriter.append( grade + "," );
                                csvWriter.append( LOinStateCSV + "," );
                                csvWriter.append( courseLevel + "\n" );
                            }
                        }
                    }
                }

            }

            csvWriter.append( "\n" );
            csvWriter.append( "\n" );
            csvWriter.append( "\n" );
            csvWriter.append( "\n" );
            csvWriter.append( "Standards" + "," );
            csvWriter.append( "Result" + "," );
            csvWriter.append( "Details" + "," );
            csvWriter.append( "\n" );

            Log.message( "Size: " + "DB Size: " + dbHierarchyMap.size() + "CSV Size: " + csvHierarchyMap.size() );
            Boolean status = true;

            if ( dbHierarchyMap.size() == csvHierarchyMap.size() ) {

                for ( int j = 0; j < dbHierarchyMap.size(); j++ ) {
                    Boolean StandardMatched = false;
                    String csvLOSort = "";
                    String dbLOSort = "";
                    errMsg = "";
                    for ( int k = 0; k < dbHierarchyMap.size(); k++ ) {
                        //CSV with DB
                        if ( ( csvKey[j].trim().equals( dbKey[k] ) ) ) { // && (csvVal[j].trim().equals(dbVal[k]))) {
                            String[] csvValSplit = csvVal[j].split( ";" );
                            String[] dbValValSplit = dbVal[k].split( ";" );

                            Arrays.sort( csvValSplit );
                            Arrays.sort( dbValValSplit );
                            for ( int x = 0; x < csvValSplit.length; x++ ) {
                                if ( !csvValSplit[x].equals( "" ) ) {
                                    csvLOSort = csvLOSort + csvValSplit[x] + ";";
                                }
                            }

                            for ( int y = 0; y < dbValValSplit.length; y++ ) {
                                if ( !dbValValSplit[y].equals( "" ) ) {
                                    dbLOSort = dbLOSort + dbValValSplit[y] + ";";
                                }
                            }
                            if ( csvLOSort.equals( dbLOSort ) ) {
                                StandardMatched = true;
                                break;
                            }
                        }
                    }
                    if ( !StandardMatched ) {
                        errMsg += "csvData: " + csvKey[j] + "=> " + csvLOSort;
                        Log.message( "Data missed in DB: " + errMsg );
                        status = false;
                        failCount++;
                        csvWriter.append( "\"" + standardName + "\"" + "," );
                        csvWriter.append( "Data Missed / Mismatched" + "," );
                        csvWriter.append( "\"" + errMsg + "\"" + "\n" );
                    }

                }

                //DB With CSV

                for ( int j = 0; j < dbHierarchyMap.size(); j++ ) {
                    Boolean StandardMatched = false;
                    String csvLOSort = "";
                    String dbLOSort = "";
                    errMsg = "";
                    for ( int k = 0; k < dbHierarchyMap.size(); k++ ) {
                        //CSV with DB
                        if ( ( dbKey[j].trim().equals( csvKey[k] ) ) ) { // && (csvVal[j].trim().equals(dbVal[k]))) {
                            String[] csvValSplit = csvVal[k].split( ";" );
                            String[] dbValValSplit = dbVal[j].split( ";" );

                            Arrays.sort( csvValSplit );
                            Arrays.sort( dbValValSplit );
                            for ( int x = 0; x < csvValSplit.length; x++ ) {
                                if ( !csvValSplit[x].equals( "" ) ) {
                                    csvLOSort = csvLOSort + csvValSplit[x] + ";";
                                }
                            }

                            for ( int y = 0; y < dbValValSplit.length; y++ ) {
                                if ( !dbValValSplit[y].equals( "" ) ) {
                                    dbLOSort = dbLOSort + dbValValSplit[y] + ";";
                                }
                            }
                            if ( dbLOSort.equals( csvLOSort ) ) {
                                StandardMatched = true;
                                break;
                            }
                        }
                    }
                    if ( !StandardMatched ) {
                        errMsg += "DBData: " + dbKey[j] + "=> " + dbLOSort;
                        Log.message( "Data missed in CSV: " + errMsg );
                        status = false;
                        failCount++;
                        csvWriter.append( "\"" + standardName + "\"" + "," );
                        csvWriter.append( "Data Missed in CSV" + "," );
                        csvWriter.append( "\"" + errMsg + "\"" + "\n" );
                    }

                }

            } else if ( csvHierarchyMap.size() < dbHierarchyMap.size() ) {
                status = false;
                failCount++;
                List<String> CSVList = Arrays.asList( csvKey );
                List<String> DBList = Arrays.asList( dbKey );

                List<String> additionalDataInDB = new ArrayList<String>( DBList );
                additionalDataInDB.removeAll( CSVList );
                Log.failsoft( "Additional Data Present in DB: " + additionalDataInDB );
                csvWriter.append( "\"" + standardName + "\"" + "," );
                csvWriter.append( "Additional Data in DB" + "," );
                csvWriter.append( "\"" + additionalDataInDB + "\"" + "\n" );
            } else {
                status = false;
                failCount++;
                List<String> CSVList = Arrays.asList( csvKey );
                List<String> DBList = Arrays.asList( dbKey );

                List<String> additionalDataInCSV = new ArrayList<String>( CSVList );
                additionalDataInCSV.removeAll( DBList );
                for ( int k = 0; k < additionalDataInCSV.size(); k++ ) {
                    csvWriter.append( "\"" + standardName + "\"" + "," );
                    csvWriter.append( "Data Missed in DB" + "," );
                    csvWriter.append( "\"" + additionalDataInCSV.get( k ) + "\"" + "\n" );
                }
                csvWriter.append( "Data Missed in DB" + "," );
                Log.failsoft( "Data Missed in DB: " + additionalDataInCSV );
            }
            if ( status ) {
                Log.message( "standardName: " + standardName + " all the data matched with DB" );
            }
            //          Log.softAssertThat(status, fileName + " Data matched with DB", 
            //                  "Some Data mismatched / not found. Please check report and " + csvoutputePath );
            csvWriter.flush();
            csvWriter.close();
        }
        //         Log.assertThat(failCount == 0, "Math State standard data matched with DB", 
        //               "Some Sate standard Data mismatched / not found. Please check report and " + outputbasePath + " folder for mismatced information");
    }

}