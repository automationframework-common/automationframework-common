package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

public class RestoreDeletedAssignments extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String districtId;
    private String teacherId;
    private String assignmentID;
    private String AssignmentUserId;
    private String CourseId;
    RBSUtils rbsutils = new RBSUtils();
    Map<String, String> assignmentResponse = new HashMap<>();
    private String studentDetail;
    private String studentUserID;
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        districtId = configProperty.getProperty( "district_ID" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( priority = 1, dataProvider = "RestoreAssignmentsPositiveFlow", groups = { "SMK-51939", "smoke_test_case", "RestoreDeletedAssignmentsAPI", "P1", "API" } )
    public void tcPostiveforRestoreAssignmentsAPI( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> GroupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        String endpoint = "null";

        studentRumbaIds.add( studentUserID );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

        HashMap<String, String> Response = new HashMap<>();
        HashMap<String, String> DeleteAssignmentRespose = new HashMap<>();

        GroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( groupAPI.createGroup( smUrl, GroupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }
        switch ( scenario ) {
            case "Default Math Assignment Restore":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                break;
            case "Default Reading Assignment Restore":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                break;
            case "Focus Reading Assignment Restore":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "5" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                break;
            case "Focus Math Assignment Restore":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "3" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                break;
            case "Custom By Skills - Math Assignment Restore":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.SKILL,
                        String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                break;
            case "Custom By Settings - Math Assignment Restore":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.SETTINGS,
                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                break;
            case "Custom By Standard - Math Assignment Restore":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.STANDARD,
                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                break;
            case "Custom By Skills - Reading Assignment Restore":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.SKILL,
                        String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                break;
            case "Custom By Settings - Reading Assignment Restore":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.SETTINGS,
                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                break;
            case "Custom By Standard - Reading Assignment Restore":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.STANDARD,
                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                break;
            default:
                Log.message( "Case is invalid" );
                break;

        }

        HashMap<String, String> response = restoreDeletedAssignment( smUrl, assignmentDetails, endpoint );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + response.get( "body" ) );
        Log.testCaseResult();

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "RestoreAssignmentsPositiveFlow" )
    public Object[][] RestoreAssignmentsPositiveFlow() {

        Object[][] inputData = { { "Validate 200 for Restore Math Assignment", "Default Math Assignment Restore", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Restore Reading Assignment", "Default Reading Assignment Restore", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Restore Focus Reading Assignment", "Focus Reading Assignment Restore", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Restore Focus Math Assignment", "Focus Math Assignment Restore", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Restore Custom By Skills - Math Assignment", "Custom By Skills - Math Assignment Restore", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Restore Custom By Settings - Math Assignment", "Custom By Settings - Math Assignment Restore", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Restore Custom By Standard - Math Assignment", "Custom By Standard - Math Assignment Restore", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Restore Custom By Skills - Reading Assignment", "Custom By Skills - Reading Assignment Restore", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Restore Custom By Settings - Reading Assignment", "Custom By Settings - Reading Assignment Restore", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Restore Custom By Standard - Reading Assignment", "Custom By Standard - Reading Assignment Restore", CommonAPIConstants.STATUS_CODE_OK }

        };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "RestoreAssignmentsNegativeFlow", groups = { "SMK-51939", "RestoreAssignmentsAPI", "RestoreAssignmentsAPI", "P2", "API" } )
    public void tcNegativeforRestoreAssignmentsAPI( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> GroupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        String endpoint = "null";

        studentRumbaIds.add( studentUserID );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

        HashMap<String, String> Response = new HashMap<>();
        HashMap<String, String> DeleteAssignmentRespose = new HashMap<>();

        GroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( groupAPI.createGroup( smUrl, GroupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }

        String exception = null;
        String message = null;
        boolean status = false;

        switch ( scenario ) {
            case "Restore not deleted focus math course":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "3" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = CommonAPIConstants.USER_ALREADY_RESTORED;
                status = true;
                break;
            case "Incorrect assignmentUserId":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "3" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, "1234$" );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                exception = CommonAPIConstants.MESSAGE_NOT_READABLE_EXCEPTION;
                break;
            case "Incorrect ord-id":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "3" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, "1234$" );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;
            case "Invalid StaffId":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "3" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, "1234$" );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            case "Empty assignmentUserId in request body":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "3" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, "  " );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                exception = CommonAPIConstants.MESSAGE_NOT_READABLE_EXCEPTION;
                break;
            case "Invalid end point":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "3" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, "  " );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                endpoint = AssignmentAPIConstants.RESTORE_DELETED_ASSIGNMENTS;
                endpoint = endpoint.replace( "assignments", "assignmentsss" );
                break;
            case "Invalid User as Teacher instead of Admin":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "3" );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                DeleteAssignmentRespose = deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.message( DeleteAssignmentRespose.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            default:
                Log.message( "Case is invalid" );
                break;

        }

        HashMap<String, String> response = restoreDeletedAssignment( smUrl, assignmentDetails, endpoint );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + response.get( "body" ) );
        if ( message != null ) {
            verifyException( response.get( "body" ), exception, status, message );
        }
        Log.testCaseResult();

    }

    /**
     * Data provider for negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "RestoreAssignmentsNegativeFlow" )
    public Object[][] RestoreAssignmentsNegativeFlow() {

        Object[][] inputData = { { "Verify the status code is 400 while trying to restore the not deleted Focus math assignment", "Restore not deleted focus math course", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the status code is 400 when the assignmentUserId is incorrect", "Incorrect assignmentUserId", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the status code is 403 when the incorrect ord-id passed in headers section", "Incorrect ord-id", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code is 401 when the Invalid StaffId passed in headers section", "Invalid StaffId", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify that the status code is 400 without passing assignmentUserId in request body", "Empty assignmentUserId in request body", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify that the status code is 404 while passing invalid end point", "Invalid end point", CommonAPIConstants.STATUS_CODE_NOTFOUND },
                { "Verify the status code is 401 when the teacher user used instead of admin user", "Invalid User as Teacher instead of Admin", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },

        };
        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }
}
