package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

/**
 * To test the get assignments by Group ID
 * 
 * @author manikanda.nagendran
 *
 */
public class GetAssignmentsyGroupID extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherUsername;
    List<String> studentRumbaIds = new ArrayList<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(school , teacherUsername), Constants.USERID_HEADER) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(school , teacherUsername), Constants.USERID_HEADER) );
   
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    /**
     * Tests the positive scenarios of create group.
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( dataProvider = "getAssignementPositiveScenariosData", groups = { "SMK-51911", "smoke_test_case", "Assignments", "Group Assignments", "P1", "API" } )
    public void GetAssignmentsyGroupID001( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();

        List<String> requestIds = new ArrayList<>();
        List<String> mathCourseIds = new ArrayList<String>();
        List<String> readingCourseIds = new ArrayList<String>();
        List<String> expectedCourseIds = new ArrayList<String>();
        ArrayList<String> actualcourseIds = new ArrayList<String>();

        String groupName = "Successmaker API Test Group " + System.nanoTime();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        String teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        String organizationId = RBSDataSetup.organizationIDs.get( school );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

        readingCourseIds.add( "2" );
        readingCourseIds.add(
                courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), organizationId.toString(), DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) ) );
        readingCourseIds.add( courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), organizationId.toString(), DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) ) );
        readingCourseIds.add(
                courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), organizationId.toString(), DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) ) );

        mathCourseIds.add( "1" );
        mathCourseIds.add( courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), organizationId.toString(), DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) ) );
        mathCourseIds.add( courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), organizationId.toString(), DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) ) );
        mathCourseIds.add( courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), organizationId.toString(), DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) ) );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

        HashMap<String, String> response = new HashMap<>();
        assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, mathCourseIds );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( "body" ), "data,groupId" );

        requestIds.add( groupId );
        assignmentDetails.put( AssignmentAPIConstants.GROUP_ID, groupId );

        try {
            switch ( scenario ) {

                case "GET ASSIGNMENTS FROM GROUP MATH":

                    mathCourseIds.forEach( courseID -> {
                        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseID );

                        try {

                            HashMap<String, String> assignResponse = new HashMap<>();
                            assignResponse = assignAssignment( smUrl, assignmentDetails, requestIds, AssignmentAPIConstants.GROUPS_TYPE );

                            Log.assertThat( assignResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Assignment assigned successfully", "Assignment not assigned successfully" );



                        } catch ( Exception e ) {
                            Log.fail( "Assigning Reading assignment to multiple students failed: " + e );
                        }

                    } );
                    expectedCourseIds = mathCourseIds;

                    break;

                case "GET ASSIGNMENTS FROM GROUP READING":

                    readingCourseIds.forEach( courseID -> {

                        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseID );

                        try {
                            HashMap<String, String> assignResponse = new HashMap<>();
                            assignResponse = assignAssignment( smUrl, assignmentDetails, requestIds, AssignmentAPIConstants.GROUPS_TYPE );

                            Log.assertThat( assignResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Assignment assigned successfully", "Assignment not assigned successfully" );

                        } catch ( Exception e ) {
                            Log.fail( "Assigning Reading assignment to multiple students failed: " + e );
                        }

                    } );
                    expectedCourseIds = readingCourseIds;

                    break;

                case "NO ASSIGNMENTS":

                    Log.message( "No Assignments assigned" );

                    break;

                default:
                    Log.fail( "Invalid case " + scenario );

            }
        } catch ( Exception e ) {
            Log.fail( "Exception : " + e );
        }

        response = getGroupAssignmentLists( smUrl, assignmentDetails );
        Log.message( "response: " + response );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "getAssignmentbyGroupID", response.get( Constants.STATUS_CODE ), response.get( "body" ) ), "Schema is returned as expected.", "Schema is not as expected." );

        actualcourseIds = SMUtils.getAllKeyValueFromJsonArray( response.get( "body" ), "id" );
        Log.assertThat( SMUtils.compareTwoList( expectedCourseIds, actualcourseIds ), "Assignment List matched with groups", "Assignment List not matched with groups" );

        Log.testCaseResult();

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "getAssignementPositiveScenariosData" )
    public Object[][] getAssignementValidtData() {

        Object[][] inputData = { { "Verify that the status code is 200 and response is as expected while passing valid input for MATH", "GET ASSIGNMENTS FROM GROUP MATH", "200" },
                { "Verify that the status code is 200 and response is as expected while passing valid input for READING", "GET ASSIGNMENTS FROM GROUP READING", "200" },

        };
        return inputData;
    }

    @Test ( dataProvider = "getAssignementNegativeScenariosData", groups = { "SMK-51911", "Assignments", "Group Assignments", "P1", "API" } )
    public void GetAssignmentsyGroupID002( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        Map<String, String> headers = new HashMap<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> response = new HashMap<>();
        //Parameters
        HashMap<String, String> params = new HashMap<>();

        String groupName = "Successmaker API Test Group " + System.nanoTime();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

        //Valid GroupID
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

        HashMap<String, String> groupRresponse = new HashMap<>();
        groupRresponse = groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );

        String validGroupID = SMUtils.getKeyValueFromResponse( groupRresponse.get( "body" ), "data,groupId" );

        String orgID = null;

        String teacherID = null;
        String groupID = null;
        String exception = null;
        String message = null;
        boolean status = false;

        switch ( scenario ) {

            case "NO ASSIGNMENTS":
                teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
                orgID = RBSDataSetup.organizationIDs.get( school );
                groupID = validGroupID;
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.ASSIGNMENT_NOT_FOUND_MESSAGE;
                status = true;

                Log.message( "No Assignments assigned" );

                break;

            case "INVALID GROUP ID":

                teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
                orgID = RBSDataSetup.organizationIDs.get( school );

                groupID = "zzz";
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = CommonAPIConstants.GROUP_NOT_FOUND_MESSAGE;
                status = true;

                break;

            case "INVALID ORG ID":

                teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
                orgID = "jhgdfhg558875";
                groupID = validGroupID;

                break;

            case "INVALID TEACHER ID":

                orgID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
                teacherID = "54334";

                groupID = validGroupID;

                break;

            case "EMPTY ORG ID":

                orgID = " ";
                teacherID = RBSDataSetup.organizationIDs.get( school );
                groupID = validGroupID;
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = CommonAPIConstants.ORGID_EMPTY;
                status = true;

                break;

            default:
                Log.fail( "Invalid case " + scenario );
        }

        String endPoint = AssignmentAPIConstants.GET_GROUP_ASSIGNMENTS_API;
        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{groupID}", groupID );

        if ( endPoint.contains( "//" ) ) {
            endPoint = endPoint.replace( "/ /", "//" );
        }

        response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
        Log.message( "response: " + response );

        Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

        verifyResponse( response.get( "body" ), response.get( Constants.STATUS_CODE ) );
        verifyException( response.get( "body" ), exception, status, message );

        Log.testCaseResult();
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "getAssignementNegativeScenariosData" )
    public Object[][] getAssignementInvalidData() {

        Object[][] inputData = { { "Verify the status code as 200 and message \"Assignment Details Not found\"  displays in response body when no assignment assigned to that group", "NO ASSIGNMENTS", "200" },

                { "Verify that the status code is 400 and response is as expected while passing combination of valid and invalid ids to add groups to single course POST API\r\n" + " Create 2 groups and 1 content base id", "INVALID GROUP ID", "400" },
                { "Verify that the status code is 400 and response is as expected while passing invalid organizationId to add students/groups to single course POST API", "INVALID ORG ID", "400" },

                { "Verify that the status code is 400 and response is as expected while passing invalid organizationId to add students/groups to single course POST API", "INVALID TEACHER ID", "400" },
                { "Verify that the status code is 400 and response is as expected while passing invalid organizationId to add students/groups to single course POST API", "EMPTY ORG ID", "400" },

        };

        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    /**
     * Verify the response data
     * 
     * @param expectedResponse
     * @param actualResponse
     * @param withStudent
     * @return
     * @throws IOException
     */
    public boolean verifyResponse( String actualResponse, String statusCode ) throws IOException {
        boolean isVerified = false;

        Log.assertThat( new SMAPIProcessor().isSchemaValid( "200_DataNotFoundSchema", statusCode, actualResponse ), "Schema is returned as expected.", "Schema is not as expected." );

        return isVerified;
    }

}
