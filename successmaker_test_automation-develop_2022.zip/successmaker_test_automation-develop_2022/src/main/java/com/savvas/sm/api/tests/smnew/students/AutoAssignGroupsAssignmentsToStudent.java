package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import io.restassured.response.Response;

public class AutoAssignGroupsAssignmentsToStudent extends AssignmentAPI {

	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	private String smUrl;
	private String teacherDetails = null;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String orgId;
	private String teacherId;
	private String assignmentID;
	private String assignmentUserId;
	private String studentDetail;
	private String studentUserID;
	private String studentUsername;
	private String courseName;
	Map<String, String> response = new HashMap<>();
	Map<String, String> assignmentResponse = new HashMap<>();
	GroupAPI groupAPI;
	CourseAPI courseAPI;
	SMAPIProcessor smAPIprocessor;

	 @BeforeClass ( alwaysRun = true )
	public void BeforeTest() {
		smUrl = configProperty.getProperty("SMAppUrl");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		orgId = RBSDataSetup.organizationIDs.get(school);
		teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, Constants.USERID_HEADER);
		studentDetail = RBSDataSetup.getMyStudent(school,
				SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME));
		studentUserID = SMUtils.getKeyValueFromResponse(RBSDataSetup.orgStudentDetails.get(school).get("Student1"),
				"userId");
		studentUsername = SMUtils.getKeyValueFromResponse(RBSDataSetup.orgStudentDetails.get(school).get("Student1"),
				"userName");
		SMUtils.getKeyValueFromResponse(studentDetail, "firstName").toString();
		SMUtils.getKeyValueFromResponse(studentDetail, "lastName").toString();
		groupAPI = new GroupAPI();
		courseAPI = new CourseAPI();
		smAPIprocessor = new SMAPIProcessor();
	}

	/**
	 * Tests the positive scenarios of create group.
	 * 
	 * @param description
	 * @param scenario
	 * @param statusCode
	 * @throws Exception
	 */
	@Test(dataProvider = "autoAssignPositiveScenarios", groups = { "smoke_test_case", "SMK-56681", "Assignments",
			"Create Assignments", "P1", "API" })
	public void tcassignAssignment001(String description, String scenario, String statusCode) throws Exception {

		Log.testCaseInfo(description);

		HashMap<String, String> assignmentDetails = new HashMap<>();

		HashMap<String, String> groupdetails = new HashMap<>();
		List<String> studentRumbaIds = new ArrayList<>();
		String removeAssignEndpoint = "null";

		// Addding three students into the group
		studentRumbaIds.add(
				SMUtils.getKeyValueFromResponse(RBSDataSetup.orgStudentDetails.get(school).get("Student1"), "userId"));
		studentRumbaIds.add(
				SMUtils.getKeyValueFromResponse(RBSDataSetup.orgStudentDetails.get(school).get("Student2"), "userId"));

		String token = new RBSUtils().getAccessToken(
				SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		groupdetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		groupdetails.put(GroupConstants.GROUP_OWNER_ID, teacherId);
		groupdetails.put(GroupConstants.GROUP_OWNER_ORG_ID, orgId);
		groupdetails.put(GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime());
		new GroupAPI().createGroup(smUrl, groupdetails, studentRumbaIds);

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);

		String CourseId;
		try {

			Map<String, String> headers = new HashMap<>();
			headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
			switch (scenario) {

			case "Default Math":
				courseName = Constants.MATH;
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH);
				String accessTokenMath = new RBSUtils().getAccessToken(studentUsername,
						RBSDataSetupConstants.DEFAULT_PASSWORD);
				assignmentResponse = assignAssignment(smUrl, assignmentDetails, studentRumbaIds,
						AssignmentAPIConstants.USERS_TYPE);
				Log.message("assignmentResponse=" + assignmentResponse);
				assignmentID = SMUtils.getKeyValueFromResponse(assignmentResponse.get(Constants.RESPONSE_BODY),
						"data,assignmentId");
				assignmentUserId = new SqlHelperCourses().getAssignmentUserId(studentUserID, assignmentID);
				Log.message("assignmentUserId =" + assignmentUserId);

				// Remove Assignment
				assignmentDetails.put(AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId);
				HashMap<String, String> getresponseDefaultMath = removeStudentAssignment(smUrl, assignmentDetails,
						removeAssignEndpoint);
				Log.message(getresponseDefaultMath.get("statusCode"));
				Log.message(getresponseDefaultMath.get("body"));

				response = autoAssignStudent(orgId, studentUserID, accessTokenMath);
				Log.assertThat(response.get(Constants.STATUS_CODE).equals(statusCode),
						"Status code is returned as expected and the status code is "
								+ response.get(Constants.STATUS_CODE),
						"Status code is not returned as expected and the same is " + statusCode + " Actual - "
								+ response.get(Constants.STATUS_CODE));

				break;

			case "Default Reading":
				courseName = Constants.READING;
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING);
				String accessTokenReading = new RBSUtils().getAccessToken(studentUsername,
						RBSDataSetupConstants.DEFAULT_PASSWORD);
				assignmentResponse = assignAssignment(smUrl, assignmentDetails, studentRumbaIds,
						AssignmentAPIConstants.USERS_TYPE);
				Log.message("assignmentResponse=" + assignmentResponse);
				assignmentID = SMUtils.getKeyValueFromResponse(assignmentResponse.get(Constants.RESPONSE_BODY),
						"data,assignmentId");
				assignmentUserId = new SqlHelperCourses().getAssignmentUserId(studentUserID, assignmentID);
				Log.message("assignmentUserId =" + assignmentUserId);

				// Remove Assignment
				assignmentDetails.put(AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId);
				HashMap<String, String> getresponseDefaultReading = removeStudentAssignment(smUrl, assignmentDetails,
						removeAssignEndpoint);
				Log.message(getresponseDefaultReading.get("statusCode"));
				Log.message(getresponseDefaultReading.get("body"));

				response = autoAssignStudent(orgId, studentUserID, accessTokenReading);
				Log.assertThat(response.get(Constants.STATUS_CODE).equals(statusCode),
						"Status code is returned as expected and the status code is "
								+ response.get(Constants.STATUS_CODE),
						"Status code is not returned as expected and the same is " + statusCode + " Actual - "
								+ response.get(Constants.STATUS_CODE));

				break;
				
			case "Custom Math":
				courseName = "CustomSettingMath" + System.nanoTime();
				CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( courseName ) );
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, CourseId);
				String accessTokenCustomMath = new RBSUtils().getAccessToken(studentUsername,
						RBSDataSetupConstants.DEFAULT_PASSWORD);
				assignmentResponse = assignAssignment(smUrl, assignmentDetails, studentRumbaIds,
						AssignmentAPIConstants.USERS_TYPE);
				Log.message("assignmentResponse=" + assignmentResponse);
				assignmentID = SMUtils.getKeyValueFromResponse(assignmentResponse.get(Constants.RESPONSE_BODY),
						"data,assignmentId");
				assignmentUserId = new SqlHelperCourses().getAssignmentUserId(studentUserID, assignmentID);
				Log.message("assignmentUserId =" + assignmentUserId);

				// Remove Assignment
				assignmentDetails.put(AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId);
				HashMap<String, String> getresponseCustomMath = removeStudentAssignment(smUrl, assignmentDetails,
						removeAssignEndpoint);
				Log.message(getresponseCustomMath.get("statusCode"));
				Log.message(getresponseCustomMath.get("body"));

				response = autoAssignStudent(orgId, studentUserID, accessTokenCustomMath);
				Log.assertThat(response.get(Constants.STATUS_CODE).equals(statusCode),
						"Status code is returned as expected and the status code is "
								+ response.get(Constants.STATUS_CODE),
						"Status code is not returned as expected and the same is " + statusCode + " Actual - "
								+ response.get(Constants.STATUS_CODE));

				break;
			default:
				Log.fail("Invalid case " + scenario);

			}
		} catch (Exception e) {
			Log.fail("Exception : " + e);
		}
		Log.testCaseResult();

	}

	/**
	 * Data provider for positive scenarios
	 * 
	 * @return
	 */
	@DataProvider(name = "autoAssignPositiveScenarios")
	public Object[][] createAssignementData() {

		Object[][] inputData = { {
				"Verify the status code is 200 when the newly created student added to group which has already group assignment for 'Default Math' in Student Login",
				"Default Math", "200" },
				{ "Verify the status code is 200 when the existing student added to group which has already group assignment  for 'Default Reading'",
						"Default Reading", "200" },
				{ "Verify the status code is 200 when the newly created student assigned to group which has already group assignment for 'Custom Math'",
							"Custom Math", "200" },

		};
		return inputData;
	}

	public HashMap<String, String> autoAssignStudent(String orgId, String studentid, String token) {
		try {
			// headers
			Map<String, String> headers = new HashMap<String, String>();
			String endPoint = "/lms/web/api/v1/students/{studentid}/groups/assignments/autoassign";
			
			headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			headers.put(Constants.USERID_SM_HEADER, studentid);
			headers.put(Constants.AUTHORIZATION, "Bearer " + token);

			HashMap<String, String> params = new HashMap<>();
			endPoint = endPoint.replace("{studentid}", studentid);

			String requestBody = "";
			HashMap<String, String> response = RestHttpClientUtil.POST(smUrl, headers, params, endPoint, requestBody);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}