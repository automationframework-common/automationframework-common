package com.savvas.sm.teacher.ui.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class QualtricsSurveyPopup extends LoadableComponent<QualtricsSurveyPopup> {

    private WebDriver driver;
    boolean isPageLoaded;
    
    public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();
	
    //********Qualtrics Pop up Elements***********

    @IFindBy(how = How.CSS, using= "cel-platform-navbar.hydrated",AI =false)
    public WebElement topNavBarwithShadow;

    @IFindBy(how = How.CSS, using= ".QSIPopOver.SI_3dBahYvHLmlPaQu_PopOverContainer",AI =false)
    public WebElement qualtricsPopupContainer;

    @IFindBy(how = How.CSS, using= "img[src='https://co1.qualtrics.com/WRQualtricsSiteIntercept/Graphic.php?IM=IM_2lWWvABwA1eeyW1']",AI =false)
    public WebElement qualtricsPopupSavvasLogo;

    @IFindBy(how = How.CSS, using= "span[style='color:#696969;']",AI =false)
    public WebElement qualtricsPopupTextInfo;

    @IFindBy(how = How.CSS, using= "div[data-type='target'] div span span",AI =false)
    public WebElement qualtricsPopupYesButton;

    @IFindBy(how = How.CSS, using= "span[style='color:#95a5a6;']",AI =false)
    public WebElement qualtricsPopupNoText;

    @IFindBy(how = How.CSS, using= "img[src='https://static-assets.qualtrics.com/static/prototype-ui-modules/SharedGraphics/siteintercept/svg-close-btn-black-1.svg']",AI =false)
    public WebElement qualtricsPopupXIcon;

    @IFindBy(how = How.CSS, using= "img[src='https://static-assets.qualtrics.com/static/prototype-ui-modules/SharedGraphics/siteintercept/svg-close-btn-black-6.svg']",AI =false)
    public WebElement qualtricsPopupXIconTopRight;

    @IFindBy(how = How.CSS, using= "div[id='Logo']",AI =false)
    public WebElement questionairePageSMLogo;

    @IFindBy(how = How.CSS, using= "div[id='Plug']",AI =false)
    public WebElement poweredByQualtricsTextLink;

    @IFindBy(how = How.CSS, using= "input[id='NextButton']",AI =false)
    public WebElement questionaireNextButton;

    @IFindBy(how = How.CSS, using= "div.ValidationError",AI =false)
    public WebElement errorMessage;

    @IFindBy(how = How.CSS, using= "div.QuestionText.BorderColor",AI =false)
    public WebElement questionaireQuestionText;

    @FindBy ( css = "label.q-radio" )
    List<WebElement> questionaireFirstMultipleRadioChoice;

    @FindBy ( css = "table.ChoiceStructure tbody tr td input" )
    List<WebElement> questionaireFirstMultipleRadioInput;

    @IFindBy(how = How.CSS, using= "label.QuestionText.BorderColor",AI =false)
    public WebElement questionaireSecondQuestionText;

    @FindBy ( css = "div.ChoiceStructure tbody tr td label" )
    List<WebElement> questionaireSecondThirdAnsLabel;

    @FindBy ( css = "div.ChoiceStructure tbody tr td textarea" )
    List<WebElement> questionaireSecondThirdAnsTextArea;

    @FindBy ( css = "ul.ChoiceStructure li input" )
    List<WebElement> questionaireFourthCheckBoxes;

    @FindBy ( css = "table.ChoiceStructure td.ControlContainer input.checkbox" )
    List<WebElement> questionaireFifthReadingMathCheckBoxes;

    @FindBy ( css = "table.ChoiceStructure td span.LabelWrapper label" )
    List<WebElement> questionaireFifthReadingMathLabel;

    @FindBy ( css = "tbody tr th div.dropdown-arrow.mobile span" )
    List<WebElement> seventhQuestionDropDownArrow;

    @FindBy ( css = "tbody tr td input[value='5']" )
    List<WebElement> seventhQuestionRadioChoices;

    @FindBy ( css = "ul.ChoiceStructure li.Selection input" )
    List<WebElement> eigthNineQuestionRadioButton;

    @IFindBy(how = How.CSS, using= "div.QuestionBody Select",AI =false)
    public WebElement elevenDropDownAnswer;

    @FindBy ( css = "div.QuestionBody Select option" )
    List<WebElement> elevenDropDownAnswerSelection;

    public String qualitircsPopup = ".QSIPopOver.SI_3dBahYvHLmlPaQu_PopOverContainer";
    public String savvasLogo = "div[id='Plug']";

    
    public QualtricsSurveyPopup()
    {}
    /**
     * Constructor class for Qualtrics Survey Popup Here we initializing the
     * driver for page factory objects.
     *
     * @param driver
     */
    public QualtricsSurveyPopup( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
    	PageFactory.initElements(finder, this);
    	elementLayer = new ElementLayer(driver);
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, topNavBarwithShadow );
    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }

        if ( SMUtils.waitForElement( driver, topNavBarwithShadow, 30 ) ) {
            Log.message( "SM Teacher home page loaded successfully." );
        } else {
            Log.fail( "SM Teacher home page did not load." );
        }
    }

    /**
     * To Verify Qualtrics pop up appeared or not
     */
    public boolean verifyQualtricsPopupAppeared() {
        return ( SMUtils.waitForElement( driver, qualtricsPopupContainer, 60 ) );
    }

    /**
     * To Verify is savvas Logo displayed
     */
    public boolean isSavvasLogoDisplayed() {
        return ( qualtricsPopupSavvasLogo.isDisplayed() );
    }

    /**
     * To Verify is the Qualtrics Pop up text
     */
    public boolean isQualtricasPopupTextIsAsExpected() {
        return ( SMUtils.getTextOfWebElement( qualtricsPopupTextInfo, driver ).replaceAll( "\\p{Z}", " " ).contains( Constants.QUALTRICS_POPUP_TEXT ) );
    }

    /**
     * To Verify the Button Text in Qualtrics Popup
     */
    public boolean yesNoTextInPopup() {
        return ( SMUtils.getTextOfWebElement( qualtricsPopupYesButton, driver ).contains( Constants.QUALTRICS_POPUP_YES_BUTTON ) && SMUtils.getTextOfWebElement( qualtricsPopupNoText, driver ).contains( Constants.QUALTRICS_POPUP_NO_TEXT ) );
    }

    /**
     * To click on Yes so that Survey is Opened in New window and switched to
     * that new window
     */
    public String toOpenSurveyInNewWindow() {
        SMUtils.waitForElement( driver, qualtricsPopupYesButton, 60 );
        Log.message( "Qualtrics pop up Yes Button is clickable" );
        SMUtils.clickJS( driver, qualtricsPopupYesButton );
        String window = SMUtils.switchWindow( driver );
        SMUtils.waitForElement( driver, poweredByQualtricsTextLink, 30 );
        Log.message( "Qualtrics Popup Survey Opened in New Window" );
        driver.manage().window().maximize();
        return window;
    }

    /**
     * To Verify is Powered By Qualitrics button displayed
     */
    public boolean isPoweredByQualtricsDisplayed() {
        return ( poweredByQualtricsTextLink.isDisplayed() );
    }

    /**
     * To Verify Qualtrics pop up disappeared after a min
     */
    public boolean verifyQualtricsPopupDisappeared() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds(60) );
        return ( wait.until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( qualitircsPopup ) ) ) );
    }

    /**
     * To Verify Qualtrics pop up disappeared after a min
     */
    public boolean verifyQualtricsPopupDisappearedAfterAMin() {
        if ( SMUtils.waitForElement( driver, qualtricsPopupContainer, 60 ) ) {
            Log.message( "Qualtrics pop up loaded successfully." );
        } else {
            Log.fail( "Qualtrics pop up did not load." );
        }

        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds(60) );
        return ( wait.until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( qualitircsPopup ) ) ) );
    }

    /**
     * To Verify Qualitrics pop up closes when cliked on 'X' present on top
     * right
     */
    public boolean verifyPopupClosedOnClickingX() {
        SMUtils.clickJS( driver, qualtricsPopupXIconTopRight );
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds(60) );
        return ( wait.until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( qualitircsPopup ) ) ) );
    }

    /**
     * To Verify Qualitrics pop up closes when cliked on 'X' present below No
     * Thank you
     */
    public boolean verifyPopupClosedOnClickingXBelowNoThankYou() {
        SMUtils.clickJS( driver, qualtricsPopupXIcon );
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds(60) );
        return ( wait.until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( qualitircsPopup ) ) ) );
    }

    /**
     * Validating & Answering SATISFACTION QUESTION from Qualitrics Survey
     */
    public void satisficationQuestionAnswer() {
        if ( SMUtils.getTextOfWebElement( questionaireQuestionText, driver ).contains( Constants.SATISFACTION_QUESTION ) ) {
            SMUtils.clickJS( driver, questionaireFirstMultipleRadioChoice.stream().reduce( ( first, second ) -> second ).get() );
            Log.message( "Question answered:- " + SMUtils.getTextOfWebElement( questionaireQuestionText, driver ) );
            SMUtils.clickJS( driver, questionaireNextButton );
            Log.message( "Clicked on Next button" );
        } else {
            Log.fail( "Question displayed is different: " + SMUtils.getTextOfWebElement( questionaireQuestionText, driver ) );
        }
    }

    /**
     * Validating & Answering Like Most About Success Maker Question from
     * Qualitrics Survey
     */
    public void mostLikeSMQuestionAnswer() {
        if ( SMUtils.getTextOfWebElement( questionaireSecondQuestionText, driver ).contains( Constants.LIKE_ABOUT_SM_QUESTION ) ) {
            SMUtils.clickJS( driver, questionaireSecondThirdAnsTextArea.stream().findFirst().get() );
            SMUtils.enterValue( questionaireSecondThirdAnsTextArea.stream().findFirst().get(), Constants.SURVEY_TEXT_ANSWER );
            Log.message( "Question answered:- " + SMUtils.getTextOfWebElement( questionaireSecondQuestionText, driver ) );
            SMUtils.clickJS( driver, questionaireNextButton );
            Log.message( "Clicked on Next button" );
        } else {
            Log.fail( "Question displayed is different: " + SMUtils.getTextOfWebElement( questionaireSecondQuestionText, driver ) );
        }
    }

    /**
     * Validating & Answering Least Like About Success Maker Question from
     * Qualitrics Survey
     */
    public void leastLikeQuestionAnswer() {
        SMUtils.waitForElement( driver, questionaireSecondQuestionText, 30 );
        if ( SMUtils.getTextOfWebElement( questionaireSecondQuestionText, driver ).replaceAll( "\\p{Z}", "" ).contains( Constants.LEAST_LIKE_QUESTION.replaceAll( "\\p{Z}", "" ) ) ) {
            SMUtils.clickJS( driver, questionaireSecondThirdAnsTextArea.stream().findFirst().get() );
            SMUtils.enterValue( questionaireSecondThirdAnsTextArea.stream().findFirst().get(), Constants.SURVEY_TEXT_ANSWER );
            Log.message( "Question answered:- " + SMUtils.getTextOfWebElement( questionaireSecondQuestionText, driver ) );
            SMUtils.clickJS( driver, questionaireNextButton );
            Log.message( "Clicked on Next button" );
        } else {
            Log.fail( "Question displayed is different: " + SMUtils.getTextOfWebElement( questionaireSecondQuestionText, driver ) );
        }
    }

    /**
     * Validating & Selecting which Success Maker Program teacher use from
     * Qualitrics Survey
     */
    public void whichSMProgramQuestionAnswer() {
        SMUtils.waitForElement( driver, questionaireQuestionText, 30 );
        if ( SMUtils.getTextOfWebElement( questionaireQuestionText, driver ).contains( Constants.WHICH_SM_PROGRAM_QUESTION ) ) {
            SMUtils.clickJS( driver, questionaireFourthCheckBoxes.stream().findFirst().get() );
            Log.message( "SM Program selected" );
            SMUtils.clickJS( driver, questionaireNextButton );
            Log.message( "Clicked on Next button" );
        } else {
            Log.fail( "Question displayed is different: " + SMUtils.getTextOfWebElement( questionaireQuestionText, driver ) );
        }
    }

    /**
     * Validating and selecting the Grade for Reading course
     */
    public void readingGradeQuestionAnswer() {
        SMUtils.waitForElement( driver, questionaireQuestionText, 30 );
        if ( SMUtils.getTextOfWebElement( questionaireQuestionText, driver ).contains( Constants.WHICH_GRADE_READING_QUESTION ) ) {
            SMUtils.clickJS( driver, questionaireFifthReadingMathCheckBoxes.stream().findFirst().get() );
            Log.message( "Grade has been Selected" );
            SMUtils.clickJS( driver, questionaireNextButton );
            Log.message( "Clciked on Next button" );
        } else {
            Log.fail( "Question displayed is different: " + SMUtils.getTextOfWebElement( questionaireQuestionText, driver ) );
        }
    }

    /**
     * Validating and selecting the statement which teacher Agrees or Disagrees
     */
    public void agreeOrDisagreeQuestionAnswer() {
        SMUtils.waitForElement( driver, questionaireSecondQuestionText, 30 );
        if ( SMUtils.getTextOfWebElement( questionaireSecondQuestionText, driver ).replaceAll( "\\p{Z}", " " ).contains( Constants.AGREE_DISAGREE_QUESTION ) ) {
            seventhQuestionRadioChoices.forEach( e -> SMUtils.clickJS( driver, e ) );
            Log.message( "Selected all Agree Strongly" );
            SMUtils.clickJS( driver, questionaireNextButton );
            Log.message( "Clciked on Next button" );
        } else {
            Log.fail( "Question displayed is different: " + SMUtils.getTextOfWebElement( questionaireSecondQuestionText, driver ) );
        }
    }

    /**
     * Validating and selecting how many years they have used Success Maker
     * question
     */
    public void yearsOfUsingSMQuestionAnswer() {
        SMUtils.waitForElement( driver, questionaireQuestionText, 30 );
        if ( SMUtils.getTextOfWebElement( questionaireQuestionText, driver ).contains( Constants.YEARS_OF_USING_SM_QUESTION ) ) {
            SMUtils.clickJS( driver, eigthNineQuestionRadioButton.stream().findFirst().get() );
            Log.message( "Years of using has been selected" );
            SMUtils.clickJS( driver, questionaireNextButton );
            Log.message( "Clciked on Next button" );
        } else {
            Log.fail( "Question displayed is different: " + SMUtils.getTextOfWebElement( questionaireQuestionText, driver ) );
        }
    }

    /**
     * Validating and selecting the Job Titles
     */
    public void jobTitleQuestionAnswer() {
        SMUtils.waitForElement( driver, questionaireQuestionText, 30 );
        if ( SMUtils.getTextOfWebElement( questionaireQuestionText, driver ).contains( Constants.JOB_TITLE_QUESTION ) ) {
            SMUtils.clickJS( driver, eigthNineQuestionRadioButton.stream().findFirst().get() );
            Log.message( "Job Title Selected" );
            SMUtils.clickJS( driver, questionaireNextButton );
            Log.message( "Clciked on Next button" );
        } else {
            Log.fail( "Question displayed is different: " + SMUtils.getTextOfWebElement( questionaireQuestionText, driver ) );
        }
    }

    /**
     * Validating and Selecting mode of usage of SM
     */
    public void usageOfSMQuestionAnswer() {
        SMUtils.waitForElement( driver, questionaireQuestionText, 30 );
        if ( SMUtils.getTextOfWebElement( questionaireQuestionText, driver ).replaceAll( "\\p{Z}", " " ).contains( Constants.USAGE_OF_SM_QUESTION ) ) {
            SMUtils.clickJS( driver, eigthNineQuestionRadioButton.stream().findFirst().get() );
            Log.message( "Selected the SM Usage mode for students" );
            SMUtils.clickJS( driver, questionaireNextButton );
            Log.message( "Clciked on Next button" );
        } else {
            Log.fail( "Question displayed is different: " + SMUtils.getTextOfWebElement( questionaireQuestionText, driver ) );
        }
    }

    /**
     * Selecting the State
     */
    public void stateSelectionQuestionAnswer() {
        SMUtils.waitForElement( driver, questionaireSecondQuestionText, 30 );
        if ( SMUtils.getTextOfWebElement( questionaireSecondQuestionText, driver ).contains( Constants.STATE_SELECTION_QUESTION ) ) {
            SMUtils.selectOption( elevenDropDownAnswer, Constants.DISTRICT_DROPDOWN_IN_SURVEY );
            Log.message( "State has been selected" );
            SMUtils.clickJS( driver, questionaireNextButton );
            Log.message( "Clciked on Next button" );
        } else {
            Log.fail( "Question displayed is different: " + SMUtils.getTextOfWebElement( questionaireSecondQuestionText, driver ) );
        }
    }

    /**
     * To Verify Thank you Note once all survey questions answered
     *
     * @return
     */
    public boolean isThankYouNoteDisplayed() {
        if ( SMUtils.getTextOfWebElement( questionaireQuestionText, driver ).contains( Constants.QUALTRICS_SURVEY_THANK_YOU ) ) {
            Log.message( "Thank you Note displayed" );
            SMUtils.clickJS( driver, questionaireNextButton );
            Log.message( "Clciked on Next button" );
            return true;
        } else {
            Log.fail( "Thank you note is not displayed: " + SMUtils.getTextOfWebElement( questionaireQuestionText, driver ) );
            return false;
        }
    }

    /**
     * To Verify page navigated to Savvas home page after clicking on next
     * button
     *
     * @return
     */
    public boolean isSavvasHomePageDisplayed() {
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds(60) );
        wait.until( ExpectedConditions.invisibilityOfElementLocated( By.cssSelector( savvasLogo ) ) );
        SMUtils.waitForPageLoad( driver );
        return ( driver.getCurrentUrl().equals( Constants.SAVVAS_URL ) );
    }

    /**
     * Answering the Survey Question
     */
    public void surveyQuestionAnswers() {
        satisficationQuestionAnswer();
        mostLikeSMQuestionAnswer();
        leastLikeQuestionAnswer();
        whichSMProgramQuestionAnswer();
        readingGradeQuestionAnswer();
        agreeOrDisagreeQuestionAnswer();
        yearsOfUsingSMQuestionAnswer();
        jobTitleQuestionAnswer();
        usageOfSMQuestionAnswer();
        stateSelectionQuestionAnswer();
    }

    /**
     * To Attend survey for only few question
     */
    public void toSkipSurvey() {
        satisficationQuestionAnswer();
        mostLikeSMQuestionAnswer();
        leastLikeQuestionAnswer();
    }
}
