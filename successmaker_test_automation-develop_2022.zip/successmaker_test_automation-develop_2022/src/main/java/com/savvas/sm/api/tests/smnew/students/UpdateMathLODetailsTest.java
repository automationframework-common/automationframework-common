package com.savvas.sm.api.tests.smnew.students;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.simulatorrun.SimulatorRun;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class UpdateMathLODetailsTest extends EnvProperties {
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public String endPoint = "/lms/web/assignments/mastery/{auId}";
    private String smUrl;
    private String orgId;
    private String userId;
    private String studentUserName;
    private String studentUserDetails = null;

    public static String teacherDetails = null;
    public static String teacherUserName, teacherUserId;
    public static String math_Assignment = "Math_Skills" + System.nanoTime();
    public static String groupName = Constants.GROUP_NAME;
    private String browser;
    public HashMap<String, String> GroupDetails = new HashMap<>();
    public HashMap<String, String> AssignmentDetails = new HashMap<>();
    public List<String> StudentRumbaIds = new ArrayList<>();
    public List<String> courseIdsForAssign = new ArrayList<>();
    String teacherBearertoken = null;

    @BeforeTest ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        orgId = RBSDataSetup.organizationIDs.get( school );

        // Fetching Teacher Details
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUserName = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        Log.message( teacherUserName );

        // Fetching Student Details
        studentUserDetails = RBSDataSetup.getMyStudent( school, teacherUserName );
        userId = SMUtils.getKeyValueFromResponse( studentUserDetails, "userId" );
        studentUserName = SMUtils.getKeyValueFromResponse( studentUserDetails, "userName" );

        sessionIdGeneration();
    }

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-66854", "[Automation] API To Update Student LO Mastery: PUT-/lms/web/assignments/mastery/", "API" , "smoke_test_case" }, priority = 1 )
    public void putUpdateStudentLOMastery001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        //Pathparams
        Map<String, String> pathParams = new HashMap<String, String>();
        //payload
        Map<String, Object> payload = new HashMap<>();

        String assignmentUserId = getuserAssignmentId( userId );
        String sessionId = getSessionId( Integer.parseInt( assignmentUserId ) );
        String scoHistory = getScoHistory( Integer.parseInt( assignmentUserId ) );
        String scoId = getScoId( scoHistory );

        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( studentUserName, "testing123$" ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.ORG_ID, orgId );
        headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.USER_ID, userId );
        headers.put( StudentsAPIConstants.SESSION_ID, sessionId );
        Log.message( headers + "" );

        pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );
        Log.message( pathParams + "" );

        switch ( scenarioType ) {
            case "IN_PROGRESS_MATH":
                payload.put( StudentsAPIConstants.ID, scoId );
                payload.put( StudentsAPIConstants.SKILL_LEVEL, 4.0 );
                payload.put( StudentsAPIConstants.PEARSON_SKILL_OBEJCTID, null );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_ID, 1 );
                payload.put( StudentsAPIConstants.TOTAL_ATTEMPTS, 4 );
                payload.put( StudentsAPIConstants.TOTAL_CORRECTS, 4 );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_DATE, null );
                payload.put( StudentsAPIConstants.STRAND_ID, null );
                payload.put( StudentsAPIConstants.STRAND_LEVEL, null );
                payload.put( StudentsAPIConstants.ASSIGNMENT_TITLE, null );
                payload.put( StudentsAPIConstants.FIRST_NAME, null );
                payload.put( StudentsAPIConstants.LAST_NAME, null );
                break;
            case "MASTERED_STATUS_MATH":
                payload.put( StudentsAPIConstants.ID, scoId );
                payload.put( StudentsAPIConstants.SKILL_LEVEL, 4.0 );
                payload.put( StudentsAPIConstants.PEARSON_SKILL_OBEJCTID, null );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_ID, 2 );
                payload.put( StudentsAPIConstants.TOTAL_ATTEMPTS, 4 );
                payload.put( StudentsAPIConstants.TOTAL_CORRECTS, 4 );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_DATE, null );
                payload.put( StudentsAPIConstants.STRAND_ID, null );
                payload.put( StudentsAPIConstants.STRAND_LEVEL, null );
                payload.put( StudentsAPIConstants.ASSIGNMENT_TITLE, null );
                payload.put( StudentsAPIConstants.FIRST_NAME, null );
                payload.put( StudentsAPIConstants.LAST_NAME, null );
                break;
            case "NOT_MASTERED_STATUS_MATH":
                payload.put( StudentsAPIConstants.ID, scoId );
                payload.put( StudentsAPIConstants.SKILL_LEVEL, 4.0 );
                payload.put( StudentsAPIConstants.PEARSON_SKILL_OBEJCTID, null );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_ID, 3 );
                payload.put( StudentsAPIConstants.TOTAL_ATTEMPTS, 4 );
                payload.put( StudentsAPIConstants.TOTAL_CORRECTS, 4 );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_DATE, null );
                payload.put( StudentsAPIConstants.STRAND_ID, null );
                payload.put( StudentsAPIConstants.STRAND_LEVEL, null );
                payload.put( StudentsAPIConstants.ASSIGNMENT_TITLE, null );
                payload.put( StudentsAPIConstants.FIRST_NAME, null );
                payload.put( StudentsAPIConstants.LAST_NAME, null );
                break;
            case "RISK_STATUS_MATH":
                payload.put( StudentsAPIConstants.ID, scoId );
                payload.put( StudentsAPIConstants.SKILL_LEVEL, 4.0 );
                payload.put( StudentsAPIConstants.PEARSON_SKILL_OBEJCTID, null );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_ID, 4 );
                payload.put( StudentsAPIConstants.TOTAL_ATTEMPTS, 4 );
                payload.put( StudentsAPIConstants.TOTAL_CORRECTS, 4 );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_DATE, null );
                payload.put( StudentsAPIConstants.STRAND_ID, null );
                payload.put( StudentsAPIConstants.STRAND_LEVEL, null );
                payload.put( StudentsAPIConstants.ASSIGNMENT_TITLE, null );
                payload.put( StudentsAPIConstants.FIRST_NAME, null );
                payload.put( StudentsAPIConstants.LAST_NAME, null );
                break;
        }
        Response response = PUTWITHPATHPARAMS( smUrl, headers, pathParams, payload, endPoint );
        int actualstatuscode = response.getStatusCode();
        Log.message( response.getBody().asString() );
        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC01: ", "200", "Verify the response code is 200 for mastery in-progress status for Math course", "IN_PROGRESS_MATH" },
                { "TC02: ", "200", "Verify the response code is 200 for mastered status for Math course", "MASTERED_STATUS_MATH" }, { "TC03: ", "200", "Verify the response code is 200 for not mastered status for Math course", "NOT_MASTERED_STATUS_MATH" },
                { "TC04: ", "200", ".Verify the response code is 200 for at risk status for Math course", "RISK_STATUS_MATH" } };
        return data;
    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-66854", "[Automation] API To Update Student LO Mastery: PUT-/lms/web/assignments/mastery/", "API" }, priority = 1 )
    public void putUpdateStudentLOMastery002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        //Pathparams
        Map<String, String> pathParams = new HashMap<String, String>();
        //payload
        Map<String, Object> payload = new HashMap<>();

        String assignmentUserId = getuserAssignmentId( userId );
        String sessionId = getSessionId( Integer.parseInt( assignmentUserId ) );
        String scoHistory = getScoHistory( Integer.parseInt( assignmentUserId ) );
        String scoId = getScoId( scoHistory );

        switch ( scenarioType ) {
            case "INVALIDAUTH_REQUEST":

                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );

                headers.put( Constants.AUTHORIZATION, new RBSUtils().getAccessToken( studentUserName, "testing123$" ) );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.ORG_ID, orgId );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.USER_ID, userId );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );

                payload.put( StudentsAPIConstants.ID, scoId );
                payload.put( StudentsAPIConstants.SKILL_LEVEL, 4.0 );
                payload.put( StudentsAPIConstants.PEARSON_SKILL_OBEJCTID, null );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_ID, 1 );
                payload.put( StudentsAPIConstants.TOTAL_ATTEMPTS, 4 );
                payload.put( StudentsAPIConstants.TOTAL_CORRECTS, 4 );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_DATE, null );
                payload.put( StudentsAPIConstants.STRAND_ID, null );
                payload.put( StudentsAPIConstants.STRAND_LEVEL, null );
                payload.put( StudentsAPIConstants.ASSIGNMENT_TITLE, null );
                payload.put( StudentsAPIConstants.FIRST_NAME, null );
                payload.put( StudentsAPIConstants.LAST_NAME, null );
                break;
            case "INVALID_ASSIGNMENTUSER_ID":

                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId + 123 );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( studentUserName, "testing123$" ) );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.ORG_ID, orgId );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.USER_ID, userId );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );

                payload.put( StudentsAPIConstants.ID, scoId );
                payload.put( StudentsAPIConstants.SKILL_LEVEL, 4.0 );
                payload.put( StudentsAPIConstants.PEARSON_SKILL_OBEJCTID, null );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_ID, 1 );
                payload.put( StudentsAPIConstants.TOTAL_ATTEMPTS, 4 );
                payload.put( StudentsAPIConstants.TOTAL_CORRECTS, 4 );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_DATE, null );
                payload.put( StudentsAPIConstants.STRAND_ID, null );
                payload.put( StudentsAPIConstants.STRAND_LEVEL, null );
                payload.put( StudentsAPIConstants.ASSIGNMENT_TITLE, null );
                payload.put( StudentsAPIConstants.FIRST_NAME, null );
                payload.put( StudentsAPIConstants.LAST_NAME, null );
                break;
            case "STRING_ASSIGNMENTUSER_ID":

                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, StudentsAPIConstants.STRING_ASSIGNMENT_USER_ID );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( studentUserName, "testing123$" ) );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.ORG_ID, orgId );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.USER_ID, userId );
                headers.put( StudentsAPIConstants.SESSION_ID, sessionId );

                payload.put( StudentsAPIConstants.ID, scoId );
                payload.put( StudentsAPIConstants.SKILL_LEVEL, 4.0 );
                payload.put( StudentsAPIConstants.PEARSON_SKILL_OBEJCTID, null );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_ID, 1 );
                payload.put( StudentsAPIConstants.TOTAL_ATTEMPTS, 4 );
                payload.put( StudentsAPIConstants.TOTAL_CORRECTS, 4 );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_DATE, null );
                payload.put( StudentsAPIConstants.STRAND_ID, null );
                payload.put( StudentsAPIConstants.STRAND_LEVEL, null );
                payload.put( StudentsAPIConstants.ASSIGNMENT_TITLE, null );
                payload.put( StudentsAPIConstants.FIRST_NAME, null );
                payload.put( StudentsAPIConstants.LAST_NAME, null );
                break;
            case "MISSED_SESSION_ID":

                pathParams.put( StudentsAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( studentUserName, "testing123$" ) );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.ORG_ID, orgId );
                headers.put( StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants.USER_ID, userId );

                payload.put( StudentsAPIConstants.ID, scoId );
                payload.put( StudentsAPIConstants.SKILL_LEVEL, 4.0 );
                payload.put( StudentsAPIConstants.PEARSON_SKILL_OBEJCTID, null );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_ID, 1 );
                payload.put( StudentsAPIConstants.TOTAL_ATTEMPTS, 4 );
                payload.put( StudentsAPIConstants.TOTAL_CORRECTS, 4 );
                payload.put( StudentsAPIConstants.MASTERY_STATUS_DATE, null );
                payload.put( StudentsAPIConstants.STRAND_ID, null );
                payload.put( StudentsAPIConstants.STRAND_LEVEL, null );
                payload.put( StudentsAPIConstants.ASSIGNMENT_TITLE, null );
                payload.put( StudentsAPIConstants.FIRST_NAME, null );
                payload.put( StudentsAPIConstants.LAST_NAME, null );
                break;
        }
        Response response = PUTWITHPATHPARAMS( smUrl, headers, pathParams, payload, endPoint );
        int actualstatuscode = response.getStatusCode();
        Log.message( response.getBody().asString() );
        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );

    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC05: ", "401", "Verify the response code is 401 for unauthorized request", "INVALIDAUTH_REQUEST" },
                { "TC06: ", "403", "Verify the response code is 403 for the invalid integer assignment userId", "INVALID_ASSIGNMENTUSER_ID" },
                { "TC07: ", "500", "Verify the response code is 500 for the String type assignment user id", "STRING_ASSIGNMENTUSER_ID" }, { "TC08: ", "400", "Verify the Response code is 400 if the session-id missed in the header", "MISSED_SESSION_ID" }

        };
        return data;

    }

    // method for put with input parameter
    public static Response PUTWITHPATHPARAMS( String baseURL, Map<String, String> headers, Map<String, String> inputData, Map<String, Object> body, String url ) {
        setBaseURL( baseURL );
        Response resp = RestAssured.given().headers( headers ).pathParams( inputData ).body( body ).put( url ).andReturn();
        Log.message( "running PUT command" );
        Log.message( "URL \n" + baseURL );
        Log.message( "Header \n" + resp.getHeaders().toString() );
        Log.event( "Response body \n" + resp.asString() );
        Log.message( "Time taken to get response is \n" + resp.getTime() + " milli second" );
        return resp;

    }

    // method for setting of base url
    public static void setBaseURL( String baseURL ) {
        try {
            if ( !baseURL.isEmpty() || !baseURL.contains( null ) ) {
                RestAssured.baseURI = baseURL;
            }
        } catch ( NullPointerException e ) {
            System.out.println( "Base URL is set as null" );
        }
    }

    public String getuserAssignmentId( String studentRumbaId ) {
        List<Object[]> userAssignmentId = SQLUtil.executeQuery( "select assignment_user_id from assignment_user where person_id ='" + studentRumbaId + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : userAssignmentId ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String userAssID = arrList.get( 0 );
        return userAssID;
    }

    public String getSessionId( int assUId ) {
        List<Object[]> Session_Id = SQLUtil.executeQuery( "select session_id from school.assignment_session where assignment_user_id in( " + assUId + ")" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : Session_Id ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String ssID = arrList.get( 0 );
        return ssID;
    }

    public String getScoHistory( int assUId ) {
        List<Object[]> Sco_History = SQLUtil.executeQuery( "select exercise_set_sco_id from school.math_assignment_sco_history WHERE assignment_user_id='" + assUId + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : Sco_History ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String ssID = arrList.get( 0 );
        return ssID;
    }

    public String getScoId( String scoHis ) {
        List<Object[]> Sco_Id = SQLUtil.executeQuery( "select exercise_set_sco_name from successmaker.exerset_sco where exercise_set_sco_id='" + scoHis + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : Sco_Id ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String ssID = arrList.get( 0 );
        String ssID1 = ssID.substring( 0, ssID.length() - 3 );
        return ssID1;

    }

    public void sessionIdGeneration() throws Exception {
        // creating groups with students
        StudentRumbaIds.add( userId );

        GroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        GroupDetails.put( com.savvas.sm.utils.Constants.GROUP_OWNER_ID, teacherUserId );
        GroupDetails.put( com.savvas.sm.utils.Constants.GROUP_ORG_ID, orgId );
        GroupDetails.put( com.savvas.sm.utils.Constants.GROUP_NAME, groupName );
        if ( new GroupAPI().createGroup( smUrl, GroupDetails, StudentRumbaIds ).get( "statusCode" ).equals( "201" ) ) {
            Log.message( "Group created for the student !" );
        }
        teacherBearertoken = new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        courseIdsForAssign.add( new CourseAPI().createCourse( smUrl, teacherBearertoken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SKILL, math_Assignment ) );

        // Assigning the courses to the students
        AssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        AssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        AssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherBearertoken );
        new AssignmentAPI().assignMultipleAssignments( smUrl, AssignmentDetails, StudentRumbaIds, courseIdsForAssign );
        try {
            // First student for Mastered
            new SimulatorRun().masterySimulatorRun( smUrl, teacherUserId, studentUserName, math_Assignment, "1", "50", "3" );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
