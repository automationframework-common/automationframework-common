    package com.savvas.sm.api.tests.smnew.license;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.ethnicity;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.gender;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.grade;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasDisability;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEconomicDisadvantage;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEnglishProficiency;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.isMigrant;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.specialServices;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

/**
 * This class is used to check the session id when the simultaneous execution of
 * assignments
 *
 * @author saravanan.murugesan
 */
public class SimultaneousAssignmentTest extends BaseAPITest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    String mathTeacherDetails;

    private String token = null;
    HashMap<String, String> mathSchoolAssignmentResponse = new HashMap<>();
    HashMap<String, String> mathSchoolCreateStudentResponse = new HashMap<>();

    String math_UserId = null;
    String math_UserName = null;
    String mathAssignUserId = null;
    String mathStudentDetails;
    String actualFirstSessId;
    String actualSecondSessionId;
    String actualThirdSessionId;

    @BeforeClass(alwaysRun = true)
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        mathTeacherDetails = RBSDataSetup.getMyTeacher( mathSchool );
        mathStudentDetails = RBSDataSetup.getMyStudent( mathSchool, SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USER_NAME ) );
    }

    @Test ( dataProvider = "verifySessionID", groups = { "SMK-51559", "smoke_test_case", "P1", "(SQE) Restrict simultaneous execution of assignments", "API" }, priority = 1 )
    public void verifySessionIDTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> Dummy = new HashMap<>();
        HashMap<String, String> headers = new HashMap<String, String>();
        HashMap<String, String> headersSecondSession = new HashMap<String, String>();
        HashMap<String, String> headersThirdSession = new HashMap<String, String>();
        List<String> pathParamsList = new ArrayList<String>();
        List<String> pathParamsListSecondSession = new ArrayList<String>();
        List<String> pathParamsListThirdSession = new ArrayList<String>();
        String endPoint = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {
            case "FIRST_SESSION_AS_STUDENT":
                // Creating Student, Group, Assigning assignment for a group and getting userassignmentId from DB

                HashMap<String, String> mathSchoolStudentDetails = new HashMap<>();
                mathSchoolStudentDetails = generateRequestValues( mathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                mathSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, mathSchoolStudentDetails );
                String cmsResponse = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( mathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );

                math_UserId = SMUtils.getKeyValueFromResponse( mathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID );
                math_UserName = SMUtils.getKeyValueFromResponse( mathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new RBSUtils().updateUserOrgId( new RBSUtils().getUser( math_UserId ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( mathSchool ) ) );
                HashMap<String, String> mathSchoolGroupDetails = new HashMap<>();
                HashMap<String, String> mathSchoolAssignmentDetails = new HashMap<>();
                List<String> mathSchoolStudentRumbaIds = new ArrayList<>();
                mathSchoolStudentRumbaIds.add( math_UserId );
                mathSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userId" ) );
                mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, mathSchoolGroupDetails, mathSchoolStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }

                mathSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userId" ) );
                mathSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                mathSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                mathSchoolAssignmentResponse = new AssignmentAPI().assignAssignment( smUrl, mathSchoolAssignmentDetails, mathSchoolStudentRumbaIds, "users" );

                mathAssignUserId = getuserAssignmentId( math_UserId );
                Log.message( mathAssignUserId + "AssignmentUserId" );
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( math_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                headers.put( LicenseAPIConstants.USERID, math_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( mathAssignUserId );

                HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint, pathParamsList );
                Response responseFirstSession = RestAssuredAPIUtil.GET( smUrl, headers, endPoint, pathParams );
                int actualStatusCode = responseFirstSession.getStatusCode();
                Log.assertThat( actualStatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actualStatusCode + "is the same as expected status code " + expected_StatusCode,
                        "The actual status code " + actualStatusCode + "is not the same as expected status code " + expected_StatusCode );
                actualFirstSessId = getuserSessionId( math_UserId );
                Log.assertThat( !( actualFirstSessId == null ) && ( actualFirstSessId.toCharArray().length == 36 ), "The session id " + actualFirstSessId + " is not null and the length is 36",
                        "The session id " + actualFirstSessId + " shouldn't be null and session length should be 36" );
                break;
            case "SECOND_SESSION_AS_STUDENT_SAME_TOKEN":
                headersSecondSession.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                headersSecondSession.put( LicenseAPIConstants.USERID, math_UserId );
                headersSecondSession.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsListSecondSession.add( mathAssignUserId );
                HashMap<String, String> pathParamsSecondSession = SMUtils.setPathParametersFromEndpoint( endPoint, pathParamsListSecondSession );
                Response responseSecondSession = RestAssuredAPIUtil.GET( smUrl, headersSecondSession, endPoint, pathParamsSecondSession );
                int actualSecondSessionStatusCode = responseSecondSession.getStatusCode();
                Log.assertThat( actualSecondSessionStatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actualSecondSessionStatusCode + "is the same as expected status code " + expected_StatusCode,
                        "The actual status code " + actualSecondSessionStatusCode + "is not the same as expected status code " + expected_StatusCode );
                actualSecondSessionId = getuserSessionId( math_UserId );
                Log.assertThat( !( actualSecondSessionId == null ) && ( actualSecondSessionId.toCharArray().length == 36 ), "The session id " + actualSecondSessionId + " is not null and the length is 36",
                        "The session id " + actualSecondSessionId + " shouldn't be null and session length should be 36" );
                Log.assertThat( !actualSecondSessionId.equals( actualThirdSessionId ), "The previous session id " + actualFirstSessId + " is not equal with current session id " + actualSecondSessionId + " when the token is same",
                        "The previous session id " + actualFirstSessId + " shouldn't be equal with current session id " + actualSecondSessionId + " when the token is same" );
                break;
            case "THIRD_SESSION_AS_STUDENT_DIFFERENT_TOKEN":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( math_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headersThirdSession.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                headersThirdSession.put( LicenseAPIConstants.USERID, math_UserId );
                headersThirdSession.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsListThirdSession.add( mathAssignUserId );
                HashMap<String, String> pathParamsThirdSession = SMUtils.setPathParametersFromEndpoint( endPoint, pathParamsListThirdSession );
                Response responseThirdSession = RestAssuredAPIUtil.GET( smUrl, headersThirdSession, endPoint, pathParamsThirdSession );
                int actualThirdSessionStatusCode = responseThirdSession.getStatusCode();
                Log.assertThat( actualThirdSessionStatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actualThirdSessionStatusCode + "is the same as expected status code " + expected_StatusCode,
                        "The actual status code " + actualThirdSessionStatusCode + "is not the same as expected status code " + expected_StatusCode );
                actualThirdSessionId = getuserSessionId( math_UserId );
                Log.assertThat( !( actualThirdSessionId == null ) && ( actualThirdSessionId.toCharArray().length == 36 ), "The session id " + actualThirdSessionId + " is not null and the session length is 36",
                        "The session id " + actualThirdSessionId + " shouldn't be null and session length should be 36" );
                Log.assertThat( !actualSecondSessionId.equals( actualThirdSessionId ), "The previous session id " + actualSecondSessionId + " is not equal with current session id " + actualThirdSessionId + " when the token is different",
                        "The previous session id " + actualSecondSessionId + " shouldn't equal with current session id " + actualThirdSessionId + " when the token is different" );
                break;
        }

    }

    @DataProvider
    public Object[][] verifySessionID() {
        Object[][] data = {
                { "TC:001", "200", " Verify 200 status code, response body and session length when student launching the 'SUCCESSMAKER DEFAULT MATH COURSES' with valid DEFAULT MATH license left for the orgainzation  ", "FIRST_SESSION_AS_STUDENT" },
                { "TC:002", "200", " Verify the session id is not same with previous one when the user login using the same token ", "SECOND_SESSION_AS_STUDENT_SAME_TOKEN" },
                { "TC:003", "200", " Verify the session id is not same with previous one when the user login using the diffent token   ", "THIRD_SESSION_AS_STUDENT_DIFFERENT_TOKEN" } };
        return data;
    }

    @Test ( dataProvider = "verifyMultiSession", groups = { "SMK-56780", "smoke_test_case", "P1", "Warn student when launching new assignment window/tab when one exists.", "API" }, priority = 1 )
    public void verifyMultiAssignmentTest002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> Dummy = new HashMap<>();
        HashMap<String, String> headers = new HashMap<String, String>();
        HashMap<String, String> headersSecondSession = new HashMap<String, String>();
        List<String> pathParamsList = new ArrayList<String>();
        List<String> pathParamsListFirstSession = new ArrayList<String>();
        String endPoint1 = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        String endPoint2 = LicenseAPIConstants.CHECK_MULTI_ASSIGNMENT_SESSION;
        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {
            case "VERIFY_NOSESSION_EXISTS_FALSE":
                // Creating Student, Group, Assigning assignment for a group and getting userassignmentId from DB

                HashMap<String, String> mathSchoolStudentDetails = new HashMap<>();
                mathSchoolStudentDetails = generateRequestValues( mathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                mathSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, mathSchoolStudentDetails );
                String cmsResponse = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( mathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );

                math_UserId = SMUtils.getKeyValueFromResponse( mathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID );
                math_UserName = SMUtils.getKeyValueFromResponse( mathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new RBSUtils().updateUserOrgId( new RBSUtils().getUser( math_UserId ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( mathSchool ) ) );
                HashMap<String, String> mathSchoolGroupDetails = new HashMap<>();
                HashMap<String, String> mathSchoolAssignmentDetails = new HashMap<>();
                List<String> mathSchoolStudentRumbaIds = new ArrayList<>();
                mathSchoolStudentRumbaIds.add( math_UserId );
                mathSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userId" ) );
                mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, mathSchoolGroupDetails, mathSchoolStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }

                mathSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userId" ) );
                mathSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                mathSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                mathSchoolAssignmentResponse = new AssignmentAPI().assignAssignment( smUrl, mathSchoolAssignmentDetails, mathSchoolStudentRumbaIds, "users" );

                mathAssignUserId = getuserAssignmentId( math_UserId );
                Log.message( mathAssignUserId + "AssignmentUserId" );
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( math_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                headers.put( LicenseAPIConstants.USERID, math_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( mathAssignUserId );
                //Checking no session exists
                HashMap<String, String> pathParamsSessionNotExist = SMUtils.setPathParametersFromEndpoint( endPoint2, pathParamsList );
                Response responseSessionCheck = RestAssuredAPIUtil.GET( smUrl, headers, endPoint2, pathParamsSessionNotExist );
                int actualStatusSessionNotExists = responseSessionCheck.getStatusCode();
                Log.assertThat( actualStatusSessionNotExists == Integer.parseInt( expected_StatusCode ), "The actual status code " + actualStatusSessionNotExists + "is the same as expected status code " + expected_StatusCode,
                        "The actual status code " + actualStatusSessionNotExists + "is not the same as expected status code " + expected_StatusCode );
                break;
            case "VERIFY_SESSION_EXISTS_TRUE":
                //Launching course and creating session
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( math_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headersSecondSession.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                headersSecondSession.put( LicenseAPIConstants.USERID, math_UserId );
                headersSecondSession.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsListFirstSession.add( mathAssignUserId );
                HashMap<String, String> pathParamsFirstSession = SMUtils.setPathParametersFromEndpoint( endPoint1, pathParamsListFirstSession );
                Response responseFirstSession = RestAssuredAPIUtil.GET( smUrl, headersSecondSession, endPoint1, pathParamsFirstSession );
                //Checking session exists
                HashMap<String, String> pathParamsSessionExists = SMUtils.setPathParametersFromEndpoint( endPoint2, pathParamsListFirstSession );
                Response responseSessionExistsCheck = RestAssuredAPIUtil.GET( smUrl, headersSecondSession, endPoint2, pathParamsSessionExists );
                int actualStatusSessionExists = responseSessionExistsCheck.getStatusCode();
                Log.assertThat( actualStatusSessionExists == Integer.parseInt( expected_StatusCode ), "The actual status code " + actualStatusSessionExists + "is the same as expected status code " + expected_StatusCode,
                        "The actual status code " + actualStatusSessionExists + "is not the same as expected status code " + expected_StatusCode );
                actualFirstSessId = getuserSessionId( math_UserId );
                break;
        }

    }

    @DataProvider
    public Object[][] verifyMultiSession() {
        Object[][] data = { { "TC:001", "200", " Verify 200 status code, response body when no session exists", "VERIFY_NOSESSION_EXISTS_FALSE" },
                { "TC:002", "200", "Verify 200 status code, response body when session exists", "VERIFY_SESSION_EXISTS_TRUE" } };
        return data;
    }

    /*
     * Get AssignmentUserId from the given studentId
     *
     * @param studentRumbaId
     */
    public String getuserAssignmentId( String studentRumbaId ) {
        List<Object[]> userAssignmentId = SQLUtil.executeQuery( "select assignment_user_id from assignment_user where person_id ='" + studentRumbaId + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : userAssignmentId ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String userAssID = arrList.get( 0 );
        return userAssID;
    }

    /*
     * Get SessionId from the given studentId
     *
     * @param studentRumbaId
     */
    public String getuserSessionId( String studentRumbaId ) {
        List<Object[]> userAssignmentId = SQLUtil.executeQuery( "select session_id  from school.assignment_session where person_id ='" + studentRumbaId + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : userAssignmentId ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String sessionID = arrList.get( 0 );
        return sessionID;
    }

    public HashMap<String, String> generateRequestValues( HashMap<String, String> studentDetails, String key, String value ) {
        HashMap<String, String> generatedStudentDetails = studentDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, new Faker().name().firstName() );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, new Faker().name().firstName().substring( 1 ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, new Faker().name().lastName() );
        generatedStudentDetails.put( CreateStudentAPIConstants.GRADE, grade.FIRST.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, new Faker().name().username() );
        generatedStudentDetails.put( CreateStudentAPIConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( CreateStudentAPIConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( GetUserDetailsUsingUserServiceAPIConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        return generatedStudentDetails;
    }

    /**
     * This methods will update the details whatever given in Key and value
     *
     * @param studentDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> updateRequestBodyValues( HashMap<String, String> studentDetails, String key, String value ) {
        HashMap<String, String> generatedStudentDetails = studentDetails;
        if ( generatedStudentDetails.containsKey( key ) ) {
            generatedStudentDetails.put( key, value );
        } else {
            generatedStudentDetails.put( key, value );
        }
        return generatedStudentDetails;
    }
}
