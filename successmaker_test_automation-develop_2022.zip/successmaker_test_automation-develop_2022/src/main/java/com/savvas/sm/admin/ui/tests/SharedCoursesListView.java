package com.savvas.sm.admin.ui.tests;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SharedCoursesListViewPage;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants.SharedCourses.SHARED_COURSE_TABLE_HEADER;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class SharedCoursesListView extends BaseTest {

    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify Shared Courses list view in admin dashboard", groups = { "SMK-51097", "adminDashboard", "sharedCourseListView" }, priority = 1 )
    public void tcSMSharedCourses001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMSharedCourses001: Verify Shared Courses list view in admin dashboard. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Shared Courses List View Page
            SharedCoursesListViewPage sharedCoursesPage = dashBoardPage.navigateToSharedCoursesListPage();

            SMUtils.logDescriptionTC( "Verify the default text inside the search box in shared course page" );
            Log.assertThat( sharedCoursesPage.getSearchBarPlaceHolderTxt().equals( AdminConstants.SharedCourses.SEARCH_COURSE_NAME ), "The default text inside the search box is same as excepted", "The default text inside the search box is wrong" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Shared Course page displayes search bar if there is shared courses available for the organization" );
            Log.assertThat( sharedCoursesPage.isSearchBoxDisplayed(), "Search box is displayed in shared courses list view page", "Search box is not displayed in shared courses list view page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the user is able to type on the search bar in the shared courses page." );
            SMUtils.logDescriptionTC( "Verify the functionality of search bar in the Shared Courses page with minimum characters." );
            sharedCoursesPage.enterValueInSearchBox( Constants.MATH );
            Log.assertThat( sharedCoursesPage.getListFromTable( SHARED_COURSE_TABLE_HEADER.COURSE_NAME ).stream().allMatch( text -> text.toLowerCase().contains( Constants.MATH.toLowerCase() ) ), "User is able to type on the search box",
                    "User is not able to type on the search box" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the edit button is displayed for all the shared courses listed in the shared courses page." );
            Log.assertThat( sharedCoursesPage.isEditBtnDisplayed(), "Edit button is present in shared course list view table", "Edit button is not present in shared course list view table" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the shared course listing header are displayed in the shared course page." );
            Log.assertThat( sharedCoursesPage.getSharedCoursesTableHeader().containsAll( AdminConstants.SharedCourses.SHARED_COURSE_TABLE_HEADER ), "Headers are displayed in shared courses page", "Headers are not displayed in shared courses page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the user is able to type valid alpha numeric and special characters in the search bar of the Shared course page." );
            SMUtils.logDescriptionTC( "Verify the user is able to type shared course name with multiple spaces in the search bar of the Shared course page." );
            sharedCoursesPage.enterValueInSearchBox( AdminConstants.SharedCourses.ALPHA_NUMERIC_SPECIAL_CHAR );
            Log.assertThat( sharedCoursesPage.getValueEnteredInSearchBox().equals( AdminConstants.SharedCourses.ALPHA_NUMERIC_SPECIAL_CHAR ), "User is able to type alpha numeric and special characters in the search bar",
                    "User is not able to type alpha numeric and special characters in the search bar" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the user is able to type invalid shared course in the search bar of the Shared course page." );
            Log.assertThat( sharedCoursesPage.getValueEnteredInSearchBox().equals( AdminConstants.SharedCourses.ALPHA_NUMERIC_SPECIAL_CHAR ), "User is able to type invalid shared course in the search bar",
                    "User is not able to type invalid shared course in the search bar" );
            Log.assertThat( sharedCoursesPage.getInvalidSearchMsgTxt().equals( AdminConstants.SharedCourses.INVALID_SEARCH_RESULT ), "Not found message is displayed while entering invalid shared course",
                    "Not found message is not displayed while entering invalid shared course" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Shared Courses list view in admin dashboard", groups = { "SMK-51097", "adminDashboard", "sharedCourseListView" }, priority = 1 )
    public void tcSMSharedCourses002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMSharedCourses001: Verify Shared Courses list view in admin dashboard. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Shared Courses List View Page
            SharedCoursesListViewPage sharedCoursesPage = dashBoardPage.navigateToSharedCoursesListPage();

            SMUtils.logDescriptionTC( "Verify the Course Name header is clickable in the Shared course page" );
            SMUtils.logDescriptionTC( "Verify the Course Name header is descending sort the Course names" );
            SMUtils.logDescriptionTC( "Verify the Course Name header is ascending sort the Course names" );

            Log.assertThat( sharedCoursesPage.isColumnInAscendingOrder(), "Course Name column is sortable in ascending order", "Course Name column is not sortable in ascending order" );
            // Getting asc list from shared course table
            List<String> expectedCourseNameList = sharedCoursesPage.getListFromTable( SHARED_COURSE_TABLE_HEADER.COURSE_NAME ).stream().map( String::toLowerCase ).collect( Collectors.toList() );
            sharedCoursesPage.sortTableColumn( SHARED_COURSE_TABLE_HEADER.COURSE_NAME );
            Log.assertThat( sharedCoursesPage.isColumnInDescendingOrder(), "Course Name column is sortable in descending order", "Course Name column is not sortable in descending order" );

            // Getting dsc order list from shared course table
            List<String> actualCourseNameList = sharedCoursesPage.getListFromTable( SHARED_COURSE_TABLE_HEADER.COURSE_NAME ).stream().map( String::toLowerCase ).collect( Collectors.toList() );
            Collections.reverse( actualCourseNameList );

            // Verifying Course Name column is sortable to asc and desc order
            Log.assertThat( expectedCourseNameList.equals( actualCourseNameList ), "The Course Name column is able to sort in ascending and descending order", "The Course Name column is not able to sort in ascending and descending order" );

            SMUtils.logDescriptionTC( "Verify the Course Owner header is ascending sort the course owner" );
            SMUtils.logDescriptionTC( "Verify the Course owner header is descending sort the Course owner" );
            sharedCoursesPage.sortTableColumn( SHARED_COURSE_TABLE_HEADER.COURSE_OWNER );
            Log.assertThat( sharedCoursesPage.isColumnInAscendingOrder(), "Course Owner column is sortable in ascending order", "Course Owner column is not sortable in ascending order" );

            // Getting asc list from shared course table
            List<String> expectedOwnerList = sharedCoursesPage.getListFromTable( SHARED_COURSE_TABLE_HEADER.COURSE_OWNER ).stream().map( String::toLowerCase ).collect( Collectors.toList() );
            // Getting desc list from shared course table
            sharedCoursesPage.sortTableColumn( SHARED_COURSE_TABLE_HEADER.COURSE_OWNER );

            Log.assertThat( sharedCoursesPage.isColumnInDescendingOrder(), "Course Owner column is sortable in descending order", "Course Owner column is not sortable in descending order" );
            List<String> actualOwnerList = sharedCoursesPage.getListFromTable( SHARED_COURSE_TABLE_HEADER.COURSE_OWNER ).stream().map( String::toLowerCase ).collect( Collectors.toList() );
            Collections.reverse( actualOwnerList );

            // Verifying Course Owner column is sortable to asc and desc order
            Log.assertThat( expectedOwnerList.equals( actualOwnerList ), "The Course Owner column is able to sort in ascending and descending order", "The Course Owner column is not able to sort in ascending and descending order" );

            SMUtils.logDescriptionTC( "Verify the Organizations shared with header is ascending sort the Organizations shared with" );
            SMUtils.logDescriptionTC( "Verify the Organizations shared with header is descending sort the Organizations shared with" );
            // Getting asc list from shared course table
            sharedCoursesPage.sortTableColumn( SHARED_COURSE_TABLE_HEADER.ORGANIZATIONS_SHARED_WITH );
            Log.assertThat( sharedCoursesPage.isColumnInAscendingOrder(), "Organizations Shared With is sortable in ascending order", "Organizations Shared With column is not sortable in ascending order" );

            List<String> expectedOrgSharedWithList = sharedCoursesPage.getListFromTable( SHARED_COURSE_TABLE_HEADER.ORGANIZATIONS_SHARED_WITH ).stream().map( String::toLowerCase ).collect( Collectors.toList() );
            // Getting desc list from shared course table
            sharedCoursesPage.sortTableColumn( SHARED_COURSE_TABLE_HEADER.ORGANIZATIONS_SHARED_WITH );
            Log.assertThat( sharedCoursesPage.isColumnInDescendingOrder(), "Organizations Shared With column is sortable in descending order", "Organizations Shared With column is not sortable in descending order" );

            List<String> actualOrgSharedWithList = sharedCoursesPage.getListFromTable( SHARED_COURSE_TABLE_HEADER.ORGANIZATIONS_SHARED_WITH ).stream().map( String::toLowerCase ).collect( Collectors.toList() );
            Collections.reverse( actualOrgSharedWithList );

            // Verifying Organization Shared With is sortable to asc and desc order
            Log.assertThat( expectedOrgSharedWithList.equals( actualOrgSharedWithList ), "The Organizations Shared With column is able to sort in ascending and descending order",
                    "The Organizations Shared With column is not able to sort in ascending and descending order" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
