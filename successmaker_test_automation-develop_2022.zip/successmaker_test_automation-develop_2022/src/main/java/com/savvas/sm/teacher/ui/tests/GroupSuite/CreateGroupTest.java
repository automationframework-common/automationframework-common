package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.google.common.collect.Ordering;
import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.GroupUIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This class test the group creation UI testing.
 *
 * @author ajith.mohan
 *
 */
@Listeners ( EmailReport.class )
public class CreateGroupTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String username = null;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String student1;
    private String student2;
    private String student3;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        student1 = RBSDataSetup.getMyStudent( school, username );
        student2 = RBSDataSetup.getMyStudent( school, username );
        student3 = RBSDataSetup.getMyStudent( school, username );

    }

    @Test ( priority = 1, dataProvider = "createGroupData", groups = { "SMK-39182", "Groups", "CreateGroup" } )
    public void tcCreateGroupPositive01( ITestContext context, String groupName, String description ) throws Exception {
        
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( description + "<small><b><i>[" + browser + "]</b></i></small>" );
            
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            SMUtils.logDescriptionTC( "SMK-8225 : Verify the Teacher can create a simple group." );
            SMUtils.logDescriptionTC( "SMK-8235 : Verify teacher cannot able to create group with no student." );

            groupsTab.createGroupWithoutStudent( groupName );
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Groups Page verified successfully!", "Issue in group page" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @DataProvider ( name = "createGroupData" )
    public Object[][] createGroupData() {

        Object[][] inputData = { { GroupUIConstants.SIMPLE_GROUP_NAME, "Verify the Teacher can create a simple group" }, { GroupUIConstants.SPECIAL_CHAR_GROUP_NAME, "Verify the teacher can create group name with special character" },
                { GroupUIConstants.NUMERIC_GROUP_NAME, "Verify the groupname field accepting numeric value." }, { GroupUIConstants.EXACT_75_CHAR_GROUP_NAME, "Verify the group name accepting the exact 75 characters." },
                { GroupUIConstants.EXACT_3_CHAR_GROUP_NAME, "Verify the group name accepting the exact 3 characters." }, { GroupUIConstants.APHOSTROPHY_CHAR_GROUP_NAME, "Verify the group name accepting the (') aphostrophy symbol" },
                { GroupUIConstants.GROUP_NAME_INBETWEEN_SPACE, "Verify the group name fiels accepts the white space inbetween two words." } };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "addStudentGroupData", groups = { "SMK-39182", "Groups", "CreateGroup" } )
    public void tcCreateGroupPositive02( ITestContext context, String groupName, String description, String studentUserName ) throws Exception {
        // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( description + "<small><b><i>[" + browser + "]</b></i></small>" );
         
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            SMUtils.logDescriptionTC( "SMK-8237 : Verify the Teacher can student can be searched and added into group" );
            SMUtils.logDescriptionTC( "Verify the incorrect student search in Create a New Group" );

            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithHomeRoomStudents( groupName, studentUserName );
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @DataProvider ( name = "addStudentGroupData" )
    public Object[][] addStudentGroupData() throws Exception {

        HashMap<String, String> userDetails = new HashMap<>();

        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, "demoStuddent" + System.nanoTime() );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
        new RBSUtils().createUser( userDetails );

        Object[][] inputData = { { GroupUIConstants.SIMPLE_GROUP_NAME + 1, "Verify the Teacher can student can be searched and added into group", userDetails.get( RBSDataSetupConstants.USERNAME ) },
                { GroupUIConstants.SIMPLE_GROUP_NAME + 2, "Verify the incorrect student search in Create a New Group", "nnnnnnnnnnnnnn" } };
        return inputData;
    }

    @Test ( priority = 3, groups = { "SMK-39182", "Groups", "CreateGroup" } )
    public void tcCreateGroupPositive03( ITestContext context ) throws Exception {
        // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-8266 : Verify the add student field listing the all students part of roster.<small><b><i>[" + browser + "]</b></i></small>" );
         
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            List<String> studentsUNFromUI = studentsPage.getColumnDetailsAsList().get( Constants.USER_NAME );
            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            SMUtils.waitForElementToBeClickable( groupsTab.getCreateGroupButton(), driver );
            SMUtils.clickJS( driver, groupsTab.getCreateGroupButton() );

            SMUtils.logDescriptionTC( "Verify 'Create new group' title should present in top of the create group frame." );
            SMUtils.logDescriptionTC( "Verify the X mark present in right side of the create roup frame." );
            SMUtils.logDescriptionTC( "Verify the 'Name your group' lable should present above the group name field." );
            SMUtils.logDescriptionTC( "Verify the 'Enter Name of group' placeholder should present in group name fiels." );
            SMUtils.logDescriptionTC( "Verify the 'Add students' lable present above the add students field." );
            //   SMUtils.logDescriptionTC( "Verify the 'search all the students in my school' check box present in create group UI." );

            groupsTab.verifyCreateGroupPopupLables();

            //Rosterd students will not be listed in 2022 system and it will display all the students from school.

            // SMUtils.nap( 2 );
            // List<String> studentsUNFromUIGroupsPage = groupsTab.getAllStudentListFromAddStudent().get( Constants.USER_NAME );
            // Log.assertThat( SMUtils.sortList( studentsUNFromUIGroupsPage ).equals( SMUtils.sortList( studentsUNFromUI ) ), "All the students listed from roster",
            //       "All the students not displayed as like roster.- Expected: " + SMUtils.sortList( studentsUNFromUI ) + " Actual: " + SMUtils.sortList( studentsUNFromUIGroupsPage ), driver );
            SMUtils.clickJS( driver, groupsTab.getCancelButton() );
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = false, priority = 4, dataProvider = "addStudentUnassignedAndHRG", groups = { "SMK-39182", "Groups", "CreateGroup" } )
    public void tcCreateGroupPositive04( ITestContext context, String groupName, String description, String studentUserName ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( description + "<small><b><i>[" + browser + "]</b></i></small>" );
    	    
        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( groupName, studentUserName, "All Grades" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @DataProvider ( name = "addStudentUnassignedAndHRG" )
    public Object[][] addStudentUnassignedAndHRG() throws Exception {

        Object[][] inputData = { { GroupUIConstants.SIMPLE_GROUP_NAME + "UG", "SMK-8267 : Verify the add student field listing the students part of unassigned home room group." },
                { GroupUIConstants.SIMPLE_GROUP_NAME + "Shared", "SMK-8266 : Verify the add student field listing the students part of different home room group." } };
        return inputData;
    }

    @Test ( enabled = false, priority = 5, groups = { "SMK-39182", "Groups", "CreateGroup" } )
    public void tcCreateGroupPositive05( ITestContext context ) throws Exception {
        // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-8270 : Verify the add student field list should contains the each students First Name, Last Name, Username and grade.<small><b><i>[" + browser + "]</b></i></small>" );
         
    	try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            HashMap<String, List<String>> studentDetailsFromStudentsTab = studentsPage.getColumnDetailsAsList();
            List<String> studentsUNFromUI = studentDetailsFromStudentsTab.get( Constants.USER_NAME );
            List<String> studentsFNFromUI = studentDetailsFromStudentsTab.get( Constants.FIRSTNAME );
            List<String> studentsLNFromUI = studentDetailsFromStudentsTab.get( Constants.LASTNAME );
            List<String> studentsGradeFromUI = studentDetailsFromStudentsTab.get( Constants.GRADE );

            SMUtils.logDescriptionTC( "Verify the add student list frame should not overlap the username and grade." );
            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            SMUtils.waitForElementToBeClickable( groupsTab.getCreateGroupButton(), driver );
            SMUtils.clickJS( driver, groupsTab.getCreateGroupButton() );
            SMUtils.nap( 2 );
            HashMap<String, List<String>> studentDetailsFromGroupTab = groupsTab.getAllStudentListFromAddStudent();
            List<String> studentsUNFromUIGroupsPage = studentDetailsFromGroupTab.get( Constants.USER_NAME );
            List<String> studentsFNFromUIGroupsPage = studentDetailsFromGroupTab.get( Constants.FIRSTNAME );
            List<String> studentsLNFromUIGroupsPage = studentDetailsFromGroupTab.get( Constants.LASTNAME );
            List<String> studentsGradeFromUIGroupsPage = studentDetailsFromGroupTab.get( Constants.GRADE );
            Log.assertThat( SMUtils.sortList( studentsUNFromUIGroupsPage ).equals( SMUtils.sortList( studentsUNFromUI ) ), "All the students UserName listed from roster",
                    "All the students UserName not displayed as like roster. Expected: " + SMUtils.sortList( studentsUNFromUI ) + " Actual: " + SMUtils.sortList( studentsUNFromUIGroupsPage ), driver );
            Log.assertThat( SMUtils.sortList( studentsFNFromUIGroupsPage ).equals( SMUtils.sortList( studentsFNFromUI ) ), "All the students FirstName listed from roster",
                    "All the students FirstName not displayed as like roster. Expected: " + studentsFNFromUI + "Actual: " + studentsFNFromUIGroupsPage, driver );
            Log.assertThat( SMUtils.sortList( studentsLNFromUIGroupsPage ).equals( SMUtils.sortList( studentsLNFromUI ) ), "All the students LastName listed from roster",
                    "All the students LastName not displayed as like roster. Expected: " + studentsFNFromUI + "Actual: " + studentsLNFromUIGroupsPage, driver );
            Log.assertThat( SMUtils.sortList( studentsGradeFromUIGroupsPage ).equals( SMUtils.sortList( studentsGradeFromUI ) ), "All the students Grade listed from roster",
                    "All the students Grade not displayed as like roster. Actual - " + studentsGradeFromUIGroupsPage + "Actual - " + studentsGradeFromUI, driver );

            SMUtils.clickJS( driver, groupsTab.getCancelButton() );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 6, groups = { "SMK-39182", "Groups", "CreateGroup" } )
    public void tcCreateGroupPositive06( ITestContext context ) throws Exception {
    	 // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-8234 : Verify teacher can access help documenation in create new group modal window should." + "<small><b><i>[" + browser + "]</b></i></small>" );
       
    	try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "Verify the help is loaded when the teacher clicks i icon from the header of create group frame." );
            SMUtils.logDescriptionTC( "Verify the i icon displayed next to create new group title." );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            SMUtils.waitForElementToBeClickable( groupsTab.getCreateGroupButton(), driver );
            SMUtils.clickJS( driver, groupsTab.getCreateGroupButton() );
            SMUtils.nap( 2 );
            SMUtils.clickJS( driver, groupsTab.getiIcon() );
            SMUtils.nap( 3 );
            String winHandleBefore = driver.getWindowHandle();
            for ( String winHandle : driver.getWindowHandles() ) {
                driver.switchTo().window( winHandle );
            }
            String title = driver.getTitle();
            Log.assertThat( title.trim().equalsIgnoreCase( GroupUIConstants.CREATE_GROUP_HELP_TITLE.trim() ), "Help Page loaded successfully.", "Issue with help Page. - " + driver.getCurrentUrl() );
            driver.close();
            driver.switchTo().window( winHandleBefore );
            SMUtils.clickJS( driver, groupsTab.getCancelButton() );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 7, dataProvider = "createGroupDataNegative", groups = { "SMK-39182", "Groups", "CreateGroup" } )
    public void tcCreateGroupNegative07( ITestContext context, String groupName, String description, String errorMessage ) throws Exception {
    	 // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( description + "<small><b><i>[" + browser + "]</b></i></small>" );
       
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            if ( groupName.equalsIgnoreCase( GroupUIConstants.BELOW_3_CHAR_GROUP_NAME ) ) {
                SMUtils.logDescriptionTC( "Verify the group name not accepting the value less then 3 characters." );
            } else if ( groupName.equalsIgnoreCase( GroupUIConstants.ABOVE_75_CHAR_GROUP_NAME ) ) {
                SMUtils.logDescriptionTC( "Verify the group name not accepting the vlaue more then 75 characters." );
            } else if ( groupName.equalsIgnoreCase( GroupUIConstants.NULL_GROUP_NAME ) ) {
                SMUtils.logDescriptionTC( "Verify the group name not accepting the whitespace value" );
                SMUtils.logDescriptionTC( "Verify the groupname not accepting the null value." );
            }
            //Verifying the error messages
            groupsTab.groupNameErrorVerification( groupName, errorMessage );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @DataProvider ( name = "createGroupDataNegative" )
    public Object[][] createGroupDataNegative() {

        Object[][] inputData = { { GroupUIConstants.BELOW_3_CHAR_GROUP_NAME, "Verify the Teacher cannot able to create group with groupname is less than 3 character length", GroupUIConstants.MIN_MAX_ERROR_MESSAGE },
                { GroupUIConstants.ABOVE_75_CHAR_GROUP_NAME, "Verify the Teacher cannot able to create group with groupname is greater than 75 character length", GroupUIConstants.MIN_MAX_ERROR_MESSAGE },
                { GroupUIConstants.NULL_GROUP_NAME, "Verify the Teacher cannot able to create group with only whitespaces.", GroupUIConstants.NULL_GROUP_NAME_ERROR_MESSAGE } };
        return inputData;
    }

    @Test ( enabled = false, priority = 8, groups = { "SMK-39182", "Groups", "CreateGroup" } )
    public void tcCreateGroupNegative08( ITestContext context ) throws Exception {
    	 // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the teacher cannot able to create duplicate group name." + "<small><b><i>[" + browser + "]</b></i></small>" );
       
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            String groupName = "Duplicate group";
            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            //Creating group
            groupsTab.createGroupWithoutStudent( groupName );

            //This functionality removed from 2022 system and system will allow the duplicate group name
            //    SMUtils.logDescriptionTC( "Verify the group name field not accepting the duplicate name." );
            //Verifying the error messages
            //  groupsTab.groupNameErrorVerification( groupName, GroupUIConstants.DUPLICATE_GROUP_NAME_MESSAGE );
            //  SMUtils.clickJS( driver, groupsTab.getCancelButton() );

            SMUtils.logDescriptionTC( "Verify the group name field accepting the duplicate group name that part of other teacher." );
            groupsTab.createGroupWithoutStudent( groupName );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-39182", "Groups", "CreateGroup" } )
    public void tcCreateGroupNegative09( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Add student functionality check" + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            String invalidGroupName = "AutoMation_Group_Invalid";

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            SMUtils.clickJS( driver, groupsTab.getCreateGroupButton() );

            SMUtils.waitForElement( driver, groupsTab.getPopupHeader(), 5 );

            SMUtils.logDescriptionTC( "Verify the student sorted list in Create new group modal window should" );
            SMUtils.logDescriptionTC( "Verify the add student field list should be sorted alphabetically in ascending order by first name last name." );
            groupsTab.searchGroupTextField.sendKeys( "smauto" );
            SMUtils.nap( 3 );
            Log.assertThat( Ordering.natural().isOrdered( groupsTab.getAllStudentList() ), "Studdent Names displayed in sorted form as expected.", "Student field is not sorted." );

            SMUtils.logDescriptionTC( "Verify the cancel button cancelling the group creation." );
            SMUtils.logDescriptionTC( "Verify clicking cancel button will not create group." );
            SMUtils.enterValue( groupsTab.getGroupNameTextBoxInPopup(), invalidGroupName );

            SMUtils.clickJS( driver, groupsTab.getCancelButton() );
            Log.assertThat( !groupsTab.isGroupExist( invalidGroupName ), "Group is not created after clicked the cancel button!", "Group is created after clicked the cancel button!" );

            SMUtils.logDescriptionTC( "Verify the X icon cancelling the group creation." );
            SMUtils.logDescriptionTC( "Verify clicking 'X' icon will not create any group" );
            SMUtils.clickJS( driver, groupsTab.getCreateGroupButton() );
            SMUtils.waitForElement( driver, groupsTab.getPopupHeader(), 5 );

            SMUtils.logDescriptionTC( "Verify the create group button disabled when the group name is empty." );
            Log.assertThat( !groupsTab.getCreateButton().isEnabled(), "Create group button disabled correctly before validation completed!", "Create group button enabled before completing the validations" );

            SMUtils.logDescriptionTC( "Verify the create group button color is gray when it is disabled." );
            Log.assertThat( groupsTab.getCreateButton().getCssValue( "background-color" ).equalsIgnoreCase( GroupUIConstants.CREATE_BUTTON_COLOR_DISABLED ), "Create group button diplayed in Gray color", "Create group diplayed in different color" );
            SMUtils.enterValue( groupsTab.getGroupNameTextBoxInPopup(), invalidGroupName );

            SMUtils.logDescriptionTC( "Verify the create group button enabled when teacher add single student to group." );
            SMUtils.logDescriptionTC( "Verify create group button is enabled when teacher not selected any students." );
            SMUtils.waitForElementToBeClickable( groupsTab.getCreateButton(), driver );
            Log.assertThat( groupsTab.getCreateButton().isEnabled(), "Create group button enabled correctly after validation completed!", "Create group button diabled after completing the validations" );

            SMUtils.logDescriptionTC( "Verify the create group button color is blue when it is enabled." );
            Log.assertThat( groupsTab.getCreateButton().getCssValue( "background-color" ).equalsIgnoreCase( GroupUIConstants.CREATE_BUTTON_COLOR_ENABLED ), "Create group button diplayed in Blue color", "Create group diplayed in different color" );

            SMUtils.logDescriptionTC( "Verify the teacher can see the lable ('Start typing to search for students') in student listing panel." );
            groupsTab.verifyDisplayMessage( false );
            SMUtils.logDescriptionTC( "Verify the teacher can see the message ('No students meet your search criteria') when there is no search results." );
            SMUtils.enterValue( groupsTab.getAddStudentTextBox(), "invalidStudent" );
            groupsTab.verifyDisplayMessage( true );

            SMUtils.logDescriptionTC( "Verify the the grade drop down is not displayed when the teacher unchecks the 'Search all students in school' check box." );
            //   groupsTab.clickSelectStudentFromSchoolCheckBox();
            Log.assertThat( groupsTab.isGradeDropdownDisplayed(), "Grade dropdown not displayed when teacher uncheck the school selection!", "Grade dropdown displayed when teacher uncheck the school selection!" );

            SMUtils.logDescriptionTC( "Verify the add student field list should display the list of students with first name and last name in block letters on the firstline." );
            SMUtils.logDescriptionTC( "Verify the add student field list should display the list of students with username and grade in normal letters on the second line." );

            SMUtils.logDescriptionTC( "Verify the add student field suggesting the students based on firstname" );
            groupsTab.addStudentInGroupPopup( Constants.FIRSTNAME, SMUtils.getKeyValueFromResponse( student1, RBSDataSetupConstants.FIRSTNAME ) );

            SMUtils.logDescriptionTC( "Verify the add student field suggesting the students based on lastname" );
            groupsTab.addStudentInGroupPopup( Constants.LASTNAME, SMUtils.getKeyValueFromResponse( student2, RBSDataSetupConstants.LASTNAME ) );

            SMUtils.logDescriptionTC( "Verify the add student field suggesting the students based on username" );
            groupsTab.addStudentInGroupPopup( Constants.USER_NAME, SMUtils.getKeyValueFromResponse( student3, RBSDataSetupConstants.USERNAME ) );

            SMUtils.logDescriptionTC( "Verify the add student field listing all the students based on grades." );
            SMUtils.logDescriptionTC( "Verify the add student field listing all the students based on single grade." );

            SMUtils.logDescriptionTC( "Verify the Grade Filter option of list of student in Create a new group modal window" );
            // groupsTab.clickSelectStudentFromSchoolCheckBox();

            groupsTab.searchGroupTextField.sendKeys( "smauto" );
            SMUtils.nap( 3 );
            groupsTab.selectGrade( "Grade 1" );

            groupsTab.getAllGradesFromStudentList().forEach( grade -> {
                if ( !grade.substring( 1 ).equalsIgnoreCase( "Grade 1" ) ) {
                    Log.fail( "Grade not filtered as per grade filter." );
                } else {
                    Log.pass( "Grade is filtered successfully!" );
                }
            } );

            SMUtils.logDescriptionTC( "Verify the add student field accepting String value." );
            groupsTab.enterValueInAddStudentFilter( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.verifyDisplayMessage( true );

            SMUtils.logDescriptionTC( "Verify the add student field accepting String value." );
            groupsTab.enterValueInAddStudentFilter( GroupUIConstants.EXACT_75_CHAR_GROUP_NAME );
            groupsTab.verifyDisplayMessage( true );

            SMUtils.logDescriptionTC( "Verify the add student field accepting the special characters." );
            groupsTab.studentFieldErrorVerification( GroupUIConstants.NULL_STUDENTNAME_ERROR );
            groupsTab.verifyDisplayMessage( true );

            SMUtils.logDescriptionTC( "Verify the add student accepting the null value." );
            SMUtils.logDescriptionTC( "Verify the add student accepting the whitespace value" );
            groupsTab.studentFieldErrorVerification( GroupUIConstants.NULL_STUDENTNAME_ERROR );
            groupsTab.verifyDisplayMessage( true );

            SMUtils.logDescriptionTC( "Verify the add student field accepting numeric value." );
            groupsTab.enterValueInAddStudentFilter( GroupUIConstants.NUMERIC_GROUP_NAME );
            groupsTab.verifyDisplayMessage( true );

            SMUtils.logDescriptionTC( "Verify the X mark present in right side of the create group frame." );
            groupsTab.closeCreateGroupPopupUsingXIcon();
            Log.assertThat( !groupsTab.isGroupExist( invalidGroupName ), "Group is not created after clicked the X icon!", "Group is created after clicked the X icon!" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 10, groups = { "SMK-39182", "Groups", "CreateGroup" } )
    public void tcCreateGroupNegative10( ITestContext context ) throws Exception {
    	 // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Add student functionality! " + "<small><b><i>[" + browser + "]</b></i></small>" );
       
        String studentNameWith75Char = "SuccessMaker75CharacterStudentSuccessMaker75CharacterStudentSuccessMakerTes";
        String studentName = "smTestStudent" + System.nanoTime();
        HashMap<String, String> userDetails = new HashMap<>();

        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, studentNameWith75Char );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
        new RBSUtils().createUser( userDetails );
        userDetails.put( RBSDataSetupConstants.USERNAME, studentName );
        new RBSUtils().createUser( userDetails );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            SMUtils.clickJS( driver, groupsTab.getCreateGroupButton() );
            SMUtils.waitForElement( driver, groupsTab.getPopupHeader(), 5 );

            SMUtils.logDescriptionTC( "Verify the add student field not listing the unassigned students." );
            SMUtils.logDescriptionTC( "Verify the teacher can see only home room group students when the select students from school checkbox is unchecked." );
            groupsTab.searchGroupTextField.sendKeys( "smauto" );
            SMUtils.nap( 3 );
            List<String> studentList = groupsTab.getAllStudentList();
            Log.message( "Displayed students:" + studentList );
            //  boolean isUnssignedDisplayed = studentList.stream().filter( studentNameUI -> studentNameUI.contains( studentName ) ).findAny().isPresent();
            //  Log.assertThat( !isUnssignedDisplayed, "Unassigned students are not displayed !", "Unassigned students are displayed!" );

            SMUtils.logDescriptionTC( "Verify the add button in every student details." );
            SMUtils.logDescriptionTC( "Verify the add student field displaying each student in seperate frame." );

            SMUtils.logDescriptionTC( "Verify the add student field accepting infinite number of students in group." );
            SMUtils.logDescriptionTC( "Verify the add student field enlarging when there is multiple students added." );

            SMUtils.logDescriptionTC( "Verify the teacher can add one by one student to class." );
            SMUtils.logDescriptionTC( "Verify the teacher can see remove option in student list when the student already added to group." );

            SMUtils.logDescriptionTC( "Verify the teacher can not add same student again in group." );

            groupsTab.addStudentInGroupPopup( Constants.FIRSTNAME, studentList.get( 0 ) );

            SMUtils.logDescriptionTC( "Verify the scroll displayed in add student field when there is more number of students added to group." );
            SMUtils.logDescriptionTC( "Verify the add student field student card have X icon." );
            SMUtils.logDescriptionTC( "Verify the teacher can remove the added student by clicking X icon in student card from add student field." );

            groupsTab.removeStudentFromSelection( studentList.get( 0 ) );

            SMUtils.logDescriptionTC( "Verify the student can be added and removed and added again to group while creating a new group" );
            groupsTab.addStudentInGroupPopup( Constants.FIRSTNAME, studentList.get( 0 ) );

            SMUtils.logDescriptionTC( "Verify the add student field displaying student firstname and last name in card format." );
            groupsTab.getAddStudChipTextValue();

            SMUtils.logDescriptionTC( "Verify all the students displaying from the school when the teacher clicks the 'search all the students in my school'" );
            SMUtils.logDescriptionTC( "Verify the add student field listing all the students based on all grades by default." );
            groupsTab.clickSelectStudentFromSchoolCheckBox();
            groupsTab.selectGrade( "All Grades" );

            //Unassigned Group is removed as part of 2022
            /*
             * SMUtils.nap( 2 ); //This nap required for safari execution
             * groupsTab.enterValueInAddStudentFilter( studentName );
             * SMUtils.nap( 2 ); List<String> schoolStudents =
             * groupsTab.getAllStudentList();
             */

            //    SMUtils.logDescriptionTC( "Verify unassigned students displaying from the school when the teacher clicks the 'search all the students in my school'" );
            //  Log.assertThat( schoolStudents.stream().filter( studentNameUI -> studentNameUI.contains( studentName ) ).findAny().isPresent(), "Unassigned students from school displayed successfully!", "Unassigned Students not displayed properly" );

            //  groupsTab.enterValueInAddStudentFilter( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( SMUtils.getKeyValueFromResponse( DataSetup.teacherDetailsMap.get( "Teacher2" ), "data,userId" ) ).get( "Student3" ), "data,userName" ) );
            //  schoolStudents = groupsTab.getAllStudentList();
            // SMUtils.logDescriptionTC( "Verify the teacher can add the shared student across the school." );
            //  SMUtils.logDescriptionTC( "Verify all the students displaying from all teacher home room group school when the teacher clicks the 'search all the students in my school'" );

            //Now the functionality changed to display all the students in the school
            // Log.assertThat(
            //       schoolStudents.stream().filter( studentNameUI -> studentNameUI.contains(
            //             SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( SMUtils.getKeyValueFromResponse( DataSetup.teacherDetailsMap.get( "Teacher2" ), "data,userId" ) ).get( "Student3" ), "data,firstName" ) ) ).findAny().isPresent(),
            //   "Other teacher students from school displayed successfully!", "Other teacher Students not displayed properly" );

            SMUtils.logDescriptionTC( "Verify the add student list frame not extending when the student first name and last name contains 75 characters." );
            SMUtils.logDescriptionTC( "Verify the add student list frame not overlaping when the student first name and last name contains 75 characters." );
            SMUtils.logDescriptionTC( "Verify the add student list frame not extending when the student username contains 75 characters." );

            SMUtils.logDescriptionTC( "Verify the add student list frame not overlaping when the student username contains 75 characters." );
            groupsTab.enterValueInAddStudentFilter( studentNameWith75Char );
            SMUtils.nap( 3 );
            Log.assertThat( groupsTab.getStudentInfoFrameInCreateGroupPopup().getCssValue( "width" ).equalsIgnoreCase( GroupUIConstants.STUDENT_INFO_MAX_SIZE ), "Frame is not extended when the student name contain above 75 characters",
                    "Frame is extended when the student name contain above 75 characters. Expected - " + GroupUIConstants.STUDENT_INFO_MAX_SIZE + " , Actual -  " + groupsTab.getStudentInfoFrameInCreateGroupPopup().getCssValue( "width" ) );

            groupsTab.closeCreateGroupPopupUsingXIcon();
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
