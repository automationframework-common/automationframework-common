
package com.savvas.sm.api.tests.smnew.groups;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertNotEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.DeleteGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.getGroupListAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.studentsNotPartofGroupsAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

/**
 * To test the students not part of group API
 * 
 * @author nishanth.kamaraj
 *
 */

public class StudentsNotPartOfGroupAPI extends GroupAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    String sessionCookie;

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String classId = null;
    String className = null;

    // Teacher variable used for this class
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String school2 = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String teacherUsed = null;
    private String secondteacherUsed = null;
    private String orgId;
    private String teacherId;
    private String username;
    private String studUsed;
    private String stud2Used;
    private String stud3Used;
    private String studId;
    private String stud2Id;
    private String secondstudId;
    private String thirdstudId;
    private String fourthstudId;
    private String fifthstudId;
    private String studUserName;

    // other school constants
    private String readingSchoolId;

    // Second Teacher
    private String secondTeacherId;
    private String secondTeacherUsername;

    List<String> studentRumbaIds = new ArrayList<>();


    @BeforeClass(alwaysRun=true)
    public void BeforeTest() {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        // Teacher used Details    
        teacherUsed = RBSDataSetup.getMyTeacher( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherUsed, Constants.USERID_HEADER );
        username = SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME );
        orgId = RBSDataSetup.organizationIDs.get( school );
        // Student Username
        studUsed = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME ) );
        stud2Used = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME ) );
        stud3Used = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME ) );

        studId = SMUtils.getKeyValueFromResponse( studUsed, RBSDataSetupConstants.USERID );
        studUserName = SMUtils.getKeyValueFromResponse( studUsed, RBSDataSetupConstants.USERNAME );
        secondstudId = SMUtils.getKeyValueFromResponse( stud2Used, RBSDataSetupConstants.USERID );
        thirdstudId = SMUtils.getKeyValueFromResponse( stud3Used, RBSDataSetupConstants.USERID );

        studentRumbaIds.add( studId );
        studentRumbaIds.add( secondstudId );
        studentRumbaIds.add( thirdstudId );

        // Second Teacher for Data Setup purposes
        Log.message( "teacher details:" + RBSDataSetup.orgTeacherDetails );
        secondteacherUsed = RBSDataSetup.getMyTeacher( school );
        secondTeacherUsername = SMUtils.getKeyValueFromResponse( secondteacherUsed, RBSDataSetupConstants.USERNAME );
        secondTeacherId = SMUtils.getKeyValueFromResponse( secondteacherUsed, RBSDataSetupConstants.USERID );
    }

    @Test ( dataProvider = "studentNotPartofGroupPositiveScenariosData", groups = { "smoke_test_case", "Smoke TC001_StudentNotPartOfGroup","Student noT part Of Group","P1","SMK-51967", "Group", "Student noT part Of Group", "P1", "API" } )
    public void tcStudentNotPartofGroup001( String description, String scenario, String statusCode ) throws Exception {
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        List<String> studentRumbaIdEmpty = new ArrayList<>();
        ArrayList<String> groupIds = new ArrayList<>();
        List<String> schools = new ArrayList<>();
        String multiSchoolTeacher = null;
        HashMap<String, String> response;

        Log.testCaseInfo( description );

        String groupName = "Successmaker API Test Group " + System.nanoTime();
        String duplicateGroupName = "Duplicate Class" + System.nanoTime();

        HashMap<String, String> userDetails = new HashMap<>();
        switch ( scenario ) {

            case "VALID SCENARIO":
                Log.testCaseInfo( "Verify the teacher cannot see the students from whole school. (Only should see from the rostered students.)" );
                Log.testCaseInfo( "Verify the Group is updated if it have No Students" );
                Log.testCaseInfo( "Verify First name Field has value in the Response" );
                Log.testCaseInfo( "Verify Last name Field has value in the Response" );
                Log.testCaseInfo( "Verify Grade name Field has value in the Response" );
                Log.testCaseInfo( "Verify Grade Id field has value in the Response" );
                Log.testCaseInfo( "Verify the Username field has Value in the Response" );
                Log.testCaseInfo( "Verify the Student Id field has value in the Response" );

                studentRumbaIds.add( studId );
                studentRumbaIds.add( secondstudId );
                studentRumbaIds.add( thirdstudId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName + System.nanoTime() );
                response = createGroup( smUrl, groupDetails, studentRumbaIdEmpty );

                String emptyGroup = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, emptyGroup );

                break;

            case "GROUP WITH SHARED STUDENT":
                Log.testCaseInfo( "Verify the Response if the group have no assignments" );

                String multiSchoolStudent = "MultiSchStudent" + System.nanoTime();
                studentRumbaIds.add( studId );

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

                schools.add( RBSDataSetup.organizationIDs.get( school ) );
                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                String finalSchool = "";
                for ( String school : schools ) {
                    finalSchool += school.concat( "\",\"" );
                }
                finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
                String multiSchoolStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( multiSchoolStudentID );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String sharedStudentGroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, sharedStudentGroupId );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, sharedStudentGroupId );
                break;

            case "GROUP WITH MULTIPLE SCHOOL TEACHER":
                multiSchoolTeacher = "MultiSchTeacher" + System.nanoTime();

                studentRumbaIds.add( studId );

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
                schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
                String listString = "";
                for ( String school : schools ) {
                    listString += school.concat( "\",\"" );
                }
                listString = listString.substring( 0, listString.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
                String multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                response = createGroup( smUrl, groupDetails, studentRumbaIdEmpty );

                String emptyGroup2 = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                String MultiGrpId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, emptyGroup2 );
                break;

            case "REMOVE STUDENT FROM GROUP":
                //empty group
                Log.testCaseInfo( "Verify the Response if the group has all the student part of one Teacher" );
                Log.testCaseInfo( "Verify the Response With valid GroupId and Org Id and Rostered Teacher ID with basic instance" );

                ArrayList<String> studentRumbaIdremove = new ArrayList<>();
                studentRumbaIdremove.add( secondstudId );
                
                studentRumbaIds.add( studId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                response = createGroup( smUrl, groupDetails, studentRumbaIds );

                String removeStudGroup = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                groupIds.add( removeStudGroup );

                String accessCode = new RBSUtils().getAccessToken( username, password );
                //boolean status = new RBSUtils().deleteStudentFromSection( removeStudGroup, teacherId, studId );
                removeStudentFromGroup( smUrl, studId, removeStudGroup, teacherId, orgId, accessCode );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, removeStudGroup );

                break;

            case "SHARED STUDENT GROUP":
                Log.testCaseInfo( "Verify the Response if the group have duplicate names" );
                String sharedTeacher = "SharedTeacher" + System.nanoTime();
                String sharedStudent = "SharedStudent" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, sharedTeacher );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );

                String sharedTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                userDetails.put( RBSDataSetupConstants.USERNAME, sharedStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                String sharedStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                studentRumbaIds.add( sharedStudentID );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( secondTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, secondTeacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, duplicateGroupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String sharedstudgrp = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                response = createGroup( smUrl, groupDetails, studentRumbaIdEmpty );
                String sharedstudgrp2 = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( secondTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, secondTeacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, sharedstudgrp2 );
                break;

            case "ORG LEVEL STUD IN GROUP":

                String orphanStudent = "orphanStudent" + System.nanoTime();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
                userDetails.put( RBSDataSetupConstants.USERNAME, orphanStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                String orphanStudentId = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                studentRumbaIds.add( studId );
                studentRumbaIds.add( secondstudId );
                studentRumbaIds.add( thirdstudId );
                studentRumbaIds.add( orphanStudentId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName + System.nanoTime() );
                response = createGroup( smUrl, groupDetails, studentRumbaIdEmpty );

                String orphanStudGroup = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, orphanStudGroup );

                break;

            case "ALL STUDENT IN ONE GROUP":
                Log.testCaseInfo( "Verify the Group is updated if it have No Students" );
                studentRumbaIds.add( studId );
                studentRumbaIds.add( secondstudId );
                studentRumbaIds.add( thirdstudId );
                studentRumbaIds.add( fourthstudId );
                studentRumbaIds.add( fifthstudId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( secondTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, secondTeacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );

                String Group = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( secondTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, secondTeacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, Group );
                break;

            case "INVALID GROUPID":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String emptygroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, getGroupListAPIConstants.INVALID_INPUT );
                break;

            case "OTHER TEACHER GROUPID":
                Log.testCaseInfo( "Verify the teacher cannot get the student details from other teacher group." );
                Log.testCaseInfo( "Verify the teacher can able to see the orphan students.(not part of any class)." );

                orphanStudent = "orphanStudent" + System.nanoTime();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
                userDetails.put( RBSDataSetupConstants.USERNAME, orphanStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                orphanStudentId = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String emptygroupId6 = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( secondTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, secondTeacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, emptygroupId6 );
                break;

            case "NO_SM_PRODCUT":
                className = "ClasstoNoSMprod" + System.nanoTime();
                accessCode = new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                String noProdGrp = new RBSUtils().CreateClassWithoutSMProdcut( className, teacherId, studId, orgId, accessCode );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, noProdGrp );
                break;

        }
        HashMap<String, String> putResponse = StudentsNotPartOfGroupAPI( smUrl, userDetails );
        Log.message( putResponse.toString() );
        Log.assertThat( ( putResponse.get( Constants.STATUS_CODE ) ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                "Issue in returning status code! Expected - " + statusCode + " Actual - " + putResponse.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + putResponse.get( Constants.REPORT_BODY ) );
        verifyResponse( putResponse, studentRumbaIds );
        //Schema validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( studentsNotPartofGroupsAPIConstants.SCHEMA_FILE, statusCode, putResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        Log.testCaseResult();

    }

    /**
     * Data provider to give the data of negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "studentNotPartofGroupPositiveScenariosData" )
    public Object[][] studentNotPartofGroupValid() {

        //Commented cases are has future backlog tickets since its excluded from execution
        Object[][] inputData = { 
                { "Verify Response Code 200 For valid Scenario with Proper response", "VALID SCENARIO", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the Response if Student Part of Multiple Teacher(Shared Student)", "SHARED STUDENT GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the Response if Group is part of multiple Teachers (Shared Group)", "GROUP WITH MULTIPLE SCHOOL TEACHER", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can able to see the student when the student is removed from group.", "REMOVE STUDENT FROM GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify you added a org level student in one group and verify in the other group this student is listing.", "ORG LEVEL STUD IN GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the Response With Valid Org Id and Teacher id and invalid Group ID", "INVALID GROUPID", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can not able to see the students once they added into group. ", "ALL STUDENT IN ONE GROUP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the Response With Valid Org Id and Teacher id and other Teacher Group ID", "OTHER TEACHER GROUPID", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher can not able to see the students once they added into group. ", "NO_SM_PRODCUT", CommonAPIConstants.STATUS_CODE_OK }

        };
        return inputData;

    }

    @Test ( dataProvider = "studentNotPartofGroupNevativeScenariosData", groups = { "SMK-51967", "Group", "Student noT part Of Group", "P1", "API" } )
    public void tcStudentNotPartofGroup002( String description, String scenario, String statusCode ) throws Exception {
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> userDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        HashMap<String, String> response = new HashMap<>();

        Log.testCaseInfo( description );

        String exception = null;
        boolean status = false;
        String message = null;
        String groupName = "SM TEST UPDATE CLASS";

        switch ( scenario ) {

            case "INVALID TEACHERID":

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String emptygroupId2 = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, emptygroupId2 );
                userDetails.put( CreateGroupAPIConstants.INVALID_TEACHER, getGroupListAPIConstants.INVALID_INPUT );
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.INVALID_TEACHER_MESSSAGE;
                status = true;
                break;

            case "INVALID ORGID":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String emptygroupId3 = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, emptygroupId3 );
                userDetails.put( CreateGroupAPIConstants.INVALID_ORG, getGroupListAPIConstants.INVALID_INPUT );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = CreateGroupAPIConstants.INVALID_ORGID_MESSAGE;
                status = true;
                break;

            case "OTHER ORGID":
                Log.testCaseInfo( "Verify the teacher can not see the students from other school" );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String emptygroupId4 = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.INVALID_ORG, readingSchoolId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, emptygroupId4 );
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CreateGroupAPIConstants.OTHER_ORGID_MESSAGE;
                status = true;
                break;

            case "OTHER TEACHERID":

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String emptygroupId5 = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, secondTeacherId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, emptygroupId5 );
                exception = CommonAPIConstants.JAVA_LANG_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "INVALID TOKEN":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String InvalidTokengroupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, getGroupListAPIConstants.INVALID_INPUT );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, InvalidTokengroupId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "STUDENT AUTHORIZATION":
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

                response = createGroup( smUrl, groupDetails, studentRumbaIds );
                String groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( studUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, studId );
                userDetails.put( CreateGroupAPIConstants.GROUP_ID, groupId );
                userDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );

                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

        }
        HashMap<String, String> putResponse = StudentsNotPartOfGroupAPI( smUrl, userDetails );
        Log.message( putResponse.toString() );
        Log.assertThat( putResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + putResponse.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + putResponse.get( Constants.REPORT_BODY ) );

        verifyException( putResponse.get( Constants.REPORT_BODY ), exception, status, message );

        //Schema validation
        if ( putResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( CommonAPIConstants.STATUS_CODE_OK ) ) {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( studentsNotPartofGroupsAPIConstants.SCHEMA_FILE, CommonAPIConstants.STATUS_CODE_BAD_REQUEST, putResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.",
                    "Schema is not as expected." );
        } else {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( studentsNotPartofGroupsAPIConstants.SCHEMA_FILE, statusCode, putResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        }
        Log.testCaseResult();
    }

    /**
     * Data provider to give the data of negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "studentNotPartofGroupNevativeScenariosData" )
    public Object[][] studentNotPartofGroupDataInvalid() {

        //Commented cases are has future backlog tickets since its excluded from execution
        Object[][] inputData = {
                //{ "Verify the Response With valid GroupId and Org Id and invalid Teacher ID", "INVALID TEACHERID", CommonAPIConstants.STATUS_CODE_OK },
                //{ "Verify the response for  other org id", "OTHER ORGID", CommonAPIConstants.STATUS_CODE_OK },

                { "Verify the Response With Valid Group id and Teacher ID and invalid Org ID", "INVALID ORGID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the response for Invalid Group id", "OTHER TEACHERID", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED }, { "Verify the Response with invalid access token", "INVALID TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the response for invalid authorization", "STUDENT AUTHORIZATION", CommonAPIConstants.STATUS_CODE_FORBIDDAN } };
        return inputData;
    }

    /**
     * Verify the response data
     * 
     * @param expectedResponse
     * @param actualResponse
     * @param withStudent
     * @return
     */
    public void verifyResponse( HashMap<String, String> response, List<String> studentRumbaIds ) {
        boolean isVerified = false;
        try {
            List<String> actStudentIds = new ArrayList<>();
            JSONObject userJsonObjectAct = new JSONObject( response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) );
            JSONArray jsonArray = userJsonObjectAct.getJSONArray( "data" );
            for ( int i = 0; i < jsonArray.length(); i++ ) {
                JSONObject jobj = jsonArray.getJSONObject( i );
                String actualStudentIds = new SMAPIProcessor().getKeyValues( jobj, getGroupListAPIConstants.USER_ID ).toString();
                actualStudentIds = actualStudentIds.replaceAll( "\\[", "" ).replaceAll( "\\]", "" );
                actStudentIds.add( actualStudentIds );
            }

            Log.message( "actual:" + actStudentIds );
            Log.message( "exp:" + studentRumbaIds );
            if ( ( actStudentIds.contains( studentRumbaIds ) ) ) {
                isVerified = true;
                Log.assertThat( ( isVerified ), "The User Details is  matched ", "The User Details is not  matched" );
                getExpectedUserDetailsHashMap( studentRumbaIds, response );
                actStudentIds.clear();
                studentRumbaIds.clear();
            } else {
                getExpectedUserDetailsHashMap( studentRumbaIds, response );

            }

        } catch ( Exception e ) {

        }
    }

    /**
     * Verify the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) {
        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, studentsNotPartofGroupsAPIConstants.MESSAGE_EXCEPTION ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, studentsNotPartofGroupsAPIConstants.MESSAGE_STATUS ).equalsIgnoreCase( studentsNotPartofGroupsAPIConstants.FAILURE ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, studentsNotPartofGroupsAPIConstants.MESSAGE_MESSAGE ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, studentsNotPartofGroupsAPIConstants.MESSAGE_MESSAGE ) );
        }
        return isVerified;
    }

    /**
     * To validate the student fields from response
     * 
     * @param userIds
     * @param response
     * 
     * 
     */

    public void getExpectedUserDetailsHashMap( List<String> userIds, HashMap<String, String> response ) {
        List<String> firstNameExpValue = new ArrayList<>();
        List<String> lastNameExpValue = new ArrayList<>();
        List<String> userNameExpValue = new ArrayList<>();
        List<String> personIdExpValue = new ArrayList<>();
        JSONObject userJsonObjectAct = new JSONObject( response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) );

        List<String> firstNameActValue = new ArrayList<>();
        List<String> lastNameActValue = new ArrayList<>();
        List<String> userNameActValue = new ArrayList<>();
        List<String> personIdActValue = new ArrayList<>();

        firstNameActValue = new SMAPIProcessor().getKeyValues( userJsonObjectAct, GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD );
        lastNameActValue = new SMAPIProcessor().getKeyValues( userJsonObjectAct, GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD );
        userNameActValue = new SMAPIProcessor().getKeyValues( userJsonObjectAct, GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD.toLowerCase() );
        personIdActValue = new SMAPIProcessor().getKeyValues( userJsonObjectAct, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD );
        for ( String userId : userIds ) {
            JSONObject userJsonObjectExp = new JSONObject( new RBSUtils().getUser( userId ) );
            firstNameExpValue.add( new SMAPIProcessor().getKeyValues( userJsonObjectExp, GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD ).get( 0 ) );
            lastNameExpValue.add( new SMAPIProcessor().getKeyValues( userJsonObjectExp, GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD ).get( 0 ) );
            userNameExpValue.add( new SMAPIProcessor().getKeyValues( userJsonObjectExp, GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD ).get( 0 ) );
            personIdExpValue.add( new SMAPIProcessor().getKeyValues( userJsonObjectExp, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ).get( 0 ) );
        }
        if ( personIdExpValue.size() == personIdActValue.size() ) {
            Log.assertThat( SMUtils.compareTwoList( firstNameExpValue, firstNameActValue ), "The user Details is matching as expected!", "The user Details is not matching" );
            Log.assertThat( SMUtils.compareTwoList( lastNameExpValue, lastNameActValue ), "The user Details is matching as expected!", "The user Details is not matching" );
            Log.assertThat( SMUtils.compareTwoList( userNameExpValue, userNameActValue ), "The user Details is matching as expected!", "The user Details is not matching" );
            Log.assertThat( SMUtils.compareTwoList( personIdExpValue, personIdActValue ), "The user Details is matching as expected!", "The user Details is not matching" );
        
        }
        else if(personIdExpValue != personIdActValue)
        {
            Log.assertThat(!SMUtils.compareTwoList( firstNameExpValue, firstNameActValue ), "The user details are removed from the Group as expected!", "The user details are not removed from the Group as expected!" );
            Log.assertThat(!SMUtils.compareTwoList( lastNameExpValue, lastNameActValue ), "The user details are removed from the Group as expected!", "The user details are not removed from the Group as expected!" );
            Log.assertThat(!SMUtils.compareTwoList( userNameExpValue, userNameActValue ), "The user details are removed from the Group as expected!", "The user details are not removed from the Group as expected!" );
            Log.assertThat(!SMUtils.compareTwoList( personIdExpValue, personIdActValue ), "The user details are removed from the Group as expected!", "The user details are not removed from the Group as expected!" );
        }
        
        
        else {
            Log.assertThat( firstNameActValue.containsAll( firstNameExpValue ), "The user Details is matching as expected!", "The user Details is not matching" );
            Log.assertThat( lastNameActValue.containsAll( lastNameExpValue ), "The user Details is matching as expected!", "The user Details is not matching" );
            Log.assertThat( userNameActValue.containsAll( userNameExpValue ), "The user Details is matching as expected!", "The user Details is not matching" );
            Log.assertThat( personIdActValue.containsAll( personIdExpValue ), "The user Details is matching as expected!", "The user Details is not matching" );
        }
    }
}
