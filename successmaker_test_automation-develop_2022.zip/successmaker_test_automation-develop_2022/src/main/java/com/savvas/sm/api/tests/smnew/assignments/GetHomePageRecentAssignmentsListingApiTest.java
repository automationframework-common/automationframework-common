package com.savvas.sm.api.tests.smnew.assignments;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.FileNameConstatnts;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * This class used to test the API of GET method for Home Page Recent
 * Assignments listing
 * 
 * @author dharani.chandrasekar
 *
 */
public class GetHomePageRecentAssignmentsListingApiTest extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    List<String> studentRumbaIds = new ArrayList<>();
    private String teacherUsername;
    private String teacherId;
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;
    String endpoint=null;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(school , teacherUsername), Constants.USERID_HEADER) );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
        
        
    }
    

    @Test ( priority = 1, dataProvider = "getRecentAssignmentsListing_PositiveFlow", groups = { "SMK-51918", "smoke_test_case", "AssignmentsListing", "P1", "API" } )
    public void tcGetRecentAssignmentsListing_01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> GroupDetails = new HashMap<>();
        HashMap<String, String> response = new HashMap<>();

        switch ( scenario ) {
            case "1.Teacher - No Group and No Assingmnets":
                
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
             //   assignmentDetails.put(AssignmentAPIConstants.STUDENT_ID, studentRumbaIds.get(0));
              //  getStudnetAssignmentDetailsByStudnetID(smUrl, assignmentDetails, null);
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername , RBSDataSetupConstants.DEFAULT_PASSWORD ) );
              

                break;

            case "2.Teacher -  Group and No Assingmnets":

                GroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername , RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                GroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( groupAPI.createGroup( smUrl, GroupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername , RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                break;

            case "3.TEACHER HAVING EXACTLY ONE ASSIGNEMTS":

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername , RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "statusCode" ) );
                Log.message( response.get( "body" ) );

                break;

            case "4.TEACHER HAVING EXACTLY TWO ASSIGNEMTS":

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "statusCode" ) );
                Log.message( response.get( "body" ) );

                break;

            case "5.TEACHER HAVING EXACTLY THREE ASSIGNEMTS":

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH_1 ); //Need to change in contanst file
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername , RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "statusCode" ) );
                Log.message( response.get( "body" ) );

                break;

            case "6.TEACHER HAVING EXACTLY FOUR ASSIGNEMTS":

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH_2 );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername , RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "statusCode" ) );
                Log.message( response.get( "body" ) );

                break;

            case "7.TEACHER HAVING MORETHEN FOUR ASSIGNEMTS":

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH_3 );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername , RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "statusCode" ) );
                Log.message( response.get( "body" ) );

                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }

        HashMap<String, String> getresponse = getRecentAssignmentLists( smUrl, assignmentDetails );
        Log.message( getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        validateResponse( assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), getresponse.get( "body" ) );

        // Verifying Status Code
        Log.assertThat( getresponse.get( "statusCode" ).equals( statusCode ), "Status code is matched", "Status code is mismatched" );

        // Verifying schema in the Response body
        if ( scenario.equals( "1.Teacher - No Group and No Assingmnets" ) || scenario.equals( "2.Teacher -  Group and No Assingmnets" ) ) {

            Log.assertThat( smAPIprocessor.isSchemaValid( FileNameConstatnts.GET_RECENT_ASSIGNMENTS_EXCEPCTIONS_SCHEMA_FILE, statusCode, getresponse.get( AssignmentAPIConstants.BODY_FIELD ) ), "The schema is valid and mathcing",
                    "The schema is not valid and not  mathcing for the Status code :" + statusCode );
        } else {
            Log.assertThat( smAPIprocessor.isSchemaValid( FileNameConstatnts.GET_RECENT_ASSIGNMENTS_SCHEMA_FILE, statusCode, getresponse.get( AssignmentAPIConstants.BODY_FIELD ) ), "The schema is valid and mathcing",
                    "The schema is not valid and not  mathcing for the Status code :" + statusCode );
        }

        Log.testCaseResult();
    }

    @Test ( priority = 2, dataProvider = "getRecentAssignmentsListing_NegativeFlow", groups = { "SMK-51918", "Assignments", "AssignmentsListing", "P1", "API" } )
    public void tcGetRecentAssignmentsListing_02( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );
        HashMap<String, String> response = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> params = new HashMap<>();
        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_RECENT_ASSIGNMENTS_API;

        switch ( scenario ) {
            case "1.Invalid OrgID in path":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                endPoint = endPoint.replace( "{orgID}", "InvalidOrgID" ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );

                break;

            case "2.Invalid StaffID in path":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", "1234$" );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );

                break;

            case "3.Invalid Authorzation":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) + "InvalidAuthkey" );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );

                break;

            case "4.Student Authorzation instead of teacher":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );

                break;

            case "5.Vaid userid & Empry orgid in header":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                headers.put( Constants.ORGID_SM_HEADER, " " );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );

                break;

            case "6.Vaid userid & Invalid orgid in header":

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, teacherId );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) + "InvalidOrgId" );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );

                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }
        
        Log.message( response.get( "statusCode" ) );
        Log.message( response.get( "body" ) );

        // Verifying Status Code
        Log.assertThat( response.get( "statusCode" ).equals( statusCode ), "Status code is matched", "Status code is mismatched" );

        // Verifying schema in Response body
        Log.assertThat( smAPIprocessor.isSchemaValid( FileNameConstatnts.GET_RECENT_ASSIGNMENTS_SCHEMA_FILE, statusCode, response.get( AssignmentAPIConstants.BODY_FIELD ) ), "The schema is valid and mathcing",
                "The schema is not valid and not  mathcing for the Status code :" + statusCode );

        Log.testCaseResult();
        Log.endTestCase();
    }

    /**
     * Data provider to give the postive data
     * 
     * @return
     */
    @DataProvider ( name = "getRecentAssignmentsListing_PositiveFlow" )
    public Object[][] getRecentAssignmentsListing_PositiveFlow() {

        Object[][] inputData = { 
        		{ "Verify the teacher is able to get the No assignments & No group", "1.Teacher - No Group and No Assingmnets", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher is able to get the No assignments and having groups", "2.Teacher -  Group and No Assingmnets", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher is able to get the only 1 assignments", "3.TEACHER HAVING EXACTLY ONE ASSIGNEMTS", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher is able to get the only 2 assignments", "4.TEACHER HAVING EXACTLY TWO ASSIGNEMTS", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher is able to get the only 3 assignments", "5.TEACHER HAVING EXACTLY THREE ASSIGNEMTS", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher is able to get the only 4 assignments", "6.TEACHER HAVING EXACTLY FOUR ASSIGNEMTS", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the teacher is able to get the more than 4 assignments", "7.TEACHER HAVING MORETHEN FOUR ASSIGNEMTS", CommonAPIConstants.STATUS_CODE_OK }, };

        return inputData;
    }

    /**
     * Data provider to give the negative data
     * 
     * @return
     */
    @DataProvider ( name = "getRecentAssignmentsListing_NegativeFlow" )
    public Object[][] getRecentAssignmentsListing_NegativeFlow() {

        Object[][] inputData = { { "Verify that '400 Bad Request - Expection and message' are displayed when pasing the invalid org ID in Path prams ", "1.Invalid OrgID in path", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify that '400 Bad Request - Expection and message' displayed when passing the invalid staff ID in path prams", "2.Invalid StaffID in path", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the status code is 401 when passing the invalid authorization in Header", "3.Invalid Authorzation", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code is 403 when passing the invalid authorization in Header", "4.Student Authorzation instead of teacher", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code is 403 when passing the values with combinations of Valid user-id and Empty orgid in the headers along with valid authorization", "5.Vaid userid & Empry orgid in header", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code is 403 when passing the values with Valid userid and invalid org-id in the headers", "6.Vaid userid & Invalid orgid in header", CommonAPIConstants.STATUS_CODE_FORBIDDAN } };

        return inputData;
    }


    // DB Query Validation
    public void validateResponse( String staffId, String actualResponse ) {
        JSONObject actualData = new JSONObject( actualResponse );

        if ( !SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {

            JSONArray assignmentListFromResponse = actualData.getJSONArray( "data" );

            SqlHelperCourses helper = new SqlHelperCourses();
            HashMap<String, List<String>> assignmentList = helper.getRecentAssignmentListingDetails( staffId );
            Log.message( "AssignmentDetails = " + assignmentList );
            HashMap<String, String> studentCount = new HashMap<>();
            HashMap<String, String> productId = new HashMap<String, String>();
            HashMap<String, String> assignmentTitle = new HashMap<String, String>();
            HashMap<String, String> subject = new HashMap<String, String>();

            IntStream.range( 0, assignmentList.get( AssignmentAPIConstants.ASSIGNMENT_ID ).size() ).forEach( i -> {
                String count = helper.getStudentCountForAssignment( assignmentList.get( AssignmentAPIConstants.ASSIGNMENT_ID ).get( i ) );
                studentCount.put( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ), count );
                productId.put( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ), helper.getContentBaseDetails( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ) ).get( AssignmentAPIConstants.PRODUCT_ID ) );
                assignmentTitle.put( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ), assignmentList.get( AssignmentAPIConstants.ASSIGNMENT_NAME ).get( i ) );
                subject.put( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ), helper.getContentBaseDetails( assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( i ) ).get( AssignmentAPIConstants.SUBJECT_NAME ) );
            } );

            Log.message( "Student count for Assignments - " + studentCount );
            Log.message( "Product ID for Assignments - " + productId );
            Log.message( "Assignment Title for Assignments - " + assignmentTitle );
            Log.message( "Subject for Assignments - " + subject );

            boolean isTitleVerified = false;
            boolean isSubjectVerified = false;
            boolean isProductIDVerified = false;
            boolean isStudentsCountVerified = false;

            for ( Object assignment : assignmentListFromResponse ) {
                JSONObject assignemntJson = new JSONObject( assignment.toString() );

                if ( subject.get( assignemntJson.get( "id" ).toString() ).equalsIgnoreCase( "Mathematics" ) ) {
                    subject.put( assignemntJson.get( "id" ).toString(), "MATH" );
                } else {
                    subject.put( assignemntJson.get( "id" ).toString(), "READING" );
                }

                if ( assignemntJson.get( "subject" ).toString().equalsIgnoreCase( subject.get( assignemntJson.get( "id" ).toString() ) ) ) {
                    isSubjectVerified = true;
                }

                if ( assignemntJson.get( "name" ).toString().equalsIgnoreCase( assignmentTitle.get( assignemntJson.get( "id" ).toString() ) ) ) {
                    isTitleVerified = true;
                }

                if ( assignemntJson.get( "productId" ).toString().equalsIgnoreCase( productId.get( assignemntJson.get( "id" ).toString() ) ) ) {
                    isProductIDVerified = true;
                }

                if ( assignemntJson.get( "numberStudentsActive" ).toString().equalsIgnoreCase( studentCount.get( assignemntJson.get( "id" ).toString() ) ) ) {
                    isStudentsCountVerified = true;
                }

            }

            if ( isTitleVerified ) {
                Log.pass( "Assignment title matched successfully!" );

            } else {
                Log.fail( "Assignment title mismatched!" );

            }

            if ( isSubjectVerified ) {
                Log.pass( "subject matched successfully!" );

            } else {
                Log.fail( "subject mismatched!" );
            }

            if ( isProductIDVerified ) {
                Log.pass( "productId matched successfully!" );

            } else {
                Log.fail( "productId mismatched!" );
            }

            if ( isStudentsCountVerified ) {
                Log.pass( "Active Student Count matched successfully!" );

            } else {
                Log.fail( "Active Student Count mismatched!" );
            }

        } else {
            Log.message( "Data not found exception!!" );
        }
    }
    
}