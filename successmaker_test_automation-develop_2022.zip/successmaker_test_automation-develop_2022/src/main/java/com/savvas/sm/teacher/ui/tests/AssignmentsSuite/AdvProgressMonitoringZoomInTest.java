package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.io.IOException;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

@Listeners ( EmailReport.class )

public class AdvProgressMonitoringZoomInTest extends BaseTest {
    private String smUrl;
    private String browser;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String username = null;
    private String password = null;
    private String schoolID;
    private String teacherID;
    private String stuFName;
    private String stuUserName;
    private String orgId;
    // For Simulator Execution
    private String chromePlatform = "Windows_10_Chrome_latest";
    String staticCourseName = null;
    String studentDetails;
    String teacherDetails;
    LocalDate today = LocalDate.now();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private static HashMap<String, String> mathAssignmentDetails = new HashMap<>();
    AssignmentAPI assign = new AssignmentAPI();
    private String token = null;

    @BeforeClass (alwaysRun = true)
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        
        orgId = RBSDataSetup.organizationIDs.get( school );
        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentDetails = RBSDataSetup.getMyStudent( school, username );
        stuUserName = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );
        stuFName = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );

        // token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Log.message( "Teacher access token: " + token );
        
     // Getting group details
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherID );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId);
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" + System.nanoTime() );
        // Creating a group
        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );
        
        // Assigning Math assignment
        mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
        mathAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        HashMap<String, String> mathRssignmentResponse = assign.assignMultipleAssignments( smUrl, mathAssignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );
        Log.message( mathRssignmentResponse.toString() );
        
     //    executeSimulator( stuUserName, Constants.MATH, Constants.MATH );
    }

    @Test ( description = "Verify if all links are hidden and only View Summary is visible when student's IP level is in \"In IP\" or \"--\" or \"N/A\"", priority = 1, groups = { "SMK-43631", "HomePage", "Mastery-Widget" } )
    public void tcAPMZoomIn001() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify if all links are hidden and only View Summary is visible when student's IP level is in \"In IP\" or \"--\" or \"N/A" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // To assign default Math course to the Student traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            // Click on the default Math course
            customCourses.clickFromCourseListingPage( Constants.MATH );

            // Click on the assignment
            customCourses.clickAssignBtn();

            // Assign the course to the student
            customCourses.addCourseToStudents();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // customCourses.expandForSkillDetails();
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Assert Statement
            Log.assertThat( assignmentDetailsPage.isZeroStatePresentforSkillTested(), "Zero state displayed successfully!", "Zero state message not displayed!" );

            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isDisplayedViewSummaryBtn(), "View Summary button is displayed", "View Summary button is not displayed" );
            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify if teacher is not able to see the IP level plotted on the Student's progress monitoring graph for a Custom by Settings course when IP level is turned off.", priority = 1, groups = { "SMK-45593", "HomePage",
            "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn002() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify if teacher is not able to see the IP level plotted on the Student's progress monitoring graph for a Custom by Settings course when IP level is turned off." );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            staticCourseName = customCourses.generateRandomCourseName();

            // Traverse to Courses page
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            tHomePage.topNavBar.getCourseListingPage();

            // Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            // Make a copy of the course
            customCourses.copyOfCourse( staticCourseName, Constants.SETTINGS, Constants.MATH );

            // Get Course Listing Page
            tHomePage.topNavBar.getCourseListingPage();

            // Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            // Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            // Click on course name
            customCourses.clickCourseName( staticCourseName );

            // Click on edit button for setting
            assignmentDetailsPage.clickEditSettingBtn();

            // Turn off Initial placement
            customCourses.turnOffInitialPlacement();

            // Click on save button.
            customCourses.clickSaveBtn();

            // Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            // Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            // Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            // Click on the course
            customCourses.clickCourseName( staticCourseName );

            // Click on the assignment
            customCourses.clickAssignBtn();

            // Assign the course to the student
            customCourses.addCourseToStudents();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            SMUtils.nap( 8 );
            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isDisplayedZeroIPLevel(), "Zero IP level is displayed", "Zero IP level is not displayed" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the student is able to attend the Math course via simulator", groups = { "SMK-45611", "Assignments", "PMG_EditTargets" }, priority = 1 )
    public void verifyAssignmentsPmgEditTarget_003() throws Exception {
        Log.testCaseInfo( "Verify the student is able to attend the Math course via simulator" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

     // Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);
        try {
            Log.message( "The subject name is " + Constants.MATH );
            // Executing math assignments in student dashboard
       //     String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, stuUserName, password );
            StudentDashboardPage studentDashboardPage = new StudentDashboardPage( chromeDriver );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Constants.MATH, "95", "5", "30" );
            studentDashboardPage.logout();
            chromeDriver.quit();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the user is able to view the 'Zoom In' popup.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn004() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
    	
        Log.testCaseInfo( "Verify the user is able to view the 'Zoom In' popup." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on zoom in button.
            assignmentDetailsPage.clickZoomInBtn();

            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isDisplayedVeiwGraphTitle(), "View Garph tile is displayed", "View Garph tile is not displayed" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the user able to close the 'Zoom In' popup", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn005() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify if teacher is not able to see the IP level plotted on the Student's progress monitoring graph for a Custom by Settings course when IP level is turned off." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on zoom in button.
            assignmentDetailsPage.clickZoomInBtn();

            // Click on close button in zoom in pop up
            assignmentDetailsPage.clickCloseButton();

            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isZoomInPopupClosed(), "Zoom In pop up is closed", "Zoom In pop up is not closed" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the 'Edit Target' , 'Prints' buttons are clickable.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn006() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify the 'Edit Target' , 'Prints' buttons are clickable." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on edit target button.
            assignmentDetailsPage.clickEditTargetBtn();

            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isDisplayedEditTargetTitlePopUp(), "Edit Target tile is displayed", "Edit Target tile is not displayed" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify user can able to enable/disable the 'show target' toggle button.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn007() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify user can able to enable/disable the 'show target' toggle button." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on toggle button for show target
            assignmentDetailsPage.clickToggleOffShowTarget();

            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isDisplayedToggleONShowTarget(), "Toggle button is in switched Off mode", "Toggle button switched On" );

            // Click on toggle button for show target
            assignmentDetailsPage.clickToggleONShowTarget();

            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isDisplayedToggleOffShowTarget(), "Toggle button switched On", "Toggle button switched Off" );
            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the availability of Print button in \"Zoom In\" pop up for Default Math assignment", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn008() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify the availability of Print button in \"Zoom In\" pop up for Default Math assignment" );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isDispayedPrintBtn(), "Print button is displayed", "Print button is not displayed" );
            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the availability of \"Edit Target\" link in \"Zoom In\" pop up for Default Math assignment", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn009() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify the availability of \"Edit Target\" link in \"Zoom In\" pop up for Default Math assignment" );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isDisplayedEditTargetBtn(), "Edit Target button is displayed", "Edit Target button is not displayed" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the Edit target window appears on clicking 'Edit Target' link.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn010() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify the Edit target window appears on clicking 'Edit Target' link" );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on edit target button.
            assignmentDetailsPage.clickEditTargetBtn();

            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isDisplayedToggleOffShowTarget(), "Toggle button switched on", "Toggle button switched off" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the Zoom In Link is present in blue color in progress monitoring graph .", priority = 3, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn011() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify the Zoom In Link is present in blue color in progress monitoring graph ." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Verify zoom in link is present in progress monitoring graph
            Log.softAssertThat( assignmentDetailsPage.isDisplayedZoomInLink(), "Zoom In link is displayed", "Zoom In link is not displayed" );

            // Verify color of zoom in link.
            Log.assertThat( assignmentDetailsPage.verifyColorZoomInLink(), "Color of zoom in link is as expected", "Color of zoom in link is not as expected" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the header is displayed as \"View Graph\" in bold font at top left corner in the 'Zoom In' popup..", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn012() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify the header is displayed as \"View Graph\" in bold font at top left corner in the 'Zoom In' popup." );

        try {
            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on zoom in button.
            assignmentDetailsPage.clickZoomInBtn();

            // Verify header is displayed as View Graph
            Log.softAssertThat( assignmentDetailsPage.isDisplayedVeiwGraphTitle(), "View graph tile is displayed", "View graph tile is not displayed" );

            // Verify font is bold of View Graph.
            Log.assertThat( assignmentDetailsPage.verifyViewGraphTextIsBold(), "View graph font weight is as expected", "View graph font weight is not as expected" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the 'Progress' text is dispalyed in bold font below the header.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn013() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify the 'Progress' text is dispalyed in bold font below the header." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on zoom in button.
            assignmentDetailsPage.clickZoomInBtn();

            // Verify Process Text is displayed
            Log.softAssertThat( assignmentDetailsPage.isDisplayedProgressHeader(), "Progress header is displayed", "Progress header is not displayed" );

            // Verify font is bold of progress.
            Log.assertThat( assignmentDetailsPage.verifyProgressTextIsBold( browser ), "Progress font weight is as expected", "Progress font weight is not as expected" );
            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the availability and color of 'Edit Target' , 'Prints' , 'Show Targets Toggle Button' in the 'Zoom In' popup.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn014() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify the availability and color of 'Edit Target' , 'Prints' , 'Show Targets Toggle Button' in the 'Zoom In' popup." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on zoom in button.
            assignmentDetailsPage.clickZoomInBtn();

            // Verify Edit Target button is displayed
            Log.softAssertThat( assignmentDetailsPage.isDisplayedEditTargetBtn(), "Edit Target button is displayed", "Edit Target button is not displayed" );

            // Verify Print button is displayed
            Log.softAssertThat( assignmentDetailsPage.isDispayedPrintBtn(), "Print button is displayed", "Print button is not displayed" );

            // Verify show target toggle is displayed
            Log.softAssertThat( assignmentDetailsPage.isDisplayedToggleOffShowTarget(), "Toggle button switched ON", "Toggle button switched OFF" );

            // Verify color of Print and Edit target link.
            Log.assertThat( assignmentDetailsPage.verifyColorPrintAndEditTarget(), "Color of Print And EditTarget link is as expected", "Color of Print And EditTarget link is not as expected" );

            // Verify color of Show Target Toggle.
            Log.assertThat( assignmentDetailsPage.verifyColorShowTargetToggle(), "Color of Show Target Toggle is as expected", "Color of Show Target Toggle is not as expected" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the progress bar is mapped in X-Y axis.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn015() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify the progress bar is mapped in X-Y axis." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on edit target button.
            assignmentDetailsPage.clickZoomInBtn();

            // Assert Statement to verify x-y axis is displayed
            Log.softAssertThat( assignmentDetailsPage.isDisplayedXYAxis(), "x-y axis is displayed", "x-y axis is not displayed" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify Y-axis is dispayed with text 'course level'.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn016() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify Y-axis is dispayed with text 'course level'." );

        try {

         //   LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            // Sign In
       //     TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
//            CoursesPage customCourses = new CoursesPage( driver );
//            CourseListingPage courseListingPage = new CourseListingPage( driver );
//            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
//
        	  // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            
              // Traverse to Courses page
              tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on zoom in button.
            assignmentDetailsPage.clickZoomInBtn();

            // Verify Y-axis is dispayed with text 'course level
            Log.assertThat( assignmentDetailsPage.verifyYAxisValue().equals( Constants.Y_AXIS_VALUE ), "Y axis is displayed correctly ", "Y axis is not displayed correctly " );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify x-axis is dispayed with text 'Calendar Days (Since IP)'.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn017() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify x-axis is dispayed with text 'Calendar Days (Since IP)'." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to the assignment
            tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on zoom in button.
            assignmentDetailsPage.clickZoomInBtn();

            // Verify x-axis is dispayed with text 'Calendar Days (Since IP)'.
            Log.assertThat( assignmentDetailsPage.verifyXAxisValue().contains( Constants.X_AXIS_VALUE ), "X Axis is displayed correctly", "X Axis is not displayed correctly" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify rectangular window is dispayed at bottom of the page with following parameters:Target Date,Primary Target, Secondary Target, Gain, Sessions, Current Level, IP Level.", priority = 2, groups = { "SMK-45593", "HomePage",
            "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn018() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify rectangular window is dispayed at bottom of the page with following parameters:Target Date,Primary Target, Secondary Target, Gain, Sessions, Current Level, IP Level." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            List<String> legendList = new ArrayList<>();

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on zoom in button.
            assignmentDetailsPage.clickZoomInBtn();
            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isDisplayedRectangularLgendsBox(), "Rectangular legends box is displayed", "Rectangular legends box is not displayed" );
            // Verify All legends display
            legendList = assignmentDetailsPage.getLegendNames();

            // Assersion statement
            Log.softAssertThat( ( legendList.size() == assignmentDetailsPage.getLegendNames().size() ), "All the legends are displayed successfully", "All the legends are not displayed successfully" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify if user is able to edit target date, primary target, secondary target in \"edit target \" page through zoom in option.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn019() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify if user is able to edit target date, primary target, secondary target in \"edit target \" page through zoom in option." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            List<Integer> dateList = assignmentDetailsPage.getYesterdayAndTomorrowsDate();

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on zoom in button.
            assignmentDetailsPage.clickZoomInBtn();

            // Click on edit target button.
            assignmentDetailsPage.clickEditTargetBtn();

            // Future Date
            LocalDate dateDayAfterTomorrow = LocalDate.of( today.getYear(), Month.JULY, today.getDayOfMonth()+2  );

            SMUtils.nap( 5 );// tried with Webdriver wait but did't worked.
            // Choose the required date
            LocalDate selectedDateDayAfterTomorrow = assignmentDetailsPage.chooseDate( dateDayAfterTomorrow );

            // Assertion
            Log.softAssertThat( selectedDateDayAfterTomorrow.equals( dateDayAfterTomorrow ), "Future date is as per selected by the Teacher", "Future date is not as per selected by the Teacher" );

            // Drag the slider value of primary target
            assignmentDetailsPage.drageTheSlider( 3 );
            assignmentDetailsPage.verifySliderValuesOfEditTargetPopup( Constants.DRAG_VALUES_FIRST );

            // Assertion for sliders
            Log.softAssertThat( assignmentDetailsPage.verifySliderValuesOfEditTargetPopup( Constants.DRAG_VALUES_FIRST ), "Sliders values for 'Edit Targets' popup  are appearing as expected",
                    "Sliders values for 'Edit Targets' popup  are not appearing as expected" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify if user is able to reset, cancel and save the \"edit target \" page through zoom in option.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn020() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify if user is able to reset, cancel and save the \"edit target \" page through zoom in option." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            List<Integer> dateList = assignmentDetailsPage.getYesterdayAndTomorrowsDate();

            // Traverse to the assignment
            tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on edit target button.
            assignmentDetailsPage.clickZoomInBtn();

            // Click on edit target button.
            assignmentDetailsPage.clickEditTargetBtn();

            // Perform Save operation.

            // Future Date
            LocalDate dateDayAfterTomorrow1 = LocalDate.of( today.getYear(), Month.JULY, today.getDayOfMonth() + 2 );

            SMUtils.nap( 5 );
            // Choose the required date
            LocalDate selectedDateDayAfterTomorrow1 = assignmentDetailsPage.chooseDate( dateDayAfterTomorrow1 );

            // Click on save button of edit target pop up.
            assignmentDetailsPage.clickOnSaveButtonOfEditTargets();

            // Asserssion
            Log.softAssertThat( assignmentDetailsPage.isDisplayedVeiwGraphTitle(), "Targets are saved successfully", "Targets are not saved successfully" );

            SMUtils.nap( 5 );

            // Click on edit target button.
            assignmentDetailsPage.clickEditTargetBtn();

            // Perform Reset operation
            // Past date
            LocalDate pastDate = today.minusDays( 1 );

            // Choose the required date
            LocalDate selectedPastDate = assignmentDetailsPage.chooseDate( pastDate );

            // Click on Reset Button.
            assignmentDetailsPage.clickOnResetButtonOfEditTargets();

            // Assertion
            Log.softAssertThat( !selectedPastDate.equals( assignmentDetailsPage.getSelectedDate() ), "Data is getting retained when the teacher click on the Reset button", "Data is not getting retained when the teacher click on the Reset button" );

            // Click on Close button of edit target pop up.
            assignmentDetailsPage.clickCloseButtonOfEditTargets();

            SMUtils.nap( 5 );

            // Click on edit target button.
            assignmentDetailsPage.clickEditTargetBtn();

            // Perform Cancel operation
            LocalDate dateDayAfterTomorrow2 = LocalDate.of( today.getYear(), Month.JULY, today.getDayOfMonth() + 2 );

            SMUtils.nap( 5 );// tried with Webdriver wait but did't worked.
            // Choose the required date
            LocalDate selectedDateDayAfterTomorrow2 = assignmentDetailsPage.chooseDate( dateDayAfterTomorrow2 );

            // Click on edit target button.
            assignmentDetailsPage.clickCancelButtonOfEditTargetsPopup();

            // Asserssion
            Log.softAssertThat( assignmentDetailsPage.isDisplayedVeiwGraphTitle(), "Targets are saved successfully", "Targets are not saved successfully" );
            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify legend in the View Graph popup is matching the UX.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn021() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify legend in the View Graph popup is matching the UX." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            List<String> legendList = new ArrayList<>();

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Assert Statement
            Log.softAssertThat( assignmentDetailsPage.isDisplayedRectangularLgendsBox(), "Rectangular legends box is displayed", "Rectangular legends box is not displayed" );

            // Verify All legends display
            legendList = assignmentDetailsPage.getLegendNames();

            // Verify Legends are matching with the UX.
            Log.softAssertThat( ( legendList.size() == assignmentDetailsPage.getLegendNames().size() ), "All the legends are displayed successfully", "All the legends are not displayed successfully" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify zoom in pop Up is closed by clicking outside of the pop up.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn022() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify zoom in pop Up is closed by clicking outside of the pop up." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on edit target button.
            assignmentDetailsPage.clickZoomInBtn();

            // Click ouside of the zoom in pop up.
            assignmentDetailsPage.clickOutside();

            // Verify zoom in pop is closed by clicking outside of the pop up.
            Log.softAssertThat( assignmentDetailsPage.isDisplayedViewSummaryBtn(), "Zoom in pop up closed successfully", "Zoom in pop up is not closed successfully" );
            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }

    }

    @Test ( description = "Verify the 'SHOW TARGETS' label font size is correct as per UX.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn023() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify the 'SHOW TARGETS' label font size is correct as per UX." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on edit target button.
            assignmentDetailsPage.clickZoomInBtn();

            // Verify 'SHOW TARGETS' label font size is correct as per UX
            Log.softAssertThat( assignmentDetailsPage.verifyShowTargetFontSize( browser ), "Font size of show target lable is as expected", "Font size of show target lable is not as expected" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }

    }

    @Test ( description = "Verify the font size of \"Process\" is matching with UX.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn024() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "Verify the font size of \"Process\" is matching with UX." );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on edit target button.
            assignmentDetailsPage.clickZoomInBtn();

            // Verify the font size of "Process" is matching with UX
            Log.softAssertThat( assignmentDetailsPage.verifyProgressFontSize(), "Font size of Progress is as expected", "Font size of Progress is not as expected" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }

    }

    @Test ( description = "MAC Safari>> Verify the text for \"primary target\" and \"secondary target\" is completely visible in chart.\"", priority = 3, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn025() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "MAC Safari>> Verify the text for \"primary target\" and \"secondary target\" is completely visible in chart.\"" );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on edit target button.
            assignmentDetailsPage.clickZoomInBtn();

            // Verify Primary target is visible in legends chart.
            Log.assertThat( assignmentDetailsPage.checkLegendNames( Constants.PRIMARY_TARGET ), "Primary Target Displayed Successfuly", "Primary Target Not Displayed" );

            // Verify Secendory target is visible in legends chart.
            Log.assertThat( assignmentDetailsPage.checkLegendNames( Constants.SECONDARY_TARGET ), "Secondary Target Displayed Successfuly", "Secondary Target Not Displayed" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }

    }

    @Test ( description = "Verify the UX appearance on clicking 'Zoom In' link.", priority = 2, groups = { "SMK-45593", "HomePage", "Advance Progress Moinitoring-Zoom In" } )
    public void tcAPMZoomIn027() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "TC029_Verify border is present between 'View Graph' and \"Progress\"" );

        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            // Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            // Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            // Click on plus icon to expand the student.
            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );
            assignmentDetailsPage.scrollInToExpandedStudent();

            // Click on Zoom in button.
            assignmentDetailsPage.clickZoomInBtn();

            // Verify Horizontal line
            SMUtils.logDescriptionTC( "SMK-13961 : TC029_Verify border is present between 'View Graph' and \"Progress\"" );
            Log.softAssertThat( assignmentDetailsPage.isHorizonalLinePresent(), "Border line is present between 'View Graph' and 'Progress'", "Border line is not present between 'View Graph' and 'Progress'" );

            // Verify Padding of the graph area
            SMUtils.logDescriptionTC( "SMK-13965 : TC033_Verify paddings around the graph are as per the UX" );
            Log.softAssertThat( assignmentDetailsPage.paddingOfViewGraph( browser ), "Padding of Graph area is as expected", "Padding of Graph area is not as expected" );

            // Verify Last date on X axis of the graph area
            SMUtils.logDescriptionTC( "SMK-13966 : TC034_Verify alignment of last date on x-axis is proper as shown in UX." );
            Log.softAssertThat( assignmentDetailsPage.positionOfLastDateInXAxis(), "Alignment of last date on x-axis is as expected", "Alignment of last date on x-axis is not as expected" );

            // Position of Target line
            SMUtils.logDescriptionTC( "SMK-13970 : TC038_Verify Spacing Between Target Date and arrow of x-axis is proper." );
            Log.softAssertThat( assignmentDetailsPage.isTargetLinePresent(), "Spacing Between Target Date and arrow of x-axis is proper.", "Spacing Between Target Date and arrow of x-axis is not proper." );

            // Presence of Gain label in legend menu
            SMUtils.logDescriptionTC( "SMK-13971 : TC039_Verify positioning of Gain label is as per UX" );
            Log.softAssertThat( assignmentDetailsPage.isGainPresent(), "Gain label is present", "Gain label is not present" );

            // Verify First date on X axis of the graph area
            SMUtils.logDescriptionTC( "SMK-13972 : TC040_Verify positioning of Target Date on the x-axis is as per UX" );
            Log.softAssertThat( assignmentDetailsPage.isFirstDatePresent(), "Positioning of Target Date on the x-axis is as expected", "Positioning of Target Date on the x-axis is not as expected" );

            // Verify Course level text
            SMUtils.logDescriptionTC( "SMK-13974 : TC042_Verify spacing of the Calendar days and Course level is as per UX" );
            Log.softAssertThat( assignmentDetailsPage.positionOfCourseLevelTextOnYAxis(), "Course level is present", "Course level is not present" );

            // Verify presence of legend image
            SMUtils.logDescriptionTC( "SMK-13975 : TC043_Verify space between the legends on the Zoom In is in accordance with the UX" );
            Log.softAssertThat( assignmentDetailsPage.positionOfLegendImageZoomIn(), "Positioning of Legend Image on Zoom In is as expected", "Positioning of Legend Image on Zoom In is not as expected" );

            // TC 26
            // Verify if text "Calendar Days" is center aligned with x- axis.
            Log.softAssertThat( assignmentDetailsPage.isCalenderTextCenterAligned(), "Text \"Calendar Days\" is center aligned with x- axis.", "Text \"Calendar Days\" is not center aligned with x- axis." );

            // TC 27
            SMUtils.logDescriptionTC( "SMK-13959 Verify vertical alignment between \"Progress\" ,\"View Graph\" and \"course level\" is proper." );
            // Verify vertical alignment between "Progress" ,"View Graph" and "course level"
            // is proper.
            Log.softAssertThat( assignmentDetailsPage.isAlignmentOfProgressViewGraphCourseLevelProper( browser ), "Vertical alignment between Progress ,View Graph and course level is as expected.",
                    "Vertical alignment between Progress ,View Graph and course level is not as expected." );

            // TC 30
            SMUtils.logDescriptionTC( "SMK-13962 Verify vertical alignment between \"Close button\" and \"Print\" is as per UX." );
            // Verify vertical alignment between "Close button" and "Print" is as per UX.
            Log.softAssertThat( assignmentDetailsPage.isCloseButtonAndPrintVerticallyAligned(), "Vertical alignment between close button and print is as expected.", "Vertical alignment between close button and print is not as expected." );

            // TC 32
            SMUtils.logDescriptionTC( "SMK-13964 Verify the space between \"Course level\" and Y-axis is proper as per UX." );
            // Verify the space between "Course level" and Y-axis is proper as per UX.
            Log.softAssertThat( assignmentDetailsPage.isSpacingBetCourseLevelAndYAxisProper(), "Spacing between course level and y-axis is proper.", "Spacing between course level and y-axis is not proper." );

            // TC 36
            SMUtils.logDescriptionTC( "SMK-13968 Verify spacing between \"show target\" and \"toggle button\" is as per UX." );
            // Verify spacing between "show target" and "toggle button" is as per UX.
            Log.softAssertThat( assignmentDetailsPage.isSpacingBetShowTargetAndToggleBtnProper(), "Spacing between \"show target\" and \"toggle button\" is as per UX.", "Spacing between \"show target\" and \"toggle button\" is not as per UX" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }
    public void executeSimulator( String studentUsername, String assignmentName, String assignmentType ) throws Exception {
        WebDriver studentDriver = WebDriverFactory.get( browser );
        LoginPage smStudentLoginPage = new LoginPage( studentDriver, smUrl ).get();
        StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
        try {
            if ( assignmentType.equals( Constants.MATH ) ) {
                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
                    Log.message( "Math Course Execution" );
                    try {
                        studentDashboardPage.executeMathCourse( username, assignmentName, "95", "2", "30" );
                    } catch ( IOException e ) {
                        Log.message( "Error occurred while running the simulator for Math" );
                    }

                } );

            } else {
                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
                    Log.message( "Reading Course Execution" );
                    try {
                        studentDashboardPage.executeReadingCourse( username, assignmentName, "100", "2", "15" );
                    } catch ( IOException e ) {
                        Log.message( "Error occurred while running the simulator Reading" );
                    }

                } );

            }
        } catch ( Exception e ) {

            Log.message( "Error occurred while running the simulator" );
        }
        studentDriver.quit();
    }

}