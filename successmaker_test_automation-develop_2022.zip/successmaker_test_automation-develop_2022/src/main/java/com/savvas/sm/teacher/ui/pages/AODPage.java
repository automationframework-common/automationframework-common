package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class AODPage extends LoadableComponent<AODPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    private WebDriver driver;
    boolean isPageLoaded;
    ReportComponent reportComponents;
    
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    


    // ********* SuccessMaker CPR Page Elements ***************

    @IFindBy (how = How.CSS, using = "section.page-title div h1", AI = false )
    public WebElement lblAODHeader;

    /**
     * get the report header
     *
     * @return
     */
    public String getReportPageHeader() {
        return lblAODHeader.getText();
    }

    public AODPage() {}
    /**
     * Constructor to load driver and components
     *
     * @param driver
     */
    public AODPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
        PageFactory.initElements(finder, this);
        elementLayer = new ElementLayer(driver);
    }

    /**
     * Verify the page load
     */
    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, lblAODHeader );
    }

    /**
     * Verifying the page is loaded.
     */
    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( SMUtils.waitForElement( driver, lblAODHeader ) ) {
            Log.message( "SM Areas of Difficulty report page loaded successfully." );
        } else {
            Log.fail( "SM Areas of Difficulty report page did not load." );
        }

    }

}
