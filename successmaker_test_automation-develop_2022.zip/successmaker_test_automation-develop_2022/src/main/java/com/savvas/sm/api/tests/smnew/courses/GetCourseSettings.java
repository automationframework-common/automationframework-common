package com.savvas.sm.api.tests.smnew.courses;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicReference;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class GetCourseSettings extends CourseAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String flexSchoolTeacherDetails = null;
    private String mathSchoolTeacherDetails = null;
    private String readingSchoolTeacherDetails = null;
    private String focusReadingSchoolTeacherDetails = null;
    private String focusMathSchoolTeacherDetails = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String token = null;
    String customCourseId = null;
    //Variable declaration
    String userName = null;
    HashMap<String,String> mathGradeStandardDetails = new HashMap<String,String>();
    HashMap<String,String> readingGradeStandardDetails = new HashMap<String,String>();
    HashMap<String,String> mathGradeSkillDetails = new HashMap<String,String>();
    HashMap<String,String> readingGradeSkillDetails = new HashMap<String,String>();
    public String isItMt = "";


    @BeforeClass(alwaysRun=true)
    public void BeforeTest() throws IOException {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        isItMt = configProperty.getProperty( "isMTExecution" );
        
        //To get Random Skill and Standard ID's for Math and Reading Courses
    	mathGradeStandardDetails = SqlHelperCourses.getGradeStandardID( Constants.MATH, isItMt.equalsIgnoreCase( "true" ));
    	readingGradeStandardDetails = SqlHelperCourses.getGradeStandardID( Constants.READING, isItMt.equalsIgnoreCase( "true" ));
    	mathGradeSkillDetails = SqlHelperCourses.getSCOIDsOfRandomSkillID(Constants.MATH);
    	while( readingGradeSkillDetails.get("LOName")==null || readingGradeSkillDetails.get("LOName").isEmpty() || readingGradeSkillDetails.get("LOName").startsWith("_") ) {
        	readingGradeSkillDetails = SqlHelperCourses.getSCOIDsOfRandomSkillID(Constants.READING); 
        	}
    }

    @Test ( priority = 1, dataProvider = "positiveScenarioForGetCourseSettings", groups = { "SMK-51173/SMK-52341", "Course", "CourseSettings", "P1", "API", "smoke_test_case" } )
    public void getCourseSettingsPositiveScenarios( String description, String scenario, String scenario2, String courseID, String gradeID, String standardFrameworkID, String parentNode, String childNode, String scenario1, String statusCode )
            throws Exception {
        //Test case description
        Log.testCaseInfo( description );
        
        

        switch ( scenario ) {
            case "TC001_Default Math Course":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get Course setting
                HashMap<String, String> apiResponseTc001 = getCoursesSettings( flexSchool, Constants.DEFAULT_MATH_ID );
                Log.message( "Returned API Response - " + apiResponseTc001.get( Constants.REPORT_BODY ) );

                JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj( apiResponseTc001.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

                //Verifying settings are returned in the response body or not
                Log.softAssertThat( getSettingsResp.has( CourseAPIConstants.SESSION_LENGTH ), "SESSION_LENGTH is present in the body", "SESSION_LENGTH is not present in the body" );
                Log.softAssertThat( getSettingsResp.has( CourseAPIConstants.IDLE_TIME ), "IDLE_TIME is present in the body", "IDLE_TIME is not present in the body" );

                //Assertion 
                Log.softAssertThat( apiResponseTc001.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponseTc001.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponseTc001.get( Constants.STATUS_CODE ) );
                break;

            case "TC002_Default Reading course":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get Course setting
                HashMap<String, String> apiResponseTc002 = getCoursesSettings( flexSchool, Constants.DEFAULT_READING_ID );
                Log.message( "Returned API Response - " + apiResponseTc002.get( Constants.REPORT_BODY ) );

                JSONObject getSettingsResp1 = SMUtils.convertResponseAsJsonObj( apiResponseTc002.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

                //Verifying settings are returned in the response body or not
                Log.softAssertThat( getSettingsResp1.has( CourseAPIConstants.SESSION_LENGTH ), "SESSION_LENGTH is present in the body", "SESSION_LENGTH is not present in the body" );
                Log.softAssertThat( getSettingsResp1.has( CourseAPIConstants.IDLE_TIME ), "IDLE_TIME is present in the body", "IDLE_TIME is not present in the body" );

                //Assertion
                Log.softAssertThat( apiResponseTc002.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponseTc002.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponseTc002.get( Constants.STATUS_CODE ) );

                break;

            case "TC011_Focus Math Course":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get Course setting
                HashMap<String, String> apiResponseTc011 = getCoursesSettings( flexSchool, Constants.FOCUS_MATH_ID );
                Log.message( "Returned API Response - " + apiResponseTc011.get( Constants.REPORT_BODY ) );

                JSONObject getSettingsResp2 = SMUtils.convertResponseAsJsonObj( apiResponseTc011.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

                //Verifying settings are returned in the response body or not
                Log.softAssertThat( getSettingsResp2.has( CourseAPIConstants.SESSION_LENGTH ), "SESSION_LENGTH is present in the body", "SESSION_LENGTH is not present in the body" );
                Log.softAssertThat( getSettingsResp2.has( CourseAPIConstants.IDLE_TIME ), "IDLE_TIME is present in the body", "IDLE_TIME is not present in the body" );

                //Assertion
                Log.softAssertThat( apiResponseTc011.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponseTc011.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponseTc011.get( Constants.STATUS_CODE ) );
                break;

            case "TC012_Focus Reading Course":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get Course setting
                HashMap<String, String> apiResponseTc012 = getCoursesSettings( flexSchool, Constants.FOCUS_READING_ID );
                Log.message( "Returned API Response - " + apiResponseTc012.get( Constants.REPORT_BODY ) );

                //Assertion
                Log.softAssertThat( apiResponseTc012.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponseTc012.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponseTc012.get( Constants.STATUS_CODE ) );
                break;

            case "Custom Math and Reading":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                HashMap<String, String> courseDetails = new HashMap<>();
                HashMap<String, String> headers = new HashMap<>();
                HashMap<String, String> apiResponse = new HashMap<>();

                //Create Custom course
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( flexSchool ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );

                courseDetails.put( Constants.GRADE_VALUE, gradeID );
                courseDetails.put( Constants.STANDARD_FRAMEWORK_VALUE, standardFrameworkID );
                courseDetails.put( CourseAPIConstants.PARENT_NODE, parentNode );
                courseDetails.put( CourseAPIConstants.CHILD_NODE, childNode );

                courseDetails.put( CourseAPIConstants.COURSE_ID, courseID );
                courseDetails.put( Constants.COURSE_NAME, "Skills" + System.nanoTime() );

                //Create custom course
                switch ( scenario2 ) {
                    case "customByStandards":
                        apiResponse = createCourseByStandard( smUrl, headers, courseDetails, scenario1 );
                        Log.message( "response from POST Call - " + apiResponse );

                        customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                        break;
                    case "customBySkill":
                        apiResponse = createCourseBySkill( smUrl, headers, courseDetails, scenario1 );
                        Log.message( "response from POST Call - " + apiResponse );

                        customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                        break;
                    case "customBySettings":
                        apiResponse = createCourseBySettings( smUrl, headers, courseDetails, scenario1 );
                        Log.message( "response from POST Call - " + apiResponse );

                        customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                        break;

                }

                //Get Course setting
                HashMap<String, String> apiResponseTc013 = getCoursesSettings( flexSchool, customCourseId );
                Log.message( "Returned API Response - " + apiResponseTc013.get( Constants.REPORT_BODY ) );

                JSONObject getSettingsResp3 = SMUtils.convertResponseAsJsonObj( apiResponseTc013.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

                //Verifying settings are returned in the response body or not
                Log.softAssertThat( getSettingsResp3.has( CourseAPIConstants.SESSION_LENGTH ), "SESSION_LENGTH is present in the body", "SESSION_LENGTH is not present in the body" );
                Log.softAssertThat( getSettingsResp3.has( CourseAPIConstants.IDLE_TIME ), "IDLE_TIME is present in the body", "IDLE_TIME is not present in the body" );

                //Assertion
                Log.softAssertThat( apiResponseTc013.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponseTc013.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponseTc013.get( Constants.STATUS_CODE ) );
                break;

        }
        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    @Test ( priority = 1, dataProvider = "negativeScenarioForGetCourseSettings", groups = { "SMK-52341", "Course", "CourseSettings", "P1", "API" } )
    public void getCourseSettingsNegativeScenarios( String description, String scenario, String statusCode ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );

        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> courseSettings = new HashMap<>();
        String exception = null;
        String message = null;
        boolean status = false;

        //Creating school based one the licenses
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        //Get Course setting
        courseSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        courseSettings.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        courseSettings.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );

        switch ( scenario ) {
            case "TC003_Verify the 401 code for invalid authentication":

                //Get Course setting
                courseSettings.put( RBSDataSetupConstants.BEARER_TOKEN, "12134556677" );
                apiResponse = getCoursesSettings( smUrl, courseSettings, "false", Constants.DEFAULT_MATH_ID );

                Log.message( "Returned API Response - " + apiResponse.get( Constants.REPORT_BODY ) );

                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;

                break;

            case "TC004_Verify the 403 code for invalid auth":

                //Get Course setting
                courseSettings.put( CourseAPIConstants.ORG_ID, "AssignmentAPIConstants.ORG_ID" );
                apiResponse = getCoursesSettings( smUrl, courseSettings, "false", Constants.DEFAULT_MATH_ID );
                Log.message( "Returned API Response - " + apiResponse.get( Constants.REPORT_BODY ) );

                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;

                break;

            case "TC005_Verify the 500 code for invalid path parameter":

                //Get Course setting
                courseSettings.put( CourseAPIConstants.ORG_ID, "" );
                apiResponse = getCoursesSettings( smUrl, courseSettings, "false", Constants.DEFAULT_MATH_ID );
                Log.message( "Returned API Response - " + apiResponse.get( Constants.REPORT_BODY ) );

                //Assertion
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

            case "TC006_Data Not Found for Math":

                //Get Course setting
                apiResponse = getCoursesSettings( smUrl, courseSettings, "false", "00" );
                Log.message( "Returned API Response - " + apiResponse.get( Constants.REPORT_BODY ) );

                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.NO_COURSE_ID_MESSAGE;
                status = true;

                break;

            case "TC007_Data Not Found for Reading":

                //Get Course setting
                apiResponse = getCoursesSettings( smUrl, courseSettings, "false", "10109765" );
                Log.message( "Returned API Response - " + apiResponse.get( Constants.REPORT_BODY ) );

                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.NO_COURSE_ID_MESSAGE;
                status = true;

                break;

            case "TC008_Verify the 400 code when invalid value is passed for Course ID":

                //Get Course setting
                apiResponse = getCoursesSettings( smUrl, courseSettings, "false", "@" );
                Log.message( "Returned API Response - " + apiResponse.get( Constants.REPORT_BODY ) );

                exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
                message = "Failed to convert value of type 'java.lang.String'";
                status = true;

                break;

            case "TC009_invalid course Id as ss":

                //Get Course setting
                apiResponse = getCoursesSettings( smUrl, courseSettings, "false", "ss" );
                Log.message( "Returned API Response - " + apiResponse.get( Constants.REPORT_BODY ) );

                exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
                message = "Failed to convert value of type 'java.lang.String'";
                status = true;

                break;
            case "TC010_course id as null":

                //Get Course setting
                apiResponse = getCoursesSettings( smUrl, courseSettings, "false", "" );
                Log.message( "Returned API Response - " + apiResponse.get( Constants.REPORT_BODY ) );

                exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
                message = "Failed to convert value of type 'java.lang.String'";
                status = true;

                break;

        }
        switch ( scenario ) {

            case "TC005_Verify the 500 code for invalid path parameter":
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;
            case "TC010_course id as null":
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

            default:

                //Assertion
                Log.softAssertThat( verifyException( apiResponse.get( "body" ), exception, status, message ), "Verified message is as expected", "Verified message but it is not as expected" );

                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;
        }
        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     * @throws IOException 
     */
    @DataProvider ( name = "positiveScenarioForGetCourseSettings" )
    public Object[][] getCourseListAtDashboardLevelPositiveScenario() {
        Object[][] inputData = {
                { "TC001_Validate the status code as 200 for valid data To Get Course setting API for math, TC015_Validate the response body returned session length, ldle time and all the mandatory fields for course setting API for math.",
                        "TC001_Default Math Course", "", "", "", "", "", "", "", "200" },
                { "TC002_Validate the status code as 200 for valid data To Get Course setting API for Reading, TC016_Validate the response body returned session length, ldle time and all the mandatory fields for course setting API for reading.",
                        "TC002_Default Reading course", "", "", "", "", "", "", "", "200" },
                { "TC011_Validate the status code as 200 for valid data To Get Course setting API for Focus math.", "TC011_Focus Math Course", "", "", "", "", "", "", "", "200" },
                { "TC012_Validate the status code as 200 for valid data To Get Course setting API for Focus reading.", "TC012_Focus Reading Course", "", "", "", "", "", "", "", "200" },
                { "TC013_Validate the status code as 200 for Custom math, TC019_Validate the status response body for Course of Custom by Settings for Math", "Custom Math and Reading", "customBySettings", "1", "", "", "", "", "DEFAULTMATH", "200" },
                { "TC014_Validate the status code as 200 for Custom reading, TC022_Validate the status response body for Course of Custom by Settings for Reading", "Custom Math and Reading", "customBySettings", "2", "", "", "", "", "DEFAULTREADING",
                        "200" },
                { "TC018_Validate the status response body for Course of Custom by Standard for Math", "Custom Math and Reading", "customByStandards", "1", mathGradeStandardDetails.get("GradeID"), mathGradeStandardDetails.get("StandardID"), mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID"), "DEFAULTMATH", "200" },
                { "TC017_Validate the status response body for Course of Custom by Skill for Math", "Custom Math and Reading", "customBySkill", "1", mathGradeSkillDetails.get("GradeID"), "", mathGradeSkillDetails.get("ParentNode"), mathGradeSkillDetails.get("LOName"), "DEFAULTMATH", "200" },
                { "TC020_Validate the status response body for Course of Custom by Skill for Reading", "Custom Math and Reading", "customBySkill", "2", readingGradeSkillDetails.get("GradeID"), "", readingGradeSkillDetails.get("ParentNode"), readingGradeSkillDetails.get("LOName"), "DEFAULTREADING", "200" },
                { "TC021_Validate the status response body for Course of Custom by Standard for Reading", "Custom Math and Reading", "customByStandards", "2", readingGradeStandardDetails.get("GradeID"), readingGradeStandardDetails.get("StandardID"), readingGradeStandardDetails.get("bankID"), readingGradeStandardDetails.get("scoID"), "DEFAULTREADING", "200" },

        };
        return inputData;
    }

    /**
     * Data provider for negative scenarios
     * 
     * @return
     */

    @DataProvider ( name = "negativeScenarioForGetCourseSettings" )
    public Object[][] getCourseListAtDashboardLevelNegativeScenario() {
        Object[][] inputData = { { "TC003_Validate the status code as 401 for invalid authorization To Get Course setting API for math.", "TC003_Verify the 401 code for invalid authentication", "401" },
                { "TC004_Verify the status code is 403 for invalid auth for course setting", "TC004_Verify the 403 code for invalid auth", "403" },
                { "TC005_Validate the status code as 500 for invalid url To Get Course setting API for math and reading", "TC005_Verify the 500 code for invalid path parameter", "500" },
                { "TC006_Validate the status code as 200 for  Get Course setting API with non existing course id for math.", "TC006_Data Not Found for Math", "200" },
                { "TC007_Validate the status code as 200 for  Get Course setting API with non existing course id for Readong.", "TC007_Data Not Found for Reading", "200" },
                { "TC008_Validate the status code as 400 by applying the Junk Values as course Id. ", "TC008_Verify the 400 code when invalid value is passed for Course ID", "400" },
                { "TC009_Validate the status code as 400 by appliying the invalid course Id. ", "TC009_invalid course Id as ss", "400" }, 
                { "TC010_Validate the status code as 500 by appliying NULL course Id. ", "TC010_course id as null", "500" } };
        return inputData;
    }

    //Token creation
    public void tokenCreation( String school ) {
        try {
            switch ( school ) {
                case CommonAPIConstants.FLEX_LICENSE_SCHOOL:
                    teacherDetails = flexSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.MATH_LICENSE_SCHOOL:
                    teacherDetails = mathSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.READING_LICENSE_SCHOOL:
                    teacherDetails = readingSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.FOCUS_MATH_LICENSE_SCHOOL:
                    teacherDetails = focusMathSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.FOCUS_READING_LICENSE_SCHOOL:
                    teacherDetails = focusReadingSchoolTeacherDetails;
                    break;
            }
            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
            userName = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    //Get courses Settings
    public HashMap<String, String> getCoursesSettings( String school, String courseId ) {
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> courseSettings = new HashMap<>();
        try {
            courseSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            courseSettings.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            courseSettings.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            apiResponse = getCoursesSettings( smUrl, courseSettings, "false", courseId );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return apiResponse;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.message( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.message( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.message( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.message( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.message( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.message( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    /**
     * Get response for the Create Course By Settings API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySettings( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
    	HashMap<String, String> response;
    	try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySettingsReading" ) ) );

            } else if ( scenario.contains( "DEFAULTMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySettingsMath" ) ) );
            } else if ( scenario.contains( "FOCUSMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusMath" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            response = RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );
            Log.message( "Returned API Response - " + response.get( Constants.REPORT_BODY ) );
            return response;
        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

    /**
     * Get response for the Create Course By Standard API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseByStandard( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardReading" ) ) );

            } else if ( scenario.contains( "DEFAULTMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardMath" ) ) );
            } else if ( scenario.contains( "FOCUSMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusMath" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.STANDARDFRAMEWORK_ID, courseDetails.get( Constants.STANDARD_FRAMEWORK_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            HashMap<String, String> response = RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );
            Log.message( "Returned API Response - " + response.get( Constants.REPORT_BODY ) );
            return response;

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

    /**
     * Get response for the Create Course By Skill API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySkill( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySkillsReading" ) ) );

            } else if ( scenario.contains( "DEFAULTMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySkillsMath" ) ) );
            } else if ( scenario.contains( "FOCUSMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusMath" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

}
