package com.savvas.sm.teacher.ui.pages;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.TestDataConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class StudentDashboardPage extends LoadableComponent<StudentDashboardPage> {

	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

	private WebDriver driver;
	boolean isPageLoaded;
	public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();
	public TopNavBar topNavBar;
	private String delayTime = "2";

	@FindBy ( css = "div.assignment-tile div.course-name")
	List<WebElement> assignmentLists;

	@IFindBy(how = How.CSS, using= "#run", AI = false)
	public WebElement mathRunButton;

	@IFindBy(how = How.CSS, using= "#buttonRun", AI = false)
	public WebElement readingRunButton;

	// @IFindBy(how = How.CSS, using= ".sm-logoutbtn", AI = false)
	@IFindBy(how = How.CSS, using= "#logoutContainer > button", AI = false)
	public WebElement logoutButton;

	@IFindBy(how = How.CSS, using= "#closeSimulatorModal", AI = false)
	public WebElement closeMathSimulatorPopup;

	@IFindBy(how = How.CSS, using= "#closeReadingSimulatorModal", AI = false)
	public WebElement closeReadingSimulatorPopup;

	//*
	//Math SimulatorPopup
	//*

	@IFindBy(how = How.CSS, using= "#targetPercentage", AI = false)
	public WebElement mathTargetPercentage;

	@IFindBy(how = How.CSS, using= "#noOfSession", AI = false)
	public WebElement mathNoOfSession;

	@IFindBy(how = How.CSS, using= "#noOfLOsPerSession", AI = false)
	public WebElement mathNoOfLOsPerSession;

	@IFindBy(how = How.CSS, using= "#delayTime", AI = false)
	public WebElement mathDelayTime;

	//*
	//Reading Simulator Popup
	//*

	@IFindBy(how = How.CSS, using= "#inputTPerc", AI = false)
	public WebElement readingTargetPercentage;

	@IFindBy(how = How.CSS, using= "#inputSessionCount", AI = false)
	public WebElement readingNoOfSession;

	@IFindBy(how = How.CSS, using= "#inputScoCount", AI = false)
	public WebElement readingNoOfSCOsPerSession;

	@IFindBy(how = How.CSS, using= "#delaySecond", AI = false)
	public WebElement readingDelayTime;

	@IFindBy(how = How.CSS, using= "#message", AI = false)
	public WebElement readingModalMessage;

	@IFindBy(how = How.CSS, using= "#error-footer .btn-primary", AI = false)
	public WebElement readingPopClose;

	@FindBy ( css = "div.course-name")
	List<WebElement> assignmentsList;

	@IFindBy (how = How.ID, using = "agree", AI = false)
	public WebElement agreeCheckbox;

	@IFindBy (how = How.CLASS_NAME, using = "btn-submit", AI = false)
	public WebElement nextBtn;

	@IFindBy (how = How.ID, using = "buttonCancel", AI = false)
	public WebElement ReadingCancelButton;

	public StudentDashboardPage () {}
	/**
	 *
	 * @param driver
	 */
	public StudentDashboardPage( WebDriver driver ) {
		this.driver = driver;
		// Have Topbar here and init
		ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
		PageFactory.initElements(finder, this);
		elementLayer = new ElementLayer(driver);
		topNavBar = new TopNavBar( driver );
	}

	@Override
	protected void load() {
		isPageLoaded = true;
		SMUtils.waitForElement( driver, logoutButton );
	}

	@Override
	protected void isLoaded() throws Error {
		if ( !isPageLoaded ) {
			Assert.fail();
		}

		try {
			SMUtils.waitForSpinnertoDisapper( driver, 60 );
		} catch ( InterruptedException e ) {
			Log.message( "Issue in Spinner Loading" );
		}
		if ( SMUtils.waitForElement( driver, logoutButton ) ) {


			Log.message( "SM Student loaded successfully." );
		} else {
			Log.fail( "SM Students page did not load." );
		}
	}
	
	/**
	 * To execute math course on simulator
	 *
	 * @param teacherID
	 * @param assignmentName
	 * @param percentage
	 * @param sessions
	 * @param loCount
	 * @throws IOException
	 * @throws InterruptedException 
	 */
	public void executeMathCourse( String teacherID, String assignmentName, String percentage, String sessions, String loCount ) throws IOException {
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
        } catch ( InterruptedException e1 ) {
            e1.printStackTrace();
        }
	    selectAssignmentByName( assignmentName );
		SMUtils.nap( 2 );
		SMUtils.waitForElement( driver, mathRunButton, 10 );
        SMUtils.fluentWaitForElement( driver, mathRunButton );
		SMUtils.enterValue( mathTargetPercentage, percentage );
		SMUtils.enterValue( mathNoOfSession, sessions );
		SMUtils.enterValue( mathNoOfLOsPerSession, loCount );
		SMUtils.enterValue( mathDelayTime, delayTime );
		SMUtils.clickJS( driver, mathRunButton );// Mac Safari click
		// SMUtils.click( driver, mathRunButton );
		Log.message( "Clicked on Run button" );

		try {
			//To wait till the course execution to be completed via simulator
			WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds(TestDataConstants.SIMULATOR_WAIT) );
			wait.until( ExpectedConditions.alertIsPresent() );
			String simulatorMessage = driver.switchTo().alert().getText().trim();
			driver.switchTo().alert().accept();
			if ( !simulatorMessage.contains( "Simulation Run Complete" ) ) {
				Log.message( Constants.HTML_BOLD_TAG_OPEN + "Some issue occured!!!" + Constants.HTML_BOLD_TAG_CLOSE, driver );
			}
		} catch ( Exception e ) {
			Log.message( "Alert not displayed" );

		}
		Log.message( "Simulation is completed!" );
		SMUtils.clickJS( driver, closeMathSimulatorPopup );
		saveTeacherData( teacherID, assignmentName, loCount, percentage );
	}

	/**
	 * To execute reading course on simulator
	 *
	 * @param teacherID
	 * @param assignmentName
	 * @param percentage
	 * @param sessions
	 * @param loCount
	 * @throws IOException
	 */
	public void executeReadingCourse( String teacherID, String assignmentName, String percentage, String sessions, String loCount ) throws IOException {
		int i = 0;
		while ( i < 4 ) {
			try {
				selectAssignmentByName( assignmentName );
				SMUtils.waitForElement( driver, readingRunButton, 5 );
				SMUtils.enterValue( readingTargetPercentage, percentage );
				SMUtils.enterValue( readingNoOfSession, sessions );
				SMUtils.enterValue( readingNoOfSCOsPerSession, loCount );
				SMUtils.enterValue( readingDelayTime, delayTime );
				SMUtils.clickJS( driver, readingRunButton );// Mac Safari click
				//  readingRunButton.click();
				Log.message( "Clicked on Run button" );
				break;
			} catch ( Exception e ) {
				PageFactory.initElements( driver, this );
				i++;
			}
		}
		try {
			//To wait till the course execution to be completed via simulator
			WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds(TestDataConstants.SIMULATOR_WAIT) );
			wait.until( ExpectedConditions.visibilityOfElementLocated( By.id( "message" ) ) );
			if ( !readingModalMessage.getText().trim().contains( "Simulation Run Complete" ) ) {
				Log.message( Constants.HTML_BOLD_TAG_OPEN + "Some issue occured!!!" + Constants.HTML_BOLD_TAG_CLOSE, driver );
			}
			SMUtils.clickJS( driver, readingPopClose );
		} catch ( Exception e ) {
			Log.message( Constants.HTML_BOLD_TAG_OPEN + "Alert not displayed" + Constants.HTML_BOLD_TAG_CLOSE, driver );
		}
		Log.message( "Simulation is completed!" );
		SMUtils.clickJS( driver, closeReadingSimulatorPopup );
		saveTeacherData( teacherID, assignmentName, loCount, percentage );
	}

	/**
	 * To execute reading course on simulator and cancel the execution when in progress
	 *
	 * @param teacherID
	 * @param assignmentName
	 * @param percentage
	 * @param sessions
	 * @param loCount
	 * @throws IOException
	 */
	public void executeReadingCourseInProgress( String teacherID, String assignmentName, String percentage, String sessions, String loCount ) throws IOException {
		int i = 0;
		while ( i < 4 ) {
			try {
				selectAssignmentByName( assignmentName );
				SMUtils.waitForElement( driver, readingRunButton, 5 );
				SMUtils.enterValue( readingTargetPercentage, percentage );
				SMUtils.enterValue( readingNoOfSession, sessions );
				SMUtils.enterValue( readingNoOfSCOsPerSession, loCount );
				SMUtils.enterValue( readingDelayTime, delayTime );
				SMUtils.clickJS( driver, readingRunButton );// Mac Safari click
				Log.message( "Clicked on Run button" );
				SMUtils.nap(5);
				SMUtils.clickJS( driver, ReadingCancelButton );
				Log.message("Clicked on cancel button");
				saveTeacherData( teacherID, assignmentName, loCount, percentage );
				break;
			} catch ( Exception e ) {
				PageFactory.initElements( driver, this );
				i++;
			}
		}
	}

	/**
	 * To select assignment by its name
	 *
	 * @param assignmentName
	 */
    public void selectAssignmentByName( String assignmentName ) {
        SMUtils.nap( 3 );
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( TestDataConstants.SIMULATOR_WAIT ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( assignmentLists ) );
        SMUtils.clickJS( driver, driver.findElement( By.cssSelector( "div[title='" + assignmentName + "']" ) ) );
    }

	/*
	 * To logout from student login
	 */
	public void logout() {
		SMUtils.waitForElement( driver, logoutButton );
		//logoutButton.click();
		SMUtils.clickJS( driver, logoutButton );
		Log.message( "Logout button clicked" );
	}

	/**
	 *
	 * @param teacherID
	 * @param assignmentName
	 * @param percentage
	 * @throws IOException
	 */
	private void saveTeacherData( String teacherID, String assignmentName, String loCount, String percentage ) throws IOException {
		try {
			String basePath = new File( "." ).getCanonicalPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "testdata" + File.separator;
			String usageFilePath = basePath + "usageData.csv";
			FileWriter csvWriter = new FileWriter( usageFilePath );
			csvWriter.append( "TeacherID" + "," + "assignmentName" + "," + "," + "loCount" + "percentage" + "\n" );
			csvWriter.append( teacherID + "," + assignmentName + "," + "," + loCount + percentage + "\n" );
			csvWriter.flush();
			csvWriter.close();
		} catch ( Exception e ) {
			Log.message( "Data not stored to CSV properly: " + e );
		}
	}

	/**
	 * To get Assignment names
	 *
	 * @return
	 */
	public boolean isAssignmentExists( String AssignmentName ) {
		boolean assignmentexist = false;
		try {
			WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds(TestDataConstants.SIMULATOR_WAIT) );
			wait.until( ExpectedConditions.visibilityOfAllElements( assignmentsList ) );
			for ( WebElement element : assignmentsList ) {
				String assignmentName = element.getText().trim();
				if ( assignmentName.equals( AssignmentName ) ) {
					assignmentexist = true;
					break;
				}
			}
		} catch ( Exception e ) {
			assignmentexist = false;
			Log.message( "No assignments present for students!" );
		}
		return assignmentexist;
	}

	public void agreeAndSubmit() throws InterruptedException {
		SMUtils.waitForElement( driver, agreeCheckbox );
		if ( SMUtils.isElementPresent( agreeCheckbox ) ) {
			SMUtils.clickJS( driver, agreeCheckbox );
			SMUtils.click( driver, nextBtn );
		}
		SMUtils.waitForSpinnertoDisapper( driver );
	}
	/**
	 * To execute reading course on simulator
	 *
	 * @param teacherID
	 * @param assignmentName
	 * @param percentage
	 * @param sessions
	 * @param loCount
	 * @throws IOException
	 */
	public void lunchReadingCourse( String teacherID, String assignmentName, String percentage, String sessions, String loCount ) throws IOException {

		selectAssignmentByName( assignmentName );
		SMUtils.waitForElement( driver, readingRunButton, 5 );
		SMUtils.enterValue( readingTargetPercentage, percentage );
		SMUtils.enterValue( readingNoOfSession, sessions );
		SMUtils.enterValue( readingNoOfSCOsPerSession, loCount );
		SMUtils.clickJS( driver, readingRunButton );
		Log.message( "Clicked on Run button" );

	}


	/**
	 * To execute reading course on simulator
	 *
	 * @param teacherID
	 * @param assignmentName
	 * @param percentage
	 * @param sessions
	 * @param loCount
	 * @throws IOException
	 */
	public void launchReadingCourse( String assignmentName, String percentage, String sessions, String loCount ) throws IOException {

		selectAssignmentByName( assignmentName );
		SMUtils.waitForElement( driver, readingRunButton, 5 );
		SMUtils.enterValue( readingTargetPercentage, percentage );
		SMUtils.enterValue( readingNoOfSession, sessions );
		SMUtils.enterValue( readingNoOfSCOsPerSession, loCount );
		SMUtils.clickJS( driver, readingRunButton );
		Log.message( "Clicked on Run button" );

	}
}
