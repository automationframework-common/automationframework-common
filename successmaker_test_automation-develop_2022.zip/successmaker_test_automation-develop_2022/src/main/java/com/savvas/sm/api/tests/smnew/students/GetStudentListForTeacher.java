package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.mifmif.common.regex.util.Iterator;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.FileNameConstatnts;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

import io.restassured.response.Response;

/**
 * To get the Student Details from the Given Teacher Id
 * 
 * @author suriya.kumar
 *
 */
public class GetStudentListForTeacher extends UserAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    String sessionCookie;

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String classId = null;
    String className = null;
    RBSDataSetup data = new RBSDataSetup();
    // Teacher variable used for this class
    private String orgUsed = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgUsed2 = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String teacherUsed;
    private String teacherUsed2;
    private String readingTeacherDetail;
    private String orgId;
    private String teacherId;
    private String username;

    // other school constants
    private String readingSchoolId;
    private String readingSchoolTeacherId;
    private String multipleSchoolTeacherID;
    private String multipleSchoolTeacherName;
    private String readingSchoolTeacherUsername;
    GroupAPI groupapi = new GroupAPI();
    // Second Teacher
    private String secondTeacherId;
    private String secondTeacherUsername;
    RBSUtils rbs = new RBSUtils();
    HashMap<String, String> studentInfo = new HashMap<>();

    @BeforeClass( alwaysRun = true )
    public void BeforeClass() throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        // Teacher used Details
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        teacherUsed = RBSDataSetup.getMyTeacher( orgUsed );
        teacherUsed2 = RBSDataSetup.getMyTeacher( orgUsed );
        teacherId = SMUtils.getKeyValueFromResponse( teacherUsed, Constants.USERID_HEADER );
        username = SMUtils.getKeyValueFromResponse( teacherUsed, Constants.USER_NAME );

        // Second Teacher for Data Setup purposes
        secondTeacherId = SMUtils.getKeyValueFromResponse( teacherUsed2, Constants.USERID_HEADER );
        secondTeacherUsername = SMUtils.getKeyValueFromResponse( teacherUsed2, Constants.USER_NAME );

        // Other School Details
        readingSchoolId = RBSDataSetup.organizationIDs.get( orgUsed2 );
        readingTeacherDetail = RBSDataSetup.getMyTeacher( orgUsed2 );
        readingSchoolTeacherId = SMUtils.getKeyValueFromResponse( readingTeacherDetail, Constants.USERID_HEADER );
        readingSchoolTeacherUsername = SMUtils.getKeyValueFromResponse( readingTeacherDetail, Constants.USER_NAME );

        HashMap<String, String> userDetails = new HashMap<String, String>();
        List<String> schools = new ArrayList<String>();

        String multiSchoolTeacher = "MultiSchTeacher" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

        schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
        schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
        String listString = "";
        for ( String school : schools ) {
            listString += school.concat( "\",\"" );
        }
        listString = listString.substring( 0, listString.length() - 3 );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
        String createUser = rbs.createUser( userDetails );

        multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERID );
        multipleSchoolTeacherName = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERNAME );
        new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

    }

    /**
     * Data provider for negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "negativeScenarios" )
    public Object[][] negativeData() {

        Object[][] inputData = { { "DATA_NOT_FOUND_EXCEPTION", CommonAPIConstants.STATUS_CODE_OK, CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION, "Verify data not found exception for API" },
                { "STUDENT_AUTH", CommonAPIConstants.STATUS_CODE_FORBIDDAN, CommonAPIConstants.ACCESS_DENIED_EXCEPTION, "Verify the Session exception for the 403" },
                { "INVALID_AUTH", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, CommonAPIConstants.AUTHENTICATION_EXCEPTION, "Verify the API for invalid Access Token" },
                { "STUDENT_DELETED", CommonAPIConstants.STATUS_CODE_OK, CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION, "Verify the API when student is Deleted" },
                { "STUDENT_REMVOED_FROM_CLASS", CommonAPIConstants.STATUS_CODE_OK, CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION, "Verify the API after one student is removed from associated teacher" }, };
        return inputData;
    }

    @Test ( priority = 2, description = "In Valid Scenarios", dataProvider = "negativeScenarios", groups = { "SMK-52001", "Students", "StudentDetailsForStudentId", "API" } )
    public void tcStudentDetailsByTeacher01( String scenario, String expCode, String expException, String description ) throws Exception {

        Log.testCaseInfo( description );
        HashMap<String, String> response = null;

        // Constants

        String studentName;
        String studentDetails;
        HashMap<String, String> userDetails;

        switch ( scenario ) {

            case "DATA_NOT_FOUND_EXCEPTION":

                String accessToken = new RBSUtils().getAccessToken( multipleSchoolTeacherName, password );
                String groupName = "Empty Group-" + System.nanoTime();
                String classId = new GroupAPI().createEmptyGroup( groupName, multipleSchoolTeacherID, orgId, accessToken );

                response = getStudentDetailsForTeacher( multipleSchoolTeacherID, orgId, accessToken );
                break;

            case "STUDENT_AUTH":

                String accessToken2 = new RBSUtils().getAccessToken( multipleSchoolTeacherName, password );
                String groupName2 = "Group_" + System.nanoTime();

                // Student Creation
                String studentName1 = "student" + System.nanoTime();
                String studentId = createStudentAndResetPassword( orgId, studentName1 );

                // Enrolling student into the class
                classId = new GroupAPI().createGroupWithCustomization( groupName2, multipleSchoolTeacherID, Arrays.asList( studentId ), orgId, accessToken2 );

                studentInfo = data.generateRequestValues( rbs.getUser( studentId ), studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, multipleSchoolTeacherID );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

                // Getting response
                response = getStudentDetailsForTeacher( studentId, orgId, new RBSUtils().getAccessToken( studentName1, password ) );

                break;

            case "INVALID_AUTH":

                accessToken = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "student" + System.nanoTime();
                studentId = createStudentAndResetPassword( orgId, studentName );

                // Enrolling student into the class
                classId = new GroupAPI().createGroupWithCustomization( groupName, teacherId, Arrays.asList( studentId ), orgId, accessToken );

                studentInfo = data.generateRequestValues( rbs.getUser( studentId ), studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, multipleSchoolTeacherID );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

                // Getting response
                response = getStudentDetailsForTeacher( teacherId, orgId, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                break;

            case "STUDENT_DELETED":

                // teacher Creation
                groupName = "Group_" + System.nanoTime();
                username = "teacher" + System.nanoTime();
                studentDetails = createUserWithCustomization( username, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

                studentName = "student" + System.nanoTime();
                studentDetails = createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

                // Enrolling student into the class
                accessToken = new RBSUtils().getAccessToken( username, password );
                classId = new GroupAPI().createGroupWithCustomization( className, teacherId, Arrays.asList( studentId ), orgId, accessToken );

                // Deleting Student
                new RBSUtils().deleteUser( Arrays.asList( studentId ) );

                // Getting response
                response = getStudentDetailsForTeacher( teacherId, orgId, accessToken );
                break;

            case "STUDENT_REMVOED_FROM_CLASS":

                // teacher Creation
                username = "teacher" + System.nanoTime();
                studentDetails = createUserWithCustomization( username, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                teacherId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

                accessToken = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                // Student Creation
                studentName = "student" + System.nanoTime();
                studentId = createStudentAndResetPassword( orgId, studentName );

                // Enrolling student into the class
                classId = new GroupAPI().createGroupWithCustomization( groupName, teacherId, Arrays.asList( studentId ), orgId, accessToken );

                studentInfo = data.generateRequestValues( rbs.getUser( studentId ), studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, teacherId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

                // removing studentFromTeacher

                groupapi.removeStudentFromGroup( smUrl, studentId, classId, teacherId, orgId, accessToken );

                boolean deleteStudentFromSection = new RBSUtils().deleteStudentFromSection( classId, teacherId, studentId );
                Log.message( "Is Student Deleted " + deleteStudentFromSection );

                // Getting response
                response = getStudentDetailsForTeacher( teacherId, orgId, accessToken );
                Log.message( "response shown " + response );

                break;

            default:
                break;
        }

        //Validating response code and exception Message

        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( expCode ), "The Status code matched", "The Status code Doesnot matched" );
        Log.assertThat( new SMAPIProcessor().getKeyValues( new JSONObject( response.get( Constants.BODY ) ), StudentDetailsForGivenTeacherConstants.EXCEPTION ).get( 0 ).equals( expException ), "The Exception message is matched",
                "The Exception message is not matched" );

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "positiveScenarios" )
    public Object[][] postiveData() {

        Object[][] inputData = { { "VALID_SCENARIO", "Verify the API response for valid data" }, { "TWO_CLASS", "Verify the API if the two class has same Associated Teacher and Student will not repeat the student details" },
                { "STUDENT_SUSPENDED", "Verify API When the Student is Suspended" }, { "STUDENT_MULTI_ORG", "Verify the API when the Student is prsent in mulit Orgazanization" },
                { "SHARED_STUDENT", "Verify the API when the Student is Shared student for the Associated Teacher" } };
        return inputData;
    }

    @Test ( priority = 2, description = "Valid 200 Scenarios", dataProvider = "positiveScenarios", groups = { "smoke_test_case", "Smoke studentListing", "StudentListing", "P1", "SMK-52001", "Students", "StudentDetailsForStudentId", "API" } )
    public void tcStudentDetailsByTeacher02( String scenario, String description ) throws Exception {
        Log.testCaseInfo( description );

        // Constants

        HashMap<String, String> userDetails;

        String classId;

        switch ( scenario ) {

            case "VALID_SCENARIO":
                HashMap<String, String> response = null;
                HashMap<String, String> studentInfo = new HashMap<>();
                Log.testCaseInfo( "Verify the API will return the 200 response code for valid response" );
                Log.testCaseInfo( "Verify the API will return the field values are correctly example firstname : Aaron, lastname : Aalonzo, middlename : string, username : aaalozo, studentId : stud1111," );
                Log.testCaseInfo( "Verify the API successfull message is displayed correctly" );
                Log.testCaseInfo( "Verify the API after one student is added associated for teacher" );
                Log.testCaseInfo( "Verify the API for Teacher from Easy Bridge will get the repsone for the basic user" );
                String accessToken = new RBSUtils().getAccessToken( username, password );
                String groupName = "Group_" + System.nanoTime();

                // Student Creation
                String studentName = "student" + System.nanoTime();
                String studentId = createStudentAndResetPassword( orgId, studentName );

                // Enrolling student into the class
                String teacherId = SMUtils.getKeyValueFromResponse( teacherUsed, Constants.USERID_HEADER );
                String classId1 = new GroupAPI().createGroupWithCustomization( groupName, teacherId, Arrays.asList( studentId ), orgId, accessToken );

                studentInfo = data.generateRequestValues( rbs.getUser( studentId ), studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, teacherId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

                // Getting response
                response = getStudentDetailsForTeacher( teacherId, orgId, accessToken );

                // Verifying all Details
                VerifyAPI( response, teacherId, orgId, accessToken );
                break;

            case "TWO_CLASS":
                HashMap<String, String> response1 = null;
                HashMap<String, String> studentInfo1 = new HashMap<>();

                String accessToken1 = new RBSUtils().getAccessToken( username, password );
                String groupName1 = "Group_" + System.nanoTime();
                String teacherId2 = SMUtils.getKeyValueFromResponse( teacherUsed, Constants.USERID_HEADER );

                // Student Creation
                String studentName1 = "student" + System.nanoTime();
                String studentId1 = createStudentAndResetPassword( orgId, studentName1 );

                studentInfo1 = data.generateRequestValues( rbs.getUser( studentId1 ), studentInfo1, UserConstants.SCHOOLID, orgId );
                studentInfo1 = SMUtils.updateRequestBodyValues( studentInfo1, UserConstants.SCHOOLID, orgId );
                studentInfo1 = SMUtils.updateRequestBodyValues( studentInfo1, UserConstants.TEACHER_ID, teacherId2 );
                studentInfo1 = SMUtils.updateRequestBodyValues( studentInfo1, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo1 );

                // Enrolling student into the classes
                String classId3 = new GroupAPI().createGroupWithCustomization( groupName1, teacherId2, Arrays.asList( studentId1 ), orgId, accessToken1 );
                String classId4 = new GroupAPI().createGroupWithCustomization( groupName1, teacherId2, Arrays.asList( studentId1 ), orgId, accessToken1 );

                // Getting response
                response1 = getStudentDetailsForTeacher( teacherId2, orgId, accessToken1 );

                // Verifying all Details
                VerifyAPI( response1, teacherId2, orgId, accessToken1 );
                break;

            case "STUDENT_SUSPENDED":
                HashMap<String, String> response2 = null;
                HashMap<String, String> studentInfo2 = new HashMap<>();
                String teacherId3 = SMUtils.getKeyValueFromResponse( teacherUsed, Constants.USERID_HEADER );

                String accessToken2 = new RBSUtils().getAccessToken( username, password );
                String groupName2 = "Group_" + System.nanoTime();

                // Student Creation
                String studentName2 = "student" + System.nanoTime();
                String studentId2 = createStudentAndResetPassword( orgId, studentName2 );

                // Enrolling student into the class
                String classId2 = new GroupAPI().createGroupWithCustomization( groupName2, teacherId3, Arrays.asList( studentId2 ), orgId, accessToken2 );

                studentInfo2 = data.generateRequestValues( rbs.getUser( studentId2 ), studentInfo2, UserConstants.SCHOOLID, orgId );
                studentInfo2 = SMUtils.updateRequestBodyValues( studentInfo2, UserConstants.SCHOOLID, orgId );
                studentInfo2 = SMUtils.updateRequestBodyValues( studentInfo2, UserConstants.TEACHER_ID, teacherId3 );
                studentInfo2 = SMUtils.updateRequestBodyValues( studentInfo2, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo2 );

                // Suspend Student
                new RBSUtils().suspendUser( Arrays.asList( studentId2 ) );

                // Getting response
                response2 = getStudentDetailsForTeacher( teacherId3, orgId, accessToken2 );

                // Verifying all Details
                VerifyAPI( response2, teacherId3, orgId, accessToken2 );
                break;

            case "STUDENT_MULTI_ORG":
                HashMap<String, String> response3 = null;
                HashMap<String, String> studentInfo3 = new HashMap<>();
                String teacherId4 = SMUtils.getKeyValueFromResponse( teacherUsed, Constants.USERID_HEADER );

                // Studnet Creation
                String studentName3 = "student" + System.nanoTime();
                String studentDetails3 = createUserWithCustomization( studentName3, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId, readingSchoolId ) );
                String studentId3 = new SMUtils().getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERID );

                // Enrolling student into the class
                String accessToken3 = new RBSUtils().getAccessToken( username, password );
                String groupName3 = "Group_" + System.nanoTime();

                String classId5 = new GroupAPI().createGroupWithCustomization( groupName3, teacherId4, Arrays.asList( studentId3 ), orgId, accessToken3 );

                studentInfo3 = data.generateRequestValues( rbs.getUser( studentId3 ), studentInfo3, UserConstants.SCHOOLID, orgId );
                studentInfo3 = SMUtils.updateRequestBodyValues( studentInfo3, UserConstants.SCHOOLID, orgId );
                studentInfo3 = SMUtils.updateRequestBodyValues( studentInfo3, UserConstants.TEACHER_ID, teacherId4 );
                studentInfo3 = SMUtils.updateRequestBodyValues( studentInfo3, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo3 );

                // Getting response
                response3 = getStudentDetailsForTeacher( teacherId4, orgId, accessToken3 );

                // Verifying all Details
                VerifyAPI( response3, teacherId4, orgId, accessToken3 );

                break;

            case "SHARED_STUDENT":
                HashMap<String, String> response4 = null;
                HashMap<String, String> studentInfo4 = new HashMap<>();
                String teacherId5 = SMUtils.getKeyValueFromResponse( teacherUsed, Constants.USERID_HEADER );
                String secondTeacherId = SMUtils.getKeyValueFromResponse( teacherUsed2, Constants.USERID_HEADER );

                // Student Creation
                String studentName4 = "student" + System.nanoTime();
                String studentId4 = createSharedStudent( studentName4, teacherId5, new RBSUtils().getAccessToken( username, password ), secondTeacherId, new RBSUtils().getAccessToken( secondTeacherUsername, password ), orgId );

                // Enrolling student into the class
                String accessToken4 = new RBSUtils().getAccessToken( username, password );
                String groupName4 = "Group_" + System.nanoTime();

                String classId6 = new GroupAPI().createGroupWithCustomization( groupName4, teacherId5, Arrays.asList( studentId4 ), orgId, accessToken4 );

                studentInfo4 = data.generateRequestValues( rbs.getUser( studentId4 ), studentInfo4, UserConstants.SCHOOLID, orgId );
                studentInfo4 = SMUtils.updateRequestBodyValues( studentInfo4, UserConstants.SCHOOLID, orgId );
                studentInfo4 = SMUtils.updateRequestBodyValues( studentInfo4, UserConstants.TEACHER_ID, teacherId5 );
                studentInfo4 = SMUtils.updateRequestBodyValues( studentInfo4, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo4 );

                // Getting response
                response4 = getStudentDetailsForTeacher( teacherId5, orgId, accessToken4 );

                // Verifying all Details
                VerifyAPI( response4, teacherId5, orgId, accessToken4 );
                break;

            default:
                break;
        }

    }

    @Test ( priority = 2, description = "Verifying all Multiple Teacher", groups = { "smoke_test_case", "Smoke studentListing", "StudentListing", "P1", "SMK-52001", "Students", "StudentDetailsForStudentId", "API" } )
    public void tcStudentDetailsByTeacher03() throws Exception {
        HashMap<String, String> studentInfo = new HashMap<>();
        // Studnet Creation
        String studentName = "student" + System.nanoTime();
        String studentDetails = createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
        String studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

        // Enrolling student into the class
        String accessToken = new RBSUtils().getAccessToken( username, password );
        String className = "class with multiple Teacher" + System.nanoTime();
        classId = new RBSUtils().createClassWithMultipleTeacher( className, Arrays.asList( teacherId, secondTeacherId ), Arrays.asList( studentId ), orgId, accessToken );

        studentInfo = data.generateRequestValues( rbs.getUser( studentId ), studentInfo, UserConstants.SCHOOLID, orgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, teacherId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );
        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

        // Getting response
        HashMap<String, String> response = getStudentDetailsForTeacher( secondTeacherId, orgId, new RBSUtils().getAccessToken( secondTeacherUsername, password ) );
        VerifyAPI( response, secondTeacherId, orgId, new RBSUtils().getAccessToken( secondTeacherUsername, password ) );
    }

    @Test ( priority = 2, description = "Verifying with all the Grades", groups = { "smoke_test_case", "Smoke studentListing", "StudentListing", "P1", "SMK-52001", "Students", "StudentDetailsForStudentId", "API" } )
    public void tcStudentDetailsByTeacher04() throws Exception {

        // Studnet Creation
        String studentName = "student" + System.nanoTime();
        String studentDetails = createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
        String studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

        // Enrolling student into the class
        String accessToken = new RBSUtils().getAccessToken( username, password );
        String className = "class" + System.nanoTime();
        classId = new GroupAPI().createGroupWithCustomization( className, teacherId, Arrays.asList( studentId ), orgId, accessToken );

        Log.testCaseInfo( "Verify the API Grade Id and Grade Name for the student is correct." );
        Log.testCaseInfo( "Veriyf the api for the For the Student of Grade Having K" );
        Log.testCaseInfo( "Veriyf the api for the For the Student of Grade Having 12" );

        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = data.generateRequestValues( rbs.getUser( studentId ), studentInfo, UserConstants.SCHOOLID, orgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, teacherId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        SMUtils.updateRequestBodyValues( studentInfo, UserConstants.GRADE, "FIRST" );

        Log.message( "Updating grade..." );

        // Getting response
        HashMap<String, String> response = getStudentDetailsForTeacher( teacherId, orgId, accessToken );
        VerifyAPI( response, teacherId, orgId, accessToken );

    }

    /*
     * /** It will verify the schema
     * 
     * @param StatusCode
     * 
     * @param response
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = new SMAPIProcessor().isSchemaValid( FileNameConstatnts.STUDENT_DETAILS_FOR_TEACHER_ID, StatusCode, response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) );
            Log.assertThat( isValid, "The schema is valid", "The schema is not valid" );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
    }

    /**
     * Verifying API
     * 
     * @param response
     * @param teacherId
     * @param orgId
     * @param accessToken
     */
    public void VerifyAPI( HashMap<String, String> response, String teacherId, String orgId, String accessToken ) {

        // Schema validation
        VerifySchema( response.get( Constants.STATUS_CODE ), response );

        Log.assertThat( response.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.STATUS_CODE_STRING ).equals( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.STATUS_CODE_200 ), "The response code Matches!",
                "The response code doesnot Matches" );
        Log.assertThat(
                new SMAPIProcessor().getKeyValues( new JSONObject( response.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ), StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.MESSAGE_STRING ).get( 0 ).equals(
                        "Operation succeeded!" ),
                "The success message matches!", "The success message doesnot matches" );

        // Getting actual values
        JSONObject body = new JSONObject( response.get( Constants.BODY ) );
        ArrayList<String> firstNames = new ArrayList<String>( new SMAPIProcessor().getKeyValues( body, RBSDataSetupConstants.FIRSTNAME ) );
        ArrayList<String> lastNames = new ArrayList<String>( new SMAPIProcessor().getKeyValues( body, RBSDataSetupConstants.LASTNAME ) );
        ArrayList<String> middleNames = new ArrayList<String>( new SMAPIProcessor().getKeyValues( body, RBSDataSetupConstants.MIDDLENAME ) );
        ArrayList<String> userNames = new ArrayList<String>( new SMAPIProcessor().getKeyValues( body, RBSDataSetupConstants.USERNAME.toLowerCase() ) );
        ArrayList<String> gradeNames = new ArrayList<String>( new SMAPIProcessor().getKeyValues( body, StudentDetailsForGivenTeacherConstants.GRADE_NAME ) );
        ArrayList<String> studentIds = new ArrayList<String>( new SMAPIProcessor().getKeyValues( body, StudentDetailsForGivenTeacherConstants.STUDENT_ID_TEXT ) );
        ArrayList<String> studentRumbaIds = new ArrayList<String>( new SMAPIProcessor().getKeyValues( body, RBSDataSetupConstants.USERID ) );

        // Expected Values
        ArrayList<String> expFirstNames = new ArrayList<String>();
        ArrayList<String> expLastNames = new ArrayList<String>();
        ArrayList<String> expMiddleNames = new ArrayList<String>();
        ArrayList<String> expUserName = new ArrayList<String>();
        ArrayList<String> expStudentIds = new ArrayList<String>();
        ArrayList<String> expGradeNames = new ArrayList<String>();

        studentRumbaIds.forEach( studentId -> {
            HashMap<String, String> studentDetails = getStudentDetailsByStudentId( studentId, teacherId, orgId, accessToken );
            JSONObject Studentbody = new JSONObject( studentDetails.get( Constants.BODY ) );

            expFirstNames.add( new SMAPIProcessor().getKeyValues( Studentbody, RBSDataSetupConstants.FIRSTNAME ).get( 0 ) );
            expLastNames.add( new SMAPIProcessor().getKeyValues( Studentbody, RBSDataSetupConstants.LASTNAME ).get( 0 ) );
            expMiddleNames.add( new SMAPIProcessor().getKeyValues( Studentbody, RBSDataSetupConstants.MIDDLENAME ).get( 0 ) );
            expUserName.add( new SMAPIProcessor().getKeyValues( Studentbody, RBSDataSetupConstants.USERNAME ).get( 0 ) );
            expGradeNames.add( new SMAPIProcessor().getKeyValues( Studentbody, StudentDetailsForStudentIdAPIConstants.GRADE ).get( 0 ) );
            try {
                expStudentIds.add( new SMAPIProcessor().getKeyValues( Studentbody, StudentDetailsForStudentIdAPIConstants.STUDENT_IDENTIFICATION_NO ).get( 0 ) );
            } catch ( Exception e ) {
                Log.message( "student has no student id" );

            }

        } );

        Log.assertThat( new SMUtils().compareTwoList( expFirstNames, firstNames ), "The FirsName value is matching", "The FirsName value is not matching" );
        Log.assertThat( new SMUtils().compareTwoList( expLastNames, lastNames ), "The lastName value is matching", "The last name value is not matching" );
        Log.assertThat( new SMUtils().compareTwoList( expMiddleNames, middleNames ), "The middleName value is matching", "The middle name value is not matching" );
        Log.assertThat( new SMUtils().compareTwoList( expUserName, userNames ), "The userName value is matching", "The username value is not matching" );
        Log.assertThat( new SMUtils().compareTwoList( expStudentIds, studentIds ), "The Student Identification Number value is matching", "The Student Identification Number value is not matching" );
        Log.message( "list"+getGradeArrayDetail(gradeNames)  );
        Log.message( "exp"+expGradeNames  );
        Log.assertThat( new SMUtils().compareTwoList( expGradeNames, getGradeArrayDetail(gradeNames) ), "The Student Grade value is matching", "The Student Grade value is not matching" );
//
//        // Grade 
//        for ( int i = 0; i < expGradeNames.size(); i++ ) {
//            int expIndex = StudentDetailsForStudentIdAPIConstants.GRADE_NAME.indexOf( expGradeNames.get( i ) );
//            int expIndex = StudentDetailsForGivenTeacherConstants.GRADE_NAMES_DROPDOWN.indexOf( expGradeNames.get( i ) );
//
//            int actIndex = StudentDetailsForGivenTeacherConstants.GRADE_NAMES_DROPDOWN.indexOf( gradeNames.get( i ) );
//            Log.message( "exp:" + expIndex + "list:" + expGradeNames.get( i ) );
//            Log.message( "act:" + actIndex + "list" + gradeNames.get( i ) );
//            //
//            Log.message( "act: " +gradeNames.get( i ) + "exp"+StudentDetailsForStudentIdAPIConstants.GRADE_VALUES.get( expIndex ));
//
//
//            Log.assertThat( expIndex == actIndex, "The Grade Name is mathcing", "The Grade Name is not matching" );
//        }
        
        
        
    }

    /**
     * Get Sections Details from Teacher Id
     * 
     * @param teacherId
     * @return
     */
    public String getSectionDetaislFromTeacher( String teacherId ) {
        Response response = null;
        String body = null;
        try {
            //Endpoint
            String endpoint = configProperty.getProperty( ConfigConstants.GET_SECTION_DETAILS_FOR_TEACHER_ID );
            endpoint = endpoint.replace( RBSDataSetupConstants.USERID, teacherId );

            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            response = RestAssuredAPIUtil.GETWithDigestAuth( configProperty.getProperty( ConfigConstants.CMS_URL ), headers, configProperty.getProperty( ConfigConstants.CMS_USERNAME ), configProperty.getProperty( ConfigConstants.CMS_PASSWORD ),
                    Constants.JSON_CONTENT_TYPE, endpoint );
            body = response.getBody().asString();
            body = body.substring( 1, body.length() - 1 );
            Log.message( body );
        } catch ( Exception e ) {
            return null;
        }

        return body;
    }
    /**
    *
    * @param gradeNames
    * @return
    * example:
    * sample Comparistion  output of the above method
    *    exp [SECOND, ELEVENTH, THIRD, SEVENTH, THIRD, EIGHT]
    *  act  [Grade 2, Grade 11, Grade 3, Grade 7, Grade 3, Grade 8]
    */
   public ArrayList<String> getGradeArrayDetail(ArrayList<String> gradeNames){
       ArrayList<String> arrayToBeFormed= new ArrayList<>();
       
       //ListIterator<String> iterator = gradeNames.listIterator();
 
      // for (Iterator iterator =   (Iterator) gradeNames.iterator(); iterator.hasNext();) {
     for(  ListIterator<String> iterator = gradeNames.listIterator();iterator.hasNext(); ) {
       String stringToBeReplaced = iterator.next();
           for (int i = 0; i < StudentDetailsForGivenTeacherConstants.GRADE_NAMES_DROPDOWN.size(); i++) {
               
               if(stringToBeReplaced.contentEquals(StudentDetailsForGivenTeacherConstants.GRADE_NAMES_DROPDOWN.get(i))) {
                   arrayToBeFormed.add(StudentDetailsForStudentIdAPIConstants.GRADE_NAME.get(i));
                   break;
               }
               
           }
     }
        return arrayToBeFormed;
           
           
       
   }
}
