package com.savvas.sm.api.tests.smnew.groups;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

/**
 * This class is used to test the remove students from groups
 * 
 * @author suriya.kumar
 */

public class Removestudsfromgroups extends GroupAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    String sessionCookie;
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String reqBodyTemplate = null;

    // Teacher variable used for this class
    private String orgUsed = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgUsed2 = RBSDataSetup.getSchools( Schools.READING_SCHOOL );

    private String teacherUsed;
    String orgId;
    String teacherId;
    String username;
    GroupAPI groupApi;
    String org1TeacherId2;
    private ArrayList<String> studentRumbaIds;
    private ArrayList<String> studentUserNames;

    // other school teacher details
    private String org2Id;
    private String org2TeacherId1;
    private String org2TeacherUsername1;
    private String teacherdetails2Org1;
    private String teacherdetails1Org1;
    private String teacherdetails1Org2;
    private String secondTeacherUsername;

    //Student Details
    private String studentDetails1;
    private String studentDetails2;
    private String studentDetails3;
    private String studentDetails4;
    private String studentDetails5;
    private String studentOne;
    private String studentTwo;
    private String studentFour;
    private String studentFive;
    private String studentSix;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws IOException {

        smUrl = configProperty.getProperty( "SMAppUrl" );

        // Teacher used Details
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        teacherUsed = RBSDataSetup.getMyTeacher( orgUsed );
        teacherId = SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERID );
        username = SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME );

        // Teacher 2 Details

        teacherdetails2Org1 = RBSDataSetup.getMyTeacher( orgUsed );
        org1TeacherId2 = SMUtils.getKeyValueFromResponse( teacherdetails2Org1, RBSDataSetupConstants.USERID );
        secondTeacherUsername = SMUtils.getKeyValueFromResponse( teacherdetails2Org1, RBSDataSetupConstants.USERNAME );

        // Other School Details
        org2Id = RBSDataSetup.organizationIDs.get( orgUsed2 );
        teacherdetails1Org2 = RBSDataSetup.getMyTeacher( orgUsed2 );
        org2TeacherId1 = SMUtils.getKeyValueFromResponse( teacherdetails1Org2, Constants.USERID );
        org2TeacherUsername1 = SMUtils.getKeyValueFromResponse( teacherdetails1Org2, Constants.USER_NAME );

        //Student Details
        studentDetails1 = RBSDataSetup.getMyStudent( orgUsed, username );
        studentDetails2 = RBSDataSetup.getMyStudent( orgUsed, username );
        studentDetails4 = RBSDataSetup.getMyStudent( orgUsed, username );
        studentDetails5 = RBSDataSetup.getMyStudent( orgUsed, username );
        studentDetails3 = RBSDataSetup.getMyStudent( orgUsed, username );

        studentOne = ( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ) );
        studentTwo = ( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERNAME ) );
        studentFour = ( SMUtils.getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERNAME ) );
        studentFive = ( SMUtils.getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERNAME ) );
        studentSix = ( SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERNAME ) );

        studentRumbaIds = new ArrayList<String>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERID ) );

        studentUserNames = new ArrayList<String>();
        studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ) );
        studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERNAME ) );

    }

    @Test ( priority = 1, groups = { "smoke_test_case", "Smoke TC001_RemoveStudentFromGroup", "Remove Students From Groups", "P1", "SMK-51110", "Remove Students From Groups", "Group", "P1", "API" } )

    public void tcRemoveStudentsFromGroups_001() throws Exception {
        SMUtils.logDescriptionTC( "SMK-15601- Verify the teacher can able to remove the student from group which has single student. (Obsolete - SMK-51323)" );
        SMUtils.logDescriptionTC( "SMK-15618- Verify the teacher can able to remove the student from group when the group associated with successmaker product. " );
        SMUtils.logDescriptionTC( "SMK-15623- Verify the teacher can able to remove the multiple students from group." );
        RBSUtils rbsutils = new RBSUtils();
        String groupName = "SMAutoClass" + System.currentTimeMillis();
        ArrayList<String> groupIds = new ArrayList<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

        HashMap<String, String> classResponse = createGroup( smUrl, groupDetails, studentRumbaIds );

        String removeStudGroup = SMUtils.getKeyValueFromResponse( classResponse.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
        groupIds.add( removeStudGroup );

        String accessCode = new RBSUtils().getAccessToken( username, password );

        HashMap<String, String> response = removeStudentsFromGroup( smUrl, studentRumbaIds.get( 0 ), removeStudGroup, teacherId, orgId, accessCode );

        // Validations
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( Constants.VALID_RESPONSE_200 ), "Response status code is as expected - " + "200", "Response status code is not as expected - " + response.get( "statusCode" ) );

        // Verifying schema
        VerifySchema( Constants.VALID_RESPONSE_200, response.get( Constants.REPORT_BODY ) );

        boolean flag = new GroupAPI().isStudentsPresentinClass( accessCode, removeStudGroup, studentRumbaIds.subList( 0, 1 ) );
        Log.assertThat( !flag, "The deleted student is not present in the class expected!", "The deleted student is present on the class not expected!" );

        Log.testCaseResult();
    }

    @Test ( priority = 2, groups = { "smoke_test_case", "Smoke TC002_RemoveStudentFromGroup", "Remove Students From Groups", "P1", "SMK-51110", "Remove Students From Groups", "Group", "P1", "API" } )
    public void tcRemoveStudentsFromGroups_002() throws Exception {

        SMUtils.logDescriptionTC( "SMK-15602- Verify the teacher can able to remove the student from group which has multiple student." );
        RBSUtils rbsutils = new RBSUtils();
        String className = "SMAutoClass" + System.currentTimeMillis();
        ArrayList<String> groupIds = new ArrayList<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        String token = new RBSUtils().getAccessToken( username, password );
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( orgUsed ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, className );
        HashMap<String, String> classResponse = createGroup( smUrl, groupDetails, studentRumbaIds );

        String removeStudGroup = SMUtils.getKeyValueFromResponse( classResponse.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
        groupIds.add( removeStudGroup );

        String accessCode = new RBSUtils().getAccessToken( username, password );
        HashMap<String, String> response = removeStudentsFromGroup( smUrl, studentRumbaIds.get( 0 ), removeStudGroup, teacherId, orgId, accessCode );
        // Validations
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( Constants.VALID_RESPONSE_200 ), "Response status code is as expected - " + Constants.VALID_RESPONSE_200, "Response status code is not as expected - " + response.get( "statusCode" ) );
        // Verifying schema
        VerifySchema( Constants.VALID_RESPONSE_200, response.get( Constants.REPORT_BODY ) );

        boolean flag = new GroupAPI().isStudentsPresentinClass( accessCode, removeStudGroup, studentRumbaIds );
        Log.assertThat( !flag, "The deleted student is not present in the class expected!", "The deleted student is present on the class not expected!" );

        Log.testCaseResult();
    }

    @Test ( priority = 3, groups = { "smoke_test_case", "Smoke TC003_RemoveStudentFromGroup", "Remove Students From Groups", "P1", "SMK-51110", "Remove Students From Groups", "Group", "P1", "API" }, enabled = false )
    public void tcRemoveStudentsFromGroups_003() throws Exception {
        /**
         * (Obsolete - SMK-51465)
         */

        SMUtils.logDescriptionTC( "SMK-15606- Verify the teacher cannot remove the student from group which is not part of the student. (Obsolete - SMK-51465)" );
        String accesstoken = new RBSUtils().getAccessToken( username, password );

        // Test data 
        String groupId = new GroupAPI().createGroupWithCustomization( "Group not part of one Student Testing", teacherId, Arrays.asList( studentRumbaIds.get( 0 ) ), orgId, accesstoken );

        String studentIdNotPartofGroup = new UserAPI().createStudentAndResetPassword( orgId, "Studentnotpartofschool" + System.nanoTime() );

        String accessCode = new RBSUtils().getAccessToken( username, password );
        HashMap<String, String> response = getResponse( studentIdNotPartofGroup, groupId, teacherId, orgId, accessCode );

        // Validations 
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( Constants.RESPONSE_CODE_400 ), "Response status code is as expected - " + "400", "Response status code is not as expected - 400 Actual " + response.get( "statusCode" ) );
        Log.testCaseResult();
    }

    @Test ( priority = 4, groups = { "smoke_test_case", "Smoke TC004_RemoveStudentFromGroup", "Remove Students From Groups", "P1", "SMK-51110", "Remove Students From Groups", "Group", "P1", "API" }, enabled = false )

    public void tcRemoveStudentsFromGroups_004() throws Exception {
        SMUtils.logDescriptionTC( "SMK-15613- Verify the teacher can able to remove the student from one school group when the teacher part of multiple school. (Obsolete - SMK-51462)" );
        SMUtils.logDescriptionTC( "SMK-15614- Verify the teacher can able to remove the student from one school group when the student is part of multiple schools.(Obsolete - SMK-51462)" );
        SMUtils.logDescriptionTC( "SMK-15621- Verify the teacher cannot able to remove the student at the same time when the teacher and students are part of multiple school.  (Obsolete - SMK-51462)" );
        String TeacherUserName = "MultiOrgTeacher" + System.nanoTime();
        String StudentUserName = "MultiOrgStudent" + System.nanoTime();

        String multiOrgTeacherId = new UserAPI().createMultiOrgTeacher( Arrays.asList( orgId, org2Id ), TeacherUserName );

        String multiOrgStudentId = new UserAPI().createMultiOrgStudent( Arrays.asList( orgId, org2Id ), StudentUserName );

        String accesstoken = new RBSUtils().getAccessToken( TeacherUserName, password );

        ArrayList<String> newStudentIds = new ArrayList<String>( studentRumbaIds );
        newStudentIds.add( multiOrgStudentId );

        // Test Data
        String classId1Org = new GroupAPI().createGroupWithCustomization( "Group 1st Org", multiOrgTeacherId, Arrays.asList( multiOrgStudentId ), orgId, accesstoken );

        String classId2Org = new GroupAPI().createGroupWithCustomization( "Group in 2nd Org", multiOrgTeacherId, Arrays.asList( multiOrgStudentId ), org2Id, accesstoken );

        String accessCode = new RBSUtils().getAccessToken( TeacherUserName, password );
        // Getting Response
        HashMap<String, String> response = removeStudentsFromGroup( smUrl, multiOrgStudentId, classId1Org, multiOrgTeacherId, orgId, accessCode );

        // Validations
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( Constants.VALID_RESPONSE_200 ), "Response status code is as expected - " + "200", "Response status code is not as expected - Expected 200 but Actual " + response.get( "statusCode" ) );
        // Verifying schema
        VerifySchema( Constants.VALID_RESPONSE_200, response.get( Constants.REPORT_BODY ) );

        boolean flag = new GroupAPI().isStudentsPresentinClass( accessCode, classId2Org, newStudentIds );
        Log.assertThat( flag, "The student is  present in the second org class expected!", "The student is  not present in the second org class not expected!" );

        Log.testCaseResult();
    }

    @Test ( priority = 7, groups = { "smoke_test_case", "Smoke TC005_RemoveStudentFromGroup", "Remove Students From Groups", "P1", "SMK-51110", "Remove Students From Groups", "Group", "P1", "API" } )

    public void tcRemoveStudentsFromGroups_007() throws Exception {
        SMUtils.logDescriptionTC( "SMK-15622- Verify the teacher can able to remove the student from multiple groups." );
        String accesstoken = new RBSUtils().getAccessToken( username, password );
        // Test data
        String groupId1 = new GroupAPI().createGroupWithCustomization( "Group1", teacherId, Arrays.asList( studentRumbaIds.get( 0 ) ), orgId, accesstoken );
        String groupId2 = new GroupAPI().createGroupWithCustomization( "Group2", teacherId, Arrays.asList( studentRumbaIds.get( 0 ) ), orgId, accesstoken );
        String groupId3 = new GroupAPI().createGroupWithCustomization( "Group3", teacherId, Arrays.asList( studentRumbaIds.get( 0 ) ), orgId, accesstoken );

        // Endpoint

        String accessCode = new RBSUtils().getAccessToken( username, password );
        // Getting Response
        HashMap<String, String> response = removeStudentsFromGroup( smUrl, studentRumbaIds.get( 0 ), groupId1, teacherId, orgId, accessCode );

        response = removeStudentsFromGroup( smUrl, studentRumbaIds.get( 0 ), groupId2, teacherId, orgId, accessCode );
        response = removeStudentsFromGroup( smUrl, studentRumbaIds.get( 0 ), groupId3, teacherId, orgId, accessCode );

        // Validations
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( Constants.VALID_RESPONSE_200 ), "Response status code is as expected - " + "200", "Response status code is not as expected - " + response.get( "statusCode" ) );

        // Verifying schema
        VerifySchema( Constants.VALID_RESPONSE_200, response.get( Constants.REPORT_BODY ) );

        boolean flag = new GroupAPI().isStudentsPresentinClass( accessCode, groupId1, studentRumbaIds.subList( 0, 1 ) );
        Log.assertThat( !flag, "The deleted student is not present in the class expected!", "The deleted student is present on the class not expected!" );

        flag = new GroupAPI().isStudentsPresentinClass( accessCode, groupId2, studentRumbaIds.subList( 0, 1 ) );
        Log.assertThat( !flag, "The deleted student is not present in the class expected!", "The deleted student is present on the class not expected!" );

        flag = new GroupAPI().isStudentsPresentinClass( accessCode, groupId3, studentRumbaIds.subList( 0, 1 ) );
        Log.assertThat( !flag, "The deleted student is not present in the class expected!", "The deleted student is present on the class not expected!" );

        Log.testCaseResult();

    }

    @Test ( priority = 8, groups = { "smoke_test_case", "Smoke TC006_RemoveStudentFromGroup", "Remove Students From Groups", "P1", "SMK-51110", "Remove Students From Groups", "Group", "P1", "API" } )

    public void tcRemoveStudentsFromGroups_008() throws Exception {
        SMUtils.logDescriptionTC( "SMK-15624- Verify the teacher can able to remove the multiple students from multiple group." );
        String accesstoken = new RBSUtils().getAccessToken( username, password );
        // Test data
        String groupId1 = new GroupAPI().createGroupWithCustomization( "Group1", teacherId, Arrays.asList( studentRumbaIds.get( 0 ) ), orgId, accesstoken );
        String groupId2 = new GroupAPI().createGroupWithCustomization( "Group2", teacherId, Arrays.asList( studentRumbaIds.get( 1 ) ), orgId, accesstoken );
        String groupId3 = new GroupAPI().createGroupWithCustomization( "Group3", teacherId, Arrays.asList( studentRumbaIds.get( 2 ) ), orgId, accesstoken );

        // Endpoint

        String accessCode = new RBSUtils().getAccessToken( username, password );
        // Getting Response
        HashMap<String, String> response = removeStudentsFromGroup( smUrl, studentRumbaIds.get( 0 ), groupId1, teacherId, orgId, accessCode );
        ;
        removeStudentsFromGroup( smUrl, studentRumbaIds.get( 1 ), groupId2, teacherId, orgId, accessCode );
        removeStudentsFromGroup( smUrl, studentRumbaIds.get( 1 ), groupId3, teacherId, orgId, accessCode );

        // Validations
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( Constants.VALID_RESPONSE_200 ), "Response status code is as expected - " + "200", "Response status code is not as expected - " + response.get( "statusCode" ) );

        // Verifying schema
        VerifySchema( Constants.VALID_RESPONSE_200, response.get( Constants.REPORT_BODY ) );

        boolean flag = new GroupAPI().isStudentsPresentinClass( accessCode, groupId1, Arrays.asList( studentRumbaIds.get( 0 ) ) );
        Log.assertThat( !flag, "The deleted student is not present in the class expected!", "The deleted student is present on the class not expected!" );

        flag = new GroupAPI().isStudentsPresentinClass( accessCode, groupId2, Arrays.asList( studentRumbaIds.get( 1 ) ) );
        Log.assertThat( !flag, "The deleted student is not present in the class expected!", "The deleted student is present on the class not expected!" );

        flag = new GroupAPI().isStudentsPresentinClass( accessCode, groupId3, Arrays.asList( studentRumbaIds.get( 2 ) ) );
        Log.assertThat( !flag, "The deleted student is not present in the class expected!", "The deleted student is present on the class not expected!" );

        Log.testCaseResult();

    }

    @Test ( priority = 6, groups = { "smoke_test_case", "Smoke TC007_RemoveStudentFromGroup", "Remove Students From Groups", "P1", "SMK-51110", "Remove Students From Groups", "Group", "P1", "API" }, enabled = false )
    public void tcRemoveStudentsFromGroups_006() throws Exception {
        /**
         * Obsolete - This scenario is not possible from UI side bug Id -
         * SMK-52207
         */
        SMUtils.logDescriptionTC( "SMK-15620- Verify the teacher cannot able to remove the student from other school group." );

        String accesstoken = new RBSUtils().getAccessToken( username, password );

        // Test data
        // other school
        ArrayList<String> school2StudentsIds = new UserAPI().getStudentIds( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) );

        String groupIdOtherSchool = new GroupAPI().createGroupWithCustomization( "Group -other school ", org2TeacherId1, school2StudentsIds, org2Id, new RBSUtils().getAccessToken( org2TeacherUsername1, password ) );

        String accessCode = new RBSUtils().getAccessToken( username, password );
        // Getting Response
        HashMap<String, String> response = getResponse( studentRumbaIds.get( 0 ), groupIdOtherSchool, teacherId, orgId, accessCode );

        // Validations
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( Constants.RESPONSE_CODE_400 ), "Response status code is as expected - " + "400", "Response status code is not as expected - expected 400 actual " + response.get( "statusCode" ) );
        Log.testCaseResult();

    }

    @Test ( priority = 5, groups = { "smoke_test_case", "Smoke TC008_RemoveStudentFromGroup", "Remove Students From Groups", "P1", "SMK-51110", "Remove Students From Groups", "Group", "P1", "API" } )

    public void tcRemoveStudentsFromGroups_005() throws Exception {
        SMUtils.logDescriptionTC( "SMK-15617- Verify the teacher cannot remove the student from the group which does not have successmaker product. (Obsolete - SMK-51456)" );
        String accesstoken = new RBSUtils().getAccessToken( username, password );

        // Test data
        String withoutProduct = "noSMProductGroup" + System.nanoTime();

        String groupId = new GroupAPI().createGroupWithCustomization( withoutProduct, teacherId, studentRumbaIds.subList( 0, 1 ), orgId, accesstoken );

        String accessCode = new RBSUtils().getAccessToken( username, password );
        // Getting Response
        HashMap<String, String> response = removeStudentsFromGroup( smUrl, studentRumbaIds.get( 0 ), groupId, teacherId, orgId, accessCode );
        response = removeStudentsFromGroup( smUrl, studentRumbaIds.get( 1 ), groupId, teacherId, orgId, accessCode );

        // Validations
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( Constants.VALID_RESPONSE_200 ), "Response status code is as expected - " + "200", "Response status code is not as expected - " + response.get( "statusCode" ) );
        // Verifying schema
        VerifySchema( Constants.VALID_RESPONSE_200, response.get( Constants.REPORT_BODY ) );

        boolean flag = new GroupAPI().isStudentsPresentinClass( accessCode, groupId, studentRumbaIds );
        Log.assertThat( !flag, "The deleted student is not present in the class expected!", "The deleted student is present on the class not expected!" );

        Log.testCaseResult();

    }

    @Test ( priority = 5, groups = { "smoke_test_case", "Smoke TC009_RemoveStudentFromGroup", "Remove Students From Groups", "P1", "SMK-51110", "Remove Students From Groups", "Group", "P1", "API" } )
    public void tcRemoveStudentsFromGroups_010() throws Exception {
        SMUtils.logDescriptionTC( "SMK-15603- Verify the teacher can able to remove the student from shared group." );
        String accesstoken = new RBSUtils().getAccessToken( username, password );

        String classId = new RBSUtils().createClassWithMultipleTeacher( "class -with Multiple teacher", Arrays.asList( teacherId, org1TeacherId2 ), studentRumbaIds.subList( 0, 2 ), orgId, accesstoken );

        // Getting Response
        HashMap<String, String> response = removeStudentsFromGroup( smUrl, studentRumbaIds.get( 0 ), classId, teacherId, orgId, accesstoken );
        response = removeStudentsFromGroup( smUrl, studentRumbaIds.get( 1 ), classId, teacherId, orgId, accesstoken );
        response = removeStudentsFromGroup( smUrl, studentRumbaIds.get( 2 ), classId, teacherId, orgId, accesstoken );

        // Validations
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( Constants.VALID_RESPONSE_200 ), "Response status code is as expected - " + "200", "Response status code is not as expected - " + response.get( "statusCode" ) );

        // Verifying schema
        VerifySchema( Constants.VALID_RESPONSE_200, response.get( Constants.REPORT_BODY ) );

        boolean flag = new GroupAPI().isStudentsPresentinClass( accesstoken, classId, studentRumbaIds.subList( 0, 1 ) );
        Log.assertThat( !flag, "The deleted student is not present in the class expected!", "The deleted student is present on the class not expected!" );

        Log.testCaseResult();
    }

    @Test ( priority = 9, dataProvider = "InvalidScenarios", groups = { "Smoke TC0010_RemoveStudentFromGroup", "Remove Students From Groups", "P1", "SMK-51110", "Remove Students From Groups", "Group", "P1", "API" } )
    public void tcRemoveStudentsFromGroups_009( String description, String scenario, String expStatusCode ) throws Exception {

        String accessCode;
        String body = null;
        Map<String, String> headers = null;
        String endpoint = null;
        HashMap<String, String> params = null;
        String className = null;
        String classId = null;

        SMUtils.logDescriptionTC( scenario );

        if ( scenario.equalsIgnoreCase( "INVLAID_AUTH" ) ) {
            accessCode = CommonAPIConstants.INVALID_ACCESS_TOKEN;

        } else if ( scenario.equalsIgnoreCase( "STUDENT_AUTH" ) ) {
            //String studUsername = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(orgUsed, username),RBSDataSetupConstants.USERNAME);
            accessCode = new RBSUtils().getAccessToken( studentUserNames.get( 0 ), password );
        } else {
            accessCode = new RBSUtils().getAccessToken( username, password );

        }

        switch ( scenario ) {
            case "INVALID_STUDENT_ID":

                className = "SMAutoClass" + System.currentTimeMillis();

                classId = new GroupAPI().createGroupWithCustomization( "Group - invalid student Id", teacherId, studentRumbaIds, orgId, accessCode );

                // Endpoint
                endpoint = GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ENDPOINT;
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID, orgId );
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.STAFF_ID, teacherId );

                // headers
                headers = new HashMap<String, String>();
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
                headers.put( RemoveStudentsFromGroupsAPIConstants.ORG_ID_HEADER, orgId );
                headers.put( RemoveStudentsFromGroupsAPIConstants.USER_ID_HEADER, teacherId );

                // Input Parameters
                params = new HashMap<>();
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.STUDENT_IDS, "XXXXX" );
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.GROUP_IDS, classId );

                break;
            case "PARTIAL_INVALID STUDENT_ID":

                className = "SMAutoClass" + System.currentTimeMillis();
                classId = new GroupAPI().createGroupWithCustomization( "Group - invalid student Id partial", teacherId, studentRumbaIds, orgId, accessCode );

                // Endpoint
                endpoint = GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ENDPOINT;
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID, orgId );
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.STAFF_ID, teacherId );

                // headers
                headers = new HashMap<String, String>();
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
                headers.put( RemoveStudentsFromGroupsAPIConstants.ORG_ID_HEADER, orgId );
                headers.put( RemoveStudentsFromGroupsAPIConstants.USER_ID_HEADER, teacherId );
                // Input Parameters
                params = new HashMap<>();
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.STUDENT_IDS, "XXXXX" );
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.GROUP_IDS, classId );
                break;

            case "INVALID_GROUP_ID":

                className = "SMAutoClass" + System.currentTimeMillis();

                // Endpoint
                endpoint = GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ENDPOINT;
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID, orgId );
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.STAFF_ID, teacherId );

                // headers
                headers = new HashMap<String, String>();
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
                headers.put( RemoveStudentsFromGroupsAPIConstants.ORG_ID_HEADER, orgId );
                headers.put( RemoveStudentsFromGroupsAPIConstants.USER_ID_HEADER, teacherId );

                // Input Parameters
                params = new HashMap<>();
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.STUDENT_IDS, studentRumbaIds.get( 0 ) );
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.GROUP_IDS, "XXXXXXXX" );
                break;

            case "PARTIAL_INVALID GROUP_ID":

                className = "SMAutoClass" + System.currentTimeMillis();
                classId = new GroupAPI().createGroupWithCustomization( "Group - invalid group Id partial", teacherId, studentRumbaIds, orgId, accessCode );

                // Endpoint
                endpoint = GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ENDPOINT;
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID, orgId );
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.STAFF_ID, teacherId );

                // headers
                headers = new HashMap<String, String>();
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
                headers.put( RemoveStudentsFromGroupsAPIConstants.ORG_ID_HEADER, orgId );
                headers.put( RemoveStudentsFromGroupsAPIConstants.USER_ID_HEADER, teacherId );

                // Input Parameters
                params = new HashMap<>();
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.STUDENT_IDS, "XXXXX" );
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.GROUP_IDS, classId );
                break;

            case "STUDENT_AUTH":
                className = "SMAutoClass" + System.currentTimeMillis();

                // Endpoint
                endpoint = GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ENDPOINT;
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID, orgId );
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.STAFF_ID, studentRumbaIds.get( 0 ) );

                // headers
                headers = new HashMap<String, String>();
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
                headers.put( RemoveStudentsFromGroupsAPIConstants.ORG_ID_HEADER, orgId );
                headers.put( RemoveStudentsFromGroupsAPIConstants.USER_ID_HEADER, studentRumbaIds.get( 0 ) );

                // Input Parameters
                params = new HashMap<>();
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.STUDENT_IDS, studentRumbaIds.get( 0 ) );
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.GROUP_IDS, classId );

                break;
            case "INVLAID_AUTH":
                className = "SMAutoClass" + System.currentTimeMillis();

                classId = new GroupAPI().createGroupWithCustomization( "Group - invalid auth", teacherId, studentRumbaIds, orgId, new RBSUtils().getAccessToken( username, password ) );

                // Endpoint
                endpoint = GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ENDPOINT;
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID, orgId );
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.STAFF_ID, teacherId );

                // headers
                headers = new HashMap<String, String>();
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
                headers.put( RemoveStudentsFromGroupsAPIConstants.ORG_ID_HEADER, orgId );
                headers.put( RemoveStudentsFromGroupsAPIConstants.USER_ID_HEADER, teacherId );

                // Input Parameters
                params = new HashMap<>();

                break;

            case "EMPTY_GROUP":

                classId = new GroupAPI().createGroupWithCustomization( "Group - with no student", teacherId, new ArrayList<String>(), orgId, accessCode );

                // Endpoint
                endpoint = GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ENDPOINT;
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID, orgId );
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.STAFF_ID, teacherId );

                // headers
                headers = new HashMap<String, String>();
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
                headers.put( RemoveStudentsFromGroupsAPIConstants.ORG_ID_HEADER, orgId );
                headers.put( RemoveStudentsFromGroupsAPIConstants.USER_ID_HEADER, teacherId );

                // Input Parameters
                params = new HashMap<>();
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.STUDENT_IDS, studentRumbaIds.get( 0 ) );
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.GROUP_IDS, "" );

                break;

            case "DELETE_GROUP":

                classId = new GroupAPI().createGroupWithCustomization( "Group - to be deleted", teacherId, studentRumbaIds, orgId, accessCode );

                new RBSUtils().deleteClass( classId, teacherId );

                // Endpoint
                endpoint = GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ENDPOINT;
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID, orgId );
                endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.STAFF_ID, teacherId );

                // headers
                headers = new HashMap<String, String>();
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
                headers.put( RemoveStudentsFromGroupsAPIConstants.ORG_ID_HEADER, orgId );
                headers.put( RemoveStudentsFromGroupsAPIConstants.USER_ID_HEADER, teacherId );

                // Input Parameters
                params = new HashMap<>();
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.STUDENT_IDS, studentRumbaIds.get( 0 ) );
                params.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.GROUP_IDS, classId );

                break;

            default:
                break;

        }
        String s = scenario;
        // Make DELETE Call
        Log.message( "Making DELETE Call - " + smUrl + RemoveStudentsFromGroupsAPIConstants.ENDPOINT );
        HashMap<String, String> response = RestHttpClientUtil.DELETE( smUrl, endpoint, headers, params );

        // Validations
        Log.assertThat( response.get( "statusCode" ).equals( expStatusCode ), "Response status code is as expected - " + expStatusCode, "Response status code is not as expected - " + expStatusCode + " Actual " + response.get( "statusCode" ) );

        // Verifying schema
        VerifySchema( response.get( "statusCode" ), response.get( Constants.REPORT_BODY ) );

        Log.testCaseResult();
    }

    @DataProvider ( name = "InvalidScenarios" )
    public Object[][] groupDataInvalid() {

        Object[][] inputData = { { "Verify the exception when the student Ids are invalid.", "INVALID_STUDENT_ID", "400" }, { "Verify the exception when the student Ids are partially invalid (Obsolete - SMK-51464)", "PARTIAL_INVALID STUDENT_ID", "400" },
                //This two tc is excluded as put in Place Holder stoires
                //{ "Verify the exception when the group IDs are invalid. (Obsolete - SMK-51466)", "INVALID_GROUP_ID", "400" }, { "Verify the exception when the group Ids are partially invalid. (Obsolete - SMK-51466)", "PARTIAL_INVALID GROUP_ID", "400" },
                { "Verify the 403 authorization exception when the token is student authorization.", "STUDENT_AUTH", "403" }, { "Verify the 401 authentication exception when the access token in invalid.", "INVLAID_AUTH", "401" },
                { "Verify the teacher cannot able to remove the student from empty group.", "EMPTY_GROUP", "400" }, { "Verify the exception when the teacher removes the student from deleted classes.", "DELETE_GROUP", "404" } };

        return inputData;
    }

    public String getClassId( HashMap<String, String> response ) {
        return new SMAPIProcessor().getKeyValues( new JSONObject( response.get( StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.BODY_STRING ) ), StudentsAPIConstants.StudentDetailsForGivenTeacherConstants.GROUP_ID ).get( 0 );
    }

    /**
     * Verify the schema for the api
     * 
     * @param StatusCode
     * @param Body
     */
    public void VerifySchema( String StatusCode, String Body ) {
        boolean isValid = false;
        try {
            isValid = new SMAPIProcessor().isSchemaValid( "RemoveStuFromGroupsSchema", StatusCode, Body );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
        Log.assertThat( isValid, "The schema is valid and mathcing", "The schema is not valid and not  mathcing for the Status code :" + StatusCode );
    }

    /**
     * Get response for the Remove Students from Groups API
     * 
     * @param groupIds
     * @param studentIds
     * @param teacherId
     * @param orgId
     * @param accessToken
     * @return
     */
    public HashMap<String, String> getResponse( String studentIds, String groupIds, String teacherId, String orgId, String accessToken ) {
        try {
            // Endpoint

            String endpoint = GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ENDPOINT;
            endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID, orgId );
            endpoint = endpoint.replace( GroupAPIConstants.RemoveStudentsFromGroupsAPIConstants.STAFF_ID, teacherId );

            // headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
            headers.put( RemoveStudentsFromGroupsAPIConstants.ORG_ID_HEADER, orgId );
            headers.put( RemoveStudentsFromGroupsAPIConstants.USER_ID_HEADER, teacherId );
            return new GroupAPI().removeStudentFromGroup( smUrl, studentIds, groupIds, teacherId, orgId, accessToken );

        } catch ( Exception e ) {
            return null;
        }
    }

    /**
     * Get response for the Remove Students from Groups API
     * 
     * @param smURL
     * @param studentId
     * @param groupId
     * @param teacherId
     * @param orgId
     * @param accessToken
     * @return
     */
    public HashMap<String, String> removeStudentsFromGroup( String smURL, String studentId, String groupId, String teacherId, String orgId, String accessToken ) {
        String endpoint = GroupConstants.RemoveStudentsFromGroupsAPIConstants.ENDPOINT;
        Map<String, String> headers = new HashMap<String, String>();
        HashMap<String, String> params = new HashMap<>();
        HashMap<String, String> response = new HashMap<>();

        try {
            // Endpoint
            endpoint = endpoint.replace( GroupConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID, orgId );
            endpoint = endpoint.replace( GroupConstants.RemoveStudentsFromGroupsAPIConstants.STAFF_ID, teacherId );
            endpoint = endpoint.concat( "?studentIds=" ) + studentId + "&groupIds=" + groupId;

            // headers
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
            headers.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.ORG_ID_HEADER, orgId );
            headers.put( GroupConstants.RemoveStudentsFromGroupsAPIConstants.USER_ID_HEADER, teacherId );

            /*
             * // Input Parameters params.put(
             * GroupConstants.RemoveStudentsFromGroupsAPIConstants.STUDENT_IDS,
             * studentId ); params.put(
             * GroupConstants.RemoveStudentsFromGroupsAPIConstants.GROUP_IDS,
             * groupId );
             */

            // Getting resonse
            response = RestHttpClientUtil.DELETE( smURL, endpoint, headers, params );
            Log.message( "The Received response is : " + response.toString() );

        } catch ( Exception e ) {
            Log.message( e.getMessage() );
            return null;
        }
        return response;
    }

}