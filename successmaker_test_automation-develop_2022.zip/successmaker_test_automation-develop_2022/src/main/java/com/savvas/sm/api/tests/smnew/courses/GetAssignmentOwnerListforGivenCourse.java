package com.savvas.sm.api.tests.smnew.courses;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.SharedCourseTeacherAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class GetAssignmentOwnerListforGivenCourse extends CourseAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String flexSchoolTeacherDetails = null;
    private String readingSchoolTeacherDetails = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String readingSchool = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String token = null;
    private String districtId;
    private String username;
    private String password;
    private String userId;
    private String teacherUsername;
    private String teacherUserId;
    private String courseId;
    private BaseAPITest baseAPITest = new BaseAPITest();
    private RBSUtils rbsUtils = new RBSUtils();
    //Variable declaration
    String userName = null;
    AssignmentAPI assignmentObg = new AssignmentAPI();
    String endpoint;
    AssignmentAPI assignmentAPI;
    String studentDetails;
    String readingStudentDetails;

    @BeforeClass(alwaysRun=true)
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        readingSchoolTeacherDetails = RBSDataSetup.getMyTeacher( readingSchool );
        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        studentDetails = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        readingStudentDetails = RBSDataSetup.getMyStudent( readingSchool, SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ) );

        //Creating a shared course.
        courseId = new SharedCourseTeacherAPI().createSharedCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherUserId, RBSDataSetup.organizationIDs.get( flexSchool ), DataSetupConstants.SETTINGS,
                "Shared Math course" + System.nanoTime() );
        assignmentAPI = new AssignmentAPI();

    }

    @Test ( priority = 1, dataProvider = "positiveScenariosForGetAssignmentOwnerList", groups = { "SMK-53112", "Course", "GetAssignmentOwnerList", "P1", "API", "smoke_test_case" } )
    public void getAssignmentOwnerListPositiveScenarios( String description, String statusCode, String courseId, String scenario ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );

        HashMap<String, String> apiResponse_createSettingBasedCourse = new HashMap<>();
        HashMap<String, String> courseDetails = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> editSharedCourses_api = new HashMap<>();
        String reponseDataForValidation;

        //Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        //Create Custom course by setting
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( flexSchool ) );
        headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );

        //course details
        courseDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        courseDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        courseDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
        courseDetails.put( Constants.COURSE_NAME, "Settings" + System.nanoTime() );

        //Creating custom by setting course
        apiResponse_createSettingBasedCourse = createCourseBySetting( smUrl, headers, courseDetails, scenario );
        Log.message( "response from PostCall for setting based course- " + apiResponse_createSettingBasedCourse );
        String customCourseId = SMUtils.getKeyValueFromResponse( apiResponse_createSettingBasedCourse.get( Constants.REPORT_BODY ), "data,id" );

        //Assigning a newly created course to student
        List<String> studentRumbaIdsTc001 = new ArrayList<>();

        //Adding students to group
        studentRumbaIdsTc001 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, userName, flexSchool, studentDetails );

        //Assigning assignment to student
        addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, customCourseId, flexSchool, studentRumbaIdsTc001.get( 0 ) );

        HashMap<String, String> apiResponse_getAssignmentOwnerListDetails = new HashMap<>();
        HashMap<String, String> apiResponse_getAssignmentOwnerListAfterSharingCourse = new HashMap<>();
        HashMap<String, String> apiResponse_getAssignmentOwnerListAfterDeletingCourse = new HashMap<>();

        HashMap<String, String> getAssignmentOwnerListDetails = new HashMap<>();
        List<String> totalTeachersBefore = new ArrayList<String>();
        List<String> totalTeachersAfter = new ArrayList<String>();

        //Get Assignment owner details
        getAssignmentOwnerListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        getAssignmentOwnerListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        getAssignmentOwnerListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        getAssignmentOwnerListDetails.put( CourseAPIConstants.COURSE_ID, customCourseId );

        // Getting response from get assignment owner list Api.
        apiResponse_getAssignmentOwnerListDetails = getAssignmentOwnerListDetails( smUrl, getAssignmentOwnerListDetails );
        Log.message( "response from GetCall - " + apiResponse_getAssignmentOwnerListDetails );

        //Assertion
        Log.softAssertThat( verifySuccessStatus( apiResponse_getAssignmentOwnerListDetails.get( "body" ), CommonAPIConstants.STATUS ), "Status is getting as expected", "Status is not getting as expected" );
        Log.softAssertThat( apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ),
                "Status code is returned as expected and the same is " + apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ) );

        switch ( scenario ) {
            case "Shared Course":

                //Sharing a course to another organization.
                editSharedCourses( smUrl, username, password, userId, districtId, courseId, Arrays.asList( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) ) );
                editSharedCourses_api = getSharedCourses( smUrl, username, password, userId, districtId );
                Log.assertThat( verifySharedOrgCount( editSharedCourses_api.get( Constants.BODY ), courseId, "2" ), "Shared org count is updated after shared with new organization", "Shared org count is not updated after shared with new organization" );

                tokenCreation( CommonAPIConstants.READING_LICENSE_SCHOOL );
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( readingSchool ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, "userId" ) );

                //Assigning a newly created shared course to student
                List<String> studentRumbaIdsTc002 = new ArrayList<>();

                //Adding students to group
                studentRumbaIdsTc002 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, userName, readingSchool, readingStudentDetails );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, customCourseId, readingSchool, studentRumbaIdsTc002.get( 0 ) );

                Log.message( "shared course has been assigned by reading school" );

                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );
                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( flexSchool ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                // Getting response from get assignment owner list Api.
                apiResponse_getAssignmentOwnerListAfterSharingCourse = getAssignmentOwnerListDetails( smUrl, getAssignmentOwnerListDetails );
                Log.message( "response from Get Call with two teacher names - " + apiResponse_getAssignmentOwnerListAfterSharingCourse );

                //Assertion
                Log.softAssertThat( verifySuccessStatus( apiResponse_getAssignmentOwnerListDetails.get( "body" ), CommonAPIConstants.STATUS ), "Status is getting as expected", "Status is not getting as expected" );
                Log.softAssertThat( apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ),
                        "Status code is returned as expected and the same is " + apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ) );

                //Assertion to get teacher name listed which belongs to org2.

                reponseDataForValidation = SMUtils.getKeyValueFromResponse( apiResponse_getAssignmentOwnerListDetails.get( Constants.REPORT_BODY ), Constants.DATA );
                totalTeachersBefore = SMUtils.getTheKeyCount( reponseDataForValidation.toString(), CourseAPIConstants.TEACHER );

                reponseDataForValidation = SMUtils.getKeyValueFromResponse( apiResponse_getAssignmentOwnerListAfterSharingCourse.get( Constants.REPORT_BODY ), Constants.DATA );
                totalTeachersAfter = SMUtils.getTheKeyCount( reponseDataForValidation.toString(), CourseAPIConstants.TEACHER );

                Log.softAssertThat( !( totalTeachersBefore.size() == totalTeachersAfter.size() ), "Org2 teacher name has been added into the List", "Org2 teacher name has not been added into the List" );
                break;

            case "Delete_Assignment":
                String endpoint = "null";
                HashMap<String, String> getresponse = assignmentAPI.deleteAssignment( smUrl, getAssignmentOwnerListDetails, endpoint );
                Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
                Log.message( getresponse.get( "statusCode" ) );
                Log.message( "delete response" + getresponse.get( "body" ) );
                Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );

                // Getting response from get assignment owner list Api after deleting the course
                apiResponse_getAssignmentOwnerListAfterDeletingCourse = getAssignmentOwnerListDetails( smUrl, getAssignmentOwnerListDetails );
                Log.message( "response from Get Call with two teacher names - " + apiResponse_getAssignmentOwnerListAfterDeletingCourse );
                //Assertion
                Log.softAssertThat( verifySuccessStatus( apiResponse_getAssignmentOwnerListDetails.get( "body" ), CommonAPIConstants.STATUS ), "Status is getting as expected", "Status is not getting as expected" );
                Log.softAssertThat( apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ),
                        "Status code is returned as expected and the same is " + apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ) );
        }
        Log.testCaseResult();
    }

    @Test ( priority = 1, dataProvider = "negativeScenariosForGetAssignmentOwnerList", groups = { "SMK-53112", "Course", "GetAssignmentOwnerList", "P2", "API" } )
    public void getAssignmentOwnerListNegativeScenarios( String description, String scenario, String statusCode, String courseId, String exception ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse_getAssignmentOwnerListDetails = new HashMap<>();
        HashMap<String, String> apiResponse_invalidUrl = new HashMap<>();
        HashMap<String, String> getAssignmentOwnerListDetails = new HashMap<>();

        //Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        if ( scenario.equalsIgnoreCase( "UNAUTHORIZED_ORG_ID" ) ) {
            getAssignmentOwnerListDetails.put( Constants.ORGID_SM_HEADER, CourseAPIConstants.UNAUTHORIZED_ORG_ID );
        } else {
            getAssignmentOwnerListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        }
        if ( scenario.equalsIgnoreCase( "INVALID_AUTHORIZATION" ) ) {
            getAssignmentOwnerListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CourseAPIConstants.INVALID_AUTHORIZATION_ID );
        } else {
            getAssignmentOwnerListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        }
        if ( scenario.equalsIgnoreCase( "INVALID_ORG_ID" ) ) {
            getAssignmentOwnerListDetails.put( Constants.ORGID_SM_HEADER, CourseAPIConstants.INVALID_ORGANIZATION_ID );
        } else {
            getAssignmentOwnerListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        }
        if ( scenario.equalsIgnoreCase( "NONEXISTING_ORG_ID" ) ) {
            getAssignmentOwnerListDetails.put( Constants.ORGID_SM_HEADER, CourseAPIConstants.NON_EXISTING_ORGANIZATION_ID );
        } else {
            getAssignmentOwnerListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        }
        if ( scenario.equalsIgnoreCase( "UNAUTHORIZED_STAFF_ID" ) ) {
            getAssignmentOwnerListDetails.put( Constants.USERID_SM_HEADER, CourseAPIConstants.UNAUTHORIZED_STAFF_ID );
        } else {
            getAssignmentOwnerListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        }
        if ( scenario.equalsIgnoreCase( "NONEXISTING_STAFF_ID" ) ) {
            getAssignmentOwnerListDetails.put( Constants.USERID_SM_HEADER, CourseAPIConstants.NON_EXISTING_STAFF_ID );
        } else {
            getAssignmentOwnerListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        }
        if ( scenario.equalsIgnoreCase( "INVALID_STAFF_ID" ) ) {
            getAssignmentOwnerListDetails.put( Constants.USERID_SM_HEADER, CourseAPIConstants.INVALID_STAFF_ID );
        } else {
            getAssignmentOwnerListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        }
        getAssignmentOwnerListDetails.put( CourseAPIConstants.COURSE_ID, courseId );

        apiResponse_getAssignmentOwnerListDetails = getAssignmentOwnerListDetails( smUrl, getAssignmentOwnerListDetails );
        Log.message( "response from GetCall - " + apiResponse_getAssignmentOwnerListDetails );

        //Assertion
        Log.softAssertThat( verifyExceptionMessage( apiResponse_getAssignmentOwnerListDetails.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
        Log.softAssertThat( apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ),
                "Status code is returned as expected and the same is " + apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse_getAssignmentOwnerListDetails.get( Constants.STATUS_CODE ) );

        Log.testCaseResult();
    }

    /**
     * To Verify the shared org count for given courseId
     * 
     * @param responseBody
     * @param courseId
     * @param expectedOrgCount
     * @return
     */
    public boolean verifySharedOrgCount( String responseBody, String courseId, String expectedOrgCount ) {
        return IntStream.rangeClosed( 1, SMUtils.getWordCount( responseBody, CourseAPIConstants.COURSE_NAME ) ).filter( iter -> SMUtils.getKeyValueFromJsonArray( responseBody, CourseAPIConstants.ID, iter ).equals( courseId ) ).allMatch(
                iter -> SMUtils.getKeyValueFromJsonArray( responseBody, CourseAPIConstants.SHARED_ORG_COUNT, iter ).equals( expectedOrgCount ) );
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "positiveScenariosForGetAssignmentOwnerList" )
    public Object[][] getAssignmentOwnerListPositiveScenario() {
        Object[][] inputData = { { "TC_001 Verify the status code is 200 when course must be assigned to student and valid test data is given for organization id,Staff id and course id.(Reading)", "200", "2", "READING" },
                { "TC_002 Verify the status code is 200 when course must be assigned to group and valid test data is given for organization id,Staff id and course id.(Reading)", "200", "2", "READING" },
                { "TC_003 Verify the status code is 200 when course must be assigned to student or group and valid test data is given for organization id,Staff id and course id.(Math)", "200", "1", "null" },
                { "TC_004 Verify the status code is 200 when course has been shared at district level and different org teacher has assigned that course to their student/group.", "200", "1", "Shared Course" },
                { "TC_005 Verify the status code is 200 when course has been assigned by teacher who belongs to same organization.", "200", "2", "READING" },
                { "TC_011 Verify the status code is 200 when the assignment is deleted.", "200", "1", "Delete_Assignment" },

        };
        return inputData;
    }

    /**
     * Data provider for negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "negativeScenariosForGetAssignmentOwnerList" )
    public Object[][] getAssignmentOwnerListNegativeScenario() {
        Object[][] inputData = { { "TC_007 Verify the status code is 200 when test data is given for ORG 3, and T3", "UNAUTHORIZED_ORG_ID", "200", "4346", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC_012 Verify the status code is 200 when the unassigned course id has given.", "null", "400", "3", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC_014 Verify the status code is 400 when the invalid Course Id is given.", "null", "400", "ws", "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
                { "TC_013 Verify the status code is 400 when the invalid Course Id(abc) is given.", "null", "400", "#@", "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
                { "TC_015 Verify the status code is 200 when assignment id is given instead of course id.", "null", "200", "4199", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC_016 Verify the status code is 200 when non existing Course Id(-999999) is given", "null", "200", "55555", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC_017 Verify the status code is 400 when the invalid organization Id(@#) is given.", "INVALID_ORG_ID", "200", "4346", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC_018 Verify the status code is 400 when org id which is belongs to different teacher is given.", "UNAUTHORIZED_ORG_ID", "200", "4346", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC_019 Verify the status code is 200 when the non existing organization Id(22222) is given.", "NONEXISTING_ORG_ID", "200", "4346", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC_020 Verify the status code is 400 when the invalid staff Id(@#/abc) is given.", "INVALID_STAFF_ID", "200", "4346", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC_021 Verify the status code is 200 when the non existing staff Id(22222) is given.", "NONEXISTING_STAFF_ID", "200", "4346", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC_022 Verify the status code is 400 when staff id  is given which belongs to different organization.", "UNAUTHORIZED_STAFF_ID", "400", "1", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC_025 Verify the status code is 401 when invalid authorization is given", "INVALID_AUTHORIZATION", "401", "null", "java.lang.Exception" }, };

        return inputData;
    }

    /**
     * Token creation
     * 
     * @param school
     */
    public void tokenCreation( String school ) {
        try {
            switch ( school ) {
                case CommonAPIConstants.FLEX_LICENSE_SCHOOL:
                    teacherDetails = flexSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.READING_LICENSE_SCHOOL:
                    teacherDetails = readingSchoolTeacherDetails;
                    break;
            }
            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
            userName = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Error occurred in the token creation. Please check!!" );
        }
    }

    //Adding Students to group
    public List<String> addStudentsToGroup( String statusCode, String userName, String school, String student ) {
        HashMap<String, String> response;
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        try {
            //Adding students to group
            String groupName = "Successmaker API Test Group " + System.nanoTime();
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student, "userId" ) );
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, userName );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            Log.message( "groupDetails is " + groupDetails );
            GroupAPI GroupAPI = new GroupAPI();
            response = GroupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );
            Log.message( "response for group creation is " + response );
            Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        } catch ( Exception e ) {
            Log.message( "Issue occured in addStudentsToGroup" );
        }
        return studentRumbaIds;
    }

    //Assigning assignment to student
    public void addAssignmentsToStudents( String statusCode, String courseId, String school, String studentRumbaId ) {
        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentRumbaId );
        try {
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            assignmentDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            assignmentDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            assignmentDetails.put( CourseAPIConstants.COURSE_ID, courseId );
            HashMap<String, String> assignCourseToTheStudent = assignmentObg.assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
            if ( assignCourseToTheStudent.get( Constants.STATUS_CODE ).equals( statusCode ) ) {
                Log.message( "Course has been assigned to the student!" );
            } else {
                Log.message( "Something went wrong while assigning the course to the student! - " + assignCourseToTheStudent.get( Constants.REPORT_BODY ) );
            }
        } catch ( Exception e ) {
            Log.message( "Issue occured in addAssignmentsToStudents" );
        }
    }

    /**
     * Verifying the success message
     * 
     * @param actualResponse
     * @param message
     * @return boolean
     * @throws IOException
     */
    public boolean verifySuccessStatus( String actualResponse, String status ) throws IOException {

        boolean flag = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( status ) ) {
            Log.message( "status Verified successfully!" );
            flag = true;
        } else {
            Log.message( "Issue in displaying status!" );
        }
        return flag;
    }

    /**
     * Verifying the Exception information
     * 
     * @param actualResponse
     * @param exception
     * @return boolean
     * @throws IOException
     */
    public boolean verifyExceptionMessage( String actualResponse, String exception ) throws IOException {

        boolean flag = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.message( "Exception Verified successfully!" );
            flag = true;
        } else {
            Log.message( "Issue in displaying exception!" );
        }
        return flag;
    }

    /**
     * Get response for the Create Course By Setting API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySetting( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySetting= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "READING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsReadingPayload" ) ) );

            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsMathPayload" ) ) );
            }

            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySetting method" );
            return null;
        }
    }

}