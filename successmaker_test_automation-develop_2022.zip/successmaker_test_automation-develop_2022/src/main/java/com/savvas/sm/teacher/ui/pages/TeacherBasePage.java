package com.savvas.sm.teacher.ui.pages;

// Keep any common methods which can be used across pages here.
public class TeacherBasePage {

}
