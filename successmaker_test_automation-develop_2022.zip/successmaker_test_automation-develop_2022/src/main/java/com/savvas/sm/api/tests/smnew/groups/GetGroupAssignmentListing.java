package com.savvas.sm.api.tests.smnew.groups;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.FileNameConstatnts;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.GetGroupListAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

public class GetGroupAssignmentListing extends CourseAPI {
    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String secondTeacher = null;
    private String studentUserId = null;

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String classId = null;
    String className = null;

    // Teacher variable used for this class
    private String orgUsed = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String readingOrgUsed = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String teacherUsed;
    private String orgId;
    private String teacherId;
    private String username;

    // other school constants
    private String readingSchoolId;
    private String readingSchoolTeacherId;
    private String readingSchoolTeacher;
    private String readingSchoolTeacherUsername;

    // Second Teacher
    private String teacher2;
    private String secondTeacherId;
    private String secondTeacherUsername;

    // API parameter  
    public List<String> courseIdsToVerify = new ArrayList<String>();
    public List<String> courseNamesToVerify = new ArrayList<String>();
    List<String> schools = new ArrayList<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    HashMap<String, String> deleteDetails = new HashMap<>();
    HashMap<String, String> changeStatusDetails = new HashMap<>();
    List<String> studentRumbaIds = new ArrayList<>();
    HashMap<String, String> apiDetails = new HashMap<>();
    HashMap<String, String> groupDetails = new HashMap<>();
    public List<String> StudentIdsToTest = new ArrayList<>();
    public String teacherUsernameToTest = null;
    public String teacherIdToTest = null;
    public String orgIdToTest = null;
    public String accessToken = null;
    String studentName1;
    String studentIds1;
    String studentName2;
    String studentIds2;

    String studentId;
    String secondStudentId;
    String thirdStudentId;
    String multiSchoolTeacher;
    String CourseId;
    String studentUsername;
    String secondStudentUsername;
    String studentUsed;
    String student2;
    RBSUtils rbs = new RBSUtils();
    String org2Id;
    GroupAPI groupApi;
    private List<String> courseIDs = new ArrayList<>();
    HashMap<String, String> assignmentResponse = new HashMap<>();
    private String studentId1;
    private String studentId2;
    private String studentId3;

    @BeforeTest ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        // Teacher used Details 
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        teacherUsed = RBSDataSetup.getMyTeacher( orgUsed );
        teacherId = SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERID );
        username = SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME );

        // Student Username 
        studentUsed = RBSDataSetup.getMyStudent( orgUsed, username );
        studentId1 = SMUtils.getKeyValueFromResponse( studentUsed, RBSDataSetupConstants.USERID );
        studentUsername = SMUtils.getKeyValueFromResponse( studentUsed, RBSDataSetupConstants.USERNAME );

        // Second Student for Data Setup purposes 
        student2 = RBSDataSetup.getMyStudent( orgUsed, username );
        studentId2 = SMUtils.getKeyValueFromResponse( student2, RBSDataSetupConstants.USERID );
        secondStudentUsername = SMUtils.getKeyValueFromResponse( student2, RBSDataSetupConstants.USERNAME );

        // Second Teacher for Data Setup purposes 
        teacher2 = RBSDataSetup.getMyTeacher( orgUsed );
        secondTeacherId = SMUtils.getKeyValueFromResponse( teacher2, RBSDataSetupConstants.USERID );
        secondTeacherUsername = SMUtils.getKeyValueFromResponse( teacher2, RBSDataSetupConstants.USERNAME );

        // Other School Details 
        readingSchoolId = RBSDataSetup.organizationIDs.get( readingOrgUsed );
        readingSchoolTeacher = RBSDataSetup.getMyTeacher( readingOrgUsed );
        readingSchoolTeacherId = SMUtils.getKeyValueFromResponse( readingSchoolTeacher, RBSDataSetupConstants.USERID );
        readingSchoolTeacherUsername = SMUtils.getKeyValueFromResponse( readingSchoolTeacher, RBSDataSetupConstants.USERNAME );

        // Student Creation
        studentName1 = "student" + System.nanoTime();
        studentIds1 = new UserAPI().createStudentAndResetPassword( orgId, studentName1 );
        studentName2 = "student" + System.nanoTime();
        studentIds2 = new UserAPI().createStudentAndResetPassword( orgId, studentName2 );
        studentRumbaIds.add( studentIds1 );
        studentRumbaIds.add( studentIds2 );

        groupApi = new GroupAPI();

    }

    @Test ( dataProvider = "PositiveScenariosData", groups = { "Smoke_tcGroupAssignmentListing001", "smoke_test_case", "SMK-57635", "Group", "GroupAssignmentListing", "P1", "API" } )
    public void tcGroupAssignmentListing001( String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( description );
        // Constants
        String studentName;
        String studentDetails;
        String studentIds;
        String endpoint = "null";

        String groupName = "Successmaker API Test Group " + System.nanoTime();
        HashMap<String, String> userDetails = new HashMap<>();
        //String token = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
        String assignmentName;
        switch ( scenario ) {
            case "GROUP WITHOUT STUDENT":
                String token = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                //Creating empty group
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                String groupId = groupApi.createEmptyGroup( groupName, teacherId, orgId, token );
                Log.message( groupId );
                new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );
                //assigning assignment to group
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_MATH_ID );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                //Listing assignments assigned to group
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                apiDetails.put( Constants.USERID_SM_HEADER, teacherId );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( GroupConstants.GROUP_ID, groupId );
                apiDetails.put( GetGroupListAPI.GROUP_PROGRESS_ASSIGNMENTS, "false" );

                break;
            case "VALID":
                String token1 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token1 );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                HashMap<String, String> response = groupApi.createGroup( smUrl, groupDetails, studentRumbaIds );
                groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_READING_ID );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignmentResponse.toString() );
                assignmentName = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentName" );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token1 );
                apiDetails.put( Constants.USERID_SM_HEADER, teacherId );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( GroupConstants.GROUP_ID, groupId );
                apiDetails.put( GetGroupListAPI.GROUP_PROGRESS_ASSIGNMENTS, "false" );
                //For Verification 
                courseIdsToVerify.add( Constants.DEFAULT_READING_ID );
                Log.message( courseIdsToVerify.toString() );
                courseNamesToVerify.add( assignmentName );
                Log.message( courseNamesToVerify.toString() );

                break;

            case "NO ASSIGNMENT":
                String token2 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token2 );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = groupApi.createGroup( smUrl, groupDetails, studentRumbaIds );
                groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token2 );
                apiDetails.put( Constants.USERID_SM_HEADER, teacherId );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( GroupConstants.GROUP_ID, groupId );
                apiDetails.put( GetGroupListAPI.GROUP_PROGRESS_ASSIGNMENTS, "false" );
                break;

            case "MULTPLE ASSIGNMENTS":
                Log.testCaseInfo( "Verify the assignment details when the default math course is assigned to group" );
                Log.testCaseInfo( "Verify the assignment details when the default reading course is assigned to group" );
                Log.testCaseInfo( "Verify the assignment details when the custom by setting course is assigned." );
                Log.testCaseInfo( "Verify the assignment details when the custom by skills course is assigned." );
                Log.testCaseInfo( "Verify the assignment details when the custom by standard course is assigned." );
                Log.testCaseInfo( "Verify the assignment details when the math focus course is assigned." );
                Log.testCaseInfo( "Verify the assignment details when the reading focus course is assigned." );
                String token3 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token3 );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = groupApi.createGroup( smUrl, groupDetails, studentRumbaIds );
                groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

                //Assigning focus course to group
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );

                // Creating custom by setting courses and assigning to group
                String mathcustombysetting = new CourseAPI().createCourse( smUrl, token3, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, mathcustombysetting );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                String readingcustombysetting = new CourseAPI().createCourse( smUrl, token3, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS,
                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, readingcustombysetting );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );

                // Creating custom by skill courses and assigning to group
                String mathcustombyskill = new CourseAPI().createCourse( smUrl, token3, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL,
                        String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, mathcustombyskill );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                String readingcustombyskill = new CourseAPI().createCourse( smUrl, token3, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, readingcustombyskill );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );

                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token3 );
                apiDetails.put( Constants.USERID_SM_HEADER, teacherId );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( GroupConstants.GROUP_ID, groupId );
                apiDetails.put( GetGroupListAPI.GROUP_PROGRESS_ASSIGNMENTS, "false" );
                break;

            case "PAUSED ASSIGNMENT":
                String token4 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token4 );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = groupApi.createGroup( smUrl, groupDetails, studentRumbaIds );
                groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_READING_ID );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );

                //Pausing assignment
                changeStatusDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                changeStatusDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                changeStatusDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                changeStatusDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_READING_ID );
                changeStatusDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                changeStatusDetails.put( AssignmentAPIConstants.GROUP_ID, groupId );
                HashMap<String, String> responseChange = new AssignmentAPI().changeGroupAssignmentStatus( smUrl, changeStatusDetails, changeStatusDetails.get( AssignmentAPIConstants.STATUS ), endpoint );

                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token4 );
                apiDetails.put( Constants.USERID_SM_HEADER, teacherId );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( GroupConstants.GROUP_ID, groupId );
                apiDetails.put( GetGroupListAPI.GROUP_PROGRESS_ASSIGNMENTS, "false" );
                break;

            case "REMOVED ASSIGNMENT":
                String token5 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token5 );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = groupApi.createGroup( smUrl, groupDetails, studentRumbaIds );
                groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_READING_ID );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );

                //deleting group assignment
                deleteDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                deleteDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                deleteDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                deleteDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_READING_ID );
                deleteDetails.put( AssignmentAPIConstants.GROUP_ID, groupId );
                new AssignmentAPI().deleteAssignmentfromGroup( smUrl, deleteDetails, endpoint );

                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token5 );
                apiDetails.put( Constants.USERID_SM_HEADER, teacherId );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( GroupConstants.GROUP_ID, groupId );
                apiDetails.put( GetGroupListAPI.GROUP_PROGRESS_ASSIGNMENTS, "false" );
                break;

            case "PROGRESS ASSIGNMENT TRUE":
                String token6 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token6 );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = groupApi.createGroup( smUrl, groupDetails, studentRumbaIds );
                groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );
                changeStatusDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                changeStatusDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                changeStatusDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token6 );
                changeStatusDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_MATH_ID );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, changeStatusDetails, Arrays.asList( studentIds1, studentIds2 ), AssignmentAPIConstants.USERS_TYPE );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_READING_ID );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignmentResponse.toString() );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token6 );
                apiDetails.put( Constants.USERID_SM_HEADER, teacherId );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( GroupConstants.GROUP_ID, groupId );
                apiDetails.put( GetGroupListAPI.GROUP_PROGRESS_ASSIGNMENTS, "true" );
                break;

            case "MULTIPLE SCHOOL TEACHER":
                String token7 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                //create multiple school teacher
                String multiSchoolTeachersm = "MultiSchTeacher" + System.nanoTime();

                userDetails = new HashMap<>();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeachersm );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

                schools = new ArrayList<String>();
                schools.add( orgId );
                schools.add( readingSchoolId );
                String listString = "";
                for ( String school : schools ) {
                    listString += school.concat( "\",\"" );
                }
                listString = listString.substring( 0, listString.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
                String multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

                studentName1 = "student" + System.nanoTime();
                studentIds1 = new UserAPI().createStudentAndResetPassword( orgId, studentName1 );
                studentRumbaIds.add( studentIds1 );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeachersm, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = groupApi.createGroup( smUrl, groupDetails, studentRumbaIds );
                String MultiOrgGroup = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                new RBSUtils().addProduct( MultiOrgGroup, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, multipleSchoolTeacherID );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeachersm, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_READING_ID );

                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( MultiOrgGroup ), AssignmentAPIConstants.GROUPS_TYPE );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeachersm, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.USERID_SM_HEADER, multipleSchoolTeacherID );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( GroupConstants.GROUP_ID, MultiOrgGroup );
                apiDetails.put( GetGroupListAPI.GROUP_PROGRESS_ASSIGNMENTS, "false" );
                break;

            case "SHARED CLASS":
                Log.testCaseInfo( "Verify Status Code 200 with assignments id when teacher assign any shared course from other teacher" );
                String token8 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                // Student Creation 
                studentName = "student" + System.nanoTime();
                studentDetails = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                studentIds = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
                StudentIdsToTest.clear();
                StudentIdsToTest.add( studentIds );

                // Teacher create 
                String firstTeacherUsername = "teacher" + System.nanoTime();
                String firstTeacherId = new UserAPI().createTeacherAndResetPassword( orgId, firstTeacherUsername );
                orgIdToTest = orgId;

                // Teacher create 
                String secondTeacherUsername = "teacher" + System.nanoTime();
                String secondTeacherId = new UserAPI().createTeacherAndResetPassword( orgId, secondTeacherUsername );

                String className = "class with multiple Teacher" + System.nanoTime();
                groupId = new RBSUtils().createClassWithMultipleTeacher( className, Arrays.asList( firstTeacherId, secondTeacherId ), Arrays.asList( studentIds ), orgId, token8 );
                new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, firstTeacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( firstTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_READING_ID );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( firstTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.USERID_SM_HEADER, firstTeacherId );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( GroupConstants.GROUP_ID, groupId );
                apiDetails.put( GetGroupListAPI.GROUP_PROGRESS_ASSIGNMENTS, "false" );
                break;
        }
        if ( ( scenario.equals( "REMOVED ASSIGNMENT" ) ) || ( scenario.equals( "NO ASSIGNMENT" ) ) ) {
            HashMap<String, String> response = getCourseList( smUrl, apiDetails );
            Log.message( "response" + response );
            VerifyResponseCode( response, CommonAPIConstants.STATUS_CODE_OK );
            VerifyResponseMessage( response, "Assignment Details Not found" );
            Log.testCaseResult();
        } else {
            HashMap<String, String> response = getCourseList( smUrl, apiDetails );
            Log.message( "response" + response );
            VerifyResponseCode( response, CommonAPIConstants.STATUS_CODE_OK );
            VerifyResponseMessage( response, "Operation succeeded!" );
            VerifySchema( CommonAPIConstants.STATUS_CODE_OK, response );
            Log.testCaseResult();
        }

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */

    @DataProvider ( name = "PositiveScenariosData" )
    public Object[][] PositiveScenariosData() {

        Object[][] inputData = { { "Verify the 200 response code and response body for valid data.", "VALID", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the response for a group that doesn't have any student", "GROUP WITHOUT STUDENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the response for a group that doesn't have any assignments", "NO ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the status code as 200 for valid data with a group of multiple student with multiple assignments To Get Assignments By Group Id API", "MULTPLE ASSIGNMENTS", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the response when the assignment is paused for a group", "PAUSED ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify Status Code 200 and Success - Failure the assignment details when the course assignment is removed", "REMOVED ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify that if  if groupProgressAssignments are true, it fetch all students assignments even if they are not assigned at group level", "PROGRESS ASSIGNMENT TRUE", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the  response, when teacher is part of multiple school.", "MULTIPLE SCHOOL TEACHER", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify Status Code 200 with assignments id, when assignment comes from shared student added to current teacher group ", "SHARED CLASS", CommonAPIConstants.STATUS_CODE_OK }

        };
        return inputData;

    }

    /**
     * To test the negative scenarios of Group Course Listing API
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( dataProvider = "NegativeScenariosData", groups = { "SMK-57635", "Group", "GroupAssignmentListing", "P1", "API" } )
    public void tcGroupAssignmentListing002( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );
        HashMap<String, String> apiDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        String groupName = "Successmaker API Test Group " + System.nanoTime();
        String exception = null;
        boolean status = false;
        String message = null;
        String token = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
        switch ( scenario ) {

            case "STUDENT AUTHORIZATION":
                studentName1 = "student" + System.nanoTime();
                studentIds1 = new UserAPI().createStudentAndResetPassword( orgId, studentName1 );
                studentName2 = "student" + System.nanoTime();
                studentIds2 = new UserAPI().createStudentAndResetPassword( orgId, studentName2 );
                studentRumbaIds.add( studentIds1 );
                studentRumbaIds.add( studentIds2 );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                HashMap<String, String> response = groupApi.createGroup( smUrl, groupDetails, studentRumbaIds );
                String groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_READING_ID );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( studentName1, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.USERID_SM_HEADER, studentIds1 );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( GroupConstants.GROUP_ID, groupId );
                apiDetails.put( GetGroupListAPI.GROUP_PROGRESS_ASSIGNMENTS, "false" );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;

                break;

            case "INVALID TOKEN":
                studentName1 = "student" + System.nanoTime();
                studentIds1 = new UserAPI().createStudentAndResetPassword( orgId, studentName1 );
                studentName2 = "student" + System.nanoTime();
                studentIds2 = new UserAPI().createStudentAndResetPassword( orgId, studentName2 );
                studentRumbaIds.add( studentIds1 );
                studentRumbaIds.add( studentIds2 );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = groupApi.createGroup( smUrl, groupDetails, studentRumbaIds );
                groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_READING_ID );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                apiDetails.put( Constants.USERID_SM_HEADER, teacherId );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( GroupConstants.GROUP_ID, groupId );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                break;

            case "OTHER TEACHER GROUP":
                studentName1 = "student" + System.nanoTime();
                studentIds1 = new UserAPI().createStudentAndResetPassword( orgId, studentName1 );
                studentName2 = "student" + System.nanoTime();
                studentIds2 = new UserAPI().createStudentAndResetPassword( orgId, studentName2 );
                studentRumbaIds.add( studentIds1 );
                studentRumbaIds.add( studentIds2 );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                response = groupApi.createGroup( smUrl, groupDetails, studentRumbaIds );
                groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );
                new RBSUtils().addProduct( groupId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, Constants.DEFAULT_READING_ID );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                apiDetails.put( Constants.USERID_SM_HEADER, secondTeacherId );
                apiDetails.put( Constants.ORGID_SM_HEADER, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( secondTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( GroupConstants.GROUP_ID, groupId );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = CommonAPIConstants.INVALID_GROUPID_EXP + groupId;
                break;

        }

        HashMap<String, String> response = getCourseList( smUrl, apiDetails );
        Log.message( "response" + response );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + response.get( Constants.REPORT_BODY ) );
        verifyException( response.get( Constants.REPORT_BODY ), exception, status, message );
        Log.testCaseResult();
    }

    /**
     * Data provider to give the data of negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "NegativeScenariosData" )
    public Object[][] NegativeScenariosData() {

        Object[][] inputData = { { "Verify the response should return exception when the authorization is student authorization.", "STUDENT AUTHORIZATION", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the response should return exception when the authorization is wrong", "INVALID TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the response when the groupId which is not part of the teacher or organization is passed", "OTHER TEACHER GROUP", CommonAPIConstants.STATUS_CODE_BAD_REQUEST }

        };
        return inputData;
    }

    /**
     * Verifies the response code
     * 
     * @param response
     * @param expectedCode
     */
    public void VerifyResponseCode( HashMap<String, String> response, String expectedCode ) {
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( expectedCode ), "Response status code is as expected - " + expectedCode,
                "Response status code is not as expected - Actual " + response.get( Constants.STATUS_CODE ) + " Expected " + expectedCode );
    }

    /**
     * Verifies the response message
     * 
     * @param response
     * @param expectedMessage
     */
    public void VerifyResponseMessage( HashMap<String, String> response, String expectedMessage ) {
        if ( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( expectedMessage ) ) {
            Log.pass( "Message Verified successfully!" );
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + expectedMessage + " Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ) );
        }

    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) {
        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception! Expected - " + exception + "Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ) );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    /**
     * It will verify the schema
     * 
     * @param StatusCode
     * 
     * @param response
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = new SMAPIProcessor().isSchemaValid( FileNameConstatnts.GET_COURSE_LIST_FOR_GROUP_ID_SCHEMA, StatusCode, response.get( Constants.REPORT_BODY ) );
            Log.assertThat( isValid, "The schema is valid", "The schema is not valid" );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
    }

    /**
     * Verifying API values
     * 
     * @param response
     */
    public void VerifyValues( HashMap<String, String> response ) {

        // Actual Values
        String actualStatusCode = response.get( Constants.STATUS_CODE );
        String actualBody = response.get( Constants.REPORT_BODY );
        JSONObject responseBody = new JSONObject( actualBody );

        List<String> courseId = new SMAPIProcessor().getKeyValues( responseBody, Constants.ID );
        Log.message( courseId.toString() );
        List<String> courseNames = new SMAPIProcessor().getKeyValues( responseBody, Constants.REPORT_NAME );
        Log.message( courseNames.toString() );
        Log.assertThat( new SMUtils().compareTwoList( courseId, courseIdsToVerify ), "The Course Id is matching!", "The Course Id is not matching!" );
        Log.assertThat( new SMUtils().compareTwoList( courseNames, courseNamesToVerify ), "The Course Name is matching!", "The Course Name is not matching!" );

    }

}
