package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Assignments;
import com.savvas.sm.common.utils.Constants.Students;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import LSTFAI.customfactories.EventFiringWebDriver;


@Listeners ( EmailReport.class )
public class AssignmentListingPageTest extends BaseTest {
    
    String chromeBrowser = "Windows_10_Chrome_latest";
    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String browser;
    private String smUrl;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String schoolID;
    private String teacherId;
    private static String username = null;
    private static String password = null;   
    private String token = null;
    
    List<String> studentIDList = null;
    List<String> studentNames = null;
    List<String> studentIdList = null;

    @BeforeClass (alwaysRun = true)
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty("SMAppUrl");
        browser = configProperty.getProperty("BrowserPlatformToRun");
        String teacherDetails = RBSDataSetup.getMyTeacher(school);
        username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
        schoolID = RBSDataSetup.organizationIDs.get( school );
        
        // token creation
        token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(teacherDetails, "userName"),RBSDataSetupConstants.DEFAULT_PASSWORD);              
        
        //Getting all the student ID
        studentIDList = new ArrayList<>();
        for ( int studentCount = 1; studentCount <= Integer.parseInt(configProperty.getProperty("studentCount")) ; studentCount++ ) {
            String studentId = SMUtils.getKeyValueFromResponse(RBSDataSetup.getMyStudent(school, username), "userId" );
            studentIDList.add( studentId );  
        }
        
        // Addding student usenames
        studentNames = new ArrayList<>();
        for ( int studentCount = 1; studentCount <= Integer.parseInt(configProperty.getProperty("studentCount")) ; studentCount++ ) {
            String studentUN = SMUtils.getKeyValueFromResponse(RBSDataSetup.getMyStudent(school, username), "userName" );
            studentNames.add( studentUN );
        }        
        
    }

    @Test ( description = "Verify the Assignment Listing page - Zero state ", priority = 1, groups = { "SMK-39535", "AssignmentsListing Page", "Assignments" } )
    public void tcSMAssignmentListing_001( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
                    "Course widget is not diplayed");
            
            // Go to the assignment detail Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> AssignmentsName = assignmentsPage.getColumnAssignmentValues();
            for ( String assignmentName : AssignmentsName ) {
                AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentName );
                assignmentDetailsPage.deleteAssignment();
                SMUtils.nap(5);
            }
            SMUtils.logDescriptionTC( "SMK-10303:Verify Coursewares -> Assignment Table should be empty if there is no assignment present." );
            Log.assertThat( assignmentsPage.getZeroStateText().equals( Students.NO_DATA_YET ), "The zero State  is present!", "The zero State  is not present" );
            Log.assertThat( assignmentsPage.getZeroStateMessage().equals( Assignments.ZERO_MESSAGE ), "The Zero State message is matching!", "The Zero State message is not matching" );

            //  SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Assignment Listing page - Sorting ", priority = 2, groups = { "SMK-39535", "AssignmentsListing Page", "Assignments" } )
    public void tcSMAssignmentListing_002( ITestContext context ) throws Exception {
        Random random = new Random();
        List<String> assignmentUserIdList = new ArrayList<String>();
      
        //creating a 15 Cutsom Courses & assign to students
        for ( int assignmentCount = 1; assignmentCount <= 15; assignmentCount++ ) {
            String assignmentName = DataSetupConstants.SKILL_COURSE_NAME_MATH + System.nanoTime();
            String CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, schoolID, DataSetupConstants.SKILL, assignmentName );
            
        // Assigning a  random student into Assignment
         int count = random.nextInt( Integer.parseInt(configProperty.getProperty("studentCount")) );                            
         HashMap<String, String> assignmentDetails = new HashMap<>();
         HashMap<String, String> response = new HashMap<>();
         assignmentDetails.put( AssignmentAPIConstants.ORG_ID, schoolID );
         assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
         assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token);
         assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
         response = new AssignmentAPI().assignAssignment(smUrl, assignmentDetails, studentIDList, AssignmentAPIConstants.USERS_TYPE );   
         SMUtils.nap(10);
         assignmentUserIdList.add( new SqlHelperCourses().getAssignmentUserDetails( assignmentName ).get( Constants.ASSIGNMENT_USER_ID ) );
        }
        
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
                    "Course widget is not diplayed");
                      
            // Go to the  assignment detail Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            SMUtils.logDescriptionTC( "SMK-10302:Verify Coursewares -> Assignment Table Headers - Assignment Title, Date Assigned, Active Student, Paused Student, Fluency Files" );
            SMUtils.logDescriptionTC( "SMK-10315:Verify Page Header - Assignments" );
            assignmentsPage.VerifyAssignmentsPageHeaders();

            SMUtils.logDescriptionTC( "SMK-10305:Verify Sort By -> Assignment Name -> Ascending Miniumum 5 Assignments" );
            List<String> sortedList = assignmentsPage.getAllAssignmentNames();
            Collections.sort( sortedList );
            assignmentsPage.clickColumnnAndSort( Assignments.COLUMN_ASSIGNMENT_TITILE, Constants.ASCENDING );
            String actualColumnName = assignmentsPage.getColumnNameOfArrow();
            String actualArrow = assignmentsPage.getArrowStateOfColumn();
            List<String> actualList = assignmentsPage.getAllAssignmentNames();

            Log.assertThat( actualColumnName.equals( Assignments.COLUMN_ASSIGNMENT_TITILE ), "Assignment Name column mathcing!", "Assignment Name column is not mathcing" );
            Log.assertThat( actualArrow.equals( Constants.ASCENDING ), "Arrow is in Ascending!", "Arrow is not Ascending" );
            Log.assertThat( actualList.equals( sortedList ), "Sorting is in Ascending!", "Sorting is not in Ascending!" );

            SMUtils.logDescriptionTC( "SMK-10310:Verify Sort By -> Assignment Name -> Descending Miniumum 5 Assignments" );
            sortedList = assignmentsPage.getColumnDateAssignedValues();
            Collections.sort( sortedList );
            assignmentsPage.clickColumnnAndSort( Assignments.COLUMN_DATE_ASSIGNED, Constants.ASCENDING );
            actualColumnName = assignmentsPage.getColumnNameOfArrow();
            actualArrow = assignmentsPage.getArrowStateOfColumn();
            actualList = assignmentsPage.getColumnDateAssignedValues();

            Log.assertThat( actualColumnName.equals( Assignments.COLUMN_DATE_ASSIGNED ), "Date Assigned column mathcing!", "Date Assigned column is not mathcing" );
            Log.assertThat( actualArrow.equals( Constants.ASCENDING ), "Arrow is in Ascending!", "Arrow is not ascending" );
            Log.assertThat( actualList.equals( sortedList ), "Sorting is in Ascending!", "Sorting is not in Ascending!" );

            SMUtils.logDescriptionTC( "SMK-10306:Verify Sort By -> Date Assigned -> Ascending Minimum 5 Assignments different dates" );
            sortedList = assignmentsPage.getColumnDateAssignedValues();
            Collections.sort( sortedList );
            assignmentsPage.clickColumnnAndSort( Assignments.COLUMN_DATE_ASSIGNED, Constants.ASCENDING );

            actualList = assignmentsPage.getColumnDateAssignedValues();
            actualColumnName = assignmentsPage.getColumnNameOfArrow();
            actualArrow = assignmentsPage.getArrowStateOfColumn();
            Log.assertThat( actualColumnName.equals( Assignments.COLUMN_DATE_ASSIGNED ), "Date Assigned column mathcing!", "Date Assigned column is not mathcing" );
            Log.assertThat( actualArrow.equals( Constants.ASCENDING ), "Arrow is in Ascending!", "Arrow is not Descending" );
            Log.assertThat( actualList.equals( sortedList ), "Sorting is in Ascending!", "Sorting is not in Ascending!" );

            SMUtils.logDescriptionTC( "SMK-10311:Verify Sort By -> Date Assigned -> Descending Minimum 5 Assignments different dates" );
            sortedList = assignmentsPage.getColumnDateAssignedValues();
            Collections.sort( sortedList, Collections.reverseOrder() );
            assignmentsPage.clickColumnnAndSort( Assignments.COLUMN_DATE_ASSIGNED, Constants.DESCENDING );

            actualList = assignmentsPage.getColumnDateAssignedValues();
            actualColumnName = assignmentsPage.getColumnNameOfArrow();
            actualArrow = assignmentsPage.getArrowStateOfColumn();
            Log.assertThat( actualColumnName.equals( Assignments.COLUMN_DATE_ASSIGNED ), "Date Assigned column mathcing!", "Date Assigned column is not mathcing" );
            Log.assertThat( actualArrow.equals( Constants.DESCENDING ), "Arrow is in Descending!", "Arrow is not Descending" );
            Log.assertThat( actualList.equals( sortedList ), "Sorting is in Descending!", "Sorting is not in Descending!" );

            SMUtils.logDescriptionTC( "SMK-10307:Verify Sort By -> Active Students -> Ascending Miniumum 5 Assignments" );
            List<Integer> sortedListIntegers = assignmentsPage.getColumnActiveStudentsValues();
            Collections.sort( sortedListIntegers );
            assignmentsPage.clickColumnnAndSort( Assignments.COLUMN_ACTIVE_STUDENTS, Constants.ASCENDING );

            List<Integer> actualListIntegers = assignmentsPage.getColumnActiveStudentsValues();
            actualColumnName = assignmentsPage.getColumnNameOfArrow();
            actualArrow = assignmentsPage.getArrowStateOfColumn();
            Log.assertThat( actualColumnName.equals( Assignments.COLUMN_ACTIVE_STUDENTS ), "Active Students column mathcing!", "Active Students column is not mathcing" );
            Log.assertThat( actualArrow.equals( Constants.ASCENDING ), "Arrow is in Ascending!", "Arrow is not Ascending" );
            Log.assertThat( actualListIntegers.equals( sortedListIntegers ), "Sorting is in Ascending!", "Sorting is not in Ascending!" );

            SMUtils.logDescriptionTC( "SMK-10312:Verify Sort By -> Active Students -> Descending Miniumum 5 Assignments" );
            sortedListIntegers = assignmentsPage.getColumnActiveStudentsValues();
            Collections.sort( sortedListIntegers, Collections.reverseOrder() );
            assignmentsPage.clickColumnnAndSort( Assignments.COLUMN_ACTIVE_STUDENTS, Constants.DESCENDING );

            actualListIntegers = assignmentsPage.getColumnActiveStudentsValues();
            actualColumnName = assignmentsPage.getColumnNameOfArrow();
            actualArrow = assignmentsPage.getArrowStateOfColumn();
            Log.assertThat( actualColumnName.equals( Assignments.COLUMN_ACTIVE_STUDENTS ), "Active Students column mathcing!", "Active Students column is not mathcing" );
            Log.assertThat( actualArrow.equals( Constants.DESCENDING ), "Arrow is in Descending!", "Arrow is not Descending" );
            Log.assertThat( actualListIntegers.equals( sortedListIntegers ), "Sorting is in Descending!", "Sorting is not in Descending" );

            SMUtils.logDescriptionTC( "SMK-10313:Verify Sort By -> Paused Students -> Descending Miniumum 5 Assignments" );
            sortedListIntegers = assignmentsPage.getColumnPausedStudentsValues();
            Collections.sort( sortedListIntegers );
            assignmentsPage.clickColumnnAndSort( Assignments.COLUMN_PAUSED_STUDENTS, Constants.ASCENDING );

            actualListIntegers = assignmentsPage.getColumnPausedStudentsValues();
            actualColumnName = assignmentsPage.getColumnNameOfArrow();
            actualArrow = assignmentsPage.getArrowStateOfColumn();
            Log.assertThat( actualColumnName.equals( Assignments.COLUMN_PAUSED_STUDENTS ), "Pausesd Students column mathcing!", "Pausesd Students column is not mathcing" );
            Log.assertThat( actualArrow.equals( Constants.ASCENDING ), "Arrow is in Ascending!", "Arrow is not Ascending" );
            Log.assertThat( actualListIntegers.equals( sortedListIntegers ), "Sorting is in Ascending!", "Sorting is not in Ascending!" );

            SMUtils.logDescriptionTC( "SMK-10308:Verify Sort By -> Paused Students -> Ascending Miniumum 5 Assignments" );
            sortedListIntegers = assignmentsPage.getColumnPausedStudentsValues();
            Collections.sort( sortedListIntegers, Collections.reverseOrder() );
            assignmentsPage.clickColumnnAndSort( Assignments.COLUMN_PAUSED_STUDENTS, Constants.DESCENDING );

            actualListIntegers = assignmentsPage.getColumnPausedStudentsValues();
            actualColumnName = assignmentsPage.getColumnNameOfArrow();
            actualArrow = assignmentsPage.getArrowStateOfColumn();
            Log.assertThat( actualColumnName.equals( Assignments.COLUMN_PAUSED_STUDENTS ), "Pausesd Students column mathcing!", "Pausesd Students column is not mathcing" );
            Log.assertThat( actualArrow.equals( Constants.DESCENDING ), "Arrow is in Descending!", "Arrow is not Descending" );
            Log.assertThat( actualListIntegers.equals( sortedListIntegers ), "Sorting is in Descending!", "Sorting is not in Descending!" );

            SMUtils.logDescriptionTC( "SMK-39535:Verify Sort By -> Fluency Files -> Ascending Miniumum 5 Assignments" );
            sortedListIntegers = assignmentsPage.getColumnFluencyFilesValues();
            Collections.sort( sortedListIntegers );
            assignmentsPage.clickColumnnAndSort( Assignments.COLUMN_FLUENCY_FILES, Constants.ASCENDING );

            actualListIntegers = assignmentsPage.getColumnFluencyFilesValues();
            actualColumnName = assignmentsPage.getColumnNameOfArrow();
            actualArrow = assignmentsPage.getArrowStateOfColumn();
            Log.assertThat( actualColumnName.equals( Assignments.COLUMN_FLUENCY_FILES ), "Fluency Files column mathcing!", "Fluency Files column is not mathcing" );
            Log.assertThat( actualArrow.equals( Constants.ASCENDING ), "Arrow is in Ascending!", "Arrow is not Ascending" );
            Log.assertThat( actualListIntegers.equals( sortedListIntegers ), "Sorting is in Ascending!", "Sorting is not in Ascending!" );

            SMUtils.logDescriptionTC( "SMK-39535:Verify Sort By -> Fluency Files -> Descending Miniumum 5 Assignments" );
            sortedListIntegers = assignmentsPage.getColumnFluencyFilesValues();
            Collections.sort( sortedListIntegers, Collections.reverseOrder() );
            assignmentsPage.clickColumnnAndSort( Assignments.COLUMN_FLUENCY_FILES, Constants.DESCENDING );

            actualListIntegers = assignmentsPage.getColumnFluencyFilesValues();
            actualColumnName = assignmentsPage.getColumnNameOfArrow();
            actualArrow = assignmentsPage.getArrowStateOfColumn();
            Log.assertThat( actualColumnName.equals( Assignments.COLUMN_FLUENCY_FILES ), "Fluency Files column mathcing!", "Fluency Files column is not mathcing" );
            Log.assertThat( actualArrow.equals( Constants.DESCENDING ), "Arrow is in Descending!", "Arrow is not Descending" );
            Log.assertThat( actualListIntegers.equals( sortedListIntegers ), "Sorting is in Descending!", "Sorting is not in Descending!" );

            //  SignOut from SM
            tHomePage.topNavBar.signOutfromSM();           
            Log.testCaseResult();
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Assignment Listing page - Fluency Files ", priority = 3, groups = { "SMK-39535", "AssignmentsListing Page", "Assignments" } )
    public void tcSMAssignmentListing_003( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
                    "Course widget is not diplayed");

            // create a course and adding into the half of the students
            CoursesPage coursePage = tHomePage.navigateToCourseListingPage();
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            String customCourse = "Custom Math" + System.nanoTime();
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            coursePage.copyOfCourse( customCourse, Constants.STANDARDS, Constants.MATH );
            tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( customCourse );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();
            SMUtils.nap( 10 );
            
            String assignmentId = new SqlHelperCourses().getAssignmentIDUsingName( customCourse );
            String assignmentuserId= new SqlHelperCourses().getAssignmentUserId( studentIDList.get( 0 ), assignmentId );
            new SqlHelperCourses().createFluencyFiles( 5, Integer.parseInt( assignmentuserId ) );
            SMUtils.nap( 10 );
            
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            SMUtils.nap( 10 );
            
            SMUtils.logDescriptionTC( "SMK-10323:Verify that fluency files count is pulled from all students of the assignment - both from assigned and group students" );
            String fluencyfilesCount = assignmentsPage.getValueForAssignment( customCourse, Assignments.COLUMN_FLUENCY_FILES );
            Log.assertThat( Integer.parseInt( fluencyfilesCount ) > 0, "Fluency Files present!", "Fluency Files is not present!" );

            SMUtils.logDescriptionTC( "SMK-10325:Verify that fluency files count is pulled even If students are paused" );
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( customCourse );
            assignmentDetailsPage.pauseAssignmentForAllStudents();
            tHomePage.topNavBar.navigateToAssignmentsPage();
            fluencyfilesCount = assignmentsPage.getValueForAssignment( customCourse, Assignments.COLUMN_FLUENCY_FILES );
            Log.assertThat( Integer.parseInt( fluencyfilesCount ) > 0, "Fluency Files present! for Paused Students!", "Fluency Files is not present!" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Page Header Menu - Home , Students, Courseware (Active - Blue), Mastery, Reports", groups = { "SMK-39535", "AssignmentsListing Page", "Assignments" }, priority = 4 )
    public void tcSMAssignmentListing_004( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMAssignmentListing_004:Verify Page Header Menu - Home , Students, Courseware (Active - Blue), Mastery, Reports <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
                    "Course widget is not diplayed");
          
            // Go to the  assignment detail Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            Log.assertThat( tHomePage.topNavBar.isHomeTabDisplayed(), "Home Tab Displayed", "Home Tab not Displayed" );
            Log.assertThat( tHomePage.topNavBar.isStudentsTabDisplayed(), "Students Tab Displayed", "Students Tab not Displayed" );
            Log.assertThat( tHomePage.topNavBar.isCoursewareDisplayed(), "Courseware Tab Displayed", "Courseware Tab not Displayed" );
            Log.assertThat( tHomePage.topNavBar.isCoursewareActive(), "Courseware Tab Active and Blue color", "Courseware Tab not Active or no Blue color" );
            Log.assertThat( tHomePage.topNavBar.isMasteryTabDisplayed(), "Mastery Tab Displayed", "Mastery Tab not Displayed" );
            Log.assertThat( tHomePage.topNavBar.isReportsTabDisplayed(), "Reports Tab Displayed", "Reports Tab not Displayed" );

            SMUtils.logDescriptionTC( "SMK-39535:Verify Page Header Menu - Courseware (Active - Blue) Should be highligted even if page is refreshed" );
            
            // Refresh Page
            assignmentsPage.refreshPage();
            Log.assertThat( tHomePage.topNavBar.isCoursewareActive(), "Courseware Tab Active and highlighted with Blue color", "Courseware Tab not Active or not highlighted with Blue color" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Page Header Menu - Courseware (Active - Blue) Should be highligted even if page is refreshed", groups = { "SMK-39535", "AssignmentsListing Page", "Assignments" }, priority = 5 )
    public void tcSMAssignmentListing_005( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMAssignmentListing_005:Verify Page Header Menu - Courseware (Active - Blue) Should be highligted even if page is refreshed <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
                    "Course widget is not diplayed");
            
            // Go to the  assignment detail Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            SMUtils.logDescriptionTC( "SMK-39535:Verify Page Header Menu - Courseware (Active - Blue) Should be highligted even if page is refreshed" );
            //Refresh Page
            assignmentsPage.refreshPage();
            Log.assertThat( tHomePage.topNavBar.isCoursewareActive(), "Courseware Tab Active and highlighted with Blue color", "Courseware Tab not Active or not highlighted with Blue color" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
  
}
