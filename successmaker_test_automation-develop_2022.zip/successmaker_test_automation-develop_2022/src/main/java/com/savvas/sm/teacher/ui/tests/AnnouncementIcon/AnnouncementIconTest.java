/**
 * Annoucement Icon Test Cases
 *
 * @author Sudarshan.Govindarajan
 */

package com.savvas.sm.teacher.ui.tests.AnnouncementIcon;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class AnnouncementIconTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher13" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( description = "Verify the announcement Icon is present in the top right of SM application page", priority = 1 )
    public void tcSMAnnouncementIcon001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMMAnnouncementIcon001: Verify the announcement Icon is present in the top right of SM application page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            Log.assertThat( tHomePage.topNavBar.isAnnouncementDisplayed(), "Announcement Icon is displayed", "Announcement Icon is not displayed" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the announcement Icon is clickable which is present in the top right of SM application page", priority = 2 )
    public void tcSMAnnouncementIcon002() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


        Log.testCaseInfo( "tcSMMAnnouncementIcon002 : Verify the announcement Icon is clickable which is present in the top right of SM application page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            WebElement announcementIconShadowElement = SMUtils.getWebElement( driver, tHomePage.topNavBar.getTopNavBarwithShadow(), tHomePage.topNavBar.getAnnouncementIconShadowCSS() );
            WebElement announcementIcon = SMUtils.getWebElement( driver, announcementIconShadowElement, tHomePage.topNavBar.getAnnouncementIconCSS() );
            Log.assertThat( SMUtils.verifyCssPropertyForElement( announcementIcon, "cursor", "pointer" ), "Announcement Icon is clickable", "Announcement Icon is not clickable" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user is navigated to the new tab when user click on announcement Icon ", priority = 3 )
    public void tcSMAnnouncementIcon003() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAnnouncementIcon003: Verify the user is navigated to the new tab when user click on announcement Icon  <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            WebElement announcementIconShadowElement = SMUtils.getWebElement( driver, tHomePage.topNavBar.getTopNavBarwithShadow(), tHomePage.topNavBar.getAnnouncementIconShadowCSS() );
            WebElement announcementIcon = SMUtils.getWebElement( driver, announcementIconShadowElement, tHomePage.topNavBar.getAnnouncementIconCSS() );

            Set<String> tabs_beforeannoucementiconclick = driver.getWindowHandles();
            SMUtils.clickJS( driver, announcementIcon );
            Set<String> tabs_AfterannouncementIconClick = driver.getWindowHandles();
            Log.assertThat( ( tabs_AfterannouncementIconClick.size() > tabs_beforeannoucementiconclick.size() ? true : false ), "New Windows is opened", "New Windows is not opened" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the SuccessMaker Announcements and Resources header is present in the new tab when user click on announcement Icon", priority = 4 )
    public void tcSMAnnoucementIcon004() throws Exception {

    	// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo( "tcSMAnnoucementIcon004 : Verify the SuccessMaker Announcements and Resources header is present in the new tab when user click on announcement Icon <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            tHomePage.topNavBar.navigateToAnnouncementPage();

            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, tHomePage.getHomePageHelpPageHeader(), 10 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( Constants.HelpPage_AnnoucementPageTitles.ANNOUNCEMENTICONPAGETITLE ), "SM help Announcements and Resources page is loaded in a new tab", "SM help Announcements and Resources page is not loaded in a new tab" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

}