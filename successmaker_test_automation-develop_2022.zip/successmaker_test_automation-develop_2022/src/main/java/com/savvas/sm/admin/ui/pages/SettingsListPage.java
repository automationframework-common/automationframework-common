package com.savvas.sm.admin.ui.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.Log;
import com.savvas.sm.utils.SMUtils;

public class SettingsListPage extends LoadableComponent<SettingsListPage> {

    private final WebDriver driver;
    boolean isPageLoaded;

    //*******************Success Maker Setting List page*******************//

    @FindBy ( className = "logo-image" )
    WebElement smLogo;

    @FindBy ( css = "ul.side-nav li" )
    List<WebElement> subNavList;

    @FindBy ( css = "span.side-nav-item" )
    List<WebElement> settingSubNav;

    @FindBy ( css = "span.main-container-heading-text" )
    WebElement headerlabel;

    @FindBy ( css = "span.text-overflow-nowrap" )
    List<WebElement> settingListOptions;

    @FindBy ( css = "cel-icon.contextual-help-icon" )
    WebElement helpIcon;

    //*********************Child elements****************************//

    public static String editparent = "cel-button.hydrated";
    public static String childEditbutton = ".secondary_button";

    //***************************All Common methods*******************************//

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public SettingsListPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, headerlabel );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, headerlabel, 10 ) ) {
            Log.message( "SM Setting list page loaded successfully." );
        } else {
            Log.fail( "SM Setting list page did not load." );
        }

    }

    /**
     * To verify page header text
     * 
     * @return
     */
    public String getPageHeaderText() {

        SMUtils.waitForElement( driver, headerlabel );
        Log.message( "Gettinng Setting header text" );
        return headerlabel.getText().trim();
    }

    /**
     * Return List of all field
     * 
     * @return
     */
    public List<String> getSettingListOption() {
        List<String> allOption = new ArrayList<String>();
        settingListOptions.forEach( element -> {
            allOption.add( element.getText().trim() );

        } );
        Log.message( "Getting all setting list options" );
        return allOption;
    }

    /**
     * Get edit button respect to Setting option
     * 
     * @param Option
     * @return
     */
    public String getEditButtn( String Option ) {
        SMUtils.waitForElement( driver, headerlabel );
        AtomicReference<String> value = new AtomicReference<String>();
        settingListOptions.forEach( element -> {
            if ( element.getText().trim().equalsIgnoreCase( Option ) ) {
                WebElement pElement = element.findElement( By.xpath( "./.." ) );
                WebElement parentElement = pElement.findElement( By.xpath( "./.." ) );
                WebElement editParentRoot = parentElement.findElement( By.cssSelector( editparent ) );
                //Get actual element
                value.set( SMUtils.getTextOfWebElement( editParentRoot, driver ) );
                Log.message( "Get Edit button for" + Option + "field" );
            }
        } );

        return value.get();
    }

    /**
     * Verify Question mark is displaying on setting list page
     * 
     * @return
     */
    public Boolean isQuestionIconDisplayed() {
        SMUtils.waitForElement( driver, helpIcon );
        Log.message( "Question mark is displaying" );
        return helpIcon.isDisplayed();
    }

}
