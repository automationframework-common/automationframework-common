package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentProgressGraphAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class SavePerformanceSetting extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String CourseId;
    private String assignmentID;
    private String assignmentUserId;
    RBSUtils rbsutils = new RBSUtils();
    Map<String, String> assignmentResponse = new HashMap<>();
    private String studentDetail;
    private String studentUserID;
    private String studentUsername;
    private String courseName;
    private String courseId;
    private String subject;
    Map<String, String> savePerformanceSettingresponse = new HashMap<>();
    Map<String, String> postmonitoringresponse = new HashMap<>();

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
    }

    @Test ( priority = 1, dataProvider = "SavePerformanceSettingPositiveFlow", groups = { "SMK-51714", "smoke_test_case", "SavePerformanceSettingAPI", "SavePerformanceSettingAPI", "P1", "API" } )
    public void tcPostiveforSavePerformanceSettingAPI( String description, String scenario, String statusCode, String date, String primarytarget, String secondarytarget ) throws Exception {

        Log.testCaseInfo( description );
        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        List<String> requestIds = new ArrayList<>();

        HashMap<String, String> groupdetails = new HashMap<>();
        String endpoint = "null";
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        studentRumbaIds.add( studentUserID );

        HashMap<String, String> response = new HashMap<>();
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        HashMap<String, String> group = new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );
        switch ( scenario ) {
            case "Default_Math":
                courseName = "Math";
                courseId = AssignmentAPIConstants.MATH;
                subject = DataSetupConstants.MATH;
                break;
            case "Default_Reading":
                courseName = "Reading";
                courseId = AssignmentAPIConstants.READING;
                subject = DataSetupConstants.READING;
                break;
            case "Math_Custom_Course_Settings":
                subject = DataSetupConstants.MATH;
                courseName = "CustomMathSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );
                break;
            case "Math_Custom_Course_Settings_WITHOUTIP":
                subject = DataSetupConstants.MATH;
                courseName = "CustomMathSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );
                break;
            case "Reading_Custom_Course_Settings":
                subject = DataSetupConstants.READING;
                courseName = "CustomReadingSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, courseName, "customBySettings_READING.json" );
                break;
            default:
                break;
        }
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( "assignmentResponse=" + assignmentResponse );
        assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
        Log.message( "assignmentUserId =" + assignmentUserId );
        if ( scenario.contains( "Math" ) && scenario.contains( "WITHOUTIP" ) ) {
            executeCourse( studentUsername, courseName, true, "100", "1", "1" );
        } else if ( scenario.contains( "Math" ) ) {
            executeCourse( studentUsername, courseName, true, "100", "5", "30" );
        } else {
            executeCourse( studentUsername, courseName, false, "100", "5", "30" );

        }
        HashMap<String, String> header = new HashMap();
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        header.put( Constants.AUTHORIZATION, "Bearer " + token );
        header.put( Constants.USERID_SM_HEADER, teacherId );
        header.put( Constants.ORGID_SM_HEADER, orgId );
        HashMap<String, String> pathparams = new HashMap();
        pathparams.put( Constants.TEACHER_ID, teacherId );
        pathparams.put( Constants.ORG_ID_VALUE, orgId );
        pathparams.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId );
        savePerformanceSettingresponse = postSavePerformanceSetting( smUrl, header, pathparams, date, primarytarget, secondarytarget, scenario );
        Log.message( "savePerformanceSettingresponse=" + savePerformanceSettingresponse );
        Log.softAssertThat( savePerformanceSettingresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + savePerformanceSettingresponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + savePerformanceSettingresponse.get( Constants.STATUS_CODE ) );
        postmonitoringresponse = postProgressMonitoringGraph( smUrl, header, pathparams, studentUserID, assignmentID, subject );
        Log.message( "postmonitoringresponse=" + postmonitoringresponse );
        verifyResponse( postmonitoringresponse.get( Constants.REPORT_BODY ), primarytarget, secondarytarget );
        Log.testCaseResult();
    }

    /**
     * Data provider to give the positive data
     *
     * @return
     */
    @DataProvider ( name = "SavePerformanceSettingPositiveFlow" )
    public Object[][] SavePerformanceSettingPositiveFlow() {

        Object[][] inputData = { { "Verify the valid response to Default Math", "Default_Math", CommonAPIConstants.STATUS_CODE_OK, "2022-04-30", "7.5", "8.0" },
                { "Verify the valid response to Default Reading", "Default_Reading", CommonAPIConstants.STATUS_CODE_OK, "2022-05-30", "7.2", "7.3" },
                { "Verify the valid response to Math Custom Course by Settings", "Math_Custom_Course_Settings", CommonAPIConstants.STATUS_CODE_OK, "2022-05-30", "8.1", "8.3" },
                { "Verify the valid response to Math Custom Course by Settings", "Math_Custom_Course_Settings_WITHOUTIP", CommonAPIConstants.STATUS_CODE_OK, "2022-05-30", "8.5", "8.6" },
                { "Verify the valid response to Reading Custom Course by Settings", "Reading_Custom_Course_Settings", CommonAPIConstants.STATUS_CODE_OK, "2022-05-30", "7.5", "3.0" }, };
        return inputData;
    }

    @Test ( priority = 1, dataProvider = "SavePerformanceSettingNegativeFlow", groups = { "SMK-51714", "SavePerformanceSettingAPI", "SavePerformanceSettingAPI", "P1", "API" } )
    public void tcNegativeforSavePerformanceSettingAPI( String description, String scenario, String statusCode, String date, String primarytarget, String secondarytarget ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        List<String> requestIds = new ArrayList<>();

        HashMap<String, String> groupdetails = new HashMap<>();
        String endpoint = "null";

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        studentRumbaIds.add( studentUserID );

        HashMap<String, String> response = new HashMap<>();
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        HashMap<String, String> group = new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );
        Log.message( "group id=" + group.toString() );
        subject = DataSetupConstants.MATH;
        courseName = "CustomMathSettingCourse" + System.nanoTime();
        courseId = createCustomCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( "assignmentResponse=" + assignmentResponse );
        assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
        Log.message( "assignmentUserId =" + assignmentUserId );
        executeCourse( studentUsername, courseName, true, "100", "5", "30" );
        HashMap<String, String> header = new HashMap();
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        header.put( Constants.AUTHORIZATION, "Bearer " + token );
        header.put( Constants.USERID_SM_HEADER, teacherId );
        header.put( Constants.ORGID_SM_HEADER, orgId );

        HashMap<String, String> pathparams = new HashMap();
        pathparams.put( Constants.TEACHER_ID, teacherId );
        pathparams.put( Constants.ORG_ID_VALUE, orgId );
        pathparams.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId );

        if ( scenario.contains( "INVALID_ORG" ) ) {
            pathparams.put( Constants.ORG_ID_VALUE, CourseAPIConstants.INVALID_ORGANIZATION_ID );
        }
        if ( scenario.contains( "INVALID_STAFF_ID" ) ) {
            pathparams.put( Constants.TEACHER_ID, CourseAPIConstants.INVALID_STAFF_ID_RANDOM );
        }
        if ( scenario.contains( "INVALID_ASSIGNMENT_USER_ID" ) ) {
            pathparams.put( Constants.ASSIGNMENT_USER_ID, StudentProgressGraphAPIConstants.INVALID_ASSIGNMENT_USER_ID );
        }
        if ( scenario.contains( "INVALID_DATATYPE_ASSIGNMENT_USER_ID" ) ) {
            pathparams.put( Constants.ASSIGNMENT_USER_ID, CourseAPIConstants.INVALID );
        }
        if ( scenario.contains( "INVALID_ORG_HEADER" ) ) {
            header.put( Constants.ORGID_SM_HEADER, CourseAPIConstants.INVALID_ORGANIZATION_ID );
        }
        if ( scenario.contains( "INVALID_STAFF_ID_HEADER" ) ) {
            header.put( Constants.USERID_SM_HEADER, CourseAPIConstants.INVALID_STAFF_ID_RANDOM );
        }
        savePerformanceSettingresponse = postSavePerformanceSetting( smUrl, header, pathparams, date, primarytarget, secondarytarget, scenario );
        Log.message( "savePerformanceSettingresponse=" + savePerformanceSettingresponse );
        Log.softAssertThat( savePerformanceSettingresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + savePerformanceSettingresponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + savePerformanceSettingresponse.get( Constants.STATUS_CODE ) );
        Log.testCaseResult();
    }

    @DataProvider ( name = "SavePerformanceSettingNegativeFlow" )
    public Object[][] SavePerformanceSettingNegativeFlow() {

        Object[][] inputData = { { "Verify the response for Invalid Organization", "INVALID_ORG", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "2022-04-30", "8.5", "4.0" },
                { "Verify the response for Invalid Staff id", "INVALID_STAFF_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "2022-04-30", "8.5", "4.0" },
                { "Verify the response for Invalid Assignment User id", "INVALID_ASSIGNMENT_USER_ID", CommonAPIConstants.STATUS_CODE_OK, "2022-04-30", "8.5", "4.0" },
                { "Verify the response for Invalid datatype for Assignment User id", "INVALID_DATATYPE_ASSIGNMENT_USER_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "2022-04-30", "8.5", "4.0" },
                { "Verify the response for Invalid Organization in header", "INVALID_ORG_HEADER", CommonAPIConstants.STATUS_CODE_FORBIDDAN, "2022-04-30", "8.5", "4.0" },
                { "Verify the response for Invalid Staff id in header", "INVALID_STAFF_ID_HEADER", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, "2022-04-30", "8.5", "4.0" },
                { "Verify the response for  Empty Target Date", "EMPTY_TARGET_DATE", CommonAPIConstants.STATUS_CODE_OK, "", "7.5", "7.8" },
                { "Verify the response for  Empty Primary Target", "EMPTY_PRIMARY_TARGET", CommonAPIConstants.STATUS_CODE_OK, "2022-04-30", "", "4.0" },
                { "Verify the response for  Empty Secondary Target", "EMPTY_SECONDARY_TARGET", CommonAPIConstants.STATUS_CODE_OK, "2022-04-30", "7.5", "" },
                { "Verify the response for Invalid Target Date", "INVALID_TARGET_DATE", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "20221-04-30", "7.5", "8.1" },
                { "Verify the response for Invalid Primary Target", "INVALID_PRIMARY_TARGET", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "2022-04-30", "PP", "8.1" },
                { "Verify the response for Invalid Secondary Target", "INVALID_SECONDARY_TARGET", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "2022-04-30", "7.5", "SS" },
                { "Verify the response for without Target Date in request", "WITHOUT_TARGET_DATE", CommonAPIConstants.STATUS_CODE_OK, "20221-04-30", "7.5", "8.1" },
                { "Verify the response for without Primary Target in request", "WITHOUT_PRIMARY_TARGET", CommonAPIConstants.STATUS_CODE_OK, "2022-04-30", "PP", "8.1" },
                { "Verify the response for without Secondary Target in request", "WITHOUT_SECONDARY_TARGET", CommonAPIConstants.STATUS_CODE_OK, "2022-04-30", "7.5", "SS" },

        };

        return inputData;
    }

    public Map<String, String> postSavePerformanceSetting( String smUrl, HashMap<String, String> header, HashMap<String, String> path, String date, String primarytarget, String secondarytarget, String scenario ) throws Exception {
        String endPoint = StudentProgressGraphAPIConstants.SAVE_PERFORMANCE_SETTING;
        endPoint = endPoint.replace( Constants.ORG_ID, path.get( Constants.ORG_ID_VALUE ) );
        endPoint = endPoint.replace( Constants.STAFF_ID, path.get( Constants.TEACHER_ID ) );
        endPoint = endPoint.replace( Constants.ASSIGNMENT_USER_ID_VALUE, path.get( Constants.ASSIGNMENT_USER_ID ) );
        Map<String, String> headers = new HashMap();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, header.get( Constants.AUTHORIZATION ) );
        headers.put( Constants.USERID_SM_HEADER, header.get( Constants.USERID_SM_HEADER ) );
        headers.put( Constants.ORGID_SM_HEADER, header.get( Constants.ORGID_SM_HEADER ) );
        String payload = "";
        if ( scenario.contains( "WITHOUT_TARGET_DATE" ) ) {
            payload = "{ \"primaryTargetLevel\": \"primarytarget\",  \"secondaryTargetLevel\": \"secondarytarget\"}";
            payload = payload.replace( "primarytarget", primarytarget ).replace( "secondarytarget", secondarytarget );

        } else if ( scenario.contains( "WITHOUT_PRIMARY_TARGET" ) ) {
            payload = "{ \"targetDate\": \"date\",  \"secondaryTargetLevel\": \"secondarytarget\"}";
            payload = payload.replace( "date", date ).replace( "secondarytarget", secondarytarget );

        } else if ( scenario.contains( "WITHOUT_SECONDARY_TARGET" ) ) {
            payload = "{ \"targetDate\": \"date\",  \"primaryTargetLevel\": \"primarytarget\"}";
            payload = payload.replace( "date", date ).replace( "primarytarget", primarytarget );

        } else {
            payload = "{ \"targetDate\": \"date\",  \"primaryTargetLevel\": \"primarytarget\",  \"secondaryTargetLevel\": \"secondarytarget\"}";
            payload = payload.replace( "date", date ).replace( "primarytarget", primarytarget ).replace( "secondarytarget", secondarytarget );

        }
        Log.message( payload );
        Log.message( smUrl + endPoint );
        return RestHttpClientUtil.PUT( smUrl, headers, new HashMap(), endPoint, payload );
    }

    public Map<String, String> postProgressMonitoringGraph( String smUrl, HashMap<String, String> header, HashMap<String, String> path, String studentID, String assignmentID, String subjectType ) throws Exception {
        String endPoint = StudentProgressGraphAPIConstants.PROGRESS_MONITORING_GRAPH;
        endPoint = endPoint.replace( Constants.ORG_ID, path.get( Constants.ORG_ID_VALUE ) );
        endPoint = endPoint.replace( Constants.STAFF_ID, path.get( Constants.TEACHER_ID ) );
        endPoint = endPoint.replace( Constants.ASSIGNMENT_USER_ID_VALUE, path.get( Constants.ASSIGNMENT_USER_ID ) );
        Map<String, String> headers = new HashMap();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, header.get( Constants.AUTHORIZATION ) );
        headers.put( Constants.USERID_SM_HEADER, header.get( Constants.USERID_SM_HEADER ) );
        headers.put( Constants.ORGID_SM_HEADER, header.get( Constants.ORGID_SM_HEADER ) );
        String subject = subjectType.equals( "Math" ) ? "1" : "2";
        String payload = "{ \"subjectId\": subjectID }";
        payload = payload.replace( "subjectID", subject );
        return RestHttpClientUtil.POST( smUrl, headers, new HashMap(), endPoint, payload );
    }

    public void verifyResponse( String actualResponse, String primarytarget, String secondarytarget ) {

        try {
            String performanceSettingsprimary = SMUtils.getKeyValueFromResponse( actualResponse, "data,performanceSettings" );
            String primarytargetresponse = SMUtils.getKeyValueFromResponse( performanceSettingsprimary, "primaryTargetLevel" );
            String secondarytargetresponse = SMUtils.getKeyValueFromResponse( performanceSettingsprimary, "secondaryTargetLevel" );
            Log.softAssertThat( primarytargetresponse.equalsIgnoreCase( primarytarget ), "Primary Target and Secondary Target Level code is returned as expected", "Primary Target and Secondary Target Level code is not returned as expected" );

        } catch ( Exception e ) {
            Log.message( "Error in verifyResponse method" );
        }

    }

    public void executeCourse( String studentUserName, String courseName, boolean isMath, String percentage, String numberOfSession, String loCount ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, LoginConstants.UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }
}