package com.savvas.sm.common.utils.apiconstants;

import java.util.ArrayList;
import java.util.Arrays;

public interface StudentsAPIConstants {

    public interface StudentDetailsForGivenTeacherConstants {
        public static String ROSTER_DELETE_STUDENT_FROM_SECTION = "/v2/sections/{sectionId}/students";
        public static String READING_LO_COMPLETE_ENDPOINT = "/lms/web/assignments/locomplete";
        public static String GET_STUDENTS_DETAILS_FOR_TEACHERID = "/lms/web/api/v1/staffs/{teacherId}/students";
        public static String UPDATE_READING_EXIT_DATA = "/lms/web/assignments/exitdata/reading/{assignmentUserIDValue}";
        public static String SAVE_ASSIGNMENT_FILES = "/lms/web/assignments/files/{assignmentUserIDValue}?scoId=smre_ip_00260_s1&audioSequence=undefined&learningObjectId=smre_ip_00260";
        public static String CLIENTLOGS_DATA="/lms/web/assignments/clientlog";
        public static String UPDATE_MATH_IPM="/lms/web/assignments/math/ipm/adjustment/{auId}";
        public static String SESSION_START_TIME = "/lms/web/assignments/sessionstart/{assignmentUserIDValue}";
        public static String RUMBA_ID_TEXT = "rumbaId";
        public static String ACCESS_TOKEN = "access_token";
        public static String user_id_TEXT = "user-id";
        public static String userId_TEXT = "userId";
        public static String STDUDENT_ID_TEXT = "studentId";
        public static String STATUS_CODE_STRING = "statusCode";
        public static String STATUS_CODE_200 = "200";

        // Teacher details having students having with out SM product
        public static String NON_SM_TEACHER_RUMBA_ID = "ffffffff61e1a10368a3fe00309aab19";
        public static String NON_SM_TEACHER_USERNAME = "nonsmteacher1";

        public static String CMS_ADMIN_USERNAME = "absavvasadmin";
        public static String CMS_ADMIN_PASSWORD = "password1";
        public static String ROSTER_SERVICE_URL = "roster_service_url";
        public static String ADD_STUDENT_SECTION_PAYLOAD = "addStudentintoSectionPayload";
        public static String DELETE_STUDENT_SECTION_PAYLOAD = "deleteStudentFromSectionPayload";
        public static String TEACHER_ID = "{teacherId}";
        public static String CLASS_ID = "{classId}";
        public static String SECTION_ID = "{sectionId}";
        public static String STUDENT_ID = "{studentId}";
        public static String GROUP_ID = "groupId";
        public static String GROUP_ID_DATAVALUE = "data,groupId";
        public static String USERNAME = "userName";

        public static String SUCCESS_STRING = "Success";
        public static String EXCEPTION = "exception";
        public static String STATUS_STRING = "status";
        public static String BODY_STRING = "body";
        public static String DISTRICT_STRING = "district_ID";
        public static String ADMIN_ID_STRING = "admin_id";
        public static String MESSAGE_STRING = "message";
        public static String ROSTER_SERVICE_URL_STRING = "roster_service_url";
        public static String GRADE_NAME = "gradeName";
        public static String STUDENT_ID_TEXT = "studentId";

        public static ArrayList<String> GRADE_NAMES_DROPDOWN = new ArrayList<String>(
                Arrays.asList( "Grade K", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12", "Not Specified" ) );

    }

    public interface StudentDetailsForStudentIdAPIConstants {
        public static String ENDPOINT = "/lms/web/api/v1/students/studentId";
        public static String STUDENT_ID = "studentId";
        public static String USER_ID = "user-id";
        public static String ORG_ID = "org-id";

        public static String FIRST_NAME = "firstName";
        public static String MIDDLE_NAME = "middleName";
        public static String LAST_NAME = "lastName";

        public static String USERNAME = "userName";
        public static String BIRTH_DAY = "birthday";
        public static String BIRTH_DATE = "birthDate";
        public static String PERSON_ID = "personId";
        public static String GENDER = "gender";
        public static String DEMOGRAPHICS = "demographics";
        public static String GRADE = "grade";
        public static String STUDENT_IDENTIFICATION_NO = "studentIdentificationNumber";
        public static String SIS_SOURCE_ID = "sisSourceId";
        public static String NOT_SPECIFIED = "NOT_SPECIFIED";
        public static String TITLE_MR = "Mr.";
        public static String GRADE_NAME_STRING = "gradeName";
        public static String STUDENT_COUNT = "studentCount";
        public static String STUDENT_COUNT_DATAVALUE = "data,studentCount";

        //   Demographic details

        public static String VIEW_GROUP_USERNAME = "username";
        public static String GRADE_ID = "gradeId";
        public static String ID_STUDENT = "id";
        public static String STUDENT_DISTRICT_ID = "studentDistrictId";

        //   Demographic details
        public static ArrayList<String> GRADE_VALUES = new ArrayList<String>(
                Arrays.asList( "Grade k", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12", "NOT_SPECIFIED" ) );
        public static ArrayList<String> GRADE_NAME = new ArrayList<String>( Arrays.asList( "K", "FIRST", "SECOND", "THIRD", "FOURTH", "FIFTH", "SIXTH", "SEVENTH", "EIGHT", "NINTH", "TENTH", "ELEVENTH", "TWELVETH", "NOT_SPECIFIED" ) );

        public static ArrayList<String> GRADE_CODES = new ArrayList<String>( Arrays.asList( "KG", "G01", "G02", "G03", "G04", "G05", "G06", "G07", "G08", "G09", "G10", "G11", "G12", "OTHER" ) );

        ArrayList<String> ETHNICITY_VALUES = new ArrayList<String>( Arrays.asList( "HISPANIC_OR_LATINO", "NON_HISPANIC_OR_LATINO", "NOT_SPECIFIED" ) );

        String GRADE_LEVEL = "gradeLevel";
        String GENDER_STRING = "gender";
        String BIRTHDATE = "birthDate";
        String SPECIDAL_SERVICES = "specialServices";
        String HAS_ECONOMIC_DISADVANTAGE = "hasEconomicDisadvantage";
        String HAS_DISABILITY = "hasDisability";
        String HAS_ENGLISH_PROFICIENCY = "hasEnglishProficiency";
        String IS_MIGRANT = "isMigrant";
        String ETHNICITY = "ethnicity";
        String SIS_SOURCEID = "sisSourceId";
        ArrayList<String> SPECIDAL_SERVICES_VALUES = new ArrayList<String>( Arrays.asList( "PLAN_504", "GIFTED_TALENTED", "IEP", "OTHER", "NO_SPECIAL_SERVICES", "NOT_SPECIFIED" ) );
        ArrayList<String> HAS_DISABILITY_VALUES = new ArrayList<String>( Arrays.asList( "YES", "NO", "NOT_SPECIFIED" ) );
        ArrayList<String> GENDER_VALUES = new ArrayList<String>( Arrays.asList( "MALE", "FEMALE", "UNSPECIFIED" ) );
        ArrayList<String> GENDER_VALUES_API = new ArrayList<String>( Arrays.asList( "MALE", "FEMALE", "NOT_SPECIFIED" ) );
        ArrayList<String> HAS_ECONOMIC_DISADVANTAGE_VALUES = new ArrayList<String>( Arrays.asList( "NOT_ECONOMICALLY_DISADVANTAGED", "ECONOMICALLY_DISADVANTAGED" ) );
        ArrayList<String> HAS_ENGLISH_PROFICIENCY_VALUES = new ArrayList<String>( Arrays.asList( "ENGLISH", "ENGLISH_LANGUAGE_LEARNER" ) );
        ArrayList<String> IS_MIGRANT_VALUES = new ArrayList<String>( Arrays.asList( "MIGRANT", "NON_MIGRANT" ) );
        ArrayList<String> TITLE_VALUES = new ArrayList<String>( Arrays.asList( "Dr.", "Miss.", "Ms.", "Mr.", "Mrs." ) );

    }

    public interface StudentProgressGraphAPIConstants {
        public static String STUDENT_VALUE = "S";
        public static String INVALID_STUDENT_ID = "45784hdsfd";
        public static String INVALID_ORG_ID = "45784hdsfd";
        public static String INVALID_SUB_TYPE_ID = "67we4";
        public static String INVALID_ASSIGNMENT_ID = "67we4";
        public static String CURRENT_LEVEL = "currentLevel";
        public static String IP_LEVEL = "ipLevel";
        public static String ASSIGNED_LEVEL = "AssignedLevel";
        public static String IP_COMPLETED_DATE = "IPCompletedDate";
        public static String GAIN = "gain";
        public static String INVALID_ASSIGNMENT_USER_ID = "111222333";
        public String PROGRESS_MONITORING_GRAPH = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/assignmentusers/{assignmentUserIDValue}/progressmonitoring";
        public String SAVE_PERFORMANCE_SETTING = "/lms/web/api/v1/organizations/{organizationId}/staffs/{staffId}/assignmentusers/{assignmentUserIDValue}/performanceTargets";

    }

    String ID ="id";
    String SKILL_LEVEL="skillLevel";
    String PEARSON_SKILL_OBEJCTID="pearsonSkillObjId";
    String MASTERY_STATUS_ID="masteryStatusId";
    String TOTAL_ATTEMPTS="totalAttempts";
    String TOTAL_CORRECTS="totalCorrects";
    String MASTERY_STATUS_DATE="masteryStatusDate";
    String STRAND_ID="strandId";
    String STRAND_LEVEL="strandLevel";
    String ASSIGNMENT_TITLE="assignmentTitle";
    String FIRST_NAME="firstName";
    String LAST_NAME="lastName";
    String ASSIGNMENT_USER_ID="auId";
    String INVALID_ASSIGNMENT_USER_ID="112345";
    String STRING_ASSIGNMENT_USER_ID="ASDFG";
    String SESSION_ID="session-id";
    
    String SCO_ID = "scoId";
    String CURRENT_PHASE = "currentPhase";
    String SESSIONID = "sessionId";


    public interface ScoStart {
        public static String ASSIGNMENT_SCO_HISTORY_ID = "asmtScoHistoryId";
        public static String CATALOG_NUMBER = "catalogNum";
        public static String ASSIGNMENT_USER_ID = "assignmentUserId";
        public static String COURSE_SESSION_ID = "courseSessionId";
        public static String CMI_COMPLETION_STATUS = "cmiCompletionStatus";
        public static String SUSPENDED_DATA = "suspendData";
        public static String LEARNING_OBJECT = "learningObject";
        public static String TOTAL_ATTEMPTS = "totalAttempts";
        public static String TOTAL_CORRECTS = "totalCorrect";
        public static String PST_IS_SCORABLE = "pstIsScorable";
        public static String PHASE_TYPE_NAME = "phaseTypeName";
        public static String PEARSON_CTYPE_ID = "pearsonCtTypeId";
        public static String CMI_INTERATCTIONS = "cmiInteractions";
        public static String PRE_REQUISITE = "prerequisite";
        public static String SCO_PRESENTED_COUNTER = "scoPresentedCounter";
        public static String ESCAPE_HATCH_ENABLED = "escapeHatchEnabled";
        public static String GPL = "gpl";
        public static String IIPL = "ipll";
        public static String COURSE_LEVEL = "courseLevel";
        public static String FLUENCY_STATUS = "fluencyStatus";
        public static String KEY_LO = "keyLo";
        public static String LESSON_SKILLOBJ = "lessonSkillObj";
    }

}
