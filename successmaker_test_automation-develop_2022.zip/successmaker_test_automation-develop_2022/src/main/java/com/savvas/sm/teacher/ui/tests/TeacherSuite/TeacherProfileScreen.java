package com.savvas.sm.teacher.ui.tests.TeacherSuite;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MyProfilePage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class TeacherProfileScreen extends BaseTest {

    private String lName;
    private String fName;
    private String teacherId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    List<String> studentIdList = null;
    List<String> studentUserNames = null;

    private AtomicReference<String> schoolUsed = new AtomicReference<>();

    @BeforeClass
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        String teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        fName = SMUtils.getKeyValueFromResponse( teacherDetails, "firstName" );
        lName = SMUtils.getKeyValueFromResponse( teacherDetails, "lastName" );

        ArrayList<String> studentDetails = new ArrayList<>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<>();
        studentUserNames = new ArrayList<>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

    }

    @Test ( description = "Verify First Name and Last Name field in the user profile screen", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile001( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // P1 and P2 Cases
        SMUtils.logDescriptionTC( "SMK-9816 : Verify the First name is displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9825 : Verify the Last name is displayed correctly in application" );
        // P3 and P4 Cases
        SMUtils.logDescriptionTC( "SMK-9817 : Verify the First name starts with lowercase and displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9818 : Verify the First name contains numericals and displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9819 : Verify the First name contains special characters and displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9820 : Verify the First name contains alphanumericals and displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9821 : Verify the First name contains mixed cases and displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9826 : Verify the Last name starts with lowercase and displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9823 : Verify the Middle name starts with lowercase and displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9947 : Verify the user can update the apostrophe(') symbol in between middle name for save user profile" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();
            SMUtils.waitForElement( driver, myProfilePage.txbFirstName );

            // Getting first name of the teacher from the User Profile
            String firstName = myProfilePage.getFirstName().trim();

            // Getting last name of the teacher from the User Profile
            String lastName = myProfilePage.getLastName().trim();
            // Validating whether First name is displayed correctly in the text field wihtout middle Name
            Log.assertThat( firstName.equals( fName ), "First Name " + fName + " is displaying properly and correctly in the User Profile Page ", " Expected : " + fName + " is not displaying properly and correctly in the User Profile Page" );

            // Validating whether Last name is displayed correctly in the text field wihtout middle Name
            Log.assertThat( lastName.equals( lName ), "Last Name " + lName + " is displaying properly and correctly in the User Profile Page ",
                    " Last Name " + lName + " is not displaying properly and correctly in the User Profile Page expected :" + lastName );

            // Updating the First Name with Lower case , Alphanumericals , Mixed Cases , Special Characters and Numericals
            myProfilePage.modifyFirstName( Constants.TeacherUserProfile.FIRSTNAME_WITH_MIXEDCHARACS );

            // Updating the Last Name with Lower case , Alphanumericals , Mixed Cases , Special Characters and Numericals
            myProfilePage.modifyMiddleName( Constants.TeacherUserProfile.LASTNAME_WITH_MIXEDCHARACS );

            // Updating the Middle Name with Lower case , Alphanumericals , Mixed Cases , Special Characters and Numericals
            myProfilePage.modifyLastName( Constants.TeacherUserProfile.MIDDLENAME_WITH_MIXEDCHARACS );

            myProfilePage.saveChanges();

            // Navigate to Suer Profile Page
            myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Get First Name After update
            String firstNameAfterUpdate = myProfilePage.getFirstName();
            String lastNameAfterUpdate = myProfilePage.getLastName();
            String middleNameAfterUpdate = myProfilePage.getMiddleName();

            String fNameAfterUpdate = myProfilePage.getFirstName();
            // Validating whether First name is displayed correctly in the text field
            Log.assertThat( fNameAfterUpdate.equals( Constants.TeacherUserProfile.FIRSTNAME_WITH_MIXEDCHARACS ), "First Name " + fNameAfterUpdate + " is displaying properly and correctly in the User Profile Page ",
                    " Expected : " + fNameAfterUpdate + " is not displaying properly and correctly in the User Profile Page" );

            // Validating whether Last name is displayed correctly in the text field
            Log.assertThat( lastNameAfterUpdate.equals( Constants.TeacherUserProfile.LASTNAME_WITH_MIXEDCHARACS ), "Last Name " + lastNameAfterUpdate + " is displaying properly and correctly in the User Profile Page ",
                    " Last Name " + lastNameAfterUpdate + " is not displaying properly and correctly in the User Profile Page" );

            // Validating whether Middle name is displayed correctly in the text field
            Log.assertThat( middleNameAfterUpdate.equals( Constants.TeacherUserProfile.MIDDLENAME_WITH_MIXEDCHARACS ), "Middle Name " + middleNameAfterUpdate + "  is displaying properly and correctly in the User Profile Page ",
                    " Middle Name  is not displaying properly and correctly in the User Profile Page" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validate the Cancel Button Functionality", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile002( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-9912 : Verify the user can cancel updating profile before save it for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9846 : Verify the Save button is displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9847 : Verify the Cancel button is displayed correctly in application" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Getting the old Values from the text fields
            String firstName = myProfilePage.getFirstName();
            String lastName = myProfilePage.getLastName();

            // Modify the Values with the Astrophe symbols and mixed characs
            myProfilePage.modifyFirstName( firstName + "+'$?'+ " + System.nanoTime() );
            myProfilePage.modifyLastName( lastName + " +'$?'+ " + System.nanoTime() );

            // Clicking Cancel Button
            myProfilePage.cancelChanges();

            // Getting theValues from the text fields after clicking Cancel button
            String firstNameAfterCancel = myProfilePage.getFirstName();
            String lastNameAfterCancel = myProfilePage.getLastName();

            // Validating the Cancel Button Functionality
            Log.assertThat( myProfilePage.isCancelBtnEnabled(), "Cancel Button is Present in the UI Page", "Cancel Button is not Present in the UI Page" );
            Log.assertThat( myProfilePage.isSaveBtnEnabled(), "Save Button is Present in the UI Page", "Save Button is not Present in the UI Page" );
            Log.assertThat( firstName.equals( firstNameAfterCancel ), "First Name Update failed Successfully After clicking cancel button", "First Name Modified : Failed" );
            Log.assertThat( lastName.equals( lastNameAfterCancel ), "Last Name Update failed Successfully After clicking cancel button", "Last Name Modified : Failed" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Password field is disabled", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile003( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	SMUtils.logDescriptionTC( "SMK-9915 : Verify the password input box should be disabled until user select the change password option for save user profile" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Validate whether Password field is disabled
            Log.assertThat( myProfilePage.isPasswordFieldDisabled(), "Password field is disabled by Default as Expected", "Password field is Enabled" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Change Password Link", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile004( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-9913 : Verify the user can change the password for save user profile" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Validate whether Password field is disabled
            Log.assertThat( myProfilePage.validateChangePaswordLink(), "ChangePassword link is Validated and all Password fields are enabled", "ChangePassword link fields is not working as " );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validate the Values from Title Drop Down", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile005( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-9827 : Verify the Title ( Mr ) is displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9828 : Verify the Title ( Mrs ) is displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9829 : Verify the Title ( Miss ) is displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9830 : Verify the Title ( Dr ) is displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9831 : Verify the Title ( Ms ) is displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9832 : Verify the Title ( Select Title ) is displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9848 : Verify the user can choose the title dropdown for save user profile " );
        SMUtils.logDescriptionTC( "SMK-9851 : Verify the user can choose Ms from title dropdown for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9852 : Verify the user can choose Mr from title dropdown for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9850 : Verify the user can choose Miss from title dropdown for save user profile " );
        SMUtils.logDescriptionTC( "SMK-9853 : Verify the user can choose Mrs from title dropdown for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9849 : Verify the user can choose Dr from title dropdown for save user profile " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Getting the Values from the title dropdown
            List<String> valuesFromtheTitleDropDown = myProfilePage.getValuesFromtheTitleDropDown();

            // Fetching the size of the Values from the title dropdown
            int noOfValuesPresentIntheTitleDropDown = valuesFromtheTitleDropDown.size();

            // Validate the Title Drop Down Values
            Log.assertThat( valuesFromtheTitleDropDown.equals( Constants.TeacherUserProfile.TITLE_DROPDOWN_VALUES_USERPROFILE ), "All Titles are Displayed properly in the Dropdown", "All Titles are not Displayed properly in the Dropdown" );

            myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            myProfilePage.selectValuesFromtheTitleDropDown( "Mrs" );
            Log.assertThat( myProfilePage.getUserTitle().equals( "Mrs" ), "Exepcted Title is Selected", "Exepcted Title is not Selected" );

            myProfilePage.selectValuesFromtheTitleDropDown( "Miss" );
            Log.assertThat( myProfilePage.getUserTitle().equals( "Miss" ), "Exepcted Title is Selected", "Exepcted Title is not Selected" );

            myProfilePage.selectValuesFromtheTitleDropDown( "Dr" );
            Log.assertThat( myProfilePage.getUserTitle().equals( "Dr" ), "Exepcted Title is Selected", "Exepcted Title is not Selected" );

            myProfilePage.selectValuesFromtheTitleDropDown( "Ms" );
            Log.assertThat( myProfilePage.getUserTitle().equals( "Ms" ), "Exepcted Title is Selected", "Exepcted Title is not Selected" );

            myProfilePage.selectValuesFromtheTitleDropDown( "Mr" );
            Log.assertThat( myProfilePage.getUserTitle().equals( "Mr" ), "Exepcted Title is Selected", "Exepcted Title is not Selected" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Alert Message for the Already used userID", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, enabled = false, priority = 1 )
    public void tcTeacherProfile006( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-9937 : Verify the alert message, when the userid is already exists" );
        SMUtils.logDescriptionTC( "SMK-9886 : Verify the user can update the user id for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9885 : Verify the userid as space in middle of text" );
        SMUtils.logDescriptionTC( "SMK-9887 : Verify the user can update the user id as special characters for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9888 : Verify the user can update the user id as numbers for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9889 : Verify the user can update the user id as alpha numeric for save user profile " );
        SMUtils.logDescriptionTC( "SMK-9890 : Verify the user can't update the user id as empty for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9884 : Verify the user can enter a userid with leading & trailing whitespaces " );
        SMUtils.logDescriptionTC( "SMK-9883 : Verify the user can enter a userid minimum no of characters" );
        SMUtils.logDescriptionTC( "SMK-9882 : Verify the user can enter a userid above 32 characters" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Click the save button
            myProfilePage.saveChanges();

            // Validate the alert message for already used UserID
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.USER_ID_ERROR_MESSAGE ), "Alert Message Displayed properly", "Alert Message not Displayed properly" );

            myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Passing already used UserID

            // Validate the  UserID updated properly
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MAX_LENGTH_ERROR_MESSAGE ), "User id not updated successfully", "Not expected Result" );

            myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Click the save button
            myProfilePage.saveChanges();

            // Validate the  UserID updated properly
            Log.assertThat( !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.USER_ID_ERROR_MESSAGE ) && !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MANDATORY_FIELD_ERROR ), "User ID updated Successfully",
                    "User id not updated successfully" );

            // Navigate to My Profile Page
            myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Clear UserID Text Field
            myProfilePage.clearTextField( "userId" );

            // Click Change Password link
            myProfilePage.clickChangePasswordLink();

            // Validate whether the error message thrown successfully
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MANDATORY_FIELD_ERROR ), "Error Message Successfully thrown after User ID field is blank", "Not shown as expected" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validate the Update of First Name in user profile", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile007( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-9945 : Verify the user can update the apostrophe(') symbol in between first name for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9824 : Verify the Middle name value as blank and displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9871 : Verify the user can update the middle name as empty for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9855 : Verify the user can enter a first name below 75 characters for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9856 : Verify the user can enter a firstname above 75 characters" );
        SMUtils.logDescriptionTC( "SMK-9862 : Verify the user cannot update the first name as empty for save user profile " );
        SMUtils.logDescriptionTC( "SMK-9864 : Verify the user can enter a middlename minimum no of characters" );
        SMUtils.logDescriptionTC( "SMK-9863 : Verify the user can enter a middlename above 75 characters " );
        SMUtils.logDescriptionTC( "SMK-9868 : Verify the user can enter a middle name below 75 characters for save user profile " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Get First Name before update
            String fName = myProfilePage.getFirstName();

            // Update First Name
            myProfilePage.modifyFirstName( Constants.FIRSTNAME + System.nanoTime() );

            // Get First Name After update
            String fNameAfterUpdate = myProfilePage.getFirstName();

            // Validate whether First Name is updated Successfully
            Log.assertThat( !fName.equals( fNameAfterUpdate ), "FirstName " + fName + " is Updated and changed to " + fNameAfterUpdate + " Successfully", "First Name field not changed successfully" );

            // Update First Name with 64 characs
            myProfilePage.modifyFirstName( myProfilePage.getNameWithSpecifiedNumOfCharac( 64 ) );

            myProfilePage.saveChanges();

            // Validate whether first name saved successfully with 64 characs
            Log.assertThat( !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MAX_LENGTH_ERROR_MESSAGE ), "Sucessfully saved with 64 charac names", "Not saved successfully" );

            // Update First Name with above 64 characters
            myProfilePage.modifyFirstName( myProfilePage.getNameWithSpecifiedNumOfCharac( 65 ) );

            myProfilePage.saveChanges();

            // Validate whether First name is not saved successfully with above 64 characs
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MAX_LENGTH_ERROR_MESSAGE ), "Error Message Thrown Successfully with above 64 characs names", "Not saved successfully" );

            // Update middle  Name
            myProfilePage.modifyMiddleName( myProfilePage.getNameWithSpecifiedNumOfCharac( 65 ) );

            myProfilePage.saveChanges();

            // Validate whether Middle name is not saved successfully with above 64 characs
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MAX_LENGTH_ERROR_MESSAGE ), "Error Message Thrown Successfully with above 64 characs names", "Not saved successfully" );

            myProfilePage.cancelChanges();

            // Update Middle Name with Minimum charac
            myProfilePage.modifyMiddleName( "A" );

            myProfilePage.saveChanges();

            // Validate whether Middle name saved successfully with Min characs
            Log.assertThat( !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MAX_LENGTH_ERROR_MESSAGE ) && !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MANDATORY_FIELD_ERROR ),
                    "Sucessfully saved with min no of charac", "Not saved successfully" );

            // Update Middle  Name with 64 characters
            myProfilePage.modifyMiddleName( myProfilePage.getNameWithSpecifiedNumOfCharac( 64 ) );

            myProfilePage.saveChanges();

            // Validate whether Middle name saved successfully with 64 characs
            Log.assertThat( !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MAX_LENGTH_ERROR_MESSAGE ) && !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MANDATORY_FIELD_ERROR ),
                    "Sucessfully saved with min no of charac", "Not saved successfully" );

            // Clear First name field
            myProfilePage.clearTextField( Constants.FIRSTNAME );

            // Click Change pasword link
            myProfilePage.clickChangePasswordLink();

            // Validate whether the error message thrown successfully
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MANDATORY_FIELD_ERROR ), "Error Message Successfully thrown after First Name field is blank", "Not shown as expected" );

            myProfilePage.cancelChanges();

            myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            myProfilePage.modifyMiddleName( "" );

            myProfilePage.saveChanges();

            Log.assertThat( !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MANDATORY_FIELD_ERROR ), "Sucessfully saved without username", "Not saved successfully" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validate the Update of Last Name in user profile", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile008( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-9946 : Verify the user can update the apostrophe(') symbol in between last name for save user profile" );
    	SMUtils.logDescriptionTC( "SMK-9914 : Verify the user is not required to change the password, when saving other changes" );
        SMUtils.logDescriptionTC( "SMK-9873 : Verify the user can enter a lastname minimum no of characters" );
        SMUtils.logDescriptionTC( "SMK-9872 : Verify the user can enter a lastname above 75 characters " );
        SMUtils.logDescriptionTC( "SMK-9877 : Verify the user can enter a last name below 75 characters for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9880 : Verify the user cannot update the last name as empty for save user profile " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Get Last Name before update
            String lName = myProfilePage.getLastName();

            // Update Last Name
            myProfilePage.modifyLastName( Constants.LASTNAME );

            // Get Last Name After update
            String lNameAfterUpdate = myProfilePage.getLastName();

            // Validate whether Last Name is updated Successfully
            Log.assertThat( !lName.equals( lNameAfterUpdate ), "LastName " + lName + " is Updated and changed to " + lNameAfterUpdate + " Successfully", "Last Name field not changed successfully" );

            myProfilePage.cancelChanges();

            // Update First Name
            myProfilePage.modifyLastName( "A" );

            myProfilePage.saveChanges();

            // Validate whether Last name saved successfully with Min characs
            Log.assertThat( !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MAX_LENGTH_ERROR_MESSAGE ) && !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MANDATORY_FIELD_ERROR ),
                    "Sucessfully saved with min no of charac", "Not saved successfully" );

            // Update last Name with 64 characs
            myProfilePage.modifyLastName( myProfilePage.getNameWithSpecifiedNumOfCharac( 64 ) );

            myProfilePage.saveChanges();

            // Validate whether Last name saved successfully with 64 characs
            Log.assertThat( !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MAX_LENGTH_ERROR_MESSAGE ), "Sucessfully saved with 64 charac names", "Not saved successfully" );

            // Update First Name with above 64 characs
            myProfilePage.modifyFirstName( myProfilePage.getNameWithSpecifiedNumOfCharac( 65 ) );

            myProfilePage.saveChanges();

            // Validate whether Last name saved successfully with 74 characs
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MAX_LENGTH_ERROR_MESSAGE ), "Error Message Thrown Successfully with above 65 characs names", "Not saved successfully" );

            // Clear Last name field
            myProfilePage.clearTextField( Constants.LASTNAME );

            // Click Change pasword link
            myProfilePage.clickChangePasswordLink();

            // Validate whether the error message thrown successfully
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MANDATORY_FIELD_ERROR ), "Error Message Successfully thrown after last name field is blank", "Not shown as expected" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validate the Update of email id in user profile", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile009( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-9891 : Verify the user can update the email id for save user profile" );
    	SMUtils.logDescriptionTC( "SMK-9837 : Verify the Email address which starts with lower case and displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9838 : Verify the Email address value as Empty and displayed correctly in application" );
        SMUtils.logDescriptionTC( "SMK-9892 : Verify the email id field by entering the valid email address" );
        SMUtils.logDescriptionTC( "SMK-9893 : Verify the email address contains dot ( . ) inbetween the email text " );
        SMUtils.logDescriptionTC( "SMK-9894 : Vetify the email address contains alphanumericals" );
        SMUtils.logDescriptionTC( "SMK-9895 : Verify the email address contains undesrcore" );
        SMUtils.logDescriptionTC( "SMK-9899 : Verify the contact reference label should be appear below the email id field for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9909 : Verify the for sign in text should be displayed below user name field for save user profile" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Add Email ID
            myProfilePage.modifyEmail( Constants.TeacherUserProfile.EMAIL_ID_VALUE );

            // Get Email ID from the Field
            String emailBeforeUpdate = myProfilePage.getEmail();

            // Update Email ID
            myProfilePage.modifyEmail( System.nanoTime() + Constants.TeacherUserProfile.EMAIL_ID_VALUE );

            // Get Email ID from the Field After Update
            String emailAfterUpdate = myProfilePage.getEmail();

            // Validate whether Email ID field is updated with Lower Case Letters
            Log.assertThat( !emailBeforeUpdate.equals( emailAfterUpdate ), "Email ID  " + emailBeforeUpdate + " is Updated and changed to " + emailAfterUpdate + " Successfully", "Email id not changed successfully" );

            myProfilePage.modifyEmail( "" );

            // save changes
            myProfilePage.saveChanges();

            // Validate whether the email field is blank and updated successfully
            Log.assertThat( !myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MANDATORY_FIELD_ERROR ), "User profile updated successfully after email id field left blank", "Not updated as expected" );

            // Verify Contact Reference Label Under Email Text-box
            Log.assertThat( myProfilePage.isContactRefLabelPresent(), "Contact Refernce Label Present on the UI", "Label not present on the UI" );

            // Verify For Sign In Label Reference Label Under Email Text-box
            Log.assertThat( myProfilePage.isForSignInLabelPresent(), "For Sign In Label Present on the UI", "Label not present on the UI" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validate the Error Message for Current and New Pasword field contains same Values", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile010( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        SMUtils.logDescriptionTC( "SMK-9956 : Verify the validation error when the new password is same as old password." );
        SMUtils.logDescriptionTC( "SMK-9932 : Verify the mandatory ( * ) symbol displays firstname,lastname,username and password for save user profile" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Passing Current password and New Password with same values
            myProfilePage.modifyPassword( RBSDataSetupConstants.DEFAULT_PASSWORD );

            // Click Save Button
            myProfilePage.saveChanges();

            myProfilePage.cancelChanges();

            myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Validate Mandatory symbol for First Name
            Log.assertThat( myProfilePage.isMandatorySymbolPresent( "First Name *" ), "Mandatory Symbol is present for the First name", "Mandatory Symbol is not present" );

            // Validate Mandatory symbol for last Name
            Log.assertThat( myProfilePage.isMandatorySymbolPresent( "Last Name *" ), "Mandatory Symbol is present for the last name", "Mandatory Symbol is not present" );

            // Validate Mandatory symbol for Password
            Log.assertThat( myProfilePage.isMandatorySymbolPresent( "Password *" ), "Mandatory Symbol is present for the password field", "Mandatory Symbol is not present" );

            // Validate Mandatory symbol for  UserName
            Log.assertThat( myProfilePage.isMandatorySymbolPresent( "Username *" ), "Mandatory Symbol is present for the user name", "Mandatory Symbol is not present" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validate the Password change Completed Successfully", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 11 )
    public void tcTeacherProfile011( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        SMUtils.logDescriptionTC( "SMK-9956 : Verify the validation error when the new password is same as old password." );
        SMUtils.logDescriptionTC( "SMK-9923 : Verify the user can update the password as special characters for save user profile " );
        SMUtils.logDescriptionTC( "SMK-9924 : Verify the user can update the password as numbers for save user profile " );
        SMUtils.logDescriptionTC( "SMK-9925 : Verify the user can update the password as alpha numeric for save user profile " );
        SMUtils.logDescriptionTC( "SMK-9927 : Verify the functionality by entering the mixed password (Alphanumerics, Special Character ) for save user profile " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            String modifiedPassword = RBSDataSetupConstants.DEFAULT_PASSWORD + "a$56Af3@#&" + System.nanoTime();

            // Passing Current password and New Password with same values
            myProfilePage.modifyPassword( modifiedPassword );

            // Passing modified Password as current password to check password changed
            // previously
            Boolean validateChangedPassword = myProfilePage.validateChangedPassword( modifiedPassword );

            // Validate whether the Password changed Successfully
            Log.assertThat( validateChangedPassword, "Password Change Successfully completed", "Password Change failed" );

            myProfilePage.modifyPassword( password );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the old password field blank and entering the valid new and confirm password for save user profile ", enabled = false, groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile012( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-9918 : Verify the change password functionality by leaving the old password field blank and entering the valid new and confirm password for save user profile " );
        SMUtils.logDescriptionTC( "SMK-9919 : Verify the functionality of change password by capturing the valid old password, confirm password and keep the new password field as blank for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9920 : Verify the functionality of change password by capturing the valid old password, new password and keep the confirm password field as blank for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9921 : Verify the functionality of change password by capturing the valid old password and keep both confirm and new password fields as blank for save user profile " );
        SMUtils.logDescriptionTC( "SMK-9922 : Verify the functionality of change password , when all the password fields are blank " );
        SMUtils.logDescriptionTC( "SMK-9938 : Verify the alert message when the password field is empty" );
        SMUtils.logDescriptionTC( "SMK-9931 : Verify the alert message, when all the fields are empty " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            String oldPassword = RBSDataSetupConstants.DEFAULT_PASSWORD;

            String modifiedPassword = RBSDataSetupConstants.DEFAULT_PASSWORD + System.nanoTime();

            myProfilePage.clearTextField( RBSDataSetupConstants.DEFAULT_PASSWORD );

            // Passing Current password and New Password with same values
            myProfilePage.modifyPasswordwithoutCurrentPassword( modifiedPassword );

            // Save Changes
            myProfilePage.saveChanges();

            // Validate whether the error message thrown successfully
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.MANDATORY_FIELD_ERROR ), "Save Button Disabled due to Current Password field Blank", "Not shown as expected" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Error Message for Invalid Email Address and wrong Current Password", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile013( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-9896 : Verify the email address without @ special character" );
        SMUtils.logDescriptionTC( "SMK-9930 : Verify the alert message when user enter the wrong password for save user profile" );
        SMUtils.logDescriptionTC( "SMK-9898 : Verify the email id text box, when the domain is missing" );
        SMUtils.logDescriptionTC( "SMK-9897 : Verify email address field with multiple dots for save user profile" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Passing Invalid Email Address
            myProfilePage.modifyEmail( Constants.TeacherUserProfile.INCORRECT_EMAIL_ID_VALUE );

            // Click Save Button
            myProfilePage.saveChanges();

            // Validate whether Proper Error Message is thrown for Invalid Email
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.EMAIL_ERROR_MESSAGE ), "Invalid Email Error Message thrown successfully", "Error Message not thrown successfully" );

            // Passing Invalid Email Address
            myProfilePage.modifyEmail( Constants.TeacherUserProfile.INCORRECT_EMAIL_ID_VALUE_WITHOUT_DOMAIN );

            // Click Save Button
            myProfilePage.saveChanges();

            // Validate whether Proper Error Message is thrown for Invalid Email
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.EMAIL_ERROR_MESSAGE ), "Invalid Email Error Message thrown successfully", "Error Message not thrown successfully" );

            // Passing Invalid Email Address
            myProfilePage.modifyEmail( "dEr_89v...@gmail.com" );

            // Click Save Button
            myProfilePage.saveChanges();

            // Validate whether Proper Error Message is thrown for Invalid Email
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.EMAIL_ERROR_MESSAGE ), "Invalid Email Error Message thrown successfully", "Error Message not thrown successfully" );

            // Passing valid Email Address
            myProfilePage.modifyEmail( Constants.TeacherUserProfile.EMAIL_ID_VALUE );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validate  the user saving profile changes will permanently save the changes", groups = { "SMK-39368", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile014( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-9940 : Verify the user saving profile changes will permanently save the changes, including any password change if applicable for save user profile" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Get Default Values in the Text Fields
            String fName = Constants.FIRSTNAME + System.nanoTime();
            String lName = Constants.LASTNAME + System.nanoTime();

            // Student ID value To Pass

            // Modifying the text fields
            myProfilePage.modifyFirstName( fName );
            myProfilePage.modifyLastName( lName );

            SMUtils.logDescriptionTC( "Verify the user confirmation messages that  profile changes were saved for save user profile" );

            // Clicking save button
            myProfilePage.saveChanges();

            // Navigating to the Home tab
            tHomePage.topNavBar.navigateToHomeTab();

            // Navigating to the My User Profile tab
            tHomePage.topNavBar.navigateToMyProfile();

            // Get values After update
            String fNameAfterUpdate = myProfilePage.getFirstName();
            String lNameAfterUpdate = myProfilePage.getLastName();

            // Validate whether Last Name is updated Successfully
            Log.assertThat( fName.equals( fNameAfterUpdate ), "Modified FirstName is Saved Successfully", "Not Modifed Successfully" );

            Log.assertThat( lName.equals( lNameAfterUpdate ), "Modified LastName is Saved Successfully", "Not Modifed Successfully" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-53951 - Removal of user Id and Current password Field Test", groups = { "SMK-53951", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile015( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        SMUtils.logDescriptionTC( "SMK-9940 : Verify the user saving profile changes will permanently save the changes, including any password change if applicable for save user profile" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Verify the Save button is disabled
            SMUtils.logDescriptionTC( " Verify that Save button is inactive before clicking Change Password link." );
            Log.assertThat( myProfilePage.verifySaveButtonisDisabled(), "The save Button is disabled as Expected !", "The save button is not disabled not Expected !" );

            // Change password link is present
            SMUtils.logDescriptionTC( " Verify that Change Password link is displayed in My Profile page" );
            new SMUtils();
            Log.assertThat( SMUtils.isElementPresent( myProfilePage.changePasswordLink ), "The change password link is dispayed", "The change password link is not dispayed" );

            // Clicking change password link
            SMUtils.logDescriptionTC( " Verify that user can click on the Change Password link available in the My Profile page" );
            myProfilePage.clickChangePasswordLink();
            SMUtils.logDescriptionTC( " Verify that change password link changed to inactive when New Password and Confirm Password fields are displayed" );

            // Verify the USER ID Field is  not Displyed
            SMUtils.logDescriptionTC( " Verify that User ID field is not displayed in My Profile page" );
            SMUtils.logDescriptionTC( " Verify that Current Password field is not displayed in My Profile page after clicking Change Password link" );
            Log.assertThat( myProfilePage.VerifyUserIdAndOldPasswordisNotPresent(), "The User Id Field and Current Password field is not present as Expected!", "The User Id Field and Current Password field is  present as not Expected!" );

            // Verifying password policied
            myProfilePage.clickInformationCircle();
            Log.assertThat( myProfilePage.VerifyPasswordRequirementTexts(), "The Password Requirement Text matches!", "The Password Requirement Text doesnot matches!" );

            String updtedPassword = "testing123$";

            // updating with new password
            SMUtils.logDescriptionTC( " Verify that clicking Change Password link, displays Enter New Password and Confirm New Password fields." );
            myProfilePage.modifyNewPassword( updtedPassword );
            myProfilePage.modifyConfirmPassword( updtedPassword );
            SMUtils.logDescriptionTC( "Verify that Save button is changed to active after clicking Change Password link." );
            myProfilePage.saveChanges();

            new SMUtils();
            // Waiting the alert mesage
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( MyProfilePage.alertMessageCSS ), 5 );
            Log.assertThat( SMUtils.verifyWebElementTextEquals( myProfilePage.alertElement, Constants.TeacherUserProfile.CHANGES_SAVED_TOAST_MESSAGE ), "Toast message is matched!", "Toast message is not matched!" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();
            SMUtils.logDescriptionTC( " Verify the teacher is able to login to the application using the updated Password" );
            smLoginPage.enterCredentialsAndLogIn( username, updtedPassword );

            // Navigating to the MyProfilePage tab
            tHomePage.topNavBar.navigateToMyProfile();

            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyNewPassword( RBSDataSetupConstants.DEFAULT_PASSWORD );
            myProfilePage.modifyConfirmPassword( RBSDataSetupConstants.DEFAULT_PASSWORD );
            SMUtils.logDescriptionTC( " Verify that 'Your changes have been saved' toast message is displayed after you click on Save button after entering correct passwords" );
            SMUtils.logDescriptionTC( " Verify that teacher can click on the save button after entering the passwords correctly" );
            myProfilePage.saveChanges();

            // Verifying not matched password
            SMUtils.logDescriptionTC( " Verify that If the New Password and Confirm Password fields do not match, a validate message 'Password does not match' is shown." );
            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyNewPassword( updtedPassword );
            myProfilePage.modifyConfirmPassword( updtedPassword + 1 );
            myProfilePage.modifyMiddleName( "" );
            new SMUtils();
            SMUtils.waitForLocatorToPresent( driver, By.cssSelector( MyProfilePage.erroMessgaeCSS ), 3 );
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.DOES_NOT_MATCH_NEW_PASSWORD ), "The Error message matches!", "The Error message doesnot matches!" );
            myProfilePage.cancelChanges();

            // Verify the Password req Error message
            // Verifying not matched password
            myProfilePage.clickChangePasswordLink();
            myProfilePage.modifyNewPassword( "abc" );
            myProfilePage.modifyMiddleName( "" );
            Log.assertThat( myProfilePage.validateErrorMessage( Constants.TeacherUserProfile.PASSWORD_DEOES_NOT_MEET_REQUIREMENT ), "The Error message matches!", "The Error message doesnot matches!" );
            SMUtils.logDescriptionTC( " Verify that teacher can click Cancel button to cancel changes that have been made." );
            myProfilePage.cancelChanges();

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the password field characters are unreadable in application", groups = { "SMK-55077", "Teacher", "UserProfileScreen" }, priority = 1 )
    public void tcTeacherProfile016( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-55077 : Verify the password field characters are unreadable in application");

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the MyProfilePage tab
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Validate whether Password field is Masked

            Log.assertThat(  myProfilePage.isPasswordMasked(), "Password field is Masked!!", "Password field is Not Masked" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}