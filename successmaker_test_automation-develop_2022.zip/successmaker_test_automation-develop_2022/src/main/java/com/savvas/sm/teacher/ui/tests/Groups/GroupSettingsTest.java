package com.savvas.sm.teacher.ui.tests.Groups;

import java.util.ArrayList;
import java.util.HashMap;
/**
 * This class test the Groups Settings Integration.
 *
 * @author aravindan.sivanandan
 *
 */
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants.GroupUIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

public class GroupSettingsTest extends GroupAPI {
    private String smUrl;
    private String browser;
    private String username = null;
    private String studentID_1;
    private String studentID_2;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentID_1 = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), RBSDataSetupConstants.USERNAME );
        studentID_2 = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), RBSDataSetupConstants.USERNAME );
        Log.message( "studentID 1: " + studentID_1 );
        Log.message( "studentID 2: " + studentID_2 );
    }

    // Validating Fields in group setting page

    @Test ( description = "Verify the fields present in Group settings tab", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )

    public void tcGroupsettings001() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings001:SMK-8567 Verify the fields present in Group settings tab <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.clickSettingsSubNav();

            // Verifying Groups settings header
            Log.assertThat( groupsTab.isGroupsSettingsDisplayed(), "Groups settings header is present under settings sub nav", "Groups settings header is not present under settings sub nav" );

            // Verifying Edit Settings title
            Log.assertThat( groupsTab.isEditSettingsTitleDisplayed(), "Edit Settings title is present under settings sub nav", "Edit Settings title is not present under settings sub nav" );

            // Verifying GroupNameTitle
            Log.assertThat( groupsTab.isGroupNameTitleDisplayed(), "GroupNameTitle is present under settings sub nav", "GroupNameTitle is not present under settings sub nav" );

            // Verifying Delete Group Title
            Log.assertThat( groupsTab.isDeleteGroupTitleDisplayed(), "DeleteGroupTitle is present under settings sub nav", "DeleteGroupTitle is not present under settings sub nav" );

            // Verifying Delete Group Text
            Log.assertThat( groupsTab.isDeleteGrouptextTitleDisplayed(), "DeleteGrouptext is present under settings sub nav", "DeleteGrouptext is not present under settings sub nav" );

            // Verifying edit Group TextBox
            Log.assertThat( groupsTab.isEditGroupTextboxDsiplayed(), "EditGroupTextbox is present under settings sub nav", "EditGroupTextbox is not present under settings sub nav" );

            // Verifying Save button
            Log.assertThat( SMUtils.isElementPresent( groupsTab.getSaveButton() ), "Save button is present under groups settings Tab", "Save button is not present under groups settings Tab" );

            // Verifying Delete button
            Log.assertThat( SMUtils.isElementPresent( groupsTab.getDeleteButton() ), "Delete button is present under groups settings Tab", "Delete button is not present under groups settings Tab" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Edit Group Name functionality", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings002() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings002:SMK-8568 Verify the Edit Group Name functionality <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.editGroup( GroupUIConstants.NEW_GROUP_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.NEW_GROUP_NAME ), "New Group name is displayed under groups tab!", "New Group name is not displayed under groups tab" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user can able to enter the group name text field with combination of lower and uppercase characters", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings003() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings003:SMK-8569 Verify the user can able to enter the group name text field with combination of lower and uppercase characters <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab

            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithoutStudent( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.enterGroupNameInGroupsTab( GroupUIConstants.UPPER_lOWER_CASE_GROUP_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.UPPER_lOWER_CASE_GROUP_NAME ), "Combination of lower and uppercase characters group name is displayed under groups tab!",
                    "Combination of lower and uppercase characters group name is displayed under groups tab" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user can able to enter the group name  text field contains space inbetween characters", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings004() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings004:SMK-8570 Verify the user can able to enter the group name  text field contains space inbetween characters <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.enterGroupNameInGroupsTab( GroupUIConstants.SPACE_BETWEEN_CHAR_GROUP_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.SPACE_BETWEEN_CHAR_GROUP_NAME ), "the user can able to enter the group name  text field contains space inbetween characters",
                    "the user cannot able to enter the group name  text field contains space inbetween characters" );
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user can able to enter the group name text field with numericals", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings005() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings005:SMK-8571 Verify the user can able to enter the group name text field with numericals <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.enterGroupNameInGroupsTab( GroupUIConstants.NUMERIC_GROUP_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.NUMERIC_GROUP_NAME ), "the user can able to enter the group name text field with numericals", "the user cannot able to enter the group name text field with numericals" );
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify  user can able to enter the  group name text field as special character", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings006() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings006:SMK-8572 Verify  user can able to enter the  group name text field as special character  <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
    		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.enterGroupNameInGroupsTab( GroupUIConstants.SPECIAL_CHAR_GROUP_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.SPECIAL_CHAR_GROUP_NAME ), "user can able to enter the  group name text field as special character", "user cannot able to enter the  group name text field as special character" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user can able to enter the group  name text field with the combination of  alphanumeric", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings007() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings007:SMK-8573 Verify the user can able to enter the group  name text field with the combination of  alphanumeric <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.enterGroupNameInGroupsTab( GroupUIConstants.ALPHANUMERIC_GROUP_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.ALPHANUMERIC_GROUP_NAME ), "the user can able to enter the group  name text field with the combination of  alphanumeric",
                    "the user cannot able to enter the group  name text field with the combination of  alphanumeric" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user can able to enter the group  name text field with the combination of  uppercase letters", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings008() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings008:SMK-8574 Verify the user can able to enter the group  name text field with the combination of  uppercase letters <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.enterGroupNameInGroupsTab( GroupUIConstants.UPPER_CASE_GROUP_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.UPPER_CASE_GROUP_NAME ), "the user can able to enter the group  name text field with the combination of  uppercase letters",
                    "the user can able to enter the group  name text field with the combination of  uppercase letters" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user can able to enter the  group name text field with the combination of lowercase letters", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings009() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings009:SMK-8575 Verify the user can able to enter the  group name text field with the combination of lowercase letters <small><b><i>[" + browser + "]</b></i></small>" );
    	try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.enterGroupNameInGroupsTab( GroupUIConstants.LOWER_CASE_GROUP_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.LOWER_CASE_GROUP_NAME ), "the user can able to enter the group  name text field with the combination of  lowercase letters",
                    "the user can able to enter the group  name text field with the combination of  lowercase letters" );
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the maximum number of characters  accepted in group name text field", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings010() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings010:SMK-8576 Verify the maximum number of characters  accepted in group name text field <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.editGroup( GroupUIConstants.EXACT_75_CHAR_GROUP_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.EXACT_75_CHAR_GROUP_NAME ), "the user can able to enter the group  name text field with the Maximum characters",
                    "the user cannot able to enter the group  name text field with the maximum characters" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Text field By entering more than allowed Maximum characters", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings011() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings011:SMK-8577 Verify the Text field By entering more than allowed Maximum characters <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
    		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            Log.assertThat( groupsTab.enterInvalidGroupName( GroupUIConstants.ABOVE_75_CHAR_GROUP_NAME, GroupUIConstants.MIN_MAX_ERROR_MESSAGE ), "Error message displayed properly", "Error message not displayed properly" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Text field By entering the Less than allowed Minimum characters", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings012() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings012:SMK-8578 Verify the Text field By entering the Less than allowed Minimum characters <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            Log.assertThat( groupsTab.enterInvalidGroupName( GroupUIConstants.BELOW_3_CHAR_GROUP_NAME, GroupUIConstants.MIN_MAX_ERROR_MESSAGE ), "Error message displayed properly", "Error message not displayed properly" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the minimum number of characters  accepted in group name text field", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings013() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings013:SMK-8579 Verify the minimum number of characters  accepted in group name text field <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.editGroup( GroupUIConstants.EXACT_3_CHAR_GROUP_NAME );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify and Ensure edited/updated group name is reflecting for teacher under Groups list", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings014() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings014:SMK-8582 Verify and Ensure edited/updated group name is reflecting for teacher under Groups list <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.editGroup( GroupUIConstants.UPDATED_GROUP_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.UPDATED_GROUP_NAME ), "Edited Group name is displayed under groups tab!", "Group is not displayed under groups tab" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Teacher is not able to save groups if the textbox is blank", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings015() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings015:SMK-8583 Verify Teacher is not able to save groups if the textbox is blank <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab

            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            Log.assertThat( groupsTab.enterInvalidGroupName( GroupUIConstants.NULL_GROUP_NAME, GroupUIConstants.NULL_GROUP_NAME_ERROR_MESSAGE ), "Error message displayed properly", "Error message not displayed properly" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Teacher is not able to create new group with existing Group name(Duplicate Group name)", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings016() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings016:SMK-8584 Verify Teacher is not able to create new group with existing Group name(Duplicate Group name) <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.EXISTING_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    //This case disabled due to SMK-59700
    @Test ( enabled = false, description = "Verify Teacher is not able to edit and save groups with existing name(duplicate group name)", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings017() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings017:SMK-8585 Verify Teacher is not able to edit and save groups with existing name(duplicate group name) <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
    		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            Log.assertThat( groupsTab.enterInvalidGroupName( GroupUIConstants.EXISTING_GROUP_NAME, GroupUIConstants.DUPLICATE_GROUP_NAME_MESSAGE ), "Error message displayed properly", "Error message not displayed properly" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Delete Custom Group functionality", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings018() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings018:SMK-8586 Verify the Delete Custom Group functionality <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            String groupName = GroupUIConstants.SIMPLE_GROUP_NAME + System.nanoTime();
            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( groupName, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( groupName );
            groupsTab.deleteGroup( groupName );
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Delete Button Which delete the group and take the teacher to the groups listing page.", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings019() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings019:SMK-8587 Verify the Delete Button Which delete the group and take the teacher to the groups listing page <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            String groupName = GroupUIConstants.SIMPLE_GROUP_NAME + System.nanoTime();
            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( groupName, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( groupName );
            groupsTab.deleteGroup( groupName );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( !groupsFromUI.contains( groupName ), "Deleted Group name is not displayed under groups tab", "Deleted Group name is displayed under groups tab!" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify If the teacher decides to cancel the popup delete window & Group settings page should be displayed", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings020() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings020:SMK-8588 Verify If the teacher decides to cancel the popup delete window & Group settings page should be displayed <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.clickCancelButtonGroupDeletePopUp();
            Log.assertThat( groupsTab.getDeleteButton().isDisplayed(), "Group Setting Page is disaplyed", "Group Setting Page is not disaplyed" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify deleted group and the associated roster is not visible for teacher", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings021() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings021:SMK-8589 Verify deleted group and the associated roster is not visible for teacher  <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
    		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            String groupName = GroupUIConstants.SIMPLE_GROUP_NAME + System.nanoTime();
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( groupName, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( groupName );
            groupsTab.deleteGroup( groupName );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            boolean d = groupsFromUI.contains( groupName );
            Log.assertThat( !d, "Deleted Group name is not displayed under groups tab!", "Deleted Group name is  displayed under groups tab!" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify students are deleted from students list by deleting the group", priority = 1, groups = { "SMK-42082", "Groups", "Groupsettings" } )
    public void tcGroupsettings022() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings022:SMK-8590 Verify students are deleted from students list by deleting the group <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
    		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Getting StudentID

            HashMap<String, String> userDetails = new HashMap<>();
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, "Student" + System.nanoTime() );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
            new RBSUtils().createUser( userDetails );

            SMUtils.nap( 20 ); // Wait for SOLR indexing
            String studentID = userDetails.get( RBSDataSetupConstants.USERNAME );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            String groupName = GroupUIConstants.SIMPLE_GROUP_NAME + System.nanoTime();
            List<String> studentUserNames = new ArrayList<>();
            studentUserNames.add( studentID );

            groupsTab.createGroupWithSchoolStudents( groupName, studentUserNames, "All Grades" );

            groupsTab.viewGroup( groupName );
            groupsTab.deleteGroup( groupName );
            StudentsPage studentpage = tHomePage.topNavBar.navigateToStudentsTab();
            studentpage.isStrudentPresent( studentID );
            Log.assertThat( !studentpage.isStrudentPresent( studentID ), "students are deleted from students list by deleting the group", " students not are deleted from students list by deleting the group!" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user can able to enter the  group name text field along with special character & uppercase letters", priority = 3, groups = { "SMK-42082", "Groups", "Groupsettings", "P3" } )
    public void tcGroupsettings023() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings023:SMK-8580 Verify the user can able to enter the  group name text field along with special character & uppercase letters <small><b><i>[" + browser + "]</b></i></small>" );
    	try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.enterGroupNameInGroupsTab( GroupUIConstants.UPPER_SPECIAL_CHAR_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.UPPER_SPECIAL_CHAR_NAME ), "the user can able to enter the group  name text field with the combination of  special character & uppercase letters",
                    "the user cannot able to enter the group  name text field with the combination of special character & uppercase letters" );
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user can able to enter the  group name text field along with special character & lowercase letters", priority = 3, groups = { "SMK-42082", "Groups", "Groupsettings", "P3" } )
    public void tcGroupsettings024() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcGroupsettings024:SMK-8581 Verify the user can able to enter the  group name text field along with special character & lowercase letters <small><b><i>[" + browser + "]</b></i></small>" );
    	try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( GroupUIConstants.SIMPLE_GROUP_NAME, studentID_1 + "," + studentID_2, "All Grades" );
            groupsTab.viewGroup( GroupUIConstants.SIMPLE_GROUP_NAME );
            groupsTab.enterGroupNameInGroupsTab( GroupUIConstants.LOWER_SPECIAL_CHAR_NAME );
            GroupPage groupslistingpage = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsFromUI = groupslistingpage.getGroupListNames();
            Log.assertThat( groupsFromUI.contains( GroupUIConstants.LOWER_SPECIAL_CHAR_NAME ), "the user can able to enter the group  name text field with the combination of  special character & lowercase letters",
                    "the user cannot able to enter the group  name text field with the combination of special character & lowercase letters" );
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
