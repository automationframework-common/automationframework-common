package com.savvas.sm.api.tests.smnew.license;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.ethnicity;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.gender;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.grade;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasDisability;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEconomicDisadvantage;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.hasEnglishProficiency;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.isMigrant;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.specialServices;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

/**
 * This class is used to test whether the user is able to launch the student
 * Assignment Data
 * 
 * @author madhan.nagarathinam
 *
 */
public class GetStudentAssignmentLicenseUsageTest extends BaseAPITest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    String mathTeacherDetails;
    private String readingSchool = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    String readingTeacherDetails;
    private String focusMathSchool = RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL );
    String focusMathTeacherDetails;
    private String focusReadingSchool = RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL );
    String focusReadingTeacherDetails;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String flexTeacherDetails;
    private String token = null;
    HashMap<String, String> mathSchoolAssignmentResponse = new HashMap<>();
    HashMap<String, String> readingSchoolAssignmentResponse = new HashMap<>();
    HashMap<String, String> focusMathSchoolAssignmentResponse = new HashMap<>();
    HashMap<String, String> focusReadingSchoolAssignmentResponse = new HashMap<>();
    HashMap<String, String> flexSchoolAssignmentResponse = new HashMap<>();
    HashMap<String, String> zeroLicenseSchoolAssignmentResponse = new HashMap<>();
    HashMap<String, String> mathSchoolCreateStudentResponse = new HashMap<>();
    HashMap<String, String> readingSchoolCreateStudentResponse = new HashMap<>();
    HashMap<String, String> focusMathSchoolCreateStudentResponse = new HashMap<>();
    HashMap<String, String> focusReadingSchoolCreateStudentResponse = new HashMap<>();
    HashMap<String, String> flexSchoolCreateStudentResponse = new HashMap<>();
    HashMap<String, String> zeroLicenseSchoolCreateStudentResponse = new HashMap<>();

    String math_UserId = null;
    String math_UserName = null;
    String mathAssignUserId = null;
    String reading_UserId = null;
    String reading_UserName = null;
    String readingAssignUserId = null;
    String focusMath_UserId = null;
    String focusMath_UserName = null;
    String focusMathAssignUserId = null;
    String focusReading_UserId = null;
    String focusReading_UserName = null;
    String focusReadingAssignUserId = null;
    String flex_UserId = null;
    String flex_UserName = null;
    String flexAssignUserId = null;
    String mathStudentDetails;

    @BeforeClass(alwaysRun = true)
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        mathTeacherDetails = RBSDataSetup.getMyTeacher( mathSchool );
        mathStudentDetails = RBSDataSetup.getMyStudent( mathSchool, SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USER_NAME ) );

        readingTeacherDetails = RBSDataSetup.getMyTeacher( readingSchool );
        focusMathTeacherDetails = RBSDataSetup.getMyTeacher( focusMathSchool );
        focusReadingTeacherDetails = RBSDataSetup.getMyTeacher( focusReadingSchool );
        flexTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );

    }

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-51567", "smoke_test_case", "P1", "SMK-51569", "Create end points to maintain number of used seats - math/reading", "Create end points to maintain number of used seats - flex",
            "API" }, priority = 1 )
    public void getStudentAssignmentLicenseUsageTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> Dummy = new HashMap<>();
        HashMap<String, String> headers = new HashMap<String, String>();
        List<String> pathParamsList = new ArrayList<String>();
        String endPoint = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {
            case "DEFAULT_MATH":

                // Creating Student, Group, Assigning assignment for a group and getting userassignmentId from DB

                HashMap<String, String> mathSchoolStudentDetails = new HashMap<>();
                mathSchoolStudentDetails = generateRequestValues( mathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                mathSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, mathSchoolStudentDetails );
                String cmsResponse = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( mathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );

                math_UserId = SMUtils.getKeyValueFromResponse( mathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID );
                math_UserName = SMUtils.getKeyValueFromResponse( mathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new RBSUtils().updateUserOrgId( new RBSUtils().getUser( math_UserId ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( mathSchool ) ) );
                HashMap<String, String> mathSchoolGroupDetails = new HashMap<>();
                HashMap<String, String> mathSchoolAssignmentDetails = new HashMap<>();
                List<String> mathSchoolStudentRumbaIds = new ArrayList<>();
                mathSchoolStudentRumbaIds.add( math_UserId );
                mathSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userId" ) );
                mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, mathSchoolGroupDetails, mathSchoolStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }

                mathSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                mathSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userId" ) );
                mathSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                mathSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                mathSchoolAssignmentResponse = new AssignmentAPI().assignAssignment( smUrl, mathSchoolAssignmentDetails, mathSchoolStudentRumbaIds, "users" );

                mathAssignUserId = getuserAssignmentId( math_UserId );
                Log.message( mathAssignUserId + "AssignmentUserId" );
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( math_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                headers.put( LicenseAPIConstants.USERID, math_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( mathAssignUserId );
                break;

            case "DEFAULT_READING":

                HashMap<String, String> readingSchoolStudentDetails = new HashMap<>();
                readingSchoolStudentDetails = generateRequestValues( readingSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( readingSchool ) );
                readingSchoolStudentDetails = updateRequestBodyValues( readingSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( readingSchool ) );
                readingSchoolStudentDetails = updateRequestBodyValues( readingSchoolStudentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( readingTeacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                readingSchoolStudentDetails = updateRequestBodyValues( readingSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( readingTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                readingSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, readingSchoolStudentDetails );
                String cmsResponse1 = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( readingSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse1, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( readingSchool ) );

                reading_UserId = SMUtils.getKeyValueFromResponse( readingSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID );
                reading_UserName = SMUtils.getKeyValueFromResponse( readingSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new RBSUtils().updateUserOrgId( new RBSUtils().getUser( reading_UserId ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( readingSchool ) ) );

                HashMap<String, String> readingSchoolGroupDetails = new HashMap<>();
                HashMap<String, String> readingSchoolAssignmentDetails = new HashMap<>();
                List<String> readingSchoolStudentRumbaIds = new ArrayList<>();
                readingSchoolStudentRumbaIds.add( reading_UserId );
                readingSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( readingTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                readingSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( readingTeacherDetails, "userId" ) );
                readingSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( readingSchool ) );
                readingSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, readingSchoolGroupDetails, readingSchoolStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }

                readingSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( readingSchool ) );
                readingSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( readingTeacherDetails, "userId" ) );
                readingSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_READING );
                readingSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( readingTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                readingSchoolAssignmentResponse = new AssignmentAPI().assignAssignment( smUrl, readingSchoolAssignmentDetails, readingSchoolStudentRumbaIds, "users" );

                readingAssignUserId = getuserAssignmentId( reading_UserId );
                Log.message( readingAssignUserId + "AssignmentUserId" );

                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( reading_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( readingSchool ) );
                headers.put( LicenseAPIConstants.USERID, reading_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( readingAssignUserId );
                break;

            case "FOCUS_MATH":
                HashMap<String, String> focusMathSchoolStudentDetails = new HashMap<>();
                focusMathSchoolStudentDetails = generateRequestValues( focusMathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( focusMathSchool ) );
                focusMathSchoolStudentDetails = updateRequestBodyValues( focusMathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( focusMathSchool ) );
                focusMathSchoolStudentDetails = updateRequestBodyValues( focusMathSchoolStudentDetails, CreateStudentAPIConstants.TEACHER_ID,
                        SMUtils.getKeyValueFromResponse( focusMathTeacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                focusMathSchoolStudentDetails = updateRequestBodyValues( focusMathSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( focusMathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                focusMathSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, focusMathSchoolStudentDetails );
                String cmsResponse2 = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( focusMathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse2, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( focusMathSchool ) );

                focusMath_UserId = SMUtils.getKeyValueFromResponse( focusMathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID );
                focusMath_UserName = SMUtils.getKeyValueFromResponse( focusMathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new RBSUtils().updateUserOrgId( new RBSUtils().getUser( focusMath_UserId ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( focusMathSchool ) ) );

                HashMap<String, String> focusMathSchoolGroupDetails = new HashMap<>();
                HashMap<String, String> focusMathSchoolAssignmentDetails = new HashMap<>();
                List<String> focusMathSchoolStudentRumbaIds = new ArrayList<>();
                focusMathSchoolStudentRumbaIds.add( focusMath_UserId );
                focusMathSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( focusMathTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                focusMathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( focusMathTeacherDetails, "userId" ) );
                focusMathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( focusMathSchool ) );
                focusMathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, focusMathSchoolGroupDetails, focusMathSchoolStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }

                focusMathSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( focusMathSchool ) );
                focusMathSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( focusMathTeacherDetails, "userId" ) );
                focusMathSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH_1 );
                focusMathSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( focusMathTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                focusMathSchoolAssignmentResponse = new AssignmentAPI().assignAssignment( smUrl, focusMathSchoolAssignmentDetails, focusMathSchoolStudentRumbaIds, "users" );

                focusMathAssignUserId = getuserAssignmentId( focusMath_UserId );
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( focusMath_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( focusMathSchool ) );
                headers.put( LicenseAPIConstants.USERID, focusMath_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( focusMathAssignUserId );
                break;

            case "FOCUS_READING":
                HashMap<String, String> focusReadingSchoolStudentDetails = new HashMap<>();
                focusReadingSchoolStudentDetails = generateRequestValues( focusReadingSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( focusReadingSchool ) );
                focusReadingSchoolStudentDetails = updateRequestBodyValues( focusReadingSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( focusReadingSchool ) );
                focusReadingSchoolStudentDetails = updateRequestBodyValues( focusReadingSchoolStudentDetails, CreateStudentAPIConstants.TEACHER_ID,
                        SMUtils.getKeyValueFromResponse( focusReadingTeacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                focusReadingSchoolStudentDetails = updateRequestBodyValues( focusReadingSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( focusReadingTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                focusReadingSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, focusReadingSchoolStudentDetails );
                String cmsResponse3 = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( focusReadingSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse3, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( focusReadingSchool ) );

                focusReading_UserId = SMUtils.getKeyValueFromResponse( focusReadingSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID );
                focusReading_UserName = SMUtils.getKeyValueFromResponse( focusReadingSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new RBSUtils().updateUserOrgId( new RBSUtils().getUser( focusReading_UserId ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( focusReadingSchool ) ) );

                HashMap<String, String> focusReadingSchoolGroupDetails = new HashMap<>();
                HashMap<String, String> focusReadingSchoolAssignmentDetails = new HashMap<>();
                List<String> foucsReadingSchoolStudentRumbaIds = new ArrayList<>();
                foucsReadingSchoolStudentRumbaIds.add( focusReading_UserId );
                focusReadingSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( focusReadingTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                focusReadingSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( focusReadingTeacherDetails, "userId" ) );
                focusReadingSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( focusReadingSchool ) );
                focusReadingSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, focusReadingSchoolGroupDetails, foucsReadingSchoolStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }

                focusReadingSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( focusReadingSchool ) );
                focusReadingSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( focusReadingTeacherDetails, "userId" ) );
                focusReadingSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );
                focusReadingSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( focusReadingTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                focusReadingSchoolAssignmentResponse = new AssignmentAPI().assignAssignment( smUrl, focusReadingSchoolAssignmentDetails, foucsReadingSchoolStudentRumbaIds, "users" );

                focusReadingAssignUserId = getuserAssignmentId( focusReading_UserId );
                Log.message( focusReadingAssignUserId + "AssignmentUserId" );

                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( focusReading_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( focusReadingSchool ) );
                headers.put( LicenseAPIConstants.USERID, focusReading_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( focusReadingAssignUserId );
                break;

            case "FLEX":
                HashMap<String, String> flexSchoolStudentDetails = new HashMap<>();
                flexSchoolStudentDetails = generateRequestValues( flexSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                flexSchoolStudentDetails = updateRequestBodyValues( flexSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                flexSchoolStudentDetails = updateRequestBodyValues( flexSchoolStudentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( flexTeacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                flexSchoolStudentDetails = updateRequestBodyValues( flexSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                flexSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, flexSchoolStudentDetails );
                String cmsResponse4 = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse4, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );

                flex_UserId = SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID );
                flex_UserName = SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new RBSUtils().updateUserOrgId( new RBSUtils().getUser( flex_UserId ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) ) );

                HashMap<String, String> flexSchoolGroupDetails = new HashMap<>();
                HashMap<String, String> flexSchoolAssignmentDetails = new HashMap<>();
                List<String> flexSchoolStudentRumbaIds = new ArrayList<>();
                flexSchoolStudentRumbaIds.add( flex_UserId );
                flexSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                flexSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( flexTeacherDetails, "userId" ) );
                flexSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                flexSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, flexSchoolGroupDetails, flexSchoolStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }

                flexSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                flexSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( flexTeacherDetails, "userId" ) );
                flexSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                flexSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                flexSchoolAssignmentResponse = new AssignmentAPI().assignAssignment( smUrl, flexSchoolAssignmentDetails, flexSchoolStudentRumbaIds, "users" );

                flexAssignUserId = getuserAssignmentId( flex_UserId );
                Log.message( flexAssignUserId + "AssignmentUserId" );

                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( flex_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                headers.put( LicenseAPIConstants.USERID, flex_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( flexAssignUserId );
                break;
        }
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint, pathParams );
        int actualStatusCode = response.getStatusCode();
        Log.assertThat( actualStatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actualStatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actualStatusCode + "is not the same as expected status code " + expected_StatusCode );
    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51567", "SMK-51569", "Create end points to maintain number of used seats - math/reading", "Create end points to maintain number of used seats - flex", "API" }, priority = 1 )
    public void getStudentAssignmentLicenseUsageTest002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        // Creating Student, Group, Assigning assignment for a group and getting userassignmentId from DB
        HashMap<String, String> mathSchoolStudentDetails = new HashMap<>();
        HashMap<String, String> Dummy = new HashMap<>();

        mathSchoolStudentDetails = generateRequestValues( mathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, CreateStudentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
        mathSchoolStudentDetails = updateRequestBodyValues( mathSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        mathSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, mathSchoolStudentDetails );
        String cmsResponse1 = new RBSUtils().getUserWithUserService( SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID ) );
        Dummy = new RBSDataSetup().generateRequestValues( cmsResponse1, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( mathSchool ) );

        math_UserId = SMUtils.getKeyValueFromResponse( mathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + CreateStudentAPIConstants.PERSONID );
        math_UserName = SMUtils.getKeyValueFromResponse( mathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
        new RBSUtils().updateUserOrgId( new RBSUtils().getUser( math_UserId ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( LicenseAPIConstants.ZERO_LICENSE_ORG_ID ) );

        HashMap<String, String> mathSchoolGroupDetails = new HashMap<>();
        HashMap<String, String> mathSchoolAssignmentDetails = new HashMap<>();
        List<String> mathSchoolStudentRumbaIds = new ArrayList<>();
        mathSchoolStudentRumbaIds.add( math_UserId );
        mathSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userId" ) );
        mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        mathSchoolGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( new GroupAPI().createGroup( smUrl, mathSchoolGroupDetails, mathSchoolStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }

        mathSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        mathSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userId" ) );
        mathSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
        mathSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        mathSchoolAssignmentResponse = new AssignmentAPI().assignAssignment( smUrl, mathSchoolAssignmentDetails, mathSchoolStudentRumbaIds, "users" );

        mathAssignUserId = getuserAssignmentId( math_UserId );

        HashMap<String, String> headers = new HashMap<String, String>();
        List<String> pathParamsList = new ArrayList<String>();
        String endPoint = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        Log.testCaseInfo( testcaseName + testcaseDescription );

        switch ( scenarioType ) {
            case "INVALID_TOKEN":
                token = new RBSUtils().getAccessToken( math_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                headers.put( LicenseAPIConstants.USERID, math_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( mathAssignUserId );
                break;

            case "ACCESS_DENIED":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( math_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( focusMathSchool ) );
                headers.put( LicenseAPIConstants.USERID, math_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( mathAssignUserId );
                break;

            case "VALID_ORG_INVALID_USER":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( focusMath_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( focusMathSchool ) );
                headers.put( LicenseAPIConstants.USERID, math_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( mathAssignUserId );
                break;

            case "VALID_ORG_VALID_TEACHER":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                headers.put( LicenseAPIConstants.USERID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, "userId" ) );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( mathAssignUserId );
                break;

            case "NO_PATHPARAMS":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( math_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                headers.put( LicenseAPIConstants.USERID, math_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( "" );
                break;

            case "INVALID_PATHPARAMS":
                token = LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( math_UserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                headers.put( LicenseAPIConstants.USERID, math_UserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                pathParamsList.add( "500" );
                break;
        }

        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint, pathParams );
        int actualStatusCode = response.getStatusCode();
        Log.assertThat( actualStatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actualStatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actualStatusCode + "is not the same as expected status code " + expected_StatusCode );

    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC:001", "200", " Verify 200 status code and response body when student launching the 'SUCCESSMAKER DEFAULT MATH COURSES' with valid DEFAULT MATH license left for the orgainzation  ", "DEFAULT_MATH" },
                { "TC:002 ", "200", "Verify 200 status code and response body when student launching the 'SUCCESSMAKER DEFAULT READING COURSES' with valid SUCCESSMAKER DEFAULT READING license left for the orgainzation", "DEFAULT_READING" },
                { "TC:003 ", "200", "Verify 200 status code and response body when student launching the 'SUCCESSMAKER FOCUS MATH COURSES' with valid SUCCESSMAKER FOCUS MATH license left for the orgainzation", "FOCUS_MATH" },
                { "TC:004 ", "200", "Verify 200 status code and response body when student launching the 'SUCCESSMAKER FOCUS READING COURSES' with valid SUCCESSMAKER FOCUS READING license left for the orgainzation", "FOCUS_READING" },
                { "TC:005 ", "200", "Verify 200 status code and response body when student launching the 'SUCCESSMAKER COURSES' with valid SUCCESSMAKER FLEX license left for the orgainzation", "FLEX" }, };
        return data;
    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC: 007 ", "401", "Verify 401 status code and response body when valid header details and invalid authorization is given", "INVALID_TOKEN" },
                { "TC: 008 ", "403", "Verify 403 status code and response body when student user-id with ir-respective org-id is given in the headers", "ACCESS_DENIED" },
                { "TC: 009 ", "401", "Verify 401 status code and response body when invalid user-id and valid org-id is given in the headers", "VALID_ORG_INVALID_USER" },
                { "TC: 010 ", "401", "Verify 401 status code and response body when teacher user-id with respective org-id is given in the headers", "VALID_ORG_VALID_TEACHER" },
                { "TC: 011 ", "400", "Verify the 400 status code and response body, when assignmentUserId is empty", "NO_PATHPARAMS" },
                { "TC: 012 ", "400", "Verify the 400 status code and response body, when invalid assignmentUserId is  given", "INVALID_PATHPARAMS" } };

        return data;

    }

    /*
     * Get AssignmentUserId from the given studentId
     * 
     * @param studentRumbaId
     */
    public String getuserAssignmentId( String studentRumbaId ) {
        List<Object[]> userAssignmentId = SQLUtil.executeQuery( "select assignment_user_id from assignment_user where person_id ='" + studentRumbaId + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : userAssignmentId ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String userAssID = arrList.get( 0 );
        return userAssID;
    }

    public HashMap<String, String> generateRequestValues( HashMap<String, String> studentDetails, String key, String value ) {
        HashMap<String, String> generatedStudentDetails = studentDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, new Faker().name().firstName() );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, new Faker().name().firstName().substring( 1 ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, new Faker().name().lastName() );
        generatedStudentDetails.put( CreateStudentAPIConstants.GRADE, grade.FIRST.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, new Faker().name().username() );
        generatedStudentDetails.put( CreateStudentAPIConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( CreateStudentAPIConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( GetUserDetailsUsingUserServiceAPIConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( CreateStudentAPIConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        return generatedStudentDetails;
    }

    /**
     * This methods will update the details whatever given in Key and value
     * 
     * @param studentDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> updateRequestBodyValues( HashMap<String, String> studentDetails, String key, String value ) {
        HashMap<String, String> generatedStudentDetails = studentDetails;
        if ( generatedStudentDetails.containsKey( key ) ) {
            generatedStudentDetails.put( key, value );
        } else {
            generatedStudentDetails.put( key, value );
        }
        return generatedStudentDetails;
    }
}
