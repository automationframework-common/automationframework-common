package com.savvas.sm.api.tests.smnew.license;

import java.util.HashMap;

import org.json.JSONArray;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.student.bff.StudentLicenseCheck;

public class CheckAllFocusLicensesForStudent extends EnvProperties {

    private String smUrl;
    private String districtId;
    private String mathOrgId;
    private String focusMathOrgId;
    private String focusReadingOrgId;
    private String flexOrgId;

    private String mathOrgStudentUserName;
    private String focusMathOrgStudentUserName;
    private String focusReadingOrgStudentUserName;
    private String flexOrgStudentUserName;

    private String mathOrgStudentId;
    private String focusMathOrgStudentId;
    private String focusReadingOrgStudentId;
    private String flexOrgStudentId;

    RBSUtils rbsUtils = new RBSUtils();
    StudentLicenseCheck studentLicenseCheck = new StudentLicenseCheck();

    @BeforeClass
    private void initClass() {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );

        mathOrgId = rbsUtils.getOrganizationIDByName( districtId, RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );
        focusMathOrgId = rbsUtils.getOrganizationIDByName( districtId, RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL ) );
        focusReadingOrgId = rbsUtils.getOrganizationIDByName( districtId, RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL ) );
        flexOrgId = rbsUtils.getOrganizationIDByName( districtId, RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

        mathOrgStudentUserName = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 1, 1, 1, usernameSuffixTest );
        focusMathOrgStudentUserName = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 3, 1, 1, usernameSuffixTest );
        focusReadingOrgStudentUserName = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 4, 1, 1, usernameSuffixTest );
        flexOrgStudentUserName = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 5, 1, 1, usernameSuffixTest );

        mathOrgStudentId = rbsUtils.getUserIDByUserName( mathOrgStudentUserName );
        focusMathOrgStudentId = rbsUtils.getUserIDByUserName( focusMathOrgStudentUserName );
        focusReadingOrgStudentId = rbsUtils.getUserIDByUserName( focusReadingOrgStudentUserName );
        flexOrgStudentId = rbsUtils.getUserIDByUserName( String.format( flexOrgStudentUserName ) );

    }

    @Test ( groups = { "smoke_test_case", "GetFocusLicenseCheck", "P2", "SMK-70076" }, priority = 1 )
    public void tcCheckAllFocusLicenses001() {

        SMUtils.logDescriptionTC( "tcCheckAllFocusLicenses001 - Verify the API response is returned as true with 200 status code when passing Math Focus licensed orgId" );
        try {
            HashMap<String, String> response = studentLicenseCheck.checkAllFocusLicenses( smUrl, focusMathOrgStudentUserName, focusMathOrgStudentId, focusMathOrgId, focusMathOrgId );
            String valueFromResponse = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,areAllLicensesFocus" );

            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_OK ) && valueFromResponse.equals( "true" ), "API response is returned as true with 200 status code when passing Math Focus licensed orgId",
                    "API response is not returned as true with 200 status code when passing Math Focus licensed orgId" );
        } catch ( Exception e ) {
            e.getMessage();
        }
    }

    @Test ( groups = { "smoke_test_case", "GetFocusLicenseCheck", "P2", "SMK-70076" }, priority = 1 )
    public void tcCheckAllFocusLicenses002() {

        SMUtils.logDescriptionTC( "tcCheckAllFocusLicenses002 - Verify the API response is returned as true with 200 status code when passing Reading Focus licensed orgId" );
        try {
            HashMap<String, String> response = studentLicenseCheck.checkAllFocusLicenses( smUrl, focusReadingOrgStudentUserName, focusReadingOrgStudentId, focusReadingOrgId, focusReadingOrgId );
            String valueFromResponse = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,areAllLicensesFocus" );

            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_OK ) && valueFromResponse.equals( "true" ), "API response is returned as true with 200 status code when passing Reading Focus licensed orgId",
                    "API response is not returned as true with 200 status code when passing Reading Focus licensed orgId" );
        } catch ( Exception e ) {
            e.getMessage();
        }
    }

    @Test ( groups = { "smoke_test_case", "GetFocusLicenseCheck", "P2", "SMK-70076" }, priority = 1 )
    public void tcCheckAllFocusLicenses003() {

        SMUtils.logDescriptionTC( "tcCheckAllFocusLicenses003 - Verify the API response is returned as false with 200 status code when passing Flex licensed orgId" );
        try {
            HashMap<String, String> response = studentLicenseCheck.checkAllFocusLicenses( smUrl, flexOrgStudentUserName, flexOrgStudentId, flexOrgId, flexOrgId );
            String valueFromResponse = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,areAllLicensesFocus" );

            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_OK ) && valueFromResponse.equals( "false" ), "API response is returned as false with 200 status code when passing Flex licensed orgId",
                    "API response is not returned as false with 200 status code when passing Flex licensed orgId" );
        } catch ( Exception e ) {
            e.getMessage();
        }
    }

    @Test ( groups = { "smoke_test_case", "GetFocusLicenseCheck", "P2", "SMK-70076" }, priority = 1 )
    public void tcCheckAllFocusLicenses004() {

        SMUtils.logDescriptionTC( "tcCheckAllFocusLicenses004 - Verify the API response is returned as false with 200 status code when passing Default Math/Reading licensed orgId" );
        try {
            HashMap<String, String> response = studentLicenseCheck.checkAllFocusLicenses( smUrl, mathOrgStudentUserName, mathOrgStudentId, mathOrgId, mathOrgId );
            String valueFromResponse = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,areAllLicensesFocus" );

            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_OK ) && valueFromResponse.equals( "false" ), "API response is returned as false with 200 status code when passing Default Math/Reading licensed orgId",
                    "API response is not returned as false with 200 status code when passing Default Math/Reading licensed orgId" );
        } catch ( Exception e ) {
            e.getMessage();
        }
    }

    @Test ( groups = { "smoke_test_case", "GetFocusLicenseCheck", "P2", "SMK-70076" }, priority = 1 )
    public void tcCheckAllFocusLicenses005() {

        SMUtils.logDescriptionTC( "tcCheckAllFocusLicenses005 - Verify the API response is returned as true with 200 status code when passing both Focus Math and Focus Reading licensed orgIds" );
        try {
            HashMap<String, String> response = studentLicenseCheck.checkAllFocusLicenses( smUrl, focusMathOrgStudentUserName, focusMathOrgStudentId, focusMathOrgId, focusMathOrgId + "," + focusReadingOrgId );
            String valueFromResponse = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,areAllLicensesFocus" );

            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_OK ) && valueFromResponse.equals( "true" ),
                    "API response is returned as true with 200 status code when passing both Focus Math and Focus Reading licensed orgIds",
                    "API response is not returned as true with 200 status code when passing both Focus Math and Focus Reading licensed orgIds" );
        } catch ( Exception e ) {
            e.getMessage();
        }
    }

    @Test ( groups = { "smoke_test_case", "GetFocusLicenseCheck", "P2", "SMK-70076" }, priority = 1 )
    public void tcCheckAllFocusLicenses006() {

        SMUtils.logDescriptionTC( "tcCheckAllFocusLicenses006 - Verify the API response is returned as false with 200 status code when passing both Focus and Flex licensed orgIds" );
        try {
            HashMap<String, String> response = studentLicenseCheck.checkAllFocusLicenses( smUrl, focusMathOrgStudentUserName, focusMathOrgStudentId, focusMathOrgId, focusMathOrgId + "," + flexOrgId );
            String valueFromResponse = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,areAllLicensesFocus" );

            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_OK ) && valueFromResponse.equals( "false" ), "API response is returned as false with 200 status code when passing both Focus and Flex licensed orgIds",
                    "API response is not returned as false with 200 status code when passing both Focus and Flex licensed orgIds" );
        } catch ( Exception e ) {
            e.getMessage();
        }
    }

    @Test ( groups = { "GetFocusLicenseCheck", "P2", "SMK-70076" }, priority = 4 )
    public void tcCheckAllFocusLicenses007() {

        SMUtils.logDescriptionTC( "tcCheckAllFocusLicenses007 - Verify the API thro the error message with 200 status code when passing invalid userId" );
        try {
            HashMap<String, String> response = studentLicenseCheck.checkAllFocusLicenses( smUrl, focusMathOrgStudentUserName, focusMathOrgStudentId + "INVALID", focusMathOrgId, focusMathOrgId );
            String errorMessage = new JSONArray( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages" ) ).getJSONObject( 0 ).get( "message" ).toString();

            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_UNAUTHORIZED ) && errorMessage.equals( CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE ),
                    "API response is returned as true with 200 status code when passing Math Focus licensed orgId", "API response is not returned as true with 200 status code when passing Math Focus licensed orgId" );
        } catch ( Exception e ) {
            e.getMessage();
        }
    }

    @Test ( groups = { "GetFocusLicenseCheck", "P2", "SMK-70076" }, priority = 4 )
    public void tcCheckAllFocusLicenses008() {

        SMUtils.logDescriptionTC( "tcCheckAllFocusLicenses008 - Verify the API thro the error message with 200 status code when passing invalid orgId" );
        try {
            HashMap<String, String> response = studentLicenseCheck.checkAllFocusLicenses( smUrl, focusMathOrgStudentUserName, focusMathOrgStudentId, focusMathOrgId + "INVALID", focusMathOrgId );
            String errorMessage = new JSONArray( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages" ) ).getJSONObject( 0 ).get( "message" ).toString();

            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_FORBIDDAN ) && errorMessage.equals( CommonAPIConstants.UNEXPECTED_ERROR ),
                    "API response is returned as true with 200 status code when passing Math Focus licensed orgId", "API response is not returned as true with 200 status code when passing Math Focus licensed orgId" );
        } catch ( Exception e ) {
            e.getMessage();
        }
    }

}
