package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

public class StudentAssignmentsTest extends BaseTest {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    public String USERNAME_ERROR_MESSAGE = "Username already exists";
    String teacherDetails;
    String studentDetails;
    String orgId;
    String teacherId;
    String chromeBrowser = "Windows_10_Chrome_latest";
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    List<String> studentDetailsMap = new ArrayList<>();

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        studentDetails = RBSDataSetup.getMyStudent( school, username );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        orgId = RBSDataSetup.organizationIDs.get( school );

        IntStream.range( 1, 10 ).forEach( count -> {
            studentDetailsMap.add( RBSDataSetup.getMyStudent( school, username ) );
        } );

    }

    @Test ( description = "Verify the availablity of Assignments tab and 'Zero state' message when students does not have any assignments", groups = { "SMK-43618", "students", "assignments", "studentAssignments" }, priority = 1 )
    public void tc_StudentsAssignmentPage_001( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        // Get Test Data
        Log.testCaseInfo( "tc_StudentsAssignmentPage_001:  Verify the availablity of Assignments tab and 'Zero state' message when students does not have any assignments <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetailsMap.get( 0 ), RBSDataSetupConstants.USERNAME );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentID );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Verify the Title of Sub Navigation Menu
            SMUtils.logDescriptionTC( "SMK-12940 : Verify the availability of 'Assignments' tab in left panel for the students view page" );
            Log.assertThat( studentsPage.verifyAssignmentSubNav(), "Assignment SubNav is displayed in the Students page", "Assignment SubNav is not displayed in the Students page" );

            List<String> assignmentNames = studentsPage.getAssignedAssignmentNames();
            assignmentNames.forEach( studentsPage::removeStudentFromAssignment );

            // Verify the Zero state message (when no assignments is listing)
            SMUtils.logDescriptionTC( " SMK-12941 : Verify the 'Zero state' message when students does not have any assignments in the Students view page" );
            Log.assertThat( studentsPage.getZeroStateHeaderForAssignments().equals( Constants.Students.ZERO_STATE_FOR_ASSIGNMENTS_HEADER_MSG ), "The zero State  is present!", "The zero State  is not present" );
            Log.assertThat( studentsPage.getZeroStateMessageForAssignments().replaceAll( "[^a-zA-Z0-9]", " " ).contains( Constants.Students.ZERO_STATE_FOR_ASSIGNMENTS_DESC_MSG.replaceAll( "[^a-zA-Z0-9]", " " ) ), "The Zero State message is matching!",
                    "The Zero State message is not matching" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Navigate to students Assignment page and Verify the assignments", groups = { "SMK-43618", "students", "assignments", "studentAssignments" }, priority = 1 )
    public void tc_StudentsAssignmentPage_002( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        // Get Test Data
        Log.testCaseInfo( "tc_StudentsAssignmentPage_002: Navigate to students Assignment page and Verify the assignments <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            String studentID = SMUtils.getKeyValueFromResponse( studentDetailsMap.get( 0 ), RBSDataSetupConstants.USERNAME );

            // Navigate to courseWare tab and Courses
            tHomePage.topNavBar.getCourseListingPage();

            // Math Assignment
            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickCourseName( Constants.SM_FOCUS_READING_GRADE1 );
            coursepage.clickAssignBtn();
            coursepage.addCourseToStudents();

            // Navigate to Students Tab
            studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentID );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Verify all the assignments are showing in a list under the 'Title' column
            SMUtils.logDescriptionTC( "SMK-12942 : Verify the List of assignments are displaying correctly for a assigned student in the Students view page" );
            SMUtils.logDescriptionTC( "SMK-12945 : Verify the Assignment names are displaying properly under the 'Tittle' Field for the Assignments in Students view page" );
            Log.assertThat( studentsPage.getAssignedAssignmentNames().toString().equals( "[" + Constants.SM_FOCUS_READING_GRADE1 + "]" ), "Assignment is displayed in a list", "Assignment is not dispalyed in a list" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the all Fields in Students Assignment Page", groups = { "SMK-43618", "students", "assignments", "studentAssignments" }, priority = 1 )
    public void tc_StudentsAssignmentPage_003( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        // Get Test Data
        Log.testCaseInfo( "tc_StudentsAssignmentPage_003: Verify all the Fields and the corresponding Values are displaying for the Assignments in the Students view page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetailsMap.get( 2 ), RBSDataSetupConstants.USERNAME );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentID );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            SMUtils.logDescriptionTC( "SMK-12943 : Verify all the Fields and the correspoinding Values are displaying for the Assignments in the Students view pagee" );
            // Verifying the ColumnNames in the Assignment_Details_Page
            Log.assertThat( studentsPage.getColumnTitle().trim().equals( Constants.Students.ASSIGNMENT_TITLE ), "Title Column is displayed in the Assignment_Details_Page", "Title Column is not displayed in the Assignment_Details_Page" );
            Log.assertThat( studentsPage.getColumnLastSession().trim().equals( Constants.Students.ASSIGNMENT_LAST_SESSION ), "LAST_SESSION Column is displayed in the Assignment_Details_Page",
                    "LAST_SESSION Column is not displayed in the Assignment_Details_Page" );
            Log.assertThat( studentsPage.getColumnIPLevel().trim().equals( Constants.Students.ASSIGNMENT_IP_LEVEL ), "IP_LEVEL Column is displayed in the Assignment_Details_Page", "IP_LEVEL Column is not displayed in the Assignment_Details_Page" );
            Log.assertThat( studentsPage.getColumnAssignedLevel().trim().equals( Constants.Students.ASSIGNMENT_ASSIGNED_LEVEL ), "ASSIGNED_LEVEL Column is displayed in the Assignment_Details_Page",
                    "ASSIGNED_LEVEL Column is not displayed in the Assignment_Details_Page" );
            Log.assertThat( studentsPage.getColumnCurrentLevel().trim().equals( Constants.Students.ASSIGNMENT_CURRENT_LEVEL ), "CURRENT_LEVEL Column is displayed in the Assignment_Details_Page",
                    "CURRENT_LEVEL Column is not displayed in the Assignment_Details_Page" );
            Log.assertThat( studentsPage.getColumnGain().trim().equals( Constants.Students.ASSIGNMENT_GAIN ), "GAIN Column is displayed in the Assignment_Details_Page", "GAIN Column is not displayed in the Assignment_Details_Page" );
            Log.assertThat( studentsPage.getColumnPercentageCorrect().trim().equals( Constants.Students.ASSIGNMENT_PERCENTAGE ), "PERCENTAGE CORRECT Column is displayed in the Assignment_Details_Page",
                    "PERCENTAGE CORRECT Column is not displayed in the Assignment_Details_Page" );

            SMUtils.logDescriptionTC( " SMK-12944 : Verify the tooltip text displays for all the columns under the assignments session in Students view page " );
            Log.assertThat( studentsPage.isToolTipDisplayedForTitle(), "Tooltip is displayed for Title field", "Tooltip is Not displayed for Title field" );
            Log.assertThat( studentsPage.isTooltipDisplayedForLastSession(), "Tooltip is displayed for Last session field", "Tooltip is Not displayed for Last session field" );
            Log.assertThat( studentsPage.isTooltipDisplayedForIpLevel(), "Tooltip is displayed for IP Level field", "Tooltip is Not displayed for IP Level field" );
            Log.assertThat( studentsPage.isTooltipDisplayedForAssignedLevel(), "Tooltip is displayed for Assigned Level field", "Tooltip is Not displayed for Assigned Level field" );
            Log.assertThat( studentsPage.isTooltipDisplayedForCurrentLevel(), "Tooltip is displayed for Current Level field", "Tooltip is Not displayed for Current Level field" );
            Log.assertThat( studentsPage.isTooltipDisplayedForGain(), "Tooltip is displayed for Gain field", "Tooltip is Not displayed for Gain field" );
            Log.assertThat( studentsPage.isTooltipDisplayedForPercentageCorrect(), "Tooltip is displayed for Percentage Correct field", "Tooltip is Not displayed for Percentage correct field" );

            studentsPage.clickingThreedotsEllipsisForFirstAssignments();
            Log.assertThat( studentsPage.fluencyFilesInEllipsis().contains( Constants.Students.ASSIGNMENT_FLUENCY_FILES ), "Fluency_Files option is displayed", "Fluency_Files option is not displayed" );
            Log.assertThat( studentsPage.viewAssignmentInEllipsis().equals( Constants.Students.ASSIGNMENT_VIEW_ASSIGNMENT ), "View_Assignment option is displayed", "View_Assignment option is not displayed" );
            Log.assertThat( studentsPage.editAssignmentSettingsInEllipsis().equals( Constants.Students.ASSIGNMENT_EDIT_ASSIGNMENT_SETTINGS ), "Assignment_Settings option is displayed", "Assignment Settings option is not displayed" );
            Log.assertThat( studentsPage.pauseAssignmentForStudentInEllipsis().equals( Constants.Students.ASSIGNMENT_PAUSE_ASSIGNMENT_FOR_STUDENT ), "Pause_Assignment_For_Student option is displayed",
                    "Pause_Assignment_For_Student option is not displayed" );
            Log.assertThat( studentsPage.removeStudentFromAssignmentInEllipsis().equals( Constants.Students.ASSIGNMENT_REMOVE_STUDENT_FROM_ASSGINMENT ), "Remove_Student option is displayed", "Remove_Student option is not displayed" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user is able to Remove the student from assignments in students view page", groups = { "SMK-43618", "students", "assignments", "studentAssignments" }, priority = 1 )
    public void tc_StudentsAssignmentPage_004( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        // Get Test Data
        Log.testCaseInfo( "tc_StudentsAssignmentPage_004: SMK-12984 : Verify the user is able to Remove the student from assignments in students view page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetailsMap.get( 0 ), RBSDataSetupConstants.USERNAME );

            // Navigate to courseWare tab and Courses
            tHomePage.topNavBar.getCourseListingPage();

            CoursesPage coursepage = new CoursesPage( driver );

            // Math Assignment
            coursepage.clickCourseName( Constants.SM_FOCUS_READING_GRADE2 );
            coursepage.clickAssignBtn();
            coursepage.addCourseToStudents();

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentID );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Clicking on Ellipsis
            studentsPage.clickingThreedotsEllipsisFromAssignments( Constants.SM_FOCUS_READING_GRADE2 );

            // Removing the Student from assignment
            studentsPage.removeStudentFromAssignment( Constants.SM_FOCUS_READING_GRADE2 );
            List<String> assignmentNames = studentsPage.getAssignedAssignmentNames();
            Log.assertThat( !assignmentNames.contains( Constants.SM_FOCUS_READING_GRADE2 ), "Assignment is Removed from Student", "Assignment is not Removed from Student" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Fluencyfiles for the assignment in students view page", groups = { "SMK-43618", "students", "assignments", "studentAssignments" }, priority = 1 )
    public void tc_StudentsAssignmentPage_005( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        // Get Test Data
        Log.testCaseInfo( "tc_StudentsAssignmentPage_005: SMK-12978 : Verify the Fluencyfiles for the assignment in students view page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetailsMap.get( 0 ), RBSDataSetupConstants.USERNAME );

            // Navigate to courseWare tab and Courses
            tHomePage.topNavBar.getCourseListingPage();

            // SM_FOCUS_MATH_GRADE1 Assignment
            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickCourseName( Constants.SM_FOCUS_READING_GRADE3 );
            coursepage.clickAssignBtn();
            coursepage.addCourseToStudents();

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentID );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Viewing FluencyFiles
            studentsPage.fluencyFilesFromAssignment( Constants.SM_FOCUS_READING_GRADE3 );
            Log.assertThat( studentsPage.isDisplayedCancelBtnInPopup(), "FluencyFiles popup is displayed", "FluencyFiles popup is not displayed" );
            studentsPage.clickCancelButtonInFluencyFilesPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the View Assignments Details for the assignment which is assigned to student in students view page", groups = { "SMK-43618", "students", "assignments", "studentAssignments" }, priority = 1 )
    public void tc_StudentsAssignmentPage_006( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        // Get Test Data
        Log.testCaseInfo( "tc_StudentsAssignmentPage_006: SMK-12979 : Verify the View Assignments Details for the assignment which is assigned to student in students view page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetailsMap.get( 0 ), RBSDataSetupConstants.USERNAME );

            // Navigate to courseWare tab and Courses
            tHomePage.topNavBar.getCourseListingPage();

            // SM_FOCUS_READING_GRADE1 Assignment
            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickCourseName( Constants.SM_FOCUS_READING_GRADE4 );
            coursepage.clickAssignBtn();
            coursepage.addCourseToStudents();

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentID );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Clicking on Ellipsis
            studentsPage.clickingThreedotsEllipsisFromAssignments( Constants.SM_FOCUS_READING_GRADE4 );

            // View assignment
            AssignmentDetailsPage assignmentDetailsPage = studentsPage.viewAssignmnetFromStudent( Constants.SM_FOCUS_READING_GRADE4 );
            Log.assertThat( assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals( Constants.SM_FOCUS_READING_GRADE4 ), "Navigated to Assignment Details Page", "Not Navigated to Assignment Details Page" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-12980 : Verify the 'Edit Assignment Settings' for the assignment which is assigned to student in students view page", groups = { "SMK-43618", "students", "assignments", "studentAssignments" }, priority = 1 )
    public void tc_StudentsAssignmentPage_007( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        // Get Test Data
        Log.testCaseInfo( "tc_StudentsAssignmentPage_007: SMK-12980 : Verify the 'Edit Assignment Settings' for the assignment which is assigned to student in students view page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetailsMap.get( 0 ), RBSDataSetupConstants.USERNAME );

            // Navigate to courseWare tab and Courses
            tHomePage.topNavBar.getCourseListingPage();

            // SM_FOCUS_MATH_GRADE8 Assignment
            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickCourseName( Constants.SM_FOCUS_READING_GRADE5 );
            coursepage.clickAssignBtn();
            coursepage.addCourseToStudents();

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentID );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Clicking on Ellipsis
            studentsPage.clickingThreedotsEllipsisFromAssignments( Constants.SM_FOCUS_READING_GRADE5 );

            // Edit  assignment
            studentsPage.editAssignmentSettingsFromAssignment( Constants.SM_FOCUS_READING_GRADE5 );
            Log.assertThat( studentsPage.isDisplayedCloseIcon(), "Edit Assignment Settings popup is displayed", "Edit Assignment Settings popup is not displayed" );
            studentsPage.clickCloseIconInAssignmentsPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user is able to Pause or Resume the assignment in students view page ", groups = { "SMK-43618", "students", "assignments", "studentAssignments" }, priority = 1 )
    public void tc_StudentsAssignmentPage_008( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        // Get Test Data
        Log.testCaseInfo( "tc_StudentsAssignmentPage_008: SMK-12983 : Verify the user is able to Pause or Resume the assignment in students view page  <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetailsMap.get( 0 ), RBSDataSetupConstants.USERNAME );

            // Navigate to courseWare tab and Courses
            tHomePage.topNavBar.getCourseListingPage();

            // SM_FOCUS_READING_GRADE8 Assignment
            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickCourseName( Constants.SM_FOCUS_READING_GRADE6 );
            coursepage.clickAssignBtn();
            coursepage.addCourseToStudents();

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentID );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            // Clicking on Ellipsis
            studentsPage.clickingThreedotsEllipsisFromAssignments( Constants.SM_FOCUS_READING_GRADE6 );

            // Pause the Student from assignment
            studentsPage.pasueStudentFromAssignment( Constants.SM_FOCUS_READING_GRADE6 );
            Log.assertThat( studentsPage.isAssignmentPaused( Constants.SM_FOCUS_READING_GRADE6 ), "Assignment paused successfully", "Assignment has not Paused" );
            SMUtils.scrollDownPage( driver );

            // Resume the Student from assignment
            studentsPage.resumeStudentFromAssignment( Constants.SM_FOCUS_READING_GRADE8 );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Default Math Assignment - Verification of LastSession, IP Level,Assigned Level,Current Level,Gain and %correct fields in the assignment details page", groups = { "SMK-43618", "students", "assignments",
            "studentAssignments" }, priority = 2 )
    public void tc_StudentsAssignmentPage_009() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "tc_StudentsAssignmentPage_009: Default Math Assignment <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );
            String assignmentNameMath = "Math";

            // Navigate to Student Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to student
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            //Executing Math assignments in student dashboard
            executeSimulator( "Math", "Math" );

            //Navigate to teacher page again
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting IP Level, Gain value and other values of assignment from Assignments Tab's Assignment Details Page
            AssignmentsPage mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameMath );
            Map<String, String> studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            String studentDetails = studentDetailsMap.get( 0 );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetailsMap.get( 0 ), RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = mathAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );

            // Getting IP Level, Gain value and other values of assignment from Students Tab's Assignment Details Page
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            Map<String, String> studentIPandGainFromStudentsPage = new HashMap<>();
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( assignmentNameMath );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );

            SMUtils.logDescriptionTC( "SMK-12966 : Verify the Gain value is showing as '--'(double dash) for the Reading and Math Default courses" );
            SMUtils.logDescriptionTC( "SMK-12969 : Verify the '%Correct' field is showing as '--' (double dash) when the student has not started working on an assignments in the students view page" );
            SMUtils.logDescriptionTC( "SMK-12956 : Verify that the IP level is showing as '--'(double dash) for the 'Reading and Math Default courses', custom course by settingse" );
            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student does not started the Test",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are not matching - when student does not started the Test" );

            // Getting IP Level and Gain value of assignment from Assignments Tab's Assignment Details Page
            mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameMath );
            studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            studentDetails = studentDetailsMap.get( 1 );
            studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = mathAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );

            // Getting IP Level and Gain value of assignment from Students Tab's Assignment Details Page
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( assignmentNameMath );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );

            SMUtils.logDescriptionTC( "SMK-12958 : Verify that the IP level is showing as 'In-IP'(Intial Placement) for the 'Reading and Math Default courses' when student has started and working on the assignment in the Students view page" );

            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed" );
            Log.assertThat( studentsPage.getLastSessionDetails( assignmentNameMath ).toLowerCase().contains( "today" ) || studentsPage.getLastSessionDetails( assignmentNameMath ).toLowerCase().contains( "yesterday" ), "Last Session Filed is matched",
                    "Last Session Filed is not matched" );

            // Getting IP Level and Gain value of assignment from Assignments Tab's Assignment Details Page
            mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameMath );
            studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            studentDetails = studentDetailsMap.get( 2 );
            studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = mathAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );

            // Getting IP Level and Gain value of assignment from Students Tab's Assignment Details Page
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( assignmentNameMath );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );

            SMUtils.logDescriptionTC( "SMK-12968 : Verify the 'Gain' value is showing some non zero numeric value(Eg- 1.00) for the Reading and Math Default courses when IP is ON(default)" );
            SMUtils.logDescriptionTC( "SMK-12967 : Verify the Gain value is showing as some non zero numeric value(Eg- 1.00) for the Reading and Math Default courses" );
            SMUtils.logDescriptionTC( "SMK-12959 : Verify the IP Level value should not exceed the maximum value of 8.95 for Math Default assignment in the Students view page" );
            SMUtils.logDescriptionTC( "SMK-12970 : Verify the '%Correct' field is showing as some numeric value (Eg: 65%) when the student has started working on an assignments in the students view page" );
            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - When student is completed the Test",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are not matching - When student is completed the Test" );
            Log.assertThat( studentsPage.getLastSessionDetails( assignmentNameMath ).toLowerCase().contains( "today" ) || studentsPage.getLastSessionDetails( assignmentNameMath ).toLowerCase().contains( "yesterday" ), "Last Session Filed is matched",
                    "Last Session Filed is not matched" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Default Reading Assignment - Verification of LastSession, IP Level,Assigned Level,Current Level,Gain and %correct fields in the assignment details page", groups = { "SMK-43618", "students", "assignments",
            "studentAssignments" }, priority = 2 )
    public void tc_StudentsAssignmentPage_010() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tc_StudentsAssignmentPage_010: Default Reading Assignment <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );
            String assignmentNameReading = "Reading";

            // Navigate to Student Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Reading Course and assigning to student
            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            // Executing Reading assignments in student dashboard
            executeSimulator( "Reading", "Reading" );

            //Navigate to teacher page again
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-12966 : Verify the Gain value is showing as '--'(double dash) for the Reading and Math Default courses" );
            SMUtils.logDescriptionTC( "SMK-12969 : Verify the '%Correct' field is showing as '--' (double dash) when the student has not started working on an assignments in the students view page" );
            SMUtils.logDescriptionTC( "SMK-12956 : Verify that the IP level is showing as '--'(double dash) for the 'Reading and Math Default courses', custom course by settingse" );

            // Getting IP Level, Gain value and other values of assignment from Assignments Tab's Assignment Details Page
            AssignmentsPage readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameReading );
            Map<String, String> studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            String studentDetails = studentDetailsMap.get( 0 );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = readingAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );

            // Getting IP Level, Gain value and other values of assignment from Students Tab's Assignment Details Page
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            Map<String, String> studentIPandGainFromStudentsPage = new HashMap<>();
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( assignmentNameReading );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( assignmentNameReading ).toLowerCase() );
            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student does not started the Test",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are not matching - when student does not started the Test" );

            SMUtils.logDescriptionTC( "SMK-12961 : Verify the 'Assigned Level' fields and values are displaying properly for the assignments in the students view page " );
            SMUtils.logDescriptionTC( "SMK-12962 : Verify the 'Current Level' fields and values are displaying properly for the assignments in the students view page" );
            SMUtils.logDescriptionTC( "SMK-12963 : Verify the 'Gain' value is displayed correctly in the assignment for Students view page" );
            SMUtils.logDescriptionTC( "SMK-12968 : Verify the 'Gain' value is showing some non zero numeric value(Eg- 1.00) for the Reading and Math Default courses" );
            // Getting IP Level and Gain value of assignment from Assignments Tab's Assignment Details Page
            readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameReading );
            studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            studentDetails = studentDetailsMap.get( 1 );
            studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = readingAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );

            // Getting IP Level and Gain value of assignment from Students Tab's Assignment Details Page
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( assignmentNameReading );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( assignmentNameReading ).toLowerCase() );

            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed" );
            Log.assertThat( studentsPage.getLastSessionDetails( assignmentNameReading ).toLowerCase().contains( "today" ) || studentsPage.getLastSessionDetails( assignmentNameReading ).toLowerCase().contains( "yesterday" ), "Last Session Filed is matched",
                    "Last Session Filed is not matched" );

            SMUtils.logDescriptionTC( "SMK-12967 : Verify the Gain value is showing as some non zero numeric value(Eg- 1.00) for the Reading and Math Default courses" );
            SMUtils.logDescriptionTC( "SMK-12949 : Verify the IP Level field is displaying the values properly for the assignments in the students view page " );
            SMUtils.logDescriptionTC( "SMK-12960 : Verify the IP Level value should not exceed the maximum value of 8.25 for Reading assignment in the Students view page " );
            SMUtils.logDescriptionTC( "SMK-12970 : Verify the '%Correct' field is showing as some numeric value (Eg: 65%) when the student has started working on an assignments in the students view page" );

            // Getting IP Level and Gain value of assignment from Assignments Tab's Assignment Details Page
            readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentNameReading );
            studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            studentDetails = studentDetailsMap.get( 2 );
            studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = readingAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );

            // Getting IP Level and Gain value of assignment from Students Tab's Assignment Details Page
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( assignmentNameReading );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            SMUtils.logDescriptionTC( "SMK-12947 : Verify the 'Last Session' Field is showing as 'Today' in the assignments listing page for students" );
            SMUtils.logDescriptionTC( "SMK-12948 : Verify the 'Last Session' Field is showing as 'Yesterday' in the assignments listing page for students" );
            Log.message( studentsPage.getLastSessionDetails( assignmentNameReading ).toLowerCase() );

            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - When student is completed the Test",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are not matching - When student is completed the Test" );

            SMUtils.logDescriptionTC( "SMK-12946: Verify the 'Last Session' Field is showing as the Date format" );
            Log.assertThat( studentsPage.getLastSessionDetails( assignmentNameReading ).toLowerCase().contains( "today" ) || studentsPage.getLastSessionDetails( assignmentNameReading ).toLowerCase().contains( "yesterday" ), "Last Session Filed is matched",
                    "Last Session Filed is not matched" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Math Focus Course - Assignment - Verification of LastSession, IP Level,Assigned Level,Current Level,Gain and %correct fields in the assignment details page", groups = { "SMK-43618", "students", "assignments",
            "studentAssignments" }, priority = 2 )
    public void tc_StudentsAssignmentPage_011() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tc_StudentsAssignmentPage_011: Math Focus Course - Assignment <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Student Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Foucs Course and assigning to student
            CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            coursePage.clickCourseName( Constants.SM_FOCUS_MATH_GRADE8 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            // Executing the assignments in student dashboard
            executeSimulatorforCustomcourse( Constants.SM_FOCUS_MATH_GRADE8, "Math" );

            //Navigate to teacher page again
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-12951 : Verify that the IP level is 'NA' for the 'Math Focus course' when the student has not started working on the assignment in Students View page" );
            SMUtils.logDescriptionTC(
                    "SMK-12964 : Verify the Gain value is showing as 'NA' for the Reading and Math Focus courses, custom courses by skills and custom courses by standard assignments when the student has not started working on the assignment" );

            // Getting IP Level, Gain value and other values of assignment from Assignments Tab's Assignment Details Page
            AssignmentsPage mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_MATH_GRADE8 );
            Map<String, String> studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            String studentDetails = studentDetailsMap.get( 0 );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = mathAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );
            // Getting IP Level, Gain value and other values of assignment from Students Tab's Assignment Details Page
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            Map<String, String> studentIPandGainFromStudentsPage = new HashMap<>();
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( Constants.SM_FOCUS_MATH_GRADE8 );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( Constants.SM_FOCUS_MATH_GRADE8 ).toLowerCase() );

            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student does not started the Test",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are not matching - when student does not started the Test" );

            SMUtils.logDescriptionTC(
                    "SMK-12965 : Verify the Gain value is showing as 'NA' for the Reading and Math Focus courses, custom courses by skills and custom courses by standard assignments when the student has started the assignment and made some progress" );
            // Getting IP Level and Gain value of assignment from Assignments Tab's Assignment Details Page
            mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_MATH_GRADE8 );
            studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            studentDetails = studentDetailsMap.get( 1 );
            studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = mathAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );
            // Getting IP Level and Gain value of assignment from Students Tab's Assignment Details Page
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( Constants.SM_FOCUS_MATH_GRADE8 );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( Constants.SM_FOCUS_MATH_GRADE8 ).toLowerCase() );

            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed" );

            // Getting IP Level and Gain value of assignment from Assignments Tab's Assignment Details Page
            mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_MATH_GRADE8 );
            studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            studentDetails = studentDetailsMap.get( 2 );
            studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = mathAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );
            // Getting IP Level and Gain value of assignment from Students Tab's Assignment Details Page
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( Constants.SM_FOCUS_MATH_GRADE8 );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( Constants.SM_FOCUS_MATH_GRADE8 ).toLowerCase() );
            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - When student is completed the Test",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are not matching - When student is completed the Test" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Reading Focus Course- Assignment - Verification of LastSession, IP Level,Assigned Level,Current Level,Gain and %correct fields in the assignment details page", groups = { "SMK-43618", "students", "assignments",
            "studentAssignments" }, priority = 2 )
    public void tc_StudentsAssignmentPage_012() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tc_StudentsAssignmentPage_012: Reading Focus Course <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Student Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Reading Foucs Course and assigning to student
            CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            // Selecting ReadingFocus Course and assigning to student
            coursePage.clickCourseName( Constants.SM_FOCUS_READING_GRADE8 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            // Executing the assignments in student dashboard
            executeSimulatorforCustomcourse( Constants.SM_FOCUS_READING_GRADE8, "Reading" );

            //Navigate to teacher page again
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-12950 : Verify that the IP level is 'NA' for the 'Reading Focus course' when the student has not started working on the assignment in Students View page" );
            SMUtils.logDescriptionTC(
                    "SMK-12964 : Verify the Gain value is showing as 'NA' for the Reading and Math Focus courses, custom courses by skills and custom courses by standard assignments when the student has not started working on the assignment" );

            // Getting IP Level, Gain value and other values of assignment from Assignments Tab's Assignment Details Page
            AssignmentsPage readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_READING_GRADE8 );
            Map<String, String> studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            String studentDetails = studentDetailsMap.get( 0 );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = readingAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );

            // Getting IP Level, Gain value and other values of assignment from Students Tab's Assignment Details Page
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            Map<String, String> studentIPandGainFromStudentsPage = new HashMap<>();
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( Constants.SM_FOCUS_READING_GRADE8 );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( Constants.SM_FOCUS_READING_GRADE8 ) );

            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student does not started the Test",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are not matching - when student does not started the Test" );
            SMUtils.logDescriptionTC(
                    "SMK-12965 : Verify the Gain value is showing as 'NA' for the Reading and Math Focus courses, custom courses by skills and custom courses by standard assignments when the student has started the assignment and made some progress" );

            // Getting IP Level and Gain value of assignment from Assignments Tab's Assignment Details Page
            readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_READING_GRADE8 );
            studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            studentDetails = studentDetailsMap.get( 1 );
            studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = readingAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );

            // Getting IP Level and Gain value of assignment from Students Tab's Assignment Details Page
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( Constants.SM_FOCUS_READING_GRADE8 );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( Constants.SM_FOCUS_READING_GRADE8 ).toLowerCase() );

            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Math_Custom course by skills - Verification of LastSession, IP Level,Assigned Level,Current Level,Gain and %correct fields in the assignment details page", groups = { "SMK-43618", "students", "assignments",
            "studentAssignments" }, priority = 2 )
    public void tc_StudentsAssignmentPage_013() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tc_StudentsAssignmentPage_013: Math Custom course by skills <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Student Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            String mathCustomCourseBySkills = "Math_Custom_Course_By_Skills " + System.nanoTime();

            // create custom course by Skills and assigning to students
            coursePage.clickCourseName( Constants.MATH );
            coursePage.copyOfCourse( mathCustomCourseBySkills, Constants.SKILLS, Constants.MATH );
            teacherHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( mathCustomCourseBySkills );
            Log.message( "Created CustomCourseBySkills for Math : " + mathCustomCourseBySkills );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            // Executing the assignments in student dashboard
            executeSimulatorforCustomcourse( mathCustomCourseBySkills, "Math" );

            //Navigate to teacher page again
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            SMUtils.logDescriptionTC( "SMK-12953 : Verify that the IP level is 'NA' for the 'Math Custom course by Skills' when the student has not started working on the assignment in Students View page" );

            // Getting IP Level, Gain value and other values of MathFoucs assignment from Assignments Tab's Assignment Details Page
            AssignmentsPage mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( mathCustomCourseBySkills );
            Map<String, String> studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            String studentDetails = studentDetailsMap.get( 0 );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = mathAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );
            // Getting IP Level, Gain value and other values of MathFoucs assignment from Students Tab's Assignment Details Page
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            Map<String, String> studentIPandGainFromStudentsPage = new HashMap<>();
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( mathCustomCourseBySkills );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( mathCustomCourseBySkills ) );

            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student does not started the Test",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are not matching - when student does not started the Test" );

            // Getting IP Level and Gain value of assignment from Assignments Tab's Assignment Details Page
            mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( mathCustomCourseBySkills );
            studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            studentDetails = studentDetailsMap.get( 2 );
            studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = mathAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );
            // Getting IP Level and Gain value of assignment from Students Tab's Assignment Details Page
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( mathCustomCourseBySkills );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( mathCustomCourseBySkills ).toLowerCase() );
            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Reading_Custom course by skills - Verification of LastSession, IP Level,Assigned Level,Current Level,Gain and %correct fields in the assignment details page", groups = { "SMK-43618", "students", "assignments",
            "studentAssignments" }, priority = 2 )
    public void tc_StudentsAssignmentPage_014() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tc_StudentsAssignmentPage_014: Reading Custom course by skills <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Student Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // create Math custom course by Skills
            coursePage.clickReadingCourse();
            coursePage.clickMakeCopyBtn();
            String courseNameReadingSkill = Constants.CUSTOM_BY_SKILLS_READING_COURSE + System.nanoTime();
            coursePage.enterCourseName( courseNameReadingSkill );
            coursePage.coursesRadioBtn( Constants.SKILLS, courseNameReadingSkill );
            coursePage.courseBasedOnSkills( Constants.SKILLS, Constants.READING );

            // Assigning Course to student
            coursePage.clickCourseName( courseNameReadingSkill );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            // Executing the assignments in student dashboard
            executeSimulatorforCustomcourse( courseNameReadingSkill, "Reading" );

            //Navigate to teacher page again
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            SMUtils.logDescriptionTC( "SMK-12952 : Verify that the IP level is 'NA' for the 'Reading Custom course by Skills' when the student has not started working on the assignment in Students View page " );

            // Getting IP Level, Gain value and other values of assignment from Assignments Tab's Assignment Details Page
            AssignmentsPage readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( courseNameReadingSkill );
            Map<String, String> studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            String studentDetails = studentDetailsMap.get( 0 );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = readingAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );
            // Getting IP Level, Gain value and other values of assignment from Students Tab's Assignment Details Page
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            Map<String, String> studentIPandGainFromStudentsPage = new HashMap<>();
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( courseNameReadingSkill );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student does not started the Test",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are not matching - when student does not started the Test" );

            // Getting IP Level and Gain value of assignment from Assignments Tab's Assignment Details Page
            readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( courseNameReadingSkill );
            studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            studentDetails = studentDetailsMap.get( 2 );
            studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = readingAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );
            // Getting IP Level and Gain value of assignment from Students Tab's Assignment Details Page
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( courseNameReadingSkill );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( courseNameReadingSkill ).toLowerCase() );

            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Math Custom course by Standards - Assignment - Verification of LastSession, IP Level,Assigned Level,Current Level,Gain and %correct fields in the assignment details page", groups = { "SMK-43618", "students", "assignments",
            "studentAssignments" }, priority = 2 )
    public void tc_StudentsAssignmentPage_015() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tc_StudentsAssignmentPage_015: Math Custom course by Standards <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Student Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // create Math custom course by Standards
            coursePage.clickMathCourse();
            coursePage.clickMakeCopyBtn();
            Timestamp timestamp = new Timestamp( System.currentTimeMillis() );
            String courseNAme = Constants.CUSTOM_BY_STANDARDS_MATH_COURSE + timestamp.getTime();

            coursePage.enterCourseName( courseNAme );
            coursePage.coursesRadioBtn( Constants.STANDARDS, courseNAme );
            coursePage.courseBasedOnDefaultOrFocusMathStandards( Constants.STANDARDS, Constants.MATH );

            //Assigning Course to students
            coursePage.clickCourseName( courseNAme );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            // Executing the assignments in student dashboard
            executeSimulatorforCustomcourse( courseNAme, "Math" );

            //Navigate to teacher page again
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            SMUtils.logDescriptionTC( "SMK-12955 : Verify that the IP level is 'NA' for the 'Math Custom course by Standards' when the student has not started working on the assignment in Students View page" );

            // Getting IP Level, Gain value and other values of assignment from Assignments Tab's Assignment Details Page
            AssignmentsPage mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( courseNAme );
            Map<String, String> studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            String studentDetails = studentDetailsMap.get( 0 );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = mathAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );
            // Getting IP Level, Gain value and other values of assignment from Students Tab's Assignment Details Page
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            Map<String, String> studentIPandGainFromStudentsPage = new HashMap<>();

            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE );
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( courseNAme );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );

            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student does not started the Test",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are not matching - when student does not started the Test" );

            // Getting IP Level and Gain value of assignment from Assignments Tab's Assignment Details Page
            mathAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            mathAssignmentDetailsPage = mathAssignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_MATH_GRADE8 );
            studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            studentDetails = studentDetailsMap.get( 2 );
            studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = mathAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );
            // Getting IP Level and Gain value of assignment from Students Tab's Assignment Details Page
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( courseNAme );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( courseNAme ).toLowerCase() );
            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Reading Custom course by Standards - Assignment - Verification of LastSession, IP Level,Assigned Level,Current Level,Gain and %correct fields in the assignment details page", groups = { "SMK-43618", "students", "assignments",
            "studentAssignments" }, priority = 2 )
    public void tc_StudentsAssignmentPage_016() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tc_StudentsAssignmentPage_016: Reading Custom course by Standards <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Student Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // create Math custom course by Standards
            coursePage.clickReadingCourse();
            coursePage.clickMakeCopyBtn();
            String courseName = Constants.CUSTOM_BY_STANDARDS_READING_COURSE + System.nanoTime();
            coursePage.enterCourseName( courseName );
            coursePage.coursesRadioBtn( Constants.STANDARDS, courseName );
            coursePage.courseBasedOnDefaultOrFocusReadingStandards( Constants.STANDARDS, Constants.READING );

            //Assigning Course to students
            coursePage.clickCourseName( courseName );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            // Executing the assignments in student dashboard
            executeSimulatorforCustomcourse( courseName, "Reading" );

            //Navigate to teacher page again
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            SMUtils.logDescriptionTC( "SMK-12954 : Verify that the IP level is 'NA' for the 'Reading Custom course by Standards' when the student has not started working on the assignment in Students View page in Students View page" );

            // Getting IP Level, Gain value and other values of assignment from Assignments Tab's Assignment Details Page
            AssignmentsPage readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( courseName );
            Map<String, String> studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            String studentDetails = studentDetailsMap.get( 0 );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = readingAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );
            // Getting IP Level, Gain value and other values of assignment from Students Tab's Assignment Details Page
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            Map<String, String> studentIPandGainFromStudentsPage = new HashMap<>();
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( courseName );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student does not started the Test",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are not matching - when student does not started the Test" );

            // Getting IP Level and Gain value of assignment from Assignments Tab's Assignment Details Page
            readingAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            readingAssignmentDetailsPage = readingAssignmentsPage.viewAssignmentDetailsByAssignmentName( courseName );
            studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
            studentDetails = studentDetailsMap.get( 2 );
            studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            studentIPandGainFromAssignmentDetailsPage = readingAssignmentDetailsPage.getStudentAssignmentDetailsPageIPLevelandGain( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.FIRSTNAME ),
                    SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.MIDDLENAME ), SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.LASTNAME ) );
            // Getting IP Level and Gain value of assignment from Students Tab's Assignment Details Page
            studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );
            studentIPandGainFromStudentsPage = studentsPage.getStudentAssignmentDetailsPageIPLevelandGain( courseName );
            Log.message( "Assignment Details Page Values : " + studentIPandGainFromAssignmentDetailsPage.toString() );
            Log.message( "Student's page Assignment Details Values:" + studentIPandGainFromStudentsPage.toString() );
            Log.message( studentsPage.getLastSessionDetails( courseName ).toLowerCase() );
            Log.assertThat( SMUtils.compareTwoHashMap( studentIPandGainFromAssignmentDetailsPage, studentIPandGainFromStudentsPage ),
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed",
                    "IP level,Assigned Level,Current Level, Gain and Percentage correct values are matching - when student has started the Test but not completed" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Sorting order for all Fields in Students Assignment Page", groups = { "SMK-43618", "students", "assignments", "studentAssignments" }, priority = 3 )
    public void tc_StudentsAssignmentPage_017() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        // Get Test Data
        Log.testCaseInfo( "tc_StudentsAssignmentPage_017: Verify the Sorting order for all Fields in Students Assignment Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetailsMap.get( 0 ), RBSDataSetupConstants.USERNAME );

            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            // Navigate to Ellipsis Menu
            studentsPage.clickviewStudentByEllipsis( studentID );

            // Navigate to 'Assignment' Side Navigation menu
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.nap( 2 );
            SMUtils.scrollDownPage( driver );

            SMUtils.logDescriptionTC( "SMK-12971 : Verify the sorting order of 'Title' column" );
            List<String> listFromUI = studentsPage.getAssignedAssignmentNames();
            Log.message( "List from UI:" + listFromUI );
            Collections.sort( listFromUI );
            Log.message( "Sorted list using collection.sort :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_TITLE ); //For Ascending
            List<String> afterAscendingSortedList = studentsPage.getAssignedAssignmentNames();
            Log.message( "After Ascending sorted list:" + afterAscendingSortedList );
            Log.assertThat( listFromUI.equals( afterAscendingSortedList ), "Title is sorted by Ascending order", "Title is not sorted by Ascending order" );
            Collections.sort( listFromUI );
            Collections.reverse( listFromUI );
            Log.message( "Sorted list using Collection.reverse :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_TITLE ); //For Descending
            List<String> afterDescendingSortedList = studentsPage.getAssignedAssignmentNames();
            Log.message( "After Descending sorted list:" + afterDescendingSortedList );
            Log.assertThat( listFromUI.equals( afterDescendingSortedList ), "Title is sorted by Descending order", "Title is not sorted by Descending order" );

            SMUtils.logDescriptionTC( "SMK-12972 : Verify the sorting order of 'Last Session' column" );
            listFromUI = studentsPage.getLastSessionValues();
            Log.message( "List from UI:" + listFromUI );
            Collections.sort( listFromUI );
            Log.message( "Sorted list using collection.sort :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_LAST_SESSION ); //For Ascending
            afterAscendingSortedList = studentsPage.getLastSessionValues();
            Log.message( "After Ascending sorted list:" + afterAscendingSortedList );
            Log.assertThat( listFromUI.equals( afterAscendingSortedList ), "Last session values are sorted by Ascending order", "Last Session values are not sorted by Ascending order" );
            Collections.sort( listFromUI );
            Collections.reverse( listFromUI );
            Log.message( "Sorted list using Collection.reverse :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_LAST_SESSION ); //For Descending
            afterDescendingSortedList = studentsPage.getLastSessionValues();
            Log.message( "After Descending sorted list:" + afterDescendingSortedList );
            Log.assertThat( listFromUI.equals( afterDescendingSortedList ), "Last session values are sorted by Descending order", "Last Session values are not sorted by Descending order" );

            SMUtils.logDescriptionTC( "SMK-12973 : Verify the sorting order of 'IP Level' column" );
            listFromUI = studentsPage.getIpLevelValues();
            Log.message( "List from UI:" + listFromUI );
            Collections.sort( listFromUI );
            Log.message( "Sorted list using collection.sort :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_IP_LEVEL ); //For Ascending
            afterAscendingSortedList = studentsPage.getIpLevelValues();
            Log.message( "After Ascending sorted list:" + afterAscendingSortedList );
            Log.assertThat( listFromUI.equals( afterAscendingSortedList ), "IPLevel is sorted by Ascending order", "IPLevel is not sorted by Ascending order" );
            Collections.sort( listFromUI );
            Collections.reverse( listFromUI );
            Log.message( "Sorted list using Collection.reverse :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_IP_LEVEL ); //For Descending
            afterDescendingSortedList = studentsPage.getIpLevelValues();
            Log.message( "After Descending sorted list:" + afterDescendingSortedList );
            Log.assertThat( listFromUI.equals( afterDescendingSortedList ), "IPLevel is sorted by Descending order", "IPLevel is not sorted by Descending order" );

            SMUtils.logDescriptionTC( "SMK-12974 : Verify the sorting order of 'Assigned Level' column" );
            listFromUI = studentsPage.getAssignedLevelValues();
            Log.message( "List from UI:" + listFromUI );
            Collections.sort( listFromUI );
            Log.message( "Sorted list using collection.sort :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_ASSIGNED_LEVEL ); //For Ascending
            afterAscendingSortedList = studentsPage.getAssignedLevelValues();
            Log.message( "After Ascending sorted list:" + afterAscendingSortedList );
            Log.assertThat( listFromUI.equals( afterAscendingSortedList ), "AssignedLevel is sorted by Ascending order", "AssignedLevel is not sorted by Ascending order" );
            Collections.sort( listFromUI );
            Collections.reverse( listFromUI );
            Log.message( "Sorted list using Collection.reverse :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_ASSIGNED_LEVEL ); //For Descending
            afterDescendingSortedList = studentsPage.getAssignedLevelValues();
            Log.message( "After Descending sorted list:" + afterDescendingSortedList );
            Log.assertThat( listFromUI.equals( afterDescendingSortedList ), "AssignedLevel is sorted by Descending order", "AssignedLevel is not sorted by Descending order" );

            SMUtils.logDescriptionTC( "SMK-12975 : Verify the sorting order of 'Current Level' column" );
            listFromUI = studentsPage.getCurrentLevelValues();
            Log.message( "List from UI:" + listFromUI );
            Collections.sort( listFromUI );
            Log.message( "Sorted list using collection.sort :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_CURRENT_LEVEL ); //For Ascending
            afterAscendingSortedList = studentsPage.getCurrentLevelValues();
            Log.message( "After Ascending sorted list:" + afterAscendingSortedList );
            Log.assertThat( listFromUI.equals( afterAscendingSortedList ), "CurrentLevel is sorted by Ascending order", "CurrentLevel is not sorted by Ascending order" );
            Collections.sort( listFromUI );
            Collections.reverse( listFromUI );
            Log.message( "Sorted list using Collection.reverse :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_CURRENT_LEVEL ); //For Descending
            afterDescendingSortedList = studentsPage.getCurrentLevelValues();
            Log.message( "After Descending sorted list:" + afterDescendingSortedList );
            Log.assertThat( listFromUI.equals( afterDescendingSortedList ), "CurrentLevel is sorted by Descending order", "CurrentLevel is not sorted by Descending order" );

            SMUtils.logDescriptionTC( "SMK-12976 : Verify the sorting order of 'Gain' column" );
            listFromUI = studentsPage.getGainValues();
            Log.message( "List from UI:" + listFromUI );
            Collections.sort( listFromUI );
            Log.message( "Sorted list using collection.sort :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_GAIN ); //For Ascending
            afterAscendingSortedList = studentsPage.getGainValues();
            Log.message( "After Ascending sorted list:" + afterAscendingSortedList );
            Log.assertThat( listFromUI.equals( afterAscendingSortedList ), "Gain value is sorted by Ascending order", "Gain value is not sorted by Ascending order" );
            Collections.sort( listFromUI );
            Collections.reverse( listFromUI );
            Log.message( "Sorted list using Collection.reverse :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_GAIN ); //For Descending
            afterDescendingSortedList = studentsPage.getGainValues();
            Log.message( "After Descending sorted list:" + afterDescendingSortedList );
            Log.assertThat( listFromUI.equals( afterDescendingSortedList ), "Gain value is sorted by Descending order", "Gain value is not sorted by Descending order" );

            SMUtils.logDescriptionTC( "SMK-12977 : Verify the sorting order of '% Correct' column" );
            listFromUI = studentsPage.getPercentageCorrectValues();
            Log.message( "List from UI:" + listFromUI );
            Collections.sort( listFromUI );
            Log.message( "Sorted list using collection.sort :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_PERCENTAGE ); //For Ascending
            afterAscendingSortedList = studentsPage.getPercentageCorrectValues();
            Log.message( "After Ascending sorted list:" + afterAscendingSortedList );
            Log.assertThat( listFromUI.equals( afterAscendingSortedList ), "% Correct Field is sorted by Ascending order", "% Correct Field is not sorted by Ascending order" );
            Collections.sort( listFromUI );
            Collections.reverse( listFromUI );
            Log.message( "Sorted list using Collection.reverse :" + listFromUI );
            studentsPage.sortingColumnnHeaders( Constants.Students.ASSIGNMENT_PERCENTAGE ); //For Descending
            afterDescendingSortedList = studentsPage.getPercentageCorrectValues();
            Log.message( "After Descending sorted list:" + afterDescendingSortedList );
            Log.assertThat( listFromUI.equals( afterDescendingSortedList ), "% Correct Field is sorted by Descending order", "% Correct Field is not sorted by Descending order" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the completed tag and paused tag in Students Assignment Page", groups = { "SMK-43618", "students", "assignments", "studentAssignments" }, priority = 3 )
    public void tc_StudentsAssignmentPage_018() throws Exception {

        // Get driver
        EventFiringWebDriver driver = null;
        // Get driver
        EventFiringWebDriver chromeDriver = new EventFiringWebDriver( WebDriverFactory.get( chromeBrowser ) );
        EventListener eventListner = new EventListener();
        chromeDriver.register( eventListner );
        // Get Test Data
        Log.testCaseInfo( "tc_StudentsAssignmentPage_018: Verify the completed tag and paused tag in Students Assignment Page <small><b><i>[" + browser + "]</b></i></small>" );

        String courseNameSingleLO = "MathSingleLOCourse1__" + RandomStringUtils.randomAlphanumeric( 5 );

        try {

            // login to the app
            LoginPage smLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Constants.MATH );
            String createCourseBySkill = new CourseAPI().createCourseBySkill( smUrl, new RBSUtils().getAccessToken( username, password ), DataSetupConstants.MATH, teacherId, orgId, "", courseNameSingleLO );
            Log.message( " Created Course - " + createCourseBySkill );
            teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Assigning Math Courses to Students
            coursePage.clickCourseName( courseNameSingleLO );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            chromeDriver.quit();

            //Executing Math assignments in student dashboard
            executeSinglLOSimulator( courseNameSingleLO, "Math" );
            Log.message( "Executing the courses using simulator" );

            //Navigate to teacher page again
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Viewing the Assignment Details Page from Students Tab's
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            String studentDetails = studentDetailsMap.get( 0 );
            String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );

            studentsPage.clickviewStudentByEllipsis( studentID );
            studentsPage.clickSubNavigation( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB );
            SMUtils.scrollDownPage( driver );

            SMUtils.logDescriptionTC( "SMK-12982 : Verify the Paused tag and Completed tag for the assignment in students view page" );
            // Clicking on Ellipsis and Pause the Student from assignment
            studentsPage.clickingThreedotsEllipsisFromAssignments( courseNameSingleLO );
            studentsPage.pasueStudentFromAssignment( courseNameSingleLO );
            Log.assertThat( studentsPage.isAssignmentPaused( courseNameSingleLO ), "Assignment paused successfully", "Assignment has not Paused" );
            Log.assertThat( studentsPage.checkPausedTag(), "Paused tag displayed", "Paused tag not displayed" );
            Log.assertThat( studentsPage.checkPausedTagColor().equals( Constants.PAUSED_COLOR ), "Paused tag displayed in correct color", "Paused tag not displayed correctly" );

            SMUtils.logDescriptionTC( "SMK-12981 : Verify the Completed tag for the assignment in students view page" );
            Log.assertThat( studentsPage.isAssignmentCompleted( courseNameSingleLO ), "Assignment Completed successfully", "Assignment has not Completed" );
            Log.assertThat( studentsPage.checkCompletedTag(), "Completed tag displayed", "Completed tag not displayed" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public void executeSinglLOSimulator( String assignmentName, String assignmentType ) throws Exception {
        WebDriver driver = WebDriverFactory.get( chromeBrowser );
        String studentDetails = studentDetailsMap.get( 0 );
        String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
        StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
        if ( assignmentType.equals( "Math" ) ) {
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentName, "56", "1", "80" );
        } else {
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentName, "67", "1", "1" );
        }
        driver.quit();
    }

    public void executeSimulator( String assignmentName, String assignmentType ) throws Exception {
        WebDriver driver = WebDriverFactory.get( chromeBrowser );
        String studentDetails = studentDetailsMap.get( 1 );
        String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
        StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
        if ( assignmentType.equals( "Math" ) ) {
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentName, "56", "1", "1" );
        } else {
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentName, "67", "1", "1" );
        }
        driver.quit();

        driver = WebDriverFactory.get( chromeBrowser );
        studentDetails = studentDetailsMap.get( 2 );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        smStudentLoginPage = new LoginPage( driver, smUrl ).get();
        StudentDashboardPage studentDashboardPageForThirdStudent = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
        IntStream.rangeClosed( 1, 3 ).forEach( exeCount -> {
            try {
                if ( assignmentType.equals( "Math" ) ) {
                    studentDashboardPageForThirdStudent.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentName, "94", "2", "26" );
                } else {
                    studentDashboardPageForThirdStudent.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentName, "86", "2", "20" );
                }
            } catch ( IOException e ) {

                Log.message( "Error occurred while running the simulator" );
            }
        } );
        driver.quit();
    }

    public void executeSimulatorforCustomcourse( String assignmentName, String assignmentType ) throws Exception {
        WebDriver driver = WebDriverFactory.get( chromeBrowser );
        String studentDetails = studentDetailsMap.get( 1 );
        String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
        StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
        if ( assignmentType.equals( "Math" ) ) {
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentName, "45", "1", "5" );
        } else {
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), assignmentName, "58", "1", "5" );
        }
        driver.quit();
    }

    public HashMap<String, HashMap<String, String>> getStudentIPandGainFromAPI() throws Exception {
        // headers

        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        String endpoint = "null";
        Log.message( "username = " + username );
        String token = new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsMap.get( 0 ), RBSDataSetupConstants.USERID ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        assignmentDetails.put( AssignmentAPIConstants.STUDENT_ID, studentRumbaIds.get( 0 ) );
        endpoint = AssignmentAPIConstants.GET_STUDENT_ASSIGNMENT_DETAILS_BY_STUDENT_ID;
        endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{studentID}",
                assignmentDetails.get( AssignmentAPIConstants.STUDENT_ID ) );

        HashMap<String, String> assignmentByStudent = new AssignmentAPI().getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );
        Log.message( assignmentByStudent.toString() );
        // getting list of IPLevel
        HashMap<String, String> ipLevel = new HashMap<>();
        HashMap<String, String> gain = new HashMap<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( assignmentByStudent.get( Constants.BODY ), Constants.ASSIGNMENTNAME ) ).forEach( index -> {
            String courseDetails = SMUtils.getKeyValueFromJsonArray( assignmentByStudent.get( Constants.BODY ), "courseDetail", index );
            ipLevel.put( SMUtils.getKeyValueFromResponse( courseDetails, Constants.ASSIGNMENTNAME ), SMUtils.getKeyValueFromJsonArray( assignmentByStudent.get( Constants.BODY ), "ipLevel", index ) );
            gain.put( SMUtils.getKeyValueFromResponse( courseDetails, Constants.ASSIGNMENTNAME ), SMUtils.getKeyValueFromJsonArray( assignmentByStudent.get( Constants.BODY ), "gain", index ) );
        } );
        HashMap<String, HashMap<String, String>> studentIPandGainFromAPI = new HashMap<>();
        studentIPandGainFromAPI.put( Constants.IPLEVEL, ipLevel );
        studentIPandGainFromAPI.put( Constants.GAIN, gain );
        return studentIPandGainFromAPI;

    }
}
