package com.savvas.sm.teacher.ui.tests.MasterySuite;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryDetailsPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class MasteryHierarchyViewStudentList extends BaseTest {

    private String smUrl;
    private String browser;
    private static String sessionCookie;
    /*
     * List<String> expectedCourseTypesInDropdown =
     * Arrays.asList("Focus Courses", "Default Courses", "Custom Courses",
     * "All Courses");
     */
    private String username;
    private String password;
    private String schoolID;
    private String lName;
    private String fName;
    private String teacherID;
    private String studentID1;
    private String studentID2;
    private String studentUsername1 = null;
    private String studentUsername2 = null;
    private String studentUsername3 = null;
    private String studentUsername4 = null;
    private String stuFName1;
    private String stuFName2;
    private String personID1;
    private String teacherDetails;
    private String studentDetails;
    private String groupDetails;
    private String groupName;
    String chromePlatform = "Windows_10_Chrome_latest";
    BaseAPITest baseApiObject = new BaseAPITest();
    UserSqlHelper userSqlHelper = new UserSqlHelper();
    String teacherId;
    String orgId;

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher91" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        studentUsername1 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,userName" );
        studentUsername2 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student2" ), "data,userName" );
        studentUsername3 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student3" ), "data,userName" );
        studentUsername4 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student4" ), "data,userName" );
        teacherId = userSqlHelper.getPersonID( username );
        orgId = userSqlHelper.getOrgId( teacherId );
        password = DataSetupConstants.DEFAULT_PASSWORD;
        groupDetails = DataSetup.teacherGroupMap.get( username ).get( username );
        groupName = SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", 1 );
    }

    @Test ( priority = 1, description = "Datasetup for Mastery LO View page" )
    public void tcMasteryDataSetup( ITestContext context ) throws Exception {
        String sessionCookie = baseApiObject.getJessionCookie( smUrl, username, password );
        String Math_Assignment = "MathSingleLOCourse1__" + System.nanoTime();
        String Math_Assignment2 = "MathSingleLOCourse2__" + System.nanoTime();
        String Reading_Assignment = "ReadingSingleLOCourse__" + System.nanoTime();
        String course = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.ONE_LO, Math_Assignment );
        String course2 = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.ONE_LO, Math_Assignment2 );
        String course3 = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, Reading_Assignment );

        // Get driver
//        WebDriver driver = null;
	
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner); //for simulator run
  
        Log.testCaseInfo( "Test Data generation for Mastery Details LO View Page." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            context.setAttribute( "Math_Assignment", Math_Assignment );
            context.setAttribute( "Math_Assignment2", Math_Assignment2 );

            // Assigning Math Courses to Students
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Math_Assignment );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Assigning Math Courses to Students
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Math_Assignment2 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Assigning Math Courses to Students
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Reading_Assignment );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            chromeDriver.quit();

            Log.message( "Executing the courses using simulator" );

            //Login as student1 to the executeCourses
            Log.message( "Executing the courses using simulator for student1" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername1, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "100", "1", "20" );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment2, "50", "1", "20" );
            int i = 0;
            while ( i < 4 ) {
                studentsPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Reading_Assignment, "100", "1", "20" );
                i++;
            }

            studentsPage.logout();
            chromeDriver.quit();

            //Login as student2 to the executeCourses
            Log.message( "Executing the courses using simulator for student2" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername2, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "100", "1", "5" );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment2, "90", "1", "5" );
            studentsPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Reading_Assignment, "100", "1", "20" );
            studentsPage.logout();
            chromeDriver.quit();

            //Login as student3 to the executeCourses
            Log.message( "Executing the courses using simulator for student3" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername3, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "40", "1", "20" );
            studentsPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Reading_Assignment, "50", "1", "20" );
            studentsPage.logout();
            chromeDriver.quit();

            //Login as student4 to the executeCourses
            Log.message( "Executing the courses using simulator for student4" );
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
    		eventListner = new EventListener();
    		chromeDriver.register(eventListner);
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername4, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "10", "5", "5" );
            studentsPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Reading_Assignment, "50", "1", "20" );
            studentsPage.logout();
            chromeDriver.quit();
        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        }

        finally {
            BaseAPITest apiTest = new BaseAPITest();
            apiTest.invalidateSession( smUrl, apiTest.getJessionCookie( smUrl, username, password ) );
            Log.endTestCase();
            chromeDriver.quit();
        }
    }

    @Test ( description = "Verify the teacher is able to navigate back to the Groups Mastery view page where they came from the mastery list, when they click on the breadcrumb icon in the top of the Groups Mastery detail page", groups = { "SMK-43594",
            "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy001( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        SMUtils.logDescriptionTC( "SMK-14910 : Verify the teacher is able to navigate back to the Groups Mastery view page where they came from the mastery list, when they click on the breadcrumb icon in the top of the Groups Mastery detail page " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation
            Log.assertThat( masteryDetail.isMasteryDetailsPageLoaded(), "Mastery Details page Loaded Sucessfully", "Not Loaded Successfully" );

            // Clicking breadcrumb icon in the mastery details page.
            masteryDetail.clickBreadCrumbIcon();

            // Validation whether summary page is loaded after clicking bread crumb icon in the mastery details page
            Log.assertThat( masterySummary.isMasterySummaryPageLoaded(), "Mastery Summary page Loaded Sucessfully", "Not Loaded Successfully" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher can able to see Skill Description in the second strand of the Skill LO detail page", groups = { "SMK-43594", "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy002( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        SMUtils.logDescriptionTC( "SMK-14872 : Verify the teacher can able to see Skill Description in the second strand of the Skill LO detail page for Math Subject with skills " );
        SMUtils.logDescriptionTC( "SMK-14873 : Verify the teacher can able to see Skill Description in the second strand of the Skill LO detail page for Math Subject with standards" );
        SMUtils.logDescriptionTC( "SMK-14874 : Verify the teacher can able to see Skill Description in the second strand of the Skill LO detail page for Reading Subject with skills" );
        SMUtils.logDescriptionTC( "SMK-14875 : Verify the teacher can able to see Skill Description in the second strand of the Skill LO detail page for Reading Subject with standards" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Case 1 :
            Log.message( "Case 1 : Verify the teacher can able to see Skill Description in the second strand of the Skill LO detail page for Math Subject with skills." );

            // Selecting first leaf node
            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 1
            Log.assertThat( masteryDetail.verifySkillDescriptionPresent(), "Skill Description available for the above condition", "Not Loaded Successfully" );

            // Case 2 :
            Log.message( "Case 2 : Verify the teacher can able to see Skill Description in the second strand of the Skill LO detail page for Math Subject with standard." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Standard from DropDown
            masteryFilter.selectSkillStandardsByIndex( 2 );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 2
            Log.assertThat( masteryDetail.verifySkillDescriptionPresent(), "Skill Description available for the above condition", "Not Loaded Successfully" );

            // Case 3 :
            Log.message( "Case 3 : Verify the teacher can able to see Skill Description in the second strand of the Skill LO detail page for Reading Subject with Skill." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Reading Subject From the Drop Down
            masteryFilter.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 3
            Log.assertThat( masteryDetail.verifySkillDescriptionPresent(), "Skill Description available for the above condition", "Not Loaded Successfully" );

            // Case 4 :
            Log.message( "Case 4 : Verify the teacher can able to see Skill Description in the second strand of the Skill LO detail page for Reading Subject with standard." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Standard from DropDown
            masteryFilter.selectSkillStandardsByIndex( 2 );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 4
            Log.assertThat( masteryDetail.verifySkillDescriptionPresent(), "Skill Description available for the above condition", "Not Loaded Successfully" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher can able to see LO Description after the LO name", groups = { "SMK-43594", "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy003( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        SMUtils.logDescriptionTC( "SMK-14882 : Verify the teacher can able to see LO Description after the LO name for Math Subject with skills " );
        SMUtils.logDescriptionTC( "SMK-14883 : Verify the teacher can able to see LO Description after the LO name for Math Subject with standards" );
        SMUtils.logDescriptionTC( "SMK-14884 : Verify the teacher can able to see LO Description after the LO name for Reading Subject with skills" );
        SMUtils.logDescriptionTC( "SMK-14885 : Verify the teacher can able to see LO Description after the LO name for Reading Subject with standards" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Case 1 :
            Log.message( "Case 1 : Verify the teacher can able to see LO Description in the second strand of the Skill LO detail page for Math Subject with skills." );

            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 1
            Log.assertThat( masteryDetail.verifyLODescriptionPresent(), "LO Description available for the above condition", "Not Loaded Successfully" );

            // Case 2 :
            Log.message( "Case 2 : Verify the teacher can able to see LO Description in the second strand of the Skill LO detail page for Math Subject with standard." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Standard from DropDown
            masteryFilter.selectSkillStandardsByIndex( 2 );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 2
            Log.assertThat( masteryDetail.verifyLODescriptionPresent(), "LO Description available for the above condition", "Not Loaded Successfully" );

            // Case 3 :
            Log.message( "Case 3 : Verify the teacher can able to see LO Description in the second strand of the Skill LO detail page for Reading Subject with Skill." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Reading Subject From the Drop Down
            masteryFilter.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 3
            Log.assertThat( masteryDetail.verifyLODescriptionPresent(), "LO Description available for the above condition", "Not Loaded Successfully" );

            // Case 4 :
            Log.message( "Case 4 : Verify the teacher can able to see LO Description in the second strand of the Skill LO detail page for Reading Subject with standard." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Standard from DropDown
            masteryFilter.selectSkillStandardsByIndex( 2 );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 4
            Log.assertThat( masteryDetail.verifyLODescriptionPresent(), "LO Description available for the above condition", "Not Loaded Successfully" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher can able to see SKill Parent name in the second strand of the Skill LO detail page ", groups = { "SMK-43594", "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy005( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        SMUtils.logDescriptionTC( "SMK-14868 : Verify the teacher can able to see Skill parent name in the first strand of the Skill LO detail page for Math Subject with skills " );
        SMUtils.logDescriptionTC( "SMK-14869 : Verify the teacher can able to see Skill parent name in the first strand of the Skill LO detail page for Math Subject with standards" );
        SMUtils.logDescriptionTC( "SMK-14870 : Verify the teacher can able to see Skill parent name in the first strand of the Skill LO detail page for Reading Subject with skills" );
        SMUtils.logDescriptionTC( "SMK-14871 : Verify the teacher can able to see Skill parent name in the first strand of the Skill LO detail page for Reading Subject with standards" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Case 1 :
            Log.message( "Case 1 : Verify the teacher can able to see SKill Parent name in the second strand of the Skill LO detail page for Math Subject with skills." );

            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 1
            Log.assertThat( masteryDetail.verifySkillParentName(), "SKill Parent name is available for the above condition", "Not Loaded Successfully" );

            // Case 2 :
            Log.message( "Case 2 : Verify the teacher can able to see SKill Parent name in the second strand of the Skill LO detail page for Math Subject with standard." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Standard from DropDown
            masteryFilter.selectSkillStandardsByIndex( 2 );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 2
            Log.assertThat( masteryDetail.verifySkillParentName(), "SKill Parent name available for the above condition", "Not Loaded Successfully" );

            // Case 3 :
            Log.message( "Case 3 : Verify the teacher can able to see SKill Parent name in the second strand of the Skill LO detail page for Reading Subject with Skill." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Reading Subject From the Drop Down
            masteryFilter.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 3
            Log.assertThat( masteryDetail.verifySkillParentName(), "SKill Parent name available for the above condition", "Not Loaded Successfully" );

            // Case 4 :
            Log.message( "Case 4 : Verify the teacher can able to see SKill Parent name in the second strand of the Skill LO detail page for Reading Subject with standard." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Standard from DropDown
            masteryFilter.selectSkillStandardsByIndex( 2 );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 4
            Log.assertThat( masteryDetail.verifySkillParentName(), "SKill Parent name available for the above condition", "Not Loaded Successfully" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb", groups = { "SMK-43594", "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy006( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14864 : Verify the teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb for Math Subject with skills " );
        SMUtils.logDescriptionTC( "SMK-14865 : Verify the teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb for Math Subject with standards" );
        SMUtils.logDescriptionTC( "SMK-14866 : Verify the teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb for Reading Subject with skills" );
        SMUtils.logDescriptionTC( "SMK-14867 : Verify the teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb for Reading Subject with standards" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Case 1 :
            Log.message( "Case 1 : Verify the teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb for Math subject with skills" );

            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );
            // Validation 1
            Log.assertThat( masteryDetail.isMasteryDetailsPageLoaded(), "The teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb", "Not Loaded Successfully" );

            // Case 2 :
            Log.message( "Case 2 : Verify the teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb for Math subject with standards" );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Standard from DropDown
            masteryFilter.selectSkillStandardsByIndex( 2 );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 2
            Log.assertThat( masteryDetail.isMasteryDetailsPageLoaded(), "The teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb", "Not Loaded Successfully" );

            // Case 3 :
            Log.message( "Case 3 : Verify the teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb for Reading Subject with Skill." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Reading Subject From the Drop Down
            masteryFilter.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 3
            Log.assertThat( masteryDetail.isMasteryDetailsPageLoaded(), "The teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb", "Not Loaded Successfully" );

            // Case 4 :
            Log.message( "Case 4 : Verify the teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb for Reading Subject with standard." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Standard from DropDown
            masteryFilter.selectSkillStandardsByIndex( 2 );

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 4
            Log.assertThat( masteryDetail.isMasteryDetailsPageLoaded(), "The teacher can able to breakdown a particular skill information by clicking a right arrowed breadcrumb", "Not Loaded Successfully" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher is able to see the mastery average", groups = { "SMK-43594", "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy007( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-14890 : Verify the teacher is able to see the mastery average for Math Subject with skills " );
        SMUtils.logDescriptionTC( "SMK-14891 : Verify the teacher is able to see the mastery average for Math Subject with standards" );
        SMUtils.logDescriptionTC( "SMK-14892 : Verify the teacher is able to see the mastery average for Reading Subject with skills" );
        SMUtils.logDescriptionTC( "SMK-14893 : Verify the teacher is able to see the mastery average for Reading Subject with standards" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Case 1 :
            Log.message( "Case 1 : Verify the teacher is able to see the mastery average for Math subject with skills" );

            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 1
            Log.assertThat( masteryDetail.isSkillDetailsPresentInProgressBarToolTip(), "Skills Details is Displaying Properly in the tool tip of Progress bar", "Not Showed Successfully" );

            // Case 2 :
            Log.message( "Case 2 :  Verify the teacher is able to see the mastery average for Math subject with standards" );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Standard from DropDown
            masteryFilter.selectSkillStandardsByIndex( 2 );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 2
            Log.assertThat( masteryDetail.isSkillDetailsPresentInProgressBarToolTip(), "Skills Details is Displaying Properly in the tool tip of Progress bar", "Not Showed Successfully" );

            // Case 3 :
            Log.message( "Case 3 :  Verify the teacher is able to see the mastery average for Reading Subject with Skill." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Reading Subject From the Drop Down
            masteryFilter.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            // Click Apply Filter Button
            masteryFilter.clickApplyFilter();

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 3
            Log.assertThat( masteryDetail.isSkillDetailsPresentInProgressBarToolTip(), "Skills Details is Displaying Properly in the tool tip of Progress bar", "Not Showed Successfully" );

            // Case 4 :
            Log.message( "Case 4 :  Verify the teacher is able to see the mastery average for Reading Subject with standard." );

            // Click breadcrumb button
            masteryDetail.clickBreadCrumbIcon();

            // Select Standard from DropDown
            masteryFilter.selectSkillStandardsByIndex( 2 );

            // Selecting first leaf node
            masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation 4
            Log.assertThat( masteryDetail.isSkillDetailsPresentInProgressBarToolTip(), "Skills Details is Displaying Properly in the tool tip of Progress bar", "Not Showed Successfully" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher can able to click the LO Name and Sco Content id loaded", groups = { "SMK-43594", "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy008( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        SMUtils.logDescriptionTC( " SMK-14877 : Verify the teacher can able to click the LO Name, when Math subject is chosen with skills" );
        SMUtils.logDescriptionTC( " SMK-14878 : Verify the teacher can able to see the SCO content belongs to the LO, when Math subject is chosen with skills " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Validation : Case 1 and Case 2 Validated
            Log.message( "Verify the teacher can able to see the SCO content belongs to the LO, when Math subject is chosen with skills" );

            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation : 
            Log.assertThat( masteryDetail.isNameOfLOIsClickableAndSCOContentLoaded(), "The teacher can able to click the LO Name and Sco Content Loaded in the new window", "LO Name Not Clickable" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the student name(first name, last name), Mastery Status, Skills Evaluated, Attemps fields in the Groups Mastery details page ", groups = { "SMK-43594", "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy009( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        SMUtils.logDescriptionTC( " SMK-14897 : Verify the student name(first name, last name), Mastery Status, Skills Evaluated, Attemps fields in the Groups Mastery details page " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Validation  : Verify Header Fields on the Mastery Details Page

            Log.assertThat( masteryDetail.verifyMasteryDetailsPageHeaderFields( Constants.MasteryUI.ATTEMPTS_FIELD ), " " + Constants.MasteryUI.ATTEMPTS_FIELD + " is present in the Mastery details page ", "Header not Present" );

            Log.assertThat( masteryDetail.verifyMasteryDetailsPageHeaderFields( Constants.MasteryUI.MASTERY_STATUS_FIELD ), " " + Constants.MasteryUI.MASTERY_STATUS_FIELD + " is present in the Mastery details page ", "Header not Present" );

            Log.assertThat( masteryDetail.verifyMasteryDetailsPageHeaderFields( Constants.MasteryUI.STUDENT_FIELD ), " " + Constants.MasteryUI.STUDENT_FIELD + " is present in the Mastery details page ", "Header not Present" );

            Log.assertThat( masteryDetail.verifyMasteryDetailsPageHeaderFields( Constants.MasteryUI.SKILLS_EVALUATED_FIELD ), " " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD + " is present in the Mastery details page ", "Header not Present" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the teacher is able to sort the student name field in the Groups Mastery details page", groups = { "SMK-43594", "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy010( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        SMUtils.logDescriptionTC( " SMK-14900 : Verify the teacher is able to sort the student name field in descending order in the Groups Mastery details page " );
        SMUtils.logDescriptionTC( " SMK-14901 : Verify the teacher is able to sort the student name field in ascending order in the Groups Mastery details page " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Get Default order for Students name in the Details Page
            List<String> defaultStudentOrderDetailsPage = masteryDetail.getDefaultStudentOrderDetailsPage();

            // Get sorted result for Both Descending and Ascending Order
            Boolean isStudentNameAbleToSort = masteryDetail.verifyStudentNameSortedToDescAndAsceInDetailsPage( defaultStudentOrderDetailsPage );

            // Validation :
            Log.assertThat( isStudentNameAbleToSort, "Student Name is sorted in to Descending and Ascending Order", "Student Name not Sorted" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the teacher is able to sort the Skills Evaluated field in the Groups Mastery details page", groups = { "SMK-43594", "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy011( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        SMUtils.logDescriptionTC( " SMK-14904 : Verify the teacher is able to sort the Skills Evaluated field in descending order in the Groups Mastery details page" );
        SMUtils.logDescriptionTC( " SMK-14905 : Verify the teacher is able to sort the Skills Evaluated field in ascending order in the Groups Mastery details page" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Get Default order for Students name in the Details Page
            List<String> SkillEvaluatedOrderDetailsPage = masteryDetail.getAscendingOrderSkillsEvaluated();

            // Get sorted result for Both Descending and Ascending Order
            Boolean isSkillEvaluatedFieldAbleToSort = masteryDetail.verifySkillsEvaluatedFieldSortedToDescAndAsceInDetailsPage( SkillEvaluatedOrderDetailsPage );

            // Validation :
            Log.assertThat( isSkillEvaluatedFieldAbleToSort, "Skill Evaluated Field is sorted in to Descending and Ascending Order", "Skill Evaluated Field not Sorted" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the teacher is able to sort the Attempts field in the Groups Mastery details page", groups = { "SMK-43594", "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy012( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        SMUtils.logDescriptionTC( " SMK-14906 : Verify the teacher is able to sort the Attempts field in descending order in the Groups Mastery details page" );
        SMUtils.logDescriptionTC( " SMK-14907 : Verify the teacher is able to sort the Attempts field in ascending order in the Groups Mastery details page" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Get Default order for Students name in the Details Page
            List<String> attemptsFieldOrderDetailsPage = masteryDetail.getAscendingOrderAttemptsField();

            // Get sorted result for Both Descending and Ascending Order
            Boolean isAttemoptFieldAbleToSort = masteryDetail.verifyAttemptsFieldSortedToDescAndAsceInDetailsPage( attemptsFieldOrderDetailsPage );

            // Validation :
            Log.assertThat( isAttemoptFieldAbleToSort, "Attempt Field is sorted in to Descending and Ascending Order", "Attempt Field not Sorted" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the teacher is able to sort the Mastery Status field in the Groups Mastery details page", groups = { "SMK-43594", "Group", "MasterySubNav" }, priority = 1 )
    public void tcMasteryHierarchy013( ITestContext context ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        SMUtils.logDescriptionTC( " SMK-14902 : Verify the teacher is able to sort the Mastery Status field in descending order in the Groups Mastery details page " );
        SMUtils.logDescriptionTC( " SMK-14903 : Verify the teacher is able to sort the Mastery Status field in ascending order in the Groups Mastery details page " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Click Mastery Option
            groupsPage.clickMasterySubNavOnGrpTab();

            // Selecting first leaf node
            List<WebElement> masteredProgressBars = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            // Get Default order for Students name in the Details Page
            List<String> masteryFieldOrderDetailsPage = masteryDetail.getMasteryFieldAscendOrder();

            // Get sorted result for Both Descending and Ascending Order
            Boolean isMasteryStatusFieldAbleToSort = masteryDetail.verifyMasteryStatusFieldSortedToDescAndAsceInDetailsPage( masteryFieldOrderDetailsPage );

            // Validation :
            Log.assertThat( isMasteryStatusFieldAbleToSort, "Mastery Status field is sorted in to Descending and Ascending Order", "Mastery Status field is not Sorted" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}