package com.savvas.sm.api.tests.smnew.report;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.smnew.report.model.ReportRequest;
import com.savvas.sm.api.tests.smnew.report.model.ReportResponse;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.ReportAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetupProcessor;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * This class is used to test the CP Report API Test
 * 
 * @author lakshmi.ramalingam
 *
 */

public class CPReportAPITest extends EnvProperties {

    String smUrl;
    Map<String, String> response;
    String orgId;
    String username;
    String userId;
    String groupId;
    String browser;
    List<ReportResponse> actualLst = new ArrayList<>();
    List<ReportResponse> lst = new ArrayList<>();
    HashMap<String, String> mathAssignmentDetails = new HashMap<>();
    HashMap<String, String> readingAssignmentDetails = new HashMap<>();
    static List<String> studentId = new ArrayList<>();
    String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String flexSchoolTeacherDetails;
    String orgID;
    String userID;
    String studentDetail;
    String studentUserID;
    String studentUsername;
    String teacherUsername;
    String password;
    String courseName;
    String courseId;
    String assignmentID;
    String assignmentUserId;
    boolean lastSessionValue;
    String subject;
    RBSUtils rbsUtils = new RBSUtils();
    Map<String, String> assignmentResponse = new HashMap<>();
    HashMap<String, String> groupdetails = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    String districtID;
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;
    public String isItMt = "";

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        // Getting Teacher from flex School        
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        userID = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        // Getting ORGID of Flex school       
        orgID = RBSDataSetup.organizationIDs.get( flexSchool );
        districtID = configProperty.getProperty( "district_ID" );
        // Getting Students from Flex school        
        studentDetail = RBSDataSetup.getMyStudent( flexSchool, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();

        // Create a custom course for the flex teacher 
        courseName = "CustomSettingCourse" + System.nanoTime();
        courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

        String accessToken = new RBSUtils().getAccessToken( teacherUsername, password );

        // Creating Group to add the student to assign assignment
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, userID );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgID );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );
        // Create Assignment and assign to a student HashMap<String, String>
        assignmentDetails = new HashMap<>();
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
        assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

        executeCourse( studentUsername, courseName, true, "9", "3", "8" );
        isItMt = configProperty.getProperty( "isMTExecution" );

    }

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "smoke_test_case", "Smoke postCPRTest001", "CP Report", "P1", "SMK-55555", "Java API for CP report", "API" }, priority = 1 )
    public void postCPRTest001( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> params = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );
        //Test Data
        String authorization = "Basic YWRtaW50ZXN0OnRlc3Q=";
        String endPoint = ReportAPIConstants.CP_REPORT_ENDPOINT;
        ObjectMapper mapper = new ObjectMapper();
        ReportRequest request = new ReportRequest();
        request.getStudents().add( studentUserID );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        String res;
        actualLst = new ArrayList<>();
        lst = new ArrayList<>();
        switch ( scenarioType ) {
            case "VALID_STUDENT_IDS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );

                Log.message( response.get( Constants.RESPONSE_BODY ).toString() );

                if ( !( response.get( Constants.RESPONSE_BODY ).toString().contains( ReportAPIConstants.ZERO_STATE ) ) ) {
                    Log.assertThat( new SMAPIProcessor().isSchemaValid( "CP_Report", statusCode, response.get( Constants.RESPONSE_BODY ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                } else {

                    Log.message( "No Data Found for selected criteria" );
                }
                break;
            case "INVALID_STUDENT_IDS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                List<String> studentIdLst = new ArrayList<>();
                studentIdLst.add( "test" );
                request.setStudents( studentIdLst );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "WITHOUT_TOKEN":
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "VALID_SUBJECT":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setSubject( ReportAPIConstants.MATH_ID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );

                if ( !( response.get( Constants.RESPONSE_BODY ).toString().contains( ReportAPIConstants.ZERO_STATE ) ) ) {
                    Log.assertThat( new SMAPIProcessor().isSchemaValid( "CP_Report", statusCode, response.get( Constants.RESPONSE_BODY ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                } else {

                    Log.message( "No Data Found for selected criteria" );
                }

                break;
            case "INVALID_SUBJECT":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setSubject( 12345 );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_SUBJECT_STRING":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setSubject( ReportAPIConstants.INVALID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "VALID_LIMIT":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setLimit( 1 );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_LIMIT":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setLimit( ReportAPIConstants.INVALID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );

                if ( !( response.get( Constants.RESPONSE_BODY ).toString().contains( ReportAPIConstants.ZERO_STATE ) ) ) {
                    Log.assertThat( new SMAPIProcessor().isSchemaValid( "CP_Report", statusCode, response.get( Constants.RESPONSE_BODY ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                } else {

                    Log.message( "No Data Found for selected criteria" );
                }
                break;
            case "INVALID_LIMIT_ZERO":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setLimit( 0 );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "VALID_OFFSET":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setOffset( 1 );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_OFFSET":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setOffset( ReportAPIConstants.INVALID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "VALID_ASSIGNMENT_IDS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setAssignmentIds( Arrays.asList( "576" ) );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_ASSIGNMENT_IDS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setAssignmentIds( Arrays.asList( ReportAPIConstants.INVALID ) );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "INVALID_ORDER_BY":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setOrderBy( ReportAPIConstants.INVALID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                break;
            case "ORDER_BY_PERSON_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                request.setOrderBy( ReportAPIConstants.PERSON_ID );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, mapper.writeValueAsString( request ) );
                res = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "rows" );
                actualLst = new Gson().fromJson( res, new TypeToken<List<ReportResponse>>() {}.getType() );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                        "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
                if ( !( response.get( Constants.RESPONSE_BODY ).toString().contains( ReportAPIConstants.ZERO_STATE ) ) ) {
                    Log.assertThat( new SMAPIProcessor().isSchemaValid( "CP_Report", statusCode, response.get( Constants.RESPONSE_BODY ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                } else {

                    Log.message( "No Data Found for selected criteria" );
                }
                break;
        }
        Log.message( response.toString() );
        // Validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );

        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC001", "200", "Verify the status code 200 for response body for providing only correct studentIds in request body", "VALID_STUDENT_IDS" },
                { "TC002", "200", "Verify the status code 200 for response body for providing only invalid studentIds in request body and validate response message", "INVALID_STUDENT_IDS" },
                { "TC003", "401", "Verify the status code 401 for response body for providing not providing Authorization in header", "WITHOUT_TOKEN" },
                { "TC004", "200", "Verify the status code 200 for response body for providing valid studentIds and subject in request body ", "VALID_SUBJECT" },
                { "TC005", "400", "Verify the status code 400 for response body for providing valid studentIds and invalid subject in request body ", "INVALID_SUBJECT" },
                { "TC006", "400", "Verify the status code 400 for response body for providing valid studentIds and invalid subject in request body ", "INVALID_SUBJECT_STRING" },
                { "TC007", "200", "Verify the status code 200 for response body for providing valid studentIds and limit in request body", "VALID_LIMIT" },
                { "TC008", "400", "Verify the status code 400 for response body for providing valid studentIds and invald limit in request body", "INVALID_LIMIT" },
                { "TC009", "400", "Verify the status code 400 for response body for providing valid studentIds and invald limit (0) in request body", "INVALID_LIMIT_ZERO" },
                { "TC010", "200", "Verify the status code 200 for response body for providing valid studentIds and offset in request body", "VALID_OFFSET" },
                { "TC011", "400", "Verify the status code 400 for response body for providing valid studentIds and invald offset in request body", "INVALID_OFFSET" },
                { "TC012", "400", "Verify the status code 400 for response body for providing valid studentIds and invald offset (0) in request body", "INVALID_OFFSET_ZERO" },
                { "TC013", "200", "Verify the status code 200 for response body for providing valid studentIds and assignmentIds in request body", "VALID_ASSIGNMENT_IDS" },
                { "TC014", "400", "Verify the status code 200 for response body for providing valid studentIds and invalid assignmentIds  in request body", "INVALID_ASSIGNMENT_IDS" },
                { "TC015", "400", "Verify the status code 400 for response body for providing valid studentIds and invalid orderBy  in request body", "INVALID_ORDER_BY" },
                { "TC016", "200", "Verify the status code 200 for response body and order of report data with respect to person_id for providing valid studentIds and orderBy person_id in request body", "ORDER_BY_PERSON_ID" }, };
        return data;
    }

    /**
     * This Method will generate headers
     * 
     * @param userreqDetails should contains bearer token, teacher rumbaID & org
     *            ID
     * @return
     */
    public Map<String, String> getHeaders( HashMap<String, String> userreqDetails ) {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userreqDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        headers.put( Constants.USERID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.ORG_ID ) );
        return headers;
    }

    /**
     * To create a custom course
     * 
     * @param smUrl
     * @param token
     * @param subject
     * @param teacherID
     * @param orgID
     * @param courseType
     * @param courseName
     * @param jsonFileName
     * @return
     * @throws Exception
     */
    public String createCustomCourse( String smUrl, String token, String subject, String teacherID, String orgID, String courseType, String courseName, String jsonFileName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        DataSetupProcessor dataprocess = new DataSetupProcessor();
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherID );
            headers.put( Constants.ORGID_SM_HEADER, orgID );
            // Input Params
            HashMap<String, String> params = new HashMap<>();

            // EndPoint Details
            String endPoint_post = CourseAPIConstants.POST_STANDARD_COURSE_COPY;
            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgID );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherID );

            Map<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( courseType.equalsIgnoreCase( DataSetupConstants.SETTINGS ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.SKILL ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.STANDARD ) ) {
                List<String> standardDetails = new ArrayList<>();

                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    standardDetails = SqlHelperAssignment.getRandomStandardGradeID( DataSetupConstants.MATH, isItMt.equalsIgnoreCase( "true" ) );
                } else {
                    standardDetails = SqlHelperAssignment.getRandomStandardGradeID( DataSetupConstants.READING, isItMt.equalsIgnoreCase( "true" ) );
                }

                List<String> listLO = SqlHelperAssignment.getLOIDsRandomStandard( standardDetails.get( 0 ), standardDetails.get( 1 ), isItMt.equalsIgnoreCase( "true" ) );
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
                courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }

            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.ONE_LO ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_ONE_LO, courseDetails );
                }
            }
            response_post = RestHttpClientUtil.POST( smUrl, headers, params, endPoint_post, requestBody );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }
    
    /**
     * To execute the course
     *
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, String percentage, String numberOfSession, String loCount ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );
    
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    /**
     * To assign an assignment to a user(s) or groups(s)
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            org ID & course ID
     * @param studentRumbaIds
     * @param type should be users or groups
     * @return
     * @throws Exception
     */
    public HashMap<String, String> assignAssignment( String envUrl, HashMap<String, String> assignmentDetails, List<String> studentRumbaIds, String type ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.CREATE_ASSIGNMENT_API;

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.ASSIGN_ASSIGNMENT_PAYLOAD ) );

        if ( !studentRumbaIds.isEmpty() ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {

                listString += studentID.concat( "\",\"" );

            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_IDS ), listString ) );

            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_GRADE_IDS ), listString ).replace( ",,", "," ) );
        } else {
            Log.fail( "Student / Group ID missing" );
        }

        if ( type.equalsIgnoreCase( AssignmentAPIConstants.USERS_TYPE ) ) {
            requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.USERS_TYPE ) );
        } else if ( type.equalsIgnoreCase( AssignmentAPIConstants.GROUPS_TYPE ) ) {
            requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.GROUPS_TYPE ) );
        } else {
            Log.fail( "Invalid Type: " + type );
        }

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{courseID}", courseID );

        return RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );

    }

}
