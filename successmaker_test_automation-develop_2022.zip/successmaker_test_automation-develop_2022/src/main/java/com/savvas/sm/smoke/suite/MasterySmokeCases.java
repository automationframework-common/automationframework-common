package com.savvas.sm.smoke.suite;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Students.Mastery_DropDowns;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.mastery.pages.MasterySummaryComponent;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

public class MasterySmokeCases extends BaseTest {
	private String smUrl;
	private String browser;
	private String school;
	private String username = null;
	private String password = null;
	String schoolID;
	String teacherID;
	String teacherUserName;
	String teacherDetails;
	String studentdetails;
	String studentusername;
	String studentuserid;
	TeacherHomePage teacherHomePage;
	LoginPage smLoginPage;
	MasterySummaryComponent masteryComponent;
	List<String> studentUserNames = null;

	@BeforeClass
	public void initTest(ITestContext context) {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		schoolID = RBSDataSetup.organizationIDs.get(school);
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		studentdetails = RBSDataSetup.getMyStudent(school, username);
		studentusername = SMUtils.getKeyValueFromResponse(studentdetails, "userName");
		studentuserid = SMUtils.getKeyValueFromResponse(studentdetails, "userId");

	}

	@Test(description = "Verify mastery home widget", priority = 1, groups = { "smoke_test_case", "Audit History",
			"Teacher_TC40", "P1" })
	public void tcteachermasterysmoke001() throws Exception {
		HashMap<String, String> assignmentDetails = new HashMap<>();
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get(school));
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherID);
		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN,
				new RBSUtils().getAccessToken(
						SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME),
						RBSDataSetupConstants.DEFAULT_PASSWORD));
		new AssignmentAPI().assignMultipleAssignments(smUrl, assignmentDetails, Arrays.asList(studentuserid),
				Arrays.asList("1"));
		final WebDriver studentdriver = WebDriverFactory.get(browser);
		LoginWrapper.loginToSuccessMakerAsStudent(studentdriver, smUrl, UserType.BASIC, null, studentusername,
				RBSDataSetupConstants.DEFAULT_PASSWORD);
		StudentDashboardPage studentPage = new StudentDashboardPage(studentdriver);
		new StudentDashboardPage(studentdriver).executeMathCourse(studentusername, "Math", "100", "2", "30");
		studentPage.logout();
		studentdriver.close();
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		try {
			// login to the app
			TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl,
					LoginConstants.UserType.BASIC, null, username, password);

			SMUtils.waitForSpinnertoDisapper(driver);

			teacherHomePage.topNavBar.navigateToHomeTab();
			teacherHomePage.verifyingMasteryCard();
			SMUtils.logDescriptionTC("Verify mastery home widget");
			teacherHomePage.clickViewAllinMasteryCard();
			MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();
			Log.assertThat(masteryPage.getMasteryHeading().equals("Mastery"), "Navigated to Mastery page",
					"Clicking view all  is not navigated to Mastery page");
			teacherHomePage.topNavBar.navigateToHomeTab();
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Run Report button of the Mastery page", priority = 1, groups = { "smoke_test_case",
			"Audit History", "Teacher_TC47", "P1" })
	public void tcteachermasterysmoke002() throws Exception {
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		Log.testCaseInfo(
				"Verify the Run Report button of the Mastery page <small><b><i>[" + browser + "]</b></i></small>");
		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage teacherHomePage = smLoginPage.loginToSM(username, password, true);
			// Navigate to Mastery Tab
			MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();
			MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
			masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
			SMUtils.logDescriptionTC("Tc:01 Verify the Mastery Run Report button is disabled by default");
			Log.assertThat(!masteryPage.isRunBtnEnabled(), "The Mastery Run Report button is disabled by default",
					"The Mastery Run Report button is not disabled by default");
			Log.testCaseResult();

			SMUtils.logDescriptionTC(
					"Tc:02 Verify the Mastery Run Report button is enabled after clicking on Run Report button");
			masteryFiltersComponent.applyFilter();
			Log.assertThat(masteryPage.isRunBtnEnabled(),
					"The Mastery Run Report button is enabled after clicking on Apply filter button",
					"The Mastery Run Report button is not enabled after clicking on Apply filter button");
			Log.testCaseResult();
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the mastery drop down displayed in the Student details Page", priority = 1, groups = {
			"smoke_test_case", "Audit History", "Teacher_TC49", "P1" })
	public void tcteachermasterysmoke003() throws Exception {
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		Log.testCaseInfo("Verify the mastery drop down displayed in the Student details Page <small><b><i>[" + browser
				+ "]</b></i></small>");
		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage teacherHomePage = smLoginPage.loginToSM(username, password, true);
			// Navigate to Students Tab
			StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

			// Navigate to Student detail Page
			studentsTab.clickviewStudentByEllipsis(studentusername);
			studentsTab.clickSubNavigation(Constants.Students.NAVIGATE_MASTERY);
			// Select Reading
			studentsTab.selectDropDownValues(Mastery_DropDowns.SUBJECT,
					Constants.Students.SUBJECT_DROPDOWN_VALUES.get(1));

			studentsTab.clickApplyFilter();
			Log.testCaseResult();

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Groups->Mastery Summary Page", priority = 1, groups = { "smoke_test_case",
			"Audit History", "Teacher_TC55", "P1" })
	public void tcteachermasterysmoke004() throws Exception {
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		Log.testCaseInfo("Verify Groups->Mastery Summary Page <small><b><i>[" + browser + "]</b></i></small>");

		try {
			TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl,
					LoginConstants.UserType.BASIC, null, username, password); // TODO: 5/27/2022 change username and
																				// password

			// navigate to Groups Listing Page
			GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
			groupPage.viewGroup("Successmaker Group 1");
			groupPage.clickGroupsSubNav(Constants.MASTERY);
			MasteryFiltersComponent masteryFiltersComponent = groupPage.getMasteryFilterComponent();
			masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
			masteryFiltersComponent.applyFilter();
			Log.assertThat(masteryFiltersComponent.isMasterySummaryPageLoaded(),
					"The Mastery summary details is disabled ", "The Mastery summary details is not disabled");
			Log.assertThat(masteryFiltersComponent.isSkillDetailsPresentInProgressBarToolTip(),
					"The Tool Tip is disabled ", "The Tool Tip details is not disabled");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify Mastery Summary Report Page", priority = 1, groups = { "smoke_test_case",
			"Audit History", "Teacher_TC29", "P1" })
	public void tcteachermasterysmoke005() throws Exception {
		// Get driver
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.testCaseInfo("Verify Mastery Summary Report Page <small><b><i>[" + browser + "]</b></i></small>");

		try {

			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage teacherHomePage = smLoginPage.loginToSM(username, password, true);
			// Navigate to Mastery Tab
			MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();
			MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
			masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
			masteryFiltersComponent.applyFilter();
			Log.assertThat(masteryFiltersComponent.isMasterySummaryPageLoaded(),
					"The Mastery summary details is disabled ", "The Mastery summary details is not disabled");
			Log.assertThat(masteryFiltersComponent.isSkillDetailsPresentInProgressBarToolTip(),
					"The Tool Tip is disabled ", "The Tool Tip details is not disabled");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify Mastery Report Page", priority = 1, groups = { "smoke_test_case", "Audit History",
			"Teacher_TC27", "P1" })
	public void tcteachermasterysmoke006() throws Exception {
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		Log.testCaseInfo("Verify Mastery Report Page <small><b><i>[" + browser + "]</b></i></small>");

		try {

			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage teacherHomePage = smLoginPage.loginToSM(username, password, true);
			// Navigate to Mastery Tab
			MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();
			// Verifying the headers
			Log.assertThat(masteryPage.getMasteryHeading().equals("Mastery"), "Header title displayed properly!",
					"Header title not displayed properly");
			MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
			masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);
			masteryFiltersComponent.selectSkillStandards(Constants.MasteryUI.SKILL_MATH);
			masteryFiltersComponent.isApplyFilterButtonPresent();

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}
}
