package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class PauseResumeAllStudentsAssignment extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String CourseId;
    RBSUtils rbsutils = new RBSUtils();
    List<String> studentRumbaIds = new ArrayList<>();
    private String teacherUsername;
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();

    }

    @Test ( priority = 1, dataProvider = "PauseResumeAllStudentsAssignment_PositiveFlow", groups = { "SMK-51893", "smoke_test_case", "Assignments", "PauseResumeAllStudentsAssignment", "P1", "API" } )
    public void tcPauseResumeAllStudentsAssignment_PositiveFlow_01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        String endpoint = "null";

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        HashMap<String, String> response = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        switch ( scenario ) {

            case "Default Math Assignment Resume":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Default Math Assignment Pause":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Default Reading Assignment Resume":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Default Reading Assignment Pause":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Focus Math Assignment Resume":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Focus Math Assignment Pause":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Focus Reading Assignment Resume":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Focus Reading Assignment Pause":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Skills - Math Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Skills - Math Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Settings - Math Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Settings - Math Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Standard - Math Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Standard - Math Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Skills - Reading Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Skills - Reading Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Settings - Reading Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Settings - Reading Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Standard - Reading Assignment Resume":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            case "Custom By Standard - Reading Assignment Pause":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                break;
            default:
                Log.fail( "Case is invalid" );
                break;
        }
        HashMap<String, String> getresponse = changeAssignmentStatusForAllStudents( smUrl, assignmentDetails, assignmentDetails.get( AssignmentAPIConstants.STATUS ), endpoint );
        Log.message( "StatusCode: " + getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
        VerifySchema( getresponse.get( "statusCode" ), getresponse );
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "PauseResumeAllStudentsAssignment_PositiveFlow" )
    public Object[][] PauseResumeAllStudentsAssignment_PositiveFlow() {

        Object[][] inputData = { { "Validate 200 for Math Positive flow - Activating assignment", "Default Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Math Positive flow - In-Activating assignment", "Default Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Reading Positive flow - Activating assignment", "Default Reading Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Reading Positive flow - In-Activating assignment", "Default Reading Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Focus Course - Math- Activating assignment", "Focus Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Focus Course - Math- In-Activating assignment", "Focus Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Focus Course - Reading- Activating assignment", "Focus Reading Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Focus Course - Reading-  In-Activating assignment", "Focus Reading Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Standard - Math -  Activating assignment", "Custom By Standard - Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Skills - Math - Activating assignment", "Custom By Skills - Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Settings - Math- Activating assignment", "Custom By Settings - Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Standard - Math -  In-Activating assignment", "Custom By Standard - Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Skills - Math - In-Activating assignment", "Custom By Skills - Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Settings - Math- In-Activating assignment", "Custom By Settings - Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Standard - Reading -  Activating assignment", "Custom By Standard - Reading Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Skills - Reading - Activating assignment", "Custom By Skills - Reading Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Settings - Reading- Activating assignment", "Custom By Settings - Reading Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Standard - Reading -  In-Activating assignment", "Custom By Standard - Reading Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Skills - Reading - In-Activating assignment", "Custom By Skills - Reading Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Custom By Settings - Reading- In-Activating assignment", "Custom By Settings - Reading Assignment Pause", CommonAPIConstants.STATUS_CODE_OK }

        };
        return inputData;
    }

    /**
     * Tests the Negative scenarios of Pause Resume All Students Assignment.
     * 
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( dataProvider = "PauseResumeAllStudentsAssignment_NegativeFlow", priority = 2, groups = { "SMK-51893", "Assignments", "PauseResumeAllStudentAssignment", "P2", "API" } )
    public void tcPauseResumeAllStudentsAssignment_NegativeFlow_02( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> GroupDetails = new HashMap<>();
        String endpoint = "null";

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

        HashMap<String, String> Response = new HashMap<>();

        GroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        GroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( groupAPI.createGroup( smUrl, GroupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }

        String exception = null;
        boolean status = false;
        String message = null;

        switch ( scenario ) {
            case "Incorrect orgId in Headers":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, "8a7206a97f2c9d3a017f4eedf8bd0843" );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;
            case "Invalid Staff-Id in headers":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, "ffffffff6226bf2aaeeaa300304fd51e" );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;
            case "Incorrect URL":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) ).replace( "status", "statusss" );
                break;
            case "Invalid Bearer Token":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            case "Invalid Payload":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "active" );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                exception = CommonAPIConstants.MESSAGE_NOT_READABLE_EXCEPTION;
                status = true;
                break;
            case "Invalid data type in the request payload":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "12345" );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                exception = CommonAPIConstants.MESSAGE_NOT_READABLE_EXCEPTION;
                status = true;
                break;
            case "Payload in LowerCase":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "inactive" );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                exception = CommonAPIConstants.MESSAGE_NOT_READABLE_EXCEPTION;
                status = true;
                break;
            case "organisationId with invalid data in the path parameters":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", "organizations" ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}", assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                status = true;
                break;
            case "Invalid staffId not in DB in path params":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", "12345" ).replace( "{contentbaseId}", assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                exception = CommonAPIConstants.STATUS_CODE_OK;
                status = true;
                break;
            case "Invalid staffId present in DB in path parameters":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", "ffffffff6222101721ca0e002e6df99b" ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                exception = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                status = true;
                break;
            case "Invalid contentbaseId":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}", "12345678" );
                exception = CommonAPIConstants.STATUS_CODE_OK;
                status = true;
                break;
            case "Path parameters with Invalid Datatype":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", "aa" ).replace( "{teacherID}", "bb" ).replace( "{contentbaseId}", "cc" );
                exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
                status = true;
                break;
            case "Invalid StaffId":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", assignmentDetails.get( AssignmentAPIConstants.ORG_ID ) ).replace( "{teacherID}", assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ) ).replace( "{contentbaseId}",
                        assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, "12345" );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;
            case "Org-Id and Staff-Id are from different Org":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_ASSIGNMENT_ALL_API;
                endpoint = endpoint.replace( "{orgID}", "8a7200af7f2c9d1b017f45c3000e04f9" ).replace( "{teacherID}", "ffffffff621e2e20a7f5d30030674a49" ).replace( "{contentbaseId}", assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                status = true;
                break;
            default:
                Log.fail( "Case is invalid" );
                break;
        }

        HashMap<String, String> getresponse = changeAssignmentStatusForAllStudents( smUrl, assignmentDetails, assignmentDetails.get( AssignmentAPIConstants.STATUS ), endpoint );
        Log.message( "StatusCode: " + getresponse.get( "statusCode" ) );
        Log.message( "Response: " + getresponse.get( "body" ) );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
        if ( message != null ) {
            verifyException( getresponse.get( "body" ), exception, status, message );
        }
    }

    /**
     * Data provider for Negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "PauseResumeAllStudentsAssignment_NegativeFlow" )
    public Object[][] PauseResumeAllStudentsAssignment_NegativeFlow() {

        Object[][] inputData = { { "Verify the status code is 403 for Incorrect orgId in Headers", "Incorrect orgId in Headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code is 403 for invalid Staff-Id in headers which is present in DB", "Invalid Staff-Id in headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code is 404 when the URL is wrong", "Incorrect URL", CommonAPIConstants.STATUS_CODE_NOTFOUND },
                { "Verify the response body of 401 and response body - Invalid Bearer Token", "Invalid Bearer Token", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify 400 status code and response body, when status is given with invalid data other than ACTIVE and INACTIVE in the request payload", "Invalid Payload", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify 400 status code and response body, when status is given with invalid data type in the request payload", "Invalid data type in the request payload", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify 400 status code and response body, when status is given with valid data in lower case (active or inactive) in the request payload", "Payload in LowerCase", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify 400 status code and response body, when organisationId is given with invalid data in the path params", "organisationId with invalid data in the path parameters", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Veriy 400 status code and response body, with Invalid staffId not in DB in path params", "Invalid staffId not in DB in path params", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Veriy 400 status code and response body, with Invalid staffId present in DB in path params", "Invalid staffId present in DB in path parameters", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Veriy 200 status code and the response body, when contentbaseId is given with invalid data in the path params", "Invalid contentbaseId", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify 400 status code and response body, when path params are given with invalid data type", "Path parameters with Invalid Datatype", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Validate 401 for valid OrgID and Invalid StaffId in Header parameter", "Invalid StaffId", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Validate that the status code is 400 when Org-Id and Staff-Id in path parameters and headers are from different organizations", "Org-Id and Staff-Id are from different Org", CommonAPIConstants.STATUS_CODE_BAD_REQUEST } };
        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    /**
     * Verify the Schema for the API
     * 
     * @param StatusCode
     * @param Body
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = smAPIprocessor.isSchemaValid( "PauseResumeAllStudentAssignment", StatusCode, response.get( "body" ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
        Log.assertThat( isValid, "The schema is valid and mathcing", "The schema is not valid and not  mathcing for the Status code :" + StatusCode );
    }
}