package com.savvas.sm.common.utils.apiconstants;

public interface MasteryAPIConstants {

    interface Mastery_GraphQL_Assignments {

        public static String DOUBLE_QUOTATION = "\"";
        public static String BACKWARD_SLASH = "\\";
        public static String ASSIGNMENT_ASSIGNER_FIRST_NAME = "assignmentAssignerFirstName";
        public static String ASSIGNMENT_ASSIGNER_LAST_NAME = "assignmentAssignerLastName";
        public static String ASSIGNMENT_ID = "assignmentId";
        public static String ASSIGNMENT_NAME = "assignmentName";
        public static String SUBJECT_ID = "subjectId";
        public static String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  assignments(\\n    orgId: \\\"%s\\\"\\n    userId: \\\"%s\\\"\\n    subjectId: \\\"%s\\\"\\n  ) %s\\n}\\n\"}";
        public static String ORG_ID = "org-id";
        public static String USER_ID = "user-id";
        public static String ORG_ID_VALUE = "8a7200af7f2c9d1b017f45c3000e04f9";
        public static String INVALID_ORG_ID_VALUE = "8a720a958018dddb01803cf618d96eda";
        public static String USER_ID_VALUE = "ffffffff621e34ce7310d1002e79f12b";
        public static String INVALID_USER_ID_VALUE = "ffffffff62600a04bcb4bb002f1e7a25";
        public static String USER_NAME = "teacher_d1";
        public static String USER_ID_VALUE_ZERO = "ffffffff623b200abaa845002e4200c6";
        public static String USER_NAME_ZERO = "teacher_d01";
        public static String PASSWORD = "testing123$";
        public static String STUDENT_USER_NAME = "student_d1";
        public static String STUDENT_USER_ID = "ffffffff621e37374d2d9c00307dde8a";

    }

    interface MasteryDetailsConstant {
        // constant variables for headers
        String ORGANIZATION_ID = "org-id";
        String USER_ID = "user-id";

        String ORGANIZATION_ID_VALUE = "8a72019a7f90ca06017fc105e39e1729";
        String USER_ID_VALUE = "ffffffff624d64090677c600305f96fd";

        String USERNAME_VALUE = "jesko_mastery_teacher4";
        String PASSWORD = "testing123$";

        //constant variables for request Body
        String REQ_LEARNING_OBJECT_ID = "learningObjectId";
        String REQ_SKILL_OBJECT_ID = "skillObjectId";
        String REQ_ASSIGNMENT_USER_IDS = "assignmentUserIds";
        String REQ_STANDARD_VERSION_ID = "standardVersionId";

        // Constant values for request Body 
        String LEARNING_OBJECT_FOR_MATH = "319";
        String LEARNING_OBJECT_FOR_READING = "-1";
        String SKILL_OBJECT_ID_FOR_MATH = "-1";
        String SKILL_OBJECT_ID_FOR_READING = "319";
        String ASSIGNMENT_USER_ID_VALUES = "14099";
        String STANDARD_VERSION_ID_VALUES = "1";
        String ASSIGNMENT_USER_ID_VALUES_FOR_READING = "14099";
        String STANDARD_VERSION_ID_VALUES_FOR_READING = "1";
        //negative static values for request payload
        String INVALID_USER_ID_VALUE = "ffffffff624d64090677c600305f96fd1";
        String INVALID_ORG_ID_VALUE = "8a72019a7f90ca06017fc105e39e17291";
        String INVALID_ASSIGNMENT_USER_ID_VALUES = "";
    }

    interface MasterySummaryConstants {
        // constant variables for headers
        String ORGANIZATION_ID = "org-id";
        String USER_ID = "user-id";

        String ORGANIZATION_ID_VALUE = "8a72019a7f90ca06017fc105e39e1729";
        String USER_ID_VALUE = "ffffffff624d64090677c600305f96fd";
        String USERNAME_VALUE = "jesko_mastery_teacher4";
        String PASSWORD = "testing123$";

        //constant variables for request Body
        String REQ_SUBJECTID = "subjectId";
        String REQ_STUDENTIDS = "studentIds";
        String REQ_ASSIGNMENTIDS = "assignmentIds";
        String REQ_STANDARDID = "standardId";
        String REQ_CONTENTBASEID = "contentBaseId";

        //static values for request payload

        String MATH_SUBJECT_ID = "1";
        String READING_SUBJECT_ID = "2";
        String STUDENT_USER_ID_1 = "ffffffff624d6470cb914c19f501a84c";
        String ASSIGNMENTID_VALUE1 = "6125";
        String ASSIGNMENTID_VALUE_READING = "6124";

        String STANDARDID_VALUE = "1";
        String CONTENT_BASEID_VALUE = "6125";

        //negative static values for request payload

        String INVALID_SUBJECTID = "abcd2233";
        String INVALID_STUDENTID = "ffffffff61d424796e4125002f23139e1";
        String INVALID_ASSIGNMENTID = "2345678";
        String INVALID_STANDARD_ID = "435678";
        String INVALID_USER_ID_VALUE = "ffffffff61d4248e6e4125002f231c5b1";
        String INVALID_ORG_ID_VALUE = "8a7200f77de565ac017e2498d0bf06ae1";
    }

    public interface Mastery_Summary_BFF {
        public static String DOUBLE_QUOTATION = "\"";
        public static String BACKWARD_SLASH = "\\";
        public static String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  masterySummary(\\n    subjectId: %s    isAdminCall: %s\\n    studentIds: %s\\n  ) %s\\n}\\n\"}";
        public static String REQ_PAYLOAD_ADMIN = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  masterySummary(\\n    subjectId: %s\\n    isAdminCall: %s\\n    orgId: \\\"%s\\\"\\n    studentIds: %s\\n  ) {\\n    flatHierarchyMap {\\n      id\\n      map {\\n        id\\n        name\\n        tierDepth\\n        grandParentName\\n        grandParentId\\n        parentId\\n        childNodes\\n        leafNode\\n        printPartner\\n        emptyNode\\n        gradeId\\n        displayOrder\\n      }\\n    }\\n    leafFlatHierarchyMap {\\n      id\\n      map {\\n        id\\n        name\\n        tierDepth\\n        grandParentName\\n        grandParentId\\n        parentId\\n        childNodes\\n        leafNode\\n        printPartner\\n        emptyNode\\n        gradeId\\n        displayOrder\\n        loCourseLevel\\n        loCatalogNumber\\n        viewLoUrl\\n      }\\n    }\\n    masteryMap {\\n      id\\n      map {\\n        masteredCount\\n        notMasteredCount\\n        atRiskCount\\n      }\\n    }\\n    assignmentUserIds\\n  }\\n}\\n\"}\r\n";
        public static String REQ_PAYLOAD_ALL_FIELDS = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  masterySummary(\\n    subjectId: %s    isAdminCall: %s\\n  studentIds: %s\\n  standardId: %s\\n   assignmentIds: %s\\n  contentBaseId: %s\\n ) %s\\n}\\n\"}";

        //Query Items LIST
        public static String FLAT_HIERARCHY_MAP = "flatHierarchyMap{";
        public static String LEAF_FLAT_HIERARCHY_MAP = "leafFlatHierarchyMap{";
        public static String MASTERY_MAP = "masteryMap{";
        public static String ASSIGNMENT_IDS = "assignmentUserIds";

        public static String ID = "id";
        public static String NAME = "name";
        public static String TIER_DEPTH = "tierDepth";
        public static String GRAND_PARENT_NAME = "grandParentName";
        public static String GRAND_PARENT_ID = "grandParentId";
        public static String PARENT_ID = "parentId";
        public static String CHILD_NODES = "childNodes";
        public static String LEAF_NODE = "leafNode";
        public static String PRINT_PARTNER = "printPartner";
        public static String EMPTY_NODE = "emptyNode";
        public static String GRADE_ID = "gradeId";
        public static String DISPLAY_ORDER = "displayOrder";

        public static String LO_COURSE_LEVEL = "loCourseLevel";
        public static String LO_CATALOG_NUMBER = "loCatalogNumber";
        public static String VIEW_LO_URL = "viewLoUrl";

        public static String MAP = "map";

        public static String MASTERED_COUNT = "masteredCount";
        public static String NOT_MASTERED_COUNT = "notMasteredCount";
        public static String AT_RISK_COUNT = "atRiskCount";

        // constant variables for headers
        String ORGANIZATION_ID = "org-id";
        String USER_ID = "user-id";

        String REQ_STANDARDID = "standardId";
        String REQ_CONTENTBASEID = "contentBaseId";
        String REQ_ISADMINCALL = "isAdminCall";

        String ORGANIZATION_ID_VALUE = "8a720a958018dddb01803c4c936f6ec2";
        String TEACHER_ID_VALUE = "ffffffff625d431ebcb4bb002f1e5e66";
        String TEACHER_USER_NAME = "as_mastery_teacher";
        String CA_USER_NAME = "customeradmin_school";
        String CA_ID_VALUE = "ffffffff62600a04bcb4bb002f1e7a25";
        String CA_ORG_ID = "8a720a958018dddb01803cf618d96eda";
        String PASSWORD = "testing123$";
        String STUDENT_USER_ID_VALUE = "[\\\"ffffffff625d4440bcb4bb002f1e5ea4\\\", \\\"ffffffff625d4474bcb4bb002f1e5ea5\\\"]";
        String EMPTY_STUDENT_ID = "[]";
        String ISADMINCALL_VALUE_TEACHER = "false";
        String ISADMINCALL_VALUE_ADMIN = "true";

        String MATH_SUBJECT_ID = "1";
        String READING_SUBJECT_ID = "2";
        String ASSIGNMENT_ID_VALUE = "[6881]";
        String CONTENT_BASE_ID_VALUE = "-1";
        String STANDARD_ID_VALUE = "1";

        String INVALID_ORG_ID_VALUE = "8a72af72c9d1b017f45c3000e04f9";
        String INVALID_USER_ID_VALUE = "adfgh";
        String INVALID_STUDENT_ID = "[aaas34567835]";
        String STUDENT_ID_VALUE = "ffffffff625d4440bcb4bb002f1e5ea4";
        String INVALID_ASSIGNMENT_ID_VALUE = "[234567]";
        String INVALID_SUBJECT_ID = "3";

        String FORBIDDEN_MESSAGE = "403: Forbidden";
        String UNAUTHORIZED = "401: Unauthorized";
        String UNAUTHENTICATED = "Not authenticated.";
        String INVALID_SUBJECT_ID_MESSAGE = "Invalid value passed for Subject Id";
        String ACCESS_DENIED = "Access denied! You don't have permission for this action!";

    }

    interface MasteryPerformanceConstants {
        // constant variables for headers
        String ORGANIZATION_ID = "org-id";
        String USER_ID = "user-id";

        String ORGANIZATION_ID_VALUE = "8a720a958018dddb01803c4c936f6ec2";
        String USER_ID_VALUE = "ffffffff625d431ebcb4bb002f1e5e66";
        String USERNAME_VALUE = "as_mastery_teacher";
        String PASSWORD = "testing123$";
        //constant variables for request Body
        String REQ_SUBJECTID = "subjectId";
        String REQ_STUDENTIDS = "studentIds";
        String REQ_ASSIGNMENTIDS = "assignmentIds";

        String REQ_LIMIT = "limit";

        //static values for request payload

        String MATH_SUBJECT_ID = "1";
        String READING_SUBJECT_ID = "2";
        String STUDENT_USER_ID_1 = "ffffffff625d4440bcb4bb002f1e5ea4";
        String ASSIGNMENTID_VALUE1 = "6881";
        String LIMIT = "3";

        //negative static values for request payload

        String INVALID_USER_ID_VALUE = "ffffffff61d4248e6e4125002f231c5b1";
        String INVALID_ORG_ID_VALUE = "8a7200f77de565ac017e2498d0bf06ae1";

}
    
    
    interface Mastery_Performance_Standards {
        // constant variables for headers
        String ORGANIZATION_ID = "org-id";
        String USER_ID = "user-id";

        String ORGANIZATION_ID_VALUE = "8a720a958018dddb01803cf618d96eda";
        String USER_ID_VALUE = "ffffffff625e57a7bcb4bb002f1e751b";
        String USERNAME_VALUE = "sm_jesko_basic_teach2";
        String PASSWORD = "testing123$";
        //constant variables for request Body
        String REQ_SUBJECTID = "subjectId";
        String REQ_STUDENTIDS = "studentIds";
        String REQ_ASSIGNMENTIDS = "assignmentIds";
        String REQ_STANDARDIDS = "standardId";

        String REQ_LIMIT = "limit";

        //static values for request payload

        String MATH_SUBJECT_ID = "1";
        String READING_SUBJECT_ID = "2";
        String STUDENT_USER_ID_1 = "ffffffff625e58161f2281217a860abb";
        String STUDENT_USER_ID_2 = "ffffffff625e584b1f2281217a860abc";
        String STUDENT_USER_ID_3 = "ffffffff625e587e1f2281217a860abd";
        String standardId = "1000024930";
        String ASSIGNMENTID_VALUE1 = "6989";
        String LIMIT = "3";

        //negative static values for request payload

        String INVALID_USER_ID_VALUE = "ffffffff61d4248e6e4125002f231c5b1";
        String INVALID_ORG_ID_VALUE = "8a6500f77er565ac017e2498d0bf06541";

}
  
  public interface Mastery_Performance_BFF {
      public static String DOUBLE_QUOTATION = "\"";
      public static String BACKWARD_SLASH = "\\";
      public String REQ_PAYLOAD_ALL_PARAMS = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  masteryPerformanceDetails(\\n    subjectId: %s\\n    assignmentIds: %s\\n    standardId: %s\\n    limit: %s\\n  ) %s\\n}\\n\"}";
      //Query Items LIST
      public static String TOP_PERFORMERS = "topPerformers{";
      public static String LOW_PERFORMERS = "lowPerformers{";
      public static String ID = "id";
      public static String TITLE = "title";
      public static String MASTERY_PERCENT = "masteryPercent";

      // constant variables for headers
      String ORGANIZATION_ID = "org-id";
      String USER_ID = "user-id";

      String REQ_STANDARDID = "standardId";
      
      String ORGANIZATION_ID_VALUE = "8a720a958018dddb01803c4c936f6ec2";
      String TEACHER_ID_VALUE = "ffffffff625d431ebcb4bb002f1e5e66";
      String TEACHER_USER_NAME = "as_mastery_teacher";
      String CA_USER_NAME = "customeradmin_school";
      String CA_ID_VALUE = "ffffffff62600a04bcb4bb002f1e7a25";
      String CA_ORG_ID = "8a720a958018dddb01803cf618d96eda";
      String PASSWORD = "testing123$";
      String STUDENT_USER_ID_VALUE = "[\\\"ffffffff625d4440bcb4bb002f1e5ea4\\\", \\\"ffffffff625d4474bcb4bb002f1e5ea5\\\" ,\\\"ffffffff625d449bbcb4bb002f1e5ea6\\\"  ,\\\"ffffffff62694e960ada1e0031c518a9\\\",\\\"ffffffff6269518b881b8b002d782616\\\" ]";
      

      String MATH_SUBJECT_ID = "1";
      String READING_SUBJECT_ID = "2";
      String ASSIGNMENT_ID_VALUE = "[6881]";
      String STANDARD_ID_VALUE = "1";
      String LIMIT_COUNT ="3";

      String INVALID_ORG_ID_VALUE = "8a7200af7f2c9d1b017f45c3000e04f9";
      String INVALID_USER_ID_VALUE = "adfgh";
      String INVALID_STUDENT_ID = "[aaas34567835]";
      String STUDENT_ID_VALUE = "ffffffff625d4440bcb4bb002f1e5ea4";
      String INVALID_ASSIGNMENT_ID_VALUE = "[234567]";
      String INVALID_SUBJECT_ID = "3";

      String FORBIDDEN_MESSAGE = "403: Forbidden";
      String UNAUTHORIZED = "401: Unauthorized";
      String INVALID_SUBJECT_ID_MESSAGE = "Invalid value passed for Subject Id";
      String NOT_AUTHENTICATED = "Not authenticated.";
      String BAD_REQUEST = "Bad Request";
  }
   

    interface Mastery_LoDetails_BFF {

        // constant variables for headers
        String ORGANIZATION_ID = "org-id";
        String USER_ID = "user-id";

        //Constant Variables for request payload
        String ID = "id";
        String MASTERY_DETAILS = "masteryDetails";
        String ASSIGNMENT_TITLE = "assignmentTitle";
        String PERSON_ID = "personId";
        String MASTERY_STATUS_ID = "masteryStatusId";
        String SKILLS_EVALUATED = "skillsEvaluated";
        String ATTEMPTS = "attempts";
        String FIRST_NAME = "firstName";
        String LAST_NAME = "lastName";
        String USER_NAME = "userName";

        //Static Value for Headers and request payload
        String ORG_ID_VALUE = "8a720a958018dddb01803c4c936f6ec2";
        String INVALID_ORG_ID_VALUE = "8a720a958018dddb01803cf618d96eda";

        String TEACHER_USERNAME = "as_mastery_teacher";
        String CA_USERNAME = "as_mastery_admin";
        String STUDENT_USERNAME = "as_mastery_student01";
        String TEACHER_USER_ID_VALUE = "ffffffff625d431ebcb4bb002f1e5e66";
        String CUSTOMER_USER_ID_VALUE = "ffffffff6269521b9b57f500327f875f";
        String STUDENT_USER_ID_VALUE = "ffffffff625d4440bcb4bb002f1e5ea4";
        String INVALID_USER_ID_VALUE = "ffffffff62669e16ffbb3e00311c9360";

        String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  masteryDetails(\\n    learningObjectId: %s    skillObjectId: %s\\n    assignmentUserIds: %s\\n  ) %s\\n}\\n\"}";
        String REQ_PAYLOAD_ALL_PARAMS = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  masteryDetails(\\n    learningObjectId: %s    skillObjectId: %s\\n    assignmentUserIds: %s\\n  standardVersionId: %s\\n   ) %s\\n}\\n\"}";
        String PASSWORD = "testing123$";
    }
    
}
