package com.savvas.sm.teacher.ui.tests.TeacherSmokeSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;
import LSTFAI.customfactories.EventFiringWebDriver;
import com.savvas.sm.config.EnvProperties;

public class GroupsUsageandSkillAssessmentSmokeTest extends EnvProperties {

    private String smUrl;
    private String browser;
    private String sessionCookie;
    private String username = null;
    private String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private boolean isGroupCrossedHours = false;
    LoginPage smLoginPage;
    TeacherHomePage tHomePage;
    private static String groupOne;
    private static String groupDetails1;
    private static String studentOne;
    private static String studentTwo;
    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    @BeforeClass
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );

        String studentDetails1 = RBSDataSetup.getMyStudent( school, username );
        String studentDetails2 = RBSDataSetup.getMyStudent( school, username );
        String studentDetails4 = RBSDataSetup.getMyStudent( school, username );
        String studentDetails5 = RBSDataSetup.getMyStudent( school, username );

        studentOne = ( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ) );
        studentTwo = ( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERNAME ) );

        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERID ) );

        HashMap<String, String> groupDetailsMap = new HashMap<>();
        groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, "SM Regression Group" + System.nanoTime() );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );
        groupDetails1 = createGroup.get( Constants.BODY );
        groupOne = SMUtils.getKeyValueFromResponse( groupDetails1, "data,groupName" );

        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, "SM Regression Group" + System.nanoTime() );
        createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );

    }

    @Test ( description = "Verify the Groups - Graphs - Usage  if the student usage only from this week", groups = { "smoke_test_case", "SmokeTeacher_TC38", "GroupUsageGraph" }, priority = 1 )
    public void smokeGroupUsageGraph_002( ITestContext context ) throws Exception {

        WebDriver driver = null;
        WebDriver chromeDriver = WebDriverFactory.get( chromePlatform ); //for simulator run

        Log.testCaseInfo( "smokeGroupUsageGraph_002:Verify the Groups - Graphs - Usage  if the student usage only from this week <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Executing math and reading assignments in student dashboard
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage = smStudentLoginPage.loginToSMasStudent( studentOne, password, true );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ), "Math", "100", "3", "10" );
            studentOneDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ), "Reading", "100", "3", "10" );
            studentOneDashboardPage.logout();
            chromeDriver.quit();

            // Get driver
            driver = WebDriverFactory.get( browser );
            // Login as Teacher
            smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupOne );

            //Validations
            Log.assertThat( groupsTab.verifyGroupUsageChart(), "Group usage fields are verified successfully!", "Issue with group usage fields." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Skills Assessment is displayed in the Group details Page", groups = { "smoke_test_case", "Teacher_TC48", "groupSkillsAssessment" }, priority = 1 )
    public void smokeGroupSkillAssesst_003() throws Exception {

        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "smokeGroupSkillAssesst_003: Verify the Skills Assessment is displayed in the Group details Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Course Listing Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to groups
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();
            coursePage.clickBackIcon();

            // Selecting Reading Course and assigning to groups
            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();

            SMUtils.logDescriptionTC( "SMK-14077 - Verify zero state is displayed if the assessment is not started by the students" );
            // Navigate to Groups Tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupOne );

            //Verify zero state message for student usage chart
            String zeroStateFromUI = groupsTab.getSkillsAssessmentZeroState();
            Log.assertThat( zeroStateFromUI.contains( Constants.GroupUIConstants.SKILLASSESS_ZEROSTATEMESSAGE.get( 0 ) ) && zeroStateFromUI.contains( Constants.GroupUIConstants.SKILLASSESS_ZEROSTATEMESSAGE.get( 1 ) ),
                    "Zero state message is displayed sucessfully for Skills Assessment!", "Zero state message is not displayed properly for Skills Assessment." );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
