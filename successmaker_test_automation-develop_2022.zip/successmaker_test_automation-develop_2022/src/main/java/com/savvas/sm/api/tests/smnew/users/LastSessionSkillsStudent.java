package com.savvas.sm.api.tests.smnew.users;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.CourseExecution;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.GetGroupMostAssessedSkill;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentSkillAssesedConstants;
import com.savvas.sm.utils.sql.helper.SQLConstants.Course;

import LSTFAI.customfactories.EventFiringWebDriver;

import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * @author navas.hussain
 *
 */
public class LastSessionSkillsStudent extends UserAPI {

    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails = null;
    private String coTeacherDetails = null;
    private String orgId = null;
    private String teacherId = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static HashMap<String, String> contentBase = new HashMap<>();
    private static HashMap<String, String> contentBaseName = new HashMap<>();
    private static HashMap<String, String> assignmentIds = new HashMap<String, String>();

    private List<String> courseIDs = new ArrayList<>();
    private List<String> schools = new ArrayList<>();
    private HashMap<String, String> response = new HashMap<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private HashMap<String, String> userDetails = new HashMap<>();
    private String exception = null;
    private boolean status = false;
    private String message = null;
    // other school constants
    // other school constants
    private String readingSchoolId;
    private String readingSchoolTeacherId;
    private String readingSchoolTeacherUsername;
    private String secondTeacherId;
    private String secondTeacherUsername;
    private String username;
    private String studentDetail = null;
    private String studentUserID;
    private String studentUsername;

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );

        studentDetail = RBSDataSetup.getMyStudent( school, username );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );

        studentRumbaIds.add( studentUserID );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), "userId" ) );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, "SM Focus Math: Grade 1" );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

        Log.message( "contentbasename" + contentBaseName );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS,
                contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL,
                contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS,
                contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        Log.message( "Assigning assignment..." );

        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details" + assignmentResponse );
        String username = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        Log.message( "username:" + username );
        try {
//            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
//            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ), true );
//            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true );
//            executeCourse( studentUsername, "SM Focus Math: Grade 1", true );

//            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
//            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ), false );
//            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ), false );
//            executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false );
//            executeCourse( studentUsername, "SM Focus Reading: Grade 1", false );
            
            new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true, "100", "1", "10" );
            new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ), true, "100", "1", "10" );
            new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true, "100", "1", "10" );
            new CourseExecution().executeCourse( username, "SM Focus Math: Grade 1", true, "100", "1", "10" );
            new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, "100", "1", "10" );
            new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ), false, "100", "1", "10" );
            new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ), false, "100", "1", "10" );
            new CourseExecution().executeCourse( username,contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false, "100", "1", "10" );
            new CourseExecution().executeCourse( username, "SM Focus Reading: Grade 1", false, "100", "1", "10" );

        } catch ( IOException e ) {
            e.printStackTrace();
        }

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        Log.message( "assignmentDetailsJson" + assignmentDetailsJson );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        Log.message( "Assignment IDs - " + assignmentIds );
    }

    @Test ( priority = 1, dataProvider = "lastSessionSkillsPositive", groups = { "smoke_test_case", "Smoke Last Session Skills", "Last Session Skills", "SMK-52020", "Students", "Last Session Skills", "P1", "API" } )
    public void tcPositiveTestcases( String description, String scenario, String statusCode ) throws Exception {
        
        Log.testCaseInfo( description );

        switch ( scenario ) {
            case "HAPPY_PATH":
                HashMap<String, String> apiDetails = new HashMap<String, String>();

                SMUtils.logDescriptionTC( "Verify the Response code for the Math Default courses" );
                SMUtils.logDescriptionTC( "Verify when the assignment has morethen one skill associated " );
                //executeCourse( studentUsername, Constants.MATH, true);

                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                // apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );

                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );

                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                verifyResponse( response.get( Constants.REPORT_BODY ), true );

                break;

            case "MATH_CUSTOM_BY_SKILLS":
                HashMap<String, String> apiDetails1 = new HashMap<String, String>();
                SMUtils.logDescriptionTC( "Verify the Response code for the Math Default courses" );
                SMUtils.logDescriptionTC( "Verify the response contains only one skill with one LO in math courses" );
                SMUtils.logDescriptionTC( "Verify the response contains more then one Sco Ids for one skill in reading courses  " );
                SMUtils.logDescriptionTC( "Verify the response contains proper viewLoUrl returned " );
                SMUtils.logDescriptionTC( "Verify each LO/Sco description given in response along with LO/Sco ID " );
                SMUtils.logDescriptionTC( "Verify the skill group contains completedTotalLoAttempts in response " );
                apiDetails1.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails1.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails1.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails1.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
                apiDetails1.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails1.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails1.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails1.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails1.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails1 );
                Log.message( "Last Session Skills - " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                verifyResponse( response.get( Constants.REPORT_BODY ), true );

                break;

            case "MATH_CUSTOM_BY_SETTINGS":
                SMUtils.logDescriptionTC( "Verify the Response code for the Math Default courses" );
                SMUtils.logDescriptionTC( "Verify the response contains only one skill with one LO in math courses" );
                SMUtils.logDescriptionTC( "Verify the response contains more then one Sco Ids for one skill in reading courses  " );
                SMUtils.logDescriptionTC( "Verify the response contains proper viewLoUrl returned " );
                SMUtils.logDescriptionTC( "Verify each LO/Sco description given in response along with LO/Sco ID " );
                SMUtils.logDescriptionTC( "Verify the skill group contains completedTotalLoAttempts in response " );
                HashMap<String, String> apiDetails2 = new HashMap<String, String>();

                apiDetails2.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails2.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails2.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails2.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails2.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
                apiDetails2.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails2.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails2.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails2.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails2.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails2 );
                Log.message( "Last Session Skills - " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                verifyResponse( response.get( Constants.REPORT_BODY ), true );

                break;

            case "FOCUS_MATH_ASSIGNMENT":
                HashMap<String, String> apiDetails3 = new HashMap<String, String>();

                apiDetails3.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails3.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails3.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails3.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails3.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) ) );
                apiDetails3.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails3.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails3.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails3.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails3.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails3 );
                Log.message( "Last Session Skills - " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                verifyResponse( response.get( Constants.REPORT_BODY ), true );

                break;

            case "DEFAULT_READ_ASSIGNMENT":
                HashMap<String, String> apiDetails4 = new HashMap<String, String>();

                apiDetails4.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails4.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails4.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails4.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails4.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE ) ) );
                apiDetails4.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "2" );
                apiDetails4.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails4.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails4.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails4.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails4 );
                Log.message( "Last Session Skills - " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                verifyResponse( response.get( Constants.REPORT_BODY ), true );

                break;

            case "FOCUS_READ_ASSIGNMENT":
                HashMap<String, String> apiDetails5 = new HashMap<String, String>();

                apiDetails5.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails5.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails5.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails5.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails5.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) ) );
                apiDetails5.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "2" );
                apiDetails5.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails5.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails5.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails5.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails5 );
                Log.message( "Last Session Skills - " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                verifyResponse( response.get( Constants.REPORT_BODY ), true );
                break;

            case "SHARED_STUDENT_GROUP":
                HashMap<String, String> apiDetails6 = new HashMap<String, String>();


                String sharedTeacher = "SharedTeacher" + System.nanoTime();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, sharedTeacher );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );

                String sharedTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                new RBSUtils().resetPassword( userDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ), RBSDataSetupConstants.DEFAULT_PASSWORD, sharedTeacherID );

                String groupName = "SharedStudentGroup";
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( sharedTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, sharedTeacherID );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
                new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );

                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
                groupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

                apiDetails6.put( Constants.STAFF_ID_VALUE, sharedTeacherID );
                apiDetails6.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails6.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( sharedTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails6.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails6.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails6.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails6.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails6.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails6.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails6.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails6 );
                Log.message( "Last Session Skills - " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                verifyResponse( response.get( Constants.REPORT_BODY ), true );
                break;

            case "PAUSED_ASSIGNMENT":
                HashMap<String, String> apiDetails7 = new HashMap<String, String>();
                HashMap<String, String> assignmentDetails = new HashMap<>();


                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                //assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );

                Log.message( "Pausing the assignment." + assignmentDetails );
                new AssignmentAPI().changeAssignmentStatusForAllStudents( smUrl, assignmentDetails, AssignmentAPIConstants.STATUS_INACTIVE, CourseAPIConstants.NULL );
               // changeAssignmentStatusForAllStudents( smUrl, assignmentDetails, AssignmentAPIConstants.STATUS_INACTIVE, CourseAPIConstants.NULL );

                apiDetails7.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails7.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails7.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails7.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails7.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails7.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails7.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails7.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails7.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails7.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails7 );
                Log.message( "Last Session Skills - " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                verifyResponse( response.get( Constants.REPORT_BODY ), true );
                break;

            case "SUSPENDED STUDENT":
                HashMap<String, String> apiDetails8 = new HashMap<String, String>();


                Log.message( "Suspending users..." );
                new RBSUtils().suspendUser( studentRumbaIds );

                apiDetails8.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails8.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails8.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                apiDetails8.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails8.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails8.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails8.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails8.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails8.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails8.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails8 );
                Log.message( "Last Session Skills - " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                verifyResponse( response.get( Constants.REPORT_BODY ), true );
                break;

        }
        Log.testCaseResult();
    }

    @DataProvider ( name = "lastSessionSkillsPositive" )
    public Object[][] lastSessionSkillsPositive() {

        //Cases are commented due to future backlog.

        Object[][] inputData = { { "Verify the status code is 200 for the valid data.", "HAPPY_PATH", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify when the assignment has only one Skill associated ", "MATH_CUSTOM_BY_SKILLS", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the status code is 200 for Math custom by settings course", "MATH_CUSTOM_BY_SETTINGS", CommonAPIConstants.STATUS_CODE_OK },
                //{ "Verify the Response code for the Reading Default courses ", "DEFAULT_READ_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
                //{ "Verify the Response code for the Focus Math courses", "FOCUS_MATH_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
                //{ "Verify the response code for the Focus Reading courses.", "FOCUS_READ_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the response code when student is shared student", "SHARED_STUDENT_GROUP", CommonAPIConstants.STATUS_CODE_OK }, { "Verify the response code when assignment is Paused", "PAUSED_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the response code when student is suspended", "SUSPENDED STUDENT", CommonAPIConstants.STATUS_CODE_OK }, };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "lastSessionSkillsNegative", groups = { "SMK-52020", "Students", "Last Session Skills", "P1", "API" } )
    public void tcNegativeTestcases( String description, String scenario, String statusCode ) throws Exception {
        HashMap<String, String> apiDetails = new HashMap<String, String>();

        Log.testCaseInfo( description );
        switch ( scenario ) {
            case "INVALID_SUBJECT_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, studentRumbaIds.get( 0 ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "3" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.EMPTY_ASSIGNMENT_USER_ID_MESSAGE;
                exception = CommonAPIConstants.VALIDATION_EXCEPTION;
                break;

            case "INVALID_ASSIGNMENT_USER_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, studentRumbaIds.get( 0 ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( StudentSkillAssesedConstants.INVALID_ASSIGMENT_USER_ID, "ABCD" );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.JSON_PARSE_MESSAGE;
                exception = CommonAPIConstants.MESSAGE_NOT_READABLE_EXCEPTION;
                break;

            case "INVALID_SESSION_DATES":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, getLastSessionDates( Arrays.asList( "" ) ) );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                break;

            case "INVALID_ORG_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( GroupConstants.INVALID_ORG, "ABCD1234" );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = String.format( CommonAPIConstants.MISMATCH_ORG_MESSAGE, "ABCD1234", RBSDataSetup.organizationIDs.get( school ) );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                break;

            case "DIFFERENT_VALID_ORG_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, readingSchoolId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                break;

            case "INVALID_STAFF_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( UserConstants.INVALID_TEACHER, "Abcd1234" );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.MISMATCH_TEACHER_MESSAGE;
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                break;

            case "DIFFERENT_VALID_STAFF_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, readingSchoolTeacherId );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                break;

            case "INVALID_STUDENT_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) + 123 );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                break;

            case "DIFFERENT_VALID_STUDENT_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) + 123 );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) + 1 );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) + 123 );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                break;

            case "INVALID_ASSIGNMENT_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) + 1 );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.INVALID_ASSIGMENT_ID, "Abcd123" );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                break;

            case "DIFFERENT_VALID_ASSIGNMENT_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                break;

            case "INVALID_STUDENT_AUTHORIZATION":
                apiDetails.put( Constants.STAFF_ID_VALUE, studentRumbaIds.get( 0 ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "INVALID_ACCESS_TOKEN":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "NULL_SUBJECTTYPE_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.JSON_PARSE_MESSAGE;
                exception = CommonAPIConstants.MESSAGE_NOT_READABLE_EXCEPTION;
                break;

            case "EMPTY_ASSIGNMENT_USER_ID":
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( StudentSkillAssesedConstants.ASSIGNMENT_USER_ID, "" );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "true" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.EMPTY_ASSIGNMENT_USER_ID_MESSAGE;
                exception = CommonAPIConstants.VALIDATION_EXCEPTION;
                break;

            case "SESSION_FLAG_FALSE":

                executeCourse( studentUsername, Constants.MATH, true );
                apiDetails.put( Constants.STAFF_ID_VALUE, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                apiDetails.put( Constants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                //apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                apiDetails.put( StudentSkillAssesedConstants.SUBJECT_TYPE_ID, "1" );
                apiDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), apiDetails.get( Constants.ASSIGNMENT_ID ) ) );
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern( "MM-dd-yyyy" );
                LocalDateTime now = LocalDateTime.now();
                String currentdate = dtf.format( now );
                apiDetails.put( StudentSkillAssesedConstants.SESSION_DATES, "[\"" + currentdate + "\"]" );
                apiDetails.put( StudentSkillAssesedConstants.LAST_SESSION_FLAG, "false" );
                response = getStudentSkillTested( smUrl, apiDetails );
                Log.message( "Last Session Skills - " + response );
                message = CommonAPIConstants.EMPTY_ASSIGNMENT_USER_ID_MESSAGE;
                exception = CommonAPIConstants.VALIDATION_EXCEPTION;
                break;
        }
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code matched", "The Status code Doesnot matched" );
        verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
    }

    @DataProvider ( name = "lastSessionSkillsNegative" )
    public Object[][] lastSessionSkillsNegative() {

        //Cases are commented due to future backlog.

        Object[][] inputData = { { "Verify the response code when the request body has been sent with subjectTypeId with any value other than 1 and 2.", "INVALID_SUBJECT_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the response code when the request body has been sent with invalid assignmentUserId", "INVALID_ASSIGNMENT_USER_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                // { "Verify the response code when the request body has been sent with  invalid sessionDates", "INVALID_SESSION_DATES", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the response code when the organizationId is invalid", "INVALID_ORG_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                // { "Verify the response code when the organizationId is from different org id ", "DIFFERENT_VALID_ORG_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the response code when the staffId is invalid", "INVALID_STAFF_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                //  { "Verify the response code when the staffId is from different org id", "DIFFERENT_VALID_STAFF_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                // { "Verify the response code when the studentId is invalid", "INVALID_STUDENT_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                //{ "Verify the response code when the studentId is from different org id", "DIFFERENT_VALID_STUDENT_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                //{ "Verify the response code when the assignmentId is invalid", "INVALID_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                //{ "Verify the response code when the assignmentId is from different org id", "DIFFERENT_VALID_ASSIGNMENT_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the response code when authorization is invalid(student authorization", "INVALID_STUDENT_AUTHORIZATION", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the response code when we pass invalid access token", "INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the 400 Response code when the request body of subjectTypeId is set as null", "NULL_SUBJECTTYPE_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the 400 Response code when the request body of assignmentUserId is set as empty", "EMPTY_ASSIGNMENT_USER_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the response code when the lastSessionFlag is set as false and sessionDates as empty", "SESSION_FLAG_FALSE", CommonAPIConstants.STATUS_CODE_OK }, };
        return inputData;
    }

    /**
     * Verifying the actual response
     * 
     * @param actualBody
     * @param isMath
     * @return
     */
    public boolean verifyResponse( String actualBody, boolean isMath ) {
        boolean isVerified = false;
        JSONObject actualBodyJsonObj = new JSONObject( actualBody );
        JSONArray actualBodyJsonArray = new JSONArray( actualBodyJsonObj.get( Constants.DATA ).toString() );
        for ( Object skill : actualBodyJsonArray ) {
            JSONObject skillDetails = new JSONObject( skill.toString() );
            String skillId = skillDetails.get( "skillId" ).toString();
            String skillDetailsFromDB = new SqlHelperCourses().getSkillDetails( skillId, isMath );
            if ( skillDetailsFromDB.equalsIgnoreCase( skillDetails.get( "skillName" ).toString() ) ) {
                isVerified = true;
                Log.pass( "Skill name verified successfully!" );
            } else {
                Log.fail( "Skill name is not matched - Expected -  " + skillDetailsFromDB + " Actual - " + skillDetails.get( "skillName" ).toString() );
            }
            JSONArray loDetails = skillDetails.getJSONArray( "loDetails" );
            for ( Object lo : loDetails ) {
                JSONObject loInfo = new JSONObject( lo.toString() );
                String loId = loInfo.get( "objectId" ).toString();
                HashMap<String, String> catalogDetails = new SqlHelperCourses().getCatalogDetails( loId );
                //if ( catalogDetails.get( Course.LO_OBJECT_DESCRIPTION ).equalsIgnoreCase( loInfo.get( Course.LO_OBJECT_DESCRIPTION ).toString() ) ) {
                if ( loInfo.get( Course.LO_OBJECT_DESCRIPTION ).toString().contains( catalogDetails.get( Course.LO_OBJECT_DESCRIPTION ) ) ) {
                    isVerified = true;
                    Log.pass( "LO name verified successfully! - " + loInfo.get( Course.LO_OBJECT_DESCRIPTION ).toString() );
                } else {
                    Log.fail( "LO name not Matched with actual response. Expected - " + catalogDetails.get( Course.LO_OBJECT_DESCRIPTION ) + "Actual - " + loInfo.get( Course.LO_OBJECT_DESCRIPTION ).toString() );
                }

                if ( catalogDetails.get( Course.CATALOG_NUMBER ).equalsIgnoreCase( loInfo.getString( Course.CATALOG_NUMBER ).toString() ) ) {
                    isVerified = true;
                    Log.pass( "Catalog number verified successfully! - " + loInfo.get( Course.CATALOG_NUMBER ).toString() );
                } else {
                    Log.fail( "LO name not Matched with actual response. Expected - " + catalogDetails.get( Course.CATALOG_NUMBER ) + "Actual - " + loInfo.getString( Course.CATALOG_NUMBER ).toString() );
                }
            }

        }
        return isVerified;

    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "10" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "10" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }

    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) {
        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception! Expected - " + exception + "Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ) );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    /**
     * To fetch the current session dates
     * 
     */

    public String getLastSessionDates( List<String> date ) {
        date = new ArrayList<String>();
        StringBuffer sessionDate = new StringBuffer();
        for ( int i = 0; i <= date.size(); i++ ) {
            sessionDate.append( "\"" + date.get( i ) + "\"" );
            if ( i != date.size() - 1 ) {
                sessionDate.append( "," );
            }
        }
        return ( "[" + sessionDate.toString() + "]" );
    }
    
   

}