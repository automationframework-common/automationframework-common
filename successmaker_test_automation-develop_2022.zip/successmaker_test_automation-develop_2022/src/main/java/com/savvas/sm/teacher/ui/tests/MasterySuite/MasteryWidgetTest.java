package com.savvas.sm.teacher.ui.tests.MasterySuite;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class MasteryWidgetTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String username = null;
    private String password = null;
    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    //Change this index if you want to select teacher other than "Teacher56"
    private String teacherIndex = "80";
    String staticCourseName = null;
    String studentDetails;
    String teacherDetails;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher" + teacherIndex );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        password = DataSetupConstants.DEFAULT_PASSWORD;
        studentDetails = DataSetup.teacherStudentMap.get( username ).get( "Student1" );
    }

    @Test ( description = "verify ViewAll Link Not Present When No Datak Available", priority = 1, groups = { "SMK-43631", "HomePage", "Mastery-Widget" } )
    public void verifyViewAllLinkNotPresentWhenNoDatakAvailable_01() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            Log.softAssertThat( tHomePage.isMasteryViewAllLinkPresent(), "View all link is not present when no data", "View all link is present" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the whether teacher is able to assign the course", priority = 2, groups = { "SMK-43631", "HomePage", "Mastery-Widget" } )
    public void verifyAssignCourse() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            CourseListingPage courseListingPage = new CourseListingPage( driver );
            CoursesPage customCourses = new CoursesPage( driver );
            List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
            List<String> studentList = new ArrayList<>();

            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            //To assign default Math course to the Student traverse to Courses page
            teacherHomePage.topNavBar.getCourseListingPage();

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the default Math course
            customCourses.clickFromCourseListingPage( Constants.MATH );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Assert Statement
            Log.softAssertThat( ( studentList.size() == studentListFromTheAssignmentPopup.size() ), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
                    Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //To assign default Reading course to the Student traverse to Courses page
            teacherHomePage.topNavBar.getCourseListingPage();

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the default Reading course
            customCourses.clickFromCourseListingPage( Constants.READING );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.READING );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Assert Statement
            Log.softAssertThat( ( studentList.size() == studentListFromTheAssignmentPopup.size() ), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
                    Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //sign out
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the student is able to attend the Math course via simulator", groups = { "SMK-43631", "HomePage", "HomePage - MasteryWidget" }, priority = 3 )
    public void verifyAttendCourse() throws Exception {
        Log.testCaseInfo( "Verify the student is able to attend the Math course via simulator" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        //WebDriver driver = null;
   		// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);//for simulator run

        try {
            Log.message( "The subject name is " + Constants.MATH );
            //Executing math assignments in student dashboard
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, "data,userName" );
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Constants.MATH, "95", "5", "5" );
            studentDashboardPage.logout();
            chromeDriver.quit();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify Mastery View All link present on Home Page", priority = 4, groups = { "SMK-43631", "HomePage", "Mastery-Widget" } )
    public void verifyMasteryViewAllLinkDisplayed_02() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            //Verify Mastery View all link displayed
            Log.softAssertThat( !teacherHomePage.isMasteryViewAllLinkPresent(), "Mastery View all link displayed", "Mastery View all link not displayed" );

            // Signout
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Mastery Data as per selected filters", priority = 5, groups = { "SMK-43631", "HomePage", "Mastery-Widget" } )
    public void verifyMasteryData_03() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );

            String selectedSubjectOnHome = masteryFiltersComponent.getSelectedValueFromSubjectDropDown();

            String defaultSkillStandardsOnHome = masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown();

            teacherHomePage.clickMasteryViewALL();

            masteryFiltersComponent.clickFilters();

            String selectedSubjectOnMastery = masteryFiltersComponent.getSelectedValueFromSubjectDropDown();

            String defaultSkillStandardsOnMastery = masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown();

            //verify mastery data subject
            Log.softAssertThat( selectedSubjectOnHome.equals( selectedSubjectOnMastery ), "Selected Subject displayed in mastery details", "Selected Subject is not displayed as mastery data" );

            //verify mastery data skills
            Log.softAssertThat( defaultSkillStandardsOnHome.equals( defaultSkillStandardsOnMastery ), "Selected Skills displayed in mastery details", "Selected Skills is not displayed as mastery data" );

            // Signout
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify Groups Radio Button Selected", priority = 6, groups = { "SMK-43631", "HomePage", "Mastery-Widget" } )
    public void verifyGroupsRadioButtonSelected_04() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            teacherHomePage.clickMasteryViewALL();

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );

            masteryFiltersComponent.clickFilters();

            //verify Groups radio button is selected by default
            Log.softAssertThat( masteryFiltersComponent.isGroupsChecked(), "ByDefault Groups Selected", "ByDefault Grops not selected" );

            // Signout
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify Groups Radio Button Selected And Verify Mastery data as per selected filters", priority = 7, groups = { "SMK-43631", "HomePage", "Mastery-Widget" } )
    public void verifyGroupsRadioButtonSelectedAndVerifyMasteryData_05() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );

            String selectedSubjectOnHome = masteryFiltersComponent.getSelectedValueFromSubjectDropDown();

            String defaultSkillStandardsOnHome = masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown();

            teacherHomePage.clickMasteryViewALL();

            masteryFiltersComponent.clickFilters();

            //verify Groups radio button is selected by default
            Log.softAssertThat( masteryFiltersComponent.isGroupsChecked(), "ByDefault Groups Selected", "ByDefault Grops not selected" );

            String selectedSubjectOnMastery = masteryFiltersComponent.getSelectedValueFromSubjectDropDown();

            String defaultSkillStandardsOnMastery = masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown();

            //verify mastery data subject
            Log.softAssertThat( selectedSubjectOnHome.equals( selectedSubjectOnMastery ), "Selected Subject displayed in mastery details", "Selected Subject not displayed in mastery details" );

            //verify mastery data skills
            Log.softAssertThat( defaultSkillStandardsOnHome.equals( defaultSkillStandardsOnMastery ), "Selected Skills displayed in mastery details", "Selected Skills not displayed in mastery details" );

            // Signout
            teacherHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify View All Link Present When Modify Subject And Apply Filters", priority = 8, groups = { "SMK-43631", "HomePage", "Mastery-Widget" } )
    public void verifyViewAllLinkPresentWhenModifySubjectAndApplyFilters_06() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );

            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            masteryFiltersComponent.clickApplyFilter();

            if ( tHomePage.verifyMasteryDetails() ) {

                Log.softAssertThat( !tHomePage.isMasteryViewAllLinkPresent(), "View all link present when modify subject and apply filters", "View all link not present when modify subject and apply filters" );
            } else {
                Log.softAssertThat( tHomePage.isMasteryViewAllLinkPresent(), "View all link not present when modify subject and apply filters", "View all link present when modify subject and apply filters" );
            }

            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify View All Link Present When Modify Skills And Apply Filters", priority = 9, groups = { "SMK-43631", "HomePage", "Mastery-Widget" } )
    public void verifyViewAllLinkPresentWhenModifySkillsAndApplyFilters_07() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );

            masteryFiltersComponent.selectSkillStandards( "Arkansas English Language Arts Standards, 2016" );

            masteryFiltersComponent.clickApplyFilter();

            Log.softAssertThat( !tHomePage.isMasteryViewAllLinkPresent(), "View all link present when modify skills/stanard", "View all link not present when modify skills/stanard" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify View All Link Present When Modify Subject And Without Apply Filters", priority = 10, groups = { "SMK-43631", "HomePage", "Mastery-Widget" } )
    public void verifyViewAllLinkPresentWhenModifySubjectAndWithoutApplyFilters_08() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );

            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );

            Log.softAssertThat( !tHomePage.isMasteryViewAllLinkPresent(), "View all link present when modify subject and without apply filters", "View all link not present when modify subject and without apply filters" );
            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Students Radio Button Selected", priority = 11, groups = { "SMK-43631", "HomePage", "Mastery-Widget" } )
    public void verifyStudentsRadioButtonSelected_09() throws Exception {

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            //delete all the groups
            groupsTab.deleteAllGroup( groupsTab );

            //navigate to home page
            tHomePage.topNavBar.navigateToHomeTab();

            //click on mastery view all
            tHomePage.clickMasteryViewALL();

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );

            masteryFiltersComponent.clickFilters();

            //verify by default students radio button is selected automatically when groups are not there
            Log.softAssertThat( masteryFiltersComponent.isStudentsChecked(), "ByDefaul Students Selected", "ByDefault Students not selected" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}