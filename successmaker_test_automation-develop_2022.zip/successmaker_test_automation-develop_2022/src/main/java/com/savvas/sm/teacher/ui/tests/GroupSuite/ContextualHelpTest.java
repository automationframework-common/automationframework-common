package com.savvas.sm.teacher.ui.tests.GroupSuite;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants.GroupUIConstants;
import com.savvas.sm.common.utils.Constants.UserUIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AddStudentToAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.HelpPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class ContextualHelpTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String username = null;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
    }

    @Test ( priority = 1, groups = { "SMK-39022", "Help" } )
    public void tcHelp001( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the Add Student Popup I icon redirects to help page" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            StudentsPage studentsTab = tHomePage.topNavBar.navigateToStudentsTab();

            //Clicking add student
            studentsTab.clikAddStudentInStudentListingPage();
            SMUtils.waitForElement( driver, studentsTab.getIicon() );

            //Clicking i icon and switching the window
            studentsTab.clickiIcon();
            String oldWindow = SMUtils.switchWindow( driver );

            SMUtils.logDescriptionTC( "SMK-10089 : Verify the i icon presence in Add Student Popup" );
            SMUtils.logDescriptionTC( "SMK-10093 : Verify the Add Student Popup I icon redirects to help page" );
            //Getting the title and verifying
            String title = driver.getTitle();
            Log.assertThat( title.equals( UserUIConstants.CREATE_STUDENT_HELP_TITLE ), "Help Page loaded successfully.", "Issue with help Page. - " + driver.getCurrentUrl() );
            driver.switchTo().window( oldWindow );
            studentsTab.closePopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-39022", "Help" } )
    public void tcHelp002( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the Add Student(s) to Assignments Popup I icon redirects to help page." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Page and clicking add student to assignment
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            AddStudentToAssignmentPopup addStudentToAssignmentUsingButton = studentsPage.addStudentToAssignmentButton();

            SMUtils.logDescriptionTC( "SMK-10095 : Verify the i icon presence in Add Student(s) to Assignments Popup." );
            SMUtils.logDescriptionTC( "SMK-10099 : Verify the Add Student(s) to Assignments Popup I icon redirects to help page " );

            SMUtils.waitForElement( driver, addStudentToAssignmentUsingButton.getiIcon() );
            addStudentToAssignmentUsingButton.clickiIcon();
            String oldWindow = SMUtils.switchWindow( driver );
            String title = driver.getTitle();
            Log.message( title );
            Log.assertThat( title.equals( UserUIConstants.ADD_STUDENT_ASSIGNMENT_HELP_TITLE ), "Help Page loaded successfully.", "Issue with help Page. - " + driver.getCurrentUrl() );
            driver.switchTo().window( oldWindow );
            SMUtils.clickJS( driver, addStudentToAssignmentUsingButton.getOkayButton() );
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-39022", "Help" } )
    public void tcHelp003( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10107 : Verify the Create Group Popup I icon redirects to help page" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-10095 : Verify the i icon presence in Create Group Popup I icon" );
            SMUtils.logDescriptionTC( "SMK-10099 : Verify the Create Group Popup I icon I icon redirects to help page " );

            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            SMUtils.waitForElementToBeClickable( groupsTab.getCreateGroupButton(), driver );

            SMUtils.clickJS( driver, groupsTab.getCreateGroupButton() );
            SMUtils.waitForElement( driver, groupsTab.getiIcon() );

            groupsTab.clickiIcon();
            String oldWindow = SMUtils.switchWindow( driver );
            String title = driver.getTitle();
            Log.assertThat( title.equals( GroupUIConstants.CREATE_GROUP_HELP_TITLE ), "Help Page loaded successfully.", "Issue with help Page. - " + driver.getCurrentUrl() );
            driver.switchTo().window( oldWindow );
            SMUtils.clickJS( driver, groupsTab.getCancelButton() );
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-39022", "Help" } )
    public void tcHelp004( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the Add Students to Group(s) I icon redirects to help page" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-10113 : Verify the Add Students to Group(s) I icon redirects to help page" );
            SMUtils.logDescriptionTC( "SMK-10115 : Verify the Add Students to Group(s) icon presence" );

            String groupName = "HelpTestGroup2";
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithoutStudent( groupName );
            groupsTab.viewGroup( groupName );
            groupsTab.clickAddStudentToGroup();
            groupsTab.clickiIcon();
            String oldWindow = SMUtils.switchWindow( driver );
            String title = driver.getTitle();
            Log.assertThat( title.equals( GroupUIConstants.ADD_STUDENT_TO_GROUP_HELP_TITLE ), "Help Page loaded successfully.", "Issue with help Page. - " + driver.getCurrentUrl() );
            driver.switchTo().window( oldWindow );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43269", "Help" } )
    public void tcHelp005( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10033: Verify that clicking on 'i' icon on the Add students to the group popup, user is taken to the help documentation through groups tab" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String groupName = "Reg_Automation" + System.nanoTime();
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithoutStudent( groupName );
            groupsTab.viewGroup( groupName );
            groupsTab.clickAddStudentToGroup();
            Log.assertThat( groupsTab.verifyHelpIcon(), "Help icon is displayed", "Help icon is not displayed" );
            groupsTab.clickiIcon();
            SMUtils.switchWindow( driver );
            HelpPage helpPage = new HelpPage( driver ).get();
            String currentURL = driver.getCurrentUrl();
            Log.assertThat( driver.getCurrentUrl().equals( GroupUIConstants.HELP_URL_FOR_ADD_STU_GRP_POPUP ), "Help Page loaded successfully -" + currentURL, "Issue with help Page. - " + driver.getCurrentUrl() );

            Log.assertThat( driver.getTitle().equals( GroupUIConstants.ADD_STUDENT_TO_GROUP_HELP_TITLE ), "Help Page loaded successfully with title as " + driver.getTitle(), "Issue with help Page. - " + driver.getCurrentUrl() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43269", "Help" } )
    public void tcHelp006( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10034: Verify that clicking on 'i' icon on the Add student to the group popup, user is taken to the help documentation on zero state page Add students to group button" + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Groups tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.deleteAllGroup( groupsTab );
            String groupName = "Reg_Automation" + System.nanoTime();
            groupsTab.createGroupWithoutStudent( groupName );
            groupsTab.viewGroup( groupName );
            groupsTab.clickAddStudentToGroup();
            Log.assertThat( groupsTab.verifyHelpIcon(), "Help icon is displayed", "Help icon is not displayed" );
            groupsTab.clickiIcon();
            SMUtils.switchWindow( driver );
            HelpPage helpPage = new HelpPage( driver ).get();
            String currentURL = driver.getCurrentUrl();
            Log.assertThat( driver.getCurrentUrl().equals( GroupUIConstants.HELP_URL_FOR_ADD_STU_GRP_POPUP ), "Help Page loaded successfully -" + currentURL, "Issue with help Page. - " + driver.getCurrentUrl() );

            Log.assertThat( driver.getTitle().equals( GroupUIConstants.ADD_STUDENT_TO_GROUP_HELP_TITLE ), "Help Page loaded successfully with title as " + driver.getTitle(), "Issue with help Page. - " + driver.getCurrentUrl() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43269", "Help" } )
    public void tcHelp007( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10035: Verify that clicking on 'i' icon on the Add student to the group popup, user is taken to the help documentation on zero state page Add students to group link" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Groups tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.deleteAllGroup( groupsTab );
            String groupName = "Reg_Automation" + System.nanoTime();
            groupsTab.createGroupWithoutStudent( groupName );
            groupsTab.viewGroup( groupName );
            groupsTab.clickAddStuToGrpLink();
            Log.assertThat( groupsTab.verifyHelpIcon(), "Help icon is displayed", "Help icon is not displayed" );
            groupsTab.clickiIcon();
            SMUtils.switchWindow( driver );
            HelpPage helpPage = new HelpPage( driver ).get();
            String currentURL = driver.getCurrentUrl();
            Log.assertThat( driver.getCurrentUrl().equals( GroupUIConstants.HELP_URL_FOR_ADD_STU_GRP_POPUP ), "Help Page loaded successfully -" + currentURL, "Issue with help Page. - " + driver.getCurrentUrl() );

            Log.assertThat( driver.getTitle().equals( GroupUIConstants.ADD_STUDENT_TO_GROUP_HELP_TITLE ), "Help Page loaded successfully with title as " + driver.getTitle(), "Issue with help Page. - " + driver.getCurrentUrl() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
