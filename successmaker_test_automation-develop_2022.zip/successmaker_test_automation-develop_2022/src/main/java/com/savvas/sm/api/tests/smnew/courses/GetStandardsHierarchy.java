package com.savvas.sm.api.tests.smnew.courses;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicReference;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class GetStandardsHierarchy extends CourseAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String flexSchoolTeacherDetails = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String token = null;
    HashMap<String, String> mathGradeStandardDetails = new HashMap<String, String>();
    HashMap<String, String> readingGradeStandardDetails = new HashMap<String, String>();
    public String isItMt = "";

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        isItMt = configProperty.getProperty( "isMTExecution" );

        //To get Random Standard ID's for Math and Reading Courses
        mathGradeStandardDetails = SqlHelperCourses.getGradeStandardID( Constants.MATH, isItMt.equalsIgnoreCase( "true" ) );
        readingGradeStandardDetails = SqlHelperCourses.getGradeStandardID( Constants.READING, isItMt.equalsIgnoreCase( "true" ) );
    }

    @Test ( priority = 1, dataProvider = "positiveScenarioForGetStandardHierarchy", groups = { "SMK-53109", "Course", "GetSkillsHierarchy", "P1", "API", "smoke_test_case" } )
    public void getStandardsHierarchyPositiveScenarios( String description, String statusCode, String courseId, String bankId, String level, String includeLOS ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> skillsHierarchyDetails = new HashMap<>();

        //Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        //Get Standards Hierarchy
        skillsHierarchyDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        skillsHierarchyDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        skillsHierarchyDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        skillsHierarchyDetails.put( CourseAPIConstants.COURSE_ID, courseId );
        skillsHierarchyDetails.put( CourseAPIConstants.BANK_ID, bankId );
        skillsHierarchyDetails.put( CourseAPIConstants.LEVEL, level );
        skillsHierarchyDetails.put( CourseAPIConstants.INCLUDE_LOS, includeLOS );

        apiResponse = getStandardHierarchy( smUrl, skillsHierarchyDetails );
        Log.message( "response from GetCall - " + apiResponse );

        //Assertion
        Log.softAssertThat( verifySuccessStatus( apiResponse.get( "body" ), CommonAPIConstants.STATUS ), "Status is getting as expected", "Status is not getting as expected" );
        Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    @Test ( priority = 1, dataProvider = "getStandardHierarchyForCustomCourses", groups = { "SMK-53109", "GetSkillsHierarchy for Custom Courses", "Course", "P1", "API", "smoke_test_case" } )
    public void createCourseAndGetStandardsHierarchyPositiveScenarios( String description, String scenario, String statusCode, String gradeId, String courseId, String standardFrmeworkId, String parentNode, String ChildNode, String level,
            String includeLOS ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> courseDetails = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();

        // Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( flexSchool ) );
        headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        courseDetails.put( Constants.GRADE_VALUE, gradeId );
        courseDetails.put( Constants.STANDARD_FRAMEWORK_VALUE, standardFrmeworkId );
        courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
        courseDetails.put( CourseAPIConstants.PARENT_NODE, parentNode );
        courseDetails.put( CourseAPIConstants.CHILD_NODE, ChildNode );
        courseDetails.put( Constants.COURSE_NAME, "Skills" + System.nanoTime() );
        apiResponse = createCourseBySkill( smUrl, headers, courseDetails, scenario );
        Log.message( "response from POST Call - " + apiResponse );

        String customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );

        HashMap<String, String> apiResponseGetHierarchy = new HashMap<>();
        HashMap<String, String> skillsHierarchyDetails = new HashMap<>();

        //Get Standards Hierarchy
        skillsHierarchyDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        skillsHierarchyDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        skillsHierarchyDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        skillsHierarchyDetails.put( CourseAPIConstants.COURSE_ID, customCourseId );
        skillsHierarchyDetails.put( CourseAPIConstants.BANK_ID, gradeId );
        skillsHierarchyDetails.put( CourseAPIConstants.LEVEL, level );
        skillsHierarchyDetails.put( CourseAPIConstants.INCLUDE_LOS, includeLOS );
        apiResponseGetHierarchy = getStandardHierarchy( smUrl, skillsHierarchyDetails );

        //Assertion
        Log.softAssertThat( verifySuccessStatus( apiResponse.get( "body" ), CommonAPIConstants.STATUS ), "Status is getting as expected", "Status is not getting as expected" );
        Log.softAssertThat( apiResponseGetHierarchy.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponseGetHierarchy.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponseGetHierarchy.get( Constants.STATUS_CODE ) );

    }

    @Test ( priority = 1, dataProvider = "negativeScenarioForGetStandardHierarchy", groups = { "SMK-53109", "Course", "GetSkillsHierarchy", "P2", "API" } )
    public void getStandardsHierarchyNegativeScenarios( String description, String scenario, String statusCode, String courseId, String bankId, String level, String includeLOS, String exception ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> skillsHierarchyDetails = new HashMap<>();

        switch ( scenario ) {
            case "Valid Autherization":

                //Authorization
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get Standards Hierarchy
                skillsHierarchyDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                skillsHierarchyDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                skillsHierarchyDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                skillsHierarchyDetails.put( CourseAPIConstants.COURSE_ID, courseId );
                skillsHierarchyDetails.put( CourseAPIConstants.BANK_ID, bankId );
                skillsHierarchyDetails.put( CourseAPIConstants.LEVEL, level );
                skillsHierarchyDetails.put( CourseAPIConstants.INCLUDE_LOS, includeLOS );
                apiResponse = getStandardHierarchy( smUrl, skillsHierarchyDetails );

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                break;

            case "invalid autherization":

                //Authorization
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get Standards Hierarchy
                skillsHierarchyDetails.put( RBSDataSetupConstants.BEARER_TOKEN, "1234fffff2f2fff" );
                skillsHierarchyDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                skillsHierarchyDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                skillsHierarchyDetails.put( CourseAPIConstants.COURSE_ID, courseId );
                skillsHierarchyDetails.put( CourseAPIConstants.BANK_ID, bankId );
                skillsHierarchyDetails.put( CourseAPIConstants.LEVEL, level );
                skillsHierarchyDetails.put( CourseAPIConstants.INCLUDE_LOS, includeLOS );

                apiResponse = getStandardHierarchy( smUrl, skillsHierarchyDetails );

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                break;

        }
        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "positiveScenarioForGetStandardHierarchy" )
    public Object[][] getStandardHierarchyPositiveScenario() {
        Object[][] inputData = { { "TC009_Verify the status code is 200 when  value 0 for level is given", "200", "1", mathGradeStandardDetails.get( "bankID" ), "0", "true", },
                { "Verify the status code is 200 when valid test data for Default reading is given.", "200", "2", readingGradeStandardDetails.get( "bankID" ), "0", "true" },
                { "TC0010_Verify the status code is 200 when  value 1 for level is given", "200", "1", mathGradeStandardDetails.get( "bankID" ), "1", "true" },
                { "TC012_Verify the status code is 200 when  value 2 for level is given", "200", "2", readingGradeStandardDetails.get( "bankID" ), "2", "true" },
                { "TC011_Verify the status code is 200 when  value -1 for level is given", "200", "2", readingGradeStandardDetails.get( "bankID" ), "-1", "true" },
                { "TC013_Verify the status code is 200 when invalid Integer value for level is given.", "200", "1", mathGradeStandardDetails.get( "bankID" ), "1000", "true" } };
        return inputData;
    }

    /**
     * Data provider for Custom Course positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "getStandardHierarchyForCustomCourses" )
    public Object[][] createCourseAndGetHierarchy() {
        Object[][] inputData = {
                { "TC003_Verify the status code is 200 when valid test data for Math(custom by Skill) is given.", "MATH", "200", mathGradeStandardDetails.get( "GradeID" ), "1", mathGradeStandardDetails.get( "StandardID" ),
                        mathGradeStandardDetails.get( "bankID" ), mathGradeStandardDetails.get( "scoID" ), "0", "true" },
                { "TC004_Verify the status code is 200 when valid test data for Reading(custom by Skill) is given.", "READING", "200", readingGradeStandardDetails.get( "GradeID" ), "2", readingGradeStandardDetails.get( "StandardID" ),
                        readingGradeStandardDetails.get( "bankID" ), readingGradeStandardDetails.get( "scoID" ), "0", "true" } };
        return inputData;
    }

    /**
     * Data provider for negative scenarios
     * 
     * @return
     */

    @DataProvider ( name = "negativeScenarioForGetStandardHierarchy" )
    public Object[][] getStandardHierarchyNegativeScenario() {
        Object[][] inputData = {
                { "TC005_Verify the status code is 400 when invalid Content base Id is given.", "Valid Autherization", "400", "abc@$", "1000001071", "0", "true", "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
                { "TC006_Verify the status code is 200 when non existing Content base Id is given.", "Valid Autherization", "200", "1000", "1000001071", "0", "true", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC007_Verify the status code is 200 when invalid(abc) Cttype Id is given.", "Valid Autherization", "200", "1", "abc", "0", "true", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC008_Verify the status code is 200 when non existing Cttype Id is given.", "Valid Autherization", "200", "1", "3281", "0", "true", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC014_Verify the status code is 400 when invalid String value for level is given.", "Valid Autherization", "400", "1", "1000001071", "sss", "true", "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
                { "TC015_Verify the status code is 400 when numeric value for include lo's are given.", "Valid Autherization", "400", "1", "1000001071", "0", "12321", "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
                { "TC016_Verify the status code is 400 when some text for include lo's are given.", "Valid Autherization", "400", "1", "1000001071", "0", "sssdd", "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
                { "TC017_Verify the status code is 401 when invalid authorization is given", "invalid autherization", "401", "1", "1000001071", "0", "true", "java.lang.Exception" },
                { "TC018_Verify the status code is 400 when the invalid(Null) Content base Id is given.", "Valid Autherization", "400", "null", "1000001071", "0", "true", "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" } };
        return inputData;
    }

    //Token creation
    public void tokenCreation( String school ) {
        try {

            teacherDetails = flexSchoolTeacherDetails;

            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        } catch ( Exception e ) {
            Log.message( "Issue occured in tokenCreation" );
        }
    }

    /**
     * Verifying the Exception information
     * 
     * @param actualResponse
     * @param exception
     * @return boolean
     * @throws IOException
     */
    public boolean verifyExceptionMessage( String actualResponse, String exception ) throws IOException {

        boolean flag = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.message( "Exception Verified successfully!" );
            flag = true;
        } else {
            Log.message( "Issue in displaying exception!" );
        }
        return flag;
    }

    /**
     * Verifying the success message
     * 
     * @param actualResponse
     * @param message
     * @return boolean
     * @throws IOException
     */
    public boolean verifySuccessStatus( String actualResponse, String status ) throws IOException {

        boolean flag = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( status ) ) {
            Log.message( "status Verified successfully!" );
            flag = true;
        } else {
            Log.message( "Issue in displaying status!" );
        }
        return flag;
    }

    /**
     * Get response for the Create Course By Skill API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySkill( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "READING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardReading" ) ) );

            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardMath" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.STANDARDFRAMEWORK_ID, courseDetails.get( Constants.STANDARD_FRAMEWORK_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

}