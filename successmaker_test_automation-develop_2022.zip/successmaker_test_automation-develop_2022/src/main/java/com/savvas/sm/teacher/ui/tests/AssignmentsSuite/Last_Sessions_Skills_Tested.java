package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

@Listeners ( EmailReport.class )
public class Last_Sessions_Skills_Tested extends BaseTest {

    private String smUrl;
    private String browser;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String StaticCourseNamea;
    private String StaticCourseNameb;
    private String schoolID;
    private String teacherID;

    private String chromePlatform = "Windows_10_Chrome_latest"; // for Simulator Execution

    private String studentDetailsOne;
    private String studentDetailsTwo;

    private static String studentOne;
    private static String studentTwo;

    private HashMap<String, String> groupDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();

    String studentDeatailsReading;
    String studentDetailsMath;
    String teacherDetails;
    String readingUsername;
    String mathUsername;
    String studentFirstName;
    String studentMiddleName;
    String studentLastName;

    String studentFirstNameread;
    String studentMiddleNameread;
    String studentLastNameread;

    String studentFirstNamemath;
    String studentMiddleNamemath;
    String studentLastNamemath;

    private String token = null;

    @BeforeClass (alwaysRun = true)
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        String teacherDetails = RBSDataSetup.getMyTeacher( school );

        schoolID = RBSDataSetup.organizationIDs.get( school );

        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );

        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        // Flex
        studentDetailsOne = RBSDataSetup.getMyStudent( school, username );
        studentOne = SMUtils.getKeyValueFromResponse( studentDetailsOne, "userName" );
        studentDetailsTwo = RBSDataSetup.getMyStudent( school, username );
        studentTwo = SMUtils.getKeyValueFromResponse( studentDetailsTwo, "userName" );

        studentFirstName = SMUtils.getKeyValueFromResponse( studentDetailsOne, "firstName" );
        studentMiddleName = SMUtils.getKeyValueFromResponse( studentDetailsOne, "middleName" );
        studentLastName = SMUtils.getKeyValueFromResponse( studentDetailsOne, "lastName" );

        // Flex
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsOne, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsTwo, "userId" ) );

        // token creation
        // Flex
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        // Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

        StaticCourseNamea = DataSetupConstants.SKILL_COURSE_NAME_MATH + System.nanoTime();

        String CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherID, schoolID, DataSetupConstants.SKILL, StaticCourseNamea );
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> response = new HashMap<>();
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, schoolID );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
        response = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
        StaticCourseNameb = DataSetupConstants.SKILL_COURSE_NAME_MATH + System.nanoTime();
        String CourseIda = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherID, schoolID, DataSetupConstants.SKILL, StaticCourseNameb );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseIda );
        response = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
        
    }

    @Test ( description = "Verify the Last Session skill tested for the Assignment Listing", priority = 1, groups = { "SMK-45103", "AssignmentDetails Page", "Last Session Skill Tested" } )
    public void tcSMLastSessionSkillTested_001( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
    	
        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );
            // Go to the assignment detail Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( StaticCourseNamea );

            SMUtils.logDescriptionTC( "SMK-12287 :Verifying zero state in Last Session Skill Tested" );
            assignmentDetailsPage.clicktoggleButtonForStudent( studentFirstName, studentMiddleName, studentLastName );
            boolean isZeroState = assignmentDetailsPage.isZeroStatePresentforSkillTested();
            Log.assertThat( isZeroState, "Skill Tested has Zero State!", "Skill Tested component is not in Zero State" );
            assignmentDetailsPage.collapseSkillTested();
            // SignOut
            tHomePage.topNavBar.signOutfromSM();
            // if ( isAssigned ) {

            // Get driver
            EventFiringWebDriver studentDriver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
          
            try {
                LoginWrapper.loginToSuccessMakerAsStudent( studentDriver, smUrl, UserType.BASIC, null, studentOne, password );
                SMUtils.nap( 30 );
                SMUtils.waitForSpinnertoDisapper( studentDriver );
                StudentDashboardPage studentsPage = new StudentDashboardPage( studentDriver );

                studentsPage.executeMathCourse( username, StaticCourseNamea, "100", "1", "1" );
                studentsPage.logout();
            } catch ( Exception e ) {
                Log.exception( e, studentDriver );
            } finally {
                studentDriver.quit();
                Log.endTestCase();
            }

       //      Get driver
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
           
            
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            tHomePage = new TeacherHomePage( driver );
            courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courseware tab
            SMUtils.nap( 10 );
            tHomePage.topNavBar.navigateToAssignmentsPage();

            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickOnTheHoveredAssignment( StaticCourseNamea );
            SMUtils.nap( 10 );
            assignmentDetailsPage.clicktoggleButtonForStudent( studentFirstName, studentMiddleName, studentLastName );
            SMUtils.logDescriptionTC( "SMK-12287 : Verify Skill Tested for the Assignment , the student attempted after created" );
            SMUtils.logDescriptionTC( "SMK-12306 : Verify the Skill name displayed on top of Graph bars." );

            
            HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<>();
            skillsTestedList = assignmentDetailsPage.getSkillsTestedValues();
            List<String> skillNames = new ArrayList<>();
            skillNames = assignmentDetailsPage.getSkillsListFromMap( skillsTestedList );
            Log.assertThat( skillNames.size() > 0, "The skill is present for the Student!", "The skill Tested is not present for the student" );

            SMUtils.logDescriptionTC( "SMK-12285 :Verify the last session date is availabe for the 14 dates for skill Tested" );
            assignmentDetailsPage.clickLastSession();
            Log.assertThat( assignmentDetailsPage.getLastSessionDropdownValues().equals( assignmentDetailsPage.getExpectedDatesinLastSession() ), "The dropdown values are mathcing",
                    "The dropdown values are not matching Expected!" + assignmentDetailsPage.getExpectedDatesinLastSession().toString() + "Actual" + assignmentDetailsPage.getLastSessionDropdownValues().toString() );
            assignmentDetailsPage.collapseSkillTested();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Skill Tested for the Assignment is paused and resumed and deleted", priority = 1, groups = { "SMK-45103", "AssignmentDetails Page", "Last Session Skill Tested" } )
    public void tcSMLastSessionSkillTested_002( ITestContext context ) throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );

        EventFiringWebDriver studentDriver = new EventFiringWebDriver( WebDriverFactory.get( chromePlatform ) );
        EventListener eventListner = new EventListener();
        studentDriver.register( eventListner );

        try {
            LoginWrapper.loginToSuccessMakerAsStudent( studentDriver, smUrl, UserType.BASIC, null, studentOne, password );
            SMUtils.nap( 30 );
            SMUtils.waitForSpinnertoDisapper( studentDriver );
            StudentDashboardPage studentsPage = new StudentDashboardPage( studentDriver );

            studentsPage.executeMathCourse( username, StaticCourseNameb, "100", "1", "5" );
            studentsPage.logout();
        } catch ( Exception e ) {
            Log.exception( e, studentDriver );
        } finally {
            studentDriver.quit();
            Log.endTestCase();
        }

        try {

            // Get driver
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courseware tab
            SMUtils.nap( 10 );
            // Go to the assignment detail Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( StaticCourseNameb );
            SMUtils.logDescriptionTC( "SMK-12289 : Verify Skill Tested for the if Assignment paused" );
            assignmentDetailsPage.pauseAllStudent();
            assignmentDetailsPage.pauseButtonFoAllSTudent();

            assignmentDetailsPage.clicktoggleButtonForStudent( studentFirstName, studentMiddleName, studentLastName );
            HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<>();
            skillsTestedList = assignmentDetailsPage.getSkillsTestedValues();
            List<String> skillNames = new ArrayList<>();
            skillNames = assignmentDetailsPage.getSkillsListFromMap( skillsTestedList );
            Log.assertThat( skillsTestedList.size() > 0, "Skill Tested is present for the Assignment Paused as Expected!", "Skill Tested is Not listed for the Assignment Paused" );
            assignmentDetailsPage.collapseSkillTested();
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "SMK-12290 : Verify Skill Tested for the if Assignment resumed" );
            assignmentDetailsPage.resumeAllAssignment();
            assignmentDetailsPage.resumeButtonFoAllSTudent();
            assignmentDetailsPage.clicktoggleButtonForStudent( studentFirstName, studentMiddleName, studentLastName );

            skillsTestedList = assignmentDetailsPage.getSkillsTestedValues();
            Log.assertThat( skillsTestedList.size() > 0, "Skill Tested is present for the Assignment Resumed as Expected!", "Skill Tested is Not listed for the Assignment Resumed" );
            assignmentDetailsPage.collapseSkillTested();
            Log.testCaseResult();

            List<String> dropdownValues = assignmentDetailsPage.getExpectedDatesinLastSession();

            SMUtils.logDescriptionTC( "SMK-12296 : Verify the skill tested for the last session filter only selected " );
            assignmentDetailsPage.clicktoggleButtonForStudent( studentFirstName, studentMiddleName, studentLastName );
            assignmentDetailsPage.clickLastSession();
            assignmentDetailsPage.clickCheckBoxinLastSessionDropdown( dropdownValues.subList( 0, 1 ) );
            assignmentDetailsPage.clickCheckBoxinLastSessionDropdown( dropdownValues.subList( 0, 1 ) );
            assignmentDetailsPage.clickApplyFilter();
            skillsTestedList = assignmentDetailsPage.getSkillsTestedValues();
            Log.assertThat( skillsTestedList.size() > 0, "Skill Tested is present when Last Session alone selected", "Skill Tested is Not present when Last Session alone selected!" );
            assignmentDetailsPage.collapseSkillTested();

            Log.testCaseResult();
            SMUtils.logDescriptionTC( "SMK-12298 : Verify the skill tested for other than last session date is filtered" );
            SMUtils.nap( 10 );
            assignmentDetailsPage.clicktoggleButtonForStudent( studentFirstName, studentMiddleName, studentLastName );
            assignmentDetailsPage.clickLastSession();
            assignmentDetailsPage.clickCheckBoxinLastSessionDropdown( dropdownValues.subList( 0, 1 ) );
            assignmentDetailsPage.clickCheckBoxinLastSessionDropdown( dropdownValues.subList( 7, 14 ) );
            assignmentDetailsPage.clickApplyFilter();
//            /**
//             * since running on simulator has values only on last session
//             * verifying zero state here
//             **/
////            boolean isZeroState = assignmentDetailsPage.isZeroStatePresentforSkillTested();
////            Log.assertThat( isZeroState, "Zero State is present!", "Zero state is not present" );
////            assignmentDetailsPage.collapseSkillTested();
////
////            Log.testCaseResult();
            SMUtils.logDescriptionTC( "SMK-12297 : Verify the skill tested for the last session and along with other date is filtered " );
            assignmentDetailsPage.clicktoggleButtonForStudent( studentFirstName, studentMiddleName, studentLastName );
            assignmentDetailsPage.clickLastSession();
            assignmentDetailsPage.clickCheckBoxinLastSessionDropdown( dropdownValues.subList( 1, 4 ) );
            assignmentDetailsPage.clickApplyFilter();
            skillsTestedList = assignmentDetailsPage.getSkillsTestedValues();
            Log.assertThat( skillsTestedList.size() > 0, "Skill Tested is present when other dates along with  Last Session date is selected!", "Skill Tested is Not present when other dates along with  Last Session date is  selected!" );
            assignmentDetailsPage.collapseSkillTested();

            Log.testCaseResult();
            SMUtils.logDescriptionTC( "SMK-12291 : Verify Skill Tested for the if Assignment deleted" );
            assignmentDetailsPage.deleteAssignmenttab();
            assignmentDetailsPage.deleteAssignmentButton();
            boolean flag = assignmentsPage.isAssignmentPresent( StaticCourseNameb );
            Log.assertThat( !flag, "The Assignments is not present as Expected!", "The Assignment is present for deleted assignment" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public void VerifySkillTested( HashMap<String, String> Skillvalue, String correct, String total, String percent ) {
        Log.assertThat( Skillvalue.get( AssignmentDetailsPage.SKILL_CORRECT ).equals( correct + " / " + total + " correct" ), "The Skill Correct values is matching!",
                "The Skill Correct values is not matching " + "Actual[" + Skillvalue.get( AssignmentDetailsPage.SKILL_CORRECT ) + "] Expected [" + correct + " / " + total + " correct" + "]" );
        Log.assertThat( Skillvalue.get( AssignmentDetailsPage.SKILL_PERCENT_VALUE ).equals( percent ), "The Bar value is matching!",
                "Bar Width is not matching " + "Actual[" + Skillvalue.get( AssignmentDetailsPage.SKILL_PERCENT_VALUE ) + "] Expected[" + correct + "]" );
        Log.assertThat( Skillvalue.get( AssignmentDetailsPage.BAR_WIDTH ).equals( "width: " + percent + ";" ), "The Bar Width value is matching!",
                "The Bar Width value is not matching " + "Actual[" + Skillvalue.get( AssignmentDetailsPage.BAR_WIDTH ) + "] Expected[" + "width: " + percent + ";]" );

    }
    /**
     * To execute the course
     *
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, String percentage, String numberOfSession, String loCount ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }
}