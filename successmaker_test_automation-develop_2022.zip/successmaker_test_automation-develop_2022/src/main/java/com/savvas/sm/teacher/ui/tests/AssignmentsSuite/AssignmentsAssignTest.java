package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.UserUIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AddStudentToAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class AssignmentsAssignTest extends BaseTest {

	private String smUrl;
	private String browser;
	private static String username = null;
	private static String password = DataSetupConstants.DEFAULT_PASSWORD;
	private String sessionCookie;
	private String flexSchoolTeacherDetails = null;
	private String token = null;
	private static String teacherDetails;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String teacherID;
	private String schoolID;
	String studentDetails;
	String studentDetailsSecond;
	String studentDetailsThree;
	String studentSMDetails;
	String studentSMDetailsSecond;
	String studentSMDetailsThree;
	private HashMap<String, String> groupDetails = new HashMap<>();
	private static List<String> studentRumbaIds = new ArrayList<>();
	private String organizationId = null;
	private String staticCourseName = null;

	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		String teacherDetails = RBSDataSetup.getMyTeacher(school);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		// token creation
		token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(teacherDetails, "userName"),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		
	}

	@Test(description = "Verify the teacher is able to obtain the assign widget on clicking the assign button of the assignment", groups = {"SMK-39226", "assignments", "assignmentDetailsPage" }, priority = 1)
	public void tc_AssignmentsPage_001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_AssignmentsPage_001:SMK-9392 and SMK-9389- Verify the teacher is able to assign for the reading course."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			// Get Assignments Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup(driver);
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentdetailspage = new AssignmentDetailsPage(driver);
			courseListingPage.selectCourseTypeFromDropDown("Default Courses");
			CoursesPage coursepage = new CoursesPage(driver);

			// Assigned Cousres to Students
			coursepage.clickCourseName(Constants.READING);
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();
			SMUtils.nap(3);// waiting to disappear toast message
			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(Constants.READING);

			SMUtils.logDescriptionTC("SMK-9388 : Verify for each assignment assign button with blue is present"+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			// Verify the color is blue button
			assignmentdetailspage.verifyassignButtonColor();

			SMUtils.logDescriptionTC("SMK-9422 :  Verify whether the assign widget is obtained from the courses page"+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignmentdetailspage.clickAssignButton();

			SMUtils.logDescriptionTC("SMK-9390 : Verify the certain items are present on the assign widget"
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignmentdetailspage.getAssignWidget(browser);
			Log.assertThat(assignAssignmentPopup.isCancelButtonOnPopupEnable(),"Assign Pop up Window is displayed successfully", "Assign Pop up Window is not displayed");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the teacher is able to assign for the Math course", groups = { "SMK-39226",
			"assignments", "assignmentDetailsPage" }, priority = 2)
	public void tc_AssignmentsPage_002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_AssignmentsPage_002:SMK-9393 - Verify the teacher is able to assign for the math course."
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			// Get Assignments Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup(driver);
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentdetailspage = new AssignmentDetailsPage(driver);
			courseListingPage.selectCourseTypeFromDropDown("Default Courses");
			CoursesPage coursepage = new CoursesPage(driver);

			// Assigned Cousres to Students
			coursepage.clickCourseName(Constants.MATH);
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();
			SMUtils.nap(3);// waiting to disappear toast message
			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);
			assignmentdetailspage.clickAssignButton();
			coursepage.clickContinueToAssignButtonMSDA();
			// verify assignment settings
			SMUtils.logDescriptionTC("SMK-9391 : As per the teacher preferance teacher should be able to edit the settings"
							+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignmentdetailspage.selectValueFromDropDownSessionLength(Constants.SESSION_LENGHT_SELECTED);

			assignmentdetailspage.selectValueFromDropDownIdleTime(Constants.IDEAL_TIME_SELECTED);

			Log.assertThat(assignAssignmentPopup.isCancelButtonOnPopupEnable(),
					"Assign Pop up Window is displayed successfully", "Assign Pop up Window is not displayed");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the groups is selected for the assign widget by default", groups = { "SMK-39226","assignments", "assignmentDetailsPage" }, priority = 3)
	public void tc_AssignmentsPage_003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentsPage_003:SMK-9394- Verify the groups is selected for the assign widget by default."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			// Get Assignments Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup(driver);
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentdetailspage = new AssignmentDetailsPage(driver);
			courseListingPage.selectCourseTypeFromDropDown("Default Courses");
			CoursesPage coursepage = new CoursesPage(driver);

			// Assigned Cousres to Students
			coursepage.clickCourseName(Constants.MATH);
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();
			SMUtils.nap(3);// waiting to disappear toast message
			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);
						

			assignmentdetailspage.clickAssignButton();
			// Click MSDA
			coursepage.clickContinueToAssignButtonMSDA();
			// Verify the Group is default selection
			boolean groupDefaultchecked = assignAssignmentPopup.isGroupSelected();
			Log.assertThat(groupDefaultchecked, "Groups is the default selection",
					"Groups is not the default selection");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify teacher can refine the list further by entering search criteria", groups = {
			"SMK-39226", "assignments", "assignmentDetailsPage" }, priority = 4)
	public void tc_AssignmentsPage_004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
		Log.testCaseInfo("tc_AssignmentsPage_004:SMK-9395- Verify teacher can refine the list further by entering search criteria."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			// Get Assignments Page
			AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup(driver);
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentdetailspage = new AssignmentDetailsPage(driver);
			CoursesPage coursepage = new CoursesPage(driver);

			// Clicked the view assignment
			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);
			assignmentdetailspage.clickAssignButton();
			// Click MSDA
			coursepage.clickContinueToAssignButtonMSDA();
			Log.assertThat(assignAssignmentPopup.isCancelButtonOnPopupEnable(),"Assign Pop up Window is displayed successfully", "Assign Pop up Window is not displayed");
			// Entered the value in the search text box of Group
			assignAssignmentPopup.enterSearchTextboxAssignment("student");
			// Verify assign button color
			assignmentdetailspage.verifyassignButtonColor();

			// Verify the value is present in the search text box
			String textValue = assignAssignmentPopup.getTextValue();
			if (textValue.matches("student")) {
				Log.message("Value is present in the Group Textbox");
			} else {
				Log.message("Value is not present in the Group Textbox");
			}

			assignAssignmentPopup.checkStudents();

			// Entered the value in the search text box of Student
			assignAssignmentPopup.enterSearchTextboxAssignment("student text");
			Log.message("Entered value in the Student Textbox");
			String textValuestudent = assignAssignmentPopup.getTextValue();
			// Verify the value is present in the students search text
			if (textValuestudent.matches("student text")) {
				Log.message("Value is present in the Student Textbox");

			} else {
				Log.message("Value is not present in the Student Textbox");
			}

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the teacher should be able to add the group,remove the group ,add student and remove student", groups = {
			"SMK-39226", "assignments", "assignmentDetailsPage" }, priority = 5)
	public void tc_AssignmentsPage_005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_AssignmentsPage_005:SMK-9396 and SMK-9400- Verify teacher can refine the list further by entering search criteria."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			courseListingPage.selectCourseTypeFromDropDown("Default Courses");
			CoursesPage coursepage = new CoursesPage(driver);
			
			// Assigned Cousres to Students
						coursepage.clickCourseName(Constants.MATH);
						coursepage.clickAssignBtn();
						coursepage.addCourseToStudents();
						SMUtils.nap(3);// waiting to disappear toast message
//			
			AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup(driver);
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentdetailspage = new AssignmentDetailsPage(driver);

			assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			
			
			// Clicking on View Assignment
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.MATH);

			// Closing the Ellipsis icon at the student level
			assignmentDetailsPage.clickDotEllipsisButton();

			// Clicking on the Assignment_Settings option in the Ellipsis
			assignmentDetailsPage.assignmentSettingInEllipsis();

			SMUtils.logDescriptionTC("SMK-7241 - Delete Assignment settings in the view assignmnet details page.");
			// Delete Assignment
			assignmentDetailsPage.deleteAssignmenttab();
			assignmentDetailsPage.deleteAssignmentButton();
			Log.assertThat(assignmentDetailsPage.AssignmentDeleted(),"Assignment has deleted successfully","Assignment has not deleted successfully");
			// Get Student Page
			SMUtils.nap(5);
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
			SMUtils.nap(5);
			Map<String, List<String>> studentDetailsFromStudentTab = studentsPage.getColumnDetailsAsList();
			List<String> studenListFromStudentTab = new ArrayList<>();
			for (int studentValue = 0; studentValue < studentDetailsFromStudentTab.get(Constants.FIRSTNAME)
					.size(); studentValue++) {
				String studentFN = studentDetailsFromStudentTab.get(Constants.FIRSTNAME).get(studentValue);
				String studentLN = studentDetailsFromStudentTab.get(Constants.LASTNAME).get(studentValue);
				studenListFromStudentTab.add(coursepage.completeStudentName(studentFN, "", studentLN));
			}
			String[] FNLN = studenListFromStudentTab.get(0).split(" ");
			String studentFNLN = FNLN[0].concat(FNLN[1]);

		//	CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			courseListingPage.selectCourseTypeFromDropDown("Default Courses");

			// Assigned Cousres to Students
			coursepage.clickCourseName(Constants.MATH);
			coursepage.clickAssignBtn();

			coursepage.addCourseToOneStudent(studentFNLN);
			// Clicked the view assignment
			assignmentsPage.clickAssignmentSubMenu();
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);
			assignmentdetailspage.clickAssignButton();
			// Click MSDA
			coursepage.clickContinueToAssignButtonMSDA();
			// Clicked add button to the groups
			assignAssignmentPopup.clickAddButtonAll();

			// Verify all groups are added in the textbox
			assignAssignmentPopup.verifyallGroupsAdded();
			SMUtils.logDescriptionTC("SMK-9397- Verify the teacher should be able to remove the group by clicking the X button"
							+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			// Clicked remove icon to the groups
			assignAssignmentPopup.clickMultipleRemoveIcon();

			// Verify all the groups removed in the textbox
			assignAssignmentPopup.verifyallGroupsremoved();
			SMUtils.logDescriptionTC("SMK-9398 and SMK-9402, SMK- 9410- Verify the teacher should be able to remove the group by clicking the remove button"
							+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

			// Clicked All Remove button
			assignAssignmentPopup.clickAddButtonAll();
			assignAssignmentPopup.clickRemoveButtonAll();

			// Verify all the groups removed in the textbox
			assignAssignmentPopup.verifyallGroupsremoved();

			SMUtils.logDescriptionTC("SMK-9399 : Verify the teacher should be able to select muliple groups"
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			// Clicked one button
			assignAssignmentPopup.clickFewAddButton();

			// Verify all groups are added in the textbox
			assignAssignmentPopup.verifyallGroupsAdded();

			SMUtils.logDescriptionTC("SMK-9401 : verify the teacher should be able to select muliple groups ."
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

			assignAssignmentPopup.clickFewRemoveButton();

			// Verify all groups are removed in the textbox
			assignAssignmentPopup.verifyallGroupsremoved();

			SMUtils.logDescriptionTC("SMK-9403 : Verify the teacher is able to select the students ."
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignAssignmentPopup.checkStudents();
			Log.message("Clicked Students radio button ");

			SMUtils.logDescriptionTC("SMK-9404 and SMK-9408: Verify the teacher should be able to add the students."
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignAssignmentPopup.clickAddButtonAll();

			// Verify all students are added in the text box
			assignAssignmentPopup.verifyallStudentsAdded();

			SMUtils.logDescriptionTC(	"SMK-9405 : Verify the teacher should be able to remove the student by clicking the X button"
							+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignAssignmentPopup.clickMultipleRemoveIcon();

			// Verify all student are removed in the textbox
			assignAssignmentPopup.verifyAllstudentsremoved();
			SMUtils.logDescriptionTC("SMK-9406 : Verify the teacher should be able to remove the student by clicking the button"
							+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignAssignmentPopup.clickAddButtonAll();
			assignAssignmentPopup.clickRemoveButtonAll();

			// Verify all student are removed in the textbox
			assignAssignmentPopup.verifyAllstudentsremoved();
			SMUtils.logDescriptionTC("SMK-9407 and SMK-9411: verify the teacher should be able to select muliple students"
							+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignAssignmentPopup.clickFewAddButton();

			// Verify all students are added in the text box
			assignAssignmentPopup.verifyallStudentsAdded();

			SMUtils.logDescriptionTC("SMK-9409 : verify the teacher should be able to remove muliple students"
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignAssignmentPopup.clickFewRemoveButton();

			// Verify all student are removed in the textbox
			assignAssignmentPopup.verifyAllstudentsremoved();
			assignAssignmentPopup.clickCancelButtonOnPopup();

			SMUtils.logDescriptionTC(
					"SMK-9413 : Verify the assign button is enable after selecting the group or student"
							+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignmentdetailspage.clickAssignButton();
			coursepage.clickMSDAPopup();
			assignAssignmentPopup.clickAddButtonAll();
			Log.assertThat(assignAssignmentPopup.isAssignButtonEnable(),"Assign Button Enable group successfully in Group",
					"Assign Button group not enable  successfully in Group");
			assignAssignmentPopup.checkStudents();
			assignAssignmentPopup.clickAddButtonAll();
			Log.assertThat(assignAssignmentPopup.isAssignButtonEnable(),"Assign Button Enable group successfully in Student",
					"Assign Button group not enable  successfully in Student");

			SMUtils.logDescriptionTC("SMK-9415 : Verify the teacher should be able to verify the assign button should be disabled by default "
							+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignAssignmentPopup.clickCancelButtonOnPopup();
			assignmentdetailspage.clickAssignButton();
			coursepage.clickMSDAPopup();
			Log.assertThat(assignAssignmentPopup.isCancelButtonOnPopupEnable(),"Assign Pop up Window is displayed successfully", "Assign Pop up Window is not displayed");

			SMUtils.logDescriptionTC("SMK-9416 : Verify the teacher should be able to cancel before assigning "
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignAssignmentPopup.clickCancelButtonOnPopup();
			assignmentdetailspage.clickAssignButton();
			coursepage.clickMSDAPopup();
			Log.assertThat(assignAssignmentPopup.isCancelButtonOnPopupEnable(),"Assign Pop up Window is displayed successfully", "Assign Pop up Window is not displayed");
			assignAssignmentPopup.checkStudents();
			assignAssignmentPopup.clickCancelButtonOnPopup();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the teacher is able to select a group and click the assign button then group should be appeared on the assignment page with the assigned status", groups = {
			"SMK-39226", "assignments", "assignmentDetailsPage" }, priority = 6)
	public void tc_AssignmentsPage_006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_AssignmentsPage_006:SMK-9417- Verify the teacher is able to select a group and click the assign button then group should be appeared on the assignment page with the assigned status."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			// Get Assignments Page
			AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup(driver);
			AssignmentsPage assignmentsPage = new AssignmentsPage(driver);
			AssignmentDetailsPage assignmentdetailspage = new AssignmentDetailsPage(driver);
			CoursesPage coursePage = new CoursesPage(driver);

			// Clicked the view assignment
			assignmentsPage.clickAssignmentSubMenu();
			coursePage.clickOnTheHoveredAssignment(Constants.READING);
			assignmentdetailspage.clickAssignButton();
			Log.assertThat(assignAssignmentPopup.isGroupSelected(), "Assign Pop up Window is displayed successfully",
					"Assign Pop up Window is not displayed");
			coursePage.addCourseToGroups();
			SMUtils.nap(5);// waiting for toast message to disappear

			SMUtils.logDescriptionTC("SMK-9419 : When we add all the groups then no unassigned groups should be created  "
							+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignmentdetailspage.clickAssignButton();
			assignAssignmentPopup.verifyGroupStudentsdisplayed();

			SMUtils.logDescriptionTC("SMK-9418 : Verify the teacher is able to select a student and click the assign button then student should be appeared on the assignment page with the assigned status"
							+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			assignAssignmentPopup.checkStudents();
			coursePage.addCourseToStudents();
			SMUtils.nap(5);// waiting for toast message to disappear

			SMUtils.logDescriptionTC("SMK-9420 : When we add all the students then no unassigned groups should be created"
							+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			// Verify unassigned groups should be created
			assignmentdetailspage.clickAssignButton();
			Log.assertThat(assignAssignmentPopup.isCancelButtonOnPopupEnable(),"Assign Pop up Window is displayed successfully", "Assign Pop up Window is not displayed");
			assignAssignmentPopup.checkStudents();
			assignAssignmentPopup.verifyGroupStudentsdisplayed();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify whether assign widget is obtained from the home page and Course page", groups = {
			"SMK-39226", "assignments", "assignmentDetailsPage" }, priority = 7)
	public void tc_AssignmentsPage_007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_AssignmentsPage_007:SMK-9421- Verify whether assign widget is obtained from the home page."
				+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
			AssignmentDetailsPage assignmentdetailspage = new AssignmentDetailsPage(driver);
			AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup(driver);
			CoursesPage coursePage = new CoursesPage(driver);
			// Click Assign button from home page

			assignmentdetailspage.clickAssignButtonhome();
			// Click MSDA
			coursePage.clickContinueToAssignButtonMSDA();
			assignAssignmentPopup.clickCancelButtonOnPopup();

			SMUtils.logDescriptionTC("SMK-9422 :  Verify whether the assign widget is obtained from the courses page"
					+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);
			// Click Assign button of Reading course from Course page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickCourseName(Constants.READING);
			coursepage.clickAssignBtn();
			Log.assertThat(assignAssignmentPopup.isCancelButtonOnPopupEnable(),"Assign Pop up Window is displayed successfully", "Assign Pop up Window is not displayed");
			assignAssignmentPopup.clickCancelButtonOnPopup();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify whether assign widget is obtained from the home page and Course page", groups = {
			"SMK-39226", "assignments", "assignmentDetailsPage" }, priority = 8)
	public void tc_AssignmentsPage_008(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("SMK-9423,SMK-9424 :  Verify if student is shared between two teachers then both teacher should assign the assignments"
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		String newOrgName = "Automation_Transfer_Org";
		String newTeacherName = "Transferd_School_Teacher" + System.nanoTime();
		String newStudentName = "Transferd_School_Student" + System.nanoTime();

		UserSqlHelper helper = new UserSqlHelper();

		try {

			LoginPage smLoginPage = null;

			// Login as teacher from old school
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			courseListingPage.selectCourseTypeFromDropDown("Default Courses");
			CoursesPage coursepage = new CoursesPage(driver);
			
			// Assigned Cousres to Students
						coursepage.clickCourseName(Constants.READING);
						coursepage.clickAssignBtn();
						coursepage.addCourseToStudents();
						SMUtils.nap(3);// waiting to disappear toast message
						
			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			List<String> assignmentFromAssignmentPage = assignmentsPage.getAllAssignmentNames();
			AssignmentDetailsPage assignmentDetailspage = new AssignmentDetailsPage(driver);
		//	CoursesPage coursepage = new CoursesPage(driver);
			coursepage = new CoursesPage(driver);

			// Assigned Cousres to Students
			coursepage.clickOnTheHoveredAssignment(Constants.READING);
			assignmentDetailspage.clickAssignButton();
			coursepage.addCourseToStudents();
			SMUtils.nap(3);// waiting to disappear toast message

			// Logout the teacher
			tHomePage.topNavBar.signOutfromSM();

			// Creating new school for transfer
			String studentId = SMUtils.getKeyValueFromResponse(
					DataSetup.teacherStudentMap.get(username).get("Student1"), "data,personId");
			new SqlHelperOrganization().deleteOrganization(newOrgName);
			Integer newOrgId = new SqlHelperOrganization().createOrganization(newOrgName, newOrgName);

			// Transfer the student
			sessionCookie = new BaseAPITest().getJessionCookie(smUrl, username, password);
			new BaseAPITest().transferUser(smUrl, sessionCookie, DataSetup.organizationId.toString(),
					newOrgId.toString(), "student", studentId);

			// Creating new teacher in new school for verifying the transfered student.
			Integer newTeacherID = helper.createTeacher(newTeacherName, newTeacherName, newTeacherName,Constants.PASSWORD_HASH, newOrgId);
			new BaseAPITest().createStudent(smUrl, sessionCookie, newStudentName, newStudentName, newStudentName,
					newStudentName, newTeacherID.toString(), newOrgId.toString(), "5");

			// Login as new teacher
			smLoginPage.enterCredentialsAndLogIn(newTeacherName, password);

			// Navigate to Students Page.
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
			AddStudentToAssignmentPopup addStudentToAssignmentUsingButton = studentsPage.addStudentToAssignmentButton();

			// Validations
			Log.assertThat(addStudentToAssignmentUsingButton.getZeroStateMessage().trim().equals(UserUIConstants.ADD_STUDENT_TO_ASSIGNMENT_ZERO_STAGE.trim()),
					"Zero state message displayed!", "Error in displaying zero stage.");
			SMUtils.clickJS(driver, addStudentToAssignmentUsingButton.getOkayButton());

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

}