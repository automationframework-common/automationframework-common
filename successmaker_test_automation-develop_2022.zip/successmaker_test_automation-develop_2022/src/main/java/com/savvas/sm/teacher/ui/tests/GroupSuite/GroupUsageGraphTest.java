package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This class used to test the usage graph for group UI.
 *
 * @author ajith.mohan
 *
 */
@Listeners ( EmailReport.class )
public class GroupUsageGraphTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String sessionCookie;
    private String username = null;
    private String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private boolean isGroupCrossedHours = false;

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher34" );

        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
    }

    @Test ( priority = 1, groups = { "SMK-43897", "Groups", "GroupUsageGraph" } )
    public void tcGroupUsageGraph01( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-12321 - Verify 'NO DATA YET' message  shown if the students from group not  attended any course" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            String groupName = "AutomationUsage_" + System.nanoTime();

            //Creating teacher
            String newTeacherName = "Test_Shared_Student_Teacher" + System.nanoTime();
            new UserSqlHelper().createTeacher( newTeacherName, newTeacherName, newTeacherName, Constants.PASSWORD_HASH, DataSetup.organizationId );

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( newTeacherName, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            //Creating group with students
            groupsTab.createGroupWithHomeRoomStudents( groupName, SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student10" ), "data,userName" ) );
            groupsTab.viewGroup( groupName );
            Log.assertThat( groupsTab.getZeroStateMessageForUsage().trim().equals( Constants.GroupUIConstants.ZERO_STATE_MESSAGE_FOR_USAGE ), "ZeroState Message Displayed successfully!", "ZeroState Message not displayed!" );
            SMUtils.logDescriptionTC( "SMK-12322 - Verify 'NO DATA YET' message shown  for student usage if teacher not  having any assignments" );
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 2, groups = { "SMK-43897", "Groups", "GroupUsageGraph" } )
    public void tcGroupUsageGraph02( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = null;
        Log.testCaseInfo( "SMK-12338 - Verify the Groups - Graphs - Usage if Math Course only Attended" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            String groupName = "AutomationUsage_" + System.nanoTime();

            //Logging as teacher
            // Get driver
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            EventListener eventListner = new EventListener();
            driver.register(eventListner);
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            String studentUserNames = "";
            for ( int studentCount = 1; studentCount <= 2; studentCount++ ) {

                studentUserNames = studentUserNames + SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,userName" ) + ",";
            }
            StringBuffer studentIDsForRequest = new StringBuffer( studentUserNames );
            studentIDsForRequest.deleteCharAt( studentIDsForRequest.length() - 1 );

            //Creating group with HRG
            groupsTab.createGroupWithHomeRoomStudents( groupName, studentUserNames );

            //View group
            groupsTab.viewGroup( groupName );

            //Validation
            Log.assertThat( groupsTab.verifyGroupUsageChart(), "Group usage fields are verified successfully!", "Issue with group usage fields." );

            HashMap<String, String> graphDetails = groupsTab.getGraphValues();

            for ( String usageField : Constants.UsageChart.USAGE_FIELDS ) {
                if ( graphDetails.get( usageField ).contains( Constants.UsageChart.HOUR ) ) {
                    isGroupCrossedHours = true;
                } else if ( graphDetails.get( usageField ).contains( Constants.UsageChart.Minute ) ) {
                    isGroupCrossedHours = false;
                }
            }

            Log.assertThat( groupsTab.verifyGroupUsageChartFieldsData( getIndividualFieldValues( groupName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), DataSetup.organizationId.toString() ), isGroupCrossedHours ),
                    "Group usage graph field values are displayed correctly!", "Issue with group usage field values." );
            boolean verifiedGraph = groupsTab.verifyGroupUsageGraph( getWeekUsageDetails( groupName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), driver, DataSetup.organizationId.toString() ), isGroupCrossedHours );
            Log.assertThat( verifiedGraph, "Group usage graph graph values displayed correctly!", "Issue with group usage graph values." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 3, groups = { "SMK-43897", "Groups", "GroupUsageGraph" } )
    public void tcGroupUsageGraph03( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = null;
        Log.testCaseInfo( "SMK-12339 - Verify the Groups - Graphs - Usage if Reading Course only Attended" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            String groupName = "AutomationUsage_" + System.nanoTime();

            //Logging in as teacher
            // Get driver
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            EventListener eventListner = new EventListener();
            driver.register(eventListner); LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            String studentUserNames = "";
            for ( int studentCount = 1; studentCount <= 3; studentCount++ ) {

                studentUserNames = studentUserNames + SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,userName" ) + ",";
            }

            StringBuffer studentIDsForRequest = new StringBuffer( studentUserNames );
            studentIDsForRequest.deleteCharAt( studentIDsForRequest.length() - 1 );

            //Creating group with students
            groupsTab.createGroupWithHomeRoomStudents( groupName, studentUserNames );

            //Viewing group
            groupsTab.viewGroup( groupName );

            //Validations
            Log.assertThat( groupsTab.verifyGroupUsageChart(), "Group usage fields are verified successfully!", "Issue with group usage fields." );

            HashMap<String, String> graphDetails = groupsTab.getGraphValues();

            for ( String usageField : Constants.UsageChart.USAGE_FIELDS ) {
                if ( graphDetails.get( usageField ).contains( Constants.UsageChart.HOUR ) ) {
                    isGroupCrossedHours = true;
                } else if ( graphDetails.get( usageField ).contains( Constants.UsageChart.Minute ) ) {
                    isGroupCrossedHours = false;
                }
            }

            Log.assertThat( groupsTab.verifyGroupUsageChartFieldsData( getIndividualFieldValues( groupName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), DataSetup.organizationId.toString() ), isGroupCrossedHours ),
                    "Group usage graph field values are displayed correctly!", "Issue with group usage field values." );
            boolean verifiedGraph = groupsTab.verifyGroupUsageGraph( getWeekUsageDetails( groupName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), driver, DataSetup.organizationId.toString() ), isGroupCrossedHours );
            Log.assertThat( verifiedGraph, "Group usage graph graph values displayed correctly!", "Issue with group usage graph values." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 4, groups = { "SMK-43897", "Groups", "GroupUsageGraph" } )
    public void tcGroupUsageGraph04( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-12334 - Verify the Groups - Graphs - Usage if the student is shared student" + "<small><b><i>[" + browser + "]</b></i></small>" );
    	try {
            //Creating teacher
            String newTeacherName = "Test_Shared_Student_Teacher" + System.nanoTime();
            Integer newTeacherId = new UserSqlHelper().createTeacher( newTeacherName, newTeacherName, newTeacherName, Constants.PASSWORD_HASH, DataSetup.organizationId );

            //Logging as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( newTeacherName, password, true );

            //Creating group
            String groupName = "Shared_Student_" + System.nanoTime();
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            groupsTab.createGroupWithSchoolStudents( groupName, SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,userName" ), "All Grades" );
            groupsTab.viewGroup( groupName );

            //Validations
            Log.assertThat( groupsTab.verifyGroupUsageChart(), "Group usage fields are verified successfully!", "Issue with group usage fields." );

            SMUtils.logDescriptionTC( "SMK-12329 - Verify the THIS WEEK information  shows the sum of reading and  math assignments usage of current week." );
            SMUtils.logDescriptionTC( "SMK-12330 - Verify the LAST WEEK information  shows the sum of reading and  math assignments usage of last week." );
            SMUtils.logDescriptionTC( "SMK-12331 - Verify the SCHOOL YEAR  information shows the sum of reading and math assignments usage of entire school year." );

            HashMap<String, String> graphDetails = groupsTab.getGraphValues();

            for ( String usageField : Constants.UsageChart.USAGE_FIELDS ) {
                if ( graphDetails.get( usageField ).contains( Constants.UsageChart.HOUR ) ) {
                    isGroupCrossedHours = true;
                } else if ( graphDetails.get( usageField ).contains( Constants.UsageChart.Minute ) ) {
                    isGroupCrossedHours = false;
                }
            }

            Log.assertThat( groupsTab.verifyGroupUsageChartFieldsData( getIndividualFieldValues( groupName, newTeacherId.toString(), DataSetup.organizationId.toString() ), isGroupCrossedHours ), "Group usage graph field displayed correctly!",
                    "Issue with group usage fields." );
            boolean verifiedGraph = groupsTab.verifyGroupUsageGraph( getWeekUsageDetails( groupName, newTeacherId.toString(), driver, DataSetup.organizationId.toString() ), isGroupCrossedHours );
            Log.assertThat( verifiedGraph, "Group usage graph graph values displayed correctly!", "Issue with group usage graph values." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 5, groups = { "SMK-43897", "Groups", "GroupUsageGraph" } )
    public void tcGroupUsageGraph05( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-12323 - Verify the Groups - Graphs - Usage if the student is removed from the group." + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            String groupName = "AutoMation_Usage_" + System.nanoTime();

            //Logging as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Navigating group
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            String studentUserNames = "";
            for ( int studentCount = 1; studentCount <= 3; studentCount++ ) {

                studentUserNames = studentUserNames + SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,userName" ) + ",";
            }

            StringBuffer studentIDsForRequest = new StringBuffer( studentUserNames );
            studentIDsForRequest.deleteCharAt( studentIDsForRequest.length() - 1 );

            //Creating group
            groupsTab.createGroupWithHomeRoomStudents( groupName, studentUserNames );

            //Viewing group
            groupsTab.viewGroup( groupName );

            //Validations
            Log.assertThat( groupsTab.verifyGroupUsageChart(), "Group usage fields are verified successfully!", "Issue with group usage fields." );

            HashMap<String, String> graphDetailsBeforeRemoval = groupsTab.getGraphValues();
            for ( String usageField : Constants.UsageChart.USAGE_FIELDS ) {
                if ( graphDetailsBeforeRemoval.get( usageField ).contains( Constants.UsageChart.HOUR ) ) {
                    isGroupCrossedHours = true;
                } else if ( graphDetailsBeforeRemoval.get( usageField ).contains( Constants.UsageChart.Minute ) ) {
                    isGroupCrossedHours = false;
                }
            }

            Log.assertThat( groupsTab.verifyGroupUsageChartFieldsData( getIndividualFieldValues( groupName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), DataSetup.organizationId.toString() ), isGroupCrossedHours ),
                    "Group usage graph field values are displayed correctly before removeal of student!", "Issue with group usage field values." );
            boolean verifiedGraph = groupsTab.verifyGroupUsageGraph( getWeekUsageDetails( groupName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), driver, DataSetup.organizationId.toString() ), isGroupCrossedHours );
            Log.assertThat( verifiedGraph, "Group usage graph graph values displayed correctly before removeal of student !", "Issue with group usage graph values." );

            //Removing all the groups for the students
            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();
            studentTab.clickviewStudentByEllipsis( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student3" ), "data,userName" ) );

            //Removing student
            studentTab.removeStudentFromAllGroup();
            tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );

            //Validations
            Log.assertThat( groupsTab.verifyGroupUsageChart(), "Group usage fields are verified successfully!", "Issue with group usage fields." );

            HashMap<String, String> graphDetails = groupsTab.getGraphValues();

            for ( String usageField : Constants.UsageChart.USAGE_FIELDS ) {
                if ( graphDetails.get( usageField ).contains( Constants.UsageChart.HOUR ) ) {
                    isGroupCrossedHours = true;
                } else if ( graphDetails.get( usageField ).contains( Constants.UsageChart.Minute ) ) {
                    isGroupCrossedHours = false;
                }
            }

            Log.assertThat( groupsTab.verifyGroupUsageChartFieldsData( getIndividualFieldValues( groupName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), DataSetup.organizationId.toString() ), isGroupCrossedHours ),
                    "Group usage graph field values are displayed correctly after removeal of student!", "Issue with group usage field values." );
            verifiedGraph = groupsTab.verifyGroupUsageGraph( getWeekUsageDetails( groupName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), driver, DataSetup.organizationId.toString() ), isGroupCrossedHours );
            Log.assertThat( verifiedGraph, "Group usage graph graph values displayed correctly after removeal of student!", "Issue with group usage graph values." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 5, groups = { "SMK-43897", "Groups", "GroupUsageGraph" } )
    public void tcGroupUsageGraph06( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-12324 - Verify the Groups - Graphs - Usage if the new student is added to the group" + "<small><b><i>[" + browser + "]</b></i></small>" );
    	try {
    		String groupName = "AutoMation_Usage_" + System.nanoTime();

    		//Logging in as teacher
    		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Navigating the groups tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            String studentUserNames = "";
            for ( int studentCount = 1; studentCount <= 3; studentCount++ ) {

                studentUserNames = studentUserNames + SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,userName" ) + ",";
            }

            StringBuffer studentIDsForRequest = new StringBuffer( studentUserNames );
            studentIDsForRequest.deleteCharAt( studentIDsForRequest.length() - 1 );

            //Creating group
            groupsTab.createGroupWithHomeRoomStudents( groupName, studentUserNames );
            groupsTab.viewGroup( groupName );

            //Validations
            Log.assertThat( groupsTab.verifyGroupUsageChart(), "Group usage fields are verified successfully!", "Issue with group usage fields." );

            HashMap<String, String> graphDetails = groupsTab.getGraphValues();

            for ( String usageField : Constants.UsageChart.USAGE_FIELDS ) {
                if ( graphDetails.get( usageField ).contains( Constants.UsageChart.HOUR ) ) {
                    isGroupCrossedHours = true;
                } else if ( graphDetails.get( usageField ).contains( Constants.UsageChart.Minute ) ) {
                    isGroupCrossedHours = false;
                }
            }

            Log.assertThat( groupsTab.verifyGroupUsageChartFieldsData( getIndividualFieldValues( groupName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), DataSetup.organizationId.toString() ), isGroupCrossedHours ),
                    "Group usage graph field values are displayed correctly!", "Issue with group usage field values." );
            boolean verifiedGraph = groupsTab.verifyGroupUsageGraph( getWeekUsageDetails( groupName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), driver, DataSetup.organizationId.toString() ), isGroupCrossedHours );
            Log.assertThat( verifiedGraph, "Group usage graph graph values displayed correctly!", "Issue with group usage graph values." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 7, groups = { "SMK-43897", "Groups", "GroupUsageGraph" } )
    public void tcGroupUsageGraph07( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-12327 - Verify the Groups - Graphs - Usage if the assignment is removed from the group" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            String groupName = "AutoMation_Usage_" + System.nanoTime();

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Navigating groups and creating groups
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            String studentUserNames = "";
            for ( int studentCount = 1; studentCount <= 5; studentCount++ ) {

                studentUserNames = studentUserNames + SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,userName" ) + ",";
            }

            StringBuffer studentIDsForRequest = new StringBuffer( studentUserNames );
            studentIDsForRequest.deleteCharAt( studentIDsForRequest.length() - 1 );

            groupsTab.createGroupWithHomeRoomStudents( groupName, studentUserNames );

            //Navigating to assignment and to delete the assignment
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetails = assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.MATH );

            //Deleting the assignment
            assignmentDetails.clickDeleteAssignmenttabTopEllipsis();

            Log.message( "Math assignment Deleted" );

            tHomePage.topNavBar.navigateToAssignmentsPage();
            assignmentDetails = assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.READING );

            //Deleting the assignment
            assignmentDetails.clickDeleteAssignmenttabTopEllipsis();

            tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );

            Log.assertThat( groupsTab.getZeroStateMessageForUsage().trim().equals( Constants.GroupUIConstants.ZERO_STATE_MESSAGE_FOR_USAGE ), "ZeroState Message Displayed successfully!", "ZeroState Message not displayed!" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 8, groups = { "SMK-43897", "Groups", "GroupUsageGraph" } )
    public void tcGroupUsageGraph08( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-12328 - Verify the Groups - Graphs - Usage if the new assignment is added to the group" + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {
            String groupName = "AutoMation_Usage_" + System.nanoTime();

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Navigating to groups and creating new group
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            String studentUserNames = "";
            for ( int studentCount = 1; studentCount <= 5; studentCount++ ) {

                studentUserNames = studentUserNames + SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,userName" ) + ",";
            }

            StringBuffer studentIDsForRequest = new StringBuffer( studentUserNames );
            studentIDsForRequest.deleteCharAt( studentIDsForRequest.length() - 1 );

            //Creating group with removed student
            groupsTab.createGroupWithHomeRoomStudents( groupName, studentUserNames );

            CoursesPage courseListingPage = tHomePage.topNavBar.navigateToCourseListingPage();
            courseListingPage.clickMathCourse();
            courseListingPage.clickAssignBtn();
            courseListingPage.addCourseToGroups();

            tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );

            //Validation
            Log.assertThat( groupsTab.getZeroStateMessageForUsage().trim().equals( Constants.GroupUIConstants.ZERO_STATE_MESSAGE_FOR_USAGE ), "ZeroState Message Displayed successfully!", "ZeroState Message not displayed!" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 6, groups = { "SMK-43897", "Groups", "GroupUsageGraph" } )
    public void tcGroupUsageGraph09( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-12335 - Verify the Groups - Graphs - Usage if the student is tranfered to other teacher." + "<small><b><i>[" + browser + "]</b></i></small>" );

    	String newOrgName = "Automation_Transfer_Org";
        String newTeacherName = "Transferd_School_Teacher" + System.nanoTime();
        String groupName = "AutoMation_Usage_" + System.nanoTime();
        try {

            //Logging as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Creating group in groups tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            String studentUserNames = "";
            for ( int studentCount = 1; studentCount <= 5; studentCount++ ) {

                studentUserNames = studentUserNames + SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,userName" ) + ",";
            }

            StringBuffer studentIDsForRequest = new StringBuffer( studentUserNames );
            studentIDsForRequest.deleteCharAt( studentIDsForRequest.length() - 1 );

            groupsTab.createGroupWithHomeRoomStudents( groupName, studentUserNames );

            //Logout the teacher
            tHomePage.topNavBar.signOutfromSM();

            //Creating new school for transfer
            String studentId = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student2" ), "data,personId" );
            new SqlHelperOrganization().deleteOrganization( newOrgName );
            Integer newOrgId = new SqlHelperOrganization().createOrganization( newOrgName, newOrgName );

            //Transfer the student
            sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
            new BaseAPITest().transferUser( smUrl, sessionCookie, DataSetup.organizationId.toString(), newOrgId.toString(), "student", studentId );

            //Creating new teacher in new school for verifying the transfered student.
            Integer newTeacherID = new UserSqlHelper().createTeacher( newTeacherName, newTeacherName, newTeacherName, Constants.PASSWORD_HASH, newOrgId );

            //Login as new teacher
            smLoginPage.enterCredentialsAndLogIn( newTeacherName, password );

            groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            String afterTransferGroupName = "AutoMation_Usage_Transfered" + System.nanoTime();
            groupsTab.createGroupWithSchoolStudents( afterTransferGroupName, SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student2" ), "data,userName" ), "All Grades" );
            groupsTab.viewGroup( afterTransferGroupName );

            //Validations
            Log.assertThat( groupsTab.verifyGroupUsageChart(), "Group usage fields are verified successfully!", "Issue with group usage fields." );

            HashMap<String, String> graphDetails = groupsTab.getGraphValues();

            for ( String usageField : Constants.UsageChart.USAGE_FIELDS ) {
                if ( graphDetails.get( usageField ).contains( Constants.UsageChart.HOUR ) ) {
                    isGroupCrossedHours = true;
                } else if ( graphDetails.get( usageField ).contains( Constants.UsageChart.Minute ) ) {
                    isGroupCrossedHours = false;
                }
            }
            Log.assertThat( groupsTab.verifyGroupUsageChartFieldsData( getIndividualFieldValues( afterTransferGroupName, newTeacherID.toString(), newOrgId.toString() ), isGroupCrossedHours ), "Group usage graph field displayed correctly!",
                    "Issue with group usage fields." );
            boolean verifiedGraph = groupsTab.verifyGroupUsageGraph( getWeekUsageDetails( afterTransferGroupName, newTeacherID.toString(), driver, newOrgId.toString() ), isGroupCrossedHours );
            Log.assertThat( verifiedGraph, "Group usage graph graph values displayed correctly!", "Issue with group usage graph values." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            new SqlHelperOrganization().deleteOrganization( newOrgName );
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * getting week usage details
     *
     * @param groupName
     * @param teacherId
     * @param driver
     * @param orgID
     * @return
     * @throws Exception
     * @throws IOException
     */
    private HashMap<String, HashMap<String, Integer>> getWeekUsageDetails( String groupName, String teacherId, WebDriver driver, String orgID ) throws Exception {
        HashMap<String, HashMap<String, Integer>> usageHours = new HashMap<>();

        try {
            String groupId = new UserSqlHelper().getGroupID( groupName );
            sessionCookie = new BaseAPITest().getJessionCookie( smUrl, SMUtils.getKeyValueFromResponse( DataSetup.teacherDetailsMap.get( "Teacher30" ), "data,userId" ), password );
            String usageReport = new BaseAPITest().getGroupUsageReport( smUrl, sessionCookie, orgID, teacherId, groupId );

            //Parsing json array and getting the values
            GroupPage groupsTab = new GroupPage( driver );
            List<String> lastFourWeeks = GroupPage.getFourWeeksMonday();
            for ( int week = 0; week < 4; week++ ) {
                HashMap<String, Integer> subjectUsage = new HashMap<>();
                JSONObject jsonObj = new JSONObject( usageReport );
                JSONObject weedDetails = jsonObj.getJSONObject( "data" );
                JSONArray ja = weedDetails.getJSONArray( "studentUsageData" );
                JSONObject jObj = ja.getJSONObject( week );
                subjectUsage.put( Constants.UsageChart.MATH, Integer.parseInt( jObj.get( "mathMins" ).toString() ) );
                subjectUsage.put( Constants.UsageChart.READING, Integer.parseInt( jObj.get( "readingMins" ).toString() ) );
                subjectUsage.put( Constants.UsageChart.TOTAL, subjectUsage.get( "Math" ) + subjectUsage.get( "Reading" ) );
                usageHours.put( lastFourWeeks.get( week ), subjectUsage );
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return usageHours;
    }

    /**
     * Getting individual field values
     *
     * @param groupName
     * @param teacherId
     * @param orgID
     * @return
     * @throws Exception
     * @throws IOException
     */
    private HashMap<String, Integer> getIndividualFieldValues( String groupName, String teacherId, String orgID ) throws Exception {
        String groupId = new UserSqlHelper().getGroupID( groupName );

        sessionCookie = new BaseAPITest().getJessionCookie( smUrl, SMUtils.getKeyValueFromResponse( DataSetup.teacherDetailsMap.get( "Teacher30" ), "data,userId" ), password );
        String usageReport = new BaseAPITest().getGroupUsageReport( smUrl, sessionCookie, orgID, teacherId, groupId );

        String lastWeekHour = SMUtils.getKeyValueFromResponseWithArray( usageReport, "data,lastWeekMins" );
        String thisWeekHour = SMUtils.getKeyValueFromResponseWithArray( usageReport, "data,thisWeekMins" );
        String schoolYearHours = SMUtils.getKeyValueFromResponseWithArray( usageReport, "data,totalMinutes" );
        HashMap<String, Integer> individualFields = new HashMap<>();
        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 0 ), Integer.parseInt( thisWeekHour ) );
        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 1 ), Integer.parseInt( lastWeekHour ) );
        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 2 ), Integer.parseInt( schoolYearHours ) );
        return individualFields;
    }

}
