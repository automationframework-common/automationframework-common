package com.savvas.sm.common.utils.apiconstants;

public interface CommonAPIConstants {

    public static String STATUS_CODE_CREATED = "201";
    public static String STATUS_CODE_OK = "200";
    public static String STATUS_CODE_BAD_REQUEST = "400";
    public static String STATUS_CODE_FORBIDDAN = "403";
    public static String STATUS_CODE_UNAUTHORIZED = "401";
    public static String STATUS_CODE_INTERNAL_ERROR = "500";
    public static String STATUS_CODE_NOTFOUND = "404";
    public static String INVALID_ACCESS_TOKEN = "tzKkI6qMIBEnSdktf3giXpDxZcxzPToJxmu2jViFxi2eTkhjDXmMwxkQJnTJDqGePiNmnxvxsOZLs6dIb8dIFS9UeYeNQVfHjr6vlIq5QN6gUbugeelLP4ThAltcT4pgSoRVfAtuJ1KUJjhniHYSqfpGU9xrhK1bjIbppZqD3MitFGH5sAE46bPZR4p7RkQpgOBU5xrKPEo4o74crm";
    public static String STATUS_EMPTY = "500";
    public static String INVALID_ORG_ID = "8a7201c77ea23877017ef71522c91a07";
    public static String INVALID_STAFF_ID = "ffffffff6220b5804d2d9c00307de665";
    public static String STATUS_CODE_ACCEPTED = "202";
    public static String STATUS_METHOD_NOT_SUPPORTED = "405";
    //Exceptions
    public static String BUSINESS_RULE_VIOLATION = "com.savvas.core.exceptions.BusinessRuleViolationException";
    public static String MISMATCH_SERVLET_EXCEPTION = "org.springframework.web.bind.MissingServletRequestParameterException";
    public static String AUTHENTICATION_EXCEPTION = "java.lang.Exception";
    public static String FORBIDDAN_EXCEPTION = "org.springframework.security.access.AccessDeniedException";
    public static String BAD_REQUEST_EXCEPTION = "org.springframework.web.client.HttpClientErrorException$BadRequest";
    public static String DATA_NOT_FOUND_EXCEPTION = "com.savvas.core.exceptions.DataNotFoundException";
    public static String NO_CMS_CLASS_EXCEPTION = "org.springframework.web.client.HttpClientErrorException$NotFound";
    public static String NULL_EXCEPTION_NEW="null";
 
    public String METHOD_ARGUMENT_TYPE_MISMATCH = "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException";
    public String NULL_POINTER_EXCEPTION = "java.lang.NullPointerException";
    public static String METHO_ANNOTATION_EXP = "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException";

    public String ACCESS_DENIED_EXCEPTION = "org.springframework.security.access.AccessDeniedException";
    public String JAVA_LANG_EXCEPTION = "java.lang.Exception";
    public String MESSAGE_NOT_READABLE_EXCEPTION = "org.springframework.http.converter.HttpMessageNotReadableException";

    public static String METHOD_EXCEPTION = "org.springframework.web.HttpRequestMethodNotSupportedException";
    public static String BAD_REQUEST_EXCEPTION_METHOD = "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException";
    public static String NULL_EXCEPTION = "org.springframework.web.bind.MissingPathVariableException";

    public String HTTP_MESSAGE_NOTREADABLE_EXCEPTION = "org.springframework.http.converter.HttpMessageNotReadableException";

    public String VALIDATION_EXCEPTION = "com.pst.exceptions.ValidationException";
    public String NOTFOUND_EXCEPTION = "org.springframework.web.client.HttpClientErrorException$NotFound";
    public String NUMBER_FORMAT_EXCEPTION = "java.lang.NumberFormatException";

    //Messages
    public static String INVALID_ORG_MESSAGE = "Organization ID is incorrect";
    public static String EMPTY_END_DATE ="For usage goals update, target goal end date cannot be null or blank or invalid";
    public static String INVALID_STUDENT_MESSAGE = "Invalid student id";
    public static String INVALID_TEACHER_MESSAGE = "Invalid Created by in request json";
    public static String INVALID_AUTHENTICATION_MESSAGE = "Authentication Failed";
    public static String FORBIDDAN_MESSAGE = "Access is denied";
    public static String LIMIT_MESSAGE = "Please limit the number of students in your group to 100 or less.";
    public static String GROUP_LIST_DATA_NOT_FOUND_EXCEPTION_MESSAGE = "Unable to fetch Group data";
    public static String GROUP_LIST_INVALID_STUDENT_EXCEPTION_MESSAGE = "Invalid user pi-id value to fetch sections";
    public static String NO_GROUP_CMS_MESSAGE = "No sections found for given user";
    public static String SECTION_ID_NOTFOUND_MESSAGE = "Section id not found";
    public static String INVALID_UPDATED_MESSAGE = "Invalid Updated by in request json";
    public static String GET_USER_DETAILS_SUCCESS_MESSAGE = "User Details returned Successfully";
    public static String INVALID_USER_MESSAGE = "Invalid student id";
    public static String GROUP_DELETE_SUCCESS_MESSAGE = "Group deleted Successfully";
    public static String NO_COURSE_ID_MESSAGE = "fetchContentUnitById: Content base not found with id";
    public static String STUDENT_LIST_NOT_FOUND = "Student list not found for this group Id";
    public static String EMPTY_COURSEID_EXP = "Missing URI template variable 'contentBaseId' for method parameter of type Long";
    public static String INVALID_COURSEID_EXP = "Failed to convert value of type 'java.lang.String' to required type 'java.lang.Long'; nested exception is java.lang.NumberFormatException: For input string: \"ABCD\". Root cause: For input string: \"ABCD\"";
    public static String INVALID_GROUPID_EXP="Group not associated with given staff : ";
    public static String NONEXIST_COURSEID_READING = "Assignment Details Not found for courseId:20000";
    public static String NONEXIST_COURSEID_MATH = "Assignment Details Not found for courseId:10000";
    public static String NULL_MESSAGE = "Missing URI template variable 'courseId' for method parameter of type Long";
    public static String STAFFID_EMPTY = "staff id cannot be empty";
    public static String ORGID_EMPTY = "org id cannot be empty";
    public static String TEACHER_MESSAGE = "Teacher not found for given id : 123";
    public static String STUDENT_NOT_FOUND_MESSSAGE = "Student Not Found";
    public static String INVALID_TEACHER_MESSSAGE = "Invalid Teacher Id is used";
    public static String EMPTY_STRING = "";
    public static String GROUP_NOT_FOUND_MESSAGE = "Group with id zzz is not found";
    public static String ASSIGNMENT_NOT_FOUND_MESSAGE = "Assignment Details Not found";
    public static String NO_PROGRESS_TO_SHOW_MESSAGE = "No progress to show you";
    public static String USER_ID_MISMATCH_MESSAGE = "Login UserId / Request User Id mismatch";
    public static String GROUP_USAGE_NOT_FOUND_MESSAGE = "Group usage not found";
    public static String UNEXPECTED_ERROR="Unexpected error occurred. Please view log for details";
       
    public String JSON_PARSE_ERROR = "JSON parse error";
   


    public static String DEFAULT_COURSE_DELETE_MESSAGE = "Default course deletion not allowed for given id : ";
    public static String SMFOCUS_COURSE_DELETE_MESSAGE = "SM focus course deletion not allowed for given id : ";
    public static String COURSE_DELETE_NON_EXISTING_ID_MESSAGE = "Course courseid is not associated with given organization: orgId";
    public static String COURSE_DELETE_INVALID_MESSAGE = "Failed to convert value of type 'java.lang.String' to required type 'java.lang.Long'; nested exception is java.lang.NumberFormatException";
    public static String COURSE_DELETE_INVALID_BEARER_TOKEN = "Authentication Failed";
    public static String COURSE_DELETE_SUCCESS_MESSAGE = "Message verified Successfully";
    public static String COURSE_DELETE_FAILURE_MESSAGE = "Message is not verified  Successfully";
    public static String COURSE_DELETE_SUCCESS_STATUS = "Status verified Successfully";
    public static String COURSE_DELETE_FAILURE_STATUS = "Status is not verified Successfully";
    public static String COURSE_DELETE_GET_CALL = "Request method 'GET' not supported";
    public static String STUDENT_DETAILS_UPDATED_SUCCESS_MESSAGE = "Student Details updated Successfully";
    public static String LIMIT_STUDENT_COUNT_LESS_100_ERROR_MESSAGE = "Please limit the number of students in your group to 100 or less.";

    public static String INVALID_ORG_SERVER_MESSAGE = "400 : [{\"timestamp\":1646648070143,\"error\":\"BAD_REQUEST\",\"status\":400,\"path\":\"/user-service/v1/user\",\"application\":\"user-service\",\"validationMessages\":[{\"validationId\":\"INVALID_CREATED_BY\",\"type\":\"ERROR\",\"mes... (440 bytes)]";
    public static String INVALID_TEACHER_SERVER_MESSAGE = "400 : [{\"timestamp\":1646648203276,\"error\":\"BAD_REQUEST\",\"status\":400,\"path\":\"/user-service/v1/user\",\"application\":\"user-service\",\"validationMessages\":[{\"validationId\":\"INVALID_CREATED_BY\",\"type\":\"ERROR\",\"message\":\"Created By is not valid. Expected one of these values: [Self-reg, Self-reg-EB, System, Valid UserId]\"}]}]";
    public static String INVALID_GRADE_MESSAGE = "com.fasterxml.jackson.databind.exc.InvalidFormatException";
    public static String EMPTY_GRADE_MESSAGE = "JSON parse error: Cannot coerce empty String";
    public static String EMPTY_DEMOGRAPHICS_MESSAGE = "JSON parse error: Cannot coerce empty String (\"\") to `com.pst.student.Ethnicity` value (but could if coercion was enabled using `CoercionConfig`); nested exception is com.fasterxml.jackson.databind.exc.InvalidFormatException: Cannot coerce empty String (\"\") to `com.pst.student.Ethnicity` value (but could if coercion was enabled using `CoercionConfig`)\n at [Source: (PushbackInputStream); line: 11, column: 16] (through reference chain: com.pst.lms.dto.Student[\"ethnicity\"]). Root cause: Cannot coerce empty String (\"\") to `com.pst.student.Ethnicity` value (but could if coercion was enabled using `CoercionConfig`)\n at [Source: (PushbackInputStream); line: 11, column: 16] (through reference chain: com.pst.lms.dto.Student[\"ethnicity\"])";
    public static String INVALID_ETHINICITY_MESSAGE = "JSON parse error: Cannot deserialize value of type `com.pst.student.Ethnicity` from String \"ABCD\": not one of the values accepted for Enum class: [OTHER, NATIVE_AMERICAN_ALASKAN_NATIVE, ASIAN_PACIFIC_ISLANDER, NOT_SPECIFIED, CAUCASIAN, AFRICAN_AMERICAN, HISPANIC_OR_LATINO]; nested exception is com.fasterxml.jackson.databind.exc.InvalidFormatException: Cannot deserialize value of type `com.pst.student.Ethnicity` from String \"ABCD\": not one of the values accepted for Enum class: [OTHER, NATIVE_AMERICAN_ALASKAN_NATIVE, ASIAN_PACIFIC_ISLANDER, NOT_SPECIFIED, CAUCASIAN, AFRICAN_AMERICAN, HISPANIC_OR_LATINO]\n at [Source: (PushbackInputStream); line: 11, column: 16] (through reference chain: com.pst.lms.dto.Student[\"ethnicity\"]). Root cause: Cannot deserialize value of type `com.pst.student.Ethnicity` from String \"ABCD\": not one of the values accepted for Enum class: [OTHER, NATIVE_AMERICAN_ALASKAN_NATIVE, ASIAN_PACIFIC_ISLANDER, NOT_SPECIFIED, CAUCASIAN, AFRICAN_AMERICAN, HISPANIC_OR_LATINO]\n at [Source: (PushbackInputStream); line: 11, column: 16] (through reference chain: com.pst.lms.dto.Student[\"ethnicity\"])";
    public static String EMPTY_MANDATORY_FIELD_MESAGE = "400 : [{\"timestamp\":1646644789393,\"error\":\"BAD_REQUEST\",\"status\":400,\"path\":\"/user-service/v1/user\",\"application\":\"user-service\",\"validationMessages\":[{\"validationId\":\"EMPTY_FIRST_NAME\",\"type\":\"ERROR\",\"messa... (687 bytes)]";
    public static String FIRSTNAME_LIMIT_EXCEED_EXCEPTION = "Username length must be between 0 and 64. Last Name length must be between 0 and 64. First Name length must be between 0 and 64.";
    public String MISMATCH_TEACHER_MESSAGE = "Login UserId / Request User Id mismatch";
    public String MISMATCH_ORG_MESSAGE = "OrgId: %s from request URI does not present in OrgIds: [%s] from request header";
    public static String GROUP_NAME_MESSAGE = "Group name should not be null or less than 3 characters or more than 75 characters";
    public static String USER_ALREADY_RESTORED = "Restoration Error. Reason : Assignment User has already restored.";
    public static String ASSIGNMENT_USER_NOT_FOUND ="Assignment User not found";

    public String MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE = "Only skills assessed in the past 30 days are considered for this graph.";
    public String INVALID_CONTENT_BASE_ID = "Failed to convert value of type 'java.lang.String' to required type 'int'; nested exception is java.lang.NumberFormatException: For input string: ABCD. Root cause: For input string: ABCD";
    public String EMPTY_SUBJECT_ID_MESSAGE = "Required int parameter 'subjectTypeId' is not present";
    public String JSON_PARSE_MESSAGE = "JSON parse error";
    public String EMPTY_ASSIGNMENT_USER_ID_MESSAGE = "The skills tested assignment user id cannot be null or blank";
    public String INVALID_ORG_PARTIAL_ERROR_MESSAGE = "request URI does not present in OrgIds";
    //Constants
    public String FLEX_LICENSE_SCHOOL = "flexLicensesSchool";
    public String MATH_LICENSE_SCHOOL = "mathLicensesSchool";
    public String READING_LICENSE_SCHOOL = "readingLicensesSchool";
    public String FOCUS_MATH_LICENSE_SCHOOL = "focusMathLicensesSchool";
    public String FOCUS_READING_LICENSE_SCHOOL = "focusReadingLicensesSchool";

    //Status
    public String STATUS = "success";
}
