package com.savvas.sm.api.tests.smnew.assignments;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

public class SaveSCOStartTime extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String flexSchoolTeacherDetails = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String token = null;
    private String studentToken = null;
    String customCourseId = null;
    String orgID = null;
    String userID = null;
    private String assignmentID;
    private String AssignmentUserId;
    private String studentDetail = null;
    private String studentUserID = null;
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        orgID = RBSDataSetup.organizationIDs.get( flexSchool );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        userID = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, Constants.USERID_HEADER );
        studentDetail = RBSDataSetup.getMyStudent( flexSchool, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( priority = 1, dataProvider = "SaveSCO_PositiveScenarios", groups = { "SMK-51996", "save SCO start time api changes", "Assignments", "P1", "API", "smoke_test_case" } )
    public void saveSCOStartTimePositiveScenarios( String description, String scenario, String scenario1, String scenario2, String statusCode, String gradeId, String courseId, String contentBaseId, String standardFrmeworkId, String parentNode,
            String ChildNode, String catalogNum, String learningObject ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> courseDetails = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();

        // Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );
        studentTokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        //Create Custom course by standards
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, orgID );
        headers.put( Constants.USERID_SM_HEADER, userID );

        courseDetails.put( Constants.GRADE_VALUE, gradeId );
        courseDetails.put( Constants.STANDARD_FRAMEWORK_VALUE, standardFrmeworkId );
        courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
        courseDetails.put( CourseAPIConstants.PARENT_NODE, parentNode );
        courseDetails.put( CourseAPIConstants.CHILD_NODE, ChildNode );
        courseDetails.put( Constants.COURSE_NAME, "Skills" + System.nanoTime() );

        //Create custom course
        switch ( scenario1 ) {
            case "customByStandards":
                apiResponse = createCourseByStandard( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );

                customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                break;
            case "customBySkill":
                apiResponse = createCourseBySkill( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );

                customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                break;
            case "customBySettings":
                apiResponse = createCourseBySettings( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );

                customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                break;

        }

        //Assigning a newly created course to student
        List<String> studentRumbaIdsTc001 = new ArrayList<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> Response = new HashMap<>();

        //Adding students to group
        studentRumbaIdsTc001 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, token, flexSchool );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.CATALOG_NUM, catalogNum );
        assignmentDetails.put( AssignmentAPIConstants.LEARNING_OBJECT, learningObject );

        switch ( scenario2 ) {
            case "Default and Focus":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIdsTc001, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;

            case "custom":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, customCourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIdsTc001, AssignmentAPIConstants.USERS_TYPE );
                Log.message( Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                break;
        }

        HashMap<String, String> studentHeaders = new HashMap<>();
        studentHeaders.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        studentHeaders.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        studentHeaders.put( Constants.AUTHORIZATION, "Bearer " + studentToken );
        studentHeaders.put( Constants.ORGID_SM_HEADER, orgID );
        studentHeaders.put( Constants.USERID_SM_HEADER, studentUserID );

        apiResponse = saveSCO( smUrl, studentHeaders, assignmentDetails );
        Log.message( "Save API Changes : " + apiResponse );

        //Assertion

        Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    @Test ( priority = 1, dataProvider = "SaveSCO_NegativeScenarios", groups = { "SMK-51996", "save SCO start time api changes", "Assignemnts", "P1", "API" } )
    public void saveSCOStartTimeNegativeScenarios( String description, String scenario2, String statusCode, String courseId, String ChildNode, String catalogNum, String assignmentUserId ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();

        // Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );
        studentTokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        //Assigning a newly created course to student
        List<String> studentRumbaIdsTc001 = new ArrayList<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> Response = new HashMap<>();

        //Adding students to group
        studentRumbaIdsTc001 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, token, flexSchool );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.CATALOG_NUM, catalogNum );
        assignmentDetails.put( AssignmentAPIConstants.LEARNING_OBJECT, ChildNode );

        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIdsTc001, AssignmentAPIConstants.USERS_TYPE );
        Log.message( Response.get( "body" ) );
        assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
        AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
        assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );

        HashMap<String, String> invalidAssignmentDetails = new HashMap<>();
        HashMap<String, String> headersInvalidToken = new HashMap<>();

        HashMap<String, String> studentHeaders = new HashMap<>();
        studentHeaders.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        studentHeaders.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        studentHeaders.put( Constants.AUTHORIZATION, "Bearer " + studentToken );
        studentHeaders.put( Constants.ORGID_SM_HEADER, orgID );
        studentHeaders.put( Constants.USERID_SM_HEADER, studentUserID );

        switch ( scenario2 ) {

            case "invalid authorization":

                headersInvalidToken.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.AUTHORIZATION, "Bearer " + CourseAPIConstants.INVALID_AUTHORIZATION_ID );
                headersInvalidToken.put( Constants.ORGID_SM_HEADER, orgID );
                headersInvalidToken.put( Constants.USERID_SM_HEADER, studentUserID );

                apiResponse = saveSCO( smUrl, headersInvalidToken, assignmentDetails );
                Log.message( "Save API Changes : " + apiResponse );
                break;

            case "invalid org id":

                headersInvalidToken.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.AUTHORIZATION, "Bearer " + studentToken );
                headersInvalidToken.put( Constants.ORGID_SM_HEADER, CourseAPIConstants.INVALID_ORGANIZATION_ID );
                headersInvalidToken.put( Constants.USERID_SM_HEADER, studentUserID );

                apiResponse = saveSCO( smUrl, headersInvalidToken, assignmentDetails );
                Log.message( "Save API Changes : " + apiResponse );

                break;

            case "invalid assignment id":

                invalidAssignmentDetails.put( AssignmentAPIConstants.CATALOG_NUM, catalogNum );
                invalidAssignmentDetails.put( AssignmentAPIConstants.LEARNING_OBJECT, ChildNode );
                invalidAssignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId );

                apiResponse = saveSCO( smUrl, studentHeaders, invalidAssignmentDetails );
                Log.message( "Save API Changes : " + apiResponse );

                break;

            case "invalid catalogNum and learningObject":

                invalidAssignmentDetails.put( AssignmentAPIConstants.CATALOG_NUM, catalogNum );
                invalidAssignmentDetails.put( AssignmentAPIConstants.LEARNING_OBJECT, ChildNode );
                invalidAssignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );

                apiResponse = saveSCO( smUrl, studentHeaders, invalidAssignmentDetails );
                Log.message( "Save API Changes : " + apiResponse );

                break;
        }

        //Assertion
        Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    /**
     * Data provider for save SCO Start time api positive changes
     * 
     * @return
     */
    @DataProvider ( name = "SaveSCO_PositiveScenarios" )
    public Object[][] saveSCO_PositiveScenarios() {
        Object[][] inputData = {
                { "TC01_assignment which has been created from Default Reading.", "DEFAULTREADING", "No need to create custom course", "Default and Focus", "201", "1000000217", "2", "4", "1000000000", "1000000221", "smre_di_00063_1000000221",
                        "SMMA_LO_02153_S1", "SMMA_LO_02153" },
                { "TC18_assignment which has been created from Custom ReadingStandards", "DEFAULTREADING", "customByStandards", "custom", "201", "1000000217", "2", "4", "1000000000", "1000000221", "smre_di_00063_1000000221", "SMMA_TU_00098_S1",
                        "SMMA_TU_00098" },
                { "TC19_assignment which has been created from Custom ReadingSkills", "DEFAULTREADING", "customBySkill", "custom", "201", "3276", "2", "3", null, "4529", "smre_di_00057_4529", "SMMA_LO_02153_S1", "SMMA_LO_02153" },
                { "TC02_assignment which has been created from Custom ReadingSettings", "DEFAULTREADING", "customBySettings", "custom", "201", null, "2", "2", null, "4529", "smre_di_00057_4529", "SMMA_LO_02153_S1", "SMMA_LO_02153" },
                { "TC03_assignment which has been created from Focus Reading.", "READING", "No need to create custom course", "Default and Focus", "201", "596", "15", "4", "504", "598", "smre_di_00009_598", "SMMA_TU_00098_S1", "SMMA_TU_00098" },
                { "TC04_assignment which has been created from Custom Focus Reading.", "READING", "customByStandards", "custom", "201", "596", "15", "4", "504", "598", "smre_di_00009_598", "SMMA_LO_02153_S1", "SMMA_LO_02153" } };
        return inputData;
    }

    /**
     * Data provider Save SCO Start time api changes negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "SaveSCO_NegativeScenarios" )
    public Object[][] saveSCO_NegativeScenarios() {
        Object[][] inputData = { { "TC05_invalid authorization", "invalid authorization", "401", "2", "SMMA_TU_00098", "SMMA_TU_00098_S1", null }, { "TC06_invalid org id", "invalid org id", "403", "2", "SMMA_TU_00098", "SMMA_TU_00098_S1", null },
                { "TC08_invalid assignmentid : $$#", "invalid assignment id", "400", "2", "SMMA_TU_00098", "SMMA_TU_00098_S1", "$$#" },
                { "TC09_invalid assignment id : 1234", "invalid assignment id", "403", "2", "SMMA_TU_00098", "SMMA_TU_00098_S1", "1234" },
                { "TC10_invalid assignment id : null", "invalid assignment id", "403", "2", "SMMA_TU_00098", "SMMA_TU_00098_S1", "" }, { "TC14_invalid catalog num", "invalid catalogNum and learningObject", "500", "2", "SMMA_TU_00098", "s1", null },
                { "TC11_invalid catalog num", "invalid catalogNum and learningObject", "500", "2", "SMMA_TU_00098", "", null }, { "TC13_invalid learning object", "invalid catalogNum and learningObject", "500", "2", "abc", "SMMA_TU_00098_S1", null },
                { "TC12_invalid learning object", "invalid catalogNum and learningObject", "500", "2", "", "SMMA_TU_00098_S1", null }

        };
        return inputData;
    }

    //Token creation
    public void tokenCreation( String school ) {
        try {

            teacherDetails = flexSchoolTeacherDetails;

            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        } catch ( Exception e ) {
            Log.message( "Issue occured in tokenCreation" );
        }
    }

    //Token creation for Student login
    public void studentTokenCreation( String school ) {
        try {

            studentToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        } catch ( Exception e ) {
            Log.message( "Issue occured in tokenCreation" );
        }
    }

    /**
     * Get response for the Create Course By Standard API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseByStandard( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardReading" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.STANDARDFRAMEWORK_ID, courseDetails.get( Constants.STANDARD_FRAMEWORK_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

    /**
     * Get response for the Create Course By Skill API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySkill( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySkillsReading" ) ) );

            } else if ( scenario.contains( "DEFAULTMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySkillsMath" ) ) );
            } else if ( scenario.contains( "FOCUSMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusMath" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

    /**
     * Get response for the Create Course By Settings API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySettings( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySettingsReading" ) ) );

            } else if ( scenario.contains( "DEFAULTMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySettingsMath" ) ) );
            } else if ( scenario.contains( "FOCUSMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusMath" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

    //Adding Students to group
    public List<String> addStudentsToGroup( String statusCode, String userName, String school ) {
        HashMap<String, String> response;
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        try {
            //Adding students to group
            String groupName = "Successmaker API Test Group " + System.nanoTime();
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student3" ), "userId" ) );
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, userName );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            Log.message( "groupDetails is " + groupDetails );
            response = groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );
            Log.message( "response for group creation is " + response );
            Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        } catch ( Exception e ) {
            Log.message( "Issue occured in addStudentsToGroup" );
        }
        return studentRumbaIds;
    }

    /**
     * Get response for save SCO Start time api
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> saveSCO( String envUrl, HashMap<String, String> headers, HashMap<String, String> assignmentDetails ) {
        try {

            String endpoint = CourseAPIConstants.SAVE_SCO_START_TIME;
            Log.message( "Save SCO Start Time changes = " + endpoint );

            Log.message( "endpoint=" + envUrl + endpoint );

            AtomicReference<String> requestBody = new AtomicReference<>();

            requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "saveSCO_StartTime" ) ) );

            requestBody.set( requestBody.get().replace( AssignmentAPIConstants.ASSIGNMENT_USER_ID_PAYLOAD, assignmentDetails.get( AssignmentAPIConstants.ASSIGNMENT_USER_ID ) ) );
            requestBody.set( requestBody.get().replace( AssignmentAPIConstants.CATALOG_NUM_PAYLOAD, assignmentDetails.get( AssignmentAPIConstants.CATALOG_NUM ) ) );
            requestBody.set( requestBody.get().replace( AssignmentAPIConstants.LEARNING_OBJECT_PAYLOAD, assignmentDetails.get( AssignmentAPIConstants.LEARNING_OBJECT ) ) );

            Log.message( "payload : " + requestBody.get() );
            Log.message( headers.toString() );

            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in saveSCO method" );
            return null;
        }
    }
}