package com.savvas.sm.api.tests.smnew.groups;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.smnew.users.CreateStudentAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.CourseExecution;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentProgressGraphAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

/**
 * This class used to test the api for Group Usage for Graph
 * 
 * @author praveen.rangopi
 *
 */
public class GroupUsageAPI extends UserAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;
    private String teacherDetails = null;
    private String teacherDetails1 = null;
    private String teacherDetails2 = null;
    private String studentDetail = null;
    private String studentDetail1 = null;
    private String studentDetail2 = null;
//    private String studentDetail3 = null;
//    private String studentDetail4 = null;
    private String studentUsername = null;
    private String studentUserID = null;
    public Boolean result = null;
    int noOfIterationForMath = 1;
    int noOfIterationForReading = 1;
    private String teacherDetails3 = null;
    // private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String school1 = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    public String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public String accessToken;
    RBSUtils rbs = new RBSUtils();
    public String userId;
    public String userId1;
    public String userId2;
    public String orgId;
    public String orgId2;
    // public String orgId1;
    public String username;
    public String mathOnlyProduct;
    public String readingOnlyProduct;
    //public String courseID;
    public String studentID1;
    public String studentID2;
    public String classId;
    public String adminToken;
    public HashMap<String, String> assignmentDetails = new HashMap<>();
    public String createTeacher;
    public String multipleSchoolTeacherID;
    public String multipleSchoolTeacherName;
    public String multiOrgStuID;
    public String multiOrgStuUserName;
    HashMap<String, String> assignCourseToTheStudent = new HashMap<String, String>();

    public static String mathAssignmentName;
    public static String readingAssignmentName;
    public static String focusReadingAssignmentName;
    public static String focusMathAssignmentName;
    public static String skillMathAssignemntName;
    public static String skillReadingAssignemntName;
    public static String standardMathAssignemntName;
    public static String standardReadingAssignemntName;
    public static String settingsMathAssignmentName;
    public static String settingsReadingAssignmentName;
    GroupAPI gUsage = new GroupAPI();
    public static List<String> orgIDs = new ArrayList<String>();
    HashMap<String, String> studentId = new HashMap<>();
    HashMap<String, String> studentUserName = new HashMap<>();
    HashMap<String, String> classIds = new HashMap<>();
    CourseAPI coursesMethod = new CourseAPI();

    @BeforeClass ( alwaysRun = true )
    public void BeforeClass() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        mathOnlyProduct = configProperty.getProperty( "mathOnlyProduct" );
        readingOnlyProduct = configProperty.getProperty( "readingOnlyProduct" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherDetails1 = RBSDataSetup.getMyTeacher( school );
        teacherDetails2 = RBSDataSetup.getMyTeacher( school1 );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentDetail1 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        //studentDetail4 = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentDetail2 = RBSDataSetup.getMyStudent( school1, SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ) );
        //studentDetail3 = RBSDataSetup.getMyStudent( school1, SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ) );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );

        userId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        userId1 = SMUtils.getKeyValueFromResponse( teacherDetails1, Constants.USERID_HEADER );
        userId2 = SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USERID_HEADER );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );
        orgId = RBSDataSetup.organizationIDs.get( school );
        orgId2 = RBSDataSetup.organizationIDs.get( school1 );
        orgIDs.add( orgId );

        accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        List<String> teachers = new ArrayList<String>();
        List<String> stuIDs = new ArrayList<String>();
        List<String> courseIDs = new ArrayList<String>();
        List<String> schools = new ArrayList<String>();

        IntStream.rangeClosed( 1, 10 ).forEach( index -> {
            try {
                HashMap<String, String> studentDetails = new HashMap<>();
                studentDetails = new CreateStudentAPITest().generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
                studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, userId );
                studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                HashMap<String, String> stuDetails = createStudent( smUrl, studentDetails );
                String responseBody = SMUtils.getKeyValueFromResponse( stuDetails.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA );
                String studentUserId = SMUtils.getKeyValueFromResponse( responseBody, Constants.PERSONID );
                String studentUName = SMUtils.getKeyValueFromResponse( responseBody, RBSDataSetupConstants.USERNAME );
                stuIDs.add( studentUserId );
                studentId.put( Constants.STUDENT_ID + index, studentUserId );
                studentUserName.put( Constants.USER_NAME + index, studentUName );
                rbs.updateUserOrgId( rbs.getUser( studentUserId ), StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
            } catch ( Exception e ) {
                Log.fail( "Issue in Creating Student" );
            }

        } );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> classDetails = new HashMap<>();

        teachers.add( userId );

        courseIDs.add( AssignmentAPIConstants.MATH );
        courseIDs.add( AssignmentAPIConstants.READING );
        courseIDs.add( AssignmentAPIConstants.FOCUS_READING );
        courseIDs.add( AssignmentAPIConstants.FOCUS_MATH );
        courseIDs.add( coursesMethod.createCourse( smUrl, accessToken, DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) ) );
        courseIDs.add( coursesMethod.createCourse( smUrl, accessToken, DataSetupConstants.READING, userId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) ) );
        courseIDs.add( coursesMethod.createCourse( smUrl, accessToken, DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) ) );
        courseIDs.add( coursesMethod.createCourse( smUrl, accessToken, DataSetupConstants.READING, userId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) ) );
        courseIDs.add( coursesMethod.createCourse( smUrl, accessToken, DataSetupConstants.MATH, userId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) ) );
        courseIDs.add( coursesMethod.createCourse( smUrl, accessToken, DataSetupConstants.READING, userId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) ) );

        for ( int i = 1; i < 10; i++ ) {
            String className = "Test Class" + System.nanoTime();
            classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, userId );
            classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
            classDetails.put( CreateGroupAPIConstants.GROUP_NAME, className );

            classId = SMUtils.getKeyValueFromResponse( gUsage.createGroup( smUrl, classDetails, stuIDs ).get( Constants.BODY ), "data,groupId" );
            classIds.put( Constants.GROUP_ID + i, classId );
            adminToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        }

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

        HashMap<String, String> assignAssignment = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, stuIDs, courseIDs );
        JSONObject jsonObject1 = new JSONObject( assignAssignment.get( Constants.REPORT_BODY ) );
        JSONArray array4 = jsonObject1.getJSONArray( Constants.REPORT_BODY_DATA );

        mathAssignmentName = array4.getJSONObject( 0 ).get( Constants.ASSIGNMENT_NAME ).toString();
        readingAssignmentName = array4.getJSONObject( 1 ).get( Constants.ASSIGNMENT_NAME ).toString();
        focusReadingAssignmentName = array4.getJSONObject( 2 ).get( Constants.ASSIGNMENT_NAME ).toString();
        focusMathAssignmentName = array4.getJSONObject( 3 ).get( Constants.ASSIGNMENT_NAME ).toString();
        settingsMathAssignmentName = array4.getJSONObject( 4 ).get( Constants.ASSIGNMENT_NAME ).toString();
        settingsReadingAssignmentName = array4.getJSONObject( 5 ).get( Constants.ASSIGNMENT_NAME ).toString();
        skillMathAssignemntName = array4.getJSONObject( 6 ).get( Constants.ASSIGNMENT_NAME ).toString();
        skillReadingAssignemntName = array4.getJSONObject( 7 ).get( Constants.ASSIGNMENT_NAME ).toString();
        standardMathAssignemntName = array4.getJSONObject( 8 ).get( Constants.ASSIGNMENT_NAME ).toString();
        standardReadingAssignemntName = array4.getJSONObject( 9 ).get( Constants.ASSIGNMENT_NAME ).toString();

    }

    @Test ( priority = 1, dataProvider = "ValidCases", groups = { "smoke_test_case", "SmokeGroupUsage001", "GroupUsage", "SMK-52033", "Groups", "GroupsUsage", "P1", "API" } )
    public void tcGroupsUsage001( String description, String scenario, String statusCode ) throws Exception {
        Log.message( description );
        
        String userDetails;
        //String accessToken;

        switch ( scenario ) {

            case "GROUP_WITH_MATH_ASSIGNMENT":
                HashMap<String, String> response;
                HashMap<String, String> groupDetails = new HashMap<>();

                String accessToken1 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails = rbs.getUser( studentId.get( Constants.STUDENT_ID + 1 ) );
                rbs.updateUserOrgId( userDetails, StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
                if ( noOfIterationForMath <= 1 ) {
//                    executeCourse( studentUserName.get( Constants.USER_NAME + 1 ), Constants.MATH, "3", "30", Constants.MATH );
                    new CourseExecution().executeCourse( studentUserName.get( Constants.USER_NAME + 1 ), Constants.MATH, true, "25", "3", "30" );
                    noOfIterationForMath++;
                }
                groupDetails.put( GroupConstants.STAFF_ID, userId );
                groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                groupDetails.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 1 ) );
                response = gUsage.getGroupUsage( smUrl, groupDetails );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "groupUsage", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

            case "GROUP_WITH_READING_ASSIGNMENT":
                HashMap<String, String> response1;
                HashMap<String, String> groupDetails2 = new HashMap<>();

                String accessToken2 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails = rbs.getUser( studentId.get( Constants.STUDENT_ID + 2 ) );
                rbs.updateUserOrgId( userDetails, StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
                if ( noOfIterationForReading <= 1 ) {
//                    executeCourse( studentUserName.get( Constants.USER_NAME + 2 ), Constants.READING, "3", "30", Constants.READING );
                    new CourseExecution().executeCourse( studentUserName.get( Constants.USER_NAME + 2 ), Constants.READING, true, "25", "3", "30" );
                    noOfIterationForReading++;
                }
                groupDetails2.put( GroupConstants.STAFF_ID, userId );
                groupDetails2.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails2.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken2 );
                groupDetails2.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 2 ) );

                response1 = gUsage.getGroupUsage( smUrl, groupDetails2 );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "groupUsage", statusCode, response1.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

            case "GROUP_WITH_MATH_FOCUS_COURSE":
                HashMap<String, String> response2;
                HashMap<String, String> groupDetails3 = new HashMap<>();

                String accessToken3 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails = rbs.getUser( studentId.get( Constants.STUDENT_ID + 3 ) );
                rbs.updateUserOrgId( userDetails, StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
//                executeCourse( studentUserName.get( Constants.USER_NAME + 3 ), focusMathAssignmentName, "3", "30", Constants.MATH );
                new CourseExecution().executeCourse( studentUserName.get( Constants.USER_NAME + 3 ), focusMathAssignmentName, true, "25", "3", "30" );
                groupDetails3.put( GroupConstants.STAFF_ID, userId );
                groupDetails3.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails3.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken3 );
                groupDetails3.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 3 ) );

                response2 = gUsage.getGroupUsage( smUrl, groupDetails3 );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "groupUsage", statusCode, response2.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

            case "GROUP_WITH_READING_FOCUS_COURSE":
                HashMap<String, String> response3;
                HashMap<String, String> groupDetails4 = new HashMap<>();

                String accessToken4 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails = rbs.getUser( studentId.get( Constants.STUDENT_ID + 4 ) );
                rbs.updateUserOrgId( userDetails, StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
//                executeCourse( studentUserName.get( Constants.USER_NAME + 4 ), focusReadingAssignmentName, "3", "30", Constants.READING );
                new CourseExecution().executeCourse( studentUserName.get( Constants.USER_NAME + 4 ),focusReadingAssignmentName, false, "25", "3", "30" );
                groupDetails4.put( GroupConstants.STAFF_ID, userId );
                groupDetails4.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails4.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken4 );
                groupDetails4.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 4 ) );

                response3 = gUsage.getGroupUsage( smUrl, groupDetails4 );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "groupUsage", statusCode, response3.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

            case "GROUP_WITH_CUSTOM_SETTING_MATH":
                HashMap<String, String> response4;
                HashMap<String, String> groupDetails5 = new HashMap<>();

               String accessToken5 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails = rbs.getUser( studentId.get( Constants.STUDENT_ID + 5 ) );
                rbs.updateUserOrgId( userDetails, StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
//                executeCourse( studentUserName.get( Constants.USER_NAME + 5 ), settingsMathAssignmentName, "3", "30", Constants.MATH );
                new CourseExecution().executeCourse( studentUserName.get( Constants.USER_NAME + 5 ), settingsMathAssignmentName, true, "25", "3", "30" );
                groupDetails5.put( GroupConstants.STAFF_ID, userId );
                groupDetails5.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails5.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken5 );
                groupDetails5.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 5 ) );

                response4 = gUsage.getGroupUsage( smUrl, groupDetails5 );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "groupUsage", statusCode, response4.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

            case "GROUP_WITH_CUSTOM_SETTING_READING":
                HashMap<String, String> response5;
                HashMap<String, String> groupDetails6 = new HashMap<>();

               String accessToken6 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails = rbs.getUser( studentId.get( Constants.STUDENT_ID + 6 ) );
                rbs.updateUserOrgId( userDetails, StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
//                executeCourse( studentUserName.get( Constants.USER_NAME + 6 ), settingsReadingAssignmentName, "3", "30", Constants.READING );
                new CourseExecution().executeCourse( studentUserName.get( Constants.USER_NAME + 6 ), settingsReadingAssignmentName, false, "25", "3", "30" );
                groupDetails6.put( GroupConstants.STAFF_ID, userId );
                groupDetails6.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails6.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken6 );
                groupDetails6.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 6 ) );

                response5 = gUsage.getGroupUsage( smUrl, groupDetails6 );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "groupUsage", statusCode, response5.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

            case "GROUP_WITH_CUSTOM_SKILL_MATH":
                HashMap<String, String> response6;
                HashMap<String, String> groupDetails7 = new HashMap<>();

               String accessToken7 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails = rbs.getUser( studentId.get( Constants.STUDENT_ID + 7 ) );
                rbs.updateUserOrgId( userDetails, StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
//                executeCourse( studentUserName.get( Constants.USER_NAME + 7 ), skillMathAssignemntName, "3", "30", Constants.MATH );
                new CourseExecution().executeCourse( studentUserName.get( Constants.USER_NAME + 7 ), skillMathAssignemntName, true, "25", "3", "30" );
                groupDetails7.put( GroupConstants.STAFF_ID, userId );
                groupDetails7.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails7.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken7 );
                groupDetails7.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 7 ) );

                response6 = gUsage.getGroupUsage( smUrl, groupDetails7 );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "groupUsage", statusCode, response6.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

            case "GROUP_WITH_CUSTOM_SKILL_READING":
                HashMap<String, String> response7;
                HashMap<String, String> groupDetails8 = new HashMap<>();

                String accessToken8 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails = rbs.getUser( studentId.get( Constants.STUDENT_ID + 8 ) );
                rbs.updateUserOrgId( userDetails, StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
//                executeCourse( studentUserName.get( Constants.USER_NAME + 8 ), skillReadingAssignemntName, "3", "30", Constants.READING );
                new CourseExecution().executeCourse( studentUserName.get( Constants.USER_NAME + 8 ), skillReadingAssignemntName, false, "25", "3", "30" );
                groupDetails8.put( GroupConstants.STAFF_ID, userId );
                groupDetails8.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails8.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken8 );
                groupDetails8.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 8 ) );

                response7 = gUsage.getGroupUsage( smUrl, groupDetails8 );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "groupUsage", statusCode, response7.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

            case "GROUP_WITH_CUSTOM_STANDARD_MATH":
                HashMap<String, String> response8;
                HashMap<String, String> groupDetails9 = new HashMap<>();

               String accessToken9 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails = rbs.getUser( studentId.get( Constants.STUDENT_ID + 9 ) );
                rbs.updateUserOrgId( userDetails, StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
//                executeCourse( studentUserName.get( Constants.USER_NAME + 9 ), standardMathAssignemntName, "3", "30", Constants.MATH );
                new CourseExecution().executeCourse( studentUserName.get( Constants.USER_NAME + 9 ), standardMathAssignemntName, true, "25", "3", "30" );
                groupDetails9.put( GroupConstants.STAFF_ID, userId );
                groupDetails9.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails9.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken9 );
                groupDetails9.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 9 ) );

                response8 = gUsage.getGroupUsage( smUrl, groupDetails9 );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "groupUsage", statusCode, response8.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

            case "GROUP_WITH_CUSTOM_STANDARD_READING":
                HashMap<String, String> response9;
                HashMap<String, String> groupDetails10 = new HashMap<>();

                String accessToken10 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails = rbs.getUser( studentId.get( Constants.STUDENT_ID + 10 ) );
                rbs.updateUserOrgId( userDetails, StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
//                executeCourse( studentUserName.get( Constants.USER_NAME + 10 ), standardReadingAssignemntName, "3", "30", Constants.READING );
                new CourseExecution().executeCourse( studentUserName.get( Constants.USER_NAME + 10 ), standardReadingAssignemntName, false, "25", "3", "30" );
                groupDetails10.put( GroupConstants.STAFF_ID, userId );
                groupDetails10.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails10.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken10 );
                groupDetails10.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 10 ) );

                response9 = gUsage.getGroupUsage( smUrl, groupDetails10 );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "groupUsage", statusCode, response9.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;

        }
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */

    @DataProvider ( name = "ValidCases" )
    public Object[][] tcGroupsUsage() {

        Object[][] data = { { "Verify the status code is 200 appears when group mapped with math assignment alone", "GROUP_WITH_MATH_ASSIGNMENT", "200" },
                { "Verify the status code is 200 for groups usage with valid data", "GROUP_WITH_MATH_ASSIGNMENT", "200" }, { "Verify the response body should return last week field", "GROUP_WITH_MATH_ASSIGNMENT", "200" },
                { "Verify the response body should return this week field", "GROUP_WITH_MATH_ASSIGNMENT", "200" }, { "Verify the response body should return total minutes field", "GROUP_WITH_MATH_ASSIGNMENT", "200" },
                { "Verify the status code is 200 appears when group mapped with reading assignment alone", "GROUP_WITH_READING_ASSIGNMENT", "200" },
                { "Verify the response body should return along with reading field for group usage", "GROUP_WITH_READING_ASSIGNMENT", "200" },
                { "Verify the response body should return along with math field for group usage", "GROUP_WITH_READING_ASSIGNMENT", "200" },
                { "Verify the status code is 200 appears when group mapped with focus course for math assignment", "GROUP_WITH_MATH_FOCUS_COURSE", "200" },
                { "Verify the status code is 200 appears when group mapped with focus course for reading assignment", "GROUP_WITH_READING_FOCUS_COURSE", "200" },
                { "Verify the status code is 200 appears when group mapped with custom by settings for math assignment", "GROUP_WITH_CUSTOM_SETTING_MATH", "200" },
                { "Verify the status code is 200 appears when group mapped with custom by settings for reading assignment", "GROUP_WITH_CUSTOM_SETTING_READING", "200" },
                { "Verify the status code is 200 appears when group mapped with custom by skill for math assignment", "GROUP_WITH_CUSTOM_SKILL_MATH", "200" },
                { "Verify the status code is 200 appears when group mapped with custom by skill for reading assignment", "GROUP_WITH_CUSTOM_SKILL_READING", "200" },
                { "Verify the status code is 200 appears when group mapped with custom by standard for math assignment", "GROUP_WITH_CUSTOM_STANDARD_MATH", "200" },
                { "Verify the status code is 200 appears when group mapped with custom by standard for reading assignment", "GROUP_WITH_CUSTOM_STANDARD_READING", "200" } };
        return data;
    }

    @Test ( priority = 1, dataProvider = "InValidCases", groups = { "SMK-52033", "Groups", "GroupsUsage", "P1", "API" } )
    public void tcGroupsUsage002( String description, String scenario, String statusCode ) throws Exception {
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> response;
        String errorMessage = null;
        String exceptionMessage = null;
        switch ( scenario ) {

            case "DELETED_GROUP":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.GROUP_USAGE_NOT_FOUND_MESSAGE;
                exceptionMessage = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                groupDetails.put( GroupConstants.STAFF_ID, userId );
                groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                groupDetails.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 1 ) );
                rbs.deleteClass( classIds.get( Constants.GROUP_ID + 1 ), accessToken, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                break;

            case "INVALID_GROUP_ID":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.GROUP_USAGE_NOT_FOUND_MESSAGE;
                exceptionMessage = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                groupDetails.put( GroupConstants.STAFF_ID, userId );
                groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                groupDetails.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 2 ) + 1 );

                break;

            case "INVALID_AUTH":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exceptionMessage = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                groupDetails.put( GroupConstants.STAFF_ID, userId );
                groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken + 1 );
                groupDetails.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 2 ) );

                break;

            case "INVALID_ORG_ID":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.INVALID_ORG_PARTIAL_ERROR_MESSAGE;
                exceptionMessage = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                groupDetails.put( GroupConstants.STAFF_ID, userId );
                groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( GroupConstants.INVALID_ORG, orgId + 1 );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                groupDetails.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 2 ) );

                break;

            case "INVALID_STAFF_ID":
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.USER_ID_MISMATCH_MESSAGE;
                exceptionMessage = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                groupDetails.put( GroupConstants.STAFF_ID, userId );
                groupDetails.put( GroupConstants.INVALID_TEACHER, userId + 1 );
                groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                groupDetails.put( GroupConstants.GROUP_ID, classIds.get( Constants.GROUP_ID + 2 ) );

                break;

        }
        response = gUsage.getGroupUsage( smUrl, groupDetails );
        Log.message( response.toString() );
        Log.assertThat( validateErrorANDExceptionMessage( response, errorMessage, exceptionMessage, statusCode ), "Error Message and Exception Validated Successfully", "Error Message Not returned as expected" );
    }

    /**
     * Data provider for Negative scenarios
     * 
     * @return
     */
    //    https://jira.savvasdev.com/browse/SMK-57426 - For invalid Group ID Not receiving proper Error Message
    @DataProvider ( name = "InValidCases" )
    public Object[][] tcGroupsUsagegraph() {

        Object[][] data = { { "Verify the status code ,when group is deleted", "DELETED_GROUP", "200" }, { "Verify the response for invalid Group id", "INVALID_GROUP_ID", "400" }, { "Verify the status code for Invalid Auth", "INVALID_AUTH", "401" },
                { "Verify the response for invalid Org Id", "INVALID_ORG_ID", "400" }, { "Verify the response for invalid teacher id", "INVALID_STAFF_ID", "400" } };
        return data;
    }

    // To Execute Course
    public void executeCourse( String studentUserName, String courseName, String numberOfSessions, String numberOfQuestions, String courseNames ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
        if ( courseNames.equals( Constants.MATH ) ) {
            studentsPage.executeMathCourse( studentUserName, courseName, "25", numberOfSessions, numberOfQuestions );
        } else {
            studentsPage.executeReadingCourse( studentUserName, courseName, "25", numberOfSessions, numberOfQuestions );
        }
        studentsPage.logout();
        driver.close();
    }

    // Validating the Error Message and Exception
    public Boolean validateErrorANDExceptionMessage( HashMap<String, String> response, String errorMessage, String exceptionMessage, String statusCode ) {
        Boolean status = false;
        JSONObject jsonObject = new JSONObject( response.get( Constants.REPORT_BODY ) );
        JSONArray array4 = jsonObject.getJSONArray( Constants.REPORT_MESSAGES );
        String exception = array4.getJSONObject( 0 ).get( Constants.EXCEPTION ).toString();
        String message = array4.getJSONObject( 0 ).get( Constants.REPORT_MESSAGE_VALUE ).toString();
        if ( exception.equals( exceptionMessage ) && message.contains( errorMessage ) && response.get( Constants.STATUS_CODE ).equals( statusCode ) ) {
            status = true;
        }
        return status;
    }

}
