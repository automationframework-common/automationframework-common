package com.savvas.sm.ui.tests.MasteryTest;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.ui.pages.MasteryMfePage;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

public class MasteryMfeAdminTest extends BaseTest {
    private String masteryAdminSingleMfeUrl;
    private String masteryAdminMultiMfeUrl;
    private String browser;

    @BeforeClass
    public void initTest( ITestContext context ) {
        masteryAdminSingleMfeUrl = configProperty.getProperty( "MasteryAdminSingleMfe" );
        masteryAdminMultiMfeUrl = configProperty.getProperty( "MasteryAdminMultiMfe" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
    }

    @Test ( priority = 1, groups = { "SMK-51121", "mastery_mfe_admin", "P1", "UI" } )
    public void tcMasteryMfeAdminSingle( ITestContext context ) throws Exception {
        //        // Get driver
        WebDriver selDriver = WebDriverFactory.get( browser );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( selDriver );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "Mastery Mfe Admin Test" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // TC_ 1
            SMUtils.logDescriptionTC( "1.Verify the 'Mastery' title in the mastery filter component" );
            MasteryMfePage masteryMfePage = LoginWrapper.loginToMasteryMfe( driver, masteryAdminSingleMfeUrl, LoginConstants.ADMIN_USER.ADMIN_USER_NAME, LoginConstants.ADMIN_USER.ADMIN_PASSWORD );
            Log.assertThat( masteryMfePage.getMasteryHeading().equals( MasteryConstants.Labels.MASTERY_HEADING ), "Mastery Heading is displayed", "Mastery Heading is not displayed" );

            // TC_2    
            SMUtils.logDescriptionTC( "2.Verify 'Help' icon is getting displayed" );
            Log.assertThat( masteryMfePage.isHelpIconDisplayed(), "Help icon is displayed", "Help icon is not displayed" );

            // TC_4
            SMUtils.logDescriptionTC( " 4.Verify 'STEP2: Refine Search' label is not getting displayed before the subject dropdown when 'Select an Organization' dropdown is not available" );
            Log.assertThat( !masteryMfePage.isMasteryStep2HeadingDisplayed(), "STEP2: Refine Search is not displayed for single-admin type", "STEP2: Refine Search is displayed for single-admin type" );

            // open mastery view of Admin-Multi
            driver.get( masteryAdminMultiMfeUrl );

            // TC_5
            SMUtils.logDescriptionTC( "5.Verify 'STEP2: Refine Search' label is getting displayed before the subject dropdown when 'Select an Organization' dropdown is displayed" );
            masteryMfePage = new MasteryMfePage( driver ).get();
            Log.assertThat( masteryMfePage.isMasteryStep2HeadingDisplayed(), "STEP2: Refine Search is displayed for multi-admin type", "STEP2: Refine Search is not displayed for multi-admin type" );

            // TC_3 
            if ( !( configProperty.getProperty( "BrowserPlatformToRun" ).toLowerCase().contains( "safari" ) ) ) {
                SMUtils.logDescriptionTC( "3.Verify help content is opened in new tab after clicking the 'Help' icon" );
                Log.assertThat( masteryMfePage.isHelpPageOpensInNewTab( driver ), "Help page opened in a new tab", "Help page doesn't opened in a new tab" );
            }
            // TC_6
            SMUtils.logDescriptionTC( "6.Verify Filter component is collapsed after clicking the 'Apply Filter'button" );
            masteryMfePage.getMasteryFilterComponent().applyFilter();
            Log.assertThat( !masteryMfePage.getMasteryFilterComponent().isApplyFilterButtonPresent(), "Mastery Filter section collapses after clicking on Apply filter button",
                    "Mastery Filter section is not collapsed after clicking on Apply filter button!" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
