package com.savvas.sm.api.tests.smnew.report;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.ReportAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class LoadSaveReport extends EnvProperties {
    private String smUrl;
    private Map<String, String> response;
    private Map<String, String> postResponse;
    private String school;
    private String teacherDetails;
    private String userID;
    private String teacherUsername;
    private String password;
    private String orgID;
    String districtID;
    HashMap<String, String> headers = new HashMap<>();
    HashMap<String, String> params = new HashMap<>();
    String authorization = "Basic YWRtaW50ZXN0OnRlc3Q=";

    String requestID = "";

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        userID = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        districtID = configProperty.getProperty( "district_ID" );
        // Getting ORGID of Flex school
        orgID = RBSDataSetup.organizationIDs.get( school );

        // smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        String request = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "GetSaveReport.json" );
        request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
        request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
        request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
        request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
        request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );

        //Saving a report by POST API call
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        headers.put( ReportAPIConstants.AUTHORISATION, authorization );
        headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
        headers.put( ReportAPIConstants.USERID_HEADER, userID );
        headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
        String postEndPoint = ReportAPIConstants.POST_SAVE_REPORT;
        postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );

        //To get request ID from post call response
        requestID = SMUtils.getKeyValueFromResponse( postResponse.get( Constants.REPORT_BODY ), "requestId" );

    }

    @Test ( dataProvider = "getDataForSaveReportScenarios", groups = { "smoke_test_case", "Smoke getSaveReportTest", "Save Report", "P1", "SMK-58182", "Java API for save report", "API" }, priority = 1 )
    public void getSaveReportTest( String testcaseName, String statusCode, String testcaseDescription, String reporttype, String scenarioType ) throws Exception {

        Log.testCaseInfo( testcaseName + testcaseDescription );

        //Get Save Report End Point
        String getSaveReportEndPoint = ReportAPIConstants.GET_SAVE_REPORT;

        switch ( scenarioType ) {
            case "VALID_REQUEST_ID":

                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                getSaveReportEndPoint = getSaveReportEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.GET( smUrl, getSaveReportEndPoint, headers, params );

                Log.message( response.get( Constants.RESPONSE_BODY ).toString() );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "Load_Report", statusCode, response.get( Constants.RESPONSE_BODY ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );

                break;
            case "INVALID_REQUEST_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

                String inValidRequestID = getRandomNumber();
                getSaveReportEndPoint = getSaveReportEndPoint.replace( ReportAPIConstants.REQUESTID, inValidRequestID );
                response = RestHttpClientUtil.GET( smUrl, getSaveReportEndPoint, headers, params );
                break;
            case "INVALID_AUTHORIZATION_ID":
                String invalidAuthorization = authorization + getRandomNumber();

                headers.put( ReportAPIConstants.AUTHORISATION, invalidAuthorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                getSaveReportEndPoint = getSaveReportEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.GET( smUrl, getSaveReportEndPoint, headers, params );
                break;
            case "INVALID_TEACHER/USER_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                String invalidUserID = userID + getRandomNumber();
                headers.put( ReportAPIConstants.USERID_HEADER, invalidUserID );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                getSaveReportEndPoint = getSaveReportEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.GET( smUrl, getSaveReportEndPoint, headers, params );
                break;
            case "INVALID_ORG_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                String invalidOrgID = orgID + getRandomNumber();
                headers.put( ReportAPIConstants.ORGID_HEADER, invalidOrgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                getSaveReportEndPoint = getSaveReportEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.GET( smUrl, getSaveReportEndPoint, headers, params );
                break;
            case "EMPTY_REQUEST_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

                getSaveReportEndPoint = getSaveReportEndPoint.replace( ReportAPIConstants.REQUESTID, "" );

                response = RestHttpClientUtil.GET( smUrl, getSaveReportEndPoint, headers, params );
                break;

            case "EMPTY_TEACHER_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, "" );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                getSaveReportEndPoint = getSaveReportEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.GET( smUrl, getSaveReportEndPoint, headers, params );
                break;
            case "EMPTY_ORG_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, "" );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                getSaveReportEndPoint = getSaveReportEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.GET( smUrl, getSaveReportEndPoint, headers, params );
                break;

        }
        Log.message( response.get( Constants.RESPONSE_BODY ).toString() );
        // Validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.testCaseResult();
        Log.endTestCase();
    }

    public String getRandomNumber() {
        Random random = new Random();
        int randomNumber = random.nextInt( 1000 );
        String generatedRandomNumber = Integer.toString( randomNumber );
        return generatedRandomNumber;
    }

    @DataProvider
    public Object[][] getDataForSaveReportScenarios() {
        Object[][] data = { { "TC001", "200", "TC01_Verify status code is 200 when valid Request ID is given for GET API", "LS", "VALID_REQUEST_ID" },
                { "TC002", "400", "TC02_Verify status code is 400 when Invalid Request ID is given", "LS", "INVALID_REQUEST_ID" },
                { "TC003", "401", "TC03_Verify status code is 401 when Invalid/Expired Authorization is given", "LS", "INVALID_AUTHORIZATION_ID" },
                { "TC004", "401", "TC04_Verify status code is 401 when different User/Teacher ID is given", "LS", "INVALID_TEACHER_ID" }, { "TC005", "200", "TC05_Verify status code is 200 when Invalid Org ID is given", "LS", "INVALID_ORG_ID" },
                { "TC006", "200", "TC06_Verify status code is 200 when empty Request ID is given", "LS", "EMPTY_REQUEST_ID" }, { "TC007", "400", "TC07_Verify status code is 400 when Empty/Null User/Teacher ID is given", "LS", "EMPTY_TEACHER_ID" },
                { "TC008", "200", "TC08_Verify status code is 200 when Empty/Null Org ID is given", "LS", "EMPTY_ORG_ID" }

        };

        return data;
    }

    @Test ( dataProvider = "getDataForSaveReportScenariosNegative", groups = {  "getSaveReportTest", "Save Report", "P1", "SMK-58182", "Java API for save report", "API" }, priority = 1 )
    public void getDataForSaveReportScenariosNegative( String testcaseName, String statusCode, String testcaseDescription, String reporttype, String scenarioType ) throws Exception {

        Log.testCaseInfo( testcaseName + testcaseDescription );

        //Get Save Report End Point
        String getSaveReportEndPoint = ReportAPIConstants.GET_SAVE_REPORT;

        switch ( scenarioType ) {

            case "EMPTY_DISTRICT_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( ReportAPIConstants.districtId, "" );

                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                getSaveReportEndPoint = getSaveReportEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.GET( smUrl, getSaveReportEndPoint, headers, params );
                break;
            case "DIFFERENT_DISTRICT_ID":

                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( ReportAPIConstants.districtId, ReportAPIConstants.differentDistrictID );

                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                getSaveReportEndPoint = getSaveReportEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.GET( smUrl, getSaveReportEndPoint, headers, params );
                break;

            case "INVALID_DISTRICT_ID":

                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                String invalidDistrictID = districtID + getRandomNumber();
                headers.put( ReportAPIConstants.districtId, invalidDistrictID );

                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                getSaveReportEndPoint = getSaveReportEndPoint.replace( ReportAPIConstants.REQUESTID, requestID );
                response = RestHttpClientUtil.GET( smUrl, getSaveReportEndPoint, headers, params );

                break;

        }
        Log.message( response.get( Constants.RESPONSE_BODY ).toString() );
        // Validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataForSaveReportScenariosNegative() {
        Object[][] data = { { "TC009", "403", "TC09_Verify status code is 403 when empty DISTRICT ID is given", "LS", "EMPTY_DISTRICT_ID" },
                { "TC010", "400", "TC10_Verify status code is 400 when different DISTRICT ID is given", "LS", "DIFFERENT_DISTRICT_ID" }, { "TC011", "400", "TC11_Verify status code is 400 when invalid DISTRICT ID is given", "LS", "INVALID_DISTRICT_ID" },

        };
        return data;
    }

}
