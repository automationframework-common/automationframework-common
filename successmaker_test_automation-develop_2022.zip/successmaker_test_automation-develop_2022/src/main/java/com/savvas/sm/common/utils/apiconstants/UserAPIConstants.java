package com.savvas.sm.common.utils.apiconstants;

import java.util.ArrayList;
import java.util.Arrays;

public interface UserAPIConstants {
    public static String ORGID = "org-id";
    public static String USERID = "user-id";
    public static String AUTHORIZATION = "Authorization";
    public static String BEARER = "Bearer ";
    public static String INVALID_USER_ID = "XXX";
    public static String ORG_LIST = "org-list";

    public static String STAFFID = "staffId";
    public static String MESSAGE = "message";

    public interface GetUserDetailsUsingUserServiceAPIConstants {

        public static String GET_USER_DETAILS = "/lms/web/api/v1/users/user-id";

        public static String FIRSTNAME_FIELD = "firstName";
        public static String LASTNAME_FIELD = "lastName";
        public static String MIDDLENAME_FIELD = "middleName";
        public static String USERNAME_FIELD = "userName";

        public static String PERSONID_FIELD = "personId";
        public static String USERID_FIELD = "userId";
        public static String PASSWORD_FIELD = "password";
        public static String GRADENAME_FIELD = "gradeName";
        public static String STUDENTID_FIELD = "studentId";
        public static String TITLE_FIELD = "title";
        public static String ORGANIZATIONID_FIELD = "organizationId";
        public static String EMAILID_FIELD = "email";
        public static String EMAIL_INFO_FIELD = "emailInfo";
        public static String EMAIL_ADDRESS_FIELD = "emailAddress";
        public static String GENDER_FIELD = "gender";
        public static String BODY_FIELD = "body";
        public static String GENDER_DATAVALUE = "data,gender";
        public static String ORGANIZATIONID_DATAVALUE = "data,organizationId";
        public static String NOT_SPECIFIED = "NOT_SPECIFIED";
        public static String AFFILIATION = "affiliations";
        public static String TITLE_NAME = "titleName";
        public static String SPCL_CHARACTER_USER_EMAIL_ID = "autoTesting@savvas.com";
        public static String INVALID_STRING = "abcd";
        public static String SPCL_CHARACTER_USER_ORG_ID = "8a7202057e780784017e7af013210013";
        public static String PRIMARY_ORGANIZATIONID_FIELD = "primaryOrgId";
        public static String INVALID_GET_USER_DETAILS = "/lms/web/api/v1/usersss/user-id";
        public static String FIRSTNAME_DATAVALUE = "data,firstName";
        public static String LASTNAME_DATAVALUE = "data,lastName";
        public static String USERNAME_DATAVALUE = "data,userName";
        public static String PERSONID_DATAVALUE = "data,personId";
        public static String EMAIL_DATAVALUE = "data,email";
        // Auto user details 
        public static String AUTO_USER_USER_ID = "ffffffff61d41c8f6e4125002f230dfc";
        public static String AUTO_USER_ORG_ID = "8a7200f77de565ac017e248148670654";

    }

    public interface UpdateStaffProfileAPIConstants {
        public static String NEW_PASSWORD_FIELD = "userPassword";
        public static String CHANGE_PASSWORD_FIELD = "changePassword";
        public static String NEW_PASSWORD = "password123$";
        public static String FALSE = "false";
        public static String TRUE = "true";
        public static String SPCL_CHARACTER_STRING = "$@#%ab";
        public static String EMPTY_STRING = "";
        public static String CHARACTER_STRING = "ABCD";
        public static String NUMERIC_STRING = "12345";
        public static String DR_TITLE = "DR";
        public static String MR_TITLE = "MR";
        public static String MRS_TITLE = "MRS";
        public static String MS_TITLE = "MS";
        public static String MISS_TITLE = "MISS";
        public static String FIRSTNAME_DATAVALUE = "data,firstName";
        public static String LASTNAME_DATAVALUE = "data,lastName";
        public static String UPDATE_STAFF_PROFILE_SCHEMA = "UpdateStaffProfileSchema";
        public static String SUCCESS_MESSAGE = "Your changes have been saved.";

    }

    public interface CreateStudentAPIConstants {
        public static String CREATE_STUDENT_ENDPOINT = "/lms/web/api/v1/students";
        public static String TEACHER_ID = "teacherId";
        public static String GRADE = "grade";
        public static String MIDDLE_NAME =  "middleName";
        public static String BIRTHDAY = "birthday";
        public static String STUDENT_IDENTIFICATION_NUMBER = "studentIdentificationNumber";
        public static String USER_PASSWORD = "userPassword";
        public static String CONFIRM_PASSWORD = "confirmPassword";
        public static String ETHINICITY = "ethnicity";
        public static String SPECIAL_SERVICES = "specialServices";
        public static String HAS_DISABILITY = "hasDisability";
        public static String HAS_ECONOMIC_DISADVANTAGE = "hasEconomicDisadvantage";
        public static String HAS_ENGLISH_PROFICIENCY = "hasEnglishProficiency";
        public static String ISMIGRANT = "isMigrant";
        public static String SCHOOLID = "schoolId";
        public static String PERSONID = "personId";
        public static String MORETHEN_75_CHARACTERS = "SuccessMaker75CharacterStudentSuccessMaker75CharacterStudent1111132423432234";
        public static String GOOGLE_TEACHER_ID = "ffffffff62669a5618146a002fd52dd6";
        public static String GOOGLE_SCHOOL_ORG_ID = "8a72019a7f90ca06017fd05d12f01ab2";
        public static String GOOGLE_USERNAME = "demo_gc_teacher01";

        public static ArrayList<String> GRADE_CODES_CMS = new ArrayList<String>( Arrays.asList( "KG", "G01", "G02", "G03", "G04", "G05", "G06", "G07", "G08", "G09", "G10", "G11", "G12" ) );

        public static enum grade {
            K,
            FIRST,
            SECOND,
            THIRD,
            FOURTH,
            FIFTH,
            SIXTH,
            SEVENTH,
            EIGHT,
            NINTH,
            TENTH,
            ELEVENTH,
            TWELVETH
        }

        //updated ethnicity value as part of SMK-57721
        public static enum ethnicity {
            HISPANIC_OR_LATINO,
            NOT_HISPANIC_OR_LATINO,
            NOT_SPECIFIED
        }

        public static enum race {
            WHITE,
            BLACK_OR_AFRICAN_AMERICAN,
            ASIAN,
            AMERICAN_NATIVE_OR_ALASKAN_NATIVE,
            NATIVE_HAWAIIAN_OR_PACIFIC_ISLANDER,
            HISPANIC_LATINO,
            UNKNOWN,
            NOT_SPECIFIED
        }

        public static enum specialServices {
            OTHER,
            NO_SPECIAL_SERVICES,
            PLAN_504,
            IEP,
            GIFTED_TALENTED,
            NOT_SPECIFIED
        }

        public static enum hasDisability {
            NO,
            NOT_SPECIFIED,
            YES
        }

        public static enum gender {
            NOT_SPECIFIED,
            MALE,
            FEMALE
        }

        public static enum hasEconomicDisadvantage {
            NOT_ECONOMICALLY_DISADVANTAGED,
            NOT_SPECIFIED,
            ECONOMICALLY_DISADVANTAGED
        }

        public static enum hasEnglishProficiency {
            ENGLISH,
            ENGLISH_LANGUAGE_LEARNER,
            NOT_SPECIFIED
        }

        public static enum isMigrant {
            MIGRANT,
            NOT_SPECIFIED,
            NON_MIGRANT
        }

    }

    public interface getGradeListConstants {
        String endpoint = "/lms/web/api/v1/grades";
        String GRADE_NAME = "gradeName";
        String GRADE_VALUE = "gradeValue";
    }

    public interface StudentListUsingSolarConstants {
        String GRADE_ID = "gradeId";
        String GRADE = "grade";
        String GROUP_ID = "groupId";
        String SEARCH_STRING = "searchString";
        String OFFSET = "offset";
        String NULL = "null";
        String USER_LIST = "userList";
        int OFFSET_VALUE = 250;
        String ZERO_VALUE = "0";
        String TOTAL_RECORDS = "totalRecords";
        String GRADE_NOT_SPECIFIED = "-10";
        String USERNAME = "username";
        String INVALID_ORGID_TEXT = "does not belong to orgId";

    }

}
