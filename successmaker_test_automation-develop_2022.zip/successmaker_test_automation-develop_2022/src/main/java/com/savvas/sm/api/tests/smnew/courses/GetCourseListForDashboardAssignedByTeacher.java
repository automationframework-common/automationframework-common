package com.savvas.sm.api.tests.smnew.courses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class GetCourseListForDashboardAssignedByTeacher extends CourseAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String CourseId;
    RBSUtils rbsutils = new RBSUtils();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    AssignmentAPI assignmentAPI;
    String token = null;
    String username = null;
    String studentDetails = null;
    String teacherUsername = null;
    //String accessCode;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        assignmentAPI = new AssignmentAPI();
        studentDetails = RBSDataSetup.getMyStudent( school, teacherUsername );

    }

    @Test ( priority = 1, dataProvider = "positiveScenarioForGetCourseListAtDashboardLevel", groups = { "SMK-52069", "Course", "CourseListDashboard", "P1", "API", "smoke_test_case" } )
    public void getCourseListAtDashboardLevelPositiveScenarios( String description, String scenario, String statusCode, String schoolTypeForTokenCreation, String successStatusCodeForGroupCreation, String commonSchoolTypeForGroupAndAssignment,
            String courseId, String productDescription ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );

        HashMap<String, String> apiResponse = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        switch ( scenario ) {

            case "TEST_CASE_BASED_ON_STATUS_CODE_200_GROUP_SECOND":
                List<String> studentRumbaIdsTc014 = new ArrayList<>();

                //Creating school based one the licenses
                tokenCreation( schoolTypeForTokenCreation );

                //Adding students to group
                studentRumbaIdsTc014 = addStudentsToGroup( successStatusCodeForGroupCreation, username, school );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, courseId, school, studentRumbaIdsTc014.get( 0 ) );
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, CourseAPIConstants.STRING_FOURTEEN, school, studentRumbaIdsTc014.get( 0 ) );

                //Get courses present at teacher UI home page
                apiResponse = getCoursesAtDashboardPageOfTeacherUI( school );
                Log.message( "Returned API Response - " + apiResponse.get( Constants.REPORT_BODY ) );

                //Getting the subject name
                String reponseDataTc014 = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), Constants.DATA );

                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc014, CourseAPIConstants.PRODUCT_DESCRIPTION, productDescription ), "Expected course is present in the response", "Expected course is absent in the response" );

                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc014, CourseAPIConstants.PRODUCT_DESCRIPTION, CourseAPIConstants.SUCCESSMAKER_FOCUS_READING ), "Expected course is present in the response",
                        "Expected course is absent in the response" );
                //Assertion
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;
            default:
                //Creating school based one the licenses
                tokenCreation( schoolTypeForTokenCreation );

                //Adding students to group
                studentRumbaIds = addStudentsToGroup( successStatusCodeForGroupCreation, username, school );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, courseId, school, studentRumbaIds.get( 0 ) );

                //Get courses present at teacher UI home page
                apiResponse = getCoursesAtDashboardPageOfTeacherUI( school );
                Log.message( "Returned API Response - " + apiResponse.get( Constants.REPORT_BODY ) );

                //Getting the subject name
                String reponseData = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), Constants.DATA );

                //Assertion
                Log.softAssertThat( SMUtils.compareKeyValue( reponseData, CourseAPIConstants.PRODUCT_DESCRIPTION, productDescription ), "Expected course is present in the response", "Expected course is absent in the response" );

                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;
        }
        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    @Test ( priority = 1, dataProvider = "DeleteAssignments_PositiveFlow", groups = { "SMK-51895", "DeleteAssignments", "DeleteAssignmentsFromStudnetsAndGroups", "P1", "API", "smoke_test_case" } )
    public void tcDeleteAssignment_01( String description, String scenario, String statusCode, String productDescription ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        String endpoint = "null";

        HashMap<String, String> groupDetails = new HashMap<>();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );

        HashMap<String, String> response = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        if ( groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        switch ( scenario ) {

            case "Delete Assignment CUSTOM SETTINGS MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignmentAPI.assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                HashMap<String, String> getresponse = assignmentAPI.deleteAssignment( smUrl, assignmentDetails, endpoint );
                Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
                Log.message( getresponse.get( "statusCode" ) );
                Log.message( getresponse.get( "body" ) );
                Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );

                break;
            case "ASSIGN CUSTOM SETTINGS MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignmentAPI.assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );

                break;

            case "ASSIGN CUSTOM SKILL MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignmentAPI.assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                break;

            case "ASSIGN CUSTOM STANDARD MATH":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                response = assignmentAPI.assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( response.get( "body" ) );
                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }

        //Get courses present at teacher UI home page
        HashMap<String, String> apiResponse = getCoursesAtDashboardPageOfTeacherUI( school );
        Log.message( "Returned API Response - " + apiResponse.get( Constants.REPORT_BODY ) );
        //Getting the subject name
        String reponseData = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), Constants.DATA );
        //Assertion
        Log.softAssertThat( SMUtils.compareKeyValue( reponseData, CourseAPIConstants.PRODUCT_DESCRIPTION, productDescription ), "Expected course is present in the response", "Expected course is absent in the response" );
        Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

        Log.testCaseResult();

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "positiveScenarioForGetCourseListAtDashboardLevel" )
    public Object[][] getCourseListAtDashboardLevelPositiveScenario() {
        Object[][] inputData = { { "TC001_Verify the teacher is able to see the list of the courses on the dashboard assigned by the teacher", "", "200", "flexLicensesSchool", "201", "flexSchool", "1", "SuccessMaker Default Math" },
                { "TC002_Verify the status code is 200 for the course created by the teacher", "", "200", "flexLicensesSchool", "201", "flexSchool", "1", "SuccessMaker Default Math" },
                { "TC005_Verify the status code is 200 when there are good number of courses for a particular teacher", "", "200", "flexLicensesSchool", "201", "flexSchool", "1", "SuccessMaker Default Math" },
                { "TC014_Verify the status code is 200 when teacher has assigned Focus courses to the students", "TEST_CASE_BASED_ON_STATUS_CODE_200_GROUP_SECOND", "200", "flexLicensesSchool", "201", "flexSchool", "4", "SuccessMaker Focus Math" },
                { "TC015_Verify the status code is 200 when the teacher has assigned Default course to the students", "", "200", "flexLicensesSchool", "201", "flexSchool", "2", "SuccessMaker Default Reading" },
                { "TC023_Verify the status code is 200 when the teacher has only assigned Focus Reading  course to the student", "", "200", "flexLicensesSchool", "201", "flexSchool", "12", "SuccessMaker Focus Reading" }, };

        return inputData;
    }

    @DataProvider ( name = "DeleteAssignments_PositiveFlow" )
    public Object[][] DeleteAssignments_PositiveFlow() {

        Object[][] inputData = {

                { "TC003_Verify the status code is 200 after the course which was recently created has been removed", "Delete Assignment CUSTOM SETTINGS MATH", CommonAPIConstants.STATUS_CODE_OK, "Courses created by teachers" },
                { "TC016_Verify the status code is 200 when the teacher has assigned custom courses by setting to the students", "ASSIGN CUSTOM SETTINGS MATH", CommonAPIConstants.STATUS_CODE_OK, "Courses created by teachers" },
                { "TC017_Verify the status code is 200 when the teacher has assigned custom courses by skill to the students", "ASSIGN CUSTOM SKILL MATH", CommonAPIConstants.STATUS_CODE_OK, "Courses created by teachers" },
                { "TC018_Verify the status code is 200 when the teacher has assigned custom courses by standards to the students", "ASSIGN CUSTOM STANDARD MATH", CommonAPIConstants.STATUS_CODE_OK, "Courses created by teachers" },

        };

        return inputData;
    }

    @Test ( priority = 2, dataProvider = "negativeScenarioForGetCourseListAtDashboardLevel", groups = { "SMK-52069", "Course", "CourseListDashboard", "P2", "API" } )
    public void getCourseListAtDashboardLevelNegativeScenarios( String description, String scenario, String statusCode ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        Map<String, String> dashboardCourseListDetails = new HashMap<>();
        String exception = null;
        String message = null;

        switch ( scenario ) {
            case "TC006_Verify the 403 code for invalid authentication":
                List<String> studentRumbaIdsTc006 = new ArrayList<>();

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Adding students to group
                studentRumbaIdsTc006 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, username, school );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, CourseAPIConstants.STRING_FIFTEEN, school, studentRumbaIdsTc006.get( 0 ) );

                //Get courses present at teacher UI home page
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, "TEST_HB" );
                apiResponse = getCoursesAtDashboardLevel( smUrl, dashboardCourseListDetails, "true" );

                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;

                //Assertion
                Log.softAssertThat( verifyException( apiResponse.get( "body" ), exception, message ), "Verified message is as expected", "Verified message but it is not as expected" );

                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

            case "TC007_Verify the 500 code for internal server error":
                List<String> studentRumbaIdsTc007 = new ArrayList<>();

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Adding students to group
                studentRumbaIdsTc007 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, username, school );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, CourseAPIConstants.STRING_THIRTEEN, school, studentRumbaIdsTc007.get( 0 ) );

                //Get courses present at teacher UI home page
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, "" );
                apiResponse = getCoursesAtDashboardLevel( smUrl, dashboardCourseListDetails, "true" );

                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

            case "TC008_Verify the 400 code for invalid Org id":
                List<String> studentRumbaIdsTc008 = new ArrayList<>();

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Adding students to group
                studentRumbaIdsTc008 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, username, school );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, CourseAPIConstants.STRING_SEVEN, school, studentRumbaIdsTc008.get( 0 ) );

                //Get courses present at teacher UI home page
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                dashboardCourseListDetails.put( CourseAPIConstants.INVALID_ORG_ID, "8a7201c77ea23877017ef7c0e1271b489" );
                apiResponse = getCoursesAtDashboardLevel( smUrl, dashboardCourseListDetails, "true" );

                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                message = "does not belong to orgId";

                //Assertion
                Log.softAssertThat( verifyException( apiResponse.get( "body" ), exception, message ), "Verified message is as expected", "Verified message but it is not as expected" );

                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

            case "TC011_Verify the 403 code for null parameter":
                List<String> studentRumbaIdsTc009 = new ArrayList<>();

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Adding students to group
                studentRumbaIdsTc009 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, username, school );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, CourseAPIConstants.STRING_SIX, school, studentRumbaIdsTc009.get( 0 ) );

                //Get courses present at teacher UI home page
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, "null" );
                apiResponse = getCoursesAtDashboardLevel( smUrl, dashboardCourseListDetails, "true" );

                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;

                //Assertion
                Log.softAssertThat( verifyException( apiResponse.get( "body" ), exception, message ), "Verified message is as expected", "Verified message but it is not as expected" );

                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

            case "TC013_Verify the 400 code when invalid value is passed for assignedCourses":
                List<String> studentRumbaIdsTc010 = new ArrayList<>();

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Adding students to group
                studentRumbaIdsTc010 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, username, school );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, CourseAPIConstants.STRING_SIX, school, studentRumbaIdsTc010.get( 0 ) );

                //Get courses present at teacher UI home page
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiResponse = getCoursesAtDashboardLevel( smUrl, dashboardCourseListDetails, "%21%40%23%24%25" );

                exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
                message = "Failed to convert value of type 'java.lang.String' to required type 'java.lang.Boolean'";

                //Assertion
                Log.softAssertThat( verifyException( apiResponse.get( "body" ), exception, message ), "Verified message is as expected", "Verified message but it is not as expected" );

                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;
            case "TC027_Verify the status code is 200 when the assignedCourses is set as false":
                List<String> studentRumbaIdsTc027 = new ArrayList<>();

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Adding students to group
                studentRumbaIdsTc027 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, username, school );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, CourseAPIConstants.STRING_NINE, school, studentRumbaIdsTc027.get( 0 ) );
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, CourseAPIConstants.STRING_ONE, school, studentRumbaIdsTc027.get( 0 ) );
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, CourseAPIConstants.STRING_TWO, school, studentRumbaIdsTc027.get( 0 ) );
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, CourseAPIConstants.STRING_FOURTEEN, school, studentRumbaIdsTc027.get( 0 ) );

                //Get courses present at teacher UI home page
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                apiResponse = getCoursesAtDashboardLevel( smUrl, dashboardCourseListDetails, "false" );
                //Getting the subject name
                String reponseDataTc027 = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), Constants.DATA );

                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc027, CourseAPIConstants.PRODUCT_DESCRIPTION, CourseAPIConstants.SUCCESSMAKER_DEFAULT_MATH ), "Expected course is present in the response",
                        "Expected course is absent in the response" );
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc027, CourseAPIConstants.PRODUCT_DESCRIPTION, CourseAPIConstants.SUCCESSMAKER_DEFAULT_READING ), "Expected course is present in the response",
                        "Expected course is absent in the response" );
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc027, CourseAPIConstants.PRODUCT_DESCRIPTION, CourseAPIConstants.SUCCESSMAKER_FOCUS_MATH ), "Expected course is present in the response",
                        "Expected course is absent in the response" );
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc027, CourseAPIConstants.PRODUCT_DESCRIPTION, CourseAPIConstants.SUCCESSMAKER_FOCUS_READING ), "Expected course is present in the response",
                        "Expected course is absent in the response" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;
        }
        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    /**
     * Data provider for negative scenarios
     * 
     * @return
     */

    @DataProvider ( name = "negativeScenarioForGetCourseListAtDashboardLevel" )
    public Object[][] getCourseListAtDashboardLevelNegativeScenario() {
        Object[][] inputData = { { "TC006_Verify the 403 code for invalid authentication", "TC006_Verify the 403 code for invalid authentication", "403" },
                { "TC007_Verify the 500 code for internal server error", "TC007_Verify the 500 code for internal server error", "500" }, { "TC008_Verify the 400 code for invalid Org id", "TC008_Verify the 400 code for invalid Org id", "400" },
                { "TC011_Verify the 403 code for null parameter", "TC011_Verify the 403 code for null parameter", "403" },
                { "TC013_Verify the 400 code when invalid value is passed for assignedCourses", "TC013_Verify the 400 code when invalid value is passed for assignedCourses", "400" },
                { "TC027_Verify the status code is 200 when the assignedCourses is set as false in the API endpoint", "TC027_Verify the status code is 200 when the assignedCourses is set as false", "200" } };
        return inputData;
    }

    //Token creation
    public void tokenCreation( String school ) {
        try {
            switch ( school ) {
                case CommonAPIConstants.FLEX_LICENSE_SCHOOL:
                    school = school;
                    teacherDetails = teacherDetails;
                    break;
            }
            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
            username = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            Log.message( "Error occurred in the token creation. Please check!!" );
        }
    }

    //Adding Students to group
    public List<String> addStudentsToGroup( String statusCode, String userName, String school ) {
        HashMap<String, String> response;
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        try {
            //Adding students to group
            String groupName = "Successmaker API Test Group " + System.nanoTime();
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, userName.toString() );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            GroupAPI GroupAPI = new GroupAPI();
            response = GroupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );
            Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            Log.message( "Error occurred in while adding students to group. Please check!!" );
        }
        return studentRumbaIds;
    }

    //Assigning assignment to student
    public void addAssignmentsToStudents( String statusCode, String courseId, String school, String studentRumbaId ) {
        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentRumbaId );
        try {
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            assignmentDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            assignmentDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            assignmentDetails.put( CourseAPIConstants.COURSE_ID, courseId );
            AssignmentAPI assignmentObj = new AssignmentAPI();
            HashMap<String, String> assignCourseToTheStudent = assignmentObj.assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
            if ( assignCourseToTheStudent.get( Constants.STATUS_CODE ).equals( statusCode ) ) {
                Log.message( "Course has been assigned to the student!" );
            } else {
                Log.message( "Something went wrong while assigning the course to the student! - " + assignCourseToTheStudent.get( Constants.REPORT_BODY ) );
            }
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            Log.message( "Error occurred in while adding assignments to students. Please check!!" );
        }
    }

    //Get courses present at teacher UI home page
    public HashMap<String, String> getCoursesAtDashboardPageOfTeacherUI( String school ) {
        HashMap<String, String> apiResponse = new HashMap<>();
        Map<String, String> dashboardCourseListDetails = new HashMap<>();
        try {
            dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            apiResponse = getCoursesAtDashboardLevel( smUrl, dashboardCourseListDetails, "true" );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            Log.message( "Error occurred in while getting the courses from the dashboard of Teacher UI. Please check!!" );
        }
        return apiResponse;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * 
     * @return
     */
    public boolean verifyException( String actualResponse, String exception, String message ) {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.message( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.message( "Issue in displaying exception!" );
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.message( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.message( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    /**
     * To Delete the assignment
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            org ID & course ID
     * @return
     * @throws Exception
     */
    public HashMap<String, String> deleteAssignment( String envUrl, HashMap<String, String> assignmentDetails ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters

        String endpoint = AssignmentAPIConstants.DELETE_ASSIGNMENT_API;
        endpoint = endpoint.replace( AssignmentAPIConstants.ORG_ID_VALUE, orgID ).replace( AssignmentAPIConstants.TEACHER_ID_VALUE, teacherID ).replace( AssignmentAPIConstants.CONTENT_BASE_ID_ENDPOINT, courseID );

        return RestHttpClientUtil.DELETE( envUrl, endpoint, headers, params );
    }
}
