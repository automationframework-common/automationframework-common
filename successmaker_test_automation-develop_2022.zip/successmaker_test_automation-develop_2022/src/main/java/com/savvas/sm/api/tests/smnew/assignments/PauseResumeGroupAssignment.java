package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class PauseResumeGroupAssignment extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String groupId;
    String userName = null;
    String endpoint = "null";
    List<String> studentRumbaIds = new ArrayList<>();
    RBSUtils rbsutils = new RBSUtils();
    GroupAPI groupAPI;
	CourseAPI courseAPI;
 	SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER  );
        userName = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(school , userName), Constants.USERID_HEADER) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(school , userName), Constants.USERID_HEADER) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent(school , userName), Constants.USERID_HEADER) );

        HashMap<String, String> groupDetails = new HashMap<>();

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER  ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );

        groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( "body" ), "data,groupId" );

        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();

    }

    @Test ( priority = 1, dataProvider = "PauseResumeGroupAssignment_PositiveFlow", groups = { "SMK-51915", "smoke_test_case","Assignments", "PauseResumeAllStudentsAssignment", "P1", "API" } )
    public void tcPauseResumeAllStudentsAssignment_PositiveFlow_01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> teacherUser = new HashMap<>();

        //TODO Need to change static/hard coded test data
        String token = new RBSUtils().getAccessToken( userName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        teacherUser.put( Constants.USER_NAME, userName );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( AssignmentAPIConstants.GROUP_ID, groupId );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUser.get( Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        switch ( scenario ) {

            case "Default Math Assignment Pause":
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                break;

            case "Default Math Assignment Resume":
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                break;

            case "Default Reading Assignment Pause":
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                break;

            case "Default Reading Assignment Resume":
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                break;

            case "Focus Math Assignment Pause":
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );
                break;

            case "Focus Math Assignment Resume":
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH_1 );
                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }
        HashMap<String, String> getresponse = changeGroupAssignmentStatus( smUrl, assignmentDetails, assignmentDetails.get( AssignmentAPIConstants.STATUS ), endpoint );
        Log.message( "StatusCode: " + getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        VerifySchema( getresponse.get( "statusCode" ), getresponse );
        Log.assertThat( getresponse.get( "statusCode" ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */

    @DataProvider ( name = "PauseResumeGroupAssignment_PositiveFlow" )
    public Object[][] PauseResumeAllStudentsAssignment_PositiveFlow() {

        Object[][] inputData = { { "Validate 200 for Math Positive flow - Pause Group assignment", "Default Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Math Positive flow - Resume Group assignment", "Default Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Reading Positive flow - Pause Group assignment", "Default Reading Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Reading Positive flow - Resume Group assignment", "Default Reading Assignment Resume", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Focus Math Positive flow - Pause Group assignment", "Focus Math Assignment Pause", CommonAPIConstants.STATUS_CODE_OK },
                { "Validate 200 for Focus Math Positive flow - Resume Group assignment", "Focus Math Assignment Resume", CommonAPIConstants.STATUS_CODE_OK } };
        return inputData;
    }

    /**
     * Data provider for Negative scenarios
     * 
     * @return
     */

    @DataProvider ( name = "PauseResumeGroupAssignment_NegativeFlow" )
    public Object[][] PauseResumeGroupAssignment_NegativeFlow() {

        Object[][] inputData = { { "Validate 404 for Incorrect URL to Pause/Resume Group Assignment", "Incorrect URL for Pause/Resume Group Assignment", CommonAPIConstants.STATUS_CODE_NOTFOUND },
                { "Validate 400 for Incorrect Payload data", "Incorrect Payload data", CommonAPIConstants.STATUS_CODE_BAD_REQUEST }, { "Validate 400 for Invalid payload data", "Invalid payload data", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Validate 400 for Payload in Lowercase", "Payload in Lowercase", CommonAPIConstants.STATUS_CODE_BAD_REQUEST }, { "Validate 400 for Invalid Org ID in param", "Invalid Org ID in param", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Validate 400 for Invalid Staff ID param", "Invalid Staff ID param", CommonAPIConstants.STATUS_CODE_BAD_REQUEST }, { "Validate 400 for Invalid GroupID param", "Invalid GroupID param", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Validate 403 for Invalid Org ID Header", "Invalid Org ID Header", CommonAPIConstants.STATUS_CODE_FORBIDDAN }, { "Validate 401 for Invalid Staff ID Header", "Invalid Staff ID Header", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED } };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "PauseResumeGroupAssignment_NegativeFlow", groups = { "SMK-51915", "Assignments", "PauseResumeAllStudentsAssignment", "P1", "API" } )
    public void tcPauseResumeAllStudentsAssignment_NegativeFlow_01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        String endpoint = "null";

        HashMap<String, String> teacherUser = new HashMap<>();

        String token = new RBSUtils().getAccessToken( userName,  RBSDataSetupConstants.DEFAULT_PASSWORD );

        teacherUser.put( Constants.USER_NAME, userName );
        
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( AssignmentAPIConstants.GROUP_ID, groupId );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUser.get( Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        switch ( scenario ) {

            case "Incorrect URL for Pause/Resume Group Assignment":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_GROUPASSIGNMENT_API;
                endpoint = endpoint.replace( "{orgID}", orgId ).replace( "{teacherID}", teacherId ).replace( "{groupID}", groupId ).replace( "{contentbaseId}", AssignmentAPIConstants.MATH ).replace( "status", "statusss" );
                break;

            case "Incorrect Payload data":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.COURSE_ID ); // Payload other than ACTIVE / INACTIVE
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_GROUPASSIGNMENT_API;
                endpoint = endpoint.replace( "{orgID}", orgId ).replace( "{teacherID}", teacherId ).replace( "{groupID}", groupId ).replace( "{contentbaseId}", AssignmentAPIConstants.MATH ).replace( "status", "status" );
                break;

            case "Invalid payload data":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, "12345" ); // Integer value for Payload value
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_GROUPASSIGNMENT_API;
                endpoint = endpoint.replace( "{orgID}", orgId ).replace( "{teacherID}", teacherId ).replace( "{groupID}", groupId ).replace( "{contentbaseId}", AssignmentAPIConstants.MATH ).replace( "status", "status" );
                break;

            case "Payload in Lowercase":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_INACTIVE_LCASE ); // Payload value in lowercase
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_GROUPASSIGNMENT_API;
                endpoint = endpoint.replace( "{orgID}", orgId ).replace( "{teacherID}", teacherId ).replace( "{groupID}", groupId ).replace( "{contentbaseId}", AssignmentAPIConstants.MATH ).replace( "status", "status" );
                break;

            case "Invalid Org ID in param":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE ); // Invalid ORG ID in Param
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_GROUPASSIGNMENT_API;
                endpoint = endpoint.replace( "{orgID}", orgId + "text" ).replace( "{teacherID}", teacherId ).replace( "{groupID}", groupId ).replace( "{contentbaseId}", AssignmentAPIConstants.MATH ).replace( "status", "status" );
                break;

            case "Invalid Staff ID param":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE ); // Invalid Staff ID
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_GROUPASSIGNMENT_API;
                endpoint = endpoint.replace( "{orgID}", orgId ).replace( "{teacherID}", teacherId + "text" ).replace( "{groupID}", groupId ).replace( "{contentbaseId}", AssignmentAPIConstants.MATH ).replace( "status", "status" );
                break;

            case "Invalid GroupID param":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE ); // Invalid GroupID
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_GROUPASSIGNMENT_API;
                endpoint = endpoint.replace( "{orgID}", orgId ).replace( "{teacherID}", teacherId ).replace( "{groupID}", "1234" ).replace( "{contentbaseId}", AssignmentAPIConstants.MATH ).replace( "status", "status" );
                break;

            case "Invalid Org ID Header":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_GROUPASSIGNMENT_API;
                endpoint = endpoint.replace( "{orgID}", orgId ).replace( "{teacherID}", teacherId ).replace( "{groupID}", groupId ).replace( "{contentbaseId}", AssignmentAPIConstants.MATH ).replace( "status", "status" );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, "8a7206a97f2c9d3a017f4eedf8bd0843sdsdf" );
                break;

            case "Invalid Staff ID Header":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( AssignmentAPIConstants.STATUS, AssignmentAPIConstants.STATUS_ACTIVE );
                endpoint = AssignmentAPIConstants.PAUSE_RESUME_GROUPASSIGNMENT_API;
                endpoint = endpoint.replace( "{orgID}", orgId ).replace( "{teacherID}", teacherId ).replace( "{groupID}", groupId ).replace( "{contentbaseId}", AssignmentAPIConstants.MATH ).replace( "status", "status" );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, "1asd234lklknsdnknsv" );
                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }
        HashMap<String, String> getresponse = changeGroupAssignmentStatus( smUrl, assignmentDetails, assignmentDetails.get( AssignmentAPIConstants.STATUS ), endpoint );
        Log.message( "StatusCode: " + getresponse.get( "statusCode" ) );
        Log.message( getresponse.get( "body" ) );
        Log.assertThat( getresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getresponse.get( Constants.STATUS_CODE ) );

    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    /**
     * Verify the Schema for the API
     * 
     * @param StatusCode
     * @param Body
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = smAPIprocessor.isSchemaValid( "PauseResumeAllStudentAssignment", StatusCode, response.get( "body" ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
        Log.assertThat( isValid, "The schema is valid and mathcing", "The schema is not valid and not  mathcing for the Status code :" + StatusCode );
    }
}