package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LastSessionSkillTestedPopup extends BaseTest {

    private String smUrl;
    private String browser;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String schoolID;
    private String teacherID;
    private String username = null;
    private String studentOne;
    private String chromePlatform = "Windows_10_Chrome_latest"; // for Simulator Execution
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String studentDetails;
    private String teacherDetails;
    private String assignmentId;
    private String assignmentUserId;
    private static String mathAssignment = "Math_Settings" + System.nanoTime();
    private static String readingAssignment = "Reading_Settings" + System.nanoTime();
    private static String focusAssignment = "SM Focus Math: Grade 1";
    private static String customAssignment = "T2_MathCustomSkills" + System.nanoTime();;
    private HashMap<String, String> groupDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String token = null;
    HashMap<String, String> assignmentDetails = new HashMap<>();
    String studentSMDetails;
    String studentDetail;
    String studentUsername;

    @BeforeClass (alwaysRun = true)
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentDetails = RBSDataSetup.getMyStudent( school, username );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        
    //    String customReadingCourse = "Custom Reading_" + System.nanoTime();
        
     //   studentDetail = studentSMDetails;
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );
        // token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Log.message( "Teacher access token: " + token );

        // Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

        // Assign Focus course
        assignFocusCourseToStudent();

        String mathCourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherID, schoolID, DataSetupConstants.SETTINGS, mathAssignment );
        String readingCourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherID, schoolID, DataSetupConstants.SETTINGS, readingAssignment );
        String customCourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherID, schoolID, DataSetupConstants.SETTINGS, customAssignment );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, schoolID );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        assignmentDetails.put( AssignmentAPIConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );

        new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );

        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, readingCourseId );
        new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );

        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, customCourseId );
        new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );

        studentOne = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );
        executeSimulator( studentUsername, Constants.MATH, Constants.MATH );
     
    }

    @Test ( description = "SMK-15077 - Verify the skill pop up header for Math course in 'Skill Tested' section.", dataProvider = "getMathSkillDataFromAPI", groups = { "SMK-43904", "lastSessionSkillTested", "studentUsageChart" }, priority = 1 )
    public void tcSMLastSessionSkillTestedPopup001( Map<String, String> skillDetails ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
    	

        Log.testCaseInfo( "tcSMLastSessionSkillTestedPopup001: SMK-15077 - Verify the skill pop up header for Math course in 'Skill Tested' section. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Go to the assignment detail Page
            AssignmentsPage assignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( mathAssignment );

            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );

            HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<String, HashMap<String, String>>();
            skillsTestedList = assignmentDetailsPage.getSkillsCorrectCountAndPercentage();

            String skillName = skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME );

            // Clicking Skill name
            assignmentDetailsPage.clickSkillNameInSkillTested( skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) );

            SMUtils.logDescriptionTC( "SMK-15084 - Verify the 'Close' button in 'Last session skills popup'" );
            SMUtils.logDescriptionTC( "SMK-15085 - Verify the 'Cancel' icon in 'Last session skills popup'" );

            // Verify skill tested popup header
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupHeaderAndButtons( Constants.MATH ), "Skill tested popup header and buttons displayed properly", "Skill tested popup header and buttons not displayed properly" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "SMK-15081_SMK-15082 - Verify the skill name displays correctly on bottom of the prograss bar in black bold font" );
            SMUtils.logDescriptionTC( "SMK-15083 - Verify the LO name and the description in 'Last session skills popup'" );

            // verify skill tested popup values
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupValues( skillDetails ), "skill Tested values are displayed properly!", "skill Tested values are not displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15080 : Verify the '#Correctcount / #Totalcount' displays correctly in skill pop up for Math course" );
            HashMap<String, HashMap<String, String>> skillsTestedPopupList = new HashMap<String, HashMap<String, String>>();
            skillsTestedPopupList = assignmentDetailsPage.getSkillsPopupCorrectCountAndPercentage();
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupCorrectTotalMatch( skillsTestedList, skillsTestedPopupList, skillName ), "'#Correctcount / #Totalcount' macthes with Skill tested widget & Skill Tested popup",
                    "'#Correctcount / #Totalcount' not macthing with Skill tested widget & Skill Tested popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15078 : Verify the Progress bar is displaying with green color in skill pop up for Math course" );
            
            // Verify Progress bar color
            Log.assertThat( assignmentDetailsPage.skillTestedPopupProgressBarColorMath( skillsTestedPopupList, skillName ), "Progress Bar color is Green", "Progress Bar color is not Green" );
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC( "SMK-15079_SMK-15087 : Verify the '% correct' value displays correctly in black color on progress bar in skill pop up for 'Math' course" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupBarTextMath( skillsTestedList, skillsTestedPopupList, skillName ), "Progress Bar % Correct is same and Displayed in black color",
                    "Progress Bar % Correct is not same or is not displayed in black color" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupMatch( skillsTestedList, skillsTestedPopupList ), "Skill Tested Widget data matches with Skill Tested Popup", "Skill Tested Widget data does not matches with Skill Tested Popup" );
            Log.testCaseResult();

            // Verifying after navigate to LO viewer
            assignmentDetailsPage.clickLOInSkillTestedPopup();

            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();

            SMUtils.logDescriptionTC( "SMK-15086 - Verify the user is navigated to LO corresponding view page upon clicking on the LO link in the skill pop up" );
            Log.assertThat( driver.getCurrentUrl().contains( skillDetails.get( Constants.LastSessionSkillTested.LO_URL ) ), "The Url navigated respective to LO page!", "The Url is not navigate respective to LO page!" );
            Log.testCaseResult();

            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                teacherHomePage = new TeacherHomePage( driver );
                teacherHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

   	@Test(description = "SMK-15088 - Verify the skill pop up header for Reading course in 'Skill Tested' section.", dataProvider = "getReadingSkillDataFromAPI", groups = {"SMK-43904", "lastSessionSkillTested", "studentUsageChart" }, priority = 1)
    public void tcSMLastSessionSkillTestedPopup002( Map<String, String> skillDetails ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLastSessionSkillTestedPopup002: SMK-15088 - Verify the skill pop up header for Reading course in 'Skill Tested' section. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate 'CourseWare' tab and select the 'Assignments' option
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment
            assignmentsPage.clickAssignmentSubMenu();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( readingAssignment );

            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ), SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );

            HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<String, HashMap<String, String>>();
            skillsTestedList = assignmentDetailsPage.getSkillsCorrectCountAndPercentage();

            String skillName = skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME );

            // Clicking Skill name
            assignmentDetailsPage.clickSkillNameInSkillTested( skillName );

            SMUtils.logDescriptionTC( "SMK-15095 : Verify the 'Close' button in 'Last session skills popup'" );
            SMUtils.logDescriptionTC( "SMK-15096 : Verify the 'Cancel' icon in 'Last session skills popup'" );
            
            // Verify skill tested popup header
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupHeaderAndButtons( Constants.READING ), "Skill tested popup header and buttons displayed properly", "Skill tested popup header and buttons displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15092_SMK-15093 : Verify the skill name displays correctly on bottom of the prograss bar in black bold font" );
            SMUtils.logDescriptionTC( "SMK-15094 : Verify the LO name and the description in 'Last session skills popup'" );
            
            // verify skill tested popup values
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupValues( skillDetails ), "skill Tested values are displayed properly!", "skill Tested values are not displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15091 : TC015_Verify the '#Correctcount / #Totalcount' displays correctly in skill pop up for Reading course" );
            HashMap<String, HashMap<String, String>> skillsTestedPopupList = new HashMap<String, HashMap<String, String>>();
            skillsTestedPopupList = assignmentDetailsPage.getSkillsPopupCorrectCountAndPercentage();
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupCorrectTotalMatch( skillsTestedList, skillsTestedPopupList, skillName ), "'#Correctcount / #Totalcount' matches with Skill tested widget & Skill Tested popup",
                    "'#Correctcount / #Totalcount' not matching with Skill tested widget & Skill Tested popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15089 : Verify the Progress bar is displaying with blue color in skill pop up for Reading course" );
            
            // Verify Progress bar color
            Log.assertThat( assignmentDetailsPage.skillTestedPopupProgressBarColorRead( skillsTestedPopupList, skillName ), "Progress Bar color is Blue", "Progress Bar color is not blue" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15090_SMK-15098 : Verify the '% correct' value displays correctly in white color on progress bar in skill pop up for 'Reading' course" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupBarTextRead( skillsTestedList, skillsTestedPopupList, skillName ), "Progress Bar % Correct is same and Displayed in white color",
                    "Progress Bar % Correct is not same or is not displayed in white color" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupMatch( skillsTestedList, skillsTestedPopupList ), "Skill Tested Widget data matches with Skill Tested Popup", "Skill Tested Widget data does not matches with Skill Tested Popup" );
            Log.testCaseResult();

            // Verifying after navigate to LO viewer
            assignmentDetailsPage.clickLOInSkillTestedPopup();

            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();

            SMUtils.logDescriptionTC( "SMK-15097 : Verify the user is navigated to LO corresponding view page upon clicking on the LO link in the skill pop up" );
            Log.assertThat( driver.getCurrentUrl().contains( skillDetails.get( Constants.LastSessionSkillTested.LO_URL ) ), "The Url navigated respective to LO page!", "The Url is not navigate respective to LO page!" );
            Log.testCaseResult();

            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                tHomePage = new TeacherHomePage( driver );
                tHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test(description = "SMK-15110 - Verify the skill pop up header for Focus course in 'Skill Tested' section.", dataProvider = "getFocusSkillDataFromAPI", groups = {"SMK-43904", "lastSessionSkillTested", "studentUsageChart" }, priority = 2)
    public void tcSMLastSessionSkillTestedPopup003( Map<String, String> skillDetails ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLastSessionSkillTestedPopup003: SMK-15110 - Verify the skill pop up header for Focus course in 'Skill Tested' section.<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Go to the assignment detail Page
            AssignmentsPage assignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( focusAssignment );

            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );

            HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<String, HashMap<String, String>>();
            skillsTestedList = assignmentDetailsPage.getSkillsCorrectCountAndPercentage();

            // Clicking Skill name
            assignmentDetailsPage.clickSkillNameInSkillTested( skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) );

            SMUtils.logDescriptionTC( "SMK-15117 - Verify the 'Close' button in 'Last session skills popup'" );
            SMUtils.logDescriptionTC( "SMK-15118 - Verify the 'Cancel' icon in 'Last session skills popup'" );
           
            // Verify skill tested popup header
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupHeaderAndButtons( Constants.MATH ), "Skill tested popup header and buttons displayed properly", "Skill tested popup header and buttons displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15114_SMK-15115 - Verify the skill name displays correctly on bottom of the prograss bar in black bold font" );
            SMUtils.logDescriptionTC( "SMK-15116 - Verify the LO name and the description in 'Last session skills popup'" );
            
            // verify skill tested popup values
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupValues( skillDetails ), "skill Tested values are displayed properly!", "skill Tested values are not displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15113 : Verify the '#Correctcount / #Totalcount' displays correctly in skill pop up for Focus course" );
            HashMap<String, HashMap<String, String>> skillsTestedPopupList = new HashMap<String, HashMap<String, String>>();
            skillsTestedPopupList = assignmentDetailsPage.getSkillsPopupCorrectCountAndPercentage();
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupCorrectTotalMatch( skillsTestedList, skillsTestedPopupList, skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) ),
                    "'#Correctcount / #Totalcount' macthes with Skill tested widget & Skill Tested popup", "'#Correctcount / #Totalcount' not macthing with Skill tested widget & Skill Tested popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15111 : Verify the Progress bar is displaying with green color in skill pop up for 'Focus' course" );
            
            // Verify Progress bar color
            Log.assertThat( assignmentDetailsPage.skillTestedPopupProgressBarColorMath( skillsTestedPopupList, skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) ), "Progress Bar color is Green", "Progress Bar color is not Green" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15113_SMK-15120 : Verify the '% correct' value displays correctly in black color on progress bar in skill pop up for 'Focus' course " );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupBarTextMath( skillsTestedList, skillsTestedPopupList, skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) ),
                    "Progress Bar % Correct is same and Displayed in black color", "Progress Bar % Correct is not same or is not displayed in black color" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupMatch( skillsTestedList, skillsTestedPopupList ), "Skill Tested Widget data matches with Skill Tested Popup", "Skill Tested Widget data does not matches with Skill Tested Popup" );
            Log.testCaseResult();

            // Verifying after navigate to LO viewer
            assignmentDetailsPage.clickLOInSkillTestedPopup();

            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();

            SMUtils.logDescriptionTC( "SMK-15119 - Verify the user is navigated to LO corresponding view page upon clicking on the LO link in the skill pop up" );
            Log.assertThat( driver.getCurrentUrl().contains( skillDetails.get( Constants.LastSessionSkillTested.LO_URL ) ), "The Url navigated respective to LO page!", "The Url is not navigate respective to LO page!" );
            Log.testCaseResult();
            
            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Sign out
                teacherHomePage = new TeacherHomePage( driver );
                teacherHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

   	@Test(description = "SMK-15099 - Verify the skill pop up header for 'Custom Math/Reading' course in 'Skill Tested' section.", dataProvider = "getCustomMathSkillDataFromAPI", groups = {"SMK-43904", "lastSessionSkillTested", "studentUsageChart" }, priority = 2)
    public void tcSMLastSessionSkillTestedPopup004( Map<String, String> skillDetails ) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMLastSessionSkillTestedPopup004: SMK-15099 - Verify the skill pop up header for 'Custom Math/Reading' course in 'Skill Tested' section.<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage teacherHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Go to the assignment detail Page
            AssignmentsPage assignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( customAssignment );

            assignmentDetailsPage.clicktoggleButtonForStudent( SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ), SMUtils.getKeyValueFromResponse( studentDetails, "middleName" ),
                    SMUtils.getKeyValueFromResponse( studentDetails, "lastName" ) );

            HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<String, HashMap<String, String>>();
            skillsTestedList = assignmentDetailsPage.getSkillsCorrectCountAndPercentage();

            String skillName = skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME );

            // Clicking Skill name
            assignmentDetailsPage.clickSkillNameInSkillTested( skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) );

            SMUtils.logDescriptionTC( "SMK-15106 - Verify the 'Close' button in 'Last session skills popup'" );
            SMUtils.logDescriptionTC( "SMK-15107 - Verify the 'Cancel' icon in 'Last session skills popup'" );

            // Verify skill tested popup header
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupHeaderAndButtons( Constants.MATH ), "Skill tested popup header and buttons displayed properly", "Skill tested popup header and buttons displayed properly" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "SMK-15103_SMK-15104 - Verify the skill name displays correctly on bottom of the prograss bar in black bold font" );
            SMUtils.logDescriptionTC( "SMK-15105 - Verify the LO name and the description in 'Last session skills popup'" );

            // verify skill tested popup values
            Log.assertThat( assignmentDetailsPage.verifySkillTestedPopupValues( skillDetails ), "skill Tested values are displayed properly!", "skill Tested values are not displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15102 : Verify the '#Correctcount / #Totalcount' displays correctly in skill pop up for 'Custom Math/Reading' course" );
            HashMap<String, HashMap<String, String>> skillsTestedPopupList = new HashMap<String, HashMap<String, String>>();
            skillsTestedPopupList = assignmentDetailsPage.getSkillsPopupCorrectCountAndPercentage();
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupCorrectTotalMatch( skillsTestedList, skillsTestedPopupList, skillName ), "'#Correctcount / #Totalcount' macthes with Skill tested widget & Skill Tested popup",
                    "'#Correctcount / #Totalcount' not macthing with Skill tested widget & Skill Tested popup" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15100 : Verify the Progress bar is displaying with green color in skill pop up for 'Math Skill' course" );
            
            // Verify Progress bar color
            Log.assertThat( assignmentDetailsPage.skillTestedPopupProgressBarColorMath( skillsTestedPopupList, skillName ), "Progress Bar color is Green", "Progress Bar color is not Green" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-15101_SMK-15109 : Verify the '% correct' value displays correctly in black color on progress bar in skill pop up for 'Custom Math/Reading' course" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupBarTextMath( skillsTestedList, skillsTestedPopupList, skillName ), "Progress Bar % Correct is same and Displayed in black color",
                    "Progress Bar % Correct is not same or is not displayed in black color" );
            Log.assertThat( assignmentDetailsPage.skillTestedAndSkillPopupMatch( skillsTestedList, skillsTestedPopupList ), "Skill Tested Widget data matches with Skill Tested Popup", "Skill Tested Widget data does not matches with Skill Tested Popup" );
            Log.testCaseResult();

            // Verifying after navigate to LO viewer
            assignmentDetailsPage.clickLOInSkillTestedPopup();

            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();

            SMUtils.logDescriptionTC( "SMK-15086 - Verify the user is navigated to LO corresponding view page upon clicking on the LO link in the skill pop up" );
            Log.assertThat( driver.getCurrentUrl().contains( skillDetails.get( Constants.LastSessionSkillTested.LO_URL ) ), "The Url navigated respective to LO page!", "The Url is not navigate respective to LO page!" );
            Log.testCaseResult();

            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                teacherHomePage = new TeacherHomePage( driver );
                teacherHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @DataProvider ( name = "getMathSkillDataFromAPI" )
    public Object[][] getMathSkillDataFromAPI() throws Exception {

        String endpoint = "null";

        HashMap<String, String> StudentAssignentDetails = new HashMap<>();
        StudentAssignentDetails = new AssignmentAPI().getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );
        String assignmentByStudent = StudentAssignentDetails.get( "body" );
        IntStream.rangeClosed( 1, SMUtils.getWordCount( assignmentByStudent, "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( mathAssignment ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "assignmentId", index );
                assignmentUserId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "studentAssignmentId", index );
            }
        } );
        assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId);
        // getting data from API
        String response = new AssignmentAPI().getLastSessionSkillTestedByStudent(smUrl, token, assignmentDetails, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), Constants.MATH);
        HashMap<String, String> skillDetails = new HashMap<>();
        skillDetails.put( Constants.LastSessionSkillTested.SKILL_NAME, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.SKILL_NAME ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) );

        String loDetails = SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.LO_DETAILS );
        skillDetails.put( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
        skillDetails.put( Constants.LastSessionSkillTested.CATALOG_NUMBER, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.CATALOG_NUMBER ) );
        skillDetails.put( Constants.LastSessionSkillTested.LO_URL, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.LO_URL ) );

        Object[][] result = { { skillDetails } };
        return result;

    }

    @DataProvider ( name = "getReadingSkillDataFromAPI" )
    public Object[][] getReadingSkillDataFromAPI() throws Exception {
        String endpoint = "null";
        HashMap<String, String> StudentAssignentDetails = new HashMap<>();
        StudentAssignentDetails = new AssignmentAPI().getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );

        String assignmentByStudent = StudentAssignentDetails.get( "body" );
        IntStream.rangeClosed( 1, SMUtils.getWordCount( assignmentByStudent, "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( readingAssignment ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "assignmentId", index );
                assignmentUserId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "studentAssignmentId", index );
            }
        } );
        assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId);
        // getting data from API
        String response = new AssignmentAPI().getLastSessionSkillTestedByStudent( smUrl, token, assignmentDetails, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), Constants.READING );

        HashMap<String, String> skillDetails = new HashMap<>();
        skillDetails.put( Constants.LastSessionSkillTested.SKILL_NAME, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.SKILL_NAME ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) );

        String loDetails = SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.LO_DETAILS );
        skillDetails.put( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
        skillDetails.put( Constants.LastSessionSkillTested.CATALOG_NUMBER, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.CATALOG_NUMBER ) );
        skillDetails.put( Constants.LastSessionSkillTested.LO_URL, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.LO_URL ) );

        Object[][] result = { { skillDetails } };
        return result;

    }

    @DataProvider ( name = "getFocusSkillDataFromAPI" )
    public Object[][] getFocusSkillDataFromAPI() throws Exception {
        String endpoint = "null";
        HashMap<String, String> StudentAssignentDetails = new HashMap<>();
        StudentAssignentDetails = new AssignmentAPI().getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );

        String assignmentByStudent = StudentAssignentDetails.get( "body" );
        IntStream.rangeClosed( 1, SMUtils.getWordCount( assignmentByStudent, "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( focusAssignment ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "assignmentId", index );
                assignmentUserId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "studentAssignmentId", index );
            }
        } );
        assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId);
        // getting data from API
        String response = new AssignmentAPI().getLastSessionSkillTestedByStudent( smUrl, token, assignmentDetails, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), Constants.MATH );

        HashMap<String, String> skillDetails = new HashMap<>();
        skillDetails.put( Constants.LastSessionSkillTested.SKILL_NAME, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.SKILL_NAME ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) );

        String loDetails = SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.LO_DETAILS );
        skillDetails.put( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
        skillDetails.put( Constants.LastSessionSkillTested.CATALOG_NUMBER, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.CATALOG_NUMBER ) );
        skillDetails.put( Constants.LastSessionSkillTested.LO_URL, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.LO_URL ) );

        Object[][] result = { { skillDetails } };
        return result;

    }

    @DataProvider ( name = "getCustomMathSkillDataFromAPI" )
    public Object[][] getCustomMathSkillDataFromAPI() throws Exception {
        String endpoint = "null";
        HashMap<String, String> StudentAssignentDetails = new HashMap<>();
        StudentAssignentDetails = new AssignmentAPI().getStudnetAssignmentDetailsByStudnetID( smUrl, assignmentDetails, endpoint );

        String assignmentByStudent = StudentAssignentDetails.get( "body" );
        IntStream.rangeClosed( 1, SMUtils.getWordCount( assignmentByStudent, "name" ) ).forEach( index -> {
            String courseDetail = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "courseDetail", index );
            String name = SMUtils.getKeyValueFromResponse( courseDetail, "name" );
            if ( name.equals( customAssignment ) ) {
                assignmentId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "assignmentId", index );
                assignmentUserId = SMUtils.getKeyValueFromJsonArray( assignmentByStudent, "studentAssignmentId", index );
            }
        } );
        assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserId);
        // getting data from API
        String response = new AssignmentAPI().getLastSessionSkillTestedByStudent( smUrl, token, assignmentDetails, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), Constants.MATH );

        HashMap<String, String> skillDetails = new HashMap<>();
        skillDetails.put( Constants.LastSessionSkillTested.SKILL_NAME, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.SKILL_NAME ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) );
        skillDetails.put( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT, SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) );

        String loDetails = SMUtils.getKeyValueFromResponse( response, Constants.RESPONSE_DATA + "," + Constants.LastSessionSkillTested.LO_DETAILS );
        skillDetails.put( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
        skillDetails.put( Constants.LastSessionSkillTested.CATALOG_NUMBER, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.CATALOG_NUMBER ) );
        skillDetails.put( Constants.LastSessionSkillTested.LO_URL, SMUtils.getKeyValueFromResponse( loDetails, Constants.LastSessionSkillTested.LO_URL ) );

        Object[][] result = { { skillDetails } };
        return result;

    }

    public void attendCourseAsStudent() throws Exception {
   		// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);
		try {
            LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentOne, password );
            StudentDashboardPage studentOneDashboardPage = new StudentDashboardPage( chromeDriver );

            studentOneDashboardPage.executeMathCourse( username, mathAssignment, "85", "1", "1" );

            studentOneDashboardPage.executeReadingCourse( username, readingAssignment, "80", "1", "1" );
            studentOneDashboardPage.executeMathCourse( username, focusAssignment, "90", "1", "1" );
            studentOneDashboardPage.executeMathCourse( username, customAssignment, "70", "1", "1" );
            studentOneDashboardPage.logout();
        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        } finally {
            chromeDriver.quit();
            Log.endTestCase();
        }
    }

    public void assignFocusCourseToStudent() throws Exception {

   		// Get driver
		EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		chromeDriver.register(eventListner);
        try {
            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( chromeDriver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( chromeDriver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            CourseListingPage courseListingPage = new CourseListingPage( chromeDriver );
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );
            coursePage.clickCourseName( Constants.SM_FOCUS_MATH_GRADE1 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        } finally {
            chromeDriver.quit();
            Log.endTestCase();
        }
    }
    public void executeCourse( String studentUserName, String courseName, boolean isMath )  {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "10" );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "10" );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        
}
    }
    public void executeSimulator( String studentUsername, String assignmentName, String assignmentType ) throws Exception {
        WebDriver studentDriver = WebDriverFactory.get( browser );
        LoginPage smStudentLoginPage = new LoginPage( studentDriver, smUrl ).get();
        StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
        try {
            if ( assignmentType.equals( Constants.MATH ) ) {
                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
                    Log.message( "Math Course Execution" );
                    try {
                        studentDashboardPage.executeMathCourse( username, assignmentName, "95", "2", "30" );
                    } catch ( IOException e ) {
                        Log.message( "Error occurred while running the simulator for Math" );
                    }

                } );

            } else {
                IntStream.rangeClosed( 1, 4 ).forEach( value -> {
                    Log.message( "Reading Course Execution" );
                    try {
                        studentDashboardPage.executeReadingCourse( username, assignmentName, "100", "2", "15" );
                    } catch ( IOException e ) {
                        Log.message( "Error occurred while running the simulator Reading" );
                    }

                } );

            }
        } catch ( Exception e ) {

            Log.message( "Error occurred while running the simulator" );
        }
        studentDriver.quit();
    }

}