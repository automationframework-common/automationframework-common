package com.savvas.sm.api.tests.smnew.logintest;

import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.apiconstants.LoginAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

/***
 * This class contains test scripts for Authorized & Unauthorized Login
 * 
 * @author aravindan.sivanandan
 *
 */

public class LoginAuthorizationTest extends BaseAPITest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private Response response;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherDetails;
    private String studentDetail;

    @BeforeClass(alwaysRun = true)
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
    }

    /**
     * Method for testing Authorized & Unauthorized Login - API-Positive cases.
     * 
     * @param tcID
     * @throws Exception
     */

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-51119", "smoke_test_case", "P1", "Add current district check in login flow", "API" }, priority = 1 )
    public void getLoginAuthorizationTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        // End point for API
        String endPoint = LoginAPIConstants.GET_LOGIN_AUTHORIZATION_ENDPOINT;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {
            case "VALID_TEACHER":
                headers.put( LoginAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                Log.message( headers + "" );
                break;

            case "VALID_STUDENT":
                headers.put( LoginAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID ) );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ), password ) );
                break;
        }

        response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint );
        int actual_StatusCode = response.getStatusCode();

        Log.assertThat( actual_StatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode );
        Log.message( response.getBody().asString() );
        Log.testCaseResult();
        Log.assertThat( ( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data,isValidThreeSixtyId" ).equals( "true" ) ), "Schema is returned as expected.", "Schema is not as expected." );
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC:01", "200", "Verify 200 status code and response body when valid headers and vaild authorization is given", "VALID_TEACHER" },
                { "TC:02", "200", "Verify 200 status code and response body when valid headers and vaild authorization is given", "VALID_STUDENT" }, };
        return data;

    }

    /**
     * Method for testing Authorized & Unauthorized Login -Negative cases.
     * 
     * @param tcID
     * @throws Exception
     */

    @Test ( dataProvider = "getDataForNegativieScenarios", groups = { "SMK-51119", "Add current district check in login flow", "API" }, priority = 2 )
    public void getLoginAuthorizationTest002( String testcaseName, int expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        // End point for API
        String endPoint = LoginAPIConstants.GET_LOGIN_AUTHORIZATION_ENDPOINT;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {
            case "Invalid_UserId_Valid_OrgId":
                headers.put( LoginAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) + "invalid" );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                break;

            case "Valid_UserId_Invalid_OrgId":
                headers.put( LoginAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) + "invalid" );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                break;

            case "Invalid_UserID_Invalid_OrgId":
                headers.put( LoginAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) + "invalid" );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) + "invalid" );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                break;

            case "Invalid_Auth":
                headers.put( LoginAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) + "Invalid" );
                break;

            case "Invalid_UserID_Invalid_OrgId_Invalid_Auth":
                headers.put( LoginAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) + "invalid" );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) + "invalid" );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) + "invalid" );
                break;

            case "Invalid_UserID_Invalid_OrgId_Valid_Auth":
                headers.put( LoginAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) + "invalid" );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) + "invalid" );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                break;

            case "Valid_UserID_Invalid_OrgId_invalid_Teacher_Login":
                headers.put( LoginAPIConstants.ORGID, "invalid" );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + "Invalid" );
                break;

            case "Valid_UserID_Invalid_OrgId_valid_Teacher_Login":
                headers.put( LoginAPIConstants.ORGID, "invalid" );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                break;

            case "inValid_UserID_valid_OrgId_valid_Student_Login":
                headers.put( LoginAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID ) + "invalid" );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ), password ) );
                break;

            case "Valid_UserID_Invalid_OrgId_valid_Student_Login":
                headers.put( LoginAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) + "invalid" );
                headers.put( LoginAPIConstants.USERID, SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID ) );
                headers.put( LoginAPIConstants.AUTHORIZATION, LoginAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ), password ) );
                break;

        }
        response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint );
        Log.message( response.getBody().asString() );
        int actual_StatusCode = response.getStatusCode();

        Log.assertThat( actual_StatusCode == expected_StatusCode, "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataForNegativieScenarios() {
        Object[][] data = { { "TC:03", 401, "Verify 401 status code and response body when valid header details and invalid authorization is given", "Invalid_Auth" },
                { "TC:04", 401, "Verify 401 status code and response body when invalid user-id with valid org-id is given in the headers", "Invalid_UserId_Valid_OrgId" },
                { "TC:05", 403, "Verify 403 status code and response body when valid user-id and invalid org-id is given in the headers", "Valid_UserId_Invalid_OrgId" },
                { "TC:06", 401, "Verify 401 status code and response body when invalid user-id and invalid org-id is given in the headers", "Invalid_UserId_Invalid_OrgId" },
                { "TC:07", 401, "Verify 401 status code and response body when invalid org id and invalid user id is given with valid authorisation ID", "Invalid_UserID_Invalid_OrgId_Valid_Auth" },
                { "TC:08", 401, "Verify 401 status code and response body when invalid org id and invalid user id is given with invalid authorisation ID ", "Invalid_UserID_Invalid_OrgId_Invalid_Auth" },
                { "TC:10", 403, "Verify the Status Code as 403 for the when the User id is Correct, Organization Id is not Correct and Bearer token are Correct for teacher credentials", "Valid_UserID_Invalid_OrgId_valid_Teacher_Login" },
                { "TC:11", 401, "Verify the Status Code as 401 for the student when the User id is not Correct, Organization Id and Bearer token are Correct for Student credentials", "inValid_UserID_valid_OrgId_valid_Student_Login" },
                { "TC:13", 403, "Verify the Status Code as 403 for the student when the User id is Correct, Organization Id is not Correct and Bearer token are Correct for Student credentials", "Valid_UserID_Invalid_OrgId_valid_Student_Login" } };
        return data;
    }
}