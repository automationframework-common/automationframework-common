package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.smnew.users.CreateStudentAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.ReturnStudentListAPI;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentProgressGraphAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.UserAPIEndPoints;
import com.savvas.sm.utils.sql.helper.SqlHelperUsage;

/**
 * This class used to test the api for Student Progress Monitoring Graph
 * 
 * @author praveen.rangopi
 *
 */
public class StudentProgressMonitoringGraphAPI extends UserAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;
    private String teacherDetails = null;

    private String teacherDetails1 = null;
    private String teacherDetails2 = null;
    private String studentDetail = null;
    private String studentDetail1 = null;
    private String studentDetail2 = null;
    private String studentDetail3 = null;
    private String studentDetail4 = null;
    private String studentUsername = null;
    private String studentUserID = null;
    private String studentUsername2 = null;
    private String studentUserID2 = null;
    private String courseName;
    private String courseId;
    public Boolean result = null;
    int noOfIterationForMath = 1;
    int noOfIterationForReading = 1;
    //private String teacherDetails3 = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String school1 = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    public String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    RBSDataSetup data = new RBSDataSetup();
    //public String accessToken;
    RBSUtils rbs = new RBSUtils();
    public String userId;
    public String userId1;
    public String userId2;
    public String orgId;
    public String orgId2;
    //Map<String, String> assignmentResponse = new HashMap<>();
    // public String orgId1;
    public String username;
    public String username2;
    public String username1;
    public String mathOnlyProduct;
    public String readingOnlyProduct;
    //public String courseID;
    public String studentID1;
    public String studentID2;
    public String classId;
    public String classId2;
    public String adminToken;
    public HashMap<String, String> assignmentDetails = new HashMap<>();
    public String createTeacher;
    public String multipleSchoolTeacherID;
    public String multipleSchoolTeacherName;
    public String multiOrgStuID;
    public String multiOrgStuUserName;
    HashMap<String, String> assignCourseToTheStudent = new HashMap<String, String>();
    public static String mathAssignmentID;
    public static String assignmentID;
    public static String focusMathAssignmentID;
    public static List<String> orgIDs = new ArrayList<String>();
    Map<String, String> assignmentResponse = new HashMap<>();
    GroupAPI gUsage = new GroupAPI();

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        mathOnlyProduct = configProperty.getProperty( "mathOnlyProduct" );
        readingOnlyProduct = configProperty.getProperty( "readingOnlyProduct" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherDetails1 = RBSDataSetup.getMyTeacher( school );
        teacherDetails2 = RBSDataSetup.getMyTeacher( school1 );
        userId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        userId1 = SMUtils.getKeyValueFromResponse( teacherDetails1, Constants.USERID_HEADER );
        userId2 = SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USERID_HEADER );
        username2 = SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USER_NAME );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );

        username1 = SMUtils.getKeyValueFromResponse( teacherDetails1, Constants.USER_NAME );

        studentDetail = RBSDataSetup.getMyStudent( school, username );
        studentDetail1 = RBSDataSetup.getMyStudent( school, username );
        studentDetail4 = RBSDataSetup.getMyStudent( school, username );
        studentDetail2 = RBSDataSetup.getMyStudent( school1, SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USER_NAME ) );
        studentDetail3 = RBSDataSetup.getMyStudent( school1, SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USER_NAME ) );

        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername2 = SMUtils.getKeyValueFromResponse( studentDetail2, Constants.USER_NAME );
        studentUserID2 = SMUtils.getKeyValueFromResponse( studentDetail2, Constants.USERID_HEADER );

        orgId = RBSDataSetup.organizationIDs.get( school );
        orgId2 = RBSDataSetup.organizationIDs.get( school1 );
        orgIDs.add( orgId );
        orgIDs.add( orgId2 );

        String accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        List<String> teachers = new ArrayList<String>();
        List<String> stuIDs = new ArrayList<String>();
        List<String> courseIDs = new ArrayList<String>();
        List<String> schools = new ArrayList<String>();
        HashMap<String, String> userDetails = new HashMap<>();
        HashMap<String, String> studentDetails = new HashMap<>();
        String multiSchoolTeacher = "MultiSchTeacher" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

        schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
        schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
        String listString = "";
        for ( String school : schools ) {
            listString += school.concat( "\",\"" );
        }
        listString = listString.substring( 0, listString.length() - 3 );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
        String createUser = rbs.createUser( userDetails );

        multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERID );
        multipleSchoolTeacherName = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERNAME );
        new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

        studentDetails = new CreateStudentAPITest().generateRequestValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
        studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
        studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, CreateStudentAPIConstants.TEACHER_ID, multipleSchoolTeacherID );
        studentDetails = new CreateStudentAPITest().updateRequestBodyValues( studentDetails, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        HashMap<String, String> stuDetails = createStudent( smUrl, studentDetails );
        String responseBody = SMUtils.getKeyValueFromResponse( stuDetails.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA );
        multiOrgStuID = SMUtils.getKeyValueFromResponse( responseBody, Constants.PERSONID );
        multiOrgStuUserName = SMUtils.getKeyValueFromResponse( responseBody, RBSDataSetupConstants.USERNAME );
        rbs.updateUserOrgId( rbs.getUser( multiOrgStuID ), StudentProgressGraphAPIConstants.STUDENT_VALUE, orgIDs );
        String className = "Test Class" + System.nanoTime();

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> classDetails = new HashMap<>();

        teachers.add( userId );
        teachers.add( userId1 );
        teachers.add( multipleSchoolTeacherID );
        stuIDs.add( studentUserID );
        stuIDs.add( multiOrgStuID );
        stuIDs.add( SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USERID_HEADER ) );

        courseIDs.add( AssignmentAPIConstants.MATH );
        courseIDs.add( AssignmentAPIConstants.READING );
        courseIDs.add( AssignmentAPIConstants.FOCUS_READING );
        courseIDs.add( AssignmentAPIConstants.FOCUS_MATH );
        courseIDs.add( new CourseAPI().createCourse( smUrl, accessToken, DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) ) );
        courseIDs.add( new CourseAPI().createCourse( smUrl, accessToken, DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SKILL, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) ) );
        courseIDs.add( new CourseAPI().createCourse( smUrl, accessToken, DataSetupConstants.MATH, userId, orgId, DataSetupConstants.STANDARD, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) ) );

        String className1 = "Test Class" + System.nanoTime();
        classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, userId );
        classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
        classDetails.put( CreateGroupAPIConstants.GROUP_NAME, className1 );
        classId = SMUtils.getKeyValueFromResponse( gUsage.createGroup( smUrl, classDetails, stuIDs ).get( Constants.BODY ), "data,groupId" );

        String className2 = "Test Class" + System.nanoTime();
        classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, userId1 );
        classId2 = SMUtils.getKeyValueFromResponse( gUsage.createGroup( smUrl, classDetails, stuIDs ).get( Constants.BODY ), "data,groupId" );
        classDetails.put( CreateGroupAPIConstants.GROUP_NAME, className2 );

        String className3 = "Test Class" + System.nanoTime();
        classDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multipleSchoolTeacherName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        classDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
        classId2 = SMUtils.getKeyValueFromResponse( gUsage.createGroup( smUrl, classDetails, stuIDs ).get( Constants.BODY ), "data,groupId" );
        classDetails.put( CreateGroupAPIConstants.GROUP_NAME, className2 );

        classDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        classDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
        classDetails.put( RBSDataSetupConstants.STUDENT_PI_ID, studentUserID );
        classDetails.put( RBSDataSetupConstants.STAFF_PI_ID, multipleSchoolTeacherID );
        classDetails.put( RBSDataSetupConstants.SECTION_NAME, className3 );

        String classes = rbs.createClassWithMultipleTeacher( classDetails, teachers, stuIDs );
        JSONObject jsonObject = new JSONObject( classes );

        classId = jsonObject.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();

        adminToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        rbs.addProductToClassGraphQL( orgId, classId, mathOnlyProduct, adminToken, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

        HashMap<String, String> assignAssignment = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, stuIDs, courseIDs );

    }

    @Test ( priority = 1, dataProvider = "ValidCases", groups = { "smoke_test_case", "SMK-52024", "Student", "StudentProgressGraph", "P1", "API" } )
    public void tcStudentProgressGraph001( String description, String scenario, String statusCode ) throws Exception {
        Log.message( description );
        // Constants
        //String studentName;
        //String studentId;
        //String classId;
        //String groupName = null;
        HashMap<String, String> studentInfo = new HashMap<>();
        HashMap<String, String> apiDetails = new HashMap<>();
        HashMap<String, String> response;
        HashMap<String, String> assignmentDetails = new HashMap<>();
        switch ( scenario ) {

            case "DEFAULT_MATH":

                SMUtils.logDescriptionTC( "Verify the Current Level field displayed in the response" );
                SMUtils.logDescriptionTC( "Verify the Ip Level field for Default Math course" );
                SMUtils.logDescriptionTC( "Verify the status code is 200 and Response body, if student cleared the IP today for assignment" );
                SMUtils.logDescriptionTC( "Verify the response will populate the data when student completed session followed IP Completed session." );
                SMUtils.logDescriptionTC( "Verify the Gain is the difference of Current Level - IP Level" );

                // Student Creation
                String studentName = "Math_Student" + System.nanoTime();
                String studentId = createSharedStudent( studentName, userId, new RBSUtils().getAccessToken( username, password ), userId1, new RBSUtils().getAccessToken( username1, password ), orgId );

                // Enrolling student into the class
                String accessToken = new RBSUtils().getAccessToken( username, password );
                String groupName = "Group_" + System.nanoTime();

                String classId = new GroupAPI().createGroupWithCustomization( groupName, userId, Arrays.asList( studentId ), orgId, accessToken );

                studentInfo = data.generateRequestValues( rbs.getUser( studentId ), studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, userId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

                accessToken = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );

                String courseName = "Math";
                String courseId = AssignmentAPIConstants.MATH;

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentId ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                String mathsAssignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( studentName, Constants.MATH, true, "75", "5", "30" );

                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, mathsAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentId );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "DEFAULT_READING":
                SMUtils.logDescriptionTC( "Verify the Ip Level field for Default Reading course" );
                SMUtils.logDescriptionTC( "Verify the response will populate data for assigned level course after completing second session." );
                String accessToken1 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
                String courseName1 = "Reading";
                String courseId1 = AssignmentAPIConstants.READING;

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId1 );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                String readingAssignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( studentUsername, Constants.READING, false, "75", "2", "25" );
                executeCourse( studentUsername, Constants.READING, false, "75", "2", "25" );
                executeCourse( studentUsername, Constants.READING, false, "75", "2", "25" );
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, readingAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.READING );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.READING );
                break;

            case "SHARED_STUDENT":
                SMUtils.logDescriptionTC( "Verify the response for shared Student" );
                SMUtils.logDescriptionTC( "Verify there should be four course value fields in the valid response body" );
                SMUtils.logDescriptionTC( "Verify the response will populate data for assigned level course after completing second session." );
                // Student Creation
                String studentName1 = "student" + System.nanoTime();
                String studentId2 = createSharedStudent( studentName1, userId, new RBSUtils().getAccessToken( username, password ), userId1, new RBSUtils().getAccessToken( username1, password ), orgId );

                // Enrolling student into the class
                String accessToken2 = new RBSUtils().getAccessToken( username, password );
                groupName = "Group_" + System.nanoTime();

                classId = new GroupAPI().createGroupWithCustomization( groupName, userId, Arrays.asList( studentId2 ), orgId, accessToken2 );

                studentInfo = data.generateRequestValues( rbs.getUser( studentId2 ), studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, userId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

                String accessToken3 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );

                String courseName2 = "Math";
                String courseId2 = AssignmentAPIConstants.MATH;

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId2 );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken3 );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentId2 ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                String sharedAssignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( studentName1, Constants.MATH, true, "75", "5", "30" );

                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken3 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, sharedAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentId2 );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "STUDENT_PART_OF_MULTIPLE_SCHOOL":
                // Student Creation
                String studentName2 = "student" + System.nanoTime();
                String studentId3 = createSharedStudent( studentName2, userId, new RBSUtils().getAccessToken( username, password ), userId1, new RBSUtils().getAccessToken( username1, password ), orgId );

                // Enrolling student into the class
                String accessToken4 = new RBSUtils().getAccessToken( username, password );
                String groupName1 = "Group_" + System.nanoTime();

                String classId1 = new GroupAPI().createGroupWithCustomization( groupName1, userId, Arrays.asList( studentId3 ), orgId, accessToken4 );

                studentInfo = data.generateRequestValues( rbs.getUser( studentId3 ), studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, userId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

                String accessToken5 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );

                String courseName3 = "Math";
                String courseId3 = AssignmentAPIConstants.MATH;

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId3 );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken5 );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentId3 ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                String multiAssignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( studentName2, Constants.MATH, true, "75", "5", "30" );

                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken5 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, multiAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentId3 );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "TEACHER_PART_OF_MULTIPLE_SCHOOL":
                // Student Creation
                String studentName3 = "student" + System.nanoTime();
                String studentId4 = createSharedStudent( studentName3, userId, new RBSUtils().getAccessToken( username, password ), userId1, new RBSUtils().getAccessToken( username1, password ), orgId );

                // Enrolling student into the class
                String accessToken6 = new RBSUtils().getAccessToken( username, password );
                String groupName2 = "Group_" + System.nanoTime();

                String classId2 = new GroupAPI().createGroupWithCustomization( groupName2, userId, Arrays.asList( studentId4 ), orgId, accessToken6 );

                studentInfo = data.generateRequestValues( rbs.getUser( studentId4 ), studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, userId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

                String accessToken7 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );

                String courseName4 = "Math";
                String courseId4 = AssignmentAPIConstants.MATH;

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId4 );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken7 );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentId4 ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                String multiTrAssignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( studentName3, Constants.MATH, true, "75", "5", "30" );

                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken7 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, multiTrAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentId4 );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "SHARED_GROUP":
                // Student Creation
                String studentName4 = "student" + System.nanoTime();
                String studentId5 = createSharedStudent( studentName4, userId, new RBSUtils().getAccessToken( username, password ), userId1, new RBSUtils().getAccessToken( username1, password ), orgId );

                // Enrolling student into the class
                String accessToken8 = new RBSUtils().getAccessToken( username, password );
                String groupName3 = "Group_" + System.nanoTime();

                String classId4 = new GroupAPI().createGroupWithCustomization( groupName3, userId, Arrays.asList( studentId5 ), orgId, accessToken8 );

                studentInfo = data.generateRequestValues( rbs.getUser( studentId5 ), studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, userId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

                String accessToken9 = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );

                String courseName5 = "Math";
                String courseId5 = AssignmentAPIConstants.MATH;

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId5 );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken9 );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentId5 ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                String sharedGrpAssignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( studentName4, Constants.MATH, true, "75", "5", "30" );

                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken9 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, sharedGrpAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentId5 );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;
        }
        response = studentProgressGraphAPI( smUrl, apiDetails );
        Log.message( response.toString() );
        Log.assertThat( validateResponseWithDB( response, apiDetails.get( Constants.ASSIGNMENT_ID ), apiDetails.get( Constants.STUDENT_ID ), apiDetails.get( Constants.Reports.SUBJECT_DROPDOWN ) ), "All the fields are verified and returned as expected",
                "Field value not return as Expected" );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "studentProgressGraphSchema", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */

    @DataProvider ( name = "ValidCases" )
    public Object[][] tcStudentProgressGraph01() {

        Object[][] data = { { "Verify the Gain Field displayed in the response", "DEFAULT_MATH", "200" }, { "Verify the response shows Data for Default Reading", "DEFAULT_READING", "200" },
                { "Verify the response for shared teacher", "TEACHER_PART_OF_MULTIPLE_SCHOOL", "200" },
                { "verify the api when Teacher is part of multiple org and student is also part of multiple org and check how the student performance when assigned assignment in multiple ways", "TEACHER_PART_OF_MULTIPLE_SCHOOL", "200" },
                { "Verify the status code and progress ,when the student has part of shared group", "SHARED_GROUP", "200" },
                { "Verify the api when Student is part of multiple schools and the shared course assignment was assigned to the same student", "STUDENT_PART_OF_MULTIPLE_SCHOOL", "200" },
                { "Verify the API returning no response for Orphan student", "SHARED_STUDENT", "200" }, };
        return data;
    }

    @Test ( priority = 1, dataProvider = "InValidCases", groups = { "SMK-52024", "Student", "StudentProgressGraph", "P1", "API" } )
    public void tcStudentProgressGraph002( String description, String scenario, String statusCode ) throws Exception {
        HashMap<String, String> classDetails = new HashMap<>();
        HashMap<String, String> apiDetails = new HashMap<>();
        HashMap<String, String> response;
        String errorMessage = null;
        String exceptionMessage = null;
        switch ( scenario ) {

            case "ORPHAN_STUDENT":
                String accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.NO_PROGRESS_TO_SHOW_MESSAGE;
                exceptionMessage = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                apiDetails.put( Constants.USERID, userId2 );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId2 );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId2 );
                apiDetails.put( Constants.TEACHER_ID, userId2 );
                apiDetails.put( Constants.ASSIGNMENT_ID, mathAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentDetail2, Constants.USERID_HEADER ) );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, "1" );

                break;

            case "INVALID_STUDENT_ID":
                String accessToken1 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.STUDENT_NOT_FOUND_MESSSAGE;
                exceptionMessage = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken1 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, mathAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, StudentProgressGraphAPIConstants.INVALID_STUDENT_ID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "INVALID_ORG_ID":
                String accessToken2 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.STUDENT_NOT_FOUND_MESSSAGE;
                exceptionMessage = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken2 );
                apiDetails.put( Constants.ORGANIZATION_ID, StudentProgressGraphAPIConstants.INVALID_ORG_ID );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, mathAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "OTHER_STAFF_ORGID":
                String accessToken3 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.STUDENT_NOT_FOUND_MESSSAGE;
                exceptionMessage = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken3 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId2 );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, mathAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "INVALID_STAFF_ID":
                String accessToken4 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.STUDENT_NOT_FOUND_MESSSAGE;
                exceptionMessage = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken4 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId + 1 );
                apiDetails.put( Constants.ASSIGNMENT_ID, mathAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "OTHER_TEACHER_STUDENT_ID":
                String accessToken5 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.STUDENT_NOT_FOUND_MESSSAGE;
                exceptionMessage = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken5 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, mathAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentDetail3, Constants.USERID_HEADER ) );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "OTHER_ORG_STAFF_ID":
                String accessToken6 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.USER_ID_MISMATCH_MESSAGE;
                exceptionMessage = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken6 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId2 );
                apiDetails.put( Constants.ASSIGNMENT_ID, mathAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "INVALID_SUBJECT_TYPE_ID":
                String accessToken7 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.NO_PROGRESS_TO_SHOW_MESSAGE;
                exceptionMessage = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken7 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, mathAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, StudentProgressGraphAPIConstants.INVALID_SUB_TYPE_ID );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "INVALID_ASSIGNMENT_ID":
                String accessToken8 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.ASSIGNMENT_NOT_FOUND_MESSAGE;
                exceptionMessage = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken8 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, StudentProgressGraphAPIConstants.INVALID_ASSIGNMENT_ID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "CUSTOM_BY_SKILL_COURSE":
                Map<String, String> assignmentResponse8 = new HashMap<>();

                String accessToken9 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.NO_PROGRESS_TO_SHOW_MESSAGE;
                exceptionMessage = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                courseName = "CustomMathSKillCourse" + System.nanoTime();
                courseId = new AssignmentAPI().createCustomCourse( smUrl, accessToken9, DataSetupConstants.MATH, userId, orgId, DataSetupConstants.STANDARD, courseName, "customBySkills_MATH.json" );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken9 );
                assignmentResponse8 = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse8.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( studentUsername, courseName, true, "100", "1", "10" );
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken9 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "CUSTOM_BY_STANDARD_COURSE":
                Map<String, String> assignmentResponse9 = new HashMap<>();

                String accessToken10 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.NO_PROGRESS_TO_SHOW_MESSAGE;
                exceptionMessage = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                courseName = "CustomMathStandardCourse" + System.nanoTime();
                courseId = new AssignmentAPI().createCustomCourse( smUrl, accessToken10, DataSetupConstants.MATH, userId, orgId, DataSetupConstants.STANDARD, courseName, "customByStandardsRandom_MATH.json" );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken10 );
                assignmentResponse9 = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse9.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( studentUsername, courseName, true, "100", "1", "10" );
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken10 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "MATH_FOCUS_COURSE":
                Map<String, String> assignmentResponse10 = new HashMap<>();

                String accessToken11 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.NO_PROGRESS_TO_SHOW_MESSAGE;
                exceptionMessage = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                courseName = "SM Focus Math: Grade 1";
                courseId = AssignmentAPIConstants.FOCUS_MATH;
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken11 );
                assignmentResponse10 = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                focusMathAssignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse10.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( studentUsername, courseName, true, "100", "1", "10" );
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken11 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, focusMathAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "READING_FOCUS_COURSE":
                Map<String, String> assignmentResponse11 = new HashMap<>();

                String accessToken12 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.NO_PROGRESS_TO_SHOW_MESSAGE;
                exceptionMessage = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                courseName = "SM Focus Reading: Grade 1";
                courseId = AssignmentAPIConstants.FOCUS_READING;
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken12 );
                assignmentResponse11 = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse11.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( studentUsername, courseName, false, "100", "1", "10" );
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken12 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "COURSE_WITH_ONE_SESSION":
                Map<String, String> assignmentResponse12 = new HashMap<>();

                String accessToken13 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.NO_PROGRESS_TO_SHOW_MESSAGE;
                exceptionMessage = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                courseName = "SM Focus Math: Grade 1";
                courseId = AssignmentAPIConstants.FOCUS_MATH;
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken13 );
                assignmentResponse12 = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USERID_HEADER ) ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse12.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USER_NAME ), courseName, true, "100", "1", "10" );
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken13 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentID );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USERID_HEADER ) );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "STUDENT_NOT_COMPLETING_IP":
                Map<String, String> assignmentResponse13 = new HashMap<>();

                String accessToken14 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.NO_PROGRESS_TO_SHOW_MESSAGE;
                exceptionMessage = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                courseName = "Math";
                courseId = AssignmentAPIConstants.MATH;

                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken14 );
                assignmentResponse13 = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USERID_HEADER ) ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse13 );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse13.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                executeCourse( SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USER_NAME ), Constants.MATH, true, "75", "1", "10" );

                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken14 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, assignmentID );
                apiDetails.put( Constants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentDetail1, Constants.USERID_HEADER ) );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "REMOVE_ASSIGNMENT":
                String accessToken15 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.NO_PROGRESS_TO_SHOW_MESSAGE;
                exceptionMessage = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                HashMap<String, String> assignDetails = new HashMap<>();
                assignDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, studentUserID );
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken15 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, mathAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;

            case "DELETED_STUDENT":
                String accessToken16 = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                errorMessage = CommonAPIConstants.STUDENT_NOT_FOUND_MESSSAGE;
                exceptionMessage = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                List<String> userToDel = new ArrayList<>();
                userToDel.add( studentUserID );
                rbs.deleteUser( userToDel );
                apiDetails.put( Constants.USERID, userId );
                apiDetails.put( Constants.GROUP_ORG_ID, orgId );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken16 );
                apiDetails.put( Constants.ORGANIZATION_ID, orgId );
                apiDetails.put( Constants.TEACHER_ID, userId );
                apiDetails.put( Constants.ASSIGNMENT_ID, focusMathAssignmentID );
                apiDetails.put( Constants.STUDENT_ID, studentUserID );
                apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
                apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
                break;
        }
        response = studentProgressGraphAPI( smUrl, apiDetails );
        Log.assertThat( validateErrorANDExceptionMessage( response, errorMessage, exceptionMessage, statusCode ), "Error Message and Exception Validated Successfully", "Error Message Not returned as expected" );
        Log.message( response.toString() );
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */

    @DataProvider ( name = "InValidCases" )
    public Object[][] tcStudentProgressGraph() {

        Object[][] data = { { "Verify the API returning no response for Orphan student", "ORPHAN_STUDENT", "200" }, { "Verify the Response for Invalid Student Id", "INVALID_STUDENT_ID", "200" },
                { "Verify the Response for Invalid Org Id", "INVALID_ORG_ID", "200" }, { "Verify the Response for Other Teacher Student Id", "OTHER_TEACHER_STUDENT_ID", "200" },
                { "Verify the Response for Other Teacher Org Id", "OTHER_STAFF_ORGID", "200" }, { "Verify the Response for Invalid Staff Id", "INVALID_STAFF_ID", "200" },
                { "Verify the Response for Invalid SubjectType Id", "INVALID_SUBJECT_TYPE_ID", "400" }, { "Verify the Response for Invalid Assignment Id", "INVALID_ASSIGNMENT_ID", "400" },
                { "Verify the response for Deleted Student", "DELETED_STUDENT", "400" }, { "Verify the response not show any data for assigned level courses after completing first session.", "COURSE_WITH_ONE_SESSION", "400" },
                { "Verify the response not showing data for Reading Focus Courses", "STUDENT_NOT_COMPLETING_IP", "400" }, { "Verify the response not showing data for Custom by skill course", "CUSTOM_BY_SKILL_COURSE", "400" },
                { "Verify the response not showing data for Custom by standard course", "CUSTOM_BY_STANDARD_COURSE", "400" }, { "Verify the response not showing data for Math Focus Courses", "MATH_FOCUS_COURSE", "400" },
                { "Verify the response not showing data for Reading Focus Courses", "READING_FOCUS_COURSE", "400" } };
        return data;
    }

    @Test ( priority = 1, groups = { "SMK-52024", "Student", "StudentProgressGraph", "P1", "API" } )
    public void tcStudentProgressGraph003() throws Exception {
        SMUtils.logDescriptionTC( "Verify the Assigned Level field for Custom by settings with Ip off courses" );
        SMUtils.logDescriptionTC( "Verify there should be four course value fields in the valid response body" );
        SMUtils.logDescriptionTC( "Verify the response will populate data for assigned level course after completing second session." );
        SMUtils.logDescriptionTC( "Verify the response shows Data for Custom by Setting course with IP On" );
        // Constants
        String studentName;
        String studentId;
        String classId;
        String groupName = null;
        Map<String, String> assignmentResponse15 = new HashMap<>();

        HashMap<String, String> studentInfo = new HashMap<>();
        HashMap<String, String> apiDetails = new HashMap<>();
        HashMap<String, String> response;
        HashMap<String, String> assignmentDetails = new HashMap<>();
        // Student Creation
        studentName = "student" + System.nanoTime();
        studentId = createSharedStudent( studentName, userId, new RBSUtils().getAccessToken( username, password ), userId1, new RBSUtils().getAccessToken( username1, password ), orgId );

        // Enrolling student into the class
        String accessToken = new RBSUtils().getAccessToken( username, password );
        groupName = "Group_" + System.nanoTime();

        classId = new GroupAPI().createGroupWithCustomization( groupName, userId, Arrays.asList( studentId ), orgId, accessToken );

        studentInfo = data.generateRequestValues( rbs.getUser( studentId ), studentInfo, UserConstants.SCHOOLID, orgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, userId );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        Log.message( "Updating grade..." );
        new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
        accessToken = rbs.getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD );
        courseName = "CustomMathSettingIPOffCourse" + System.nanoTime();
        courseId = new CourseAPI().createCourse( smUrl, accessToken, DataSetupConstants.MATH, userId, orgId, DataSetupConstants.SETTINGS, courseName );

        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        assignmentResponse15 = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentId ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( "assignmentResponse=" + assignmentResponse15 );
        String sharedAssignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse15.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        executeCourse( studentName, Constants.MATH, true, "75", "5", "30" );

        apiDetails.put( Constants.USERID, userId );
        apiDetails.put( Constants.GROUP_ORG_ID, orgId );
        apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        apiDetails.put( Constants.ORGANIZATION_ID, orgId );
        apiDetails.put( Constants.TEACHER_ID, userId );
        apiDetails.put( Constants.ASSIGNMENT_ID, sharedAssignmentID );
        apiDetails.put( Constants.STUDENT_ID, studentId );
        apiDetails.put( Constants.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
        apiDetails.put( Constants.Reports.SUBJECT_DROPDOWN, Constants.MATH );
        response = studentProgressGraphAPI( smUrl, apiDetails );
        Log.message( response.toString() );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "studentProgressGraphSchema", "200", response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

    }

    // To Execute Course
    public void executeCourse( String studentUserName, String courseName, boolean isMath, String percentage, String numberOfSession, String loCount ) throws IOException {
        final WebDriver chromeDriver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, LoginConstants.UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        SMUtils.nap( 30 );
        StudentDashboardPage studentsPage = new StudentDashboardPage( chromeDriver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                //driver.close();
            } catch ( Exception e ) {
                //driver.close();
            } finally {
                chromeDriver.quit();
            }

        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                //driver.close();
            } catch ( Exception e ) {
                //driver.close();
            } finally {
                chromeDriver.quit();
            }
        }
    }

    // Validating Response with DB Data
    public Boolean validateResponseWithDB( HashMap<String, String> response, String assignmentID, String studentID, String subject ) {
        Boolean status = false;
        SqlHelperUsage helperPage = new SqlHelperUsage();
        HashMap<String, String> progressDetails = helperPage.getProgressDetails( assignmentID, studentID, subject );
        Log.message( progressDetails.toString() );
        String currentLevel = progressDetails.get( StudentProgressGraphAPIConstants.CURRENT_LEVEL );
        String ipLevel = progressDetails.get( StudentProgressGraphAPIConstants.IP_LEVEL );
        String assignedLevel = progressDetails.get( StudentProgressGraphAPIConstants.ASSIGNED_LEVEL );
        String ipCompletedDate = progressDetails.get( StudentProgressGraphAPIConstants.IP_COMPLETED_DATE );

        final DecimalFormat df = new DecimalFormat( "#.###" );
        double currentLevelValue = Double.parseDouble( df.format( Double.parseDouble( currentLevel ) ) );
        double iPLevelValue = Double.parseDouble( df.format( Double.parseDouble( ipLevel ) ) );
        double ans = currentLevelValue - iPLevelValue;
        double actual = Double.parseDouble( df.format( ans ) );

        String responseBody = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA );

        if ( Double.parseDouble( SMUtils.getKeyValueFromResponse( responseBody, StudentProgressGraphAPIConstants.CURRENT_LEVEL ) ) == currentLevelValue
                && Double.parseDouble( SMUtils.getKeyValueFromResponse( responseBody, StudentProgressGraphAPIConstants.IP_LEVEL ) ) == iPLevelValue ) {
            if ( actual == Double.parseDouble( SMUtils.getKeyValueFromResponse( responseBody, StudentProgressGraphAPIConstants.GAIN ) ) ) {
                status = true;
                Log.message( "Gain Value is the diff of Current Value and Ip Value" );
                Log.message( "Ip Level and Current Level fields are Validated Successfully" );
            }
        }

        return status;
    }

    // Validating the Error Message and Exception
    public Boolean validateErrorANDExceptionMessage( HashMap<String, String> response, String errorMessage, String exceptionMessage, String statusCode ) {
        Boolean status = false;
        JSONObject jsonObject = new JSONObject( response.get( Constants.REPORT_BODY ) );
        JSONArray array4 = jsonObject.getJSONArray( Constants.REPORT_MESSAGES );
        String exception = array4.getJSONObject( 0 ).get( Constants.EXCEPTION ).toString();
        String message = array4.getJSONObject( 0 ).get( Constants.REPORT_MESSAGE_VALUE ).toString();
        if ( exception.equals( exceptionMessage ) && message.equals( errorMessage ) && response.get( Constants.STATUS_CODE ).equals( statusCode ) ) {
            status = true;
        }
        return status;
    }

}