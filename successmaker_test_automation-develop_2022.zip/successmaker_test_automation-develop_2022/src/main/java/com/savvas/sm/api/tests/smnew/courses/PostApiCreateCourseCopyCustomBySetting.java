package com.savvas.sm.api.tests.smnew.courses;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;

public class PostApiCreateCourseCopyCustomBySetting extends CourseAPI {

    private String smUrl;
    private String teacherDetails = null;
    private String flexSchoolTeacherDetails = null;
    private String mathSchoolTeacherDetails = null;
    private String readingSchoolTeacherDetails = null;
    private String focusReadingSchoolTeacherDetails = null;
    private String focusMathSchoolTeacherDetails = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String readingSchool = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String focusMathSchool = RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL );
    private String focusReadingSchool = RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL );
    private String token = null;
    String schoolType = null;
    String customCourseId = null;
    String customCourseId1 = null;
    String sessionLengthName = null;
    Long sessionLengthId = null;
    String sessionLengthValue = null;
    String idleTimeName = null;
    Long idleTimeId = null;
    String idleTimeValue = null;

    @BeforeClass(alwaysRun=true)
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        mathSchoolTeacherDetails = RBSDataSetup.getMyTeacher( mathSchool );
        readingSchoolTeacherDetails = RBSDataSetup.getMyTeacher( readingSchool );
        focusMathSchoolTeacherDetails = RBSDataSetup.getMyTeacher( focusMathSchool );
        focusReadingSchoolTeacherDetails = RBSDataSetup.getMyTeacher( focusReadingSchool );

    }

    @Test ( priority = 1, dataProvider = "postCustomBySettingPositiveScenarios", groups = { "SMK-52109", "Course", "PostApiCreateCourseCopyCustomBySetting", "P1", "API", "smoke_test_case" } )
    public void createCourseCustomBySettingPositiveScenarios( String description, String scenario, String scenario1, String statusCode, String courseId, String productDescription ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> apiResponse1 = new HashMap<>();
        HashMap<String, String> courseDetails = new HashMap<>();
        HashMap<String, String> customcourseDetails = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();
        Map<String, String> apiResponseForGetCourseListPresentOnDashboard = new HashMap<>();
        String reponseDataForValidation;

        switch( scenario1 ) {
            case "FLEX":
              //Authorization
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( flexSchool ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" ) );

                //Get course details
                courseDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                courseDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" ) );
                courseDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
                courseDetails.put( Constants.COURSE_NAME, "Settings" + System.nanoTime() );
                courseDetails.put( Constants.CONTENT_BASE_ID, Constants.SETTINGS_CONTENT_BASE_ID );

                apiResponse = createCourseBySetting( smUrl, headers, courseDetails, scenario );
                Log.message( "response from PostCall for valid auth- " + apiResponse );
                break;
                
            case "MATHLICENSE":
                //Authorization
                  tokenCreation( CommonAPIConstants.MATH_LICENSE_SCHOOL );

                  headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                  headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                  headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                  headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( mathSchool ) );
                  headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, "userId" ) );

                  //Get course details
                  courseDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                  courseDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, "userId" ) );
                  courseDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
                  courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
                  courseDetails.put( Constants.COURSE_NAME, "Settings" + System.nanoTime() );
                  courseDetails.put( Constants.CONTENT_BASE_ID, Constants.SETTINGS_CONTENT_BASE_ID );

                  apiResponse = createCourseBySetting( smUrl, headers, courseDetails, scenario );
                  Log.message( "response from PostCall for valid auth- " + apiResponse );
                  break;
                  
            case "READINGLICENSE":
                //Authorization
                  tokenCreation( CommonAPIConstants.READING_LICENSE_SCHOOL );

                  headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                  headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                  headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                  headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( readingSchool ) );
                  headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, "userId" ) );

                  //Get course details
                  courseDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                  courseDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, "userId" ) );
                  courseDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( readingSchool ) );
                  courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
                  courseDetails.put( Constants.COURSE_NAME, "Settings" + System.nanoTime() );
                  courseDetails.put( Constants.CONTENT_BASE_ID, Constants.SETTINGS_CONTENT_BASE_ID );

                  apiResponse = createCourseBySetting( smUrl, headers, courseDetails, scenario );
                  Log.message( "response from PostCall for valid auth- " + apiResponse );
                  break;
                  
            case "FLEX_CREATCOUSR_OUTOFCUSTOMCOURSE":
                //Authorization
                  tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                  headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                  headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                  headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                  headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( flexSchool ) );
                  headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" ) );

                  //Get course details
                  courseDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                  courseDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" ) );
                  courseDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                  courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
                  courseDetails.put( Constants.COURSE_NAME, "Settings" + System.nanoTime() );
                  courseDetails.put( Constants.CONTENT_BASE_ID, Constants.SETTINGS_CONTENT_BASE_ID );

                  apiResponse1 = createCourseBySetting( smUrl, headers, courseDetails, scenario );
                  Log.message( "response from PostCall for valid auth- " + apiResponse1 );
                  customCourseId = SMUtils.getKeyValueFromResponse( apiResponse1.get( Constants.REPORT_BODY ), "data,id" );
                  
                  HashMap<String, String> courseSettings = new HashMap<>();
                  HashMap<String, String> apiResponseGetSettings = new HashMap<>();
                  
                  courseSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                  courseSettings.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" ) );
                  courseSettings.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                  
                  apiResponseGetSettings = getCoursesSettings( smUrl, courseSettings, "false", customCourseId );
                  Log.message( "Get Settings : " + apiResponseGetSettings );

                  JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj( apiResponseGetSettings.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

                  JSONObject data2 = getSettingsResp.getJSONObject( CourseAPIConstants.SESSION_LENGTH );
                  sessionLengthName = data2.getString( CourseAPIConstants.NAME );
                  sessionLengthId = data2.getLong( CourseAPIConstants.ID );
                  sessionLengthValue = data2.getString( CourseAPIConstants.CURRENT_VALUE );
                  Log.message( "Name of the session length : " + sessionLengthName );
                  Log.message( "Id of the session length : " + sessionLengthId );
                  Log.message( "CurrentValue of the session length : " + sessionLengthValue );

                  JSONObject data3 = getSettingsResp.getJSONObject( CourseAPIConstants.IDLE_TIME );
                  idleTimeName = data3.getString( CourseAPIConstants.NAME );
                  idleTimeId = data3.getLong( CourseAPIConstants.ID );
                  idleTimeValue = data3.getString( CourseAPIConstants.CURRENT_VALUE );
                  Log.message( "Name of the idleTime : " + idleTimeName );
                  Log.message( "Id of the idleTime : " + idleTimeId );
                  Log.message( "CurrentValue of the idleTime : " + idleTimeValue );

                  courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( sessionLengthId ) );
                  courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName );
                  courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
                  courseSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
                  courseSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
                  courseSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue );
                  
                  courseDetails.put( CourseAPIConstants.COURSE_ID, customCourseId );
                  courseDetails.put( Constants.COURSE_NAME, "Settings" + System.nanoTime() );
                  
                  apiResponse = createCourseBySettingOutOfCustomCourse( smUrl, headers, courseDetails, courseSettings, scenario );
                  Log.message( "response from PostCall for valid auth- " + apiResponse );
                  
                  break;      
        }
        
                //Assertion
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

                //Get courses present at teacher UI home page
                apiResponseForGetCourseListPresentOnDashboard = getCoursesAtOrgLevelTeacherUi( schoolType );
                //Commenting this line cause of heap space issue
                //Log.message( "Returned API Response - " + apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ) );

                //Getting the subject name
                reponseDataForValidation = SMUtils.getKeyValueFromResponse( apiResponseForGetCourseListPresentOnDashboard.get( Constants.REPORT_BODY ), Constants.DATA );

                //Assertion
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataForValidation, Constants.ID, SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID ) ),
                        "Expected course ID is present in the response", "Expected course ID is absent in the response" );


    }

    @Test ( priority = 1, dataProvider = "postCustomBySettingNegativeScenarios", groups = { "SMK-53109", "Course", "GetSkillsHierarchy", "P2", "API" } )
    public void createCourseCustomBySettingNegativeScenarios( String description, String scenario, String scenario1, String statusCode, String courseId, String exception ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> courseDetails = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();

        switch ( scenario1 ) {

            case "FOCUSMATHLICENSE":
                //Authorization
                tokenCreation( CommonAPIConstants.FOCUS_MATH_LICENSE_SCHOOL );

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( focusMathSchool ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( focusMathSchoolTeacherDetails, "userId" ) );

                //Get course details
                courseDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                courseDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( focusMathSchoolTeacherDetails, "userId" ) );
                courseDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( focusMathSchool ) );
                courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
                courseDetails.put( Constants.COURSE_NAME, "Settings" + System.nanoTime() );
                courseDetails.put( Constants.CONTENT_BASE_ID, Constants.SETTINGS_CONTENT_BASE_ID );

                apiResponse = createCourseBySetting( smUrl, headers, courseDetails, scenario );
                Log.message( "response from PostCall for valid auth- " + apiResponse );

                break;

            case "FOCUSREADINGLICENSE":
                //Authorization
                tokenCreation( CommonAPIConstants.FOCUS_READING_LICENSE_SCHOOL );

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( focusReadingSchool ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( focusReadingSchoolTeacherDetails, "userId" ) );

                //Get course details
                courseDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                courseDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( focusReadingSchoolTeacherDetails, "userId" ) );
                courseDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( focusReadingSchool ) );
                courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
                courseDetails.put( Constants.COURSE_NAME, "Settings" + System.nanoTime() );
                courseDetails.put( Constants.CONTENT_BASE_ID, Constants.SETTINGS_CONTENT_BASE_ID );

                apiResponse = createCourseBySetting( smUrl, headers, courseDetails, scenario );
                Log.message( "response from PostCall for valid auth- " + apiResponse );

                break;

            case "FLEXLICENSE":
                //Authorization
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

                if ( scenario.equalsIgnoreCase( "INVALID_AUTHORIZATION" ) ) {
                    headers.put( Constants.AUTHORIZATION, CourseAPIConstants.INVALID_AUTHORIZATION_ID );
                } else {
                    headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                }
                if ( scenario.equalsIgnoreCase( "WITHOUT_ORG" ) ) {
                    headers.put( Constants.ORGID_SM_HEADER, CourseAPIConstants.EMPTY_ORG_ID );
                } else {
                    headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( flexSchool ) );
                }
                if ( scenario.equalsIgnoreCase( "INVALID_STAFF_ID_READING" ) ) {
                    headers.put( Constants.USERID_SM_HEADER, CourseAPIConstants.INVALID_STAFF_ID_RANDOM );
                } else if ( scenario.equalsIgnoreCase( "WITHOUT_STAFF_ID" ) ) {
                    headers.put( Constants.USERID_SM_HEADER, CourseAPIConstants.NULL_STAFF_ID );
                } else {
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                }

                //Get course details
                if ( scenario.equalsIgnoreCase( "INVALID_AUTHORIZATION" ) ) {
                    courseDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CourseAPIConstants.INVALID_AUTHORIZATION_ID );
                } else {
                    courseDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                }
                courseDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );

                if ( scenario.equalsIgnoreCase( "INVALID_ORG_ID_READING" ) ) {
                    courseDetails.put( CourseAPIConstants.ORG_ID, CourseAPIConstants.INVALID_ORGANIZATION_ID );
                } else {
                    courseDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                }
                courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
                
                if ( scenario.equalsIgnoreCase( "DUPLICATE_COURSE_NAME" ) ) {
                    courseDetails.put( Constants.COURSE_NAME, "math" );
                } else if ( scenario.equalsIgnoreCase( "EMPTY_COUTSE_NAME" ) ) {
                    courseDetails.put( Constants.COURSE_NAME, "" );

                } else if ( scenario.equalsIgnoreCase( "NULL_COURSE_NAME" ) ) {
                    courseDetails.put( Constants.COURSE_NAME, "" );

                } else {
                    courseDetails.put( Constants.COURSE_NAME, "Settings" + System.nanoTime() );
                }
                if ( scenario.equalsIgnoreCase( "INVALID_CONTENT_BASE" ) ) {
                    courseDetails.put( Constants.CONTENT_BASE_ID, Constants.INVALID_CONTENT_BASE_ID );
                } else {
                    courseDetails.put( Constants.CONTENT_BASE_ID, Constants.SETTINGS_CONTENT_BASE_ID );
                }

                apiResponse = createCourseBySettingNegaticeScenarios( smUrl, headers, courseDetails, scenario );
                Log.message( "response from PostCall for valid auth- " + apiResponse );

                break;

        }

        //Assertion
        if(description.equals("TC020_Verify the status code is 400 when we hit the API without Course id")) {
        	 Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                     "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
        }else {
       
        Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
        }

    }

    /**
     * Data provider for Custom Course positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "postCustomBySettingPositiveScenarios" )
    public Object[][] createCourseCustomBySettingPositive() {

        Object[][] inputData = {
                { "TC001_Verify the status code is 201 when valid Org id is used, TC006_Verify the status code is 201 when Org is having Flex licence and when give valid Math Course Id, "
                        + "TC014_Verify the status code is 201 when Org is having Flex licence and when give valid staff id," + " TC021_Verify the response 201 When we pass valid \"newCourseName\" in request body,"
                        + " TC027_Verify the response 201 When we pass valid value for  \"contentBaseTypeId\" in request body", "Math", "FLEX", "201", "1", "null" },
                { "TC002_Verify the status code is 201 when Org is having only Math licence and when give valid Math Course Id", "MATH_LICENSEONLY", "MATHLICENSE", "201", "1", "null" },
                { "TC003_Verify the status code is 201 when Org is having only Reading licence and when give valid Reading Course Id", "READING_LICENSEONLY", "READINGLICENSE", "201", "2", "null" },
                { "TC007_Verify the status code is 201 when Org is having Flex licence and when give valid Reading Course Id.", "READING", "FLEX", "201", "2", "null" },
                { "TC0010_Verify the status code is 201 when Org is having Flex licence and when give valid CustomMath Course Id", "Math", "FLEX_CREATCOUSR_OUTOFCUSTOMCOURSE", "201", "1", "null" },
                { "TC011_Verify the status code is 201 when Org is having Flex licence and when give valid CustomReading Course Id", "READING", "FLEX_CREATCOUSR_OUTOFCUSTOMCOURSE", "201", "2", "null" }, };
        return inputData;
    }

    /**
     * Data provider for Custom Course negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "postCustomBySettingNegativeScenarios" )
    public Object[][] createCourseCustomBySettingNegative() {

        Object[][] inputData = {
                { "TC004_Verify the status code is 400 when Org is having only FocusMath licence and when give valid FocusMath Course Id", "INVALID_MATH_LICENSE", "FOCUSMATHLICENSE", "400", "3",
                        "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC005_Verify the status code is 400 when Org is having only FocusReading licence and when give valid FocusReading Course Id", "INVALID_READING_LICENSE", "FOCUSREADINGLICENSE", "400", "11",
                        "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC008_Verify the status code is 400 when Org is having Flex licence and when give valid FocusMath Course Id", "Valid Authorization", "FLEXLICENSE", "400", "3", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC009_Verify the status code is 400 when Org is having Flex licence and when give valid FocusReading Course Id", "Valid Authorization", "FLEXLICENSE", "400", "11", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC0012_Verify the status code is 200 when Org is having Flex licence and when give already deleted Course Id", "Valid Authorization", "FLEXLICENSE", "200", "132", "com.savvas.core.exceptions.DataNotFoundException" },
                { "TC015_Verify the status code is 400 when the invalid organization Id is given.", "INVALID_ORG_ID_READING", "FLEXLICENSE", "400", "1", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC016_Verify the status code is 403 when we hit the API without Org id", "WITHOUT_ORG", "FLEXLICENSE", "403", "1", "org.springframework.security.access.AccessDeniedException" },
                { "TC017_Verify the status code is 401 when the invalid staff Id is given.", "INVALID_STAFF_ID_READING", "FLEXLICENSE", "401", "1", "java.lang.Exception" },
                { "TC018_Verify the status code is 401 when we hit the API without staff id", "WITHOUT_STAFF_ID", "FLEXLICENSE", "401", "1", "java.lang.Exception" },
                { "TC019_Verify the status code is 400 when the invalid Course Id is given.", "Valid Authorization", "FLEXLICENSE", "400", "we", "org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
                { "TC020_Verify the status code is 400 when we hit the API without Course id", "Valid Authorization", "FLEXLICENSE", "400", "", "org.springframework.web.bind.MissingPathVariableException" },

                { "TC022_Verify the response 400 When we pass duplicate value for \"newCourseName\" in request body for Reading", "DUPLICATE_COURSE_NAME", "FLEXLICENSE", "400", "1", "com.savvas.core.exceptions.BusinessRuleViolationException" },

                { "TC025_Verify the response 400 When we don't pass \"newCourseName\" in request body", "EMPTY_COUTSE_NAME", "FLEXLICENSE", "400", "1", "com.pst.exceptions.ValidationException" },
                { "TC026_Verify the response 400 When we pass value as null for \"newCourseName\" in request body", "NULL_COURSE_NAME", "FLEXLICENSE", "400", "1", "com.pst.exceptions.ValidationException" },

                { "TC029_Verify the response 400 When we pass value as null for \"contentBaseTypeId\" in request body", "INVALID_CONTENT_BASE", "FLEXLICENSE", "400", "1", "com.savvas.core.exceptions.BusinessRuleViolationException" },
                { "TC030_Verify the response 400 When we pass invalid authorization.", "INVALID_AUTHORIZATION", "FLEXLICENSE", "400", "1", "java.lang.Exception" },

        };
        return inputData;
    }
    
    /**
     * Token creation
     * 
     * @param school
     */
    public void tokenCreation( String school ) {
        try {
            switch ( school ) {
                case CommonAPIConstants.FLEX_LICENSE_SCHOOL:
                    schoolType = flexSchool;
                    teacherDetails = flexSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.MATH_LICENSE_SCHOOL:
                    schoolType = mathSchool;
                    teacherDetails = mathSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.READING_LICENSE_SCHOOL:
                    schoolType = readingSchool;
                    teacherDetails = readingSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.FOCUS_MATH_LICENSE_SCHOOL:
                    schoolType = focusMathSchool;
                    teacherDetails = focusMathSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.FOCUS_READING_LICENSE_SCHOOL:
                    schoolType = focusReadingSchool;
                    teacherDetails = focusReadingSchoolTeacherDetails;
                    break;
            }
            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Error occurred in the token creation. Please check!!" );
        }
    }

    /**
     * Verifying the Exception information
     * 
     * @param actualResponse
     * @param exception
     * @return boolean
     * @throws IOException
     */
    public boolean verifyExceptionMessage( String actualResponse, String exception ) throws IOException {

        boolean flag = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.message( "Exception Verified successfully!" );
            flag = true;
        } else {
            Log.message( "Issue in displaying exception!" );
        }
        return flag;
    }

    /**
     * Get response for the Create Course By Setting API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySetting( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySetting= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "READING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsReadingPayload" ) ) );

            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsMathPayload" ) ) );
            }

            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );

            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySetting method" );
            return null;
        }
    }

    /**
     * Get response for the Create Course By Setting API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySettingNegaticeScenarios( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySetting= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "READING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsReadingPayload2" ) ) );

            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsMathPayload2" ) ) );
            }

            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( Constants.CONTENT_BASE_ID_PAYLOAD, courseDetails.get( Constants.CONTENT_BASE_ID ) ) );

            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySetting method" );
            return null;
        }
    }
    
    /**
     * Get response for the Create Course By Setting API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySettingOutOfCustomCourse( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, HashMap<String, String> courseSettings, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySetting= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "READING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsReadingPayload3" ) ) );

            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsMathPayload3" ) ) );
            }

            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( Constants.CONTENT_BASE_ID_PAYLOAD, courseDetails.get( Constants.CONTENT_BASE_ID ) ) );
            requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_ID, courseSettings.get( CourseAPIConstants.SESSION_STRENGTH_ID ) ) );
            requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_NAME, courseSettings.get( CourseAPIConstants.SESSION_STRENGTH_NAME ) ) );
            requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_VALUE, courseSettings.get( CourseAPIConstants.SESSION_STRENGTH_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.IDLE_TIME_ID, courseSettings.get( CourseAPIConstants.IDLE_TIME_ID ) ) );
            requestBody.set( requestBody.get().replace( Constants.IDLE_TIME_NAME, courseSettings.get( CourseAPIConstants.IDLE_TIME_NAME ) ) );
            requestBody.set( requestBody.get().replace( Constants.IDLE_TIME_VALUE, courseSettings.get( CourseAPIConstants.IDLE_TIME_VALUE ) ) );

            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySetting method" );
            return null;
        }
    }

    /**
     * Get courses present at teacher UI home page
     * 
     * @param school
     * 
     * @return apiResponse
     */
    public Map<String, String> getCoursesAtOrgLevelTeacherUi( String school ) {
        Map<String, String> apiResponse = new HashMap<>();
        Map<String, String> dashboardCourseListDetails = new HashMap<>();
        try {
            dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            apiResponse = getCoursesAtOrgLevel( smUrl, dashboardCourseListDetails );
        } catch ( Exception e ) {
            Log.message( "Error occurred in while getting the courses from the dashboard of Teacher UI. Please check!!" );
        }
        return apiResponse;
    }
}
