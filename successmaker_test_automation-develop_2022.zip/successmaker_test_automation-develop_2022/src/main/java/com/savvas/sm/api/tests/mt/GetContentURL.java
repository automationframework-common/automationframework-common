package com.savvas.sm.api.tests.mt;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.ReportAPIConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

public class GetContentURL extends UserAPI {
	String smUrl;
	Map<String, String> response;
	String districtID;

	@BeforeClass ( alwaysRun = true )
	public void beforeTest() throws Exception {
		smUrl = configProperty.getProperty( "SMAppUrl" );
		districtID = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
	}
	@Test ( dataProvider ="getData", groups = { "SMK-70101", "Get Content URL", "API" ,"P1"}, priority = 1 )
	public void getContentUrlTest( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
		HashMap<String, String> headers = new HashMap<>();
		HashMap<String, String> inputParams = new HashMap<>();

		Log.testCaseInfo( testcaseName + testcaseDescription );

		//Test Data
		String authorization = "Basic dXNlcjE6dXNlcjFwYXNz";
		String endPoint = ReportAPIConstants.GET_CONTENT_SERVER_URL;

		switch ( scenarioType ) {
		case "VALID INPUTS":
			headers.put(ReportAPIConstants.AUTHORISATION, authorization);
			headers.put(Constants.ORGID_SM_HEADER, districtID);
			response = RestHttpClientUtil.GET( smUrl,endPoint, headers, inputParams );
			break;

		case "INVALID AUTH":
			headers.put(ReportAPIConstants.AUTHORISATION, authorization + "123");
			headers.put(Constants.ORGID_SM_HEADER, districtID);
			response = RestHttpClientUtil.GET( smUrl,endPoint, headers, inputParams );
			break;

		case "INVALID ORG":
			headers.put(ReportAPIConstants.AUTHORISATION, authorization);
			headers.put(Constants.ORGID_SM_HEADER, districtID + "1q2w3");
			response = RestHttpClientUtil.GET( smUrl,endPoint, headers, inputParams );
			break;

		case "EMPTY ORG":
			headers.put(ReportAPIConstants.AUTHORISATION, authorization);
			response = RestHttpClientUtil.GET( smUrl,endPoint, headers, inputParams );
			break;

		case "EMPTY AUTH":
			headers.put(Constants.ORGID_SM_HEADER, districtID);
			response = RestHttpClientUtil.GET( smUrl,endPoint, headers, inputParams );
			break;

		case "DIFF ORG":
			headers.put(ReportAPIConstants.AUTHORISATION, authorization);
			headers.put(Constants.ORGID_SM_HEADER, ReportAPIConstants.differentDistrictID);
			response = RestHttpClientUtil.GET( smUrl,endPoint, headers, inputParams );
			break;
		}

		Log.message( "Response:- " + response.get( Constants.RESPONSE_BODY ) );
		// Validation
		Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
				"The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
		Log.testCaseResult();
		Log.endTestCase();
	}
	@DataProvider
	public Object[][] getData() {
		return new Object[][] { { "TC001", "200", "Verify that the status code is 200 and response is as excpected when passing valid inputs","VALID INPUTS" },
			{ "TC002", "403", "Verify 403: Forbidden message in response when invalid authorization is given","INVALID AUTH" },
			{ "TC003", "404", "Verify 404 status code and response when invalid organizationId is given","INVALID ORG" },
			{ "TC004", "400", "Verify 400 status code and response when org-id header parameter is not given","EMPTY ORG" },
			{ "TC005", "401", "Verify 401 status code in response when empty authorization is given","EMPTY AUTH" },
			{ "TC006", "404", "Verify 404 status code and response when different organizationId is given","DIFF ORG" }
		};
	}
}
