package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class UpdateReadingLessonComplete extends AssignmentAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String stuFName;
    private String stuLName;
    private String assignmentLevel;
    private String rewardCoursePoints;
    private String assignmentID;
    RBSUtils rbsutils = new RBSUtils();
    private String studentDetail;
    private String studentUserID;
    private String studentUsername;
    private String courseName;
    Map<String, String> response = new HashMap<>();
    Map<String, String> assignmentResponse = new HashMap<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        stuFName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ).toString();
        stuLName = SMUtils.getKeyValueFromResponse( studentDetail, "lastName" ).toString();
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( dataProvider = "positiveData", priority = 1, groups = { "SMK-66850", "smoke_test_case", "P1", "API" } )
    public void updateReadingLessonComplete( String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupdetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentUserID );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );

        String CourseId;
        switch ( scenario ) {
            case "Default Reading":
                courseName = Constants.READING;
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                String accessToken = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId );
                String reCl = "3.367";
                String assl = "4.302";
                SMUtils.logDescriptionTC( "Verify the Response code is 200 while completing Reading lesson" );

                lunchCourse( studentUsername, courseName, "100", "1", "60" );

                String sessionId = SqlHelperAssignment.getSessionId( assignmentUserId );
                Log.message( "SessionId : " + sessionId );

                response = updateReadingLesson( orgId, studentUserID, accessToken, assignmentUserId, sessionId, stuFName, stuLName, reCl, assl );
                Log.message( "Response = " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the same is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                rewardCoursePoints = getRewardCourseLevel( assignmentUserId );
                Log.message( "RewardCourseLevel :" + rewardCoursePoints.toString() );

                break;

            case "Custom Setting Reading":
                courseName = "CustomSettingReading" + System.nanoTime();
                CourseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( courseName ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                String accessToken1 = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( "assignmentResponse=" + assignmentResponse );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                String assignmentUserId2 = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                Log.message( "assignmentUserId =" + assignmentUserId2 );
                String reCl1 = "5.367";
                String assl1 = "4.302";
                SMUtils.logDescriptionTC( "Verify the Response code is 200 while completing Reading lesson with CustomBySettings course and IP OFF" );

                lunchCourse( studentUsername, courseName, "100", "1", "60" );

                String sessionId1 = SqlHelperAssignment.getSessionId( assignmentUserId2 );
                Log.message( "SessionId : " + sessionId1 );

                response = updateReadingLesson( orgId, studentUserID, accessToken1, assignmentUserId2, sessionId1, stuFName, stuLName, reCl1, assl1 );
                Log.message( "Response = " + response );
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Status code is returned as expected and the same is " + response.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                rewardCoursePoints = getRewardCourseLevel( assignmentUserId2 );
                Log.message( "RewardCourseLevel :" + rewardCoursePoints );
                break;

            default:
                break;
        }
    }

    public HashMap<String, String> updateReadingLesson( String orgId, String studentUserId, String accessToken, String assignmentUserId, String sessionId, String stuFName, String stuLName, String reCl, String assl ) {
        try {
            // headersassignmentUserId
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.USERID_SM_HEADER, studentUserId );
            headers.put( Constants.SESSIONID_HEADER, sessionId );
            headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );

            HashMap<String, String> params = new HashMap<>();

            // Input Path Parameters
            String endPoint = Constants.UPDATE_READING_COMPLETE;

            endPoint = endPoint.replace( "{assignmentuserId}", assignmentUserId );

            String requestBody = GetRequestBody( assignmentUserId, stuFName, stuLName, reCl, assl );
            HashMap<String, String> response = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, requestBody );

            return response;
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    @DataProvider ( name = "positiveData" )
    public Object[][] positiveData() {
        Object[][] data = { { "TC01 Verify the valid response to Default Reading", "Default Reading", CommonAPIConstants.STATUS_CODE_OK },
                { "TC02 Verify the valid response to Custom Setting Reading", "Custom Setting Reading", CommonAPIConstants.STATUS_CODE_OK }, };
        return data;
    }

    /**
     * This method is used to select the course based on courseName.
     *
     * @param studentUserName
     * @param courseName
     */
    public void selectCourse( String studentUserName, String courseName ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );

        Log.message( "Student username :" + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentPage = new StudentDashboardPage( driver );
        studentPage.selectAssignmentByName( courseName );
    }

    /**
     * To execute the course
     *
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void lunchCourse( String studentUserName, String courseName, String percentage, String numberOfSession, String loCount ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );

        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
        studentsPage.lunchReadingCourse( studentUserName, courseName, percentage, numberOfSession, loCount );

    }

    public String GetRequestBody( String auId, String stuFName, String stuLName, String reCl, String assl ) throws Exception {
        String payload = null;

        payload = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "updateReadingLessionComplete.json" );
        payload = payload.replace( "auId", auId );
        payload = payload.replace( "FName", stuFName );
        payload = payload.replace( "LName", stuLName );
        payload = payload.replace( "reCl", reCl );
        payload = payload.replace( "assl", assl );

        Log.message( "Payload is : " + payload );
        return payload;
    }

    /**
     * This method is used to get reward course level of a student.
     * 
     * @param assignmentUserID
     */
    public String getRewardCourseLevel( String assignmentUserID ) {
        String rewardPoints = null;
        String queryString = "SELECT reward_course_level FROM school.assignment_user where assignment_user_id =" + assignmentUserID;
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list.toString() );
            }
        }
        rewardPoints = arrList.toString();
        return rewardPoints;
    }

    /**
     * This method is used to get assignment current level course level of a
     * student.
     * 
     * @param assignmentUserID
     */
    public String getassignmentCurrentLevel( String assignmentUserID ) {
        String assignmentCurrentLevel = null;
        String queryString = "SELECT assignment_current_level  FROM school.assignment_user where assignment_user_id =" + assignmentUserID;
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        assignmentCurrentLevel = arrList.get( 0 );
        return assignmentCurrentLevel;
    }

}
