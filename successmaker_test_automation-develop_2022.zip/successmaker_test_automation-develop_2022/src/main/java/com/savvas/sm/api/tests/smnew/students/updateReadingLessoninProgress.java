package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import io.restassured.response.Response;

public class updateReadingLessoninProgress extends EnvProperties {
	private static List<String> studentRumbaIds = new ArrayList<>();
	private String smUrl;
	private String browser;
	private String teacherDetails;
	private String orgId;
	private String teacherId;
	private String assignmentUserId;
	private String teacherUserName;
	private static String studentDetails1 = null;
	private static String studentUserName1, studentUserId1;
	private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
	private static HashMap<String, String> assignmentDetails = new HashMap<>();
	private static Map<String, String> contentBase = new HashMap<>();
	private static Map<String, String> contentBaseName = new HashMap<>();
	private static Map<String, String> assignmentIds = new HashMap<>();

	private List<String> courseIDs = new ArrayList<>();
	private HashMap<String, String> groupDetails = new HashMap<>();
	HashMap<String, String> assignmentResponse = new HashMap<>();

	 @BeforeClass ( alwaysRun = true )
	public void BeforeTest() throws Exception {

		smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
		browser = configProperty.getProperty( "BrowserPlatformToRun" );

		teacherDetails = RBSDataSetup.getMyTeacher( school );
		orgId = RBSDataSetup.organizationIDs.get( school );
		teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
		teacherUserName = SMUtils.getKeyValueFromResponse(teacherDetails, "userName");

		studentDetails1 = RBSDataSetup.getMyStudent(school, teacherUserName);
		studentUserId1 = SMUtils.getKeyValueFromResponse(studentDetails1, "userId");
		studentUserName1 = SMUtils.getKeyValueFromResponse(studentDetails1, "userName");

		studentRumbaIds.add( studentUserId1 );

		String token = new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );

		groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
		groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );

		assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
		assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
		assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

		Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

		contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
		contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
		contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
		contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
		
		Log.message( "contentbasename" + contentBaseName );
		contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
		contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE,
				new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
		contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
				new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
		contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE,
				new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.STANDARD, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );
		
		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );
		
		Log.message( "Assigning assignment..." );
		assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
		Log.message( "Assignment Details" + assignmentResponse );
		JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
		JSONArray assignmentList =  assignmentDetailsJson.getJSONArray( Constants.DATA );

		for ( Object assignment : assignmentList ) {
			JSONObject assignmentInfo = new JSONObject( assignment.toString() );
			assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
		}
		Log.message( "Assignment IDs - " + assignmentIds );
	}

	@Test ( priority = 1, dataProvider = "studentUsagePositive", groups = { "SMK-51977", "Students", "Assignment in progress", "P1", "API" ,"smoke_test_case" } )
	public void tcPositiveTestcases( String scenario, String description, String statusCode ) throws Throwable {
		Log.testCaseInfo( description );

		Map<String, String> headers = new HashMap<>();
		Map<String, String> response = new HashMap<>();
		String sessionID;
		String token;
		String payload;
		String actualstatuscode;
		
		switch ( scenario ) {
		case "VALID_DEFAULT_COURSE":
			token = new RBSUtils().getAccessToken( studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD ) ;
			executeCourse( studentUserName1, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
			assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId1, assignmentIds.get( contentBaseName.get( Constants.READING ) ) );
			payload = getPayload( smUrl, studentUserId1, orgId, studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD, assignmentUserId );
			sessionID = getSessionId( smUrl, studentUserId1, orgId, studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD, assignmentUserId );
			headers.put( "session-id", sessionID );
			response = ipmReadingCompletePUT(smUrl , studentUserId1, orgId, studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD, assignmentUserId, token, sessionID, payload);
			Log.message( response.get(Constants.RESPONSE_BODY).toString() );

			//Status code validation
			actualstatuscode = response.get(Constants.STATUS_CODE);
			Log.assertThat( actualstatuscode.equalsIgnoreCase(statusCode), "The actual status code " + response.get(Constants.STATUS_CODE) + "is the same as expected status code " + statusCode,
					"The actual status code " + response.get(Constants.STATUS_CODE) + "is not the same as expected status code " + statusCode );
			break;

		case "VALID_CUSTOM_BY_SETTING":
			token = new RBSUtils().getAccessToken( studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD ) ;
			executeCourse( studentUserName1, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false );
			assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId1, assignmentIds.get( contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
			payload = getPayload( smUrl, studentUserId1, orgId, studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD, assignmentUserId );
			sessionID = getSessionId( smUrl, studentUserId1, orgId, studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD, assignmentUserId );
			headers.put( "session-id", sessionID );
			response = ipmReadingCompletePUT(smUrl , studentUserId1, orgId, studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD, assignmentUserId, token, sessionID, payload);
			Log.message( response.get(Constants.RESPONSE_BODY).toString() );

			//Status code validation
			actualstatuscode = response.get(Constants.STATUS_CODE);
			Log.assertThat( actualstatuscode.equalsIgnoreCase(statusCode), "The actual status code " + response.get(Constants.STATUS_CODE) + "is the same as expected status code " + statusCode,
					"The actual status code " + response.get(Constants.STATUS_CODE) + "is not the same as expected status code " + statusCode );
			break;
		}
	} 

	@DataProvider ( name = "studentUsagePositive" )
	public Object[][] studentUsagePositive() {

		Object[][] inputData = { { "VALID_DEFAULT_COURSE", "TC01_Verify the status code is 200 when valid data is given for assignment which has been created from Deafult Reading for PUT Method", CommonAPIConstants.STATUS_CODE_OK },
				{ "VALID_CUSTOM_BY_SETTING", "TC02_Verify the status code is 200 when valid data is given for assignment which has been created from Custom Reading(custom by setting) for PUT Method.", CommonAPIConstants.STATUS_CODE_OK },
		};
		return inputData;
	}
	
	/**
	 * To execute the course
	 * 
	 * @param studentUserName
	 * @param courseName
	 * @throws IOException
	 */
	public void executeCourse( String studentUserName, String courseName, boolean isCompleteSimulation ) throws IOException {
		final WebDriver driver = WebDriverFactory.get( browser );
		Log.message( "Student username " + studentUserName );
		LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
		StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

		if ( isCompleteSimulation ) {
			try {
				studentsPage.executeReadingCourse( studentUserName, courseName, "50", "1", "1" );
				studentsPage.logout();
				driver.close();
			} catch ( Exception e ) {
				driver.close();
			}
		} else {
			try {
				studentsPage.executeReadingCourseInProgress( studentUserName, courseName, "50", "1", "1" );
//				studentsPage.logout();
//				driver.close();
			} catch ( Exception e ) {
				driver.close();
			}
		}
	}

    /**
     * To Create and get the session Id for given student
     *
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @return
     */
    public String getSessionId( String smUrl, String userId, String orgId, String studentUsername, String password, String assignmentUserId ) {
        String endPoint1 = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        List<String> pathParamsList = new ArrayList<>();
        HashMap<String, String> header = new HashMap<>();
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( LicenseAPIConstants.USERID, userId );
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        pathParamsList.add( assignmentUserId );
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint1, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, header, endPoint1, pathParams );
        Log.message( response.getBody().asString() );
        String sessionId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "sessionId" );
        Log.message( "Session ID  - " + sessionId );
        return sessionId;
    }

    /**
     * To Create and get the session Id for given student
     *
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @return
     */
    public String getPayload( String smUrl, String userId, String orgId, String studentUsername, String password, String assignmentUserId ) {
        String endPoint1 = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        List<String> pathParamsList = new ArrayList<>();
        HashMap<String, String> header = new HashMap<>();
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( LicenseAPIConstants.USERID, userId );
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        pathParamsList.add( assignmentUserId );
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint1, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, header, endPoint1, pathParams );
        Log.message( response.getBody().asString() );
        String payload = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "motionAssignmentUser" );
        String load = SMUtils.getKeyValueFromResponse(payload, "currentReadingLessonHistory");
        Log.message("Payload - " + load);
        return load;
    }
    
    /**
     * To get IPM complete student completed the assignment
     * 
     * @param smUrl
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @param sessionId
     * @return
     * @throws Throwable 
     */
    public HashMap<String, String> ipmReadingCompletePUT( String smUrl, String userId, String orgId, String studentUsername, String password, String assignemntUserId, String token, String sessionId, String Payload ) throws Throwable {
        String endPoint = "/lms/web/assignments/lessoninprogress/{auId}".replace("{auId}", assignemntUserId );
        Log.message(endPoint);
        String contentType = "application/json";
        String payload = Payload;
        //Parameters
        HashMap<String, String> params = new HashMap<>();
        Map<String, String> header = new HashMap<>();
        header.put( LicenseAPIConstants.USERID, userId );
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( "session-id", sessionId );
        header.put(Constants.AUTHORIZATION, Constants.BEARER + token);
        header.put(Constants.CONTENT_TYPE, contentType);
        
        return RestHttpClientUtil.PUT( smUrl, header, params, endPoint, payload );
       
    }
}