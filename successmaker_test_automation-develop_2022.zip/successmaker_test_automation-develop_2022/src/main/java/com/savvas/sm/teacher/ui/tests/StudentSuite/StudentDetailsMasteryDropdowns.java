package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Students.Mastery_DropDowns;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.HelpPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.sql.helper.SqlHelperMastery;
import com.savvas.sm.utils.sql.helper.StandardVersionTable.StandardVersionMastery;

import LSTFAI.customfactories.EventFiringWebDriver;

public class StudentDetailsMasteryDropdowns extends BaseTest {
    public WebDriver driver;

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    private String teacherId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    List<String> studentIdList = null;
    List<String> studentUserNames = null;

    private AtomicReference<String> schoolUsed = new AtomicReference<>();

    @BeforeClass
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        String teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        ArrayList<String> studentDetails = new ArrayList<>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<>();
        studentUserNames = new ArrayList<>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

    }

    @Test ( description = "Verify Mastery Sub- nav Student view page", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 1 )
    public void tcSMSDMD001() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "tcSMSDMD001: Verify Mastery Sub- nav Student view page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );
            Log.assertThat( studentsTab.isMasteryDisplayed(), "The Mastery sub-navigation is displayed", "The Mastery sub-navigation is not displayed" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Subject filter on Mastery Sub-navigation menu.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 1 )
    public void tcSMSDMD002() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMSDMD002: Verify Subject filter on Mastery Sub-navigation menu. <small><b><i>[" + browser + "]</b></i></small>" );

    	try {
    		smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Verify Subject Drop downs and its values are present
            Log.assertThat( studentsTab.isStaticDropDownPresent( Mastery_DropDowns.SUBJECT ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );
            List<String> subjectDropdownvalues = studentsTab.getDropDownOptions( Mastery_DropDowns.SUBJECT );
            Log.assertThat( studentsTab.verifyDropdownvalues( subjectDropdownvalues, Constants.Students.SUBJECT_DROPDOWN_VALUES ), "The Subject drop down values are displayed and verified", "The Subject drop down values are not displayed and verified" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Skill/Standard drop down, list of items available in the dropdown in the Mastery Sub-navigation menu.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 1 )
    public void tcSMSDMD003() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMSDMD003: Verify Skill/Standard drop down, list of items available in the dropdown in the Mastery Sub-navigation menu. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // get values from Database for Math subject
            List<StandardVersionMastery> listStandardVersionDBMath = SqlHelperMastery.getStandards( Constants.MasteryUI.SUBJECT_MATH );

            // Get Standards name from DB data
            List<String> skillStandardsAvailableDBMath = new ArrayList<>();
            skillStandardsAvailableDBMath.add( Constants.MasteryUI.SKILL_MATH );
            for ( StandardVersionMastery standardVersionMastery : listStandardVersionDBMath ) {
                skillStandardsAvailableDBMath.add( standardVersionMastery.getStandardsName() );
            }
            skillStandardsAvailableDBMath = skillStandardsAvailableDBMath.stream().map( String::toLowerCase ).collect( Collectors.toList() );

            // get values from Database for Reading subject
            List<StandardVersionMastery> listStandardVersionDBReading = SqlHelperMastery.getStandards( Constants.MasteryUI.SUBJECT_READING );

            // Get Standards name from DB data
            List<String> skillStandardsAvailableDBReading = new ArrayList<>();
            for ( StandardVersionMastery standardVersionMastery : listStandardVersionDBReading ) {
                skillStandardsAvailableDBReading.add( standardVersionMastery.getStandardsName() );
            }

            // look for copyright_hexcode and replace as copyright symbol
            skillStandardsAvailableDBReading = skillStandardsAvailableDBReading.stream().map( s -> s.replaceAll( Constants.COPYRIGHT_HEXCODE, Constants.COPYRIGHT_SYMBOL ) ).collect( Collectors.toList() );
            skillStandardsAvailableDBReading = skillStandardsAvailableDBReading.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            skillStandardsAvailableDBReading.add( Constants.MasteryUI.SKILL_READING );

            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Verifying the Math Drop down Skill/Standard values
            Log.assertThat( studentsTab.isStaticDropDownPresent( Mastery_DropDowns.MASTERY_SKILL ), "The Skill/Standard drop down is displayed", "The Skill/Standard drop down is not displayed" );
            List<String> mathoptions = studentsTab.getDropDownOptions( Mastery_DropDowns.MASTERY_SKILL );
            Collections.sort( mathoptions );
            Collections.sort( skillStandardsAvailableDBMath );
            Log.assertThat( mathoptions.equals( skillStandardsAvailableDBMath ), "The Skill/standard drop down Math values are displayed and verified", "The  Skill/standard drop down Math values are not displayed and verified" );

            // Verifying the Reading Drop down Skill/Standard values
            studentsTab.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) );
            List<String> readingoptions = studentsTab.getDropDownOptions( Mastery_DropDowns.MASTERY_SKILL );
            Collections.sort( readingoptions );
            Collections.sort( skillStandardsAvailableDBReading );
            Log.assertThat( skillStandardsAvailableDBReading.equals( skillStandardsAvailableDBReading ), "The Skill/standard drop down Reading values are displayed and verified",
                    "The  Skill/standard drop down Reading values are not displayed and verified" );

            // Verifying the Reading Drop down can able to select one value
            Log.message( skillStandardsAvailableDBReading.get( 1 ) );
            studentsTab.selectDropDownValues( Mastery_DropDowns.MASTERY_SKILL, skillStandardsAvailableDBReading.get( 1 ) );
            String selectedValuesFromDropdown = studentsTab.getSelectedValuesFromDropdown( Mastery_DropDowns.MASTERY_SKILL );
            Log.assertThat( selectedValuesFromDropdown.toLowerCase().equals( skillStandardsAvailableDBReading.get( 1 ).toLowerCase() ),
                    "The given value " + selectedValuesFromDropdown.toLowerCase() + " is selected as " + skillStandardsAvailableDBReading.get( 1 ).toLowerCase(),
                    "The given value is not selected" + selectedValuesFromDropdown.toLowerCase() + " -> " + skillStandardsAvailableDBReading.get( 1 ).toLowerCase() );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Assignments Dropdown on Mastery Sub-nav bar and able to select one value from the drop down.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 1 )
    public void tcSMSDMD004() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMSDMD004: Verify Assignments Dropdown on Mastery Sub-nav bar and able to select one value from the drop down. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );

            // Getting data from Assignments Page
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_ASSIGNMENTS );
            List<String> allAssignments = studentsTab.getAllAssignments();

            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Verify the assignments drop down
            Log.assertThat( studentsTab.isStaticDropDownPresent( Mastery_DropDowns.ASSIGNMENTS ), "The Assignments drop down is displayed", "The Assignments drop down is not displayed" );
            List<String> dropDownOptions = studentsTab.getDropDownOptions( Mastery_DropDowns.ASSIGNMENTS );
            dropDownOptions.remove( 0 ); // for removing select all
            Log.assertThat( allAssignments.containsAll( dropDownOptions ), "All the assignments assigned to the student is displayed", "All the assignments assigned to the student is not displayed" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify removed assignment should not displayed in assignments dropdown.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 1 )
    public void tcSMSDMD005() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMSDMD005:Verify removed assignment should not displayed in assignments dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            String assignmentToDelete = null;

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );

            // Navigate to Mastery Sub-Navigation Menu.
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Getting Assignments from UI
            List<String> dropDownOptions = studentsTab.getDropDownOptions( Mastery_DropDowns.ASSIGNMENTS );

            if ( dropDownOptions.size() > 1 ) {

                // Getting Assignment to delete
                assignmentToDelete = dropDownOptions.get( 1 );

                // Navigate to Courseware tab
                AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

                // Click on Assignment SubMenu
                page.clickAssignmentSubMenu();

                // Click Delete Assignment
                AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( assignmentToDelete );
                assignmentDetailsPage.assignmentLevelEllipsis();
                assignmentDetailsPage.deleteAssignmenttab();
                SMUtils.nap( 2 ); //required for popup load
                assignmentDetailsPage.deleteAssignmentButton();
                Log.assertThat( assignmentDetailsPage.isAssignmentDisplayed(), "Assignment has removed successfully", "Assignment has not removed successfully" );

            } else {
                Log.message( "No Assignments to delete" );
            }

            // Navigate to Students Tab
            studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );

            // Navigate to Mastery Sub-Navigation Menu.
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Getting Assignments from UI
            List<String> dropDownOptionsPostDelete = studentsTab.getDropDownOptions( Mastery_DropDowns.ASSIGNMENTS );

            // Verify the assignment deleted
            Log.assertThat( !dropDownOptionsPostDelete.contains( assignmentToDelete ), "The removed assignment is not displayed", "The removed assignment is displayed" );

            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify group assignments should display, if student is part of group.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 1 )
    public void tcSMSDMD006() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMSDMD006:Verify group assignments should display, if student is part of group. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            String assignmentToGroup = "Math";

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Courseware tab
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( assignmentToGroup );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );

            // Navigate to Mastery Sub-Navigation Menu.
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Getting Assignments from UI
            List<String> dropDownOptions = studentsTab.getDropDownOptions( Mastery_DropDowns.ASSIGNMENTS );

            // Verify the assignment deleted
            Log.assertThat( dropDownOptions.contains( assignmentToGroup ), "The assignment is assigned to the group is displayed", "The assignment is assigned to the group is not displayed" );

            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all fields are available in Student details Mastery Sub-Navigation.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = -1 )
    public void tcSMSDMD007() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMSDMD007:Verify all fields are available in Student details Mastery Sub-Navigation. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            AssignmentsPage navigateToAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentsList = navigateToAssignmentsPage.getAssignmentListBasedOnSubject( Constants.MATH );

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );

            // Navigate to Mastery Sub-Navigation Menu.
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            String assignment = assignmentsList.get( 0 );
            Log.message( assignment );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

            driver.quit();

            // Running Simulator for the simulator to get data in mastery
            executeSimulator( studentID, password, assignment );

            // Login as a teacher to verify the fields in the Student Details -> Mastery
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );

            // Navigate to Mastery Sub-Navigation Menu.
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            Log.assertThat( studentsTab.isStaticDropDownPresent( Mastery_DropDowns.SUBJECT ), "The Subject drop down is displayed", "The Subject drop down is not displayed" );
            Log.assertThat( studentsTab.isStaticDropDownPresent( Mastery_DropDowns.MASTERY_SKILL ), "The Skill/Standard drop down is displayed", "The Skill/Standard drop down is not displayed" );
            Log.assertThat( studentsTab.isStaticDropDownPresent( Mastery_DropDowns.ASSIGNMENTS ), "The Assignments drop down is displayed", "The Assignments drop down is not displayed" );

            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.LEGENDS ), "The Legends are displayed in the mastery Page", "The Legends are not displayed in the mastery Page" );
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.TOPLEVELHIERARCY ), "The Top Level Hierarcy are displayed in the mastery Page", "The Top Level Hierarcy are not displayed in the mastery Page" );
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.MIDDLELEVELHIERARCY ), "The Middle Level Hierarcy are displayed in the mastery Page", "The Middle Level Hierarcy are not displayed in the mastery Page" );
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.LEAFNODEHIERARCY ), "The Leaf nodes are displayed in the mastery Page", "The Leaf nodes are not displayed in the mastery Page" );
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.LODESCRIPTION ), "The LO and Descriptions are displayed in the mastery Page", "The LO and Descriptions are not displayed in the mastery Page" );
            Log.assertThat( studentsTab.checkElementPresence( Constants.Students.PROGRESSBARS ), "The Progress Bars are displayed in the mastery Page", "The Progress Bars are not displayed in the mastery Page" );

            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify default selection of Subject filter and the user can able to select only one value.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 3 )
    public void tcSMSDMD008() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "tcSMSDMD008: Verify default selection of Subject filter and the user can able to select only one value. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Verify the default text of Subject Drop down
            String actualText = studentsTab.getMasterySubjectDropdownDefaultText();
            Log.assertThat( actualText.equalsIgnoreCase( Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 0 ) ), "The default value in the subject drop down is Math", "The default value in the subject drop down is not Math" );

            // Verify the user can select only either Math or Reading
            studentsTab.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) );
            actualText = studentsTab.getMasterySubjectDropdownDefaultText();
            Log.assertThat( actualText.equalsIgnoreCase( Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) ), "The user can able to select only Reading and selected", "The user is unable to select only Reading and not selected" );

            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify help icon on mastery Sub-nav.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 3 )
    public void tcSMSDMD009() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);  
    	Log.testCaseInfo( "tcSMSDMD009: Verify help icon on mastery Sub-nav. <small><b><i>[" + browser + "]</b></i></small>" );

    	try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Verify the help icon for the Mastery Listing
            studentsTab.clickMasteryHelpIcon();
            String baseWindow = driver.getWindowHandle();
            SMUtils.switchWindow( driver );
            HelpPage helpPage = new HelpPage( driver ).get();
            String currentURL = driver.getCurrentUrl();
            String title = driver.getTitle();
            Log.assertThat( currentURL.equalsIgnoreCase( Constants.Students.MASTERYHELPRURL ), "Help window URL is verified", "Help window URL is not verified" );
            Log.assertThat( title.equalsIgnoreCase( Constants.Students.MASTERYHELPTITLE ), "Help window Title is verified", "Help window Title is not verified" );
            driver.switchTo().window( baseWindow );
            Log.testCaseResult();
            // SignOut from SM
            if ( browser.equals( "Windows_10_Chrome_latest" ) )
                teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of SELECT ALL check box in assignments drop down.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 3 )
    public void tcSMSDMD0010() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMSDMD0010: Verify the functionality of SELECT ALL check box in assignments drop down. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Verify the SELECT ALL option is available
            List<String> dropDownOptions = studentsTab.getDropDownOptions( Mastery_DropDowns.ASSIGNMENTS );
            Log.assertThat( dropDownOptions.get( 0 ).equalsIgnoreCase( Constants.Students.MASTERY_ASSIGNMENTS_SELECT_ALL ), "SELECT ALL option is displayed in the assignments drop down", "SELECT ALL option is not displayed in the assignments drop down" );
            Log.testCaseResult();

            // Verify SELECT ALL can select/unselect all the assignments in the drop down
            studentsTab.selectMasteryAssignmentSelectAll();
            Log.assertThat( !studentsTab.checkAllMasteryAssignmentsSelected(), "All the values are not selected", "All the values are selected" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the default value of the assignments drop down and the user can able to select one or more values at a time.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 3 )
    public void tcSMSDMD0011() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMSDMD0011: Verify the default value of the assignments drop down and the user can able to select one or more values at a time. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Verify the default value of Assignment drop down
            Log.assertThat( studentsTab.checkAllMasteryAssignmentsSelected(), "By default, all the assignments are selected", "By default, all the assignments are not selected" );
            Log.testCaseResult();

            // Verify the teacher is able to select single assignment in the drop down
            List<String> dropDownOptions = studentsTab.getMasteryAssignments();
            studentsTab.selectMasteryAssignments( dropDownOptions.get( 1 ) );
            List<String> selectedValues = studentsTab.getAllMasteryAssignmentsSelectedValues();
            Log.message( selectedValues + "" );
            Log.message( dropDownOptions.get( 1 ) );
            Log.assertThat( selectedValues.contains( dropDownOptions.get( 1 ) ), "The single assignment is selectable", "The single assignment is not selectable" );
            Log.testCaseResult();

            // Verify the teacher is able to select multiple assignment in the drop down
            studentsTab.selectMasteryAssignments( dropDownOptions.get( 1 ), dropDownOptions.get( 2 ) );
            SMUtils.nap( 2 ); // This nap is for MAC for retrieveing data from the drop down, with webdriver wait it is not achievable
            selectedValues = studentsTab.getAllMasteryAssignmentsSelectedValues();
            Log.assertThat( selectedValues.contains( dropDownOptions.get( 1 ) ) && selectedValues.contains( dropDownOptions.get( 2 ) ), "The multiple assignment is selectable", "The multiple assignment is not selectable" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Apply filter button functionality and disabled by default.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 3 )
    public void tcSMSDMD0012() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMSDMD0012: Verify Apply filter button functionality and disabled by default. <small><b><i>[" + browser + "]</b></i></small>" );

    	try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Verify by default apply filter is disabled
            Log.assertThat( studentsTab.verifyApplyFilterisDisabled(), "The Apply filter button is disabled by default", "The Apply filter button is not disabled by default" );
            Log.testCaseResult();

            // Verify the Apply filter button
            studentsTab.selectDropDownValues( Mastery_DropDowns.SUBJECT, Constants.Students.SUBJECT_DROPDOWN_VALUES.get( 1 ) );
            Log.assertThat( studentsTab.verifyApplyFilterButton(), "The Apply filter button is displayed and clickable", "The Apply filter button is not displayed and clickable" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify default selection of Skill/Standards dropdown..", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 3 )
    public void tcSMSDMD0013() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMSDMD0013: Verify default selection of Skill/Standards dropdown.. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting Student data to navigate to the respective Mastery details
            String studentID = studentUserNames.get( 0 );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( studentID );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Verify default selection of Skill/Standards dropdown
            String selectedValue = studentsTab.getSelectedValuesFromDropdown( Mastery_DropDowns.MASTERY_SKILL );
            Log.message( selectedValue );
            Log.assertThat( selectedValue.equalsIgnoreCase( Constants.Students.MASTERY_SKILL_DEFAULT_VALUE ), "The default skill/standard value is verified and displayed as SuccessMaker Mastery Skills - Math",
                    "The default skill/standard value is not displayed as expected" );

            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if student does not have any assignments.", groups = { "SMK-43621", "students", "studentDetailsMasterydropdown" }, priority = 3 )
    public void tcSMSDMD0014() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner); 
    	Log.testCaseInfo( "tcSMSDMD0014: Verify if student does not have any assignments. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();

            String dummyStudentID = studentUserNames.get( 0 );

            // Navigate to Student detail Page
            studentsTab.clickviewStudentByEllipsis( dummyStudentID );
            studentsTab.clickSubNavigation( Constants.Students.NAVIGATE_MASTERY );

            // Verify the Zero State and No Data header for no assignment
            Log.assertThat( studentsTab.getMasteryNoData().equalsIgnoreCase( Constants.Students.MASTERY_NO_DATA_ASSIGNMENT ) && studentsTab.getMasteryZeroState().equalsIgnoreCase( Constants.Students.MASTERY_ZERO_STATE_ASSIGNMENT ),
                    "No data and Zero State message is verified", "No data and Zero State message is not verified" );

            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public void executeSimulator( String username, String password, String assignment ) throws Exception {

        WebDriver driver = WebDriverFactory.get( "Windows_10_Chrome_latest" );
        smLoginPage = new LoginPage( driver, smUrl ).get();
        StudentDashboardPage sim = smLoginPage.loginToSMasStudent( username, password, true );
        sim.executeMathCourse( username, assignment, "90", "1", "30" );
        driver.quit();

    }
}
