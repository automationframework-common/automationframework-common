package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

/**
 * Add student to assignment popup POM
 *
 * @author ajith.mohan
 *
 */
public class AddStudentToAssignmentPopup extends LoadableComponent<AddStudentToAssignmentPopup> {
    public  WebDriver driver;
    boolean isPageLoaded;
       
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    // ********* SuccessMaker Add student to assignment popup Page Elements
    // ***************
    
    @IFindBy (how = How.CSS, using = "cel-dialog-header div h1", AI = false )
    public WebElement addStudentToAssignmentPopupHeader;

    @IFindBy (how = How.CSS, using = "add-student-to-assignment div div.container-fluid > div", AI = false  )
    public WebElement assignmentList;

    @IFindBy (how = How.CSS, using = "cel-button.cancel-btn-wrapper.hydrated", AI = false  )
    public WebElement btnCancelRoot;

    @IFindBy (how = How.CSS, using = "cel-button.action-btn-wrapper.d-flex.justify-content-end.hydrated", AI = false  )
    public WebElement btnAddRoot;

    @IFindBy (how = How.CSS, using = "div.dialog-footer.text-right.d-flex.justify-content-end cel-button", AI = false  )
    public WebElement btnOkayRoot;

    @IFindBy (how = How.CSS, using = "div.zero-state-content span", AI = false  )
    public WebElement lblZeroState;

    @IFindBy (how = How.CSS, using = "#alert__messageBody", AI = false  )
    public WebElement lblToastMessage;

    @IFindBy (how = How.CSS, using = "cel-dialog-header div div button", AI = false  )
    public WebElement btnIicon;

    @FindBy ( css = "div > cel-checkbox" )
    List<WebElement> checkBoxes;

    @FindBy ( css = "div[class='assignment-name-detail']" )
    List<WebElement> assignmentNames;

    private static String assignmentName = "div.container-fluid div div:nth-child(%s) div div div";
    private static String chbxChildElement = "div > label.checkbox__container > span";
    private static String btnPrimary = ".primary_button";
    private static String btnSecondary = ".secondary_button";

    public AddStudentToAssignmentPopup() {}
    
    /**
     * Constructor to invoke the add student to assignment component
     *
     * @param driver
     */
    public AddStudentToAssignmentPopup( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
        PageFactory.initElements(finder, this);
        elementLayer = new ElementLayer(driver);
    }

    @Override
    protected void isLoaded() {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( SMUtils.waitForElement( driver, addStudentToAssignmentPopupHeader ) ) {
            Log.message( "Add student to assignment popup loaded successfully." );
        } else {
            Log.fail( "Add student to assignment popup did not load." );
        }
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, addStudentToAssignmentPopupHeader );
    }

    /**
     * Verifying is assignment exist
     *
     * @param assignmentNameToFind
     * @return
     */
    public boolean isAssignmentExist( String assignmentNameToFind ) {
        boolean isExists = false;
        try {
            for ( int assignmentCount = 0; assignmentCount < checkBoxes.size(); assignmentCount++ ) {
                String assignmentName = assignmentNames.get( assignmentCount ).getText();
                if ( assignmentName.trim().equals( assignmentNameToFind.trim() ) ) {
                    Log.message( "Assignment exists: - " + assignmentNameToFind );
                    isExists = true;
                    break;
                }

            }
            return isExists;
        } catch ( Exception e ) {
            e.printStackTrace();
            return isExists;
        }
    }

    /**
     * Getting all the assignment Names
     *
     * @return
     */
    public List<String> getAllAssignmentNames() {
        List<String> assignmentnames = new ArrayList<>();
        try {
            String AssignmentCountFromUI = assignmentList.getAttribute( "childElementCount" );
            for ( int assignmentCount = 1; assignmentCount <= Integer.parseInt( AssignmentCountFromUI ); assignmentCount++ ) {
                assignmentnames.add( driver.findElement( By.cssSelector( String.format( assignmentName, assignmentCount ) ) ).getText().trim() );
            }
            Log.message( "Got all the assignments - " + assignmentnames );
            return assignmentnames;
        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Clicking i icon
     */
    public void clickiIcon() {
        SMUtils.clickJS( driver, btnIicon );
        Log.message( "Clicked i icon" );
        SMUtils.nap( 5 ); // Waiting for page switch and load
    }

    /**
     * Get the i icon
     *
     * @return
     */
    public WebElement getiIcon() {
        return btnIicon;
    }

    /**
     * Get cancel button
     *
     * @return
     */
    public WebElement getCancelButton() {
        WebElement cancelButton = SMUtils.getWebElementDirect( driver, btnCancelRoot, btnSecondary );
        return cancelButton;
    }

    /**
     * get add student to assignment title
     *
     * @return
     */
    public String getAddStudentToAssignmentTitle() {
        return addStudentToAssignmentPopupHeader.getText();
    }

    /**
     * Getting the toast message
     *
     * @return
     */
    public WebElement getToastMessage() {
        return lblToastMessage;
    }

    /**
     * Getting add button
     *
     * @return
     */
    public WebElement getAddButton() {
        WebElement addButton = SMUtils.getWebElement( driver, btnAddRoot, btnPrimary );
        return addButton;
    }

    /**
     * Getting OK button if it is zero state
     *
     * @return
     */
    public WebElement getOkayButton() {
        WebElement okayButton = SMUtils.getWebElement( driver, btnOkayRoot, btnPrimary );
        return okayButton;
    }

    /**
     * Getting zero state page
     *
     * @return
     */
    public String getZeroStateMessage() {
        return lblZeroState.getText();
    }

    /**
     * Selecting assignment name based on assignment
     *
     * @param assignmentNameToSelect
     */
    public void selectAssignmentCheck( String assignmentNameToSelect ) {
        try {

            for ( int assignmentCount = 0; assignmentCount < checkBoxes.size(); assignmentCount++ ) {
                String assignmentName = assignmentNames.get( assignmentCount ).getText();
                if ( assignmentName.trim().equals( assignmentNameToSelect.trim() ) ) {
                    WebElement checkBox = checkBoxes.get( assignmentCount );
                    WebElement checkBoxFinal = SMUtils.getWebElement( driver, checkBox, chbxChildElement );
                    SMUtils.clickJS( driver, checkBoxFinal );
                    Log.message( "Selected assignment: " + assignmentNameToSelect );
                    break;
                }

            }

        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

}