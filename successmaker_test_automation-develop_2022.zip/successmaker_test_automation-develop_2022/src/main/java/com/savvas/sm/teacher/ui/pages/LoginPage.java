package com.savvas.sm.teacher.ui.pages;

import static org.testng.AssertJUnit.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class LoginPage extends LoadableComponent<LoginPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    public  WebDriver driver;
    private String smUrl;
    private String browser;
    public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();


    // ********* SuccessMaker Launcher/Login Page Elements ***************
    @IFindBy ( how = How.ID, using = "launchButton" , AI=false)
    public WebElement smLaunchButton;

    @IFindBy ( how = How.ID, using = "user" , AI=false)
    public WebElement txtUserName;

    @IFindBy ( how = How.ID, using = "login" , AI=false)
    public WebElement txtPassWord;

    @IFindBy ( how = How.CSS, using = ".loginBtn" , AI=false)
    public WebElement btnSignIn;

    @IFindBy ( how = How.CSS, using = ".login-link a:nth-child(1)" , AI=false)
    public WebElement ebSignInLink;

    @IFindBy ( how = How.CSS, using = "#username" , AI=false)
    public WebElement ebUserName;

    @IFindBy ( how = How.CSS, using = "#password" , AI=false)
    public WebElement ebPassword;

    @IFindBy ( how = How.CSS, using = ".btn-submit" , AI=false)
    public WebElement ebSignInButton;

    @IFindBy ( how = How.CSS, using = "div.ui-widget" , AI=false)
    public WebElement alreadyLoginPopup;

    @IFindBy ( how = How.CSS, using = "#marketingImage img" , AI=false)
    public WebElement loginPageLoad;

    @IFindBy ( how = How.CSS, using = "div.ui-dialog-buttonpane>button:nth-child(1)" , AI=false)
    public WebElement btnYes;

    @IFindBy ( how = How.ID, using = "loader" , AI=false)
    public WebElement loadingScreen;

    @IFindBy ( how = How.CSS, using = "a.error.status.h3nowrap" , AI=false)
    public WebElement loginErrorMessage;
    
    @IFindBy(how = How.ID, using="containerLogin", AI=false)
   	public WebElement signInContainer;

   	//@FindBy(id="containerLogin")
   	//no such element: Unable to locate element: {"method":"css selector","selector":"*[name='signInContainer']"}

   	//@FindBy(id="username")
   	@IFindBy(how=How.ID, using ="username", AI=false)
   	public WebElement fldUserName;
   	
   	//@FindBy ( id = "password" )
   	@IFindBy(how=How.ID, using="password", AI=false)
   	public WebElement fldPassword;

   	//@FindBy ( className = "btn-submit" )
   	@IFindBy (how=How.CLASS_NAME, using="btn-submit", AI=false)
   	WebElement btnSignIn1;

    public LoginPage() {}
    /**
     *
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     *
     * @param driver
     * @param url
     */
    public LoginPage( WebDriver driver, String url ) {

        this.driver = driver;
        smUrl = url;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
    	PageFactory.initElements(finder, this);
    	elementLayer = new ElementLayer(driver);
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
    }

    @Override
    protected void isLoaded() {
    	if(!driver.getCurrentUrl().contains("savvasrealize")) {
            assertTrue( "HomePage is not loaded!", driver.getCurrentUrl().contains( configProperty.getProperty( "dbHostNonIntegrated" ) ) );
        SMUtils.nap( 10 );
        if ( browser.toLowerCase().contains( "safari" ) ) { //SMK-44058 - Inconsistent issue on clicking Enter here in Safari browser
            if ( SMUtils.waitForElement( driver, ebSignInButton ) ) { //So Launching login page directly only on safari
                Log.message( "SM Login page loaded successfully!" );
            } else {
                Log.fail( "SM login page did not load." );
            }
        } else {
            if ( SMUtils.waitForElement( driver, smLaunchButton ) ) {
                Log.message( "SM Pre-Login page loaded successfully!" );
            } else {
                Log.message( "SM pre-login page did not load." );
            }
        }
    	} else {
    		Log.message("Realize url is launched successfully");
    	}
    }

    @Override
    protected void load() {
        if ( browser.toLowerCase().contains( "safari" ) ) {
            driver.get( smUrl + "/lms/sso" ); //SMK-44058 - Inconsistent issue on clicking Enter here in Safari browser
        } else { //So Launching login page directly only on safari
            driver.get( smUrl );
        }
        Log.message( "Hit the SM Instance Url - " + smUrl );
    }

    /**
     * Login to SuccessMaker
     *
     * @param username as string
     * @param password as string
     * @param screenShot to capture screenShot
     * @return HomePage if enter the correct credential for Realize
     * @throws Exception
     */
    public TeacherHomePage loginToSM( String username, String password, boolean screenShot ) throws Exception {

        //        if ( configProperty.getProperty( "SMInstanceType" ).toLowerCase().trim().equals( "non-integrated" ) ) {
        //
        //            if ( !browser.toLowerCase().contains( "safari" ) ) { //SMK-44058 - Safari issue
        //                // Launch SignIn Page
        //                launchSignInPage();
        //            }
        //
        //            // Launch SignIn page
        //            launchEBSignInPage();
        //            // log in to app
        //            enterCredentialsAndLogIn( username, password );
        //            try {
        //                SMUtils.nap( 1 );
        //                if ( alreadyLoginPopup.isDisplayed() ) {
        //                    Log.event( "User already Logged in" );
        //                    SMUtils.clickJS( driver, btnYes );
        //                    Log.event( "Clicked Yes button" );
        //                }
        //            } catch ( Exception e ) {
        //
        //            }
        //        } else {
        //
        //            // Launch SignIn page
        //            launchEBSignInPage();
        //
        //            // Enter credentials
        //            ebUserName.clear();
        //            ebPassword.clear();
        //
        //            ebUserName.sendKeys( username );
        //            Log.event( "Entered EB UserName - " + username );
        //            ebPassword.sendKeys( password );
        //            Log.event( "Entered EB Password - " + password );
        //
        //            SMUtils.click( driver, ebSignInButton );
        //            Log.event( "Clicked the EB SignIn button" );
        //        }

        // Launch SignIn page
        if ( !browser.toLowerCase().contains( "safari" ) ) {
            launchEBSignInPage();
        }

        enterCredentialsAndLogIn( username, password );
        // Launch NG View Page
        // SMUtils.openNewTabAndSwitchToNewSMApp(driver, smUrl + "/lms/ng.view");
        TeacherHomePage tHomePage = new TeacherHomePage( driver ).get();

        return tHomePage;
    }

    /**
     * Login to SuccessMaker
     *
     * @param username as string
     * @param password as string
     * @param screenShot to capture screenShot
     * @return HomePage if enter the correct credential for Realize
     * @throws Exception
     */
    public StudentDashboardPage loginToSMasStudent( String username, String password, boolean screenShot ) throws Exception {

        if ( !configProperty.getProperty( "SMInstanceType" ).toLowerCase().trim().equals( "non-integrated" ) ) {

            if ( !browser.toLowerCase().contains( "safari" ) ) { //SMK-44058 - Safari issue
                // Launch SignIn Page
                launchSignInPage();
            }

            // log in to app
            enterCredentialsAndLogIn( username, password );
            try {
                if ( alreadyLoginPopup.isDisplayed() ) {
                    Log.event( "User already Logged in" );
                    btnYes.click();
                    Log.event( "Clicked Yes button" );
                }
            } catch ( Exception e ) {

            }
        } else {

            // Launch SignIn page
            launchEBSignInPage();

            // Enter credentials
            ebUserName.clear();
            ebPassword.clear();

            ebUserName.sendKeys( username );
            Log.event( "Entered EB UserName - " + username );
            ebPassword.sendKeys( password );
            Log.event( "Entered EB Password - " + password );

            ebSignInButton.click();
            Log.event( "Clicked the EB SignIn button" );

        }

        // Launch NG View Page
        // SMUtils.openNewTabAndSwitchToNewSMApp(driver, smUrl + "/lms/ng.view");
        StudentDashboardPage sHomePage = new StudentDashboardPage( driver ).get();

        return sHomePage;
    }

    public void enterCredentialsAndLogIn( String username, String password ) throws Exception {
        SMUtils.waitForElement( driver, ebUserName, 5 );
        // Enter credentials
        ebUserName.clear();
        ebPassword.clear();

        ebUserName.sendKeys( username );
        Log.event( "Entered EB UserName - " + username );
        ebPassword.sendKeys( password );
        Log.event( "Entered EB Password - " + password );

        new SMUtils();
        SMUtils.click( driver, ebSignInButton );

        try {
            if ( alreadyLoginPopup.isDisplayed() ) {
                Log.event( "User already Logged in" );
                btnYes.click();
                Log.event( "Clicked Yes button" );
            }
        } catch ( Exception e ) {

        }
        new SMUtils();
        SMUtils.waitForElement( driver, loadingScreen );
    }

    // Launch SM Sign-In page
    public void launchSignInPage() {

        // To do - Use same workaorund as there in launchEBSignInPage() for FF as needed
        SMUtils.waitForElementToBeClickable( smLaunchButton, driver );
        //smLaunchButton.click();
        SMUtils.clickJS( driver, smLaunchButton );

        Set<String> handles = driver.getWindowHandles();
        driver.switchTo().defaultContent();
        String winHandle = driver.getWindowHandle();
        Log.event( "Number of window handles - " + handles.size() );

        if ( handles.size() > 1 ) {
            driver.close();
        } else {
            Log.fail( "Sign in page did not show up" );
        }

        for ( String index : handles ) {
            if ( !index.equals( winHandle ) ) {
                driver.switchTo().window( index );
                break;
            }
        }

        SMUtils.waitForElementToBeClickable( txtUserName, driver );

        ( (JavascriptExecutor) driver ).executeScript( "if(window.screen){window.moveTo(0, 0); window.resizeTo(window.screen.availWidth, window.screen.availHeight);};" );
    }

    // Launch EB Sign-In page
    public void launchEBSignInPage() {
        SMUtils.waitForElementToBeClickable( smLaunchButton, driver );
        String winHandle = driver.getWindowHandle();
        smLaunchButton.click();
        SMUtils.nap( 1 );
        Set<String> handles = driver.getWindowHandles();
        Log.event( "Number of window handles - " + handles.size() );

        if ( handles.size() > 1 ) {
            driver.close();
        } else {
            // Workaround as FF closing the parent window automatically.
            for ( String index : handles ) {
                if ( !index.equals( winHandle ) ) {
                    driver.switchTo().window( index );
                    break;
                }
            }

            if ( !driver.getCurrentUrl().contains( "headless" ) ) {
                Log.fail( "Sign in page did not show up" );
            }
        }

        for ( String index : handles ) {
            if ( !index.equals( winHandle ) ) {
                driver.switchTo().window( index );
                break;
            }
        }

        //        SMUtils.waitForElementToBeClickable( ebSignInButton, driver );

        ( (JavascriptExecutor) driver ).executeScript( "if(window.screen){window.moveTo(0, 0); window.resizeTo(window.screen.availWidth, window.screen.availHeight);};" );

        // Click EB SignIn Link
        //ebSignInLink.click();
    }
    
   
    /**
	 * Returns the visibility state of Sign in container
	 * 
	 * @return
	 */
	public boolean isSignInContainerDisplayed() {
		return signInContainer.isDisplayed();
	}

	// ************* Methods for login to EB page
	/**
	 * To enter the user name in user name field on EBPlusAndAutoSignInPage
	 * 
	 * @param userName   as string
	 * @param screenshot
	 */
	public void enterUserName(String userName, boolean screenshot) {

		SMUtils.fluentWaitForElement(driver, fldUserName);
		fldUserName.clear();
		fldUserName.sendKeys(userName);
		Log.message("Entered the UserName: '" + userName + "'", driver, screenshot);
	}

	/**
	 * To enter the password in password field on EBPlusAndAutoSignInPage
	 * 
	 * @param pwd        as string
	 * @param screenshot
	 */
	public void enterPassword(String pwd, boolean screenshot) {
		SMUtils.fluentWaitForElement(driver, fldPassword);
		fldPassword.clear();
		fldPassword.sendKeys(pwd);
		Log.message("Entered the Password: '" + pwd + "'", driver, screenshot);

	}

	/**
	 * To click the sign in button on EBPlusAndAutoSignInPage login page
	 * 
	 * @param screenshot
	 */
	public void clickSignInButton(boolean screenshot) {
		SMUtils.fluentWaitForElement(driver, btnSignIn);
		SMUtils.click(driver, btnSignIn1);
		Log.message("Clicked on 'SignIn' button on EB-PlusAndAuto SignIn Page", driver, screenshot);

	}

	public RealizeTeacherHomePage signInToRealize(WebDriver driver, String url, String username, String password) {
		// TODO Auto-generated method stub
		try {
			if (isSignInContainerDisplayed()) {
				enterUserName(username, false);
				enterPassword(password, false);
				clickSignInButton(true);
			}
		} catch (Exception e) {
			Log.message(e.getMessage());
		}

		RealizeTeacherHomePage realizeteacherpage = new RealizeTeacherHomePage(driver).get();

		return realizeteacherpage;
	}
	
}
