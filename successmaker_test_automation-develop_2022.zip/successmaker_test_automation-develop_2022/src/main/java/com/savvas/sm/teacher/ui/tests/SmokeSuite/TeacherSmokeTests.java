package com.savvas.sm.teacher.ui.tests.SmokeSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Students.Mastery_DropDowns;
import com.savvas.sm.common.utils.Constants.UserUIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants.UserType;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AddStudentToAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryDetailsPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.MyProfilePage;
import com.savvas.sm.teacher.ui.pages.RealizeTeacherHomePage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.teacher.ui.pages.TopNavBar;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

public class TeacherSmokeTests extends BaseTest {

	private String CourseId;
	private String CourseId1;
	private String CourseId2;
	private String smUrl;
	private String browser;
	private static String username = null;
	private static String password = null;
	private String school;
	private String teacherName;
	HashMap<String, HashMap<String, Integer>> individualFieldsList = new HashMap<>();

	private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	HashMap<String, HashMap<String, HashMap<String, Integer>>> usageHoursList = new HashMap<>();

	String staticCourseName = null;
	private static String teacherDetails;
	List<String> studentRumbaIds = new ArrayList<>();
	private String programname = "Mathematics Screener & Diagnostic Assessments Common Core Grade 1";
	String Custom_Skills_Math = Constants.CUSTOM_BY_SKILLS_MATH_COURSE + System.nanoTime();
	List<String> studentUserNames = null;
	List<String> studentIdList = null;
	List<String> studentID;

	private String studentDetailsOne;
	private String studentDetailsTwo;
	private String studentDetailsThree;
	private String studentDetailsFour;
	private String token;

	private String studentUN;
	private String studentUN_Two;
	private String studentUN_Three;
	private String stuUserName1;
	public HashMap<String, String> stuDetailsMap = new HashMap<>();
	public List<String> stuDetails = new ArrayList<>();
	List<String> stuInfo = new ArrayList<>();
	private String realizeUrl;
	private String organizationId;
	private String teacherId;
	String Custom_Settings_Math = Constants.CUSTOM_MATH_ASSIGMENT_TITLE + System.nanoTime();
	CourseAPI courseAPI = new CourseAPI();
	AssignmentAPI assignmentAPI;
	public static List<String> FOCUS_COURSES = new ArrayList<>(Arrays.asList("SM Focus Math: Grade 1",
			"SM Focus Math: Grade 2", "SM Focus Math: Grade 3", "SM Focus Math: Grade 4", "SM Focus Math: Grade 5",
			"SM Focus Math: Grade 6", "SM Focus Math: Grade 7", "SM Focus Math: Grade 8", "SM Focus Reading: Grade 1",
			"SM Focus Reading: Grade 2", "SM Focus Reading: Grade 3", "SM Focus Reading: Grade 4",
			"SM Focus Reading: Grade 5", "SM Focus Reading: Grade 6", "SM Focus Reading: Grade 7",
			"SM Focus Reading: Grade 8"));

	@BeforeClass(alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;
		school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
		realizeUrl = configProperty.getProperty("RealizeNightlyAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		organizationId = RBSDataSetup.organizationIDs.get(school);
		teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		assignmentAPI = new AssignmentAPI();
		token = new RBSUtils().getAccessToken(username, password);

		IntStream.range(0, Integer.parseInt(configProperty.getProperty(ConfigConstants.STUDENT_COUNT)))
				.forEach(count -> {
					String studentDetails = RBSDataSetup.getMyStudent(school, username);
					stuInfo.add(studentDetails);
					stuDetails.add(SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERNAME));
					stuUserName1 = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERNAME);
					stuDetailsMap.put("Student" + count + "", stuUserName1);
				});

		studentDetailsOne = stuInfo.get(0);
		studentDetailsTwo = stuInfo.get(1);
		studentDetailsThree = stuInfo.get(2);
		studentDetailsFour = stuInfo.get(3);

		studentUN = SMUtils.getKeyValueFromResponse(studentDetailsOne, "userName");
		studentUN_Two = SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userName");
		studentUN_Three = SMUtils.getKeyValueFromResponse(studentDetailsThree, "userName");

	}

	@Test(description = "Verify Home Page Components and Widgets in a teacher dashboard", groups = { "TeacherUISmoke" })
	public void Teacher_TC01() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		Log.testCaseInfo("Teacher_TC01: Verify Home Page Components and Widgets in a teacher dashboard. <small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			TopNavBar topNavBar = tHomePage.topNavBar;

			Log.assertThat(topNavBar.isHomeTabDisplayed(), "Home Tab is displayed in TopNavBar",
					"Home Tab is not displayed in TopNavBar");

			Log.assertThat(topNavBar.isStudentsTabDisplayed(), "Students Tab is displayed in TopNavBar",
					"Students Tab is not displayed in TopNavBar");

			Log.assertThat(topNavBar.isGroupsTabDisplayed(), "Groups Tab is displayed in TopNavBar",
					"Groups Tab is not displayed in TopNavBar");

			Log.assertThat(topNavBar.isCoursewareDisplayed(), "Courseware Tab is displayed in TopNavBar",
					"Courseware Tab is not displayed in TopNavBar");

			Log.assertThat(topNavBar.isMasteryTabDisplayed(), "Mastery Tab is displayed in TopNavBar",
					"Mastery Tab is not displayed in TopNavBar");

			Log.assertThat(topNavBar.isReportsTabDisplayed(), "Reports Tab is displayed in TopNavBar",
					"Reports Tab is not displayed in TopNavBar");

			// Verify Announcement Icon, Help Icon, UserProfile menu
			Log.assertThat(topNavBar.isAnnouncementDisplayed(), "Announcement Icon is displayed in TopNavBar",
					"Announcement Icon is not displayed in TopNavBar");

			Log.assertThat(topNavBar.isHelpDisplayed(), "Help Icon is displayed in TopNavBar",
					"Help Icon is not displayed in TopNavBar");

			// expand user icon dropdown
			topNavBar.expandUserDropdown();

			Log.assertThat(topNavBar.isUserDropdownExpanded(), "User Icon dropdown is displayed in TopNavBar",
					"User Icon dropdown is not displayed in TopNavBar");

			// Verify the presence of top left SM logo and bottom right Savvas Logo
			Log.assertThat(topNavBar.isSuccessMakerLogoDisplayed(), "SuccessMaker Logo is displayed in TopNavBar",
					"SuccessMaker Logo is not displayed in TopNavBar");

			// navigate to Students tab
			StudentsPage studentsPage = topNavBar.navigateToStudentsTab();

			topNavBar = studentsPage.topNavBar;
			Log.assertThat(topNavBar.isSavvasLogoDisplayed(), "Savvas Logo is displayed in Footer",
					"Savvas Logo is not displayed in Footer");

			topNavBar.navigateToHomeTab();
			Log.assertThat(tHomePage.isCoursesWidgetDisplayed(), "Courses widget is displayed in HomePage",
					"Courses widget is not displayed in HomePage");

			Log.assertThat(tHomePage.isAnnouncementWidgetDisplayed(), "Announcement widget is displayed in HomePage",
					"Announcement widget is not displayed in HomePage");

			Log.assertThat(tHomePage.isMasteryWidgetDisplayed(), "Mastery widget is displayed in HomePage",
					"Mastery widget is not displayed in HomePage");

			Log.assertThat(tHomePage.isAssignmentWidgetDisplayed(), "Assignment widget is displayed in HomePage",
					"Assignment widget is not displayed in HomePage");

			Log.assertThat(tHomePage.isStudentUsageWidgetDisplayed(), "Student Usage widget is displayed in HomePage",
					"Student Usage widget is not displayed in HomePage");

			Log.assertThat(tHomePage.isDidYouKnowWidgetDisplayed(), "Did You Know widget is displayed in HomePage",
					"Did You Know widget is not displayed in HomePage");

			// Signout
			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify UserProfile Update", groups = { "TeacherUISmoke" })
	public void Teacher_TC02() throws Exception {

		Log.testCaseInfo("Teacher_TC02:  Verify UserProfile Update. <small><b><i>[" + browser + "]</b></i></small>");

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		String randomFirstName = new Faker().name().firstName();
		String randomLastName = new Faker().name().lastName();
		String randomMiddleName = new Faker().name().nameWithMiddle();
		String newEmail = "TC02_newEmail_" + System.nanoTime() + "@automation.com";

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			// navigate to my profile page
			MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

			myProfilePage.modifyFirstName(randomFirstName);
			myProfilePage.modifyMiddleName(randomMiddleName);
			myProfilePage.modifyLastName(randomLastName);
			myProfilePage.modifyEmail(newEmail);

			String title = myProfilePage.getUserTitle();

			if (title.equals("Ms")) {
				title = "Mrs";
				myProfilePage.selectValuesFromtheTitleDropDown(title);

			} else {
				title = "Ms";
				myProfilePage.selectValuesFromtheTitleDropDown(title);
			}

			myProfilePage.saveChanges();

			// Verify all updates are saved
			Log.assertThat(myProfilePage.getFirstName().equals(randomFirstName), "FirstName got updated",
					"FirstName couldn't be updated");

			Log.assertThat(myProfilePage.getMiddleName().equals(randomMiddleName), "MiddleName got updated",
					"MiddleName doesn't updated");

			Log.assertThat(myProfilePage.getLastName().equals(randomLastName), "LastName got updated",
					"LastName couldn't be updated");

			Log.assertThat(myProfilePage.getEmail().equals(newEmail), "Email got updated", "Email couldn't be updated");

			myProfilePage.expandUserTitle();
			Log.assertThat(myProfilePage.getUserTitle().equals(title), "Title was successfully selected",
					"Ttitle couldn't be Selected");

			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify Teacher can create new Student accounts in SuccessMaker", groups = { "TeacherUISmoke" })
	public void Teacher_TC03() throws Exception {

		String groupName = "TC03_AutoSmokeGrp_" + System.nanoTime();

		List<String> studentRumbaIds = new ArrayList<>();
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(stuInfo.get(3), "userId"));

		HashMap<String, String> groupDetailsMap = new HashMap<>();
		groupDetailsMap.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(username, password));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_OWNER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_NAME, groupName);
		HashMap<String, String> createGroup = new GroupAPI().createGroup(smUrl, groupDetailsMap, studentRumbaIds);

		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_NAME, groupName);
		createGroup = new GroupAPI().createGroup(smUrl, groupDetailsMap, studentRumbaIds);

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC03: Verify Teacher can create new Student accounts in SuccessMaker <small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get Student Page
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

			// Create New Student
			List<String> studentUserNames = new ArrayList<>();
			String studentID = studentsPage.createStudent();
			studentsPage.closePopup();
			studentUserNames.add(studentID);
			SMUtils.nap(60);

			// Add Student to Group
			GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
			Log.assertThat(groupsTab.verifyGroupHeaders(), "Verified Headers successfully!",
					"Headers not displayed properly");
			groupsTab.viewGroup(groupName);
			groupsTab.clickGroupsSubNav(Constants.USERS);
			SMUtils.waitForElement(driver, groupsTab.userTabHeader);
			SMUtils.nap(90);

			// Click on the add students to group button
			groupsTab.clickAddStudentToGroup();
			groupsTab.addStudGroupWithHomeRoomStudents(groupName, studentUserNames);
			groupsTab.clickOnAddStudentsBtn();

			studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

			SMUtils.nap(90);
			tHomePage.topNavBar.navigateToStudentsTab();
			for (String stuUserName : studentUserNames) {
				Log.assertThat(studentsPage.isStrudentPresent(stuUserName),
						stuUserName + " present in the Students listing page",
						stuUserName + " not present in the students listing page", driver);
			}

			boolean deleteStudent = new RBSUtils().deleteUser(Arrays.asList(studentID));
			Log.assertThat(deleteStudent, "Student " + studentID + " deleted successfully",
					"Student " + studentID + " couldn't be deleted");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify teacher can create a new group with students", groups = { "TeacherUISmoke" })
	public void Teacher_TC04(ITestContext context) throws Exception {
		// Get driver

		Log.testCaseInfo("Teacher_TC04: Verify teacher can create a new group with students <small><b><i>[" + browser
				+ "]</b></i></small>");

		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			String groupName = "TC04_AutoSmokeGrp" + System.nanoTime();

			// Navigating to the Groups tab
			GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();

			groupsPage.clickCreateNewGroupBtn();

			groupsPage.enterGroupNameinPopup(groupName);
			IntStream.rangeClosed(1, 2).forEach(count -> {
				groupsPage.addNameInTextField(stuDetailsMap.get("Student" + count).toLowerCase());
				groupsPage.clickAddButton();
			});

			groupsPage.clickCreateButton();
			SMUtils.nap(5);

			String UserName = stuDetailsMap.get("Student1");

			// Navigate to Groups Tab
			GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
			groupsTab.clickGetViewGroupBtn(groupName);

			HashMap<String, HashMap<String, String>> studentDetailsFromGroup = groupsTab
					.getStudentDetailsBasedOnGroup(groupName);
			String Student_Details = studentDetailsFromGroup.toString();

			Log.assertThat(Student_Details.contains(UserName),
					"UserName : " + UserName + "is mapped to the group " + groupName,
					"UserName : " + UserName + "is not mapped to the group " + groupName);
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify teacher can view student's assignment progress in his profile page", groups = {
			"TeacherUISmoke" })
	public void Teacher_TC05() throws Exception {

		String staticCourseName = "TC05_Course_" + System.nanoTime();
		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();

		CourseId = courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId, organizationId.toString(),
				DataSetupConstants.SETTINGS, staticCourseName);
		CourseIds.add(CourseId);

		HashMap<String, String> assignmentDetails = new HashMap<>();

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		// Login as Student
		// Get driver
		EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		studentDriver.register(eventListner);

		Log.testCaseInfo(
				"Teacher_TC05: Verify teacher can view student's assignment progress in his profile page <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN, password);
			SMUtils.nap(30);
			SMUtils.waitForSpinnertoDisapper(studentDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(studentDriver);

			studentsPage.executeMathCourse(username, staticCourseName, "100", "15", "30");
			studentsPage.logout();

		} catch (Exception e) {
			e.printStackTrace();
			Log.exception(e, studentDriver);
		} finally {
			studentDriver.quit();
		}

		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		eventListner = new EventListener();
		driver.register(eventListner);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			StudentsPage stuPage = tHomePage.topNavBar.navigateToStudentsTab();
			SMUtils.nap(2);
			stuPage.clickviewStudentByEllipsis(studentUN);
			Log.assertThat((stuPage.verifyDropdownLastSession()),
					"Dropdown is displayed in Last Session Skills section",
					"Dropdown is not displayed in Last Session Skills section");
			SMUtils.nap(2);
			stuPage.clickDropDownForLastSession();
			stuPage.selectSubjectFromLastSessionDropDown(staticCourseName);
			SMUtils.nap(2);
			Log.assertThat(
					stuPage.skillTestedProgressBarAndTextColor(Constants.MATH_COLOR_STRING,
							Constants.LastSessionSkillTested.COLOR_BLACK),
					"Progress Bar color & text color is displayed as expected",
					"Progress Bar color & text color is not displayed as expected");
			Log.assertThat(stuPage.skillTestedAttemptColor(staticCourseName),
					"No of attempts color is displayed as expected",
					"No of attempts color is not displayed as expected");

			Log.assertThat(stuPage.verifyStudentUsageChart(), "All fields displayed properly in student usage chart!",
					"Fields are not displayed properly in student usage chart.");

			stuPage.selectSubjectFromLastSessionDropDown((staticCourseName));
			Log.assertThat(
					stuPage.isSkillNameLinkDisplayed(
							stuPage.getSkillsListFromMap(stuPage.getSkillsTestedValues()).get(0)),
					"Skill link displayed successfully for " + staticCourseName,
					"Skill link not displayed for " + staticCourseName);

			// Progress
			stuPage.clickDropDownInStudentProgressgraph();
			stuPage.selectSubjectFromStudentProgressDropDown(staticCourseName);

			stuPage.clickViewDetails();

			// Get the skills tested heading From the Assigment Details Page
			String textInAssignmentDetailsPage = stuPage.getSkillsTestedTextInAssignmentDetailsPage();

			// Validating the view details link navigating to the assignment details page
			// with expanded
			Log.assertThat(textInAssignmentDetailsPage.equals("Skills Tested"),
					"View Details Link navigated the user to the Assignment Details Page of the "
							+ textInAssignmentDetailsPage + " Successfully ",
					"View Details Link Not working as Expected");

			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			AssignmentDetailsPage assignmentDetailsPage = assignmentPage
					.viewAssignmentDetailsByAssignmentName(staticCourseName);
			assignmentDetailsPage.assignmentLevelEllipsis();
			assignmentDetailsPage.deleteAssignmenttab();
			SMUtils.nap(2); // required for popup load
			assignmentDetailsPage.deleteAssignmentButton();
			Log.assertThat(assignmentDetailsPage.isAssignmentDisplayed(),
					"Assignment " + staticCourseName + " has been removed successfully",
					"Not able to remove the assignment " + staticCourseName);

		} catch (Exception e) {
			e.printStackTrace();
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify Teacher can View details of Group and modify or delete it", groups = {
			"TeacherUISmoke" })
	public void Teacher_TC06(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC06: Verify Teacher can View details of Group and modify or delete it <small><b><i>["
				+ browser + "]</b></i></small>");

		String groupName = "TC06_AutoSmokeGrp_" + System.nanoTime();

		List<String> studentRumbaIds = new ArrayList<>();
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsThree, "userId"));
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsFour, "userId"));

		HashMap<String, String> groupDetailsMap = new HashMap<>();
		groupDetailsMap.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(username, password));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_OWNER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_NAME, groupName);
		HashMap<String, String> createGroup = new GroupAPI().createGroup(smUrl, groupDetailsMap, studentRumbaIds);

		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_NAME, groupName);
		createGroup = new GroupAPI().createGroup(smUrl, groupDetailsMap, studentRumbaIds);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			SMUtils.nap(2);

			GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
			String newGroupName = groupName + "_updated";

			groupsPage.viewGroup(groupName);

			Log.assertThat(groupsPage.editGroup(newGroupName), "The group name is updated successfully",
					"The group name couldn't be updated");
			Log.assertThat(groupsPage.getZeroStateAssignmentMessage().contentEquals(Constants.groupAssignmentZeroPage),
					"Assignments tab zero state page displayed", "Assignments tab zero state page not displayed");
			Log.assertThat(groupsPage.verifyMasteryZeroState(), "Mastery tab zero state page displayed",
					"Mastery tab zero state page not displayed");
			Log.assertThat(groupsPage.deleteGroup(newGroupName), "The updated group is deleted successfully",
					"The updated group couldn't be deleted");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify teacher can view the course details and Standards available for the course.", groups = {
			"TeacherUISmoke" })
	public void Teacher_TC07(ITestContext context) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"Teacher_TC07: Verify teacher can view the course details and Standards available for the course. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickMathCourse();

			// Verify the left side panel shows strands
			coursePage.verifyLeftStrandsDisplayedForMathCourses();

			// Verify the mid panel shows hierarchy
			coursePage.verifyMiddleHierarchyDisplayedForMathCourses();

			// Verify the right panel shows settings
			coursePage.verifySettingsDisplayedForMathCourses();

			// Verify the Skills drop are showing values
			coursePage.clickSkillsDropDown();
			Log.assertThat(coursePage.getSkillsDroppdownvalues().size() > 0, "Skills DropDown Values are Listed",
					"Skills DropDown Values are not Listed");

			// Verify the Grades drop are showing values
			coursePage.clickGradeDropDown();
			Log.assertThat(coursePage.getGradeDroppdownvalues().size() > 0, "Grades DropDown Values are Listed",
					"Grades DropDown Values are not Listed");

			// Change Grade and verify course details changing
			String defaultFirstStrandValueBefore = coursePage.getDefaultFirstStrandValueBeforeClicking();
			coursePage.selectGradeDropDownvalue();
			String firstStrandValueAfter = coursePage.getFirstStrandValueAfterClicking();
			Log.assertThat(
					!defaultFirstStrandValueBefore.equals(firstStrandValueAfter), defaultFirstStrandValueBefore
							+ " values is changed to " + firstStrandValueAfter + " after changing Grades",
					"The values are not changed after Grades");

			// Change Standard and verify course details changing
			String defaultFirstStrandValueBeforeClicking = coursePage.getDefaultFirstStrandValueBeforeClicking();
			coursePage.selectSkillsDropDownvalue();
			String firstStrandValueAfterClicking = coursePage.getFirstStrandValueAfterClicking();
			Log.assertThat(!defaultFirstStrandValueBeforeClicking.equals(firstStrandValueAfterClicking),
					defaultFirstStrandValueBeforeClicking + " values is changed to" + firstStrandValueAfterClicking
							+ " after changing standard",
					"The values are not changed after standard");

			// Verify Edit/Remove button not present for Math Course
			coursePage.verifyEditAndRemoveBtnNotPresent();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Teacher can create a custom course by settings course", groups = { "TeacherUISmoke" })
	public void Teacher_TC08(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC08: Verify Teacher can create a custom course by settings course <small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			coursePage.clickMathCourse();
			coursePage.clickMakeCopyBtn();
			String courseName = coursePage.generateRandomCourseName();

			coursePage.enterCourseName(courseName);
			coursePage.clickSettingsRadioBtn();
			coursePage.clickNextBtn();

			// Verify that Initial placement is ON by default.
			coursePage.verifyInitialPlacementIsON();

			// Turn OFF Initial placement
			coursePage.turnOffInitialPlacement();

			// Verify Manually set course level is OFF by default
			coursePage.verifyManuallySetCourselevelIsOFF();
			coursePage.turnOnManuallySetCourseLevel();

			// Set course level to 1.75
			coursePage.moveSliderTo(Constants.COURSELEVEL_1_75);

			// Verifying other options are shown with default values
			coursePage.verifySpeedGamesIsON();

			// Change the other options from its default value
			coursePage.turnOffSpeedGames();
			coursePage.clickCreateBtn();

			context.setAttribute("CourseName", courseName);

			SMUtils.nap(10);

			CourseListingPage courseListingPage = new CourseListingPage(driver);
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			// Verify that the new course showed in course listing page
			Log.assertThat(coursePage.verifyCoursecreated(courseName), "Course " + courseName + " created Successfully",
					"Course Not Created");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify teacher can create a custom course by skills course", groups = { "TeacherUISmoke" })
	public void Teacher_TC09(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC09: Verify teacher can create a custom course by skills course <small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			coursePage.clickReadingCourse();
			coursePage.clickMakeCopyBtn();
			String courseName = coursePage.generateRandomCourseName();
			coursePage.enterCourseName(courseName);
			coursePage.clickSkillsRadioBtn();
			coursePage.clickNextBtn();
			coursePage.clickNextBtn();
			coursePage.clickStrandBtn();
			coursePage.clickCreateBtn();

			Log.assertThat(coursePage.verifyCoursePresence(courseName),
					"Newly created course " + courseName + " is present in the course listing page",
					"New course " + courseName + "  is not found in the course listing page");

			coursePage.clickCourseName(courseName);
			coursePage.removeCourse();

			// To Verify that course is removed from course listing page
			coursePage.verifyCourseRemovedSuccessfully(courseName);
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify teacher can create a custom course by standards course", groups = { "TeacherUISmoke" })
	public void Teacher_TC10(ITestContext context) throws Exception {
		// Get driver

		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC10: Verify teacher can create a custom course by standards course <small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			CoursesPage customCourses = new CoursesPage(driver);
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			String staticCourseName = customCourses.generateRandomCourseName();

			coursePage.copyOfCourse(staticCourseName, Constants.STANDARDS, Constants.READING);

			Log.assertThat(coursePage.verifyCoursePresence(staticCourseName),
					"Newly created course " + staticCourseName + " is present in the course listing page",
					"New course " + staticCourseName + "  is not found in the course listing page");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Teacher can Remove Course", groups = { "TeacherUISmoke" })
	public void Teacher_TC11(ITestContext context) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		Log.testCaseInfo(
				"Teacher_TC11: Verify Teacher can Remove Course <small><b><i>[" + browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			String courseName = "TC11_Course" + coursePage.generateRandomCourseName();

			courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId.toString(),
					organizationId.toString(), DataSetupConstants.SETTINGS, courseName);

			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickCourseName(courseName);
			coursePage.removeCourse();

			Log.assertThat(!coursePage.verifyCourseRemovedSuccessfully(courseName), "Course successfully removed",
					"Course couldn't be removed");
			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Teacher can assign the course to Groups/Students", groups = { "TeacherUISmoke" })
	public void Teacher_TC12() throws Exception {

		String courseName = "TC12_Course_" + System.nanoTime();

		CourseId = courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId, organizationId.toString(),
				DataSetupConstants.SETTINGS, courseName);

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC12: Verify Teacher can assign the course to Groups/Students <small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			// Navigate to Courses Tab
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			CourseListingPage courseListingPage = new CourseListingPage(driver);
			courseListingPage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);

			// Verify that the new course showed in course listing page
			Log.assertThat(coursePage.verifyCoursecreated(courseName), "Course Created Successfully",
					"Course Not Created");

			// Navigate to Courses Tab
			coursePage.clickCourseName(courseName);
			coursePage.clickAssignBtn();

			// Adding Custom courses to Groups
			List<String> allStudentNameFromAssignPopUp = coursePage.getAllStudentNameFromAssignPopUp();

			// Adding Custom courses to Students
			coursePage.addCourseToStudents();

			// Verify all students (in group and outside group) got assignments
			coursePage.clickAssignmentSubMenu();
			coursePage.clickViewAssignment(courseName);
			List<String> studentListfromAssignementDetailsTable = coursePage
					.getStudentListfromAssignementDetailsTable();

			int sizeOfList = Math.min(allStudentNameFromAssignPopUp.size(),
					studentListfromAssignementDetailsTable.size());
			for (int i = 0; i < sizeOfList; i++) {
				allStudentNameFromAssignPopUp.get(i).startsWith(studentListfromAssignementDetailsTable.get(i));
			}
			Log.message("Course is allocated to all Students");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Teacher can view the assignments he assigned to Groups/Students", groups = {
			"TeacherUISmoke" })
	public void Teacher_TC13(ITestContext context) throws Exception {

		String mathCourseName = "TC13_MathCourse_" + System.nanoTime();
		String readingCourseName = "TC13_ReadingCourse_" + System.nanoTime();

		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();
		HashMap<String, String> assignmentDetails = new HashMap<>();

		// Create Course
		CourseIds.add(courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId.toString(),
				organizationId.toString(), DataSetupConstants.SETTINGS, mathCourseName));

		CourseIds.add(courseAPI.createCourse(smUrl, token, DataSetupConstants.READING, teacherId.toString(),
				organizationId.toString(), DataSetupConstants.SETTINGS, readingCourseName));

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		Log.testCaseInfo(
				"Teacher_TC13: Verify Teacher can view the assignments he assigned to Groups/Students<small><b><i>["
						+ browser + "]</b></i></small>");

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			assignmentPage.clickAssignmentSubMenu();

			Log.assertThat(assignmentPage.isAssignmentPresent(mathCourseName),
					"Assignment " + mathCourseName + " is present in the assignment listing page",
					"Assignment " + mathCourseName + " is not present in the assignment listing page");

			Log.assertThat(assignmentPage.isAssignmentPresent(readingCourseName),
					"Assignment " + readingCourseName + " is present in the assignment listing page",
					"Assignment " + readingCourseName + " is not present in the assignment listing page");

			AssignmentDetailsPage assignmentDetailsPage = assignmentPage
					.viewAssignmentDetailsByAssignmentName(mathCourseName);
			assignmentDetailsPage.assignmentLevelEllipsis();
			assignmentDetailsPage.deleteAssignmenttab();
			SMUtils.nap(2); // required for popup load
			assignmentDetailsPage.deleteAssignmentButton();
			Log.assertThat(assignmentDetailsPage.isAssignmentDisplayed(), "Assignment has been removed successfully",
					"Not able to remove the assignment");

			assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentPage.clickAssignmentSubMenu();
			assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName(readingCourseName);
			assignmentDetailsPage.assignmentLevelEllipsis();
			assignmentDetailsPage.deleteAssignmenttab();
			SMUtils.nap(2); // required for popup load
			assignmentDetailsPage.deleteAssignmentButton();
			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Assignment Details Page", groups = { "TeacherUISmoke" })
	public void Teacher_TC14() throws Exception {

		String courseName = "TC14_Course_" + System.nanoTime();

		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();
		HashMap<String, String> assignmentDetails = new HashMap<>();

		// Create Course
		CourseIds.add(courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId.toString(),
				organizationId.toString(), DataSetupConstants.SETTINGS, courseName));
		;

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC14: Verify Assignment Details Page <small><b><i>[" + browser + "]</b></i></small>");

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(courseName);
			SMUtils.nap(2);
			Log.assertThat(
					(assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage()
							.contains(Constants.ACTIVE_STUDENTS_ASSIGMENT_SUBTITILE)
							&& assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage()
									.contains(Constants.PAUSED_STUDENTS_ASSIGMENT_SUBTITILE)),
					"Assignment SubTitle is displayed", "Assignment SubTitle is not displayed");

			Log.assertThat(assignmentDetailsPage.assignElement().isDisplayed(), "Assign button is displayed",
					"Assign button is not displayed");

			assignmentDetailsPage.assignmentLevelEllipsisClicked();

			Log.assertThat(assignmentDetailsPage.assignmentSettingTabTopEllipsis().equals(Constants.ASSIGMENT_SETTINGS),
					"Assignment Settings Tab is displayed", "Assignment Settings Tab is not displayed");

			Log.assertThat(assignmentDetailsPage.pauseAllStudentTopEllipsis().equals(Constants.PAUSED_ALL_STUDENTS),
					"Pause All Student is displayed", "Pause All Student is not displayed");

			Log.assertThat(assignmentDetailsPage.deleteAssignmenttabTopEllipsis().equals(Constants.DELETED_ASSIGNMENT),
					"Delete Assignment Tab is displayed", "Delete Assignment Tab is not displayed");

			Log.assertThat(assignmentDetailsPage.getColumnName().trim().equals(Constants.NAME),
					"NAME Column is displayed in the Assignment_Details_Page",
					"NAME Column is not displayed in the Assignment_Details_Page");

			Log.assertThat(assignmentDetailsPage.getColumnLastSession().trim().equals(Constants.LAST_SESSION),
					"LAST_SESSION Column is displayed in the Assignment_Details_Page",
					"LAST_SESSION Column is not displayed in the Assignment_Details_Page");

			Log.assertThat(assignmentDetailsPage.getColumnIPLevel().trim().equals(Constants.IP_LEVEL),
					"IP_LEVEL Column is displayed in the Assignment_Details_Page",
					"IP_LEVEL Column is not displayed in the Assignment_Details_Page");

			Log.assertThat(assignmentDetailsPage.getColumnAssignedLevel().trim().equals(Constants.ASSIGNED_LEVEL),
					"ASSIGNED_LEVEL Column is displayed in the Assignment_Details_Page",
					"ASSIGNED_LEVEL Column is not displayed in the Assignment_Details_Page");

			Log.assertThat(assignmentDetailsPage.getColumnCurrentLevel().trim().equals(Constants.CURRENT_LEVEL),
					"CURRENT_LEVEL Column is displayed in the Assignment_Details_Page",
					"CURRENT_LEVEL Column is not displayed in the Assignment_Details_Page");

			Log.assertThat(assignmentDetailsPage.getColumnGain().trim().equals(Constants.GAIN),
					"GAIN Column is displayed in the Assignment_Details_Page",
					"GAIN Column is not displayed in the Assignment_Details_Page");

			assignmentDetailsPage.clickDotEllipsisButton();

			Log.assertThat(assignmentDetailsPage.assignmentSettingInEllipsis().equals(Constants.ASSIGMENT_SETTINGS),
					"Assignment Settings Tab is displayed", "Assignment Settings Tab is not displayed");

			Log.assertThat(
					assignmentDetailsPage.pauseAssignmentForStudentTabInEllipsis().equals(
							Constants.PAUSE_ASSIGNMENT_FOR_STUDENTS),
					"Pause Assignment For Student Tab is displayed",
					"Pause Assignment For Student Tab is not displayed");
			Log.assertThat(assignmentDetailsPage.removeStudentTabInEllipsis().equals(Constants.REMOVE_STUDENTS),
					"Remove Student Tab is displayed", "Remove Student Tab is not displayed");

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Remove student from assignment", groups = { "TeacherUISmoke" })
	public void Teacher_TC15() throws Exception {

		String courseName = "TC15_Course_" + System.nanoTime();

		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();
		HashMap<String, String> assignmentDetails = new HashMap<>();

		// Create Course
		CourseIds.add(courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId.toString(),
				organizationId.toString(), DataSetupConstants.SETTINGS, courseName));
		;

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsThree, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"Teacher_TC15: Verify Remove student from assignment. <small><b><i>[" + browser + "]</b></i></small>");
		try {

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			// Navigate 'CourseWare' tab and select the 'Assignments' option
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			SMUtils.nap(5);
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(courseName);

			int activeStudentsCount = Integer.parseInt(assignmentDetailsPage.getactivePausedText().split("|")[0]);
			Log.message("The active student count for the assignment " + courseName + " before the student removal is "
					+ activeStudentsCount);

			assignmentDetailsPage.removeStudentTab();

			SMUtils.nap(2);
			assignmentDetailsPage.removeStudentFromCourse();

			SMUtils.nap(3);
			int reducedCount = Integer.parseInt(assignmentDetailsPage.getactivePausedText().split("|")[0]);

			Log.message("The active student count for the assignment " + courseName + " after the student removed is "
					+ reducedCount);

			Log.assertThat(reducedCount == (activeStudentsCount - 1),
					"Student successfully removed from the assignment " + courseName,
					"Student couldn't be removed from the assignment " + courseName);

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Mastery Summary Report Page", groups = { "TeacherUISmoke" })
	public void Teacher_TC16() throws Exception {

		Log.testCaseInfo(
				"Teacher_TC16: Verify Mastery Summary Report Page <small><b><i>[" + browser + "]</b></i></small>");

		String organizationId = RBSDataSetup.organizationIDs.get(school);

		String courseName = "TC16_Course_" + System.nanoTime();

		CourseId = courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId, organizationId.toString(),
				DataSetupConstants.SETTINGS, courseName);

		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();

		CourseIds.add(CourseId);

		HashMap<String, String> assignmentDetails = new HashMap<>();
		String teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		// Get driver
		EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		studentDriver.register(eventListner);

		try {
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN, password);
			SMUtils.nap(10);
			SMUtils.waitForSpinnertoDisapper(studentDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(studentDriver);

			if (!studentDriver.getCurrentUrl().contains("student.view"))
				studentsPage.agreeAndSubmit();

			studentsPage.executeMathCourse(username, courseName, "70", "2", "30");

			studentsPage.logout();

		} catch (Exception e) {
			Log.exception(e, studentDriver);
		} finally {
			studentDriver.quit();
		}

		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		eventListner = new EventListener();
		driver.register(eventListner);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			SMUtils.waitForSpinnertoDisapper(driver);

			// Navigate to Mastery Tab
			MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();

			MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
			masteryFiltersComponent.setDropDownMS(Constants.MasteryUI.STUDENTS);
			masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);

			masteryFiltersComponent.setDropDownMS(Constants.MasteryUI.ASSIGNMENTS);

			masteryFiltersComponent.selectValuesFromDropDownMS(Arrays.asList(courseName));

			MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

			List<WebElement> masteredProgressBars = masterySummaryComponent
					.getProgressBarLink(Constants.MasteryUI.MASTERED);

			MasteryDetailsPage masteryDetailsPage = masterySummaryComponent
					.navigateToLoViewPage(masteredProgressBars.get(0));

			List<String> assignmentList = masteryDetailsPage.getAssignmentNameList();
			Log.assertThat(assignmentList.contains(courseName),
					"Assignment " + courseName + " is present on the mastery details page",
					"Assignment " + courseName + " is not present on the mastery details page");

			List<String> studentsName = masteryDetailsPage.getStudentName(courseName);
			String studentName = SMUtils.getKeyValueFromResponse(studentDetailsOne, "firstName") + " "
					+ SMUtils.getKeyValueFromResponse(studentDetailsOne, "lastName");
			Log.assertThat(studentsName.contains(studentName), "Student name is displayed on the mastery details page",
					"Student name is not visible on the mastery details page");

			SMUtils.logDescriptionTC(
					"Verify the teacher is able to see the LO as a blue link, when Math subject is chosen with skills");
			Log.assertThat(masteryDetailsPage.getLOColor(browser).contentEquals(Constants.MasteryUI.LO_ID_COLOR_CODE),
					"Teacher is able to see the LO as a blue link",
					"Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills");

			SMUtils.logDescriptionTC(
					"Verify the Teacher can view the assessment details ( Students Name, Mastery Status , Skills Evaluated and No of Attempts) of the students based on each assignment in the mastery details page corresponding to the LO");
			Log.assertThat(masteryDetailsPage.isDetailsDisplayed(), "Teacher can able to view all the details properly",
					"Teacher is not able to view the details properly!");

			SMUtils.logDescriptionTC(
					"Verify the teacher able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only irrespective of the number of assignments displayed in the mastery details page");
			Log.assertThat(!masteryDetailsPage.getNoOfStudentAssessed().isEmpty(),
					"The teacher is able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only",
					"The teacher is not able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO");

			SMUtils.logDescriptionTC(
					"Verify the text displayed as Numbers Student Assessments above the progress bar if more than one student has taken assessment corresponding to the LO only irrespective of the number of assignments displayed in the mastery details page ");
			Log.assertThat(
					masteryDetailsPage.getStudentCounts().contentEquals(masteryDetailsPage.getNoOfStudentAssessed()),
					"The text is displaying as 'number' Student Assessments for more than one student Assessment ",
					"The text is displaying as 'number' Student Assessment for more than one student Assessment");

			SMUtils.logDescriptionTC(
					"Verify the count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar ");
			Log.assertThat(
					masteryDetailsPage.getStudentCounts().contentEquals(masteryDetailsPage.getNoOfStudentAssessed()),
					"The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar ",
					" The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is not matching with TOTAL count of students have taken assessment displayed above the progress bar",
					driver);

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.testCaseResult();
			Log.endTestCase();
			Log.exception(e, driver);
		} finally {
			driver.quit();
		}

	}

	@Test(description = "Verify Teacher can view his students and add them to a groups and assignments", groups = {
			"TeacherUISmoke" })
	public void Teacher_TC17(ITestContext context) throws Exception {

		String readingCourseName = "TC17_Course_" + System.nanoTime();
		String groupName = "TC17_AutoSmokeGrp_" + System.nanoTime();

		List<String> studentRumbaIds = new ArrayList<>();
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(stuInfo.get(3), "userId"));

		HashMap<String, String> groupDetailsMap = new HashMap<>();
		groupDetailsMap.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(username, password));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_OWNER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_NAME, groupName);
		HashMap<String, String> createGroup = new GroupAPI().createGroup(smUrl, groupDetailsMap, studentRumbaIds);

		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_NAME, groupName);
		createGroup = new GroupAPI().createGroup(smUrl, groupDetailsMap, studentRumbaIds);

		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();
		HashMap<String, String> assignmentDetails = new HashMap<>();

		CourseAPI courseAPI = new CourseAPI();
		// Create Course
		CourseIds.add(courseAPI.createCourse(smUrl, token, DataSetupConstants.READING, teacherId.toString(),
				organizationId.toString(), DataSetupConstants.SETTINGS, readingCourseName));
		;
		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);
		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsThree, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data
		Log.testCaseInfo(
				"Teacher_TC17: Verify Teacher can view his students and add them to a groups and assignments <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

			studentsPage.selectStudentByUsername(studentUN);
			studentsPage.selectStudentByUsername(studentUN_Two);
			studentsPage.clickAssignmentButton();

			SMUtils.nap(5);

			AddStudentToAssignmentPopup addStudentToAssignmentUsingButton = studentsPage.addStudentToAssignmentButton();
			addStudentToAssignmentUsingButton.selectAssignmentCheck(readingCourseName);

			SMUtils.clickJS(driver, addStudentToAssignmentUsingButton.getAddButton());
			SMUtils.nap(2); // Waiting for disappearing toast message
			Log.assertThat(
					UserUIConstants.ADD_STUDENT_TO_ASSIGNMENT_TOAST_MESSAGE.trim()
							.equals(addStudentToAssignmentUsingButton.getToastMessage().getText().trim()),
					"Toast message displayed successfully!", "Error in toast message!.");

			studentsPage.selectStudentByUsername(studentUN);
			studentsPage.selectStudentByUsername(studentUN_Two);
			studentsPage.clickGroupButtoninStudentLisitngPage();
			studentsPage.clickAddButtonInAddStudentToGroup(groupName);
			studentsPage.clickSaveButtonInAddStuPopup();

			SMUtils.nap(5);

			GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
			groupsTab.clickGetViewGroupBtn(groupName);

			HashMap<String, HashMap<String, String>> studentDetailsFromGroup = groupsTab
					.getStudentDetailsBasedOnGroup(groupName);
			String Student_Details = studentDetailsFromGroup.toString();

			Log.assertThat(Student_Details.contains(studentUN),
					"UserName : " + studentUN + "is mapped to the group " + groupName,
					"UserName : " + studentUN + "is not mapped to the group " + groupName);
			Log.assertThat(Student_Details.contains(studentUN),
					"UserName : " + studentUN_Two + "is mapped to the group " + groupName,
					"UserName : " + studentUN_Two + "is not mapped to the group " + groupName);

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Teacher can update a student's User Profile", groups = { "TeacherUISmoke" })
	public void Teacher_TC18() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC18: Verify Teacher can update a student's User Profile <small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			// Navigate to Students Tab
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
			SMUtils.nap(3);
			studentsPage.clickviewStudentByEllipsis(studentUN);

			studentsPage.clickSubNavigation(Constants.Students.NAVIGATE_USER_PROFILE);

			String updatedFName = "UpdatedTC18" + studentsPage.getFirstName();
			String updatedMName = "UpdatedTC18" + studentsPage.getMiddleName();
			String updatedLName = "UpdatedTC18" + studentsPage.getLastName();
			String updatedStuID = "UpdatedTC18" + studentsPage.getStudentId();

			studentsPage.changeFirstName(updatedFName);
			studentsPage.changeMiddleName(updatedMName);
			studentsPage.changeLastName(updatedLName);
			studentsPage.changeStudentId(updatedStuID);

			SMUtils.nap(3);

			String genderVal = studentsPage.getSelectedValues(UserConstants.GENDER_FIELD);
			if (!genderVal.equals("Female")) {
				genderVal = "Female";
				driver.navigate().refresh();
				studentsPage.selectDemographicValues(UserConstants.GENDER_FIELD, genderVal);
			} else {
				genderVal = "Male";
				driver.navigate().refresh();
				studentsPage.selectDemographicValues(UserConstants.GENDER_FIELD, genderVal);
			}

			String ethnicityVal = studentsPage.getSelectedValues(UserConstants.ETHINICITY);
			if (!ethnicityVal.equals("Hispanic or Latino")) {
				ethnicityVal = "Hispanic or Latino";
				studentsPage.selectDemographicValues(UserConstants.ETHINICITY, ethnicityVal);
			} else {
				ethnicityVal = "Not Hispanic or Latino";
				studentsPage.selectDemographicValues(UserConstants.ETHINICITY, ethnicityVal);
			}
			studentsPage.clickSaveButtoninUserProfile();

			driver.navigate().refresh();

			Log.assertThat(studentsPage.getFirstName().equals(updatedFName), "First name updated successfully",
					"First name couldn't be udpdated");

			Log.assertThat(studentsPage.getMiddleName().equals(updatedMName), "Middle name updated successfully",
					"Middle name couldn't be udpdated");

			Log.assertThat(studentsPage.getLastName().equals(updatedLName), "Last name updated successfully",
					"Last name couldn't be udpdated");

			Log.assertThat(studentsPage.getStudentId().equals(updatedStuID), "Student ID updated successfully",
					"Student ID couldn't be udpdated");

			Log.assertThat(studentsPage.getSelectedValues(UserConstants.ETHINICITY).equals(ethnicityVal),
					"Ethinicity value updated successfully", "Ethinicity value couldn't be updated");

			Log.assertThat(studentsPage.getSelectedValues(UserConstants.GENDER_FIELD).equals(genderVal),
					"Gender value updated successfully", "Gender value couldn't be updated");

			studentsPage.changeFirstName(studentsPage.getFirstName().replace("UpdatedTC18", "").trim());
			studentsPage.changeMiddleName(studentsPage.getMiddleName().replace("UpdatedTC18", "").trim());
			studentsPage.changeLastName(studentsPage.getLastName().replace("UpdatedTC18", "").trim());
			studentsPage.changeStudentId(studentsPage.getStudentId().replace("UpdatedTC18", "").trim());

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the student listing displays correctly for usage goals in homepage for Math and Reading", groups = {
			"TeacherUISmoke" })
	public void Teacher_TC19() throws Exception {

		Log.testCaseInfo(
				"Teacher_TC19:  Verify the student listing displays correctly for usage goals in homepage for Math and Reading <small><b><i>["
						+ browser + "]</b></i></small>");
		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();

		CourseIds.add("1");
		CourseIds.add("2");

		HashMap<String, String> assignmentDetails = new HashMap<>();

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		studentDriver.register(eventListner);

		try {
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN_Two,
					password);
			SMUtils.nap(10);
			SMUtils.waitForSpinnertoDisapper(studentDriver);

			StudentDashboardPage studentsPage = new StudentDashboardPage(studentDriver);
			studentsPage.executeMathCourse(username, Constants.MATH, "100", "1", "2");
			SMUtils.nap(2);
			studentsPage = new StudentDashboardPage(studentDriver);
			studentsPage.executeReadingCourse(username, Constants.READING, "100", "1", "2");

			studentsPage.logout();

		} catch (Exception e) {
			Log.exception(e, studentDriver);
		} finally {
			studentDriver.quit();
			Log.endTestCase();
		}

		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		eventListner = new EventListener();
		driver.register(eventListner);

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);

			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			String studentName = SMUtils.getKeyValueFromResponse(studentDetailsTwo, "firstName") + " "
					+ SMUtils.getKeyValueFromResponse(studentDetailsTwo, "lastName");

			Log.message("Verifying usage goal status for student " + studentName);

			SMUtils.nap(10);
			tHomePage.navigateToUsageGoalsStudentsList(Constants.MATH);
			Log.assertThat(tHomePage.verifyColumnsInUsageGoalStudentListingPage(),
					"Column headers are verified successfully on usage goals page",
					"Coloumn headers verification failed on the usage goals page");

			List<String> studentNames = tHomePage.getStudentNamesFromUI();

			Log.assertThat(studentNames.contains(studentName), "Student name is verified on Usage goals page",
					"Student name is not present on Usage goals page");

			Map<String, String> studentGoalStatusFromUI = tHomePage.getGoalStatusFromUI();
			Map<String, String> studentTotalTimeFromUI = tHomePage.getColumnValuesFromUI("Total Time");
			Map<String, String> studentGoalEndDateFromUI = tHomePage.getColumnValuesFromUI("Goal End Date");
			Map<String, String> studentTargetHoursFromUI = tHomePage.getColumnValuesFromUI("Target Hours");
			Map<String, String> studentAvgTimePerWeekFromUI = tHomePage.getColumnValuesFromUI("Avg Time / Wk");

			Log.assertThat(studentGoalStatusFromUI.get(studentName).equals("In IP"),
					"In IP is displayed in usage goal status when the assignment started by the student",
					"In IP is not displayed in in usage goal status when the assignment is started by the student");

			Log.assertThat(studentTotalTimeFromUI.get(studentName).equals("In IP"),
					"In IP is displayed in Student total time when the assignment started by the student",
					"In IP is not displayed in Student total time when the assignment is started by the student");

			Log.assertThat(studentAvgTimePerWeekFromUI.get(studentName).equals("In IP"),
					"In IP is displayed in Student average time when the assignment started by the student",
					"In IP is not displayed in Student average time when the assignment is started by the student");

			Log.assertThat(!studentGoalEndDateFromUI.get(studentName).isEmpty(),
					"Student goal end date is not empty when the assignment started by the student",
					"Student goal end date is empty when the assignment is started by the student");

			Log.assertThat(studentTargetHoursFromUI.get(studentName).equals("23:00"),
					"Student target hours is 23:00 when the assignment started by the student",
					"Student target hours is not 23:00 when the assignment is started by the student");

			tHomePage.clickBackIconInUsageGoalStudentListingPage();

			// READING
			SMUtils.nap(10);
			tHomePage.navigateToUsageGoalsStudentsList(Constants.READING);
			Log.assertThat(tHomePage.verifyColumnsInUsageGoalStudentListingPage(),
					"Column headers are verified successfully on usage goals page",
					"Coloumn headers verification failed on the usage goals page");

			List<String> readingStudentNames = tHomePage.getStudentNamesFromUI();

			Log.assertThat(readingStudentNames.contains(studentName), "Student name is verified on Usage goals page",
					"Student name is not present on Usage goals page");

			Map<String, String> readingStudentGoalStatusFromUI = tHomePage.getGoalStatusFromUI();
			Map<String, String> readingStudentTotalTimeFromUI = tHomePage.getColumnValuesFromUI("Total Time");
			Map<String, String> readingStudentGoalEndDateFromUI = tHomePage.getColumnValuesFromUI("Goal End Date");
			Map<String, String> readingStudentTargetHoursFromUI = tHomePage.getColumnValuesFromUI("Target Hours");
			Map<String, String> readingStudentAvgTimePerWeekFromUI = tHomePage.getColumnValuesFromUI("Avg Time / Wk");

			Log.assertThat(readingStudentGoalStatusFromUI.get(studentName).equals("In IP"),
					"In IP is displayed in usage goal status when the assignment started by the student",
					"In IP is not displayed in in usage goal status when the assignment is started by the student");

			Log.assertThat(readingStudentTotalTimeFromUI.get(studentName).equals("In IP"),
					"In IP is displayed in Student total time when the assignment started by the student",
					"In IP is not displayed in Student total time when the assignment is started by the student");

			Log.assertThat(readingStudentAvgTimePerWeekFromUI.get(studentName).equals("In IP"),
					"In IP is displayed in Student average time when the assignment started by the student",
					"In IP is not displayed in Student average time when the assignment is started by the student");

			Log.assertThat(!readingStudentGoalEndDateFromUI.get(studentName).isEmpty(),
					"Student goal end date is not empty when the assignment started by the student",
					"Student goal end date is empty when the assignment is started by the student");

			Log.assertThat(readingStudentTargetHoursFromUI.get(studentName).equals("20:00"),
					"Student target hours is 20:00 when the assignment started by the student",
					"Student target hours is not 20:00 when the assignment is started by the student");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify the Completed Status when the assignment is completed", groups = { "TeacherUISmoke" })
	public void Teacher_TC20() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC20: Verify the Completed Status when the assignment is completed <small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			String staticCourseName;

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage courses = new CoursesPage(driver);

			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			staticCourseName = courses.generateRandomCourseName();

			List<String> CourseIds = new ArrayList<>();
			List<String> requestIds = new ArrayList<>();
			HashMap<String, String> assignmentDetails = new HashMap<>();

			// Create Course
			CourseIds.add(courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId.toString(),
					organizationId.toString(), DataSetupConstants.STANDARD, staticCourseName));
			;

			assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
			assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID,
					SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
			assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

			CourseIds.forEach(courseID -> {
				HashMap<String, String> response = new HashMap<>();
				try {
					assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
					requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
					requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
					response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
							AssignmentAPIConstants.USERS_TYPE);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Response : " + response);
			});

			tHomePage.topNavBar.signOutfromSM();

			// Login as Student
			// Get driver
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);
			try {
				LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN,
						password);
				SMUtils.nap(30);
				SMUtils.waitForSpinnertoDisapper(studentDriver);
				StudentDashboardPage studentsPage = new StudentDashboardPage(studentDriver);

				studentsPage.executeMathCourse(username, staticCourseName, "100", "15", "30");
				studentsPage.logout();

			} catch (Exception e) {
				Log.exception(e, studentDriver);
			} finally {
				studentDriver.quit();
				Log.endTestCase();
			}

			// Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);

			// Verify the Completed Status
			Log.assertThat(assignmentDetailsPage.checkCompletedTag(),
					"Assignment Completed Status Displays Successfully", "Assignment Completed Status Not Displays");

		} catch (Exception e) {
			Log.exception(e);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the teacher can view the student's mastery data from home page", groups = {
			"TeacherUISmoke" })
	public void Teacher_TC21() throws Exception {

		Log.testCaseInfo(
				"Teacher_TC21:  Verify the teacher can view the student's mastery data from home page <small><b><i>["
						+ browser + "]</b></i></small>");

		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();

		CourseIds.add("1");
		CourseIds.add("2");

		HashMap<String, String> assignmentDetails = new HashMap<>();
		String teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		// Get driver
		EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		studentDriver.register(eventListner);

		// logging as student
		try {
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN, password);
			SMUtils.nap(20);
			SMUtils.waitForSpinnertoDisapper(studentDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(studentDriver);

			studentsPage.executeMathCourse(username, Constants.MATH, "100", "1", "30");

			studentsPage = new StudentDashboardPage(studentDriver);

			studentsPage.executeReadingCourse(username, Constants.READING, "100", "1", "30");

			studentsPage.logout();

			// Logging as second student
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN_Two,
					password);
			SMUtils.nap(10);
			SMUtils.waitForSpinnertoDisapper(studentDriver);
			studentsPage = new StudentDashboardPage(studentDriver);
			studentsPage.executeMathCourse(username, Constants.MATH, "50", "1", "30");

			studentsPage = new StudentDashboardPage(studentDriver);
			studentsPage.executeReadingCourse(username, Constants.READING, "50", "1", "30");

			studentsPage.logout();

		} catch (Exception e) {
			Log.exception(e, studentDriver);
		} finally {
			studentDriver.quit();
			Log.endTestCase();
		}

		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		eventListner = new EventListener();
		driver.register(eventListner);

		try {
			// login to the app
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			SMUtils.waitForSpinnertoDisapper(driver);

			SMUtils.nap(30);
			List<String> subjects = new ArrayList<>();
			subjects.add(Constants.MATH);
			teacherHomePage.clickMasteryAssignmentDropdown();
			teacherHomePage.clickSelectAllCheckbox();
			teacherHomePage.clickMasteryAssignmentDropdown();
			teacherHomePage.selectAssignmentsinMasteryCard(Arrays.asList(Constants.MATH));

			Log.assertThat(teacherHomePage.isMasterycardHasSkills(),
					"The skills are displaying when assignment is selected!",
					"The skills are not displaying when assignment is selected!");

			teacherHomePage.verifyingMasteryCard();

			// Verifying Teacher is taken to the Mastery detail page on clicking view all
			teacherHomePage.clickViewAllinMasteryCard();
			MasteryPage masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();
			Log.assertThat(masteryPage.getMasteryHeading().equals("Mastery"), "Navigated to Mastery page",
					"Clicking view all  is not navigated to Mastery page");

			teacherHomePage.topNavBar.navigateToHomeTab();

			subjects.remove(Constants.MATH);
			subjects.add(Constants.READING);

			SMUtils.nap(3);
			teacherHomePage.clickMasterySubjectDropdown();
			teacherHomePage.clickDropdownValue(Constants.READING);

			SMUtils.nap(3);

			teacherHomePage.clickMasteryAssignmentDropdown();
			teacherHomePage.clickSelectAllCheckbox();
			teacherHomePage.clickMasteryAssignmentDropdown();
			teacherHomePage.selectAssignmentsinMasteryCard(Arrays.asList(Constants.READING));

			SMUtils.nap(3);

			Log.assertThat(teacherHomePage.isMasterycardHasSkills(),
					"The skills are displaying when assignment is selected!",
					"The skills are not displaying when assignment is selected!");

			teacherHomePage.verifyingMasteryCard();

			// Verifying Teacher is taken to the Mastery detail page on clicking view all
			teacherHomePage.clickViewAllinMasteryCard();
			masteryPage = teacherHomePage.topNavBar.navigateToMasteryTab();

			Log.assertThat(masteryPage.getMasteryHeading().equals("Mastery"), "Navigated to Mastery page",
					"Clicking view all  is not navigated to Mastery page");

			teacherHomePage.topNavBar.navigateToHomeTab();
			SMUtils.nap(10);
			teacherHomePage.clickMasteryAssignmentDropdown();
			teacherHomePage.clickSelectAllCheckbox();
			teacherHomePage.clickApplyFilterinMasteryCard();

			Log.assertThat(!teacherHomePage.isMasterycardHasSkills(), "The skills are not displaying as Expected!",
					"The skills are displaying for the when 0 assignment is checked");

			teacherHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Student usage widget in home dashboard", groups = { "TeacherUISmoke" })
	public void Teacher_TC22() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC22: Verify the Student usage widget in home dashboard. <small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			String staticCourseName;
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);

			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			Log.assertThat(tHomePage.isStudentUsageWidgetDisplayed(), "Student usage widget is displayed",
					"Student usage widget is not displayed");
			tHomePage.topNavBar.navigateToStudentsTab();

			CoursesPage courses = new CoursesPage(driver);

			staticCourseName = "TC22_Course_" + courses.generateRandomCourseName();

			List<String> CourseIds = new ArrayList<>();
			List<String> requestIds = new ArrayList<>();
			HashMap<String, String> assignmentDetails = new HashMap<>();
			CourseAPI courseAPI = new CourseAPI();
			// Create Course
			CourseIds.add(courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId.toString(),
					organizationId.toString(), DataSetupConstants.SETTINGS, staticCourseName));
			;
			assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
			assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID,
					SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
			assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

			CourseIds.forEach(courseID -> {
				HashMap<String, String> response = new HashMap<>();
				try {
					assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
					requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
					response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
							AssignmentAPIConstants.USERS_TYPE);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Response : " + response);
			});

			tHomePage.topNavBar.signOutfromSM();

			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);
			try {
				LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN,
						password);
				SMUtils.nap(30);
				SMUtils.waitForSpinnertoDisapper(studentDriver);
				StudentDashboardPage studentsPage = new StudentDashboardPage(studentDriver);

				studentsPage.executeMathCourse(username, staticCourseName, "100", "15", "30");
				studentsPage.logout();

			} catch (Exception e) {
				Log.exception(e, studentDriver);
			} finally {
				studentDriver.quit();
				Log.endTestCase();
			}

			// Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			List<String> assignmentList = new ArrayList<>();
			assignmentList.add(staticCourseName);
			tHomePage.loadUsageForParticularAssignments(assignmentList);

			// Verify student usage chart fields
			Log.assertThat(tHomePage.verifyStudentUsageChart(), "All fields displayed properly in student usage chart!",
					"Fields are not displayed properly in student usage chart.");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Group Usage and Skills Assessment details are shown in Group Details page", priority = 2, groups = {
			"TeacherUISmoke" })
	public void Teacher_TC23(ITestContext context) throws Exception {

		Log.testCaseInfo(
				"Teacher_TC23: Verify the Group Usage and Skills Assessment details are shown in Group Details page"
						+ "<small><b><i>[" + browser + "]</b></i></small>");

		String groupName = "TC23_AutomationUsageGrp_" + System.nanoTime();

		List<String> studentRumbaIds = new ArrayList<>();

		for (int stuCount = 0; stuCount < stuInfo.size(); stuCount++) {
			studentRumbaIds.add(SMUtils.getKeyValueFromResponse(stuInfo.get(stuCount), "userId"));
		}

		HashMap<String, String> groupDetailsMap = new HashMap<>();
		groupDetailsMap.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(username, password));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_OWNER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_NAME, groupName);
		HashMap<String, String> createGroup = new GroupAPI().createGroup(smUrl, groupDetailsMap, studentRumbaIds);

		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_NAME, groupName);
		createGroup = new GroupAPI().createGroup(smUrl, groupDetailsMap, studentRumbaIds);

		String organizationId = RBSDataSetup.organizationIDs.get(school);
		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();

		CourseIds.add("1");
		CourseIds.add("2");

		HashMap<String, String> assignmentDetails = new HashMap<>();

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);
		String stuUserName = SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userName");
		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		studentDriver.register(eventListner);

		try {
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, stuUserName,
					password);
			SMUtils.nap(30);
			SMUtils.waitForSpinnertoDisapper(studentDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(studentDriver);

			studentsPage.executeReadingCourse(username, Constants.READING, "100", "2", "10");

			studentsPage = new StudentDashboardPage(studentDriver);

			studentsPage.executeMathCourse(username, Constants.MATH, "100", "2", "10");

			studentsPage.logout();

		} catch (Exception e) {
			Log.exception(e, studentDriver);
		} finally {
			studentDriver.quit();
			Log.endTestCase();
		}

		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		eventListner = new EventListener();
		driver.register(eventListner);

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

			groupsTab.viewGroup(groupName);

			Log.assertThat(groupsTab.verifyGroupUsageChart(), "Group usage fields are verified successfully!",
					"Issue with group usage fields.");

			Log.assertThat(groupsTab.verifySkillsNameIsPresent(),
					"skills assessed displays the focused course LOs assessed within last 30 days by the students of the group",
					"skills assessed is not displays the default math/reading LOs assessed within last 30 days by the students of the group");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
		} catch (

		Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the teacher can view students mastery data from the Student details Page", groups = {
			"TeacherUISmoke" })
	public void Teacher_TC24() throws Exception {

		Log.testCaseInfo(
				"Teacher_TC24:  Verify the teacher can view students mastery data from the Student details Page <small><b><i>["
						+ browser + "]</b></i></small>");

		String mathCourseName = "TC24_MathCourse_" + System.nanoTime();
		String readingCourseName = "TC24_ReadingCourse_" + System.nanoTime();

		CourseId1 = courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId, organizationId.toString(),
				DataSetupConstants.STANDARD, mathCourseName);
		CourseId2 = courseAPI.createCourse(smUrl, token, DataSetupConstants.READING, teacherId,
				organizationId.toString(), DataSetupConstants.SETTINGS, readingCourseName);

		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();

		CourseIds.add(CourseId1);
		CourseIds.add(CourseId2);

		HashMap<String, String> assignmentDetails = new HashMap<>();
		String teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		// Get driver
		EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		studentDriver.register(eventListner);

		// logging as student
		try {
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN, password);
			SMUtils.nap(10);
			SMUtils.waitForSpinnertoDisapper(studentDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(studentDriver);
			studentsPage.executeMathCourse(username, mathCourseName, "100", "12", "25");
			SMUtils.nap(2);
			studentsPage = new StudentDashboardPage(studentDriver);
			studentsPage.executeReadingCourse(username, readingCourseName, "100", "5", "20");

			studentsPage.logout();

		} catch (Exception e) {
			Log.exception(e, studentDriver);
		} finally {
			studentDriver.quit();
		}

		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		eventListner = new EventListener();
		driver.register(eventListner);
		try {
			// login to the app
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			SMUtils.waitForSpinnertoDisapper(driver);

			StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
			studentsPage.clickviewStudentByEllipsis(studentUN);

			studentsPage.clickSubNavigation("Mastery");

			studentsPage.checkAllMasteryAssignmentsSelected();
			studentsPage.selectMasteryAssignments(mathCourseName);
			studentsPage.clickApplyFilter();

			MasterySummaryComponent masteryComponent = new MasterySummaryComponent(driver);
			Log.assertThat(masteryComponent.isMasterySummaryPageLoaded(), "The Mastery sub-navigation is displayed",
					"The Mastery sub-navigation is not displayed");

			Log.assertThat(
					masteryComponent.getStatusColor(browser)
							.contains(Constants.MasteryUI.MASTERED_COLOR_CODE.toLowerCase()),
					"Mastered status is indicated by Green color in the progress bar ",
					"Mastered status is not indicated by Green color in the progress bar ");

			Log.assertThat(masteryComponent.verifyGradeIsDisplayed(),
					"Grade is displayed under mastery tab in the Student mastery page",
					"Grade is not displayed under mastery tab in the Student mastery page");

			Log.assertThat(masteryComponent.verifySkillHeadingIsDisplayed(),
					"Skill heading is displayed under domain and cluster in mastery tab of the Student mastery page",
					"Skill heading is not displayed under domain and cluster in mastery tab of the Student mastery page");

			Log.assertThat(masteryComponent.verifyLOColor(browser),
					"Teacher is able to see the LO as a blue link on Student mastery page",
					"Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills on Student mastery page");

			// Navigating to mastery Details page
			MasteryDetailsPage masteryDetailsPage = masteryComponent
					.navigateToLoViewPage(masteryComponent.getProgressBarLink(Constants.MasteryUI.MASTERED).get(0));
			Log.assertThat(masteryDetailsPage.isDetailsDisplayed(), "Details field is displayed",
					"Details field is not displayed");

			// Verify the count of students got mastered/Not mastered/At Risk/ displayed in
			// the progress bar is matching with TOTAL count of students have taken
			// assessment displayed above the progress bar after the same student has been
			// assigned to multiple assignments." );
			Log.assertThat(
					masteryDetailsPage.getStudentCounts().contentEquals(masteryDetailsPage.getNoOfStudentAssessed()),
					"The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is matching with TOTAL count of students have taken assessment displayed above the progress bar ",
					" The count of students got mastered/Not mastered/At Risk/ displayed in the progress bar is not matching with TOTAL count of students have taken assessment displayed above the progress bar");

			masteryDetailsPage.clickBackBtn();

			SMUtils.nap(3);

			studentsPage.selectDropDownValues(Mastery_DropDowns.SUBJECT,
					Constants.Students.SUBJECT_DROPDOWN_VALUES.get(1));
			studentsPage.checkAllMasteryAssignmentsSelected();
			studentsPage.selectMasteryAssignments(readingCourseName);
			studentsPage.clickApplyFilter();

			masteryComponent = new MasterySummaryComponent(driver);

			// MasterySummaryComponent masterySummaryComponent =
			// masteryFiltersComponent.applyFilter();
			List<WebElement> masteredProgressBars = masteryComponent.getProgressBarLink(Constants.MasteryUI.MASTERED);
			masteryDetailsPage = masteryComponent.navigateToLoViewPage(masteredProgressBars.get(0));

			Log.assertThat(Constants.MasteryUI.masteryTableHeaders.equals(masteryDetailsPage.getStudentTableHeaders()),
					"The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are available in the mastery header",
					"The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are not available in the mastery header");

			teacherHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Teacher who created the course is able to 'Remove' the course", groups = {
			"TeacherUISmoke" })
	public void Teacher_TC25(ITestContext context) throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"Teacher_TC25: Verify the Teacher who created the course is able to 'Remove' the course <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			coursePage.clickReadingCourse();
			coursePage.clickMakeCopyBtn();
			String courseName = coursePage.generateRandomCourseName();
			coursePage.enterCourseName(courseName);
			coursePage.clickNextBtn();
			coursePage.clickCreateBtn();

			Log.assertThat(coursePage.verifyCoursePresence(courseName),
					"New course is present in the course listing page",
					"New course is not found in the course listing page");

			coursePage.clickCourseName(courseName);
			coursePage.removeCourse();

			// To Verify that course is removed from course listing page
			coursePage.verifyCourseRemovedSuccessfully(courseName);
			Log.assertThat(!coursePage.verifyCoursePresence(courseName), "New course is successfully removed",
					"New course is still present and not removed");

			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickMathCourse();
			coursePage.clickMakeCopyBtn();
			String newCourseName = coursePage.generateRandomCourseName();
			coursePage.enterCourseName(newCourseName);
			coursePage.clickNextBtn();
			coursePage.clickCreateBtn();

			Log.assertThat(coursePage.verifyCoursePresence(newCourseName),
					"New course is present in the course listing page",
					"New course is not found in the course listing page");

			coursePage.clickCourseName(newCourseName);
			coursePage.clickAssignBtn();

			coursePage.addCourseToGroups();
			coursePage.clickAssignBtn();

			// Adding Custom courses to Students
			SMUtils.nap(2);

			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickCourseName(newCourseName);
			SMUtils.nap(2);
			coursePage.clickEllipsisIcon();
			coursePage.clickViewAssignedByButton();
			List<String> teachersName = new ArrayList<>();
			teachersName = coursePage.getTeacherListFromViewAssignedByPopup();
			coursePage.clickViewAssignedByPopupCloseBtn();

			MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

			if (myProfilePage.getUserTitle().equals("Select Title"))
				teacherName = myProfilePage.getFirstName() + " " + myProfilePage.getMiddleName() + " "
						+ myProfilePage.getLastName();
			else
				teacherName = myProfilePage.getUserTitle() + ". " + myProfilePage.getFirstName() + " "
						+ myProfilePage.getMiddleName() + " " + myProfilePage.getLastName();

			Log.assertThat(teachersName.contains(teacherName.trim()), "The assigned name is correct",
					"The assigned name is not correct");

			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage
					.viewAssignmentDetailsByAssignmentName(newCourseName);
			assignmentDetailsPage.assignmentLevelEllipsis();
			assignmentDetailsPage.deleteAssignmenttab();
			SMUtils.nap(2); // required for popup load
			assignmentDetailsPage.deleteAssignmentButton();
			Log.assertThat(assignmentDetailsPage.isAssignmentDisplayed(), "Assignment has removed successfully",
					"Assignment has not removed successfully");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the IP Level, Current Level and Session pop up data", groups = { "TeacherUISmoke" })
	public void Teacher_TC26() throws Exception {

		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();
		HashMap<String, String> assignmentDetails = new HashMap<>();

		// Create Course
		CourseIds.add("1");
		CourseIds.add("2");

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		// Get driver
		EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		studentDriver.register(eventListner);
		// Get Test Data
		Log.testCaseInfo("Verify the IP Level, Current Level and Session pop up data <small><b><i>[" + browser
				+ "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN_Two,
					password);
			SMUtils.nap(30);
			SMUtils.waitForSpinnertoDisapper(studentDriver);
			StudentDashboardPage stuPage = new StudentDashboardPage(studentDriver);

			stuPage.executeMathCourse(teacherId, Constants.MATH, "100", "5", "30");

			stuPage = new StudentDashboardPage(studentDriver);
			stuPage.executeReadingCourse(teacherId, Constants.READING, "100", "5", "30");

			stuPage.logout();

		} catch (IOException e) {
			Log.message("Error occurred while running the simulator");
		} finally {

			studentDriver.quit();
		}

		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		eventListner = new EventListener();
		driver.register(eventListner);

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			SMUtils.nap(5);
			AssignmentsPage assignmentList = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			assignmentList.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = assignmentList
					.viewAssignmentDetailsByAssignmentName(Constants.MATH);
			String studentName = assignmentDetailsPage.getStudentName(
					SMUtils.getKeyValueFromResponse(studentDetailsTwo, "firstName"),
					SMUtils.getKeyValueFromResponse(studentDetailsTwo, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetailsTwo, "lastName"));

			assignmentDetailsPage.clickStudentAccordionButton(studentName);

			Log.assertThat(assignmentDetailsPage.isProgressMonitoringGraphDisplayed(),
					"Progress Monitoring Graph Displayed Successfuly", "Progress Monitoring Graph Not Displayed");

			assignmentDetailsPage.clickViewSummaryPage();

			Log.assertThat((assignmentDetailsPage.getTextProgressHeading()).equals(Constants.SUMMARY_HEADER),
					"Progress Header  displayed correctly", "Progress Header not displayed correctly");

			List<String> summaryHeaders = assignmentDetailsPage.getViewSummayHeaders();
			Log.assertThat((summaryHeaders).equals(Constants.VIEW_SUMMARY_HEADER),
					"View Summary Headers are displayed successfully",
					"View Summary Headers are not displayed correctly");

			List<String> summaryLabelsFromPage = assignmentDetailsPage.getViewSummayDetails();
			Log.assertThat((summaryLabelsFromPage).equals(Constants.VIEW_SUMMARY),
					"Summary Labels are displayed correctly", "Summary Labels are not displayed correctly");

			Log.assertThat(assignmentDetailsPage.isdisplayedViewGraph(), "View Graph Button is displayed successfully",
					"View Graph Button is not  displayed");

			// Verifying the Primary and Secondary Target Value
			assignmentDetailsPage.calculationPrimarySecondary();

			// READING
			assignmentList = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			assignmentList.clickAssignmentSubMenu();

			// Click on ViewAssignments
			assignmentDetailsPage = assignmentList.viewAssignmentDetailsByAssignmentName(Constants.READING);

			assignmentDetailsPage.clickStudentAccordionButton(studentName);

			Log.assertThat(assignmentDetailsPage.isProgressMonitoringGraphDisplayed(),
					"Progress Monitoring Graph Displayed Successfuly", "Progress Monitoring Graph Not Displayed");

			assignmentDetailsPage.clickViewSummaryPage();

			Log.assertThat((assignmentDetailsPage.getTextProgressHeading()).equals(Constants.SUMMARY_HEADER),
					"Progress Header  displayed correctly", "Progress Header not displayed correctly");

			List<String> summaryReadingHeaders = assignmentDetailsPage.getViewSummayHeaders();
			Log.assertThat((summaryReadingHeaders).equals(Constants.VIEW_SUMMARY_HEADER),
					"View Summary Headers are displayed successfully",
					"View Summary Headers are not displayed correctly");

			List<String> summaryLabelsFromReadingPage = assignmentDetailsPage.getViewSummayDetails();
			Log.assertThat((summaryLabelsFromReadingPage).equals(Constants.VIEW_SUMMARY),
					"Summary Labels are displayed correctly", "Summary Labels are not displayed correctly");

			Log.assertThat(assignmentDetailsPage.isdisplayedViewGraph(), "View Graph Button is displayed successfully",
					"View Graph Button is not  displayed");

			//Verify the Primary Target and Secondary target value in the view summary of Math;
			// Verifying the Primary and Secondary Target Value
			assignmentDetailsPage.calculationPrimarySecondary();

			// Sign Out
			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, studentDriver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify Groups->Mastery Summary Page", groups = { "TeacherUISmoke" })
	public void Teacher_TC27() throws Exception {

		Log.testCaseInfo(
				"Teacher_TC27: Verify Groups->Mastery Summary Page <small><b><i>[" + browser + "]</b></i></small>");

		String groupName = "TC27_AutoSmokeGrp_" + System.nanoTime();
		List<String> studentRumbaIds = new ArrayList<>();

		for (int i = 0; i < stuInfo.size(); i++) {
			studentRumbaIds.add(SMUtils.getKeyValueFromResponse(stuInfo.get(i), "userId"));
		}

		HashMap<String, String> groupDetailsMap = new HashMap<>();
		groupDetailsMap.put(RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken(username, password));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_OWNER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_NAME, groupName);
		HashMap<String, String> createGroup = new GroupAPI().createGroup(smUrl, groupDetailsMap, studentRumbaIds);

		groupDetailsMap.put(CreateGroupAPIConstants.GROUP_NAME, groupName);
		createGroup = new GroupAPI().createGroup(smUrl, groupDetailsMap, studentRumbaIds);

		String mathCourseName = "TC27_MathAutoCourse_" + System.nanoTime();
		String readingCourseName = "TC27_ReadingAutoCourse_" + System.nanoTime();

		CourseId1 = courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId, organizationId.toString(),
				DataSetupConstants.SETTINGS, mathCourseName);
		CourseId2 = courseAPI.createCourse(smUrl, token, DataSetupConstants.READING, teacherId,
				organizationId.toString(), DataSetupConstants.SETTINGS, readingCourseName);

		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();

		CourseIds.add(CourseId1);
		CourseIds.add(CourseId2);

		HashMap<String, String> assignmentDetails = new HashMap<>();
		String teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsOne, "userId"));
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		studentDriver.register(eventListner);

		// logging as student
		try {
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN_Two,
					password);
			SMUtils.nap(10);
			SMUtils.waitForSpinnertoDisapper(studentDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(studentDriver);

			studentsPage.executeMathCourse(username, mathCourseName, "100", "2", "30");

			studentsPage = new StudentDashboardPage(studentDriver);
			studentsPage.executeReadingCourse(username, readingCourseName, "100", "2", "30");

			studentsPage.logout();

		} catch (Exception e) {
			Log.exception(e, studentDriver);
		} finally {
			studentDriver.quit();
		}

		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		eventListner = new EventListener();
		driver.register(eventListner);

		// logging as student
		try {
			// login to the app
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			SMUtils.waitForSpinnertoDisapper(driver);

			GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
			groupsTab.viewGroup(groupName);

			groupsTab.clickGroupsSubNav(Constants.MASTERY);
			SMUtils.waitForElement(driver, groupsTab.masteryHeader);
			Log.assertThat(groupsTab.masteryHeader.getText().equals(Constants.MASTERY),
					"The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully");

			MasteryFiltersComponent MasteryFiltersComponent = new MasteryFiltersComponent(driver);
			MasteryFiltersComponent.setDropDownMS(Constants.MasteryUI.ASSIGNMENTS);
			MasteryFiltersComponent.selectValuesFromDropDownMS(Arrays.asList(mathCourseName));
			MasteryFiltersComponent.clickApplyFilter();

			MasterySummaryComponent masterySummary = new MasterySummaryComponent(driver);

			// Get webElement of Progress Bar
			List<WebElement> progressBarLink = masterySummary.getProgressBarLink(Constants.MasteryUI.MASTERED);

			WebElement progressBarElement = progressBarLink.get(0);

			MasteryDetailsPage masteryDetailsPage = masterySummary.navigateToLoViewPage(progressBarElement);

			List<String> assignmentList = masteryDetailsPage.getAssignmentNameList();
			Log.assertThat(assignmentList.contains(mathCourseName),
					"Assignment " + mathCourseName + " is present on the mastery details page",
					"Assignment " + mathCourseName + " is not present on the mastery details page");

			List<String> studentsName = masteryDetailsPage.getStudentName(mathCourseName);
			String studentName = SMUtils.getKeyValueFromResponse(studentDetailsTwo, "firstName") + " "
					+ SMUtils.getKeyValueFromResponse(studentDetailsTwo, "lastName");
			Log.assertThat(studentsName.contains(studentName), "Student name is displayed on the mastery details page",
					"Student name is not visible on the mastery details page");

			masteryDetailsPage.clickBackBtn();
			SMUtils.waitForSpinnertoDisapper(driver);

			// READING
			MasteryFiltersComponent.selectSubject(Constants.READING);
			MasteryFiltersComponent.setDropDownMS(Constants.MasteryUI.ASSIGNMENTS);
			MasteryFiltersComponent.selectValuesFromDropDownMS(Arrays.asList(readingCourseName));
			MasteryFiltersComponent.clickApplyFilter();

			// Get webElement of Progress Bar
			List<WebElement> redingProgressBarLink = masterySummary.getProgressBarLink(Constants.MasteryUI.MASTERED);

			WebElement redingProgressBarElement = redingProgressBarLink.get(0);

			masteryDetailsPage = masterySummary.navigateToLoViewPage(redingProgressBarElement);

			List<String> redingAssignmentList = masteryDetailsPage.getAssignmentNameList();
			Log.assertThat(redingAssignmentList.contains(readingCourseName),
					"Assignment " + mathCourseName + " is present on the mastery details page",
					"Assignment " + mathCourseName + " is not present on the mastery details page");

			List<String> readingStudentsName = masteryDetailsPage.getStudentName(readingCourseName);

			Log.assertThat(readingStudentsName.contains(studentName),
					"Student name is displayed on the mastery details page",
					"Student name is not visible on the mastery details page");

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify Teacher can view Student's Mastery details on an Assignment", groups = {
			"TeacherUISmoke" })
	public void Teacher_TC28() throws Exception {

		Log.testCaseInfo(
				"Teacher_TC28:  Verify Teacher can view Student's Mastery details on an Assignment <small><b><i>["
						+ browser + "]</b></i></small>");

		String mathCourseName = "TC28_MathCourse_" + System.nanoTime();
		String readingCourseName = "TC28_ReadingCourse_" + System.nanoTime();

		CourseId1 = courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId, organizationId.toString(),
				DataSetupConstants.SETTINGS, mathCourseName);
		CourseId2 = courseAPI.createCourse(smUrl, token, DataSetupConstants.READING, teacherId,
				organizationId.toString(), DataSetupConstants.SETTINGS, readingCourseName);

		List<String> CourseIds = new ArrayList<>();
		List<String> requestIds = new ArrayList<>();

		CourseIds.add(CourseId1);
		CourseIds.add(CourseId2);

		HashMap<String, String> assignmentDetails = new HashMap<>();
		String teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");

		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, organizationId);

		CourseIds.forEach(courseID -> {
			HashMap<String, String> response = new HashMap<>();
			try {
				assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, courseID);
				requestIds.add(SMUtils.getKeyValueFromResponse(studentDetailsThree, "userId"));
				response = assignmentAPI.assignAssignment(smUrl, assignmentDetails, requestIds,
						AssignmentAPIConstants.USERS_TYPE);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response : " + response);
		});

		EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		studentDriver.register(eventListner);

		// logging as student
		try {
			LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN_Three,
					password);
			SMUtils.nap(10);
			SMUtils.waitForSpinnertoDisapper(studentDriver);
			StudentDashboardPage studentsPage = new StudentDashboardPage(studentDriver);

			studentsPage.executeMathCourse(username, mathCourseName, "100", "5", "30");

			studentsPage = new StudentDashboardPage(studentDriver);
			studentsPage.executeReadingCourse(username, readingCourseName, "100", "5", "30");

			studentsPage.logout();

		} catch (Exception e) {
			Log.exception(e, studentDriver);
		} finally {
			studentDriver.quit();
			Log.endTestCase();
		}

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		eventListner = new EventListener();
		driver.register(eventListner);

		try {

			// login to the app
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			SMUtils.waitForSpinnertoDisapper(driver);

			AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailspage = assignmentPage
					.viewAssignmentDetailsByAssignmentName(mathCourseName);

			assignmentDetailspage.clickMasteryToggleButton();
			SMUtils.nap(5);
			MasterySummaryComponent masteryComponent = new MasterySummaryComponent(driver);

			// Verify the progress bar, 'Mastered' status is indicated by Green color
			Log.assertThat(
					masteryComponent.getStatusColor(browser)
							.contains(Constants.MasteryUI.MASTERED_COLOR_CODE.toLowerCase()),
					"Mastered status is indicated by Green color in the progress bar ",
					"Mastered status is not indicated by Green color in the progress bar ");

			MasteryDetailsPage masteryDetailsPage = masteryComponent
					.navigateToLoViewPage(masteryComponent.getProgressBarLink(Constants.MasteryUI.MASTERED).get(0));
			Log.assertThat(masteryDetailsPage.isDetailsDisplayed(), "Details field is displayed",
					"Details field is not displayed");

			// Verify Progress Bar
			Log.softAssertThat(assignmentDetailspage.verifyProgressBar(), "Progress bar appears",
					"Progress bar doesn't appear");

			// verify student name column
			Log.softAssertThat(assignmentDetailspage.verifyStudentNameColumn(), "Student name colmn appears",
					"Student name colmn doesn't appears");

			// verify mastery status column
			Log.softAssertThat(assignmentDetailspage.verifyMasteryStatusColumn(), "Mastery status colmn appears",
					"Mastery status colmn doesn't appear");

			// verify skills evaluated column
			Log.softAssertThat(assignmentDetailspage.verifySkillsColumn(), "Skills colmn appears",
					"Skills colmn doesn't appears");

			// verify Attempts column
			Log.softAssertThat(assignmentDetailspage.verifyStudentAttemptsColumn(), "Attempt colmn appears",
					"Attempt colmn doesn't appears");

			String studentName = SMUtils.getKeyValueFromResponse(studentDetailsThree, "firstName") + " "
					+ SMUtils.getKeyValueFromResponse(studentDetailsThree, "lastName");

			Log.assertThat(studentName.equals(assignmentDetailspage.studentName.getText().trim()),
					"Mastery page has the student present that mastered the skill",
					"Mastery page doesn't have the student present that mastered the skill");

			// READING
			assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
			assignmentDetailspage = assignmentPage.viewAssignmentDetailsByAssignmentName(readingCourseName);

			assignmentDetailspage.clickMasteryToggleButton();
			SMUtils.nap(5);

			// Verify the progress bar, 'Mastered' status is indicated by Green color
			Log.assertThat(
					masteryComponent.getStatusColor(browser)
							.contains(Constants.MasteryUI.MASTERED_COLOR_CODE.toLowerCase()),
					"Mastered status is indicated by Green color in the progress bar ",
					"Mastered status is not indicated by Green color in the progress bar ");

			masteryDetailsPage = masteryComponent
					.navigateToLoViewPage(masteryComponent.getProgressBarLink(Constants.MasteryUI.MASTERED).get(0));
			Log.assertThat(masteryDetailsPage.isDetailsDisplayed(), "Details field is displayed",
					"Details field is not displayed");

			// Verify Progress Bar
			Log.softAssertThat(assignmentDetailspage.verifyProgressBar(), "Progress bar appears",
					"Progress bar doesn't appear");

			// verify student name column
			Log.softAssertThat(assignmentDetailspage.verifyStudentNameColumn(), "Student name colmn appears",
					"Student name colmn doesn't appears");

			// verify mastery status column
			Log.softAssertThat(assignmentDetailspage.verifyMasteryStatusColumn(), "Mastery status colmn appears",
					"Mastery status colmn doesn't appear");

			// verify skills evaluated column
			Log.softAssertThat(assignmentDetailspage.verifySkillsColumn(), "Skills colmn appears",
					"Skills colmn doesn't appears");

			// verify Attempts column
			Log.softAssertThat(assignmentDetailspage.verifyStudentAttemptsColumn(), "Attempt colmn appears",
					"Attempt colmn doesn't appears");

			Log.assertThat(studentName.equals(assignmentDetailspage.studentName.getText().trim()),
					"Mastery page has the student present that mastered the skill",
					"Mastery page doesn't have the student present that mastered the skill");

			teacherHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.testCaseResult();
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify teacher adding SM product to the Realize Class is brining the class to SM.", groups = {
			"TeacherUISmoke" })
	public void Teacher_TC30() throws Exception {

		// Get driver
		EventFiringWebDriver realizedriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		realizedriver.register(eventListner);

		Log.testCaseInfo(
				"Teacher_TC30: Verify teacher adding SM product to the Realize Class is brining the class to SM. <small><b><i>["
						+ browser + "]</b></i></small>");

		String classname = "TC30_RealizeClass_" + System.nanoTime();
		String stusername = String.valueOf(System.nanoTime());

		try {
			LoginPage realizeLogin = new LoginPage(realizedriver, realizeUrl).get();
			RealizeTeacherHomePage teacherhomepage = realizeLogin.signInToRealize(realizedriver, realizeUrl, username,
					password);

			SMUtils.nap(2);

			if (realizedriver.getCurrentUrl().toLowerCase().contains("/community/welcome"))
				teacherhomepage.welcomeToTeacherRegistration(programname, "Teacher_TC30");

			SMUtils.nap(3);

			teacherhomepage.clickClassestab();
			teacherhomepage.createClasses();

			if (realizedriver.getCurrentUrl().toLowerCase().contains("/community/welcome")) {
				teacherhomepage.welcomeToTeacherRegistration(programname, "Teacher_TC30");
				SMUtils.nap(5);
				teacherhomepage.clickClassestab();
				teacherhomepage.createClasses();
			}

			Log.assertThat(teacherhomepage.isCreateClassPageDisplayed(), "Successfully landed to the create class page",
					"Not able to launch the create class page");
			teacherhomepage.enterClassName(classname);
			teacherhomepage.pickProgram(programname);
			String studentname = SMUtils.getKeyValueFromResponse(studentDetailsOne, "firstName") + ", "
					+ SMUtils.getKeyValueFromResponse(studentDetailsOne, "lastName");
			teacherhomepage.enterStudentName(0, studentname);
			teacherhomepage.enterUserName(0, stusername);
			teacherhomepage.enterPassword(0, "testing123$");
			teacherhomepage.clickSaveBtn(true);
			SMUtils.nap(5);

			EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);

			try {

				LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);

				TeacherHomePage tHomePage = new TeacherHomePage(driver);
				GroupPage groupspage = tHomePage.topNavBar.navigateToGroupsTab();

				Log.assertThat(!groupspage.isGroupExist(classname),
						"The group " + classname
								+ " is not visible in successmaker without SM license added in Realize",
						"The group " + classname + " is visible in SM without licensed added in Realize");

			} catch (Exception e) {
				Log.exception(e, driver);
			} finally {
				Log.endTestCase();
			}

			try {

				realizeLogin = new LoginPage(realizedriver, realizeUrl).get();
				teacherhomepage = realizeLogin.signInToRealize(realizedriver, realizeUrl, username, password);

				SMUtils.nap(2);
				teacherhomepage.clickClassestab();
				Log.assertThat(teacherhomepage.clickClassName(classname),
						"Clicked class " + classname + " successfully", "Not able to click the class");

				teacherhomepage.navigateToClassSettingsPage(classname, true);
				SMUtils.nap(5);
				teacherhomepage.pickProgramClassSettings("SuccessMaker Flex", true);
				teacherhomepage.clickSaveBtnClassSettings();
				SMUtils.nap(10);

			} catch (Exception e) {
				Log.exception(e, realizedriver);
			} finally {
				Log.endTestCase();
			}
			driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);

			try {
				LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
				TeacherHomePage tHomePage = new TeacherHomePage(driver);

				GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
				Log.assertThat(groupsTab.isGroupExist(classname),
						"The group " + classname + " is visible in successmaker after adding SM license in Realize",
						"The group " + classname + " cannot be found in SM");

			} catch (Exception e) {
				Log.exception(e, driver);
			} finally {
				driver.quit();
				Log.endTestCase();
			}
		} catch (Exception e) {
			Log.exception(e, realizedriver);
		} finally {
			realizedriver.quit();
			Log.testCaseResult();
			Log.endTestCase();
		}
	}

	@Test(description = "Verify license purchase of SM flex product", groups = { "TeacherUISmoke" })
	public void Teacher_TC31() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC31: Verify license purchase of SM flex product <small><b><i>[" + browser
				+ "]</b></i></small>");

		try {

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			Log.assertThat((courseListingPage.mathDefaultCourse.getText().trim().equalsIgnoreCase("Math")),
					"PASS: Default Math Couse appears in Default courses",
					"FAIL: Default Math Couse does not appear in Default courses");

			Log.assertThat((courseListingPage.readingDefaultCourse.getText().trim().equalsIgnoreCase("Reading")),
					"PASS: Default Reading Couse appears in Default courses",
					"FAIL: Default Reading Couse does not appear in Default courses");

			courseListingPage.selectCourseTypeFromDropDown(Constants.FOCUS_COURSES);

			List<String> focusCourses = courseListingPage.getFocusCourses();
			Log.softAssertThat(SMUtils.compareTwoList(FOCUS_COURSES, focusCourses), "PASS: Focus couses are visible.",
					"FAIL: Focus couses are not visible.");

			tHomePage.topNavBar.signOutfromSM();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			if (driver != null) {
				driver.quit();
			}
			Log.testCaseResult();
			Log.endTestCase();
		}

	}

}
