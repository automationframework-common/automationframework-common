package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.FileNameConstatnts;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

/**
 * To get the Student Details from the Given Teacher Id
 * 
 * @author suriya.kumar
 *
 */
public class StudentDetailsForStudentId extends UserAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    //String sessionCookie;

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String classId = null;
    String className = null;

    // Teacher variable used for this class
    private String orgUsed = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherUsed;
    private String orgId;
    private String teacherId;
    private String studentsId;
    private String studentUsername;
    private String username;
    private String studentDetails;
    private String teacherdetails1Org1;
    private String teacherdetails2Org1;

    // other school constants
    private String readingSchoolId;
    private String readingSchoolTeacherId;
    private String readingSchoolTeacherUsername;

    // Second Teacher
    private String secondTeacherId;
    private String secondTeacherUsername;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        // Teacher used Details
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        teacherdetails1Org1 = RBSDataSetup.getMyTeacher( orgUsed );
        teacherId = SMUtils.getKeyValueFromResponse( teacherdetails1Org1, RBSDataSetupConstants.USERID );
        username = SMUtils.getKeyValueFromResponse( teacherdetails1Org1, RBSDataSetupConstants.USERNAME );

        // Student Username
        studentDetails = RBSDataSetup.getMyStudent( orgUsed, username );
        studentsId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );

        // Second Teacher for Data Setup purposes

        teacherdetails2Org1 = RBSDataSetup.getMyTeacher( orgUsed );
        secondTeacherId = SMUtils.getKeyValueFromResponse( teacherdetails2Org1, RBSDataSetupConstants.USERID );
        secondTeacherUsername = SMUtils.getKeyValueFromResponse( teacherdetails2Org1, RBSDataSetupConstants.USERNAME );

        // Other School Details
        readingSchoolId = RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) );
        JSONObject otherSchoolTeacherJson = new JSONObject( ( RBSDataSetup.orgTeacherDetails.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) ).get( "Teacher1" ) );
        readingSchoolTeacherId = new SMAPIProcessor().getKeyValues( otherSchoolTeacherJson, RBSDataSetupConstants.USERID ).get( 0 );
        readingSchoolTeacherUsername = new SMAPIProcessor().getKeyValues( otherSchoolTeacherJson, RBSDataSetupConstants.USERNAME ).get( 0 );

    }

    /**
     * Data provider for negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "negativeScenarios" )
    public Object[][] negativeData() {

        Object[][] inputData = { { "SMK-16937 - Verify the api Given that Org id is different from the teacher present in organization", "OTHER_SCHOOL_ORGID", "403", CommonAPIConstants.ACCESS_DENIED_EXCEPTION },
                { "SMK-16933- Verify the  403 response code for student autorization.", "STUDENT_AUTH", "403", CommonAPIConstants.ACCESS_DENIED_EXCEPTION },
                { "SMK-16932 - Verify the 401 response code for invalid credentials.", "INVALID_AUTH", "401", CommonAPIConstants.JAVA_LANG_EXCEPTION },
                { "SMK-16938- Verify the 401 response code for null student id.", "STUDENTID_null", "200", CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION },
                { "SMK-16939- Verify the 400 response code for invalid student Id", "INVALID_STUDENT_ID", "200", CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION },
                { "SMK-16946- Verify the response when the student deleted", "STUDENT_DELETED", "200", CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION } };
        return inputData;
    }

    @Test ( priority = 2, description = "In Valid Scenarios", dataProvider = "negativeScenarios", groups = { "SMK-52005", "Students", "StudentDetailsForStudentId", "API" } )
    public void tcStudentDetailsByStudentId_01( String description, String scenario, String expCode, String expException ) throws Exception {
        Log.testCaseInfo( description );

        // Constants
        HashMap<String, String> response = null;
        String studentName;
        String studentDetails;
        String studentId;
        HashMap<String, String> userDetails;
        String accessToken;
        String classId;

        switch ( scenario ) {

            case "OTHER_SCHOOL_ORGID":

                /*
                 * // Studnet Creation studentName = "student" +
                 * System.nanoTime(); studentDetails = new
                 * UserAPI().createUserWithCustomization( studentName,
                 * RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                 * studentId = new SMUtils().getKeyValueFromResponse(
                 * studentDetails, RBSDataSetupConstants.USERID );
                 */

                // Enrolling student into the class
                accessToken = new RBSUtils().getAccessToken( username, password );
                className = "Class" + System.nanoTime();
                classId = new GroupAPI().createGroupWithCustomization( className, teacherId, Arrays.asList( studentsId ), orgId, accessToken );

                // Update the student
                userDetails = new HashMap<String, String>();
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsername );
                userDetails.put( RBSDataSetupConstants.USERID, studentsId );
                userDetails.put( RBSDataSetupConstants.PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails.put( RBSDataSetupConstants.ORG_ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                userDetails.put( RBSDataSetupConstants.TITLE, StudentDetailsForStudentIdAPIConstants.TITLE_MR );
                new RBSUtils().updateUserByUserService( userDetails );

                // Getting response
                response = getStudentDetailsByStudentId( studentsId, teacherId, readingSchoolId, accessToken );
                break;

            case "STUDENT_AUTH":

                /*
                 * // Studnet Creation studentName = "student" +
                 * System.nanoTime(); studentDetails = new
                 * UserAPI().createUserWithCustomization( studentName,
                 * RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                 * studentId = new SMUtils().getKeyValueFromResponse(
                 * studentDetails, RBSDataSetupConstants.USERID );
                 */

                // Enrolling student into the class
                accessToken = new RBSUtils().getAccessToken( studentUsername, password );

                // Update the student
                userDetails = new HashMap<String, String>();
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsername );
                userDetails.put( RBSDataSetupConstants.USERID, studentsId );
                userDetails.put( RBSDataSetupConstants.PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails.put( RBSDataSetupConstants.ORG_ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                userDetails.put( RBSDataSetupConstants.TITLE, StudentDetailsForStudentIdAPIConstants.TITLE_MR );
                new RBSUtils().updateUserByUserService( userDetails );

                // Getting response
                response = getStudentDetailsByStudentId( studentsId, studentsId, orgId, accessToken );
                break;

            case "INVALID_AUTH":
                // Studnet Creation
                studentName = "student" + System.nanoTime();
                studentDetails = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

                // Enrolling student into the class
                accessToken = new RBSUtils().getAccessToken( studentName, password );

                // Update the student
                userDetails = new HashMap<String, String>();
                userDetails.put( RBSDataSetupConstants.USERNAME, studentName );
                userDetails.put( RBSDataSetupConstants.USERID, studentId );
                userDetails.put( RBSDataSetupConstants.PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails.put( RBSDataSetupConstants.ORG_ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                userDetails.put( RBSDataSetupConstants.TITLE, StudentDetailsForStudentIdAPIConstants.TITLE_MR );
                new RBSUtils().updateUserByUserService( userDetails );

                // Getting response
                response = getStudentDetailsByStudentId( studentId, teacherId, orgId, CommonAPIConstants.INVALID_ACCESS_TOKEN );

                break;

            case "STUDENTID_null":
                accessToken = new RBSUtils().getAccessToken( username, password );
                // Getting response
                response = getStudentDetailsByStudentId( " ", teacherId, orgId, accessToken );
                break;

            case "INVALID_STUDENT_ID":

                accessToken = new RBSUtils().getAccessToken( username, password );
                // Getting response
                response = getStudentDetailsByStudentId( "576787987966764", teacherId, orgId, accessToken );
                break;

            case "STUDENT_DELETED":

                // Studnet Creation
                studentName = "student" + System.nanoTime();
                studentDetails = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

                // Enrolling student into the class
                accessToken = new RBSUtils().getAccessToken( username, password );
                classId = new GroupAPI().createGroupWithCustomization( className, teacherId, Arrays.asList( studentId ), orgId, accessToken );

                // Update the student
                userDetails = new HashMap<String, String>();
                userDetails.put( RBSDataSetupConstants.USERNAME, studentName );
                userDetails.put( RBSDataSetupConstants.USERID, studentId );
                userDetails.put( RBSDataSetupConstants.PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
                userDetails.put( RBSDataSetupConstants.ORG_ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                userDetails.put( RBSDataSetupConstants.TITLE, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.TITLE_VALUES ) );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.GRADE_LEVEL, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.GRADE_CODES ) );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.GENDER_STRING, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.GENDER_VALUES ) );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.BIRTHDATE, "2021-12-01" );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY_VALUES ) );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE_VALUES ) );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY_VALUES ) );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.ETHNICITY, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.ETHNICITY_VALUES ) );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.IS_MIGRANT, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.IS_MIGRANT_VALUES ) );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES_VALUES ) );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.SIS_SOURCEID, "stu_" + System.nanoTime() );

                new RBSUtils().updateUserByUserService( userDetails );
                new RBSUtils().updateUserByUserServiceForDemoGraphics( userDetails );

                // Deleting Student
                new RBSUtils().deleteUser( Arrays.asList( studentId ) );

                // Getting response
                response = getStudentDetailsByStudentId( studentId, teacherId, orgId, accessToken );
                break;
        }

        //Validating response code and exception Message
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( expCode ), "The Status code matched", "The Status code Doesnot matched" );
        Log.assertThat( new SMAPIProcessor().getKeyValues( new JSONObject( response.get( Constants.BODY ) ), StudentDetailsForGivenTeacherConstants.EXCEPTION ).get( 0 ).equals( expException ), "The Exception message is matched",
                "The Exception message is not matched" );

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "positiveScenarios" )
    public Object[][] postiveData() {

        Object[][] inputData = { { "SMK-16931 - Verify the 200 response code for student profile API.", "VALID_SCENARIO", "200" }, { "SMK-16947- Verify the response when the student removed from the Class", "STUDENT_REMOVED_FROM_CLASS", "200" },
                { "SMK-16953- Verify the student profile when the student is mapped with class which having multiple teachers.", "CLASS_HAVING_MULTIPLE_TEACHER", "200" },
                { "SMK-16951- Verify the student profile when the student is part of multiple school.", "STUDENT_MULTI_ORG", "200" },
                { "SMK-16944 - Verify the demographics specialServices,hasEconomicDisadvantage,hasDisability,hasEnglishProficiency, isMigrant,ethnicity values are retuning not specified when the student don't have demographics for student details API.",
                        "DEMOGRAPHIC_NOT_SPECIFIED", "200" },
                { "SMK-16955 - Verify the student profile when the student is suspended from A&E.", "STUDENT_SUSPENDED", "200" } };
        return inputData;
    }

    @Test ( priority = 2, description = "Valid 200 Scenarios", dataProvider = "positiveScenarios", groups = { "smoke_test_case", "Smoke TC001_StudentDetailsForStudentID", "StudentDetailsForStudentId", "P1", "SMK-52005", "Students",
            "StudentDetailsForStudentId", "API" } )
    public void tcStudentDetailsByStudentId_02( String description, String scenario, String expCode ) throws Exception {
        Log.testCaseInfo( description );

        // Constants
        //HashMap<String, String> response = null;
        //String studentName;
        //String studentDetails;
        //String studentId;
        HashMap<String, String> userDetails;
        //String accessToken;
        //String classId;

        switch ( scenario ) {
            case "VALID_SCENARIO":

                Log.testCaseInfo( "SMK-16958 - Verify the student profile when the user is Basic user." );
                Log.testCaseInfo( "SMK-16949 - Verify the response retuning properly for active students." );
                Log.testCaseInfo( "SMK-16948 - Verify the response when the student is added into the class" );
                Log.testCaseInfo( "SMK-16945 - Verify the birthdate retuning in milliseconds format for student details API." );
                Log.testCaseInfo( "SMK-16943- Verify the demographics specialServices,hasEconomicDisadvantage,hasDisability,hasEnglishProficiency, isMigrant,ethnicity values are retuning properly for student details API." );
                Log.testCaseInfo( "SMK-16940 - Verify the person Id returning correctly for the valid student.(Id should be Rumba id =String)" );
                Log.testCaseInfo( "SMK-16934- Verify the api for the Student is created (studentIdentificationNumber) is not given" );
                Log.testCaseInfo( "SMK-16935- Verify the api for the Student is created (studentIdentificationNumber) is given" );
                // Studnet Creation
                String studentName = "student" + System.nanoTime();
                String studentDetails = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                String studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

                // Enrolling student into the class
                String accessToken = new RBSUtils().getAccessToken( username, password );
                String classId = new GroupAPI().createGroupWithCustomization( className, teacherId, Arrays.asList( studentId ), orgId, accessToken );

                // Update the student
                updateStudent( studentName, studentId );

                // Getting response
                HashMap<String, String> response = getStudentDetailsByStudentId( studentId, teacherId, orgId, accessToken );
                // Verifying all Details
                VerifyValidAPI( response );
                break;

            case "STUDENT_SUSPENDED":
                // Studnet Creation
                String studentName1 = "student" + System.nanoTime();
                String studentDetails1 = new UserAPI().createUserWithCustomization( studentName1, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                String studentId1 = new SMUtils().getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERID );

                // Enrolling student into the class
                String accessToken1 = new RBSUtils().getAccessToken( username, password );
                String classId1 = new GroupAPI().createGroupWithCustomization( className, teacherId, Arrays.asList( studentId1 ), orgId, accessToken1 );

                // Update the student
                updateStudent( studentName1, studentId1 );

                // Suspend Student
                new RBSUtils().suspendUser( Arrays.asList( studentId1 ) );

                // Getting response
                HashMap<String, String> response1 = getStudentDetailsByStudentId( studentId1, teacherId, orgId, accessToken1 );
                // Verifying all Details
                VerifyValidAPI( response1 );
                break;

            case "STUDENT_MULTI_ORG":

                // Studnet Creation
                String studentName2 = "student" + System.nanoTime();
                String studentDetails2 = new UserAPI().createUserWithCustomization( studentName2, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId, readingSchoolId ) );
                String studentId2 = new SMUtils().getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERID );

                // Enrolling student into the class
                String accessToken2 = new RBSUtils().getAccessToken( username, password );
                String classId2 = new GroupAPI().createGroupWithCustomization( className, teacherId, Arrays.asList( studentId2 ), orgId, accessToken2 );

                // Update the student
                updateStudent( studentName2, studentId2 );

                // Getting response
                HashMap<String, String> response2 = getStudentDetailsByStudentId( studentId2, teacherId, orgId, accessToken2 );
                // Verifying all Details
                VerifyValidAPI( response2 );
                break;

            case "DEMOGRAPHIC_NOT_SPECIFIED":
                Log.testCaseInfo( "SMK-16952- Verify the student profile when the student is having the grade as Not specified." );

                // Studnet Creation
                String studentName3 = "student" + System.nanoTime();
                String studentDetails3 = new UserAPI().createUserWithCustomization( studentName3, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                String studentId3 = new SMUtils().getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERID );

                // Enrolling student into the class
                String accessToken3 = new RBSUtils().getAccessToken( username, password );
                String classId3 = new GroupAPI().createGroupWithCustomization( className, teacherId, Arrays.asList( studentId3 ), orgId, accessToken3 );

                // Update the student
                userDetails = new HashMap<String, String>();
                updateStudentOnlyBasicDetails( studentName3, studentId3 );
                userDetails.put( RBSDataSetupConstants.USERID, studentId3 );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.GRADE_LEVEL, "OTHER" );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.GENDER_STRING, "UNSPECIFIED" );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.BIRTHDATE, "2021-12-01" );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.ETHNICITY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.IS_MIGRANT, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                userDetails.put( StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
                new RBSUtils().updateUserByUserServiceForDemoGraphics( userDetails );

                // Getting response
                HashMap<String, String> response3 = getStudentDetailsByStudentId( studentId3, teacherId, orgId, accessToken3 );
                // Verifying all Details
                VerifyValidAPI( response3 );
                break;

            case "STUDENT_REMOVED_FROM_CLASS":
                // Studnet Creation
                String studentName4 = "student" + System.nanoTime();
                String studentDetails4 = new UserAPI().createUserWithCustomization( studentName4, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                String studentId4 = new SMUtils().getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERID );
                // Enrolling student into the class
                String accessToken4 = new RBSUtils().getAccessToken( username, password );
                String classId4 = new GroupAPI().createGroupWithCustomization( className, teacherId, Arrays.asList( studentId4 ), orgId, accessToken4 );

                // Update the student
                updateStudent( studentName4, studentId4 );

                // Student is removed from the class
                new RBSUtils().deleteStudentFromSection( classId4, teacherId, studentId4 );

                // Getting response
                HashMap<String, String> response4 = getStudentDetailsByStudentId( studentId4, teacherId, orgId, accessToken4 );
                // Verifying all Details
                VerifyValidAPI( response4 );
                break;

            case "CLASS_HAVING_MULTIPLE_TEACHER":

                // Studnet Creation
                String studentName5 = "student" + System.nanoTime();
                String studentDetails5 = new UserAPI().createUserWithCustomization( studentName5, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                String studentId5 = new SMUtils().getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERID );

                // Enrolling student into the class
                String accessToken5 = new RBSUtils().getAccessToken( username, password );
                String className1 = "class with multiple Teacher" + System.nanoTime();
                String classId5 = new RBSUtils().createClassWithMultipleTeacher( className1, Arrays.asList( teacherId, secondTeacherId ), Arrays.asList( studentId5 ), orgId, accessToken5 );

                // Update the student
                updateStudent( studentName5, studentId5 );

                // Getting response
                HashMap<String, String> response5 = getStudentDetailsByStudentId( studentId5, teacherId, orgId, accessToken5 );
                // Verifying all Details
                VerifyValidAPI( response5 );
                break;
        }

    }

    @Test ( priority = 2, description = "Verifying with all the Grades", groups = { "smoke_test_case", "Smoke TC002_StudentDetailsForStudentID", "StudentDetailsForStudentId", "P1", "SMK-52005", "Students", "StudentDetailsForStudentId", "API" } )
    public void tcStudentDetailsByStudentId_03() throws Exception {

        Log.testCaseInfo( "SMK-16942- Verify the grade value returning from K to 12 for student details API." );

        String accessToken;

        // Studnet Creation
        String studentName = "student" + System.nanoTime();
        String studentDetails = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
        String studentId = new SMUtils().getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

        // Enrolling student into the class
        String accessToken6 = new RBSUtils().getAccessToken( username, password );
        String className = "class" + System.nanoTime();
        classId = new RBSUtils().createClassWithMultipleTeacher( className, Arrays.asList( teacherId ), Arrays.asList( studentId ), orgId, accessToken6 );

        StudentDetailsForStudentIdAPIConstants.GRADE_CODES.forEach( grade -> {
            Log.message( "Verifying with the Grade value " + grade );

            HashMap<String, String> userDetails = new HashMap<String, String>();
            updateStudentOnlyBasicDetails( studentName, studentId );

            // Giving each Grade
            userDetails.put( StudentDetailsForStudentIdAPIConstants.GRADE_LEVEL, grade );

            // other details
            userDetails.put( RBSDataSetupConstants.USERID, studentId );
            userDetails.put( StudentDetailsForStudentIdAPIConstants.GENDER_STRING, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.GENDER_VALUES ) );
            userDetails.put( StudentDetailsForStudentIdAPIConstants.BIRTHDATE, "2021-12-01" );
            userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY_VALUES ) );
            userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE_VALUES ) );
            userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY_VALUES ) );
            userDetails.put( StudentDetailsForStudentIdAPIConstants.ETHNICITY, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.ETHNICITY_VALUES ) );
            userDetails.put( StudentDetailsForStudentIdAPIConstants.IS_MIGRANT, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.IS_MIGRANT_VALUES ) );
            userDetails.put( StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES_VALUES ) );
            userDetails.put( StudentDetailsForStudentIdAPIConstants.SIS_SOURCEID, "stu_" + System.nanoTime() );

            new RBSUtils().updateUserByUserServiceForDemoGraphics( userDetails );

            // Getting response
            HashMap<String, String> response = getStudentDetailsByStudentId( studentId, teacherId, orgId, accessToken6 );
            VerifyValidAPI( response );
        } );

    }

    // Verifying response code, Schema, All the demographic values
    public void VerifyValidAPI( HashMap<String, String> response ) {

        String apiResonseBody = response.get( Constants.REPORT_BODY );
        JSONObject data = new JSONObject( apiResonseBody );

        String userId = new SMAPIProcessor().getKeyValues( data, Constants.PERSONID ).get( 0 );
        JSONObject userdetailsData = new JSONObject( new RBSUtils().getUserWithUserService( userId ) );

        // Status code Matched
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_OK ), "The Status code matched", "The Status code Doesnot matched" );

        // User Details
        Log.assertThat( new SMUtils().compareTwoHashMap( getExpectedValues( userId ), getActualValuesFromAPI( response ) ), "The User Details is matched ", "The User Details is not matched" );

        // Grade Values
        String expGrade;
        String actGrade = new SMAPIProcessor().getKeyValues( data, StudentDetailsForStudentIdAPIConstants.GRADE ).get( 0 );
        String gradeName = null;

        try {
            expGrade = new SMAPIProcessor().getKeyValues( userdetailsData, StudentDetailsForStudentIdAPIConstants.GRADE_LEVEL ).get( 0 );
        } catch ( Exception e ) {
            expGrade = null;
        }
        if ( expGrade != null ) {
            int indexOfGrade = StudentDetailsForStudentIdAPIConstants.GRADE_CODES.indexOf( expGrade );
            Log.assertThat( StudentDetailsForStudentIdAPIConstants.GRADE_NAME.get( indexOfGrade ).equals( actGrade ), "The Grade value is matching", "The grade value is not matching" );
        } else {
            Log.assertThat( actGrade.equals( StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED ), "The Grade value is NOT_SPECIFIED", "The grade value is not NOT_SPECIFIED" );
        }

        // Verifying other demographic values
        String details = new SMAPIProcessor().getKeyValues( userdetailsData, StudentDetailsForStudentIdAPIConstants.DEMOGRAPHICS ).get( 0 );
        if ( details.equals( "{}" ) ) {
            Log.message( "Demographic value is not specified" );
            VerifyDemoGraphicsValueForNotSpecified( data );
        } else {
            VerifyDemoGraphicsValue( userdetailsData, data );
        }

        // Student Identificaiton number verificaiton
        VerifyStudentIdField( userdetailsData, data );

        // Gender Verification
        VerifyGender( userdetailsData, data );

        // Verifying the organization Id
        VerifyOrganizationDetails( response );
    }

    // Get the actual values from the API response
    public HashMap<String, String> getActualValuesFromAPI( HashMap<String, String> response ) {

        HashMap<String, String> actualValues = new HashMap<String, String>();
        JSONObject data = new JSONObject( response.get( Constants.REPORT_BODY ) );

        actualValues.put( StudentDetailsForStudentIdAPIConstants.FIRST_NAME, new SMAPIProcessor().getKeyValues( data, StudentDetailsForStudentIdAPIConstants.FIRST_NAME ).get( 0 ) );
        actualValues.put( StudentDetailsForStudentIdAPIConstants.LAST_NAME, new SMAPIProcessor().getKeyValues( data, StudentDetailsForStudentIdAPIConstants.LAST_NAME ).get( 0 ) );
        actualValues.put( StudentDetailsForStudentIdAPIConstants.MIDDLE_NAME, new SMAPIProcessor().getKeyValues( data, StudentDetailsForStudentIdAPIConstants.MIDDLE_NAME ).get( 0 ) );
        actualValues.put( StudentDetailsForStudentIdAPIConstants.USERNAME, new SMAPIProcessor().getKeyValues( data, StudentDetailsForStudentIdAPIConstants.USERNAME ).get( 0 ) );
        //actualValues.put( StudentDetailsForStudentIdAPIConstants.BIRTH_DAY, new SMUtils().convertMillisecondstoDate( Long.parseLong( new SMAPIProcessor().getKeyValues( data, StudentDetailsForStudentIdAPIConstants.BIRTH_DAY ).get( 0 ) ) ) );

        return actualValues;
    }

    // Get the expected values from the user service api
    public HashMap<String, String> getExpectedValues( String userId ) {

        String userdetails = new RBSUtils().getUserWithUserService( userId );
        HashMap<String, String> expValues = new HashMap<String, String>();

        JSONObject data = new JSONObject( userdetails );

        expValues.put( StudentDetailsForStudentIdAPIConstants.FIRST_NAME, new SMAPIProcessor().getKeyValues( data, StudentDetailsForStudentIdAPIConstants.FIRST_NAME ).get( 0 ) );
        expValues.put( StudentDetailsForStudentIdAPIConstants.LAST_NAME, new SMAPIProcessor().getKeyValues( data, StudentDetailsForStudentIdAPIConstants.LAST_NAME ).get( 0 ) );
        expValues.put( StudentDetailsForStudentIdAPIConstants.MIDDLE_NAME, new SMAPIProcessor().getKeyValues( data, StudentDetailsForStudentIdAPIConstants.MIDDLE_NAME ).get( 0 ) );
        expValues.put( StudentDetailsForStudentIdAPIConstants.USERNAME, new SMAPIProcessor().getKeyValues( data, StudentDetailsForStudentIdAPIConstants.USERNAME ).get( 0 ) );
        //expValues.put( StudentDetailsForStudentIdAPIConstants.BIRTH_DAY, new SMAPIProcessor().getKeyValues( data, StudentDetailsForStudentIdAPIConstants.BIRTH_DATE ).get( 0 ) );

        return expValues;

    }

    // Verifying the other demogaphic values
    public void VerifyDemoGraphicsValue( JSONObject expected, JSONObject actual ) {

        HashMap<String, String> expValues = new HashMap<String, String>();
        // exp fields
        expValues.put( StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES, new SMAPIProcessor().getKeyValues( expected, StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES ).get( 0 ) );
        expValues.put( StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY, new SMAPIProcessor().getKeyValues( expected, StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY ).get( 0 ) );
        expValues.put( StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE, new SMAPIProcessor().getKeyValues( expected, StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE ).get( 0 ) );
        expValues.put( StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY, new SMAPIProcessor().getKeyValues( expected, StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY ).get( 0 ) );
        expValues.put( StudentDetailsForStudentIdAPIConstants.IS_MIGRANT, new SMAPIProcessor().getKeyValues( expected, StudentDetailsForStudentIdAPIConstants.IS_MIGRANT ).get( 0 ) );
        expValues.put( StudentDetailsForStudentIdAPIConstants.ETHNICITY, new SMAPIProcessor().getKeyValues( expected, StudentDetailsForStudentIdAPIConstants.ETHNICITY ).get( 0 ) );

        HashMap<String, String> actValues = new HashMap<String, String>();

        actValues.put( StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES ).get( 0 ) );
        actValues.put( StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY ).get( 0 ) );
        actValues.put( StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE ).get( 0 ) );
        actValues.put( StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY ).get( 0 ) );
        actValues.put( StudentDetailsForStudentIdAPIConstants.IS_MIGRANT, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.IS_MIGRANT ).get( 0 ) );
        actValues.put( StudentDetailsForStudentIdAPIConstants.ETHNICITY, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.ETHNICITY ).get( 0 ) );
        Log.assertThat( new SMUtils().compareTwoHashMap( expValues, actValues ), "The Demographic values are matched ", "The Demographic values are not matched" );

    }

    // Verifying the other demogaphic values
    public void VerifyDemoGraphicsValueForNotSpecified( JSONObject actual ) {

        HashMap<String, String> expValues = new HashMap<String, String>();
        // exp fields
        expValues.put( StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        expValues.put( StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        expValues.put( StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        expValues.put( StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        expValues.put( StudentDetailsForStudentIdAPIConstants.IS_MIGRANT, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );
        expValues.put( StudentDetailsForStudentIdAPIConstants.ETHNICITY, StudentDetailsForStudentIdAPIConstants.NOT_SPECIFIED );

        HashMap<String, String> actValues = new HashMap<String, String>();

        actValues.put( StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES ).get( 0 ) );
        actValues.put( StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY ).get( 0 ) );
        actValues.put( StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE ).get( 0 ) );
        actValues.put( StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY ).get( 0 ) );
        actValues.put( StudentDetailsForStudentIdAPIConstants.IS_MIGRANT, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.IS_MIGRANT ).get( 0 ) );
        actValues.put( StudentDetailsForStudentIdAPIConstants.ETHNICITY, new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.ETHNICITY ).get( 0 ) );

        Log.assertThat( new SMUtils().compareTwoHashMap( expValues, actValues ), "The Demographic values are matched ", "The Demographic values are not matched" );

    }

    /**
     * It will verify the studentIdentificationNumber
     * 
     * @param expected
     * @param actual
     */
    public void VerifyStudentIdField( JSONObject expected, JSONObject actual ) {
        try {
            String studentId = new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.STUDENT_IDENTIFICATION_NO ).get( 0 );
            Log.assertThat( studentId.equals( new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.SIS_SOURCE_ID ).get( 0 ) ), "The student Id is valid", "The student Id is not valid" );
        } catch ( Exception e ) {

        }
    }

    /**
     * It will verify the Gender field
     * 
     * @param expected
     * @param actual
     */
    public void VerifyGender( JSONObject expected, JSONObject actual ) {
        String actGender = new SMAPIProcessor().getKeyValues( actual, StudentDetailsForStudentIdAPIConstants.GENDER ).get( 0 );
        String expGender = new SMAPIProcessor().getKeyValues( expected, StudentDetailsForStudentIdAPIConstants.GENDER ).get( 0 );
        Log.assertThat( expGender.equals( StudentDetailsForStudentIdAPIConstants.GENDER_VALUES.get( StudentDetailsForStudentIdAPIConstants.GENDER_VALUES_API.indexOf( actGender ) ) ), "The Gender is valid", "The Gender value is not valid" );
    }

    /***
     * It will verify the Organization Id of the user
     * 
     * @param response
     */
    public void VerifyOrganizationDetails( HashMap<String, String> response ) {

        JSONObject userJsonObject = new JSONObject(
                new RBSUtils().getUser( new SMAPIProcessor().getKeyValues( new JSONObject( response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) ), StudentDetailsForStudentIdAPIConstants.PERSON_ID ).get( 0 ) ) );
        String innerJSON = new SMAPIProcessor().getKeyValues( userJsonObject, GetUserDetailsUsingUserServiceAPIConstants.AFFILIATION ).get( 0 );
        JSONObject affliation = new JSONObject( "{ \"data\":" + innerJSON + "}" );
        ArrayList<String> expOrgIds = new ArrayList<String>( new SMAPIProcessor().getKeyValues( affliation, GetUserDetailsUsingUserServiceAPIConstants.ORGANIZATIONID_FIELD ) );

        String orgIdValue = SMUtils.getKeyValueFromResponse( response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ), GetUserDetailsUsingUserServiceAPIConstants.ORGANIZATIONID_DATAVALUE );
        orgIdValue = orgIdValue.substring( 1, orgIdValue.length() - 1 );

        List<String> actOrgIds = new ArrayList<>();
        List<String> jsonArray = Arrays.asList( orgIdValue.split( "," ) );
        Log.message( jsonArray.toString() );

        jsonArray.forEach( orgId -> {
            Log.message( orgId );
            actOrgIds.add( orgId.substring( 1, orgId.length() - 1 ) );
        } );

        Log.assertThat( SMUtils.compareTwoList( expOrgIds, actOrgIds ), "The organizaiton Id fiels is matching", "The organizaion field is not matching" + "Actual " + actOrgIds.toString() + "Expected" + expOrgIds.toString() );

    }

    /**
     * It will update both Demo and basic details
     * 
     * @param studentName
     * @param studentId
     */
    public void updateStudent( String studentName, String studentId ) {
        updateStudentOnlyBasicDetails( studentName, studentId );
        updateDemoGraphics( studentId );
    }

    /**
     * It will update only basic details for student
     * 
     * @param studentName
     * @param studentId
     */
    public void updateStudentOnlyBasicDetails( String studentName, String studentId ) {
        HashMap<String, String> userDetails;
        // Update the student
        userDetails = new HashMap<String, String>();
        userDetails.put( RBSDataSetupConstants.USERNAME, studentName );
        userDetails.put( RBSDataSetupConstants.USERID, studentId );
        userDetails.put( RBSDataSetupConstants.PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        userDetails.put( RBSDataSetupConstants.ORG_ROLE, RBSDataSetupConstants.STUDENT_ROLE );
        userDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
        userDetails.put( RBSDataSetupConstants.TITLE, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.TITLE_VALUES ) );
        new RBSUtils().updateUserByUserService( userDetails );
    }

    /**
     * It will update the demographics for student
     * 
     * @param studentId
     */
    public void updateDemoGraphics( String studentId ) {
        HashMap<String, String> userDetails;
        userDetails = new HashMap<String, String>();
        userDetails.put( RBSDataSetupConstants.USERID, studentId );
        userDetails.put( StudentDetailsForStudentIdAPIConstants.GRADE_LEVEL, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.GRADE_CODES ) );
        userDetails.put( StudentDetailsForStudentIdAPIConstants.GENDER_STRING, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.GENDER_VALUES ) );
        userDetails.put( StudentDetailsForStudentIdAPIConstants.BIRTHDATE, "2021-12-01" );
        userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.HAS_DISABILITY_VALUES ) );
        userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.HAS_ECONOMIC_DISADVANTAGE_VALUES ) );
        userDetails.put( StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.HAS_ENGLISH_PROFICIENCY_VALUES ) );
        userDetails.put( StudentDetailsForStudentIdAPIConstants.ETHNICITY, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.ETHNICITY_VALUES ) );
        userDetails.put( StudentDetailsForStudentIdAPIConstants.IS_MIGRANT, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.IS_MIGRANT_VALUES ) );
        userDetails.put( StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES, new SMUtils().getRandomVariableFromArrayList( StudentDetailsForStudentIdAPIConstants.SPECIDAL_SERVICES_VALUES ) );
        userDetails.put( StudentDetailsForStudentIdAPIConstants.SIS_SOURCEID, "stu_" + System.nanoTime() );
        new RBSUtils().updateUserByUserServiceForDemoGraphics( userDetails );
    }

    /**
     * It will verify the schema
     * 
     * @param StatusCode
     * @param response
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = new SMAPIProcessor().isSchemaValid( FileNameConstatnts.STUDENT_DETAILS_FOR_STUDENTID, StatusCode, response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
    }

}
