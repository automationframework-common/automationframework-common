package com.savvas.sm.common.utils.apiconstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public interface ReportsAPIConstants {
    String Report_BFF_Graphql_NIGHTLY = "https://successmaker-report-bff-service-nightly.smdemo.info/graphql";

    String UNAUTHORIZED_MESSAGE = "UNAUTHORIZED";
    String UNAUTHORIZED_401 = "401: Unauthorized";
    String FORBIDDEN_403 = "403: Forbidden";
    String NOT_FOUND_404 = "404: Not Found";
    String BAD_REQUEST_400 = "400: Bad Request";
    String INTERNAL_SERVERZ_ERROR_500 = "500: Internal Server Error";
    String FAILED = "failed";
    String INVALID_MESSAGE_FOR_USERID = "Invalid value passed for userId";
    String INVALID_MESSAGE_FOR_ORGID = "Invalid value passed for organizationId";
    String INVALID_AUTHENTICATION_MESSAGE = "Access denied! You don't have permission for this action!";
    String NOT_AUTHENTICATED_MESSAGE = "Not authenticated";
    String ZERO_STATE_MESSAGE ="Report details not found";

    //Demographics
    String GENDER = "GENDER";
    String DISABILITY_STATUS = "DISABILITY_STATUS";
    String MIGRANT_STATUS = "MIGRANT_STATUS";
    String SOCIOECONOMIC_STATUS = "SOCIOECONOMIC_STATUS";
    String RACE = "RACE";
    String ETHNICITY = "ETHNICITY";
    String SPECIAL_SERVICES = "SPECIAL_SERVICES";
    String ENGLISH_LANGUAGE = "ENGLISH_LANGUAGE";

    String TNS_USESRNAME = "tns:UserName";
    String TNS_FIRSTNAME = "tns:FirstName";
    String TNS_LASTNAME = "tns:LastName";
    String TNS_MIDDLENAME = "tns:MiddleName";

    String COURSE_LIST_ZERO_STATE_MESSAGE = "Course List not found";
    String CLASSNAME = "className";

    //BFF payload
    String REPORT_BFF = "https://successmaker-report-bff-service-nightly.smdemo.info";
    String GRAPHQL_ENDPOINT = "/graphql";

    String FIRTNAME_LASTNAME = "firstAndLastName";

    //Student Performance Report Constants
    public interface SPReportConstants {

        public static String DISTRICT_ID_VALUE = "{districtId}";
        public static String DISTRICT_ID = "districtId";
        public static String STUDENT_ID_VALUE = "{studentId}";
        public static String STUDENT_ID = "studentId";
        List<String> EXPECTED_RESPONSE_PARAMS = new ArrayList<>( Arrays.asList( "studentId", "studenName", "courses" ) );
        public static String STUDENT_NAME = "studenName";
        public static String COURSES = "courses";
        public static String SUBJECT = "subject";
        public static String LANGUAGE_VALUE = "{language}";
        public static String SUBJECT_VALUE = "{subject}";
        public static String ENGLISH = "en";
        public static String COURSE_VALUES = "[\\\"1234\\\", \\\"5678\\\"]";
        String GET_SPREPORTS_OUTPUT_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getSPReportData(\\n    spReportRequest: {\\n      studentId: \\\"{studentId}\\\"\\n      language: \\\"{language}\\\"\\n      subject: \\\"{subject}\\\"\\n      courseList: [\\\"1234\\\", \\\"5678\\\"]\\n      includePerformanceSummary: true\\n      includePerformanceByStrand: true\\n      includeAreasOfDifficulty: true\\n      includeRecentHistoryData: true\\n      filterBySchool: []\\n      filterByTeacher: []\\n      filterByGrade: []\\n      filterByGroup: []\\n    }\\n  ) {\\n    studentId\\n    studenName\\n    courses {\\n      course {\\n        name\\n        school\\n        teacher\\n        grade\\n        group\\n        assignedCourseLevel\\n        currentCourseLevel\\n        ipLevel\\n        gain\\n        exerCorrect\\n        exerAttempted\\n        cri\\n        skillsMastered\\n        skillsAssessed\\n        helpUsed\\n        audioRepeatsUsed\\n        reportCardViews\\n        glossaryUsed\\n        timeSpent\\n        totalSessions\\n        averageSessionTime\\n        computationStrands {\\n          name\\n          level\\n          skillsMastered\\n          skillsAssessed\\n        }\\n        applicationStrands {\\n          name\\n          level\\n          skillsMastered\\n          skillsAssessed\\n        }\\n        skillsDelayed {\\n          strand\\n          level\\n          description\\n        }\\n        skillsNotMastered {\\n          strand\\n          level\\n          description\\n        }\\n      }\\n    }\\n  }\\n}\\n\"}";
        public static String MATH = "math";
        public static String GET_SP_REPORT_OUTPUT_SCHEMA = "spReportMockOutput_Schema";
    }
    
    //Groups and Student Details Constants
    public interface getGroupAndStudentDetailsConstants{
    	 // constant variables for headers
        String ORGANIZATION_ID = "org-id";
        String USER_ID = "user-id";
        
        //QueryItems Constants for constructing Queries
        String DATA = "data";
        String STUDENT_DATA = "studentData";
        String SYSTEM = "system";
        String DISTRICTS ="districts";
        String METADATA = "metadata";
        
        String SECTION = "section";
        String ID ="id";
        String SECTION_INFO = "sectionInfo";
        String SECTION_NAME = "sectionName";
        String ORGANIZATIONID = "organizationId";
        String ROSTERSOURCE ="rosterSource";
        String AUTOROSTERED = "autoRostered";
        String STUDENTS = "students";
        String STAFF = "staff";
        
        String STUDENTPIID = "studentPiId";
        String STUDENTENROLLMENTID= "studentEnrollmentId";
        
        String STAFFPIID="staffPiId";
        String STAFFASSIGNMENTID = "staffAssignmentId";
        String TEACHEROFRECORD="teacherOfRecord";
        String TEACHERASSIGNMENT ="teacherAssignment";
        
        
        String SECTIONPRODUCTSASSOCIATIONLIST= "SectionProductsAssociationList";
        String PRODUCTID = "productId";
        String PLATFORMS = "platforms";
        
        String SESSIONINFO = "SessionInfo";
        String BEGINDATE = "beginDate";
        String ENDDATE = "endDate";
        
        String LIFECYCLE = "lifecycle";
        String DELETED = "deleted";
        String CREATEDATE = "createDate";
        String MODIFIEDDATE = "modifiedDate";
        String CREATEDBY = "createdBy";
        String UPDATEDBY = "updatedBy";
        
        String ATTRIBUTEKEY = "attributeKey";
        String ATTRIBUTEVALUE = "attributeValue";
        String LMSNAME = "lmsName";
        
        String PERSONID = "personId";
        String USERID = "userId";
        String FIRSTNAME = "firstName";
        String LASTNAME = "lastName";
        String MIDDLENAME ="middleName";
        String DISPLAYNAME = "displayName";
        String GENDER = "gender";
        String CREATEDDATE = "createdDate";
        String LASTUPDATEDDATE = "lastUpdatedDate";
        String LASTUPDATEDBY = "lastUpdatedBy";
        String CREATED_BY = "createdBy";
        String USERNAME = "userName";
        String ENCRYPTIONTYPE = "encryptionType";
        String AUTHENTICATIONTYPE = "authenticationType";
        String TITLE = "title";
        String BIRTHDATE = "birthDate";
        String LANGUAGE = "language";
        String USERSTATUS = "userStatus";
        String RESETFLAG = "resetFlag";
        String PASSWARDEXPIRYDATE = "passwordExpiryDate";
        String PREFFEREDTIMEZONE = "preferredTimeZone";
        String BUSSINESSRULESET = "businessRuleSet";
        String AUTOGENERATED = "autoGenerated";
        String USERMETADATA = "userMetaData";
        String GRADES = "grades";
        String GRADELEVEL = "gradeLevel";
        String PLATFORM = "platform";
        
        String DEMOGRAPHICS ="demographics";
        String SPECIALSERVICES = "specialServices";
        String ECONOMICDISADVANTAGE = "economicDisadvantage";
        String HASDISABILTIY = "hasDisability";
        String ENGLISHPROFIENCY = "englishProficiency";
        String MIGRANT = "migrant";
        String ETHNICITY = "ethnicity"; 
        String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getGroupAndStudentDetails(\\n    userId: \\\"%s\\\"  ) %s\\n}\\n\"}";
    }
    
    public interface adminLSRConstants{
        String REQ_PAYLOAD = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getLSAdminReportData(\\n    filterParams: {filterByGroup: [{groupId}], filterByGrade: [{grade}], filterByTeacher: [{teacherId}], filterBySchool: [\\\"%s\\\"], additionalGrouping: 0, courseList: [{assignmentId}], subject: \\\"%s\\\", filterByDemographics: {disabilityStatus: [{disabilityStatus}], englishLanguageProficiency: [{language}], gender: [{gender}], migrantStatus: [{migrantStatus}], race: [{race}], ethnicity: [{ethnicity}], socioeconomicStatus: [{socioStatus}], specialServices: [{specialServices}]}}\\n    userId: \\\"%s\\\"\\n    organizationId: \\\"%s\\\"\\n  ) {\\n    reportRun\\n    organizationName\\n    grade\\n    assignmentTitle\\n    groupID\\n    groupName\\n    teacherID\\n    teacherTitle\\n   teacherName\\n    studentName\\n    studentUsername\\n    studentID\\n    currentCourseLevel\\n    fluencyFlag\\n    courseType\\n    ipmStatusID\\n    rawPerformance {\\n      exercisesCorrect\\n      exercisesAttempted\\n      exercisesPercentCorrect\\n    }\\n    usage {\\n      sessionStartDate\\n      sessionCompleteDate\\n      sessionLength\\n      helpUsed\\n      timeSpent\\n      totalSessions\\n      sessionDate\\n    }\\n    exercisesCorrectedAttempted {\\n      instructionalCorrect\\n      instructionalAttempted\\n      independentPracticeCorrect\\n      independentPracticeAttempted\\n      remediationCorrect\\n      remediationAttempted\\n    }\\n  }\\n}\\n\"}";
        public static String SCHOOL_ID_VALUE = "{schoolId}";
        public static String USER_ID_VALUE = "{userId}";
        public static String DISTRICT_ID_VALUE = "{districtId}";
        public static String TEACHER_ID_VALUE = "{teacherId}";
        public static String GROUP_ID_VALUE = "{groupId}";
        public static String GRADE_ID_VALUE = "{grade}";
        public static String ASSIGNMENT_ID = "{assignmentId}";
        public static String DISABILITY_STATUS = "{disabilityStatus}";
        public static String ENGLISH_PROFICIENCY = "{language}";
        public static String GENDER = "{gender}";
        public static String MIGRANT_STATUS = "{migrantStatus}";
        public static String RACE = "{race}";
        public static String Ethnicity = "{ethnicity}";
        public static String SOCIO_STATUS = "{socioStatus}";
        public static String SPECIAL_SERVICES = "{specialServices}";
    }
    
}
