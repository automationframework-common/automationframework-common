package com.savvas.sm.admin.api.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.stream.IntStream;

import org.aspectj.weaver.tools.Trace;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.Dashboard;
import com.savvas.sm.utils.sme187.admin.api.restoreassignment.RestoreAssignment;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class PostPerformanceReportTest extends EnvProperties {

    private static List<String> studentRumbaIds = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String teacherUsername;
    private String flexSchool;
    private String student1Details;
    private String student2Details;
    private String student3Details;
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();

    private List<String> courseIDs = new ArrayList<>();
    private String groupId = null;
    private String exception = null;
    private String message = null;
    private String courseId;

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        Log.message( RBSDataSetup.teacherStudentRelation.toString() );
        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

        teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );

        student1Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        student2Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        student3Details = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student1Details, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student2Details, "userId" ) );
        String token = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

        Log.message( "contentbasename" + contentBaseName );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

        Log.message( "Assigning assignment..." );
        Log.message( assignmentDetails.toString() );
        Log.message( studentRumbaIds.toString() );
        Log.message( courseIDs.toString() );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        Log.message( "Assignment IDs - " + assignmentIds );

        executeCourse( SMUtils.getKeyValueFromResponse( student1Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true, true );
        executeCourse( SMUtils.getKeyValueFromResponse( student2Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true, true );

        executeCourse( SMUtils.getKeyValueFromResponse( student1Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, true );
        executeCourse( SMUtils.getKeyValueFromResponse( student2Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, true );
    }

    /**
     * This method is used to test the Performance report API.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "performanceReportpositiveScenario", groups = { "smoke_test_case", "performanceReport", "SMK-51765", "P1", "API" } )
    public void performanceReportPositiveTest( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        String adminDetails = RBSDataSetup.adminDetails.get( admin );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        String adminOrgId;
        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {
            adminOrgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgIds" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );
        } else {
            adminOrgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        }
        String token = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, adminUserId );
        headers.put( UserConstants.ORGID, adminOrgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        Map<String, List<String>> studentIds = new HashMap<>();
        Map<String, String> postPerformanceReportResponse = new HashMap<>();
        String subjectTypeId = "";

        switch ( scenario ) {
            case "HAPPY_PATH":
                studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student1Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "ZERO_STATE_WITHOUT_ASSIGNMENT":
                studentIds.put( "grade_2", Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "ZERO_STATE_NOT_YET_ATTENDED":
                new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ), courseIDs );
                studentIds.put( "grade_2", Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "ZERO_STATE_NOT_YET_CLEAR_THE_IP":
                executeCourse( SMUtils.getKeyValueFromResponse( student3Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true, false );
                studentIds.put( "grade_2", Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "FOR_MATH_SINGLE_STUDENT":
                studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student1Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "FOR_MATH_MULTIPLE_STUDENT":
                studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student1Details, "userId" ), SMUtils.getKeyValueFromResponse( student2Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "FOR_MATH_MULTIPLE_GRADE_STUDENT":
                executeCourse( SMUtils.getKeyValueFromResponse( student3Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true, true );
                studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student1Details, "userId" ), SMUtils.getKeyValueFromResponse( student2Details, "userId" ) ) );
                studentIds.put( "grade_2", Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "FOR_READING_SINGLE_STUDENT":
                studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student1Details, "userId" ) ) );
                subjectTypeId = "2";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "FOR_READING_MULTIPLE_STUDENT":
                studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student1Details, "userId" ), SMUtils.getKeyValueFromResponse( student2Details, "userId" ) ) );
                subjectTypeId = "2";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "FOR_READING_MULTIPLE_GRADE_STUDENT":
                executeCourse( SMUtils.getKeyValueFromResponse( student3Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, true );
                studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student1Details, "userId" ), SMUtils.getKeyValueFromResponse( student2Details, "userId" ) ) );
                studentIds.put( "grade_2", Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ) );
                subjectTypeId = "2";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "FOR_MATH_CUSTOM_BY_SETTINGS_IPM_ON_COURSE":
                executeCourse( SMUtils.getKeyValueFromResponse( student3Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true, true );
                studentIds.put( "grade_2", Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "FOR_READING_CUSTOM_BY_SETTINGS_IPM_ON_COURSE":
                executeCourse( SMUtils.getKeyValueFromResponse( student3Details, "userName" ), contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false, true );
                studentIds.put( "grade_2", Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ) );
                subjectTypeId = "2";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "FOR_MCL_COURSE_AND_GROUP_ASSIGNMENT":
                token = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
                //Course creation
                String courseName = "Custom Setting Course" + System.nanoTime();
                courseId = new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName );

                //Creating group  for above created teacher & student
                groupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ), orgId, token );

                //Assign assignments
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                assignmentDetails.put( AdminAPIConstants.ASSIGNMENT_COURSE_ID, courseId );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );

                //executing course
                executeCourse( SMUtils.getKeyValueFromResponse( student3Details, "userName" ), courseName, true, true );

                studentIds.put( "grade_2", Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "DELETED_ASSIGNMENT":
                //remove the Assignment for student
                HashMap<String, String> assignmentDetail = new HashMap<>();
                assignmentDetail.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( SMUtils.getKeyValueFromResponse( student2Details, "userId" ), assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetail, "null" );

                studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student2Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "RESTORED_ASSIGNMENT":
                //restoring the Assignment for student
                HashMap<String, String> userDetail = new HashMap<>();
                userDetail.put( Constants.ORGID_SM_HEADER, configProperty.getProperty( "district_ID" ) );
                userDetail.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                userDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, new SqlHelperCourses().getAssignmentUserId( SMUtils.getKeyValueFromResponse( student2Details, "userId" ), assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) ) );

                Log.assertThat( new RestoreAssignment().restoreDeletedAssignment( smUrl, userDetail, CourseAPIConstants.NULL ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment restored sucessfully!", "Issue in restoring the assignment!" );

                studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student2Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "DELETED_GROUP_ASSIGNMENT":
                //delete the group assignment
                HashMap<String, String> assignmentDetailForGroup = new HashMap<>();
                assignmentDetailForGroup.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetailForGroup.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetailForGroup.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetailForGroup.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetailForGroup.put( AssignmentAPIConstants.GROUP_ID, groupId );
                Log.assertThat( new AssignmentAPI().deleteAssignmentfromGroup( smUrl, assignmentDetailForGroup, "null" ).get( Constants.STATUS_CODE ).equals( "200" ), "Assignment deleted fro group", "Issue in deleting the group assignment!" );

                studentIds.put( "grade_2", Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "ORPHAN_STUDENT":
                //delete Student from all groups
                HashMap<String, String> studentDetails = new HashMap<String, String>();
                studentDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
                studentDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( GroupConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( student3Details, "userId" ) );
                HashMap<String, String> groupsForStudentID = new GroupAPI().getGroupsForStudentID( smUrl, studentDetails );
                List<String> groupIds = new ArrayList<>();
                IntStream.rangeClosed( 1, SMUtils.getWordCount( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId" ) ).forEach(
                        iter -> groupIds.add( SMUtils.getKeyValueFromJsonArray( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId", iter ) ) );

                groupIds.stream().forEach( groupId -> {
                    try {
                        new GroupAPI().removeStudentFromGroup( smUrl, SMUtils.getKeyValueFromResponse( student3Details, "userId" ), groupId, teacherId, orgId,
                                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    } catch ( Exception e ) {
                        e.printStackTrace();
                    }
                } );
                studentIds.put( "grade_2", Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "SUSPENDED_STUDENT":
                String newStudentForSuspend = "SchStudent" + System.nanoTime();
                String newStudentForSuspendDetails = new UserAPI().createUserWithCustomization( newStudentForSuspend, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                String newStudentIdForSuspend = SMUtils.getKeyValueFromResponse( newStudentForSuspendDetails, RBSDataSetupConstants.USERID );
                HashMap<String, String> studentInformation = new HashMap<>();
                studentInformation = generateRequestValues( newStudentForSuspendDetails, studentInformation, UserConstants.SCHOOLID, orgId );
                studentInformation = SMUtils.updateRequestBodyValues( studentInformation, UserConstants.SCHOOLID, orgId );
                studentInformation = SMUtils.updateRequestBodyValues( studentInformation, UserConstants.TEACHER_ID, teacherId );
                studentInformation = SMUtils.updateRequestBodyValues( studentInformation, RBSDataSetupConstants.BEARER_TOKEN,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );

                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInformation );
                new RBSUtils().resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, newStudentIdForSuspend );

                //Creating group  for above created teacher & student
                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( newStudentIdForSuspend ), orgId,
                        new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newStudentIdForSuspend ), AssignmentAPIConstants.USERS_TYPE );

                executeCourse( newStudentForSuspend, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, true );

                //suspend Student
                new RBSUtils().suspendUser( Arrays.asList( newStudentIdForSuspend ) );
                studentIds.put( "grade_2", Arrays.asList( newStudentIdForSuspend ) );
                subjectTypeId = "2";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "MUTIPLE_SCHOOL_STUDENT":
                studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student1Details, "userId" ), SMUtils.getKeyValueFromResponse( student2Details, "userId" ) ) );
                studentIds.put( "grade_2", Arrays.asList( SMUtils.getKeyValueFromResponse( student3Details, "userId" ) ) );
                subjectTypeId = "2";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            case "UPDATED_STUDENT_GRADE":
                // update student info
                HashMap<String, String> studentInfos = new HashMap<>();
                studentInfos = generateRequestValues( student1Details, studentInfos, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );

                Log.message( "Updating grade..." );
                HashMap<String, String> updateStudentProfile = new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfos );
                Log.message( updateStudentProfile.toString() );
                studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student1Details, "userId" ) ) );
                subjectTypeId = "1";
                postPerformanceReportResponse = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }
        Log.message( postPerformanceReportResponse.toString() );

        //Status code validation
        Log.assertThat( postPerformanceReportResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                "Issue in returning status code! Expected - " + statusCode + " Actual - " + postPerformanceReportResponse.get( Constants.STATUS_CODE ) );

        if ( !scenario.contains( "ZERO_STATE" ) && !scenario.contains( "DELETED_ASSIGNMENT" ) ) {
            //data Validation
            Map<String, Map<String, String>> performanceReportDataFromResponse = getPeformanceReportDetailsFromResponse( postPerformanceReportResponse );
            Map<String, Map<String, String>> performanceReportDataFromDB = getPeformanceReportDetailsFromDB( studentIds, subjectTypeId );
            Log.assertThat( performanceReportDataFromDB.entrySet().stream().allMatch( entry -> {
                return entry.getValue().get( "ipLevel" ).equals( performanceReportDataFromResponse.get( entry.getKey() ).get( "ipLevel" ) )
                        && entry.getValue().get( "currentLevel" ).equals( performanceReportDataFromResponse.get( entry.getKey() ).get( "currentLevel" ) );
            } ), "Performance Report data are fetched properly", "Performance Report data are not fetched properly. Expected -" + performanceReportDataFromDB.toString() + ": Actual -" + performanceReportDataFromResponse.toString() );

            // schema validation
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "postPerformanceReportSchema", statusCode, postPerformanceReportResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        }
    }

    @DataProvider ( name = "performanceReportpositiveScenario" )
    public Object[][] performanceReportpositiveScenario() {

        Object[][] inputData = { { "tc_PerformanceReport001", "Verify the 200 status code if hit the API with district admin credential", "HAPPY_PATH", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport002", "Verify the 200 status code if hit the API with school admin credential", "HAPPY_PATH", CommonAPIConstants.STATUS_CODE_OK, Admins.SCHOOL_ADMIN },
                { "tc_PerformanceReport003", "Verify the 200 status code if hit the API with multi-school admin credential", "HAPPY_PATH", CommonAPIConstants.STATUS_CODE_OK, Admins.MULTI_SCHOOL_ADMIN },
                { "tc_PerformanceReport004", "Verify the 200 status code if hit the API with subdistrict admin credential", "HAPPY_PATH", CommonAPIConstants.STATUS_CODE_OK, Admins.SUBDISTRICTWITHSCHOOL_ADMIN },
                { "tc_PerformanceReport006", "verify the 200 status code and message if the students are not having any default assignments and custom by setting - IPM on assignments", "ZERO_STATE_WITHOUT_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport007", "verify the 200 status code and message if the students are not attended the default assignments and custom by setting - IPM on assignments", "ZERO_STATE_NOT_YET_ATTENDED", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport008", "verify the 200 status code and message if the students are not Cleared IPM for the default assignments and custom by setting - IPM on assignments", "ZERO_STATE_NOT_YET_CLEAR_THE_IP",
                        CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport009", "Verify the 200 status code and the response if we pass single student in any one grade for Math who completed IPM", "FOR_MATH_SINGLE_STUDENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport010", "Verify the 200 status code and the response if we pass multiple students in any one grade for math who completed IPM.", "FOR_MATH_MULTIPLE_STUDENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport011", "Verify the 200 status code and the response if we pass multiple students in multiple grades for Math who completed IPM", "FOR_MATH_MULTIPLE_GRADE_STUDENT", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport012", "Verify the 200 status code and the response if we pass single student in any one grade for Reading who completed IPM", "FOR_READING_SINGLE_STUDENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport013", "Verify the 200 status code and the response if we pass multiple students in any one grade for Reading who completed IPM.", "FOR_READING_MULTIPLE_STUDENT", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport014", "Verify the 200 status code and the response if we pass multiple students in multiple grades for Reading who completed IPM.", "FOR_READING_MULTIPLE_GRADE_STUDENT", CommonAPIConstants.STATUS_CODE_OK,
                        Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport015", "Verify the 200 status code and the response if we pass multiple students who are having Math - Custom by setting course IPM on Course.", "FOR_MATH_CUSTOM_BY_SETTINGS_IPM_ON_COURSE",
                        CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport016", "Verify the 200 status code and the response if pass multiple students who are having Reading - Custom by setting course IPM on Course.", "FOR_READING_CUSTOM_BY_SETTINGS_IPM_ON_COURSE",
                        CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport017",
                        "Verify the 200 status code and the response if pass multiple students who are having Math- Custom by setting course IPM on Course with Manually set course level & Verify the 200 status code and the response if the students have group assignment.",
                        "FOR_MCL_COURSE_AND_GROUP_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport018", "Verify the 200 status code and the response when student has deleted the student assignment.", "DELETED_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport019", "Verify the 200 status code and the response when admin restored the student deleted assignment.", "RESTORED_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport020", "Verify the 200 status code and the response when teacher deleted the group assignment.", "DELETED_GROUP_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport021", "Verify the 200 status code and the response if the pass the orphan student Id.", "ORPHAN_STUDENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport022", "Verify the 200 status code and the response if we pass the suspended student Id.", "SUSPENDED_STUDENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN }, };
        return inputData;
    }

    /**
     * This method is used to test the Performance report API.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 2, dataProvider = "performanceReportNegativeScenario", groups = { "performanceReport", "SMK-51765", "P1", "API" } )
    public void performanceReportNegativeTest( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        String adminDetails = RBSDataSetup.adminDetails.get( admin );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        String adminOrgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        String subjectTypeId = "1";
        Map<String, List<String>> studentIds = new HashMap<>();
        studentIds.put( "grade_k", Arrays.asList( SMUtils.getKeyValueFromResponse( student1Details, "userId" ) ) );
        Map<String, String> response = new HashMap<>();
        String token = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        switch ( scenario ) {
            case "EMPTY_USER_ID":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( UserConstants.USERID, "" );
                headers.put( UserConstants.ORGID, adminOrgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                response = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "ZERO_STATE_WITHOUT_STUDENTS":
                subjectTypeId = "1";
                response = new Dashboard().postPerformanceReport( smUrl, headers, new HashMap<>(), subjectTypeId );
                break;

            case "WITHOUT_ACCESS_TOKEN":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, adminOrgId );
                headers.put( Constants.AUTHORIZATION, "" );
                response = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "EMPTY_ORGID":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, "" );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                response = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "INVALID_USERID":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( UserConstants.USERID, adminUserId + "invalid" );
                headers.put( UserConstants.ORGID, adminOrgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                response = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "WITH_STUDENT_CREDENTIAL":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( student1Details, "userId" ) );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( student1Details, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "WITH_TEACHER_CREDENTIAL":
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                response = new Dashboard().postPerformanceReport( smUrl, headers, studentIds, subjectTypeId );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;
            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        //Status code validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

        //Schema Validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "postPerformanceReportSchema", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        //Exception validation
        Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ).equalsIgnoreCase( exception ), "Exception Verified successfully!",
                "Issue in displaying exception! Expected - " + exception + "Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ) );

        //Status Validation
        Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,status" ).equalsIgnoreCase( "failure" ), "Status Verified successfully!", "Issue in displaying Status!" );

        //message Validation
        Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( message ), "Message Verified successfully!",
                "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ) );

    }

    @DataProvider ( name = "performanceReportNegativeScenario" )
    public Object[][] performanceReportNegativeScenario() {

        Object[][] inputData = { { "tc_PerformanceReport023", "Verify status code 401 when user id is not passed in header parameter", "EMPTY_USER_ID", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport024", "Verify status code 401 when bearer token is not passed in header parameter", "WITHOUT_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport025", "Verify status code 403 when Org ID is not passed in query parameter", "EMPTY_ORGID", CommonAPIConstants.STATUS_CODE_FORBIDDAN, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport026", "Verify status code 401 when User ID is invalid is in headers", "INVALID_USERID", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport027", "Verify status code 403 when User ID is student rumba id in headers", "WITH_STUDENT_CREDENTIAL", CommonAPIConstants.STATUS_CODE_FORBIDDAN, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport028", "Verify status code 403 when User ID is teacher rumba id in headers", "WITH_TEACHER_CREDENTIAL", CommonAPIConstants.STATUS_CODE_FORBIDDAN, Admins.DISTRICT_ADMIN },
                { "tc_PerformanceReport005", "Verify the 200 status code and message if the organization has no students", "ZERO_STATE_WITHOUT_STUDENTS", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN } };

        return inputData;
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, boolean isClearIP ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 3 ).forEach( value -> {
                        Log.message( "Math Custom Course Execution" );
                        try {
                            studentsPage.executeMathCourse( studentUserName, courseName, "95", "2", "30" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "5" );
                }

                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                if ( isClearIP ) {
                    IntStream.rangeClosed( 1, 2 ).forEach( value -> {
                        Log.message( "Reading Custom Course Execution" );
                        try {
                            studentsPage.executeReadingCourse( studentUserName, courseName, "95", "1", "30" );
                        } catch ( IOException e ) {
                            Log.message( "Error occurred while running the simulator" );
                        }
                    } );
                } else {
                    studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "5" );
                }
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    /**
     * To get the details from response
     * 
     * @return
     */
    public Map<String, Map<String, String>> getPeformanceReportDetailsFromResponse( Map<String, String> response ) {
        String data = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data" );
        Map<String, Map<String, String>> performanceReportDetails = new HashMap<>();
        AdminAPIConstants.GRADES.forEach( grade -> {
            String assignmentDetails = SMUtils.getKeyValueFromResponse( data, grade );
            Map<String, String> performanceDetailsForSpecificGrade = new HashMap<>();
            if ( assignmentDetails.contains( "currentLevel" ) ) {
                performanceDetailsForSpecificGrade.put( "currentLevel", SMUtils.getKeyValueFromResponse( assignmentDetails, "currentLevel" ) );
                performanceDetailsForSpecificGrade.put( "ipLevel", SMUtils.getKeyValueFromResponse( assignmentDetails, "ipLevel" ) );
                performanceDetailsForSpecificGrade.put( "gain", SMUtils.getKeyValueFromResponse( assignmentDetails, "gain" ) );
            } else {
                performanceDetailsForSpecificGrade.put( "currentLevel", "null" );
                performanceDetailsForSpecificGrade.put( "ipLevel", "null" );
                performanceDetailsForSpecificGrade.put( "gain", "null" );
            }
            performanceReportDetails.put( grade, performanceDetailsForSpecificGrade );
        } );
        return performanceReportDetails;
    }

    /**
     * To get the details from DB
     * 
     * @return
     */
    public Map<String, Map<String, String>> getPeformanceReportDetailsFromDB( Map<String, List<String>> studentIds, String subjectTypeId ) {
        Map<String, Map<String, String>> performanceReportDetails = new HashMap<>();
        AdminAPIConstants.GRADES.forEach( grade -> {
            Map<String, String> performanceDetailsForSpecificGrade = new HashMap<>();
            if ( Objects.nonNull( studentIds.get( grade ) ) ) {
                performanceDetailsForSpecificGrade = SqlHelperAssignment.getPerformanceReport( studentIds.get( grade ), subjectTypeId.equals( "2" ) ? "1292" : "1" );
            } else {
                performanceDetailsForSpecificGrade.put( "currentLevel", "null" );
                performanceDetailsForSpecificGrade.put( "ipLevel", "null" );
                performanceDetailsForSpecificGrade.put( "gain", "null" );
            }
            performanceReportDetails.put( grade, performanceDetailsForSpecificGrade );
        } );
        return performanceReportDetails;
    }

    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }
}
