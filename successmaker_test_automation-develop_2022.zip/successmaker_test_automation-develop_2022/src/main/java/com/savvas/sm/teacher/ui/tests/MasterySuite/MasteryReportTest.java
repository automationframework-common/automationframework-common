package com.savvas.sm.teacher.ui.tests.MasterySuite;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperUsage;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class MasteryReportTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String studentDetails;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher19" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        password = DataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify the Run Report button is in disabled state in the bottom left of the Mastery page", priority = 1 )
    public void verifyRunReportButtonIsDisabled( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "SMK-43896:Verify the Run Report button is in disabled state in the bottom left of the Mastery page <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            SMUtils.logDescriptionTC( "SMK-11421 : Verify the Run Report button is in disabled state in the bottom left of the Mastery page" );
            Log.assertThat( !masteryPage.isRunBtnEnabled(), "The 'Run Report' button is disabled as default after landing mastery page", "The 'Run Report' button is enabled as default after landing mastery page" );
            masteryFiltersComponent.applyFilter();
            SMUtils.logDescriptionTC( "SMK-11422 & SMK-11423 : Verify the Run Report button is in disabled state in the bottom left of the Mastery page when mastery data is not available" );
            Log.assertThat( !masteryPage.isRunBtnEnabled(), "The 'Run Report' button is disabled when zero Mastery state is available", "The 'Run Report' button is enabled when zero Mastery state is available" );
            Log.testCaseResult();
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Run Report button is enabled when Mastery data is available", groups = { "executeCourse" }, priority = 2 )
    public void verifyRunReportButtonIsEnabled( ITestContext context ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // navigate to Student Page
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Math Course and assigning to student
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            coursePage.clickBackIcon();
            driver.quit();

    		// Get driver
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            studentDetails = DataSetup.teacherStudentMap.get( username ).get( "Student1" );
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, "data,userName" );
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Constants.MATH, "80", "5", "5" );
            driver.quit();
            new SqlHelperUsage();
            SqlHelperUsage.shareUsageData( DataSetupConstants.BVT_SCHOOL );

    		// Get driver
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.applyFilter();
            SMUtils.logDescriptionTC( "SMK-11424 : Verify Run Report button is enabled when Mastery data is available" );
            Log.assertThat( masteryPage.isRunBtnEnabled(), "The 'Run Report' button is enabled when Mastery data is available", "The 'Run Report' button is not enabled when Mastery data is available" );
            Log.testCaseResult();
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
