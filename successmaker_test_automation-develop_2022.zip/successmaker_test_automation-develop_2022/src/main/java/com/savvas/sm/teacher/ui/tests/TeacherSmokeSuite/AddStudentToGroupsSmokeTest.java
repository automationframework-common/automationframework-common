package com.savvas.sm.teacher.ui.tests.TeacherSmokeSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;

import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.Constants.GroupUIConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class AddStudentToGroupsSmokeTest extends EnvProperties {
    private String smUrl;
    private String browser;
    private String username = null;
    private String studentID_1 = "IC_student2";
    private String studentID_2;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String groupName;
    private static String studentOne;
    private static String studentTwo;
    private static String studentFour;
    private static String studentFive;
    private static String studentSix;
    private String teacherDetails;
    private String groupDetails;
    String studentDetails1;
    String studentDetails2;
    String studentDetails3;
    String studentDetails4;
    String studentDetails5;
    GroupPage groupsTab;
    public HashMap<String, String> stuDetailsMap = new HashMap<>();
    private String stuUserName1;
    public List<String> stuDetails = new ArrayList<>();
    private String schoolID;
    private String teacherID;
    
    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentDetails1 = RBSDataSetup.getMyStudent( school, username );
        studentDetails2 = RBSDataSetup.getMyStudent( school, username );
        studentDetails4 = RBSDataSetup.getMyStudent( school, username );
        studentDetails5 = RBSDataSetup.getMyStudent( school, username );
        studentDetails3 = RBSDataSetup.getMyStudent( school, username );

        studentOne = ( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ) );
        studentTwo = ( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERNAME ) );
        studentFour = ( SMUtils.getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERNAME ) );
        studentFive = ( SMUtils.getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERNAME ) );
        studentSix = ( SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERNAME ) );

        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERID ) );

        HashMap<String, String> groupDetailsMap = new HashMap<>();
        groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, "SM Regression Group" + System.nanoTime() );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );
        groupDetails = SMUtils.getKeyValueFromResponse( createGroup.get( Constants.BODY ), "data" );
   
        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        
        IntStream.range( 1, Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) ) ).forEach( count -> {
            String studentDetails = RBSDataSetup.getMyStudent( school, username );
            stuDetails.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ) );
            stuUserName1 = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            stuDetailsMap.put( "Student" + count + "", stuUserName1 );
        } );
    }

    @Test ( description = "Verify add student to Group", priority = 1, groups = { "SMK-42082", "Groups", "GroupsSmokeTest" } )
    public void tcGroupsSmokeTest001() throws Exception {
     // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
       
        
        try {
            
            Log.testCaseInfo( "tcGroupsSmokeTest001 : Verify add student to Group <small><b><i>[" + browser + "]</b></i></small>" );
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Groups tab 
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();

            String groupName1 = "SM AutoGroup" + System.nanoTime();
            groupsPage.createGroupWithoutStudent( groupName1 );

            groupsPage.viewGroup( groupName1 );

            // Click add student to group button
            groupsPage.clickAddStudentToGrpBtnGrpPage();

            // Case 1
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student2" ) );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickAddButton();
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student3" ) );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickAddButton();
            groupsPage.clickSaveBtnAddStudToGrpPopUp();
           
            // Navigating to the Groups tab 
            tHomePage.topNavBar.navigateToHomeTab();
            groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName1 );
            
            Log.assertThat( groupsPage.isUserPresentInGrp( stuDetailsMap.get( "Student2" ) ), "Student Successfully added to group", "Not added to Group" );
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify Group listing page", priority = 1, groups = { "SMK-42082", "Groups", "GroupsSmokeTest" } )
    public void tcGroupsSmokeTest002() throws Exception {
        // Deleting all the groups
        Log.testCaseInfo( "Verification of Group listing on the Zero State" );
        Log.message( "Deleting all groups" );
        deleteAllGroupsByAPI();

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        groupsTab = new GroupPage( driver );
        try {
            
            Log.testCaseInfo( "tcGroupsSmokeTest002 : Verify add student to Group <small><b><i>[" + browser + "]</b></i></small>" );
            
            // Loggin in and goes to group tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            //        //Creating group
            String GroupName = "Group1";
            groupsTab.createGroupWithoutStudent( GroupName );
            List<String> groupsList = new ArrayList<String>();
            groupsList.add( GroupName );

            Log.message( "checking if the group is present on the UI" );
            List<String> groupsFromUI = groupsTab.getGroupNames();
            // GroupName.tr
            Log.assertThat( groupsFromUI.equals( groupsList ), "The Created Group is present on the UI", "Group created" + groupsList + "is not present on the UI" + groupsFromUI );
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );

            String noOfStudents = groupsTab.getNo_Of_Students( GroupName );
            Log.assertThat( noOfStudents.equals( "0" ), "# of Student count is matching!", "# of Student count is not matching! expected 0" + " actual is " + noOfStudents );

            groupsTab.clickGetViewGroupBtn( GroupName );
            String groupHeaderName = groupsTab.getGroupNameinContainer();
            Log.assertThat( groupHeaderName.equals( GroupName ), "The Group name is mathcing!", "Group name is not matching expected " + GroupName + " groupHeaderName" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify the Student search in the school level while adding the student to group.", priority = 1, groups = { "SMK-42082", "Groups", "GroupsSmokeTest" } )
    public void tcGroupsSmokeTest003() throws Exception {
     // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        
        Log.testCaseInfo( "tcGroupsSmokeTest003 : Verify the Student search in the school level while adding the student to group. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Groups tab 
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();

            String groupName1 = "SM AutoGroup" + System.nanoTime();
            groupsPage.createGroupWithoutStudent( groupName1 );

            groupsPage.viewGroup( groupName1 );

            // Click add student to group button
            groupsPage.clickAddStudentToGrpBtnGrpPage();

            // Case 1
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student2" ) );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickAddButton();
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student3" ) );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickAddButton();
            groupsPage.clickSaveBtnAddStudToGrpPopUp();
           
            // Navigating to the Groups tab 
            tHomePage.topNavBar.navigateToHomeTab();
            groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName1 );
            
            Log.assertThat( groupsPage.isUserPresentInGrp( stuDetailsMap.get( "Student2" ) ), "Student Successfully added to group", "Not added to Group" );
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }
    
    public void deleteAllGroupsByAPI() throws Exception {

        RBSDataSetup data = new RBSDataSetup();

        HashMap<String, String> groupDetails = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.STAFF_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );

        HashMap<String, String> groupListingForTeacherID = new GroupAPI().getGroupListingForTeacherID( smUrl, groupDetails );

        data.deleteAllGroupUnderTeacher( groupListingForTeacherID.get( Constants.REPORT_BODY ), groupDetails.get( GroupConstants.GROUP_OWNER_ID ), groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ),
                new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

    }

    /**
     * To get the List of Random Text
     * 
     * @param int size of List
     * @return
     */
    public List<String> getListOfRandomText( int size ) {
        List<String> groupAsciiNames = new ArrayList<String>();
        IntStream.rangeClosed( 1, size ).forEach( element -> {
            groupAsciiNames.add( getSaltString() );
        } );
        return groupAsciiNames;
    }

    protected static String getSaltString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while ( salt.length() < 7 ) { // length of the random string.
            int index = (int) ( rnd.nextFloat() * SALTCHARS.length() );
            salt.append( SALTCHARS.charAt( index ) );
        }
        String saltStr = salt.toString();
        return saltStr;
    }
}
