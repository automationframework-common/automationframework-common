package com.savvas.sm.teacher.ui.tests.HomeSuite;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class HomePageCourseWidgetLinceseTest extends BaseTest {
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    TeacherHomePage tHomePage;
    LoginPage smLoginPage;
    String teacherDetailsAgain;
    List<String> studentListFromTheAssignmentPopup;
    List<String> studentList;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String teacherDetails;

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
    }

    @Test ( description = "Verify that default courses are listed on home page if the organization has license for both Math and Reading with last edited date", groups = { "SMK-40845", "HomePage",
            "HomePage Course" }, priority = 1 )
    public void tc_SMCourseHomePage001( ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


        Log.testCaseInfo( "tc_SMCourseHomePage001: Verify that default courses are listed on home page if the organization has license for both Math and Reading with last edited date<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );
            studentListFromTheAssignmentPopup = new ArrayList<>();
            CoursesPage customCourses = new CoursesPage( driver );
            String staticCourseName = customCourses.generateRandomCourseName();
            String newCourseName = customCourses.generateRandomCourseName();
            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfMathCourse( staticCourseName, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            tHomePage.topNavBar.navigateToHomeTab();
            if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.CREATED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.CREATED_DATE ), "Edited or Created date is diaplayed", "Edited or created is not displayed" );

            } else if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ), "Assigned date is displayed", "Assigned date is not displayed" );
            }

            tHomePage.topNavBar.getCourseListingPage();

            //Click on the course
            customCourses.clickCourseFromTheListing( staticCourseName );

            //Edit the course settings
            customCourses.clickEditBtnCourseLevel();

            //Verify edit button
            customCourses.verifyEditAndRemoveBtnPresent();
            //Enter name again
            customCourses.enterCourseName( newCourseName );

            customCourses.clickNextBtn();

            ///Click Next from Setting page
            customCourses.clickNextBtn();

            //Click Save button
            customCourses.clickSaveBtnForEdit();

            tHomePage.topNavBar.navigateToHomeTab();
            if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ), "Edited or Created date is diaplayed for courses in Homepage", "Edited or created is not displayed" );

            } else if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ), "Assigned date is displayed", "Assigned date is not displayed" );
            }

            Log.assertThat( tHomePage.isCoursesWidgetDisplayed(), "Courses widget is displayed in HomePage", "Courses widget is not displayed in HomePage" );
            List<String> courseName = tHomePage.getCourseTitleFromCoursesWidget();

            Log.assertThat( courseName.get( 0 ).contains( Constants.HomePage.MATH_COURSE ), "Math Title is displaying in course widget", "Math Title is not displaying in course widget" );

            Log.assertThat( courseName.get( 1 ).contains( Constants.HomePage.READING_COURSE ), "Reading Title is displaying in course widget", "Math Title is not displaying in course widget" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that default courses are listed on home page if the organization has license for both Math and Reading with assigned date on adding a student", groups = { "SMK-40845", "HomePage", "HomePage Course" }, priority = 2 )
    public void tc_SMCourseHomePage002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


        Log.testCaseInfo( "tc_SMCourseHomePage002:Verify that default courses are listed on home page if the organization has license for both Math and Reading with assigned date on adding a student <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            Log.assertThat( tHomePage.isCoursesWidgetDisplayed(), "Courses widget is displayed in HomePage", "Courses widget is not displayed in HomePage" );
            List<String> courseName = tHomePage.getCourseTitleFromCoursesWidget();

            Log.assertThat( courseName.get( 0 ).contains( Constants.HomePage.MATH_COURSE ), "Math Title is displaying in course widget", "Math Title is not displaying in course widget" );

            Log.assertThat( courseName.get( 1 ).contains( Constants.HomePage.READING_COURSE ), "Reading Title is displaying in course widget", "Math Title is not displaying in course widget" );

            Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ), "Assigned date is displayed", "Assigned date is not displayed" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            driver.quit();
        }
    }

    // Note Skipping this test case
    // As part of UI Testing We have Flex licensed sschool alone so not able to test licensed specified cases so added enabled =false tag.
    @Test ( description = "Verify that Math course is listed on home page if the organization has license for Math course alone", groups = { "SMK-40845", "HomePage", "HomePage Course" }, priority = 3 ,enabled=false )
    public void tc_SMCourseHomePage003( ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseHomePage003:Verify that Math course is listed on home page if the organization has license for Math course alone  <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            Log.assertThat( tHomePage.isCoursesWidgetDisplayed(), "Courses widget is displayed in HomePage", "Courses widget is not displayed in HomePage" );
            List<String> courseName = tHomePage.getCourseTitleFromCoursesWidget();
            Log.assertThat( courseName.get( 0 ).contains( Constants.HomePage.MATH_COURSE ), "Math Title is displaying in course widget", "Math Title is not displaying in course widget" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that, on updating custom course listed on home page they are displayed with last updated date",  groups = { "SMK-40845", "HomePage", "HomePage Course" }, priority = 4 )
    public void tc_SMCourseHomePage004(  ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseHomePage004:Verify that, on updating custom course listed on home page they are displayed with last updated date<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            studentListFromTheAssignmentPopup = new ArrayList<>();
            CoursesPage customCourses = new CoursesPage( driver );
            String staticCourseName = customCourses.generateRandomCourseName();
            String newCourseName = customCourses.generateRandomCourseName();
            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfMathCourse( staticCourseName, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            tHomePage.topNavBar.navigateToHomeTab();
            if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.CREATED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.CREATED_DATE ), "Edited or Created date is diaplayed", "Edited or created is not displayed" );

            } else if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ), "Assigned date is displayed", "Assigned date is not displayed" );
            }

            tHomePage.topNavBar.getCourseListingPage();

            //Click on the course
            customCourses.clickCourseFromTheListing( staticCourseName );

            //Edit the course settings
            customCourses.clickEditBtnCourseLevel();

            //Verify edit button
            customCourses.verifyEditAndRemoveBtnPresent();
            //Enter name again
            customCourses.enterCourseName( newCourseName );

            customCourses.clickNextBtn();

            ///Click Next from Setting page
            customCourses.clickNextBtn();

            //Click Save button
            customCourses.clickSaveBtnForEdit();

            tHomePage.topNavBar.navigateToHomeTab();

            if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ), "Edited or Created date is diaplayed", "Edited or created is not displayed" );

            } else if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ), "Assigned date is displayed", "Assigned date is not displayed" );
            }

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }


    // Note Skipping this test case
    // As part of UI Testing We have Flex licensed school alone so not able to test licensed specified cases so added enabled =false tag.
    @Test ( description = "Verify that, only focus courses are displayed on home page, based on last modified date when organization has license for focus courses alone", groups = { "SMK-40845", "HomePage",
            "HomePage Course" }, priority = 4,enabled=false )
    public void tc_SMCourseHomePage005(  ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseHomePage005:Verify that, only focus courses are displayed on home page, based on last modified date when organization has license for focus courses alone<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );
            studentListFromTheAssignmentPopup = new ArrayList<>();
            CoursesPage customCourses = new CoursesPage( driver );
            String staticCourseName = "Focus" + customCourses.generateRandomCourseName();
            String staticFocusCourseName = customCourses.generateRandomCourseName();
            String newCourseName = "Focus" + customCourses.generateRandomCourseName();
            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            customCourses.copyOfMathCourseFocus( staticCourseName, Constants.STANDARDS, Constants.HomePage.FOCUS_MATH_COURSE );

            tHomePage.topNavBar.getCourseListingPage();

            //Click on the course
            customCourses.clickCourseFromTheListing( staticCourseName );

            //Edit the course settings
            customCourses.clickEditBtnCourseLevel();

            //Verify edit button
            customCourses.verifyEditAndRemoveBtnPresent();
            //Enter name again
            customCourses.enterCourseName( newCourseName );

            customCourses.clickNextBtn();

            ///Click Next from Setting page
            customCourses.clickNextBtn();

            //Click Save button
            customCourses.clickSaveBtnForEdit();

            tHomePage.topNavBar.navigateToHomeTab();

            if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ), "Edited or Created date is diaplayed", "Edited or created is not displayed" );

            } else if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ), "Assigned date is displayed", "Assigned date is not displayed" );
            }

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = " Verify that the last edited date is updated on removing the assignment ", groups = { "SMK-40845", "HomePage", "HomePage Course" }, priority = 2 )
    public void tc_SMCourseHomePage006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseHomePage006:Verify that the last edited date is updated on removing the assignment <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // Login to the SM_Application
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // System.out.println( "Student details is " + studentDetails );
            String studentDetails1 = RBSDataSetup.getMyStudent( school, username );

            String fname = SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.FIRSTNAME );
            String lname = SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.LASTNAME );
            String studentFNLN = fname + " " + lname ;
            // Select Focus course
            CoursesPage coursepage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursepage.clickCourseName( Constants.SM_FOCUS_MATH_GRADE3 );

            // Clicking on 'Assign-Widget' and assigning
            coursepage.clickAssignBtn();
            coursepage.addCourseToStudents();

            // Navigate 'CourseWare' tab and select the 'Assignments' option
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_MATH_GRADE3 );

            // Verifying the Remove_Student option in the Ellipsis
            assignmentDetailsPage.removeStudentFromAssignment( studentFNLN );

            Log.assertThat( !assignmentDetailsPage.getStudentListfromAssignementDetailsTable().contains( studentFNLN ), "Mentioned student removed", "Mentioned student not removed" );

            tHomePage.topNavBar.navigateToHomeTab();

            if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ), "Edited or Created date is diaplayed", "Edited or created is not displayed" );

            } else if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ), "Assigned date is displayed", "Assigned date is not displayed" );
            }

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that, on assigning default and focus courses listed on home page they are displayed with assigned date",  groups =

    { "SMK-40845", "HomePage", "HomePage Course" }, priority = 7 )

    public void tc_SMCourseHomePage007(  ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseHomePage007:Verify that, on assigning default and focus courses listed on home page they are displayed with assigned date<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );
            studentListFromTheAssignmentPopup = new ArrayList<>();
            CoursesPage customCourses = new CoursesPage( driver );
            String staticCourseName = "Focus" + customCourses.generateRandomCourseName();
            String staticFocusCourseName = customCourses.generateRandomCourseName();
            String newCourseName = "Focus" + customCourses.generateRandomCourseName();
            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );
            customCourses.copyOfMathCourseFocus( staticCourseName, Constants.STANDARDS, Constants.HomePage.FOCUS_MATH_COURSE );
            tHomePage.topNavBar.getCourseListingPage();

            tHomePage.topNavBar.navigateToHomeTab();

            Log.assertThat( tHomePage.isCoursesWidgetDisplayed(), "Courses widget is displayed in HomePage", "Courses widget is not displayed in HomePage" );
            List<String> courseName = tHomePage.getCourseTitleFromCoursesWidget();
            Log.assertThat( courseName.get( 0 ).contains( Constants.HomePage.MATH_COURSE ), "Math Title is displaying in course widget", "Math Title is not displaying in course widget" );

            Log.assertThat( courseName.get( 1 ).contains( Constants.HomePage.READING_COURSE ), "Reading Title is displaying in course widget", "Math Title is not displaying in course widget" );

            Boolean status = false;
            for ( String eachCourse : courseName ) {
                if ( eachCourse.contains( staticCourseName ) ) {
                    status = true;
                    break;
                }
            }
            Log.assertThat( status, "Focus course tiltle is displaying in course widget", "Focus course tile is not displaying in course widget" );
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }
}
