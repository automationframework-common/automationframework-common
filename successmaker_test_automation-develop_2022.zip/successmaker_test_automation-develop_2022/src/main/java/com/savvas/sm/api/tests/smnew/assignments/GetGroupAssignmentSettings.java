package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

/**
 * To test the GET API to get Group Assignment Settings
 *
 * @author Subramanian
 *
 */
public class GetGroupAssignmentSettings extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String CourseId;
    private String teacherUsername;
    List<String> studentRumbaIds = new ArrayList<>();
    RBSUtils rbsutils = new RBSUtils();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    /**
     * Tests the positive scenarios of create group.
     *
     * @param description
     * @param scenario
     * @param statusCode
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "getGroupAssignmentsSettingsPositiveFlow", groups = { "SMK-52071", "GroupAssignmentsSettings", "P1", "API", "smoke_test_case" } )
    public void groupAssignmentSettingsPostiveTestcases( String description, String scenario, String courseid, String statusCode, String id1, String id2, String message ) throws Exception {

        Log.testCaseInfo( description );
        HashMap<String, String> groupDetails = new HashMap<>();
        Map<String, String> apiResponse = new HashMap<>();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        HashMap<String, String> apiResponseGetSettings = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( Constants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( Constants.STAFF_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" + System.nanoTime() );
        String groupid = createGroupforAssignment( smUrl, groupDetails, studentRumbaIds );
        Log.message( "groupid=" + groupid );

        if ( scenario.contains( "NOSTUDENT" ) ) {
            groupAPI.removeStudentFromGroup( smUrl, studentRumbaIds.get( 0 ), groupid, groupDetails.get( Constants.STAFF_ID ), groupDetails.get( Constants.ORG_ID ), groupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
            Log.message( "No student in group or empty group" );
        }

        groupDetails.put( CreateGroupAPIConstants.GROUP_ID, groupid );
        HashMap<String, String> courseSettings = new HashMap<>();
        courseSettings.put( CourseAPIConstants.ORG_ID, orgId );
        courseSettings.put( CourseAPIConstants.TEACHER_ID, teacherId );
        courseSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        if ( scenario.contains( "CUSTOM" ) ) {
            CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
            apiResponseGetSettings = courseAPI.getCoursesSettings( smUrl, courseSettings, "false", CourseId );
            Log.message( "Get Settings : " + apiResponseGetSettings );
            JSONObject postResp = SMUtils.convertResponseAsJsonObj( apiResponseGetSettings.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );
            JSONObject data2 = postResp.getJSONObject( "SESSION_LENGTH" );
            String sessionLengthName = data2.getString( "name" );
            Long sessionLengthId = data2.getLong( "id" );
            String sessionLengthValue = data2.getString( "currentValue" );
            JSONObject data3 = postResp.getJSONObject( "IDLE_TIME" );
            String idleTimeName = data3.getString( "name" );
            Long idleTimeId = data3.getLong( "id" );
            String idleTimeValue = data3.getString( "currentValue" );
            courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( sessionLengthId ) );
            courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName );
            courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
            courseSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
            courseSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
            courseSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue );
        } else {
            CourseId = courseid;
            courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, id1 );
            courseSettings.put( CourseAPIConstants.IDLE_TIME_ID, id2 );
        }
        Log.message( "CourseId=" + CourseId );
        groupDetails.put( CourseAPIConstants.COURSE_ID, CourseId );
        assignCourseToGroup( smUrl, groupDetails, courseSettings, scenario );
        apiResponse = getGroupAssignmentSettings( smUrl, groupDetails );
        verifyResponse( apiResponse, message, statusCode );
        Log.testCaseResult();
    }

    @Test ( priority = 1, dataProvider = "getGroupAssignmentsSettingsNegativeFlow", groups = { "SMK-52071", "GroupAssignmentsSettings", "P1", "API" } )
    public void groupAssignmentSettingsNegativeTestcases( String description, String scenario, String courseid, String statusCode, String id1, String id2, String message ) throws Exception {

        Log.testCaseInfo( description );
        HashMap<String, String> groupDetails = new HashMap<>();
        Map<String, String> apiResponse = new HashMap<>();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        HashMap<String, String> apiResponseGetSettings = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( Constants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( Constants.STAFF_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" + System.nanoTime() );
        String groupid = createGroupforAssignment( smUrl, groupDetails, studentRumbaIds );
        Log.message( "groupid=" + groupid );
        groupDetails.put( CreateGroupAPIConstants.GROUP_ID, groupid );
        HashMap<String, String> courseSettings = new HashMap<>();
        courseSettings.put( CourseAPIConstants.ORG_ID, orgId );
        courseSettings.put( CourseAPIConstants.TEACHER_ID, teacherId );
        courseSettings.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        if ( scenario.contains( "CUSTOM" ) ) {
            CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
            apiResponseGetSettings = courseAPI.getCoursesSettings( smUrl, courseSettings, "false", CourseId );
            Log.message( "Get Settings : " + apiResponseGetSettings );
            JSONObject postResp = SMUtils.convertResponseAsJsonObj( apiResponseGetSettings.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );
            JSONObject data2 = postResp.getJSONObject( "SESSION_LENGTH" );
            String sessionLengthName = data2.getString( "name" );
            Long sessionLengthId = data2.getLong( "id" );
            String sessionLengthValue = data2.getString( "currentValue" );
            JSONObject data3 = postResp.getJSONObject( "IDLE_TIME" );
            String idleTimeName = data3.getString( "name" );
            Long idleTimeId = data3.getLong( "id" );
            String idleTimeValue = data3.getString( "currentValue" );
            courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( sessionLengthId ) );
            courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName );
            courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
            courseSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
            courseSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
            courseSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue );
        } else {
            CourseId = courseid;
            courseSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, id1 );
            courseSettings.put( CourseAPIConstants.IDLE_TIME_ID, id2 );
        }
        Log.message( "CourseId=" + CourseId );
        groupDetails.put( CourseAPIConstants.COURSE_ID, CourseId );
        assignCourseToGroup( smUrl, groupDetails, courseSettings, scenario );
        if ( scenario.contains( "INVALIDORG" ) ) {
            groupDetails.put( Constants.ORG_ID, CourseAPIConstants.INVALID_ORGANIZATION_ID );
        } else if ( scenario.contains( "NONEXISTINGORG" ) ) {
            groupDetails.put( Constants.ORG_ID, CourseAPIConstants.NON_EXISTING_ORGANIZATION_ID );
        } else if ( scenario.contains( "INVALIDSTAFFID" ) ) {
            groupDetails.put( Constants.STAFF_ID, CourseAPIConstants.INVALID_STAFF_ID_RANDOM );
        } else if ( scenario.contains( "NONEXISTINGSTAFFID" ) ) {
            groupDetails.put( Constants.STAFF_ID, CourseAPIConstants.NON_EXISTING_STAFF_ID );
        } else if ( scenario.contains( "INVALIDCOURSEID" ) ) {
            groupDetails.put( CourseAPIConstants.COURSE_ID, CourseAPIConstants.INVALID_COURSE_ID );
        } else if ( scenario.contains( "NONEXISTINGCOURSEID" ) ) {
            groupDetails.put( CourseAPIConstants.COURSE_ID, CourseAPIConstants.NON_EXISTING_COURSE_ID );
        } else if ( scenario.contains( "INVALIDGROUPID" ) ) {
            groupDetails.put( CreateGroupAPIConstants.GROUP_ID, CourseAPIConstants.INVALID_GROUP_ID );
        } else if ( scenario.contains( "INVALIDAUTHORIZATION" ) ) {
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, CourseAPIConstants.INVALID_STAFF_ID_RANDOM );
        } else if ( scenario.contains( "INVALIDORDIDHEADER" ) ) {
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, CourseAPIConstants.INVALID_ORGANIZATION_ID );
        }

        apiResponse = getGroupAssignmentSettings( smUrl, groupDetails );
        verifyResponse( apiResponse, message, statusCode );
        Log.testCaseResult();
    }

    /**
     * Data provider for positive scenarios
     *
     * @return
     */
    @DataProvider ( name = "getGroupAssignmentsSettingsPositiveFlow" )
    public Object[][] getGroupAssignmentsSettingsPositiveFlow() {

        Object[][] inputData = { { "TC01_Verify the status code is 200 when valid data is given for assignment which has been created from default math.", "DEFAULT_MATH", "1", CommonAPIConstants.STATUS_CODE_OK, "1", "2", "Operation succeeded!" },
                { "TC02_Verify the status code is 200 when valid data is given for assignment which has been created from default reading.", "DEFAULT_READING", "2", CommonAPIConstants.STATUS_CODE_OK, "24", "25", "Operation succeeded!" },
                { "TC03_Verify the status code is 200 when valid data is given for assignment which has been created from custom math.", "CUSTOM_MATH", "", CommonAPIConstants.STATUS_CODE_OK, "", "", "Operation succeeded!" },
                { "TC04_Verify the status code is 200 when valid data is given for assignment which has been created from custom reading.", "CUSTOM_READING", "", CommonAPIConstants.STATUS_CODE_OK, "", "", "Operation succeeded!" },
                { "TC05_Verify the status code is 200 when valid data is given for assignment which has been created from focus math", "SM_FOCUS_MATH", "3", CommonAPIConstants.STATUS_CODE_OK, "1", "2", "Operation succeeded!" },
                { "TC06_Verify the status code is 200 when valid data is given for assignment which has been created from focus reading.", "SM_FOCUS_READING", "11", CommonAPIConstants.STATUS_CODE_OK, "1", "2", "Operation succeeded!" },
                { "TC07_Verify the status code is 200 when group id is given which is not having any student", "DEFAULT_MATH_NOSTUDENT", "1", CommonAPIConstants.STATUS_CODE_OK, "1", "2", "Operation succeeded!" },

        };

        return inputData;
    }

    @DataProvider ( name = "getGroupAssignmentsSettingsNegativeFlow" )
    public Object[][] getGroupAssignmentsSettingsNegativeFlow() {

        Object[][] inputData = {
                { "TC08_Verify the status code is 400 when invalid org id(aa) is given.", "DEFAULT_MATH_INVALIDORG", "1", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "1", "2",
                        "OrgId: 22220a5a7f2c9dcf017f3fe81bc602we from request URI does not present in OrgIds:" },
                { "TC09_Verify the status code is 400 when org id is given which belongs to different teacher.", "DEFAULT_MATH_NONEXISTINGORG", "1", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "1", "2",
                        "OrgId: 8a720a5a7f2c9dcf017f3fe81bc602we from request URI does not present in OrgIds:" },
                { "TC10_Verify the status code is 400 when invalid staff id is given.", "DEFAULT_MATH_INVALIDSTAFFID", "1", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "1", "2", "Login UserId / Request User Id mismatch" },
                { "TC11_Verify the status code is 400 when staff id is given which belongs to different org", "DEFAULT_MATH_NONEXISTINGSTAFFID", "1", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "1", "2", "Login UserId / Request User Id mismatch" },
                { "TC12_Verify the status code is 400 when invalid course id is given.", "DEFAULT_MATH_INVALIDCOURSEID", "1", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "1", "2",
                        "Failed to convert value of type 'java.lang.String' to required type 'java.lang.Long';" },
                { "TC13_Verify the status code is 200 when non exsting course id is given.", "DEFAULT_MATH_NONEXISTINGCOURSEID", "1", CommonAPIConstants.STATUS_CODE_OK, "1", "2", "Group Assignment not found." },
                { "TC17_Verify the status code is 400 when invalid group id is given.", "DEFAULT_MATH_INVALIDGROUPID", "1", CommonAPIConstants.STATUS_CODE_BAD_REQUEST, "1", "2", "Failed to get the details of group with group id" },
                { "TC23_Verify the status code is 401 when invalid authorization is given", "DEFAULT_MATH_INVALIDAUTHORIZATION", "1", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, "1", "2", "Authentication Failed" },
                { "TC24_Verify the status code is 403 when invalid Org id in headers", "DEFAULT_MATH_INVALIDORDIDHEADER", "1", CommonAPIConstants.STATUS_CODE_FORBIDDAN, "1", "2", "Access is denied" }, };

        return inputData;
    }

    public HashMap<String, String> assignCourseToGroup( String envUrl, HashMap<String, String> groupDetails, HashMap<String, String> courseSettings, String scenario ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + groupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );
        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = CreateGroupAPIConstants.ASSIGN_COURSE_GROUP;
        endPoint = endPoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
        endPoint = endPoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
        endPoint = endPoint.replace( Constants.COURSE_ID, groupDetails.get( CourseAPIConstants.COURSE_ID ) );

        Log.message( "assignCourseToGroup=" + endPoint );
        String requestBody;
        if ( scenario.contains( "CUSTOM" ) ) {
            requestBody = SMUtils.convertFileToString( configProperty.getProperty( "assignCustomCourseToGroupPayload" ) );
            requestBody = requestBody.replace( Constants.SESSION_LENGTH_ID, courseSettings.get( CourseAPIConstants.SESSION_STRENGTH_ID ) );
            requestBody = requestBody.replace( Constants.SESSION_LENGTH_NAME, courseSettings.get( CourseAPIConstants.SESSION_STRENGTH_NAME ) );
            requestBody = requestBody.replace( Constants.SESSION_LENGTH_VALUE, courseSettings.get( CourseAPIConstants.SESSION_STRENGTH_VALUE ) );
            requestBody = requestBody.replace( Constants.IDLE_TIME_ID, courseSettings.get( CourseAPIConstants.IDLE_TIME_ID ) );
            requestBody = requestBody.replace( Constants.IDLE_TIME_NAME, courseSettings.get( CourseAPIConstants.IDLE_TIME_NAME ) );
            requestBody = requestBody.replace( Constants.IDLE_TIME_VALUE, courseSettings.get( CourseAPIConstants.IDLE_TIME_VALUE ) );
        } else {
            requestBody = SMUtils.convertFileToString( configProperty.getProperty( "assignCourseToGroupPayload" ) );
            requestBody = requestBody.replace( Constants.SESSION_LENGTH_ID, courseSettings.get( CourseAPIConstants.SESSION_STRENGTH_ID ) );
            requestBody = requestBody.replace( Constants.IDLE_TIME_ID, courseSettings.get( CourseAPIConstants.IDLE_TIME_ID ) );

        }
        requestBody = requestBody.replace( Constants.GROUPID, groupDetails.get( CreateGroupAPIConstants.GROUP_ID ) );
        HashMap<String, String> response = RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody );
        Log.message( " assignCourseToGroup endPoint" + endPoint );
        Log.message( " assignCourseToGroup response" + requestBody );
        Log.message( " assignCourseToGroup " + response );
        return response;
    }

    public HashMap<String, String> getGroupAssignmentSettings( String envUrl, HashMap<String, String> groupDetails ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + groupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = CreateGroupAPIConstants.GROUP_ASSIGNMENT_SETTINGS;
        endPoint = endPoint.replace( Constants.ORG_ID, groupDetails.get( Constants.ORG_ID ) );
        endPoint = endPoint.replace( Constants.STAFF_ID, groupDetails.get( Constants.STAFF_ID ) );
        endPoint = endPoint.replace( Constants.COURSE_ID, groupDetails.get( CourseAPIConstants.COURSE_ID ) );
        endPoint = endPoint.replace( Constants.GROUPID, groupDetails.get( CreateGroupAPIConstants.GROUP_ID ) );

        HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
        Log.message( " getGroupAssignmentSettings endPoint" + endPoint );
        Log.message( " getGroupAssignmentSettings response" + response );
        return response;
    }

    public String createGroupforAssignment( String envUrl, HashMap<String, String> groupDetails, List<String> studentRumbaIds ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + groupDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );
        headers.put( Constants.USERID_SM_HEADER, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = CreateGroupAPIConstants.CREATE_GROUP_API_NEW;
        endPoint = endPoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
        endPoint = endPoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
        Log.message( "update custom course by Skill= " + endPoint );

        String groupName = groupDetails.get( CreateGroupAPIConstants.GROUP_NAME );
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createGroupAPIPayload" ) ) );
        if ( studentRumbaIds.size() > 0 ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {

                listString += studentID.concat( "\",\"" );

            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( CreateGroupAPIConstants.STUDENT_RUMBA_IDS ), listString ) );

        } else {
            requestBody.set( JSONUtil.removeProperty( requestBody.get(), CreateGroupAPIConstants.STUDENT_RUMBA_IDS ) );
        }
        requestBody.set( JSONUtil.setProperty( requestBody.get(), CreateGroupAPIConstants.GROUP_NAME, groupName ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), CreateGroupAPIConstants.GROUP_OWNER_ID, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ID ) ) );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) ) );
        Log.message( "create group request - " + requestBody.get() );
        HashMap<String, String> response = RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );
        String groupid = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,groupId" );
        Log.message( "Group id in create group - " + response );
        return groupid;
    }

    /**
     * Verify the response data
     *
     * @param expectedResponse
     * @param actualResponse
     * @param withStudent
     * @return
     * @throws IOException
     */
    public void verifyResponse( Map<String, String> actualResponse, String message, String status ) {

        try {
            Log.message( "statuscode=" + actualResponse.get( Constants.STATUS_CODE ) );
            Log.message( "statuscode1=" + status );
            if ( SMUtils.getKeyValueFromResponse( actualResponse.get( Constants.RESPONSE_BODY ), "messages,message" ).contains( message ) ) {
                Log.pass( CommonAPIConstants.COURSE_DELETE_SUCCESS_MESSAGE );
            } else {
                Log.fail( CommonAPIConstants.COURSE_DELETE_FAILURE_MESSAGE );
            }
            if ( actualResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( status ) ) {
                Log.pass( CommonAPIConstants.COURSE_DELETE_SUCCESS_STATUS );
            } else {
                Log.fail( CommonAPIConstants.COURSE_DELETE_FAILURE_STATUS );
            }

        } catch ( Exception e ) {
            Log.message( "Error in verifyResponse method" );
        }

    }

}