package com.savvas.sm.api.tests.smnew.OrgLevelCourses;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class GetCoursesListAtOrgLevel extends BaseAPITest {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String flexSchoolTeacherDetails = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String token = null;
    //Variable declaration
    String userName = null;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
    }

    @Test ( priority = 1, dataProvider = "positiveScenarioForGetCourseListAtOrgLevel", groups = { "SMK-52068", "Course", "CourseListDashboard", "P1", "API", "smoke_test_case" } )
    public void getCourseListAtOrgLevelPositiveScenarios( String description, String scenario, String statusCode ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );

        switch ( scenario ) {
            case "TC001_Verify the status code is 200 when valid teacher creds are used":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get courses present at Org level
                Map<String, String> apiResponseTc001 = getCoursesAtListingPageOfTeacherUI( flexSchool );
                //Commenting this line cause of heap space issue 
                //Log.pass( "Returned API Response - " + apiResponseTc001.get( Constants.REPORT_BODY ) );

                //Assertion
                Log.softAssertThat( apiResponseTc001.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponseTc001.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponseTc001.get( Constants.STATUS_CODE ) );

                break;

            case "TC009_Verify the status code is 200 when teacher assigned any course to Student":
                List<String> studentRumbaIdsTc001 = new ArrayList<>();

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Adding students to group
                studentRumbaIdsTc001 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, userName, flexSchool );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, "1", flexSchool, studentRumbaIdsTc001.get( 0 ) );

                //Get courses present at Org level
                Map<String, String> apiResponseTc009 = getCoursesAtListingPageOfTeacherUI( flexSchool );
                //Commenting this line cause of heap space issue 
                //Log.pass( "Returned API Response - " + apiResponseTc009.get( Constants.REPORT_BODY ) );

                //Gettting response
                String reponseDataTc009 = SMUtils.getKeyValueFromResponse( apiResponseTc009.get( Constants.REPORT_BODY ), Constants.DATA );

                //Assertion
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc009, "productDescription", "SuccessMaker Default Math" ), "Pass", "Fail" );
                Log.softAssertThat( apiResponseTc009.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponseTc009.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponseTc009.get( Constants.STATUS_CODE ) );
                break;

            case "TC0011_Verify the status code is 200 when we pass assignedCourses=true":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get courses present at teacher UI home page
                HashMap<String, String> apiResponseTc0011 = getCoursesAtDashboardPageOfTeacherUI( flexSchool, "true" );
                //Commenting this line cause of heap space issue 
                //Log.pass( "Returned API Response - " + apiResponseTc0011.get( Constants.REPORT_BODY ) );

                //Gettting response
                String reponseDataTc0011 = SMUtils.getKeyValueFromResponse( apiResponseTc0011.get( Constants.REPORT_BODY ), Constants.DATA );

                //Assertion
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc0011, "productDescription", "SuccessMaker Default Math" ), "Pass", "Fail" );
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc0011, "productDescription", "SuccessMaker Default Reading" ), "Pass", "Fail" );

                Log.softAssertThat( apiResponseTc0011.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponseTc0011.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponseTc0011.get( Constants.STATUS_CODE ) );

                break;

            case "TC0012_Verify the status code is 200 when we pass assignedCourses=false":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get courses present at Org level
                HashMap<String, String> apiResponseTc0012 = getCoursesAtDashboardPageOfTeacherUI( flexSchool, "false" );
                //Commenting this line cause of heap space issue 
                //Log.pass( "Returned API Response - " + apiResponseTc0012.get( Constants.REPORT_BODY ) );

                //Gettting response
                String reponseDataTc0012 = SMUtils.getKeyValueFromResponse( apiResponseTc0012.get( Constants.REPORT_BODY ), Constants.DATA );

                //Assertion
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc0012, "productDescription", "SuccessMaker Default Math" ), "Pass", "Fail" );
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc0012, "productDescription", "SuccessMaker Default Reading" ), "Pass", "Fail" );
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc0012, "productDescription", "SuccessMaker Focus Math" ), "Pass", "Fail" );
                Log.softAssertThat( SMUtils.compareKeyValue( reponseDataTc0012, "productDescription", "SuccessMaker Focus Reading" ), "Pass", "Fail" );

                Log.softAssertThat( apiResponseTc0012.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponseTc0012.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponseTc0012.get( Constants.STATUS_CODE ) );

                break;

        }
    }

    @Test ( priority = 1, dataProvider = "negativeScenarioForGetCourseListAtDashboardLevel", groups = { "SMK-52069", "Course", "CourseListDashboard", "P2", "API" } )
    public void getCourseListAtOrgLevelNegativeScenarios( String description, String scenario, String statusCode ) throws Exception {
        //Test case description
        Log.testCaseInfo( description );
        Map<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> dashboardCourseListDetails = new HashMap<>();

        String exception = null;

        switch ( scenario ) {

            case "TC023_Verify the 403 code for invalid Org id":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get courses present at Org level
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                dashboardCourseListDetails.put( CourseAPIConstants.INVALID_ORG_ID, "ssdd" );
                apiResponse = new CourseAPI().getCoursesAtOrgLevel( smUrl, dashboardCourseListDetails );

                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;

                //Assertion

                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );

                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

            case "TC022_Verify the 401 code for invalid authentication":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get courses present at teacher UI home page
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, "ffff888884556777" );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                apiResponse = new CourseAPI().getCoursesAtOrgLevel( smUrl, dashboardCourseListDetails );

                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

            case "TC025_Verify the 403 code for null parameter of Org id":
                List<String> studentRumbaIdsTc009 = new ArrayList<>();

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Adding students to group
                studentRumbaIdsTc009 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, userName, flexSchool );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, "6", flexSchool, studentRumbaIdsTc009.get( 0 ) );

                //Get courses present at Org level
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, "null" );
                apiResponse = new CourseAPI().getCoursesAtOrgLevel( smUrl, dashboardCourseListDetails );

                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

            case "TC026_Verify the status code 403 When we pass Org id as Integer":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get courses present at teacher UI home page
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, "234661234" );
                apiResponse = new CourseAPI().getCoursesAtOrgLevel( smUrl, dashboardCourseListDetails );

                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

            case "TC027_Verify the status code 403 When we pass Org id as Double":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get courses present at Org level
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, "234.074" );
                apiResponse = new CourseAPI().getCoursesAtOrgLevel( smUrl, dashboardCourseListDetails );

                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;

                //Assertion
                Log.softAssertThat( verifyExceptionMessage( apiResponse.get( "body" ), exception ), "Exception message gatting as expected", "Exception message getting as not expected" );
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

            case "TC028_Verify the 500 code for empty parameter for org id":

                //Creating school based one the licenses
                tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

                //Get courses present at Org level
                dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, "" );
                apiResponse = new CourseAPI().getCoursesAtOrgLevel( smUrl, dashboardCourseListDetails );

                //Assertion       
                Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                        "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );
                break;

        }
    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "positiveScenarioForGetCourseListAtOrgLevel" )
    public Object[][] getCourseListAtDashboardLevelPositiveScenario() {
        Object[][] inputData = { { "TC001_Verify the status code is 200 when valid teacher creds are used", "TC001_Verify the status code is 200 when valid teacher creds are used", "200" },
                { "TC009,TC021_Verify the status code is 200 and in response we are getting assigned courses when teacher assigned any course to Student", "TC009_Verify the status code is 200 when teacher assigned any course to Student", "200" },
                { "TC0011,TC013_Verify the status code is 200 and in response we are getting Dash board courses when we pass assignedCourses=true", "TC0011_Verify the status code is 200 when we pass assignedCourses=true", "200" },
                { "TC0012,TC019_Verify the status code is 200 and in response we are getting Org level courses when we pass assignedCourses=false", "TC0012_Verify the status code is 200 when we pass assignedCourses=false", "200" } };
        return inputData;
    }

    /**
     * Data provider for negative scenarios
     * 
     * @return
     */

    @DataProvider ( name = "negativeScenarioForGetCourseListAtDashboardLevel" )
    public Object[][] getCourseListAtDashboardLevelNegativeScenario() {
        Object[][] inputData = { { "TC023_Verify the 403 code for invalid Org id", "TC023_Verify the 43 code for invalid Org id", "403" },
                { "TC022_Verify the 401 code for invalid authentication", "TC022_Verify the 401 code for invalid authentication", "401" },
                { "TC025_Verify the 403 code for null parameter of Org id", "TC025_Verify the 403 code for null parameter of Org id", "403" },
                { "TC026_Verify the status code 403 When we pass Org id as Integerr", "TC026_Verify the status code 403 When we pass Org id as Integer", "403" },
                { "TC027_Verify the status code 403 When we pass Org id as Double", "TC027_Verify the status code 403 When we pass Org id as Double", "403" },
                { "TC028_Verify the 500 code for empty parameter for org id", "TC028_Verify the 500 code for empty parameter for org id", "500" } };
        return inputData;
    }

    //Token creation
    public void tokenCreation( String school ) {
        try {

            teacherDetails = flexSchoolTeacherDetails;

            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
            userName = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            Log.message( "Issue occured in tokenCreation" );
        }
    }

    //Adding Students to group
    public List<String> addStudentsToGroup( String statusCode, String userName, String school ) {
        HashMap<String, String> response;
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        try {
            //Adding students to group
            String groupName = "Successmaker API Test Group " + System.nanoTime();
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student3" ), "userId" ) );
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, userName );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            response = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );
            Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            Log.message( "Issue occured in addStudentsToGroup" );
        }
        return studentRumbaIds;
    }

    //Assigning assignment to student
    public void addAssignmentsToStudents( String statusCode, String courseId, String school, String studentRumbaId ) {
        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentRumbaId );
        try {
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            assignmentDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            assignmentDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            assignmentDetails.put( CourseAPIConstants.COURSE_ID, courseId );
            HashMap<String, String> assignCourseToTheStudent = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
            if ( assignCourseToTheStudent.get( Constants.STATUS_CODE ).equals( statusCode ) ) {
                Log.message( "Course has been assigned to the student!" );
            } else {
                Log.message( "Something went wrong while assigning the course to the student! - " + assignCourseToTheStudent.get( Constants.REPORT_BODY ) );
            }
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            Log.message( "Issue occured in addAssignmentsToStudents" );
        }
    }

    //Get courses present at CourseListing Page
    public Map<String, String> getCoursesAtListingPageOfTeacherUI( String school ) {
        Map<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> dashboardCourseListDetails = new HashMap<>();
        try {
            dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            apiResponse = new CourseAPI().getCoursesAtOrgLevel( smUrl, dashboardCourseListDetails );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return apiResponse;
    }

    /**
     * Verifying the Exception information
     * 
     * @param actualResponse
     * @param exception
     * @return boolean
     * @throws IOException
     */
    public boolean verifyExceptionMessage( String actualResponse, String exception ) throws IOException {

        boolean flag = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.message( "Exception Verified successfully!" );
            flag = true;
        } else {
            Log.message( "Issue in displaying exception!" );
        }
        return flag;
    }

    //Get courses present at teacher UI home page
    public HashMap<String, String> getCoursesAtDashboardPageOfTeacherUI( String school, String assignedCourses ) {
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> dashboardCourseListDetails = new HashMap<>();
        try {
            dashboardCourseListDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            dashboardCourseListDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            dashboardCourseListDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            apiResponse = new CourseAPI().getCoursesAtDashboardLevel( smUrl, dashboardCourseListDetails, assignedCourses );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return apiResponse;
    }
}