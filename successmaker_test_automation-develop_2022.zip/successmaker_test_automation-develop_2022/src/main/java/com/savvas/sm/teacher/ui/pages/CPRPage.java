package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.HashMap;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class CPRPage extends LoadableComponent<CPRPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    private WebDriver driver;
    boolean isPageLoaded;
    ReportComponent reportComponents;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    
    
    // ********* SuccessMaker CPR Page Elements ***************
    @IFindBy (how = How.CSS, using = "section.page-title div h1" , AI = false)
    public WebElement lblCPRHeader;

    @IFindBy (how = How.CSS, using = "report-options label.date-field-title", AI = false )
    public WebElement lblShowStudentPerformance;

    @FindBy ( css = "report-options label.radio__label" )
    List<WebElement> lblAlldatesAndSelectedDateRange;

    @FindBy ( css = "div.date-field-range div div label" )
    List<WebElement> lblDateHeadings;

    @IFindBy (how = How.CSS, using = "#fromDate", AI = false )
    public WebElement fromDateRoot;

    @IFindBy (how = How.CSS, using = "#toDate", AI = false )
    public WebElement toDateRoot;

    @FindBy ( css = "cel-radio-button[name='date'] div" )
    List<WebElement> lblDates;

    @IFindBy (how = How.CSS, using = ".contextual-help-icon.hydrated", AI = false )
    public WebElement cprPageHelpIcon;

    @IFindBy (how = How.CSS, using = "#mc-main-content > h1", AI = false )
    public WebElement cprHelpPageHeader;

    @FindBy ( css = "label.form-label" )
    List<WebElement> labelHeader;

    // Child elements for shadow root
    String btnDatePicker = "button.date-picker-button";

    String datePickerChild = ".date-picker-input";

    String rbDates = "input[name='date']";

    String errorLabel = "form-error-message span span";

    /**
     * get the report header
     *
     * @return
     */
    public String getReportPageHeader() {
        return lblCPRHeader.getText();
    }

    public CPRPage() {}
    /**
     * Constructor to load driver and components
     *
     * @param driver
     */
    public CPRPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
        PageFactory.initElements(finder, this);
        elementLayer = new ElementLayer(driver);
    }

    /**
     * Verify the page load
     */
    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, lblCPRHeader );
    }

    /**
     * Verifying the page is loaded.
     */
    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( SMUtils.waitForElement( driver, lblCPRHeader ) ) {
            Log.message( "SM Cumulative performance report page loaded successfully." );
        } else {
            Log.fail( "SM Cumulative performance report page did not load." );
        }

    }

    /**
     * Validate "Show Student Performance for" heading in CPR Page
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isShowStudentPerformanceHeadingDisplayed() throws InterruptedException {
        Log.message( "Verifying Show Student Performance Heading!" );
        return lblShowStudentPerformance.getText().equals( Constants.Reports.CPR_SHOW_STUDENT_PERFORMANCE_HEADER );
    }

    /**
     * Validate All Dates fields in CPR Page
     *
     * @param dateHeader
     * @return
     * @throws InterruptedException
     */
    public boolean isAllDatesAndSelectedDateRangeFieldPresent( String dateHeader ) throws InterruptedException {
        Log.message( "Verifying " + dateHeader + " Heading!" );
        for (  WebElement lbldateHeader : lblAlldatesAndSelectedDateRange ) {
            if ( lbldateHeader.getText().trim().equals( dateHeader ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Validate From Date under "show student performance For" in CPR Page
     *
     * @param textBoxName
     * @return
     * @throws InterruptedException
     */
    public boolean isFromDateAndToDateHeaderPresent( String textBoxName ) throws InterruptedException {
        Log.message( "Verifying " + textBoxName + " text box header!" );
        for ( WebElement lblDate : lblDateHeadings ) {
            if ( lblDate.getText().trim().equals( textBoxName ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Validate date picker for from date in CPR Page
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isDatePickerDisplayedForFomDAte() throws InterruptedException {
        Log.message( "Verifying Date picker for From date text box." );
        WebElement datePicker = SMUtils.getWebElement( driver, fromDateRoot, btnDatePicker );
        return SMUtils.isElementPresent( datePicker );
    }

    /**
     * Validate date picker for To date in CPR Page
     *
     * @return
     * @throws InterruptedException
     */
    public boolean isDatePickerDisplayedForToDAte() throws InterruptedException {
        Log.message( "Verifying Date picker for To date text box." );
        WebElement datePicker = SMUtils.getWebElement( driver, toDateRoot, btnDatePicker );
        return SMUtils.isElementPresent( datePicker );
    }

    /**
     * Setting date range for filters
     *
     * @param fromDate
     * @param toDate
     */
    public void setDateRange( String fromDate, String toDate ) {
        SMUtils.getWebElement( driver, fromDateRoot, datePickerChild ).sendKeys( fromDate );
        SMUtils.getWebElement( driver, toDateRoot, datePickerChild ).sendKeys( toDate + Keys.ENTER );
        Log.message( "Date entered in date text boxes. From date - " + fromDate + " To date - " + toDate );
    }

    /**
     * Verify Selected date range field is selected or not
     *
     * @return
     */
    public String getSelectedDateRange() throws InterruptedException {
        String dates = null;
        dates = "From Date : " + SMUtils.getWebElement( driver, fromDateRoot, datePickerChild ).getAttribute( "value" );
        dates = dates + "\n" + "To date : " + SMUtils.getWebElement( driver, toDateRoot, datePickerChild ).getAttribute( "value" );
        Log.message( "got selected date -" + dates );
        return dates;
    }

    /**
     * Selecting the filters for report. (Date filter: allDates/ dateRange)
     *
     * @param dateType
     */
    public void selectShowStudentPerformancefor( String dateType ) {
        if ( dateType.equals( Constants.Reports.CPR_ALL_DATES ) ) {
            for ( WebElement lblDate : lblDates ) {
                if ( lblDate.getText().trim().equals( Constants.Reports.CPR_ALL_DATES ) ) {
                    WebElement rbAllDate = lblDate.findElement( By.cssSelector( rbDates ) );
                    SMUtils.clickJS( driver, rbAllDate );
                    Log.message( "Clicked All Dates radio button!" );
                    break;
                }
            }
        } else if ( dateType.equals( Constants.Reports.CPR_SELECTED_DATE_RANGE ) ) {
            for ( WebElement lblDate : lblDates ) {
                if ( lblDate.getText().trim().equals( Constants.Reports.CPR_SELECTED_DATE_RANGE ) ) {
                    WebElement rbSpecificDate = lblDate.findElement( By.cssSelector( rbDates ) );
                    SMUtils.clickJS( driver, rbSpecificDate );
                    Log.message( "Clicked Specfic Dates radio button!" );
                    break;
                }
            }
        }
    }

    /**
     * Verify All date field is selected or not
     *
     * @return
     */
    public boolean isAllDatesSelected() throws InterruptedException {
        Log.message( "Verifying All Date is selected or not!" );
        boolean isSelected = false;
        for ( WebElement lblDate : lblDates ) {
            if ( lblDate.getText().trim().equals( Constants.Reports.CPR_ALL_DATES ) ) {
                WebElement rbAllDate = lblDate.findElement( By.cssSelector( rbDates ) );
                isSelected = rbAllDate.isSelected();
                break;
            }
        }
        return isSelected;
    }

    /**
     * Verify Selected date range field is selected or not
     *
     * @return
     */
    public boolean isSelectedDateRangeSelected() throws InterruptedException {
        Log.message( "Verifying Selected Date Range is selected or not!" );
        boolean isSelected = false;
        for ( WebElement lblDate : lblDates ) {
            if ( lblDate.getText().trim().equals( Constants.Reports.CPR_SELECTED_DATE_RANGE ) ) {
                WebElement rbSpecificDate = lblDate.findElement( By.cssSelector( rbDates ) );
                isSelected = rbSpecificDate.isSelected();
                break;
            }
        }
        return isSelected;
    }

    /**
     * To get all Selected Filters in CPR Page
     *
     * @param reportComponent
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getAllSelectedFilters( ReportComponent reportComponent ) throws Exception {

        HashMap<String, String> selectedFilters = new HashMap<>();
        if ( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.GROUP_DROPDOWN ) ) {
            selectedFilters.put( Constants.Reports.GROUP_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.GROUP_DROPDOWN ) );
        } else {
            selectedFilters.put( Constants.Reports.STUDENTS_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.STUDENTS_DROPDOWN ) );
        }
        selectedFilters.put( Constants.Reports.SUBJECT_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.SUBJECT_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.ASSIGNMENTS_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.DISPLAY_DROPDOWN, reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.SORT_DROPDOWN, reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ) );

        if ( reportComponent.isRemovePageBreakChecked() )
            selectedFilters.put( Constants.Reports.REMOVE_PAGE_BREAKS, "Checked" );
        else
            selectedFilters.put( Constants.Reports.REMOVE_PAGE_BREAKS, "unchecked" );

        if ( reportComponent.isMaskStudentDisplayChecked() )
            selectedFilters.put( Constants.Reports.MASK_STUDENT_DISPLAY, "Checked" );
        else
            selectedFilters.put( Constants.Reports.MASK_STUDENT_DISPLAY, "unchecked" );

        if ( isAllDatesSelected() )
            selectedFilters.put( Constants.Reports.CPR_ALL_DATES, "Selected" );
        else
            selectedFilters.put( Constants.Reports.CPR_ALL_DATES, "not selected" );

        if ( isSelectedDateRangeSelected() )
            selectedFilters.put( Constants.Reports.CPR_SELECTED_DATE_RANGE, getSelectedDateRange() );
        else
            selectedFilters.put( Constants.Reports.CPR_SELECTED_DATE_RANGE, "not selected" );

        Log.message( "got all selected filters from CPR Page!" );
        return selectedFilters;
    }

    /**
     * returns the WebElement of the CPR Page help Icon
     *
     * @return the WebElement
     */
    public WebElement getCprPageHelpIcon() {
        return cprPageHelpIcon;
    }

    /**
     * return the WebElement of the CPR Help Page
     *
     * @return the WebElement
     */
    public WebElement getCprHelpPageHeader() {
        return cprHelpPageHeader;
    }

    /**
     * @author vikas.pandey
     * @param DateHeader
     * @return
     */
    public String getErrorMessage( String DateHeader ) {
        return labelHeader.stream().filter( element -> element.getText().trim().equalsIgnoreCase( DateHeader ) ).map( element -> {
            WebElement parentElement = element.findElement( By.xpath( "./.." ) );
            Log.message( "Verify error Messsage displaying" );
            return parentElement.findElement( By.cssSelector( errorLabel ) ).getText().trim();
        } ).findFirst().orElse( null );

    }
}
