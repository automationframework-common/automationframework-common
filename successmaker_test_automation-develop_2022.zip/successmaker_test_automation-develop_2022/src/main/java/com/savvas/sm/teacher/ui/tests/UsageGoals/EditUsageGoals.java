package com.savvas.sm.teacher.ui.tests.UsageGoals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EditUsageGoalsPopupPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class EditUsageGoals extends BaseTest {

    private String smUrl;
    private String browser;
    private String username = null;
    private String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String studentLastName;
    private String school;
    private String teacherId;

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

        HashMap<String, String> assignmentDetails = new HashMap<>();

        // Getting teacher details
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        studentLastName = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "lastName" );

        List<String> studentId = new ArrayList();
        studentId.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //assign the assignment
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentId, AssignmentAPIConstants.USERS_TYPE );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
        new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, studentId, AssignmentAPIConstants.USERS_TYPE );

    }

    @Test ( priority = 1, groups = { "SMK-43642", "Goals, EditUsageGoals" } )
    public void tcEditUsageGoals001( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-12489 : Verify the default TARGET HOURS for Maths is 23 hrs" + "<small><b><i>[" + browser + "]</b></i></small>" );
        EditUsageGoalsPopupPage editGoalsPage = null;
        TeacherHomePage tHomePage = null;

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate edit goals
            editGoalsPage = tHomePage.navigateToMathEditGoalsPopup();
            Log.assertThat( editGoalsPage.getDefaultHour().trim().equals( "23" ), "Default Target hour 23 displayed for Math usage Goals", " Default Target hour" + editGoalsPage.getDefaultHour() + " displayed for Math usage Goals " );

            //Moving slider for Math usage goals
            editGoalsPage.moveSlider( "30" );
            editGoalsPage.clickCancelButton();

            SMUtils.logDescriptionTC( "SMK-12490 : Verify the default TARGET HOURS for Reading is 20 hrs" );
            //Navigating to Reading usage goals
            tHomePage.topNavBar.navigateToHomeTab();
            editGoalsPage = tHomePage.navigateToReadingEditGoalsPopup();
            Log.assertThat( editGoalsPage.getDefaultHour().trim().equals( "20" ), "Default Target hour 20 displayed for Reading usage Goals", " Default Target hour" + editGoalsPage.getDefaultHour() + " displayed for Reading usage Goals " );
            editGoalsPage.clickCancelButton();
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 2, groups = { "SMK-43642", "Goals, EditUsageGoals" } )
    public void tcEditUsageGoals002( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "Verify whether the pop-up fields go back to their original state when the teacher clicks on the Reset button for the Usage Goals" + "<small><b><i>[" + browser + "]</b></i></small>" );
        EditUsageGoalsPopupPage editGoalsPage = null;
        TeacherHomePage tHomePage = null;

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate edit goals
            editGoalsPage = tHomePage.navigateToMathEditGoalsPopup();

            //Moving the target hour slider and changing the date
            editGoalsPage.moveSlider( "30" );
            editGoalsPage.clickCalenderIcon();
            editGoalsPage.clickDateFromCalender( "5" );

            SMUtils.logDescriptionTC( "SMK-12469 : Verify whether the pop-up fields go back to their original state when the teacher clicks on the Reset button for the Math Usage Goals" );
            //Clicking reset button
            editGoalsPage.clickResetButton();
            String defaultHour = editGoalsPage.getDefaultHour();

            SMUtils.logDescriptionTC( "SMK-12471 : Verify whether the pop-up gets disappeared when the teacher clicks on the Cancel button for Math Usage Goals" );
            Log.assertThat( defaultHour.trim().equals( "23" ), "Default Target hour 23 displayed after reset for Math usage Goals", " Default Target hour" + editGoalsPage.getDefaultHour() + " displayed for Math usage Goals " );
            editGoalsPage.clickCancelButton();

            //Navigating to reading usage goals
            tHomePage.topNavBar.navigateToHomeTab();
            editGoalsPage = tHomePage.navigateToReadingEditGoalsPopup();

            //Moving the target hour slider and changing the date
            editGoalsPage.moveSlider( "30" );
            editGoalsPage.clickCalenderIcon();
            editGoalsPage.clickDateFromCalender( "5" );

            SMUtils.logDescriptionTC( "SMK-12470 : Verify whether the pop-up fields go back to their original state when the teacher clicks on the Reset button for the Reading Usage Goals" );
            //Clicking reset button
            editGoalsPage.clickResetButton();
            defaultHour = editGoalsPage.getDefaultHour();

            SMUtils.logDescriptionTC( "SMK-12472 : Verify whether the pop-up gets disappeared when the teacher clicks on the Cancel button for Reading Usage Goals" );
            Log.assertThat( defaultHour.trim().equals( "20" ), "Default Target hour 20 displayed after reset for Reading usage Goals", " Default Target hour" + editGoalsPage.getDefaultHour() + " displayed for Reading usage Goals " );
            editGoalsPage.clickCancelButton();
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 3, groups = { "SMK-43642", "Goals, EditUsageGoals" } )
    public void tcEditUsageGoals003( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "Verify whether the teacher is able to move the slider for the TARGET HOURS for Usage Goals" + "<small><b><i>[" + browser + "]</b></i></small>" );
        EditUsageGoalsPopupPage editGoalsPage = null;
        TeacherHomePage tHomePage = null;

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate edit goals
            editGoalsPage = tHomePage.navigateToMathEditGoalsPopup();
            SMUtils.logDescriptionTC( "SMK-12465 : Verify whether the teacher is able to move the slider for the TARGET HOURS for Math Usage Goals" );
            //Moving the slider to low range and high range.
            editGoalsPage.moveSlider( "24" );
            SMUtils.logDescriptionTC( "SMK-12463 : Verify whether the teacher is able to enter the date in the GOAL END DATE for Math Usage Goals" );
            SMUtils.logDescriptionTC( "SMK-12461 : Verify whether the teacher is able to selct the date from the calendar for Reading Usage Goals" );
            //Selecting dates from calendar
            editGoalsPage.clickCalenderIcon();
            editGoalsPage.clickDateFromCalender( "10" );

            //Submitting changes and verifying the change.
            editGoalsPage.clickOKButton();
            SMUtils.nap( 2 ); //Waiting to disappear the toast message
            Log.assertThat( editGoalsPage.getStudentTargetHour( studentLastName ).trim().equals( "24:00" ), "Target hours changed for students", "Target hours not changed for students!" );

            //Selecting single student and editing the goals settings
            editGoalsPage.selectStudentCheckBox( studentLastName );
            editGoalsPage.clickEditButton();

            //Moving the target hours slider
            editGoalsPage.moveSlider( "8" );

            //Selecting different dates
            editGoalsPage.clickCalenderIcon();
            editGoalsPage.clickDateFromCalender( "5" );

            SMUtils.logDescriptionTC( "SMK-12473 : Verify whether the settings gets saved when the teacher clicks on the OK button for Math Usage Goals" );

            //Submitting and verifying the changes.
            editGoalsPage.clickOKButton();
            SMUtils.nap( 2 ); //Waiting to disappear the toast message
            Log.assertThat( editGoalsPage.getStudentTargetHour( studentLastName ).trim().equals( "08:00" ), "Target hours changed for students", "Target hours not changed for students!" );

            //Navigating to Reading usage goals
            tHomePage.topNavBar.navigateToHomeTab();
            editGoalsPage = tHomePage.navigateToReadingEditGoalsPopup();

            SMUtils.logDescriptionTC( "SMK-12466 : Verify whether the teacher is able to move the slider for the TARGET HOURS for Reading Usage Goals" );
            //Moving the slider to low range and high range.
            editGoalsPage.moveSlider( "8" );

            //Selecting dates from calendar
            editGoalsPage.clickCalenderIcon();
            editGoalsPage.clickDateFromCalender( "10" );

            SMUtils.logDescriptionTC( "SMK-12474 : Verify whether the settings gets saved when the teacher clicks on the OK button for Reading Usage Goals" );
            //Submitting changes and verifying the change.
            editGoalsPage.clickOKButton();
            SMUtils.nap( 2 ); //Waiting to disappear the toast message
            Log.assertThat( editGoalsPage.getStudentTargetHour( studentLastName ).trim().equals( "08:00" ), "Target hours changed for students", "Target hours not changed for students!" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
