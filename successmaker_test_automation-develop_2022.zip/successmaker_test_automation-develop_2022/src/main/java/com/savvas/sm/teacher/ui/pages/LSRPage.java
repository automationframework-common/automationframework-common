package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class LSRPage extends LoadableComponent<LSRPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    public  WebDriver driver;
    boolean isPageLoaded;
    ReportComponent reportComponents;
    public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();


    // ********* SuccessMaker LSR Page Elements ***************

    @IFindBy ( how = How.CSS, using = "section.page-title div h1" , AI=false)
    public WebElement lblLSRHeader;

    @IFindBy ( how = How.CSS, using = ".contextual-help-icon.hydrated" , AI=false)
    public WebElement lastSessionPageHelpIcon;

    @IFindBy ( how = How.CSS, using = "#mc-main-content > h1" , AI=false)
    public WebElement lsHelpPageHeader;

    /**
     * get the report header
     *
     * @return
     */
    public String getReportPageHeader() {
        return lblLSRHeader.getText();
    }
    public LSRPage() {}
    /**
     * Constructor to load driver and components
     *
     * @param driver
     */
    public LSRPage( WebDriver driver ) {
        this.driver = driver;
        // Have Top bar here and init
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
    	PageFactory.initElements(finder, this);
    	elementLayer = new ElementLayer(driver);

    }

    /**
     * Verify the page load
     */
    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, lblLSRHeader );
    }

    /**
     * Verifying the page is loaded.
     */
    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( SMUtils.waitForElement( driver, lblLSRHeader ) ) {
            Log.message( "SM Last Session report page loaded successfully." );
        } else {
            Log.fail( "SM Last Session report page did not load." );
        }

    }

    /**
     * To get all Selected Filters in CPR Page
     *
     * @param reportComponent
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getAllSelectedFilters( ReportComponent reportComponent ) throws Exception {

        HashMap<String, String> selectedFilters = new HashMap<>();
        if ( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.GROUP_DROPDOWN ) ) {
            selectedFilters.put( Constants.Reports.GROUP_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.GROUP_DROPDOWN ) );
        } else {
            selectedFilters.put( Constants.Reports.STUDENTS_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.STUDENTS_DROPDOWN ) );
        }
        selectedFilters.put( Constants.Reports.SUBJECT_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.SUBJECT_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.ASSIGNMENTS_DROPDOWN, reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.DISPLAY_DROPDOWN, reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ) );
        selectedFilters.put( Constants.Reports.SORT_DROPDOWN, reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ) );

        if ( reportComponent.isRemovePageBreakChecked() )
            selectedFilters.put( Constants.Reports.REMOVE_PAGE_BREAKS, "Checked" );
        else
            selectedFilters.put( Constants.Reports.REMOVE_PAGE_BREAKS, "unchecked" );

        if ( reportComponent.isMaskStudentDisplayChecked() )
            selectedFilters.put( Constants.Reports.MASK_STUDENT_DISPLAY, "Checked" );
        else
            selectedFilters.put( Constants.Reports.MASK_STUDENT_DISPLAY, "unchecked" );

        Log.message( "got all selected filters from LSR Page!" );
        return selectedFilters;
    }

    /**
     * Returns the Last Session Page Help Icon
     *
     * @return WebElement
     */
    public WebElement getLastSessionPageHelpIcon() {
        return lastSessionPageHelpIcon;
    }

    /**
     * Returns the Header of the Last Session Page Help Page
     *
     * @return WebElement
     */
    public WebElement getLastSessionHeader() {
        return lsHelpPageHeader;
    }

}