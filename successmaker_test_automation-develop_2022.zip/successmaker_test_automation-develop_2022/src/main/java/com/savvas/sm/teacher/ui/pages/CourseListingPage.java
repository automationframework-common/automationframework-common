package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class CourseListingPage extends LoadableComponent<CourseListingPage> {

    private WebDriver driver;

    private boolean isPageLoaded;
    
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();


    private String courseTypeDropDownTriggerCSSSelector = "button.dropdown-trigger";
    private String courseTypeItemsWithShadowCSSSelector = "cel-dropdown-menu-box.hydrated";
    private String allCourseTypesCSSSelector = "ul li";

    private String sortByDropDownTriggerCSSSelector = "button.dropdown-trigger";
    private String sortByItemsWithShadowCSSSelector = "cel-dropdown-menu-box.hydrated";
    private String sortByTypesCSSSelector = "ul li";
    
    // ********* SuccessMaker Launcher/Login Page Elements ***************
//    @IFindBy (how = How.CSS, using = "course-list .course-custom-select-type", AI = false )
//    public WebElement courseSelectDropdown;
    
    @FindBy(css="course-list .course-custom-select-type")
    public WebElement courseSelectDropdown;

    @IFindBy (how = How.CSS, using = "course-list .course-custom-select-order", AI = false )
    public WebElement sortByDropdown;
    
    @IFindBy ( how = How.CSS, using = "div.row:nth-child(2)>div:nth-child(1) span.tile__title", AI = false )
  	public WebElement mathDefaultCourse;	
  	
  	@IFindBy ( how = How.CSS, using = "div.row:nth-child(2)>div:nth-child(2) span.tile__title", AI = false )
  	public WebElement readingDefaultCourse;
  	
  	@FindBy ( css = "div.row:nth-child(2) > div > cel-tile > div > div > span.tile__title" )
	List<WebElement> focusCourses;

    public CourseListingPage() {}
    /**
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     *
     * @param driver
     * @param url
     */
    public CourseListingPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
        PageFactory.initElements(finder, this);
        elementLayer = new ElementLayer(driver);
    }

    @Override
    protected void load() {
        isPageLoaded = true;
    }

    @Override
    protected void isLoaded() throws Error {
        // TODO Auto-generated method stub
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( isPageLoaded && !driver.getCurrentUrl().toLowerCase().contains( "/course" ) && !SMUtils.waitForElement( driver, courseSelectDropdown ) ) {

            Log.fail( "SuccessMakercourse listing page did not open", driver );
        }

    }

    public List<String> getAllCourseTypeDropDownItems() {
        List<String> courseTypeList = new ArrayList<>();
        WebElement courseTypeDropdownTrigger = SMUtils.getWebElement( driver, courseSelectDropdown, courseTypeDropDownTriggerCSSSelector );
        SMUtils.clickJS( driver, courseTypeDropdownTrigger );
        //Nap is required as page takes some time to load
        SMUtils.nap( 1 );
        WebElement courseTypeItemsWithShadow = SMUtils.getWebElement( driver, courseSelectDropdown, courseTypeItemsWithShadowCSSSelector );
        List<WebElement> courseTypeItemElements = SMUtils.getAllWebElements( driver, courseTypeItemsWithShadow, allCourseTypesCSSSelector );
        courseTypeItemElements.stream().forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( courseTypeList::add ) );
        SMUtils.clickJS( driver, courseTypeDropdownTrigger );
        //Nap is required as page takes some time to load
        SMUtils.nap( 1 );

        Log.message( "Fetched all course type items" );
        return courseTypeList;
    }

    public List<String> getAllSortByDropDownItems() {
        List<String> sortByList = new ArrayList<>();
        WebElement sortByDropdownTrigger = SMUtils.getWebElement( driver, sortByDropdown, sortByDropDownTriggerCSSSelector );
        SMUtils.clickJS( driver, sortByDropdownTrigger );
        //Nap is required as page takes some time to load
        SMUtils.nap( 1 );
        WebElement sortByItemsWithShadow = SMUtils.getWebElement( driver, sortByDropdown, sortByItemsWithShadowCSSSelector );
        List<WebElement> sortByItemElements = SMUtils.getAllWebElements( driver, sortByItemsWithShadow, sortByTypesCSSSelector );
        sortByItemElements.stream().forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( sortByList::add ) );
        SMUtils.clickJS( driver, sortByDropdownTrigger );
        //Nap is required as page takes some time to load
        SMUtils.nap( 1 );
        Log.message( "Fetched all sortBy items" );
        return sortByList;
    }

    public void selectCourseTypeFromDropDown( String courseType ) {
    	SMUtils.nap(5);
        WebElement courseTypeDropdownTrigger = SMUtils.getWebElement( driver, courseSelectDropdown, courseTypeDropDownTriggerCSSSelector );
        SMUtils.clickJS( driver, courseTypeDropdownTrigger );
        SMUtils.waitForElement( driver, courseTypeDropdownTrigger, 5 );
        WebElement courseTypeItemsWithShadow = SMUtils.getWebElement( driver, courseSelectDropdown, courseTypeItemsWithShadowCSSSelector );
        List<WebElement> courseTypeItemElements = SMUtils.getAllWebElements( driver, courseTypeItemsWithShadow, allCourseTypesCSSSelector );
        //TODO - Need to handle exception in more graceful manner. Will do it in the next story PR.
        try {
            courseTypeItemElements.forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( filteredValues -> {
                if ( filteredValues.equals( courseType ) ) {
                    SMUtils.waitForElement( driver, element, 5 );
                    SMUtils.clickJS( driver, element );
                }
            } ) );
        } catch ( StaleElementReferenceException | NoSuchElementException e ) {
            Log.message( "Course selected is " + courseType );
        }
    }

    public void selectMyCustomCourseTypeFromDropDown( String courseType ) {
        WebElement courseTypeDropdownTrigger = SMUtils.getWebElement( driver, courseSelectDropdown, courseTypeDropDownTriggerCSSSelector );
        SMUtils.clickJS( driver, courseTypeDropdownTrigger );
        SMUtils.waitForElement( driver, courseTypeDropdownTrigger, 5 );
        WebElement courseTypeItemsWithShadow = SMUtils.getWebElement( driver, courseSelectDropdown, courseTypeItemsWithShadowCSSSelector );
        List<WebElement> courseTypeItemElements = SMUtils.getAllWebElements( driver, courseTypeItemsWithShadow, allCourseTypesCSSSelector );
        //TODO - Need to handle exception in more graceful manner. Will do it in the next story PR.
        try {
            courseTypeItemElements.forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( filteredValues -> {
                if ( filteredValues.equals( courseType ) ) {
                    SMUtils.waitForElement( driver, element, 5 );
                    SMUtils.clickJS( driver, element );
                }
            } ) );
        } catch ( StaleElementReferenceException | NoSuchElementException e ) {
            Log.message( "Course selected is " + courseType, driver, true );
        }
    }

    public void selectsortByDropDown( String sortByType ) {
        WebElement sortByDropdownTrigger = SMUtils.getWebElement( driver, sortByDropdown, sortByDropDownTriggerCSSSelector );
        SMUtils.clickJS( driver, sortByDropdownTrigger );
        SMUtils.waitForElement( driver, sortByDropdownTrigger, 5 );
        WebElement sortByItemsWithShadow = SMUtils.getWebElement( driver, sortByDropdown, sortByItemsWithShadowCSSSelector );
        List<WebElement> sortByItemElements = SMUtils.getAllWebElements( driver, sortByItemsWithShadow, sortByTypesCSSSelector );
        //TODO - Need to handle exception in more graceful manner. Will do it in the next story PR.
        try {
            sortByItemElements.stream().forEach( element -> Optional.ofNullable( element.getText() ).ifPresent( filteredValues -> {
                if ( filteredValues.equals( sortByType ) ) {
                    SMUtils.waitForElement( driver, element, 5 );
                    SMUtils.clickJS( driver, element );
                }
            } ) );
        } catch ( StaleElementReferenceException | NoSuchElementException e ) {
            Log.message( "Course selected is " + sortByType );
        }

    }

    public boolean courseTypeDropDown() {
        WebElement courseTypeDropdownTrigger = SMUtils.getWebElement( driver, courseSelectDropdown, courseTypeDropDownTriggerCSSSelector );
        return courseTypeDropdownTrigger.isEnabled();
    }

    public boolean sortByDropDown() {
        WebElement sortByDropdownTrigger = SMUtils.getWebElement( driver, sortByDropdown, sortByDropDownTriggerCSSSelector );
        return sortByDropdownTrigger.isEnabled();
    }
    
    /**
   	 * To get the list of focus courses
   	 *
   	 */
   	public List<String> getFocusCourses() {	
   		List<String> focusCoursesList = new ArrayList<>();
   		focusCourses.forEach(element -> {focusCoursesList.add(element.getText().trim());
   		});
   		return focusCoursesList;
   	}

}
