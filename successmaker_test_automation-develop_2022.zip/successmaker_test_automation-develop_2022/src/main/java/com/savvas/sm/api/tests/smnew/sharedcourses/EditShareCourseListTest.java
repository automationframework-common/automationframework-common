package com.savvas.sm.api.tests.smnew.sharedcourses;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

public class EditShareCourseListTest extends EnvProperties {

    private String smUrl;
    public RBSUtils rbsUtils = new RBSUtils();
    private String username;
    private String subDistrictUsername;
    private String subDistrictOrgId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String orgId;
    private String userId;
    private String subDistrictUserId;
    private String accessToken;
    private Map<String, String> response;
    HashMap<String, String> params = new HashMap<String, String>();
    UserSqlHelper userSqlHelper = new UserSqlHelper();
    private String mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    Map<String, String> sharedCourseResponse;
    private String schoolId;
    private String courseId;
    private String teacherUserId;
    private String teacherAccessToken;
    private String courseName;
    private String teacherUsername;
    private String adminAccessToken;
    private String customCourse;
    SharedCourses sharedCourse = new SharedCourses();

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {

        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        orgId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );

        // Getting district admin user data to login
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        accessToken = rbsUtils.getAccessToken( username, password );

        // Getting sub-district admin details in RBS Datasetup
        String subDistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        subDistrictUsername = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        subDistrictUserId = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERID );
        subDistrictOrgId = RBSDataSetup.subDistrictwithSchoolId;
        adminAccessToken = rbsUtils.getAccessToken( subDistrictUsername, password );

        // Teacher details
        String teacherDetails = RBSDataSetup.getMyTeacher( mathSchool );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        Log.message( teacherUsername );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        // Creating share course
        courseName = "Custom by Setting_" + System.nanoTime();
        schoolId = RBSDataSetup.organizationIDs.get( mathSchool );
        teacherAccessToken = rbsUtils.getAccessToken( teacherUsername, password );
        courseId = sharedCourse.createCustomCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserId, schoolId, DataSetupConstants.SETTINGS, courseName );
        Log.message( courseId );
    }

    @Test ( dataProvider = "getData", groups = { "smoke_test_case", "SMK-51787", "Edit Share Course", "API" }, priority = 1 )
    public void editShareCourse( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {

        HashMap<String, String> headers = new HashMap<String, String>();

        // Headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( AdminAPIConstants.ORGID, orgId );
        headers.put( AdminAPIConstants.USERID, userId );
        headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );

        // End point for API
        // Request body
        String[] mathSchoolId = { RBSDataSetup.organizationIDs.get( mathSchool ) };
        Log.testCaseInfo( testcaseName + testcaseDescription );

        switch ( scenarioType ) {

            case "PASSING ONE ORGANIZATION ID":
                String[] singleOrgID = { RBSDataSetup.organizationIDs.get( mathSchool ) };
                response = sharedCourse.editShareCourseList( smUrl, headers, singleOrgID, courseId, "" );
                // Validation
                sharedCourseResponse = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                Log.assertThat( verifySharedOrgCount( sharedCourseResponse.get( Constants.REPORT_BODY ), courseId, "1" ), "Course is shared to the organization", "Course is shared to the organization" );
                break;

            case "PASSING MULTIPLE ORGANIZATION ID":
                String[] orgs = { RBSDataSetup.organizationIDs.get( mathSchool ), RBSDataSetup.organizationIDs.get( flexSchool ) };
                response = sharedCourse.editShareCourseList( smUrl, headers, orgs, courseId, "" );
                // Validation
                sharedCourseResponse = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                Log.assertThat( verifySharedOrgCount( sharedCourseResponse.get( Constants.REPORT_BODY ), courseId, "2" ), "Course is shared to the organizations", "Course is not shared to the organizations" );
                break;

            case "PASSING SHARED AND UNSHARED ORGANIZATION IDS":
                String[] multiOrgs = { RBSDataSetup.organizationIDs.get( mathSchool ), RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetup.organizationIDs.get( flexSchool ) };
                response = sharedCourse.editShareCourseList( smUrl, headers, multiOrgs, courseId, "" );

                // Validation
                sharedCourseResponse = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                Log.assertThat( verifySharedOrgCount( sharedCourseResponse.get( Constants.REPORT_BODY ), courseId, "3" ), "Course is shared to the organizations", "Course is not shared to the organizations" );
                break;

            case "INVALID FOR TEACHER USER":
                // Headers
                headers.put( AdminAPIConstants.ORGID, schoolId );
                headers.put( AdminAPIConstants.USERID, teacherUserId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + teacherAccessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "INVALID FOR STUDENT USER":
                String studentDetails = RBSDataSetup.getMyStudent( mathSchool, teacherUsername );
                String studentUserName = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
                String studentAccessToken = rbsUtils.getAccessToken( studentUserName, password );

                // Headers
                headers.put( AdminAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( schoolId ) );
                headers.put( AdminAPIConstants.USERID, SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + studentAccessToken );

                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "INVALID SSO TOKEN GIVEN":
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken + "INVALID" );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "INVALID USER ID":
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId + "Invalid" );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "EMPTY USER ID":
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, "" );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "INVALID ORG ID":
                headers.put( AdminAPIConstants.ORGID, orgId + "Invalid" );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "EMPTY ORG ID":
                headers.put( AdminAPIConstants.ORGID, "" );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "EMPTY COURSE ID":
                headers.put( AdminAPIConstants.ORGID, subDistrictOrgId );
                headers.put( AdminAPIConstants.USERID, subDistrictUserId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + adminAccessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, "", "" );
                Log.message( response + "" );
                break;

            case "ORG ID UNDER SUBDISTRICT":

                headers.put( AdminAPIConstants.ORGID, subDistrictOrgId );
                headers.put( AdminAPIConstants.USERID, subDistrictUserId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + adminAccessToken );
                String[] orgUnderSubDistrict = { RBSDataSetup.schoolUnderSubDistrict_SchoolId };
                response = sharedCourse.editShareCourseList( smUrl, headers, orgUnderSubDistrict, courseId, "" );
                // Validation
                sharedCourseResponse = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                Log.assertThat( verifySharedOrgCount( sharedCourseResponse.get( Constants.REPORT_BODY ), courseId, "1" ), "Course is shared to the organizations", "Course is not shared to the organizations" );
                break;

            case "ORG ID NOT PART OF SUBDISTRICT":

                headers.put( AdminAPIConstants.ORGID, subDistrictOrgId );
                headers.put( AdminAPIConstants.USERID, subDistrictUserId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + adminAccessToken );

                String[] orgNotPartOfSubDisntrict = { RBSDataSetup.organizationIDs.get( mathSchool ) };
                response = sharedCourse.editShareCourseList( smUrl, headers, orgNotPartOfSubDisntrict, courseId, "" );
                // Validation
                sharedCourseResponse = sharedCourse.getSharedCourseList( smUrl, headers, "" );
                Log.message( sharedCourseResponse + "" );
                break;

            case "SAVVAS ADMIN":

                String courseName = "Custom by Setting_" + System.nanoTime();
                String schoolId = RBSDataSetup.organizationIDs.get( mathSchool );
                String teacherAccessToken = rbsUtils.getAccessToken( teacherUsername, password );
                String courseId = sharedCourse.createCustomCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserId, schoolId, DataSetupConstants.SETTINGS, courseName );
                Log.message( courseId );
                String[] sharedOrg = { schoolId, RBSDataSetup.schoolUnderSubDistrict_SchoolId };

                String savvasAdminDetail = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
                String savvasAdminUsername = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
                String savvasAdminUserId = SMUtils.getKeyValueFromResponse( savvasAdminDetail, RBSDataSetupConstants.USERID );
                String savvasAdminorgId = SMUtils.getKeyValueFromResponse( savvasAdminDetail, "primaryOrgId" );

                headers.put( AdminAPIConstants.ORGID, savvasAdminorgId );
                headers.put( AdminAPIConstants.USERID, savvasAdminUserId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( savvasAdminUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = sharedCourse.editShareCourseList( smUrl, headers, sharedOrg, courseId, orgId );
                // Validation
                sharedCourseResponse = sharedCourse.getSharedCourseList( smUrl, headers, orgId );
                Log.message( sharedCourseResponse + "" );
                Log.assertThat( verifySharedOrgCount( sharedCourseResponse.get( Constants.REPORT_BODY ), courseId, "2" ), "Course is shared to the organization", "Course is shared to the organization" );

                break;

        }
        // Validation
        Log.message( response + "" );
        Log.message( response.get( Constants.STATUS_CODE ) );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " is not Verified" );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "editSharedCourse", statusCode, response.get( Constants.RESPONSE_BODY ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @Test ( dataProvider = "getNegativeScenarioData", groups = { "SMK-51787", "Edit Share Course", "API" }, priority = 1 )
    public void editShareCourseNegativeScenarios( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {

        HashMap<String, String> headers = new HashMap<String, String>();

        // Headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( AdminAPIConstants.ORGID, orgId );
        headers.put( AdminAPIConstants.USERID, userId );
        headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );

        // End point for API
        // Request body
        String[] mathSchoolId = { RBSDataSetup.organizationIDs.get( mathSchool ) };
        Log.testCaseInfo( testcaseName + testcaseDescription );

        switch ( scenarioType ) {

            case "INVALID FOR TEACHER USER":
                // Headers
                headers.put( AdminAPIConstants.ORGID, schoolId );
                headers.put( AdminAPIConstants.USERID, teacherUserId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + teacherAccessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "INVALID FOR STUDENT USER":
                String studentDetails = RBSDataSetup.getMyStudent( mathSchool, teacherUsername );
                String studentUserName = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
                String studentAccessToken = rbsUtils.getAccessToken( studentUserName, password );

                // Headers
                headers.put( AdminAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( schoolId ) );
                headers.put( AdminAPIConstants.USERID, SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + studentAccessToken );

                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "INVALID SSO TOKEN GIVEN":
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken + "INVALID" );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "INVALID USER ID":
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId + "Invalid" );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "EMPTY USER ID":
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, "" );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "INVALID ORG ID":
                headers.put( AdminAPIConstants.ORGID, orgId + "Invalid" );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "EMPTY ORG ID":
                headers.put( AdminAPIConstants.ORGID, "" );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, courseId, "" );
                break;

            case "EMPTY COURSE ID":
                headers.put( AdminAPIConstants.ORGID, subDistrictOrgId );
                headers.put( AdminAPIConstants.USERID, subDistrictUserId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + adminAccessToken );
                response = sharedCourse.editShareCourseList( smUrl, headers, mathSchoolId, "", "" );
                Log.message( response + "" );
                break;

        }
        // Validation
        Log.message( response + "" );
        Log.message( response.get( Constants.STATUS_CODE ) );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " is not Verified" );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "editSharedCourse", statusCode, response.get( Constants.RESPONSE_BODY ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
        Log.testCaseResult();
        Log.endTestCase();
    }

    /**
     * To Verify the shared org count for given courseId
     *
     * @param responseBody
     * @param courseId
     * @param expectedOrgCount
     * @return
     */
    public boolean verifySharedOrgCount( String responseBody, String courseId, String expectedOrgCount ) {
        return IntStream.rangeClosed( 1, SMUtils.getWordCount( responseBody, AdminAPIConstants.COURSE_NAME ) ).filter( iter -> SMUtils.getKeyValueFromJsonArray( responseBody, AdminAPIConstants.ID, iter ).equals( courseId ) ).anyMatch(
                orgCount -> SMUtils.getKeyValueFromJsonArray( responseBody, AdminAPIConstants.SHARED_ORG_COUNT, orgCount ).equals( expectedOrgCount ) );
    }

    /**
     * To get headers from user details
     * 
     * @param userreqDetails
     * @return
     */
    public Map<String, String> getHeaders( HashMap<String, String> userreqDetails ) {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userreqDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        headers.put( Constants.USERID_SM_HEADER, userreqDetails.get( AdminAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, userreqDetails.get( AdminAPIConstants.ORG_ID ) );
        return headers;
    }

    /**
     * To assign an assignment to a user(s) or groups(s)
     *
     * @param envUrl
     * @param assignmentDetails
     * @param studentRumbaIds
     * @param type
     * @return
     * @throws Exception
     */
    public HashMap<String, String> assignMultipleAssignments( String envUrl, HashMap<String, String> assignmentDetails, List<String> studentRumbaIds, List<String> courseIDs ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AdminAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AdminAPIConstants.TEACHER_ID ); //Parameters
        HashMap<String, String> params = new HashMap<>(); // Input Path Parameters
        String endPoint = AdminAPIConstants.ASSIGN_MULTIPLE_ASSIGNMENTS_API;
        String payload = "{\n\"ids\": [\"{studentRumbaIds}\"],\n\"contentBaseIds\":[\"{courseIds}\"],\n\"type\":\"users\"\n}";
        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( payload );
        if ( !studentRumbaIds.isEmpty() && !courseIDs.isEmpty() ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {
                listString += studentID.concat( "\",\"" );
            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AdminAPIConstants.STUDENT_RUMBA_IDS ), listString ) );
            listString = "";
            for ( String courseID : courseIDs ) {
                listString += courseID.concat( "\",\"" );
            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AdminAPIConstants.COURSE_IDS ), listString ) );
        } else {
            Log.fail( "Student / Course ID missing" );
        }
        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID );
        return RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );
    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "getData" )
    public Object[][] getData() {
        return new Object[][] { { "tcEditShareCourse002: ", "200", "Verify the 200 status code if pass any one orgId in the organization array", "PASSING ONE ORGANIZATION ID" },
                { "tcEditShareCourse003: ", "200", "Verify the 200 status code if pass all the orgIds(which are present under the district) in the organization array", "PASSING MULTIPLE ORGANIZATION ID" },
                { "tcEditShareCourse004: ", "200", "Verify the response if pass the some already shared organizationIds and some new organization Ids", "PASSING SHARED AND UNSHARED ORGANIZATION IDS" },
                { "tcEditShareCourse014: ", "200", "Verify the status code if pass the subdistrict admin credentials and the organizationId as school id which is present under subdistrict", "ORG ID UNDER SUBDISTRICT" },
                { "tcEditShareCourse015: ", "200", "Verify the response if pass the subdistrict admin credentials and the organizationId as school id which is not part of the subdistrict", "ORG ID NOT PART OF SUBDISTRICT" },
                { "tcEditShareCourse016: ", "200", "Verify the 200 status code if pass any one orgId in the organization array and passed savvas admin details in header request", "SAVVAS ADMIN" }, };
    }

    /**
     * Data provider to provide the negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "getNegativeScenarioData" )
    public Object[][] getNegativeScenarioData() {
        return new Object[][] { { "tcEditShareCourse005: ", "403", "Verify the status code is 403 for incorrect authorization for invalids roles(Give teacher authorization)", "INVALID FOR TEACHER USER" },
                { "tcEditShareCourse006: ", "403", "Verify the status code is 403 for incorrect authorization for invalids roles(Give student authorization)", "INVALID FOR STUDENT USER" },
                { "tcEditShareCourse007: ", "401", "Verify the status code is 401 if pass the invalid Bearer token", "INVALID SSO TOKEN GIVEN" },
                { "tcEditShareCourse008: ", "401", "Verify the status code is 401 if pass the invalid user Id", "INVALID USER ID" }, { "tcEditShareCourse009: ", "401", "Verify the status code is 401 if pass the empty user Id", "EMPTY USER ID" },
                { "tcEditShareCourse010: ", "403", "Verify the status code is 403 if pass the invalid org Id", "INVALID ORG ID" }, { "tcEditShareCourse011: ", "403", "Verify the status code is 403 if pass the empty org Id", "EMPTY ORG ID" },
                { "tcEditShareCourse012: ", "400", "Verify the status code is 400 if pass Invalid Course Id in request body", "EMPTY COURSE ID" } };
    }

}