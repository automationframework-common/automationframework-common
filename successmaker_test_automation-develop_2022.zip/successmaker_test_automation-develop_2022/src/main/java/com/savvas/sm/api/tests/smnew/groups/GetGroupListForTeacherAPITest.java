package com.savvas.sm.api.tests.smnew.groups;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.GetGroupListAPI;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.ReturnStudentListAPI;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

/**
 * This class is used to test the group listing API for given Teacher ID
 * 
 * @author Praveen Kumar
 *
 */
public class GetGroupListForTeacherAPITest extends GroupAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String teacherDetails1 = null;
    private String teacherDetails2 = null;
    private String studentDetail = null;
    private String studentDetail2 = null;
    private String studentUsername = null;
    private String studentUserID = null;
    public Boolean result = null;

    //private String teacherDetails3 = null;
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String school1 = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    RBSUtils rbs = new RBSUtils();
    public String userId;
    public String userId1;
    public String userId2;
    public String orgId;
    public String orgId2;
    // public String orgId1;
    public String username;
    public String mathOnlyProduct;
    public String readingOnlyProduct;
    //public String courseID;
    public String studentID1;
    public String studentID2;
    public String classId1;
    public String classId2;
    public String class1;
    public String class2;
    public HashMap<String, String> assignmentDetails = new HashMap<>();
    public String createTeacher;
    public String multipleSchoolTeacherID;
    public String multipleSchoolTeacherName;
    BaseAPITest baseapi = new BaseAPITest();
    HashMap<String, String> assignCourseToTheStudent = new HashMap<String, String>();
    public static String fName;
    public static String mName;
    public static String lName;
    public static String studId;
    public static String uName;
    public static String duplicateClassId;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        mathOnlyProduct = configProperty.getProperty( "mathOnlyProduct" );
        readingOnlyProduct = configProperty.getProperty( "readingOnlyProduct" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherDetails1 = RBSDataSetup.getMyTeacher( school );
        teacherDetails2 = RBSDataSetup.getMyTeacher( school1 );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USER_NAME );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        userId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        userId1 = SMUtils.getKeyValueFromResponse( teacherDetails1, Constants.USERID_HEADER );
        userId2 = SMUtils.getKeyValueFromResponse( teacherDetails2, Constants.USERID_HEADER );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );
        orgId = RBSDataSetup.organizationIDs.get( school );
        orgId2 = RBSDataSetup.organizationIDs.get( school1 );

        HashMap<String, String> userDetails = new HashMap<String, String>();
        List<String> schools = new ArrayList<String>();

        String multiSchoolTeacher = "MultiSchTeacher" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

        schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
        schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
        String listString = "";
        for ( String school : schools ) {
            listString += school.concat( "\",\"" );
        }
        listString = listString.substring( 0, listString.length() - 3 );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
        String createUser = rbs.createUser( userDetails );

        multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERID );
        multipleSchoolTeacherName = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERNAME );
        new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

    }

    @Test ( dataProvider = "GroupListingData", groups = { "SMK-50199", "Group", "Get Group List for TeacherID", "P1", "API" } )
    public void tcgetGroupListTest01( String description, String scenario, String statusCode ) throws Exception {
        String groupName = "Successmaker API Test Group " + System.nanoTime();
        HashMap<String, String> userDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> apiDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        HashMap<String, String> response;
        String accessToken;
        String errorMessage = null;
        String exceptionMessage = null;

        switch ( scenario ) {

            case "TEACHER_HAVE_NO_GROUPS":
                Log.message( "Verify the API returning data not found exception when the teacher don't have any groups." );
                accessToken = rbs.getAccessToken( multipleSchoolTeacherName, password );
                errorMessage = CommonAPIConstants.GROUP_LIST_DATA_NOT_FOUND_EXCEPTION_MESSAGE;
                exceptionMessage = ReturnStudentListAPI.DATA_NOT_FOUND_EXCEPTION;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, multipleSchoolTeacherID );
                break;

            case "GROUPS_WITHOUT_SUCCESSMAKER_PRODUCT":
                Log.message( "Verify the API returning 200 data not found exception when the SM product not associated with class in EB." );
                Log.message( "Verify the Response when there is No Data (The teacher should have classes but should not add product  for the  class)" );
                String className = "Customize Group without product" + System.currentTimeMillis();
                List<String> teachers1 = new ArrayList<String>();
                teachers1.add( multipleSchoolTeacherID );
                List<String> stuIDs1 = new ArrayList<String>();
                stuIDs1.add( SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER ) );
                HashMap<String, String> classDetails1 = new HashMap<>();
                classDetails1.put( RBSDataSetupConstants.USERNAME, multipleSchoolTeacherName );
                classDetails1.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                classDetails1.put( RBSDataSetupConstants.STUDENT_PI_ID, SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER ) );
                classDetails1.put( RBSDataSetupConstants.SECTION_NAME, className );
                // Creating Class without Successmaker Product
                class1 = rbs.createClassWithMultipleTeacher( classDetails1, teachers1, stuIDs1 );
                accessToken = rbs.getAccessToken( multipleSchoolTeacherName, password );
                errorMessage = CommonAPIConstants.GROUP_LIST_DATA_NOT_FOUND_EXCEPTION_MESSAGE;
                exceptionMessage = ReturnStudentListAPI.DATA_NOT_FOUND_EXCEPTION;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, multipleSchoolTeacherID );
                apiDetails.put( GetGroupListAPI.INVALID_TEACHER, multipleSchoolTeacherID );
                break;

            case "DELETED_CLASS":

                Log.message( "Verify the API retuning data not found exception when the class is deleted from Easybridge." );
                JSONObject jsonnObject4 = new JSONObject( class1 );
                String classId = jsonnObject4.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();
                accessToken = rbs.getAccessToken( multipleSchoolTeacherName, password );
                String adminToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                rbs.addProductToClassGraphQL( orgId, classId, mathOnlyProduct, adminToken, multipleSchoolTeacherID );
                rbs.deleteClass( classId, accessToken, multipleSchoolTeacherID );
                errorMessage = CommonAPIConstants.GROUP_LIST_DATA_NOT_FOUND_EXCEPTION_MESSAGE;
                exceptionMessage = ReturnStudentListAPI.DATA_NOT_FOUND_EXCEPTION;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, multipleSchoolTeacherID );
                break;

            case "INVALID_TEACHER_ID":

                Log.message( "Verify the API returning exception when the teacher ID is invalid." );
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                errorMessage = CommonAPIConstants.GROUP_LIST_INVALID_STUDENT_EXCEPTION_MESSAGE;
                exceptionMessage = CommonAPIConstants.BAD_REQUEST_EXCEPTION;
                apiDetails.put( GetGroupListAPI.INVALID_TEACHER, userId + 1 );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, userId );
                break;

            case "INVALID_ORGANIZATION_ID":

                Log.message( "Verify the API returning exception when the organization ID is invalid." );
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                errorMessage = CommonAPIConstants.GROUP_LIST_DATA_NOT_FOUND_EXCEPTION_MESSAGE;
                exceptionMessage = ReturnStudentListAPI.DATA_NOT_FOUND_EXCEPTION;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, userId );
                apiDetails.put( GroupConstants.INVALID_ORG, orgId + 1 );
                break;

            case "OTHER_TEACHER_ORG_ID":

                Log.message( "Verify the API returning exception when the teacher not belongs to given organization." );
                Log.message( "Verify the API returning data not found exception when the teacher organization id changed. " );
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                errorMessage = CommonAPIConstants.GROUP_LIST_DATA_NOT_FOUND_EXCEPTION_MESSAGE;
                exceptionMessage = ReturnStudentListAPI.DATA_NOT_FOUND_EXCEPTION;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, userId );
                apiDetails.put( GroupConstants.INVALID_ORG, orgId2 );
                break;

            case "INVALID_AUTHORIZATION":

                Log.message( "Verify the API returning authentication exception when the authentication is invalid." );
                accessToken = GetGroupListAPI.INVALID_ACCESS_TOKEN;
                errorMessage = ReturnStudentListAPI.AUTHENTICATION_FAILED_MESSAGE;
                exceptionMessage = ReturnStudentListAPI.EXCEPTION_MESSAGE;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken + 1 );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, userId );
                break;

            case "STUDENT_AUTHORIZATION":

                Log.message( "Verify the API returning access exception when the API using student authentication." );
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ), password );
                errorMessage = ReturnStudentListAPI.ACCESS_DENIED_MESSAGE;
                exceptionMessage = ReturnStudentListAPI.ACCESS_DENIED_EXCEPTION;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID ) );
                apiDetails.put( GetGroupListAPI.INVALID_TEACHER, userId );
                break;

            case "OTHER_TEACH_AUTH":

                Log.message( "Verify the API returning access exception when the API using student authentication." );
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ), password );
                errorMessage = ReturnStudentListAPI.AUTHENTICATION_FAILED_MESSAGE;
                exceptionMessage = ReturnStudentListAPI.EXCEPTION_MESSAGE;
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, userId );
                apiDetails.put( GetGroupListAPI.INVALID_TEACHER, userId );
                break;

        }
        // Validation
        response = getGroupListingForTeacherID( smUrl, apiDetails );
        Log.assertThat( validateErrorANDExceptionMessage( response, errorMessage, exceptionMessage, statusCode ), "Proper Error and Exception Message Displayed", "No proper Error Message" );
    }

    public Boolean validateErrorANDExceptionMessage( HashMap<String, String> response, String errorMessage, String exceptionMessage, String statusCode ) {
        Boolean status = false;
        JSONObject jsonObject = new JSONObject( response.get( Constants.REPORT_BODY ) );
        JSONArray array4 = jsonObject.getJSONArray( Constants.REPORT_MESSAGES );
        String exception = array4.getJSONObject( 0 ).get( Constants.EXCEPTION ).toString();
        String message = array4.getJSONObject( 0 ).get( Constants.REPORT_MESSAGE_VALUE ).toString();
        if ( exception.equals( exceptionMessage ) && message.equals( errorMessage ) && response.get( Constants.STATUS_CODE ).equals( statusCode ) ) {
            status = true;
        }
        return status;
    }

    /**
     * Data provider for Negative scenarios
     * 
     * @return
     */

    @DataProvider ( name = "GroupListingData" )
    public Object[][] getGroupList() {

        Object[][] inputData = { { "Verify the API returning data not found exception when the teacher don't have any groups.", "TEACHER_HAVE_NO_GROUPS", "200" },
                { "Verify the API returning 200 data not found exception when the SM product not associated with class in EB.", "GROUPS_WITHOUT_SUCCESSMAKER_PRODUCT", "200" },
                { "Verify the Response when there is No Data (The teacher should have classes but should not add product for the class)", "GROUPS_WITHOUT_SUCCESSMAKER_PRODUCT", "200" },
                { "Verify the API retuning data not found exception when the class is deleted from Easybridge.", "DELETED_CLASS", "200" }, { "Verify the API returning exception when the teacher ID is invalid.", "INVALID_TEACHER_ID", "400" },
                { "Verify the API returning exception when the organization ID is invalid.", "INVALID_ORGANIZATION_ID", "200" }, { "Verify the API returning exception when the teacher not belongs to given organization.", "OTHER_TEACHER_ORG_ID", "200" },
                { "Verify the API returning data not found exception when the teacher organization id changed.", "OTHER_TEACHER_ORG_ID", "200" },
                { "Verify the API returning authentication exception when the authentication is invalid", "INVALID_AUTHORIZATION", "401" },
                { "Verify the API returning authentication exception when the authentication is invalid", "STUDENT_AUTHORIZATION", "403" },
                { "Verify the API returning authentication exception when the authentication is invalid", "OTHER_TEACH_AUTH", "401" } };
        return inputData;
    }

    @Test ( dataProvider = "Valid", groups = { "smoke_test_case", "Smoke TC002_GetGroupListForTeacherID", "Get Group List for TeacherID", "P1", "SMK-50199", "Group", "Get Group List for TeacherID", "P1", "API" } )
    public void tcgetGroupListTest02( String description, String scenario, String statusCode ) throws Exception {
        Log.message( description );
        HashMap<String, String> response;
        String classId = null;
        List<String> teachers1 = new ArrayList<String>();
        List<String> stuIDs = new ArrayList<String>();
        List<String> schools = new ArrayList<>();
        HashMap<String, String> apiDetails = new HashMap<>();
        HashMap<String, String> userDetails = new HashMap<>();
        HashMap<String, String> classDetails1 = new HashMap<>();
        String accessToken = null;
        JSONObject jsonObject = null;
        //String className = null;
        String adminToken = null;
        String multipleSchoolTeacherID = null;

        switch ( scenario ) {

            case "HAPPY_PATH":
                // = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                String className = "Customize Group without product" + System.currentTimeMillis();
                teachers1.add( userId );
                stuIDs.add( studentUserID );
                classDetails1.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
                classDetails1.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                classDetails1.put( RBSDataSetupConstants.STUDENT_PI_ID, studentUserID );
                classDetails1.put( RBSDataSetupConstants.SECTION_NAME, className );
                String classes = rbs.createClassWithMultipleTeacher( classDetails1, teachers1, stuIDs );
                jsonObject = new JSONObject( classes );
                classId = jsonObject.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();
                //adminToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                rbs.addProductToClassGraphQL( orgId, classId, mathOnlyProduct,
                        rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ),
                        SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                //accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, userId );
                response = getGroupListingForTeacherID( smUrl, apiDetails );
                Log.assertThat( validateActualAPIValuesWithCMS( response, apiDetails.get( GroupConstants.STAFF_ID ) ), "Actual Values are validated with the CMS value", "Not Matched with the CMS value" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getGroupListForTeacherID", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                rbs.deleteClass( classId, accessToken, apiDetails.get( GroupConstants.STAFF_ID ) );
                break;

            case "SHARED_GROUP":

                //accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                String className1 = "Customize Group without product" + System.currentTimeMillis();
                teachers1.add( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                teachers1.add( SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERID ) );
                stuIDs.add( studentUserID );
                classDetails1.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
                classDetails1.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                classDetails1.put( RBSDataSetupConstants.STUDENT_PI_ID, studentUserID );
                classDetails1.put( RBSDataSetupConstants.SECTION_NAME, className1 );
                class1 = rbs.createClassWithMultipleTeacher( classDetails1, teachers1, stuIDs );
                jsonObject = new JSONObject( class1 );
                classId = jsonObject.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();
                //adminToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                rbs.addProductToClassGraphQL( orgId, classId, mathOnlyProduct,
                        rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ),
                        SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                //accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, userId );
                response = getGroupListingForTeacherID( smUrl, apiDetails );
                Log.assertThat( validateActualAPIValuesWithCMS( response, apiDetails.get( GroupConstants.STAFF_ID ) ), "Actual Values are validated with the CMS value", "Not Matched with the CMS value" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getGroupListForTeacherID", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                rbs.deleteClass( classId, accessToken, apiDetails.get( GroupConstants.STAFF_ID ) );
                break;

            case "TEACHER_WITH_SHARED_STUDENTS":

                Log.message( "Verify the group details returned in API when the group has shared students." );
                Log.message( "Verify the group details returned in API when the group has multiple students." );
                Log.message( "Verify the student count displaying according to the student count." );

                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                String className2 = "Customize Group without product" + System.currentTimeMillis();
                teachers1.add( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                stuIDs.add( studentUserID );
                classDetails1.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
                classDetails1.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                classDetails1.put( RBSDataSetupConstants.STUDENT_PI_ID, studentUserID );
                classDetails1.put( RBSDataSetupConstants.SECTION_NAME, className2 );
                class1 = rbs.createClassWithMultipleTeacher( classDetails1, teachers1, stuIDs );

                String className3 = "Customize Group without product" + System.currentTimeMillis();
                classDetails1.put( RBSDataSetupConstants.SECTION_NAME, className3 );
                classDetails1.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERNAME ) );

                class1 = rbs.createClassWithMultipleTeacher( classDetails1, teachers1, stuIDs );
                jsonObject = new JSONObject( class1 );
                classId = jsonObject.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();
                adminToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                rbs.addProductToClassGraphQL( orgId, classId, mathOnlyProduct,
                        rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ),
                        SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, userId );
                response = getGroupListingForTeacherID( smUrl, apiDetails );
                Log.assertThat( validateActualAPIValuesWithCMS( response, apiDetails.get( GroupConstants.STAFF_ID ) ), "Actual Values are validated with the CMS value", "Not Matched with the CMS value" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getGroupListForTeacherID", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                rbs.deleteClass( classId, accessToken, apiDetails.get( GroupConstants.STAFF_ID ) );
                break;

            case "DUPLICATE_GROUP_NAME":

                Log.message( "Verify the API returning 200 with proper response when the CMS has duplicate class names." );
                Log.message( "Verify the API returning the group details when more than one group name is same. (duplicated group name)" );
                Log.message( "Verify the API retuning single Rumba ID for class when the class having multiple teacher." );
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                String className4 = "Customize Group without product" + System.currentTimeMillis();
                teachers1.add( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                stuIDs.add( studentUserID );
                classDetails1.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
                classDetails1.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                classDetails1.put( RBSDataSetupConstants.STUDENT_PI_ID, studentUserID );
                classDetails1.put( RBSDataSetupConstants.SECTION_NAME, className4 );
                class1 = rbs.createClassWithMultipleTeacher( classDetails1, teachers1, stuIDs );
                String duplicateClassName = rbs.createClassWithMultipleTeacher( classDetails1, teachers1, stuIDs );

                jsonObject = new JSONObject( class1 );
                classId = jsonObject.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();

                jsonObject = new JSONObject( duplicateClassName );
                duplicateClassId = jsonObject.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();

                adminToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                rbs.addProductToClassGraphQL( orgId, classId, mathOnlyProduct,
                        rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ),
                        SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                rbs.addProductToClassGraphQL( orgId, duplicateClassId, mathOnlyProduct,
                        rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ),
                        SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, userId );
                response = getGroupListingForTeacherID( smUrl, apiDetails );
                Log.assertThat( validateActualAPIValuesWithCMS( response, apiDetails.get( GroupConstants.STAFF_ID ) ), "Actual Values are validated with the CMS value", "Not Matched with the CMS value" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getGroupListForTeacherID", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                rbs.deleteClass( classId, accessToken, apiDetails.get( GroupConstants.STAFF_ID ) );
                break;

            case "GROUP_TEACHERS_STUDENTS_PART_OF_MULTIPLE_SCHOOL":
                Log.message( "Verify the API returning 200 with proper data when the student is part of multiple school and added into multiple group which is part of multi school asociated teacher." );
                Log.message( "Verify the API returning proper response when the class having multi school associated student and multi school assiciated teacher." );
                Log.message( "Verify the API returns all classes part of teacher when the teacher mapped with multiple school." );

                String multiSchoolStudent = "MultiSchStudent" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

                schools.add( orgId );
                schools.add( orgId2 );
                String finalSchool = "";
                for ( String school : schools ) {
                    finalSchool += school.concat( "\",\"" );
                }
                finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
                String createUser = rbs.createUser( userDetails );

                String multiSchoolStudentID = SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERID );
                stuIDs.add( multiSchoolStudentID );

                HashMap<String, String> uDetails = new HashMap<>();

                String multiSchoolTeacher = "MultiSchTeacher" + System.nanoTime();
                uDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                uDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
                uDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                String listString = "";
                for ( String school : schools ) {
                    listString += school.concat( "\",\"" );
                }
                listString = listString.substring( 0, listString.length() - 3 );
                uDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
                createTeacher = new RBSUtils().createUser( uDetails );
                multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( createTeacher, RBSDataSetupConstants.USERID );

                rbs.resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );
                new RBSUtils().resetPassword( orgId2, RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );
                String className5 = "Customize Group without product" + System.currentTimeMillis();
                teachers1.add( multipleSchoolTeacherID );
                classDetails1.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( createTeacher, RBSDataSetupConstants.USERNAME ) );
                classDetails1.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                classDetails1.put( RBSDataSetupConstants.STUDENT_PI_ID, multiSchoolStudentID );
                classDetails1.put( RBSDataSetupConstants.SECTION_NAME, className5 );
                class1 = rbs.createClassWithMultipleTeacher( classDetails1, teachers1, stuIDs );

                jsonObject = new JSONObject( class1 );
                classId = jsonObject.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();

                adminToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                rbs.addProductToClassGraphQL( orgId, classId, mathOnlyProduct,
                        rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ),
                        SMUtils.getKeyValueFromResponse( createTeacher, RBSDataSetupConstants.USERID ) );
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( createTeacher, RBSDataSetupConstants.USERNAME ), password );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( createTeacher, RBSDataSetupConstants.USERNAME ), password ) );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, multipleSchoolTeacherID );
                response = getGroupListingForTeacherID( smUrl, apiDetails );
                Log.message( response.toString() );
                Log.assertThat( validateActualAPIValuesWithCMS( response, apiDetails.get( GroupConstants.STAFF_ID ) ), "Actual Values are validated with the CMS value", "Not Matched with the CMS value" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getGroupListForTeacherID", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                rbs.deleteClass( classId, accessToken, apiDetails.get( GroupConstants.STAFF_ID ) );
                break;

            case "GROUP_HAVE_SINGLE_AND_MULTI_SCHOOL_STUDENT":

                Log.message( "Verify the API returning 200 with proper data when the teacher having class with Multi school associated student aswell single school associated studdent." );
                Log.message( "Verify the API returning 200 with proper data when the student part of multiple school." );

                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                String className6 = "Customize Group without product" + System.currentTimeMillis();
                teachers1.add( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                String multiSchlStudent = "MultiSchStudent" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchlStudent );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

                schools.add( orgId );
                schools.add( orgId2 );
                String finalSchools = "";
                for ( String school : schools ) {
                    finalSchools += school.concat( "\",\"" );
                }
                finalSchools = finalSchools.substring( 0, finalSchools.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchools );
                String createUsers = rbs.createUser( userDetails );

                String multiSchoolStudID = SMUtils.getKeyValueFromResponse( createUsers, RBSDataSetupConstants.USERID );
                stuIDs.add( multiSchoolStudID );
                stuIDs.add( studentUserID );

                classDetails1.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
                classDetails1.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                classDetails1.put( RBSDataSetupConstants.STUDENT_PI_ID, studentUserID );
                classDetails1.put( RBSDataSetupConstants.SECTION_NAME, className6 );
                class1 = rbs.createClassWithMultipleTeacher( classDetails1, teachers1, stuIDs );

                jsonObject = new JSONObject( class1 );
                classId = jsonObject.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();
                adminToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                rbs.addProductToClassGraphQL( orgId, classId, mathOnlyProduct,
                        rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ),
                        SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, userId );
                response = getGroupListingForTeacherID( smUrl, apiDetails );
                Log.assertThat( validateActualAPIValuesWithCMS( response, apiDetails.get( GroupConstants.STAFF_ID ) ), "Actual Values are validated with the CMS value", "Not Matched with the CMS value" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getGroupListForTeacherID", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                rbs.deleteClass( classId, accessToken, apiDetails.get( GroupConstants.STAFF_ID ) );
                break;

            case "ORG_PARAMETER_REMOVED":
                Log.message( "Verify all the groups part of given teacher returned in response when the query parameter is removed." );
                String multiSchoolTeachers = "MultiSchTeacher" + System.nanoTime();
                String className7 = "Customize Group without product" + System.currentTimeMillis();
                schools.add( orgId );
                schools.add( orgId2 );
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeachers );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                String listStringss = "";
                for ( String school : schools ) {
                    listStringss += school.concat( "\",\"" );
                }
                listStringss = listStringss.substring( 0, listStringss.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listStringss );
                createTeacher = new RBSUtils().createUser( userDetails );
                multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( createTeacher, RBSDataSetupConstants.USERID );
                teachers1.add( multipleSchoolTeacherID );
                stuIDs.add( studentUserID );

                rbs.resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );
                rbs.resetPassword( orgId2, RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

                classDetails1.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( createTeacher, RBSDataSetupConstants.USERNAME ) );
                classDetails1.put( RBSDataSetupConstants.ORGANIZATION_ID, orgId );
                classDetails1.put( RBSDataSetupConstants.STUDENT_PI_ID, studentUserID );
                classDetails1.put( RBSDataSetupConstants.SECTION_NAME, className7 );
                class1 = rbs.createClassWithMultipleTeacher( classDetails1, teachers1, stuIDs );
                jsonObject = new JSONObject( class1 );
                classId = jsonObject.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();
                accessToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( createTeacher, RBSDataSetupConstants.USERNAME ), password );
                adminToken = rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                rbs.addProductToClassGraphQL( orgId, classId, mathOnlyProduct,
                        rbs.getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ),
                        SMUtils.getKeyValueFromResponse( createTeacher, RBSDataSetupConstants.USERID ) );
                apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbs.getAccessToken( SMUtils.getKeyValueFromResponse( createTeacher, RBSDataSetupConstants.USERNAME ), password ) );
                apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                apiDetails.put( GroupConstants.STAFF_ID, multipleSchoolTeacherID );
                apiDetails.put( GroupConstants.INVALID_ORG, "" );
                response = getGroupListingForTeacherID( smUrl, apiDetails );
                Log.assertThat( validateActualAPIValuesWithCMS( response, apiDetails.get( GroupConstants.STAFF_ID ) ), "Actual Values are validated with the CMS value", "Not Matched with the CMS value" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "getGroupListForTeacherID", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                rbs.deleteClass( classId, accessToken, apiDetails.get( GroupConstants.STAFF_ID ) );
                break;

        }

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "Valid" )
    public Object[][] tcgetGroupListTest2() {

        Object[][] data = { { "Verify the API returns 200 and group details when the group is part of multipe teachers", "SHARED_GROUP", "200" },
                { "Verify all the group details returned in response with 200 response code for given teacher.", "HAPPY_PATH", "200" }, { "Verify the group details returned in API when the group does not have any students.", "HAPPY_PATH", "200" },
                { "Verify the response shows Students Rumba ID field in the response", "HAPPY_PATH", "200" }, { "Verify the response showing Student GradeIds Field in the response", "HAPPY_PATH", "200" },
                { "Verify the API returning proper class details when the SM product added to class in EB.", "HAPPY_PATH", "200" }, { "Verify the API returns staff ID as A&E ID", "HAPPY_PATH", "200" },
                { "Verify the API returns org ID as A&E ID.", "HAPPY_PATH", "200" }, { "Verify the API returns group ID as A&E ID.", "HAPPY_PATH", "200" },
                { "Verify the group details returned in API when the group has shared students.", "TEACHER_WITH_SHARED_STUDENTS", "200" },
                { "Verify the group details returned in API when the group has multiple students.", "TEACHER_WITH_SHARED_STUDENTS", "200" }, { "Verify the student count displaying according to the student count.", "TEACHER_WITH_SHARED_STUDENTS", "200" },
                { "Verify the API returning 200 with proper response when the CMS has duplicate class names.", "DUPLICATE_GROUP_NAME", "200" },
                { "Verify the API returning the group details when more than one group name is same. (duplicated group name)", "DUPLICATE_GROUP_NAME", "200" },
                { "Verify the API retuning single Rumba ID for class when the class having multiple teacher.", "DUPLICATE_GROUP_NAME", "200" },
                { "Verify the API returning 200 with proper data when the student is part of multiple school and added into multiple group which is part of multi school asociated teacher.", "GROUP_TEACHERS_STUDENTS_PART_OF_MULTIPLE_SCHOOL", "200" },
                { "Verify the API returning proper response when the class having multi school associated student and multi school assiciated teacher.", "GROUP_TEACHERS_STUDENTS_PART_OF_MULTIPLE_SCHOOL", "200" },
                { "Verify the API returns all classes part of teacher when the teacher mapped with multiple school.", "GROUP_TEACHERS_STUDENTS_PART_OF_MULTIPLE_SCHOOL", "200" },
                { "Verify the Rumba ids for the student who is part of the group should display in the StudentRumbaIds Field", "GROUP_TEACHERS_STUDENTS_PART_OF_MULTIPLE_SCHOOL", "200" },
                { "Verfy the Student Grade Details shown in the Student Grade Details Field from the response", "GROUP_TEACHERS_STUDENTS_PART_OF_MULTIPLE_SCHOOL", "200" },
                { "Verify the API returning all the grades of students who is part of the group.", "GROUP_TEACHERS_STUDENTS_PART_OF_MULTIPLE_SCHOOL", "200" },
                { "Verify the API returning 200 with proper data when the teacher having class with Multi school associated student aswell single school associated studdent.", "GROUP_HAVE_SINGLE_AND_MULTI_SCHOOL_STUDENT", "200" },
                { "Verify the API returning 200 with proper data when the student part of multiple school.", "GROUP_HAVE_SINGLE_AND_MULTI_SCHOOL_STUDENT", "200" }, { "Verify the API returns staff ID as A&E ID", "ORG_PARAMETER_REMOVED", "200" } };
        return data;
    }

    public Boolean validateActualAPIValuesWithCMS( HashMap<String, String> response, String teacherId ) throws Exception {
        List<String> actualGrpName = new ArrayList<String>();
        List<String> actualOrgid = new ArrayList<String>();
        List<String> actualClassId = new ArrayList<String>();
        Boolean response1;
        RBSUtils rbs = new RBSUtils();

        JSONObject jsonObject = new JSONObject( response.get( Constants.REPORT_BODY ) );
        JSONArray array = jsonObject.getJSONArray( CreateGroupAPIConstants.DATA );

        IntStream.range( 0, array.length() ).forEach( iter -> {
            String eachObject = array.getJSONObject( iter ).toString();
            actualGrpName.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_NAME ) );
            actualOrgid.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_OWNER_ORGID ) );
            actualClassId.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_ID ) );
        } );
        response1 = validateCMSApiWithActualApi( teacherId, actualGrpName, actualClassId, actualOrgid );
        Log.message( response1.toString() );
        return response1;

    }

    public Boolean validateCMSApiWithActualApi( String userid, List<String> actualgroupName, List<String> actualgroupId, List<String> actualOrgId ) throws Exception {
        result = false;
        List<String> groupName = new ArrayList<String>();
        List<String> orgid = new ArrayList<String>();
        List<String> classId = new ArrayList<String>();
        // List<String> groupName=new ArrayList<String>();

        String smUrl = configProperty.getProperty( ConfigConstants.CMS_URL );

        // headers
        String endpoint = GetGroupListAPI.GET_GROUP_DETAIL_SWAGGER;
        endpoint = endpoint.replace( Constants.USER_ID_ENDPOINT, userid );

        Map<String, String> params = new HashMap<String, String>();

        // Instantiating a class
        RestAssuredAPIUtil restCall = new RestAssuredAPIUtil();

        // Sends the POST request to create the tenant
        Response response = (Response) restCall.GETWithDigest( smUrl, configProperty.getProperty( ConfigConstants.CMS_USERNAME ), configProperty.getProperty( ConfigConstants.CMS_PASSWORD ), Constants.JSON_CONTENT_TYPE, endpoint );

        // Log.message(response.asString());

        String data = response.asString();

        JSONArray jsonArr = new JSONArray( data );
        IntStream.range( 0, jsonArr.length() ).forEach( i -> {

            JSONObject jsonObj = jsonArr.getJSONObject( i );

            String classNames = SMUtils.getKeyValueFromResponse(
                    jsonObj.getJSONObject( CreateGroupAPIConstants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).getJSONObject( CreateGroupAPIConstants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION_INFO ).toString(),
                    RBSDataSetupConstants.SECTION_NAME );
            groupName.add( classNames );

            String orgId = SMUtils.getKeyValueFromResponse(
                    jsonObj.getJSONObject( CreateGroupAPIConstants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).getJSONObject( CreateGroupAPIConstants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION_INFO ).toString(),
                    Constants.ORGANIZATION_ID );
            orgid.add( orgId );

            String groupId = SMUtils.getKeyValueFromResponse( jsonObj.getJSONObject( CreateGroupAPIConstants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).toString(), CreateGroupAPIConstants.ID );
            classId.add( groupId );

            if ( groupName.containsAll( actualgroupName ) ) {
                Log.message( "Group Name " + groupName + " Matched" );
                if ( orgid.containsAll( actualOrgId ) ) {
                    Log.message( "Org ID " + orgid + " Matched" );
                    if ( classId.containsAll( actualgroupId ) ) {
                        result = true;
                        Log.message( "Group ID " + classId + " Matched" );
                        Log.message( "validation completed for all the fields" );
                    }
                }
            }

        } );

        return result;
    }
}
