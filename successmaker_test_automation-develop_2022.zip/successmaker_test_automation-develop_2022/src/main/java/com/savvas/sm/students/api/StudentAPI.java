package com.savvas.sm.students.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.CourseExecution;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.response.Response;

public class StudentAPI extends BaseTest {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    // Teacher variable used for this class
    private String teacherDetails=null;
    private String orgId=null;
    private String school=null;
    private String teacherUserId=null;
    private String studentUsername=null;
    private String studentUserId=null;
    private String mathAssignmentUserId=null;
    private String mathAssignmentId=null;
    private String mathSessionId=null;
    private String teacherUsername=null;
    private String studentDetails=null;
    private String readingAssignmentUserId=null;
    private String readingSessionId=null;
    private String readingAssignmentId=null;
    private String catalogNum = null;
    private String skillObjs = null;
    private String scoId = null;

    HashMap<String, String> studentInfo = new HashMap<>();
    private List<String> studentRumbaIds = new ArrayList<>();
    private Map<String, String> courseIds = new HashMap<>();
    private Map<String, String> courseName = new HashMap<>();
    private Map<String, String> assignmentIds = new HashMap<>();
    
    @BeforeClass(alwaysRun = true)
    public void initTest( ITestContext context ) throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        studentDetails = RBSDataSetup.getMyStudent( school, teacherUsername );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

        Log.message( "Teacher Name : "+teacherUsername +" , Student Name :"+ studentUsername);
        String teacherAccessToken = null;
        try {
            teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Issue in get the accces token - " + e.getMessage() );
            try {
                Log.message( "Retrying to get the access token!!!!" );
                teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            } catch ( Exception e1 ) {
                Log.fail( "Unable to create the access token for the teacher - " + teacherUsername );
            }
        }

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );

        // Creating math custom Course and assigning

        courseName.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );

        courseIds.put( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE,
                new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ) ) );
        // Assigning an math assignment
        HashMap<String, String> mathAssignmentDetails = new HashMap<>();
        mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        mathAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        try {
            mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
        } catch ( Exception e ) {
            Log.message( "Issue in get the accces token - " + e.getMessage() );
            try {
                Log.message( "Retrying to get the access token!!!!" );
                mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, password ) );
            } catch ( Exception e1 ) {
                Log.fail( "Unable to create the access token for the teacher - " + teacherUsername );
            }
        }
        try {
            // Assigning Assignment
            Log.message( "Assigning assignment..." );

            HashMap<String, String> mathAssignment = new AssignmentAPI().assignMultipleAssignments( smUrl, mathAssignmentDetails, Arrays.asList( studentUserId ), new ArrayList<>( courseIds.values() ) );
            Log.message( "Assignment Response : " + mathAssignment );

            JSONObject mathAssignmentDetailsJson = new JSONObject( mathAssignment.get( Constants.REPORT_BODY ) );
            JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray( Constants.DATA );
            JSONObject mathAssignmentInfo = new JSONObject( mathAssignmentList.get( 0 ).toString() );
            mathAssignmentId = mathAssignmentInfo.get( "assignmentId" ).toString();
            mathAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), mathAssignmentId );

        } catch ( Exception e ) {
            Log.fail( "Issue in Assigning the assignment to the student!! - " + e.getMessage() );
        }

        // Creating Reading custom Course and assigning

        Log.message( "Math Course Ids for " + school + ": " + courseIds );
        courseIds.clear();
        courseName.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );

        courseIds.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE,
                new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SKILL, courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );

        Log.message( "Reading Course Ids for " + school + ": " + courseIds );

        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        staffDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        try {
            // Assigning Assignment
            Log.message( "Assigning assignment..." );

            HashMap<String, String> readingAssignment = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, Arrays.asList( studentUserId ), new ArrayList<>( courseIds.values() ) );
            Log.message( "Assignment Response : " + readingAssignment );

            JSONObject readingAssignmentDetailsJson = new JSONObject( readingAssignment.get( Constants.REPORT_BODY ) );
            JSONArray readingAssignmentList = readingAssignmentDetailsJson.getJSONArray( Constants.DATA );
            JSONObject readingAssignmentInfo = new JSONObject( readingAssignmentList.get( 0 ).toString() );
            readingAssignmentId = readingAssignmentInfo.get( "assignmentId" ).toString();
            readingAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), readingAssignmentId );

        } catch ( Exception e ) {
            Log.fail( "Issue in Assigning the assignment to the student!! - " + e.getMessage() );
        }

       new CourseExecution().executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ), true, "100", "1", "1" );
       new CourseExecution().executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ), false, "100", "1", "2" );
//        executeCourseInBS( studentUsername, courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ), true );
//        executeCourseInBS( studentUsername, courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ), false );

        String scoHistory = getScoHistory( Integer.parseInt( readingAssignmentUserId ) );
        scoId = getScoId( scoHistory );
        skillObjs = getSkillObjId( readingAssignmentUserId );
        catalogNum = scoId;

        Log.message( "SkillObjId:" + skillObjs );
        Log.message( "SCO ID" + scoId );
        Log.message( "Math Assignment userId :" + mathAssignmentUserId );
        Log.message( "Reading Assignment userId :" + readingAssignmentUserId );

    }

    @Test ( priority = 1, dataProvider = "testData", groups = { "Studets UI API Automation","smoke_test_case", "SMK-67528","P1" } )
    public void studentDashboardAPI( String tcId, String description, String endPoint, String caseName, String parameters, String keys, String statusCode ) throws Exception {

        Log.testCaseInfo( tcId + ":-" + description );
        // Add headers

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.USERID_SM_HEADER, studentUserId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( studentUsername, password ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        String finalEndPoint = "";

        Map<String, String> queryParam = new HashMap<>();

        finalEndPoint = endPoint.replace( "{userId}", studentUserId ).replace( "{auId}", mathAssignmentUserId ).replace( "{mathAuId}", mathAssignmentUserId ).replace( "{readAuId}", readingAssignmentUserId ).replace( "{skillObjs}", skillObjs ).replace(
                "{num}", "15" ).replace( "{lessonId}", "" ).replace( "{catalogNum}", "" ).replace( "{phaseType}", "InitialPlacementK2" ).replace( "{languageCodes}", "spanish" ).replace( "{orgIds}", orgId );
        switch ( caseName ) {
            case "recentInteractions":
                headers.put( "session-id", getSessionID( studentUserId, new RBSUtils().getAccessToken( studentUsername, password ), readingAssignmentUserId ) );
                break;

            case "researchLog":
                headers.put( "session-id", getSessionID( studentUserId, new RBSUtils().getAccessToken( studentUsername, password ), mathAssignmentUserId ) );
                break;

            case "mathCurrentSession":
                headers.put( "session-id", getSessionID( studentUserId, new RBSUtils().getAccessToken( studentUsername, password ), mathAssignmentUserId ) );
                break;

            case "ReadSCO":
                headers.put( "session-id", getSessionID( studentUserId, new RBSUtils().getAccessToken( studentUsername, password ), readingAssignmentUserId ) );
                break;
        }

        Log.message( "Headers " + headers );
        Log.message( "End point :" + finalEndPoint );
        Response response = RestAssuredAPIUtil.get( smUrl, headers, queryParam, finalEndPoint );
        Log.message( "Response: " + response.getBody().asString() );

        // Verifying Status Code
        Log.assertThat( response.getStatusCode() == Integer.parseInt( statusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + statusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + statusCode );

        String responseData = "";
        ArrayList<String> keyList = new ArrayList<String>();
        StringTokenizer st;
        if ( response.getBody().asString().contains( "data" ) ) {
            responseData = SMUtils.getKeyValueFromResponse( response.asString(), "data" );
        } else {
            responseData = response.getBody().asString();
        }
        switch ( caseName ) {
            case "ReadSCO":
                int num = catalogNum.lastIndexOf( '_' );
                keyList.add( (String) catalogNum.subSequence( 0, num ) );
                break;

            case "recentInteractions":
                st = new StringTokenizer( skillObjs, "," );
                while ( st.hasMoreTokens() ) {
                    keyList.add( st.nextToken() );
                }
                break;
            default:
                st = new StringTokenizer( keys, "," );
                while ( st.hasMoreTokens() ) {
                    keyList.add( st.nextToken() );
                }
                break;
        }

        if ( responseData.isEmpty() ) {
            Log.message( "Student response is empty because Student need to achieve the skill " );
        } else {
            for ( String key : keyList ) {
                if ( responseData.contains( key ) ) {
                    Log.softAssertThat( true, "Expected Key " + key + " is found in response", "Expected Key " + key + " is not found in response" );
                } else {
                    Log.softAssertThat( false, "Expected Key " + key + " is found in response", "Expected Key " + key + " is not found in response" );
                }
            }
        }

    }

    @DataProvider ( name = "testData" )
    public Object[][] studentAPIValidation() {

        Object[][] inputData = { // TestCaseId ,TestCaseDescription , EndPoint , case , Payload , Keys  StatusCode
                { "TC01", "GET - API to check multiple assignment session", "lms/web/assignments/multiple/session/{auId}", "appendAssignmentUserId", "", "isSessionExist", CommonAPIConstants.STATUS_CODE_OK },
                { "TC02", "GET API To fetch home page course list for student", "lms/web/assignments/{userId}", "appendUserID", "", "subject,courseName", CommonAPIConstants.STATUS_CODE_OK },
                { "TC03", "GET API to fetch most recent interactions", "lms/web/assignments/interactions/{readAuId}?skillObjs={skillObjs}&num={num}", "recentInteractions", "", "totalNumInteractions,totalResult", CommonAPIConstants.STATUS_CODE_OK },
                { "TC04", "GET - API To get Research Log Required", "/lms/web/assignments/logrequired/{auId}", "researchLog", "", "isLogRequired", CommonAPIConstants.STATUS_CODE_OK },
                { "TC05", "GET API to Math Current Sessions.", "lms/web/assignments/math/session/{mathAuId}", "mathCurrentSession", "", "mathCurrentSession", CommonAPIConstants.STATUS_CODE_OK },
                { "TC06", "GET API to Read Sco History", "lms/web/assignments/scohistory/{readAuId}?lessonId={lessonId}&catalogNum={catalogNum}&phaseType={phaseType}", "ReadSCO", "", "", CommonAPIConstants.STATUS_CODE_OK },
                { "TC07", "GET - DB Time", "lms/web/assignments/dbtime", "currentDbTimestamp", "", "currentDbTimestamp", CommonAPIConstants.STATUS_CODE_OK },
                { "TC08", "GET - Escapehatch API", "lms/web/assignments/escapehatch", "escapehatch", "", "escapeHatchCount", CommonAPIConstants.STATUS_CODE_OK },
                { "TC09", "GET - Language Names", "lms/web/assignments/languageNames?languageCodes={languageCodes}", "languageNames", "", "languageCode,languageName", CommonAPIConstants.STATUS_CODE_OK },
                { "TC10", "GET - Focus Licenses", "lms/web/license/organization/allFocusLicenses?orgIds={orgIds}", "FocusLicenses", "", "areAllLicensesFocus", CommonAPIConstants.STATUS_CODE_OK },
                { "TC11", "GET - Assignments", "lms/web/assignments/k2ipm/assessments", "getAssignments", "", "smre_ip", CommonAPIConstants.STATUS_CODE_OK },
                { "TC12", "GET API To Get Launch Data for assignment user", "lms/web/assignments/launchdata/{auId}", "launchData", "", "motionAssignmentUser,assignmentCurrentLevel", CommonAPIConstants.STATUS_CODE_OK }, };
        return inputData;
    }

    /**
     * Used to fetch the session ID for that Student User
     * @param studentUserId
     * @param studentAccessToken
     * @param studentAssignmentUserId
     * @return
     */
    public String getSessionID( String studentUserId, String studentAccessToken, String studentAssignmentUserId ) {
        String endPoint1 = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        List<String> pathParamsList = new ArrayList<String>();
        HashMap<String, String> header = new HashMap<String, String>();
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( LicenseAPIConstants.USERID, studentUserId );
        header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + studentAccessToken );
        pathParamsList.add( studentAssignmentUserId );
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint1, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, header, endPoint1, pathParams );
        String sessionId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "sessionId" );
        return sessionId;
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws Exception
     */
    public void executeCourseInBS( String studentUserName, String courseName, boolean isMath ) throws Exception {
        WebDriver chromeDriver = null;
        StudentDashboardPage studentsPage = null;
        boolean flagIsExecutionSuccessfull = false;
        try {
            for ( int i = 0; i < 3; i++ ) {
                try {
                    // Get driver
                    chromeDriver = WebDriverFactory.get( browser );
                    LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                    studentsPage = new StudentDashboardPage( chromeDriver );
                    Log.message( "Student username " + studentUserName );
                } catch ( Exception e ) {
                    Log.message( "Issue occurrred at driver creation and Login , reattempting : " + i );
                    continue;
                }
                if ( isMath ) {
                    try {
                        studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "1" );
                        studentsPage.logout();
                        flagIsExecutionSuccessfull = true;
                        break;
                    } catch ( Exception e ) {
                        Log.message( "Issue in course execution!!!" );
                        Log.message( "Issue in executing this course:" + courseName + " , for this Student Username : " + studentUserName );
                    }
                } else {
                    try {
                        studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "2" );
                        studentsPage.logout();
                        flagIsExecutionSuccessfull = true;
                        break;
                    } catch ( Exception e ) {
                        Log.message( "Issue in course execution!!!" );
                        Log.message( "Issue in executing this course:" + courseName + " , for this Student Username : " + studentUserName );
                    }
                }
            }
        } finally {
            if ( flagIsExecutionSuccessfull ) {
                Log.message( "Course executed successfully" );
            } else {
                Log.message( "Course execution failed after reattempting : 3" );
            }
            chromeDriver.quit();

        }

    }

    /**
     * Used to fetch the SCO History
     * @param assUId
     * @return
     */
    public String getScoHistory( int assUId ) {
        List<Object[]> Sco_History = SQLUtil.executeQuery( "select exercise_set_sco_id from school.read_assignment_sco_history WHERE assignment_user_id='" + assUId + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : Sco_History ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String scoHistoryValue = arrList.get( 0 );
        return scoHistoryValue;
    }

    /**
     * Used to fetch the SCO ID(SCO Name)
     * @param scoHis
     * @return
     */
    public String getScoId( String scoHis ) {
        List<Object[]> Sco_Id = SQLUtil.executeQuery( "select exercise_set_sco_name from successmaker.exerset_sco where exercise_set_sco_id='" + scoHis + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : Sco_Id ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String scoIDValue = arrList.get( 0 );
        return scoIDValue;
    }

    /**
     * Used to get the Skill ObjectiveID
     * @param assUId
     * 
     * @return
     */
    public String getSkillObjId( String assUId ) {

        List<Object[]> Skill_Id = SQLUtil.executeQuery( "select skill_objective_id from school.read_interaction where assignment_user_id = '" + assUId + "'" );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : Skill_Id ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        String skillObjIdValue = arrList.get( 0 );
        return skillObjIdValue;
    }
//    @Test ( priority = 1, dataProvider = "testData" )
//    public void test() throws Exception {
//        new CourseExecution().executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_STANDARDS_MATH_COURSE ), true, "100", "1", "1" );
//        new CourseExecution().executeCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ), false, "100", "1", "2" );
//    }
//    @DataProvider ( name = "testData", parallel = true )
//    public Object[][] studentAPIValidationtest() {
//
//        Object[][] inputData = {
//                {},
//                {},
//                {},
//                {},
//                {},
//                {},
//                {},
//                {},
//                {},
//                {},
//                {},
//                {},
//                {}
//        };
//        return inputData;
//    }
}
