package com.savvas.sm.ui.tests.smnew.Mastery;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.mastery.pages.MasteryDetailsPage;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasterySummaryComponent;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperMastery;
import com.savvas.sm.utils.sql.helper.StandardVersionTable;

import LSTFAI.customfactories.EventFiringWebDriver;

public class GroupMasteryTests extends BaseTest {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String assignment;

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = MasteryDataSetup.teacherUserName;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        assignment = MasteryDataSetup.math_Assignment;
    }

    @Test ( description = "Verify Mastery sub tab in group details page", groups = { "SMK-51586", "groups", "groupsMastery" }, priority = 1 )
    public void tcGroupMastery001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcGroupMastery001: Verify Mastery sub tab in group details page. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password

            // navigate to Groups Listing Page
            GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();

            SMUtils.logDescriptionTC( "Verify the Mastery filters are not shown if the teacher doesn't have any students assigned to the group" );
            // Creating new group with no student
            groupPage.createGroupWithoutStudent( Constants.Groups.CREATE_NEW_GROUP );
            groupPage.viewGroup( Constants.Groups.CREATE_NEW_GROUP );
            groupPage.clickGroupsSubNav( Constants.MASTERY );
            Log.assertThat( groupPage.verifyMasteryZeroState(), "Mastery filters are not shown for a group with no students", "Mastery filters are shown for a group with no students" );

            // navigate to Groups Listing Page
            tHomePage.topNavBar.navigateToGroupsTab();
            //groupPage.viewGroup( "Mastery Group 1" ); // TODO: 5/27/2022 change group name
            groupPage.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );

            SMUtils.logDescriptionTC( "Verify Mastery sub tab is displaying on Groups details page" );
            SMUtils.logDescriptionTC( "Verify Mastery sub tab is displaying below Assignment sub tab and above Settings subtab" );
            Log.assertThat( groupPage.getGroupSubNav().contains( Constants.MASTERY ), "Mastery sub tab is displayed in in group details page", "Mastery sub tab is displayed in in group details page" );

            SMUtils.logDescriptionTC( "On clicking Mastery Subtab, Verify 'Mastery' header is displaying" );
            groupPage.clickGroupsSubNav( Constants.MASTERY );
            Log.assertThat( groupPage.verifySubNavHeader( Constants.MASTERY ), "Mastery is displayed on clicking mastery sub tab in group details page", "Mastery is displayed on clicking mastery sub tab in group details page" );

            SMUtils.logDescriptionTC( "Verify Teacher able to view Mastery details on clicking Mastery sub tab" );
            SMUtils.logDescriptionTC( "On Mastery sub tab, Verify Subject, Skill/Standards and Assignments dropdown are present" );
            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );
            Log.assertThat( masteryFiltersComponent.isSubjectDropDownCollapsed() && masteryFiltersComponent.isSkillsStandardsDropdownPresent() && masteryFiltersComponent.isAssignmentDropdownPresent(),
                    "Mastery details are displayed and all filter dropdowns are present on clicking Mastery sub tab", "Mastery details are not displayed or all filter dropdowns are not present on clicking Mastery sub tab" );

            SMUtils.logDescriptionTC( "On Mastery sub tab, Verify Apply Filter button is present" );
            Log.assertThat( masteryFiltersComponent.isApplyFilterButtonPresent(), "Apply Filter button is present in Mastery tab", "Apply Filter button is not present in Mastery tab" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify subject and Skills/Standards dropdowns functionality in Mastery sub tab.", groups = { "SMK-51586", "groups", "groupsMastery" }, priority = 2 )
    public void tcGroupMastery002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcGroupMastery002: Verify subject and Skills/Standards dropdowns functionality in Mastery sub tab.. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // get values from Database for Math subject
            List<StandardVersionTable.StandardVersionMastery> listStandardVersionDBMath = SqlHelperMastery.getStandards( Constants.MasteryUI.SUBJECT_MATH );

            // Get Standards name from DB data
            List<String> skillStandardsAvailableDBMath = new ArrayList<String>();
            skillStandardsAvailableDBMath.add( Constants.MasteryUI.SKILL_MATH );
            for ( StandardVersionTable.StandardVersionMastery standardVersionMastery : listStandardVersionDBMath ) {
                skillStandardsAvailableDBMath.add( standardVersionMastery.getStandardsName() );
            }
            skillStandardsAvailableDBMath = skillStandardsAvailableDBMath.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password
            // navigate to group mastery Page
            GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
            //groupPage.viewGroup( "Mastery Group 1" ); // TODO: 5/26/2022 change group name
            groupPage.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );
            groupPage.clickGroupsSubNav( Constants.MASTERY );

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );
            SMUtils.logDescriptionTC( "Verify the default value for Skills/Standards is 'SuccessMaker Mastery Skills - Math'" );
            Log.assertThat( masteryFiltersComponent.getSkillStandardDropDownSelectedValue().equals( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 0 ) ), "SuccessMaker Mastery Skills - Math is selected as default value for Skills/Standards",
                    "SuccessMaker Mastery Skills - Math is not selected as default value for Skills/Standards" );

            SMUtils.logDescriptionTC( "Verify the teacher is not able to select multiple standards in the Skills/Standards dropdown(Mastery Page)" );
            masteryFiltersComponent.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            masteryFiltersComponent.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 2 ) );
            Log.assertThat( masteryFiltersComponent.getSkillStandardDropDownSelectedValue().equalsIgnoreCase( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 2 ) ), "Skills/Standards dropdown is a single select dropdown",
                    "Skills/Standards dropdown is not a single select dropdown" );

            SMUtils.logDescriptionTC( "Verify the defalut value for Subject dropdown is 'Math'" );
            Log.assertThat( masteryFiltersComponent.getSubjectDropDownSelectedValue().equalsIgnoreCase( Constants.MATH ), "Math is selected as default value for Subject dropdown", "Math is selected as default value for Subject dropdown" );

            SMUtils.logDescriptionTC( "Select Math from subject dropdown, Verify Skill/Standards dropdown having options with respect to selected subject only" );
            Log.assertThat( masteryFiltersComponent.getAllSkillStandardsDropDownValues().stream().map( String::toLowerCase ).collect( Collectors.toList() ).containsAll( skillStandardsAvailableDBMath ),
                    "Skill/Standards dropdown is having options with respect to Math subject only", "Skill/Standards dropdown is not having options with respect to Math subject only" );

            SMUtils.logDescriptionTC( "Verify teacher is able to select 'Reading' from subject dropdown" );
            masteryFiltersComponent.selectSubject( Constants.READING );
            Log.assertThat( masteryFiltersComponent.getSubjectDropDownSelectedValue().equals( Constants.READING ), "Reading is able to select in subject dropdown", "Reading is able to select in subject dropdown" );

            SMUtils.logDescriptionTC( "Select Reading from subject dropdown, Verify Skill/Standards dropdown having options with respect to selected subject only" );
            Log.assertThat(
                    masteryFiltersComponent.getAllSkillStandardsDropDownValues().stream().map( String::toLowerCase ).collect( Collectors.toList() ).containsAll(
                            Constants.READING_SKILLS_DROPDOWN_LIST.stream().map( String::toLowerCase ).collect( Collectors.toList() ) ),
                    "Skill/Standards dropdown are having options with respect to Reading subject only", "Skill/Standards dropdown are not having options with respect to Reading subject only" );

            SMUtils.logDescriptionTC( "Verify subject dropdown will have both Math and Reading option irrespective of the type of assignments assigned to the group" );
            Log.assertThat( masteryFiltersComponent.getAllSubjectDropDownValues().containsAll( Constants.SUBJECT_DROPDOWN_LIST ), "Subject dropdown is having both Math and Reading option", "Subject dropdown is not having both Math and Reading option" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Assignments dropdown functionality in Mastery sub tab.", groups = { "SMK-51586", "groups", "groupsMastery" }, priority = 3 )
    public void tcGroupMastery003() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcGroupMastery003: Verify Assignments dropdown functionality in Mastery sub tab.. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password

            // navigate to group assignment listing Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentNames = assignmentsPage.getAllAssignmentNames();
            List<String> mathAssignments = assignmentNames.stream().filter( name -> name.contains( Constants.MATH ) ).collect( Collectors.toList() );
            List<String> readingAssignments = assignmentNames.stream().filter( name -> name.contains( Constants.READING ) ).collect( Collectors.toList() );

            // navigate to group mastery Page
            GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
            //groupPage.viewGroup( "Mastery Group 1" ); // TODO: 5/27/2022 change group name
            groupPage.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );
            groupPage.clickGroupsSubNav( Constants.MASTERY );

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );

            SMUtils.logDescriptionTC( "Verify the default value for Assignments dropdown is 'All Assignemnts'" );
            Log.assertThat( masteryFiltersComponent.getDropDownMSSelectedValue().contains( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, Integer.toString( mathAssignments.size() ) ) ),
                    "The default value for Assignments dropdown is displayed as excepted", "The default value for Assignments dropdown is wrong" );

            SMUtils.logDescriptionTC( "Select Math from subject dropdown, Verify Assignments dropdown having options with respect to selected subject only" );
            Log.assertThat( masteryFiltersComponent.getSelectedValuesFromDropDownMS().containsAll( mathAssignments ), "Assignments dropdown having options with respect to math subject only",
                    "Assignments dropdown is not having options with respect to math subject only" );

            SMUtils.logDescriptionTC( "Select Reading from subject dropdown, Verify Assignments dropdown having options with respect to selected subject only" );
            masteryFiltersComponent.selectSubject( Constants.READING );
            Log.assertThat( masteryFiltersComponent.getSelectedValuesFromDropDownMS().containsAll( readingAssignments ), "Assignments dropdown having options with respect to reading subject",
                    "Assignments dropdown is not having options with respect to reading subject" );

            SMUtils.logDescriptionTC( "On Mastery sub tab, Verify Assignemnts dropdown is multi selection dropdown" );
            masteryFiltersComponent.selectValuesByIndexFromDropDownMS( Arrays.asList( 0, 1 ) );
            Log.assertThat( masteryFiltersComponent.getDropDownMSSelectedValue().contains( Constants.Reports.SELECTED_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Assignments dropdown is a multi select dropdown",
                    "Assignments dropdown is not a multi select dropdown" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the zero state message displayed when No students have taken the assignment or they have not been assessed any of the skills in the assignment.", groups = { "SMK-51586", "groups", "groupsMastery" }, priority = 4 )
    public void tcGroupMastery004() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcGroupMastery004: Verify the zero state message displayed when No students have taken the assignment or they have not been assessed any of the skills in the assignment. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password

            //coursepage.clickCourseName(Constants.MATH);

            // navigate to Course Listing Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.copyOfCourse( Constants.CUSTOM_BY_STANDARDS_COURSE + "-" + System.nanoTime(), Constants.STANDARDS, Constants.MATH );
            teacherHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Constants.CUSTOM_BY_STANDARDS_COURSE );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroup();

            SMUtils.logDescriptionTC( "Verify the zero state message is displayed when No default courseware has been assigned to any students in the group" );

            //String groupName = SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", 1 );  // TODO: 5/27/2022 Need to enable after datasetup

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();

            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( "Create New Group" ); // TODO: 5/27/2022 change group name

            // Navigate to Mastery sub-tab
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            SMUtils.waitForElement( driver, groupsTab.masteryHeader );
            Log.assertThat( groupsTab.masteryHeader.getText().equals( Constants.MASTERY ), "The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully" );

            // Verify zero state message
            Log.assertThat( groupsTab.verifyMasteryZeroState(), "Zero state message is displayed sucessfully for mastery!", "Zero state message is not displayed sucessfully for mastery!" );

            SMUtils.logDescriptionTC( "Verify the zero state message is displayed when  0 assignments is selected from the assignment dropdown\r\n" );

            groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );

            //Unchecked select all drop down
            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            masteryFiltersComponent.unCheckSelectAllDropdownMS();
            Log.assertThat( groupsTab.verifyMasteryZeroState(), "Zero state message is displayed successfully for mastery!", "Zero state message is not displayed successfully for mastery!" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the zero state message displayed when No students have taken the assignment or they have not been assessed any of the skills in the assignment.", groups = { "SMK-51586", "groups", "groupsMastery" }, priority = 5 )
    public void tcGroupMastery005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcGroupMastery005: Verify the apply filter is in disable state  by default <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password

            SMUtils.logDescriptionTC( "Verify the zero state message is displayed when No default courseware has been assigned to any students in the group" );
            //String groupName = SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", 1 );  // TODO: 5/27/2022 Need to enable after datasetup

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            //groupsTab.viewGroup( "Mastery Group 1" ); // TODO: 5/27/2022 change group name
            groupsTab.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );

            // Navigate to Mastery sub-tab
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            SMUtils.waitForElement( driver, groupsTab.masteryHeader );
            Log.assertThat( groupsTab.masteryHeader.getText().equals( Constants.MASTERY ), "The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully" );

            /// Verify apply filter button disabled
            SMUtils.logDescriptionTC( "Verify the apply filter is in disable state  by default" );
            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );
            masterySummaryComponent.applyFilter();

            //Verify the apply filter is enabled once the new selection is made in the Subject/Standards/assignment dropdown
            SMUtils.logDescriptionTC( "Verify the apply filter is enabled once the new selection is made in the Subject/Standards/assignment dropdown" );
            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );
            masteryFiltersComponent.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            Log.assertThat( masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown().equalsIgnoreCase( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) ), "Selected Skills/Standards name is displayed in Skills/Standards dropdown",
                    "Selected Skills/Standards name is not displayed in Skills/Standards dropdown" );

            //apply filter modified
            SMUtils.logDescriptionTC( "Verify the applied filters can be modified" );
            masteryFiltersComponent.expandSubjectDropDown();
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            Log.assertThat( masteryFiltersComponent.getSelectedValueFromSubjectDropDown().equalsIgnoreCase( Constants.MasteryUI.SUBJECT_MATH ), "The teacher is able to select the subject in the Subjects dropdown",
                    "The teacher is not able to select the subject in the Subjects dropdown" );
            masteryFiltersComponent.expandSkillStandardsDropDown();
            masteryFiltersComponent.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            Log.assertThat( masteryFiltersComponent.getSelectedValueFromSkillStandardsDropDown().equalsIgnoreCase( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) ), "Selected Skills/Standards name is displayed in Skills/Standards dropdown",
                    "Selected Skills/Standards name is not displayed in Skills/Standards dropdown" );
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            masteryFiltersComponent.selectValuesByIndexFromDropDownMS( Arrays.asList( 2 ) );
            Log.assertThat( masterySummaryComponent.applyFilter(), "Apply filter button is modified successfully", "Apply filter button is not modified successfully" );

            //Verify the apply filter is enabled when there are no assignment found  in the assignment dropdown
            SMUtils.logDescriptionTC( "Verify the apply filter is enabled when there are no assignment found  in the assignment dropdown" );
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            masteryFiltersComponent.unCheckSelectAllDropdownMS();
            Log.assertThat( masterySummaryComponent.applyFilter(), "Apply filter is enabled", "Apply filter is not enabled" );
            Log.assertThat( groupsTab.verifyMasteryZeroState(), "Zero state message is displayed sucessfully for mastery!", "Zero state message is not displayed sucessfully for mastery!" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the teacher is able to view the LO & LO details as a blue link in Groups-Mastery tab", groups = { "SMK-51586", "groups", "groupsMastery" }, priority = 6 )
    public void tcGroupMastery006() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcGroupMastery006: Verify the teacher is able to view the LO & LO details as a blue link in Groups-Mastery tab\\r\\n <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login as Teacher
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password
            // String groupName = SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", 1 ); // TODO: 5/27/2022 Need to enable after datasetup

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            //groupsTab.viewGroup( "Mastery Group 1" ); // TODO: 5/27/2022 change group name
            groupsTab.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );

            // Navigate to Mastery sub-tab
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            SMUtils.waitForElement( driver, groupsTab.masteryHeader );
            Log.assertThat( groupsTab.masteryHeader.getText().equals( Constants.MASTERY ), "The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully" );
            //LO as blue color
            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );

            SMUtils.logDescriptionTC( "Verify the teacher is able to view the LO & LO details as a blue link in Groups-Mastery tab\r\n" );
            Log.assertThat( masterySummaryComponent.verifyLOColor( browser ), "Teacher is able to see the LO as a blue link", "Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills" );

            // Student assessment count
            SMUtils.logDescriptionTC( "Verify the text displayed as \" Numbers Student Assessments  \" above the progress bar if more than one student has taken assessment \r\n" );

            Log.assertThat( masterySummaryComponent.getStudentAssessmentOfLeafNodeLO().stream().allMatch( studentCount -> !studentCount.isEmpty() ),
                    "The teacher is able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only",
                    "The teacher is not able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO" );

            SMUtils.logDescriptionTC( "SMK-15004 Verify the text displayed as Numbers Student Assessments above the progress bar if more than one student has taken assessment corresponding to the LO only" );
            String singleStudentAssessCount = Constants.MasteryUI.STUDENT_ASSESSMENT_COUNT.replace( "studentCount ", "" );
            String multiStudentAssessCount = Constants.MasteryUI.STUDENT_ASSESSMENTS_COUNT.replace( "studentCount ", "" );

            Log.assertThat( masterySummaryComponent.getStudentAssessmentOfLeafNodeLO().stream().allMatch( list -> list.endsWith( singleStudentAssessCount ) || list.endsWith( multiStudentAssessCount ) ),
                    "Student assessed count is displayed if one or more student has taken an assessment", "Student assessed count is not displayed if one or more student has taken an assessment" );

            //Assessed objectives legends
            SMUtils.logDescriptionTC( "On clicking 'Apply Filters' button on Mastery Page, verify teacher is able to see the 'Mastered', 'At Risk', 'Not Mastered', and \"Unassessed' breakdown per skills on progress bar\r\n" );
            Log.assertThat( masterySummaryComponent.getAssessedObjectivesHeaders(), "Assessed objectives are present", "Assessed objectives are not present" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify teacher is able to change Skills/Standards option", groups = { "SMK-51586", "groups", "groupsMastery" }, priority = 7 )
    public void tcGroupMastery007() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcGroupMastery007: Verify teacher is able to change Skills/Standards option <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password
            SMUtils.logDescriptionTC( "Verify the teacher is not able to select multiple standards in the Skills/Standards dropdown(Mastery Page)" );

            //String groupName = SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", 1 ); // TODO: 5/30/2022 Need to enable after datasetup

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            //groupsTab.viewGroup( "Mastery Group 1" ); // TODO: 5/30/2022 change group name
            groupsTab.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );

            // Navigate to Mastery sub-tab
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            SMUtils.waitForElement( driver, groupsTab.masteryHeader );
            Log.assertThat( groupsTab.masteryHeader.getText().trim().equals( Constants.MASTERY ), "The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully" );

            //modified skill drop down
            MasteryFiltersComponent masteryPage = new MasteryFiltersComponent( driver );
            masteryPage.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            Log.assertThat( masteryPage.getSelectedValueFromSkillStandardsDropDown().equalsIgnoreCase( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) ), "Selected Skills/Standards name is displayed in Skills/Standards dropdown",
                    "Selected Skills/Standards name is not displayed in Skills/Standards dropdown" );
            /// Verify apply filter button disabled
            SMUtils.logDescriptionTC( "Verify the apply filter is in disable state  by default" );
            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );
            masterySummaryComponent.applyFilter();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher is able to change Skills/Standards option", groups = { "SMK-51586", "groups", "groupsMastery" }, priority = 8 )
    public void tcGroupMastery008() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcGroupMastery008: Verify teacher is able to change Skills/Standards option <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password
            SMUtils.logDescriptionTC( "Verify the teacher is not able to select multiple standards in the Skills/Standards dropdown(Mastery Page)" );

            //String groupName = SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", 1 );  // TODO: 5/30/2022 Need to enable after datasetup

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            //groupsTab.viewGroup( "Mastery Group 1" ); // TODO: 5/30/2022 change group name
            groupsTab.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );

            // Navigate to Mastery sub-tab
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            SMUtils.waitForElement( driver, groupsTab.masteryHeader );
            Log.assertThat( groupsTab.masteryHeader.getText().trim().equals( Constants.MASTERY ), "The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully" );

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );
            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );

            List<String> contentsInGroupMasteryPage = masterySummaryComponent.getLeafNodeContent();

            //Navigate to Mastery page
            teacherHomePage.topNavBar.navigateToMasteryTab();

            masteryFiltersComponent.applyFilter();
            List<String> contentsInmasteryPage = masterySummaryComponent.getLeafNodeContent();

            SMUtils.logDescriptionTC( "Verify the Mastery report/details is identical to the details present in the  Mastery primary tab.for the selected single / multiple assignment (s)\r\n" );
            Log.assertThat( contentsInGroupMasteryPage.containsAll( contentsInmasteryPage ),
                    "The details displayed based on the skills/standard dropdown selection in the groups mastery details page is matching with the details present under primary mastery tab for the same selection",
                    "The details displayed based on the skills/standard dropdown selection in the groups mastery details page is not matching with the details present under primary mastery tab for the same selection" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "On Mouse hovering on Progress bar, Verify tooltip message is displaying", groups = { "SMK-51586", "assignments", "assignmentsMastery" }, priority = 9 )
    public void tcGroupMastery009() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcGroupMastery009: On Mouse hovering on Progress bar, Verify tooltip message is displaying <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password

            SMUtils.logDescriptionTC( "SMK-14952 : On Mouse hovering on Progress bar, Verify tooltip message is displaying" );

            //String groupName = SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", 1 );
            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();

            // Click View Group
            //groupsTab.viewGroup( "Mastery Group 1" ); // TODO: 5/30/2022 change group name
            groupsTab.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );

            groupsTab.clickGroupsSubNav( Constants.MASTERY );

            SMUtils.nap( 2 );
            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );
            // Get webElement of Progress Bar
            List<WebElement> progressBarLink = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            SMUtils.clickJS( driver, progressBarLink.get( 0 ) );

            MasteryDetailsPage masteryDetailsPage = new MasteryDetailsPage( driver );

            //Get Tool Tip Text
            String tooltipOfProgressBar = masteryDetailsPage.getProgressBarToolTipText();

            // Validation 1:
            Log.assertThat( tooltipOfProgressBar.contains( "mastered" ), "Text mastered is present in the Tool tip in the Progress Bar", "Not present in the tool tip" );

            // Validation 2:
            Log.assertThat( tooltipOfProgressBar.contains( "at risk" ), "Text at risk is present in the Tool tip in the Progress Bar", "Not present in the tool tip" );

            // Validation 3:
            Log.assertThat( tooltipOfProgressBar.contains( "not mastered" ), "Text not mastered is present in the Tool tip in the Progress Bar", "Not present in the tool tip" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Mastery data is displayed with respect to the selected assignments only", groups = { "SMK-51586", "assignments", "assignmentsMastery" }, priority = 10 )
    public void tcGroupMastery010() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcGroupMastery010: Verify Mastery data is displayed with respect to the selected assignments only <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password

            SMUtils.logDescriptionTC( "SMK-14937 :Verify Mastery data is displayed with respect to the selected assignments only" );

            //String groupName = SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", 1 );
            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();

            // Click View Group
            //groupsTab.viewGroup( "Mastery Group 1" ); // TODO: 5/30/2022 change group name
            groupsTab.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );
            SMUtils.nap( 0.5 );
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );

            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            masteryFiltersComponent.unCheckSelectAllDropdownMS();
            masteryFiltersComponent.clickApplyFilter();

            masteryFiltersComponent.selectValuesFromDropDownMS( Arrays.asList() );

            masteryFiltersComponent.clickApplyFilter();

            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );
            Log.assertThat( masterySummaryComponent.verifySkillHeadingIsDisplayed(), "Report Displayed for Selected assignment", "Report Not Displayed for selected Assignment" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the mastery data should display for the respective filter combination given by the teacher", groups = { "SMK-51586", "assignments", "assignmentsMastery" }, priority = 11 )
    public void tcGroupMastery011() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcGroupMastery011: Verify the mastery data should display for the respective filter combination given by the teacher <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password

            SMUtils.logDescriptionTC( "SMK-14969 : Verify the mastery data should display for the respective filter combination given by the teacher" );

            //String groupName = SMUtils.getKeyValueFromJsonArray(groupDetails, "groupName", 1); // TODO: 5/30/2022 Need to enable after datasetup
            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();

            // Click View Group
            //groupsTab.viewGroup( "Mastery Group 1" ); // TODO: 5/30/2022 change group name
            groupsTab.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );
            groupsTab.clickGroupsSubNav( Constants.MASTERY );

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );

            masteryFiltersComponent.selectValuesFromDropDownMS( Arrays.asList( MasteryDataSetup.math_Assignment ) );

            masteryFiltersComponent.clickApplyFilter();

            // Get webElement of Progress Bar
            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );
            List<WebElement> progressBarLink = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            WebElement progressBarElement = progressBarLink.get( 0 );

            SMUtils.clickJS( driver, progressBarElement );

            MasteryDetailsPage masteryDetailsPage = new MasteryDetailsPage( driver );
            List<String> assignmentNameList = masteryDetailsPage.getAssignmentNameList();

            Log.assertThat( assignmentNameList.size() == 1, "Selected Assigment Filtered and Shown report for applied filter", "Not filtered as Expected" );

            Log.assertThat( assignmentNameList.contains( MasteryDataSetup.math_Assignment ), "Selected Assigment Filtered and Shown report for applied filter", "Not filtered as Expected" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Mastery data displaying is with respect to all the students present in the group", groups = { "SMK-51586", "assignments", "assignmentsMastery" }, priority = 12 )
    public void tcGroupMastery012() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcGroupMastery012: Verify Mastery data displaying is with respect to all the students present in the group <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            TeacherHomePage teacherHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password ); // TODO: 5/27/2022 change username and password

            SMUtils.logDescriptionTC( "SMK-14936 : Verify Mastery data displaying is with respect to all the students present in the group" );

            //String groupName = SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", 1 );  // TODO: 5/30/2022 Need to enable after datasetup

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();

            //int totalStudentsInGrp = Integer.parseInt( groupsTab.getStudentsCount( "Mastery Group 1" ) ); // TODO: 5/30/2022 change group name

            int totalStudentsInGrp = Integer.parseInt( groupsTab.getStudentsCount( com.savvas.sm.utils.Constants.GROUP_NAME ) );
            // Click View Group
            //groupsTab.viewGroup( "Mastery Group 1" ); // TODO: 5/30/2022 change group name
            groupsTab.viewGroup( com.savvas.sm.utils.Constants.GROUP_NAME );

            groupsTab.clickGroupsSubNav( Constants.MASTERY );

            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );

            masteryFiltersComponent.selectValuesFromDropDownMS( Arrays.asList( MasteryDataSetup.math_Assignment ) );

            masteryFiltersComponent.clickApplyFilter();

            // Get webElement of Progress Bar
            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );
            List<WebElement> progressBarLink = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            WebElement progressBarElement = progressBarLink.get( 0 );

            SMUtils.clickJS( driver, progressBarElement );

            MasteryDetailsPage masteryDetailsPage = new MasteryDetailsPage( driver );
            int totalStudentcountInDetailPage = masteryDetailsPage.getStudentCountsFromDetailsPage();

            // get students count who took assignments
            int totalStudentsTookAssignment = totalStudentsInGrp - 1;

            // Validation :
            Log.assertThat( totalStudentcountInDetailPage == totalStudentsTookAssignment, "Reports Displayed for all the students present in the Group", "Report Not displayed for all students" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
}
