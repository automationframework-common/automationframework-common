package com.savvas.sm.teacher.ui.pages;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class MyProfilePage extends LoadableComponent<MyProfilePage> {

    private WebDriver driver;
    boolean isPageLoaded;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public TopNavBar topNavBar;

    // ********* SuccessMaker My Profile Page Elements ***************

    @IFindBy ( how = How.CSS, using = ".sc-cel-dropdown-select [aria-expanded='false']", AI = false )
    public WebElement drdExpandTitle;

    @IFindBy ( how = How.CSS, using = ".sc-cel-dropdown-select [aria-expanded='true']", AI = false )
    public WebElement drdCollapseTitle;

    @IFindBy ( how = How.CSS, using = ".sc-cel-dropdown-select >span[aria-hidden='true'] ", AI = false )
    public WebElement selectedTitle;

    @FindBy ( css = ".sc-cel-dropdown-select [aria-hidden='false'] >ul li[aria-selected='false']" )
    List<WebElement> unSelectedTitles;

    @IFindBy ( how = How.CSS, using = "input#firstName", AI = false )
    public WebElement txbFirstName;

    @IFindBy ( how = How.ID, using = "middleName", AI = false )
    public WebElement txbMiddleName;

    @IFindBy ( how = How.CSS, using = "input#lastName", AI = false )
    public WebElement txbLastName;

    @IFindBy ( how = How.CSS, using = "input#userId", AI = false )
    public WebElement txbUserId;

    @IFindBy ( how = How.ID, using = "email", AI = false )
    public WebElement txbEmail;

    @IFindBy ( how = How.ID, using = "userName", AI = false )
    public WebElement txbUserName;

    @IFindBy ( how = How.CSS, using = "div.change-password-label >span", AI = false )
    public WebElement changePasswordLink;

    //   @IFindBy (how = How.CSS,using = "input#oldPassword" ,AI=false)
    //    public WebElement txbOldPassword;

    @IFindBy ( how = How.ID, using = "userPassword", AI = false )
    public WebElement txbNewPassword;

    @IFindBy ( how = How.ID, using = "confirmPassword", AI = false )
    public WebElement txbConfirmNewPassword;

    @FindBy ( css = ".error-message span" )
    public List<WebElement> errorMessageElements;

    @FindBy ( css = "span.change-password-disable" )
    public List<WebElement> disabledChangePasswordLink;

    @FindBy ( css = "div.form-group label" )
    List<WebElement> headersTextInTextField;

    @IFindBy ( how = How.CSS, using = ".btn-footer .footer-button:nth-of-type(1)", AI = false )
    public WebElement saveBtnShadow;

    private String saveBtnCSS = ".primary_button";
    public static String erroMessgaeCSS = ".error-message span";

    @IFindBy ( how = How.CSS, using = ".btn-footer .footer-button:nth-of-type(2)", AI = false )
    public WebElement cancelBtnShadow;

    @FindBy ( css = "ul.dropdown-select-options>li" )
    List<WebElement> titleDropDownElements;

    @IFindBy ( how = How.CSS, using = "form-error-message+span.for-sign-in", AI = false )
    public WebElement forSignInLabel;

    @IFindBy ( how = How.CSS, using = "form-error-message+span.for-contact-reference", AI = false )
    WebElement contactReferenceLabel;

    @IFindBy ( how = How.CSS, using = "#alert__messageBody", AI = false )
    public WebElement alertElement;

    @IFindBy ( how = How.CSS, using = "input#firstName", AI = false )
    public WebElement firstNameField;

    @IFindBy ( how = How.CSS, using = "cel-icon.on-hover.hydrated", AI = false )
    public WebElement iIconRoot;

    @IFindBy ( how = How.CSS, using = "div.container-fluid.card.main-container-body.user-profile div.cell-tooltip", AI = false )
    public WebElement PasswordRequirementRoot;

    @IFindBy ( how = How.CSS, using = "input#userPassword", AI = false )
    public WebElement userPassword;
    
    @IFindBy ( how = How.CSS, using = "#userName", AI = false )
    public WebElement userNameField;

    ArrayList<String> passwordRequirementsText = new ArrayList<>(
            Arrays.asList( "Password Requirements", "Must be at least eight characters long", "Must contain at least one letter", "Must contain at least one number", "Can not include your name or username" ) );

    private String cancelBtnCSS = ".secondary_button";
    public static String alertMessageCSS = "#alert__messageBody";
    public static String userIDCSS = "input#userId";
    public static String oldPasswordCSS = "input#oldPassword";
    public static String newPasswordCSS = "input#userPassword";
    public static String confirmPasswordCSS = "input#confirmPassword";

    public MyProfilePage() {}

    public MyProfilePage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
        topNavBar = new TopNavBar( driver );
    }

    @Override
    protected void isLoaded() {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }

        if ( SMUtils.waitForElement( driver, changePasswordLink ) ) {
            Log.message( "SM My profile page loaded successfully." );
        } else {
            Log.fail( "SM My profile page did not load." );
        }
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, changePasswordLink );
    }

    /**
     * edit firstName
     *
     * @param valueToUpdate
     */
    public void modifyFirstName( String valueToUpdate ) {
        SMUtils.waitForElement( driver, txbFirstName );
        txbFirstName.clear();
        txbFirstName.sendKeys( valueToUpdate );
        Log.message( "First Name Modified" );
    }

    /**
     * Returns the first name as string
     *
     * @return
     */
    public String getFirstName() {
        SMUtils.waitForElement( driver, txbFirstName );
        return txbFirstName.getAttribute( "value" );

    }

    /**
     * edit middleName
     *
     * @param valueToUpdate
     */
    public void modifyMiddleName( String valueToUpdate ) {
        txbMiddleName.clear();
        txbMiddleName.sendKeys( valueToUpdate );
        Log.message( "Middle Name Modified" );

    }

    /**
     * Returns the middle name as string
     *
     * @return
     */
    public String getMiddleName() {
        return txbMiddleName.getAttribute( "value" );
    }

    /**
     * edit lastName
     *
     * @param valueToUpdate
     */
    public void modifyLastName( String valueToUpdate ) {
        txbLastName.clear();
        txbLastName.sendKeys( valueToUpdate );
        Log.message( "Last Name Modified" );
    }

    /**
     * Returns the last name as string
     *
     * @return
     */
    public String getLastName() {
        SMUtils.waitForElement( driver, txbLastName );
        return txbLastName.getAttribute( "value" );
    }

    /**
     * edit email
     *
     * @param valueToUpdate
     */
    public void modifyEmail( String valueToUpdate ) {
        SMUtils.waitForElement( driver, txbEmail );
        txbEmail.clear();
        txbEmail.sendKeys( valueToUpdate );
        Log.message( "Email Modified" );
    }

    /**
     * Returns the email as string
     *
     * @return
     */
    public String getEmail() {
        return txbEmail.getAttribute( "value" );
    }

    /**
     * edit User name
     *
     * @param valueToUpdate
     */
    public void modifyUserName( String valueToUpdate ) {
        txbUserName.clear();
        txbUserName.sendKeys( valueToUpdate );
        Log.message( "UserName Modified" );
    }

    /**
     * Returns the User name as string
     *
     * @return
     */
    public String getUserName() {
        return txbUserName.getAttribute( "value" );
    }

    /**
     * Click on change password link
     */
    public void clickChangePasswordLink() {
        SMUtils.waitForElement( driver, changePasswordLink );
        changePasswordLink.click();
        Log.message( "Clicked Change Passsword Link" );
    }

    /**
     * Click on information icon on New Password
     */
    public void clickInformationCircle() {
        new SMUtils();
        new SMUtils();
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, iIconRoot, "img" ) );
        Log.message( "Clicked (i) icon on the New Password Field" );
    }

    /**
     * Validate the Password requirement Text
     *
     * @return
     */
    public boolean VerifyPasswordRequirementTexts() {
        ArrayList<String> actualText = new ArrayList<>();
        new SMUtils();
        actualText.add( SMUtils.getChildWebElementFromParent( PasswordRequirementRoot, "label" ).getText().trim() );
        List<WebElement> passwordPolicies = SMUtils.getChildWebElementsFromParent( PasswordRequirementRoot, "ul li" );
        new SMUtils();
        actualText.addAll( SMUtils.getAllTextFromWebElementList( passwordPolicies ) );
        new SMUtils();
        return SMUtils.compareTwoList( passwordRequirementsText, actualText );
    }

    /**
     * Change password
     *
     * @param oldPassword
     * @param newPassword
     */
    public void modifyPassword( String newPassword ) {
        clickChangePasswordLink();

        // add new password
        txbNewPassword.clear();
        txbNewPassword.sendKeys( newPassword );

        // add confirm new password
        txbConfirmNewPassword.clear();
        txbConfirmNewPassword.sendKeys( newPassword );

        Log.message( "Password Details Passed to the fields" );
    }

    /**
     * Verify the displayed error messages
     *
     * @param expectedErrorMessages
     * @return
     */
    public boolean verifyErrorMessages( List<String> expectedErrorMessages ) {
        List<String> actualErrorMessages = new ArrayList<>();
        for ( WebElement errorMessageElement : errorMessageElements )
            actualErrorMessages.add( errorMessageElement.getText() );
        boolean returnParam = actualErrorMessages.containsAll( expectedErrorMessages );
        Log.message( "Error Messages validated Successfully" );
        return returnParam;
    }

    /**
     * Click on Save Btn
     */
    public void saveChanges() {
        SMUtils.waitForElement( driver, saveBtnShadow );
        WebElement saveBtn = SMUtils.getWebElement( driver, saveBtnShadow, saveBtnCSS );
        SMUtils.clickJS( driver, saveBtn );
        Log.message( "Clicked Save Button" );
        SMUtils.nap( 0.5 );
    }

    /**
     * Click on Cancel Btn
     */
    public void cancelChanges() {
        new SMUtils();
        SMUtils.waitForElement( driver, cancelBtnShadow );
        WebElement cancelBtn = SMUtils.getWebElement( driver, cancelBtnShadow, cancelBtnCSS );
        SMUtils.clickJS( driver, cancelBtn );
        Log.message( "Clicked Cancel Button" );
    }

    /**
     * To Verify the Presence of Cancel Button
     *
     * @return
     */

    public Boolean isCancelBtnEnabled() {
        boolean status = false;
        WebElement cancelBtn = SMUtils.getWebElement( driver, cancelBtnShadow, cancelBtnCSS );
        if ( cancelBtn.isDisplayed() ) {
            status = true;
        }
        return status;
    }

    /**
     * To Verify the Presence of Save Button
     *
     * @return
     */

    public Boolean isSaveBtnEnabled() {
        boolean status = false;
        WebElement saveBtn = SMUtils.getWebElement( driver, saveBtnShadow, saveBtnCSS );
        if ( saveBtn.isDisplayed() ) {
            status = true;
        }
        return status;
    }

    /**
     * To check Password field is Disabled
     */
    public Boolean isPasswordFieldDisabled() {
        boolean status = false;
        SMUtils.waitForElement( driver, userPassword );
        if ( !userPassword.isEnabled() ) {
            status = true;
            Log.message( "Password field is Disabled" );
        }
        return status;
    }

    /**
     * To Validate Change password Link
     *
     * @return
     * @throws Exception
     */

    public Boolean validateChangePaswordLink() throws Exception {
        boolean status = false;
        clickChangePasswordLink();
        try {
            if ( userPassword.isEnabled() && txbNewPassword.isEnabled() && txbConfirmNewPassword.isEnabled() ) {
                status = true;
                Log.message( "Change Password Link is Validated Successfully" );
            }
        } catch ( Exception e ) {
            Log.message( "Change Password Link is not working properly" );
            Log.exception( e );
        }

        return status;

    }

    /**
     * To Expand Titles DropDown
     */
    public void expandUserTitle() {
        SMUtils.waitForElement( driver, drdExpandTitle, 8 );
        SMUtils.clickJS( driver, drdExpandTitle );
        Log.message( "Titles DropDown Expanded" );
    }

    /**
     * To get Values From the TitleDropDown
     *
     * @return
     */

    public List<String> getValuesFromtheTitleDropDown() {
        List<String> allValuesInTheDropDown = new ArrayList<>();
        expandUserTitle();
        for ( int titleValue = 0; titleValue < titleDropDownElements.size(); titleValue++ ) {
            WebElement eachValue = titleDropDownElements.get( titleValue );
            String valueFrom = eachValue.getText().trim();
            allValuesInTheDropDown.add( valueFrom );
            Log.message( "Fetched the Values from the Drop Down" );
        }
        return allValuesInTheDropDown;
    }

    /**
     * To get Values From the TitleDropDown
     *
     * @return
     */

    public void selectValuesFromtheTitleDropDown( String titleName ) {
        expandUserTitle();
        for ( WebElement webElement : titleDropDownElements ) {
            SMUtils.scrollDownIntoViewElement( driver, webElement );
            String name = webElement.getText().trim();
            if ( name.equals( titleName ) ) {
                SMUtils.clickJS( driver, webElement );
                Log.message( "Successfully Clicked" );
                break;
            }
        }

    }

    /**
     * To validate the Error message for the invalid text fields
     *
     * @return
     */

    public Boolean validateErrorMessage( String message ) {
        SMUtils.nap( 2 );
        boolean status = false;
        List<String> errMessages = new ArrayList<>();
        for ( WebElement msgElement : errorMessageElements ) {
            String msg = msgElement.getText();
            if ( msg.equals( message ) ) {
                Log.message( "Error Message validated Successfully" );
                status = true;
                break;
            }
        }
        return status;
    }

    /**
     * To validate Password changed successfully
     *
     * @return
     * @throws Exception
     */

    public Boolean validateChangedPassword( String newPassword ) throws Exception {
        boolean status = false;
        try {
            modifyPassword( newPassword );
            saveChanges();
            status = true;
            Log.message( "Default password Changed Successfully" );
        } catch ( Exception e ) {
            Log.message( "Password Not Updated" );
            Log.exception( e, driver );
        }
        return status;
    }

    /**
     * To Clear value in the text field
     *
     * @throws AWTException
     *
     */

    public void clearTextField( String textField ) throws AWTException {
        if ( textField.contains( "password" ) ) {
            clickChangePasswordLink();
            Log.message( "Password Field Cleared" );
        } else if ( textField.contains( "firstName" ) ) {
            clearText( txbFirstName );
            Log.message( "Firstname Field Cleared" );
        } else if ( textField.contains( "lastName" ) ) {
            clearText( txbLastName );
            Log.message( "LastName Field Cleared" );
        } else if ( textField.contains( "NewPwd" ) ) {
            clearText( txbNewPassword );
        } else if ( textField.contains( "conformPwd" ) ) {
            clearText( txbConfirmNewPassword );
        }
    }

    /**
     * Common Method to del using key board keys
     *
     * @throws AWTException
     *
     */

    private void clearText( WebElement element ) throws AWTException {
        SMUtils.waitForElement( driver, element );
        element.sendKeys( Keys.CONTROL + "a" );
        element.sendKeys( Keys.DELETE );
    }

    /**
     * To pass value in to new password field
     *
     */

    public void modifyNewPassword( String newPassword ) {
        SMUtils.waitForElement( driver, txbNewPassword );
        txbNewPassword.clear();
        txbNewPassword.sendKeys( newPassword );
        Log.message( "newPassword passed in to field successfully" );
    }

    /**
     * To pass value in to confirm password field
     *
     */

    public void modifyConfirmPassword( String newPassword ) {
        txbConfirmNewPassword.clear();
        txbConfirmNewPassword.sendKeys( newPassword );
        // txbConfirmNewPassword.sendKeys( newPassword ); // Removed as part of SME- 187
        Log.message( "Confirm Password passed in to field successfully" );
    }

    /**
     * To get Name with specified number of characs
     *
     * @return
     */

    public String getNameWithSpecifiedNumOfCharac( int noOfCharacs ) {
        String name = "";
        for ( int noOfcharc = 1; noOfcharc <= noOfCharacs; noOfcharc++ ) {
            name = name + "a";
        }
        return name;
    }

    /**
     * To get Name with below 75 characs
     *
     * @return
     */
    public String getNameWith75Charscs() {
        String name = "";
        for ( int noOfcharc = 1; noOfcharc <= 76; noOfcharc++ ) {
            name = name + "a";
        }
        return name;
    }

    /**
     * To Pass Values into New password and conform password field
     */

    public void modifyPasswordwithoutCurrentPassword( String newPassword ) {
        // add new password
        SMUtils.waitForElement( driver, txbNewPassword );
        txbNewPassword.clear();
        txbNewPassword.sendKeys( newPassword );
        Log.message( "Value passed in to New password field " );

        // add confirm new password
        txbConfirmNewPassword.clear();
        txbConfirmNewPassword.sendKeys( newPassword );
        Log.message( "Value passed in to Confirm password field " );

    }

    /**
     * This method is to get option present in the Title dropdown
     *
     * @return
     */
    public String getUserTitle() {
        return SMUtils.getTextOfWebElement( selectedTitle, driver );
    }

    /**
     * To verify Contact Reference Text Present under the email Id text field
     *
     * @return
     */

    public boolean isContactRefLabelPresent() {
        SMUtils.waitForElement( driver, contactReferenceLabel );
        return contactReferenceLabel.isDisplayed();
    }

    /**
     * To verify For Sign In Text Present under the email Id text field
     *
     * @return
     */

    public boolean isForSignInLabelPresent() {
        SMUtils.waitForElement( driver, forSignInLabel );
        return forSignInLabel.isDisplayed();
    }

    /**
     * To verify mandatory symbol(*) is present in the end of the field name
     *
     * @return
     */

    public Boolean isMandatorySymbolPresent( String fieldName ) {
        boolean status = false;
        for ( WebElement webElement : headersTextInTextField ) {
            String field = webElement.getText().trim();
            if ( field.equals( fieldName ) ) {
                if ( field.contains( "*" ) ) {
                    status = true;
                }
            }
        }
        return status;

    }

    /**
     * Verify if the Removed UserId and Current Password field is not present in
     * UI.
     *
     * @return true if not present
     */
    public boolean VerifyUserIdAndOldPasswordisNotPresent() {
        new SMUtils();
        boolean isUserIdExists = SMUtils.verifyElementDoesNotExist( By.cssSelector( userIDCSS ), driver );
        new SMUtils();
        boolean isOldPasswordExits = SMUtils.verifyElementDoesNotExist( By.cssSelector( oldPasswordCSS ), driver );
        return ( isUserIdExists && isOldPasswordExits ) ? true : false;
    }

    public boolean VerifyNewPasswordandConfirmPasswordisPresent() {
        new SMUtils();
        boolean isNewPasswordExists = SMUtils.isElementPresent( txbNewPassword );
        new SMUtils();
        boolean isConfirmNewPasswordExists = SMUtils.isElementPresent( txbConfirmNewPassword );
        return ( isNewPasswordExists && isConfirmNewPasswordExists ) ? true : false;
    }

    /**
     * Verify if save button is disabled
     *
     * @return true if disabled
     */
    public boolean verifySaveButtonisDisabled() {
        new SMUtils();
        SMUtils.waitForElement( driver, saveBtnShadow );
        new SMUtils();
        String elementText = SMUtils.getOuterHTML( saveBtnShadow );
        return elementText.contains( "disabled" ) ? true : false;
    }

    /**
     * Verify whether password is masked or not
     *
     * @return true if masked
     */
    public boolean isPasswordMasked() {
        new SMUtils();
        SMUtils.waitForElement( driver, txbNewPassword );
        new SMUtils();
        //txbNewPassword.click();
        //String getTypeAttribute = txbNewPassword.getAttribute("type");
        //String getTypeAttribute = new SMUtils().getAttributeOfWebElement(txbNewPassword, driver,"type" );
        String getTypeAttribute = SMUtils.getAttributeOfWebElement( txbNewPassword, driver, "type" );

        return getTypeAttribute.contains( "password" ) ? true : false;
    }
    
    /***
     * Checks and return Username field is enabled or not
     *
     * @return
     */
    public boolean isUsernameEnabled() {
        return userNameField.isEnabled();
    }
    
    

}