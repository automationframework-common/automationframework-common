package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Groups;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.ReturnStudentListAPI;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class GroupListingTest extends BaseTest {

    // Initializing the object
    GroupPage groupPageObject;
    SMUtils SMUtilsObject = new SMUtils();

    private String OrgId;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String smUrl;
    private String browser;
    private String accesstoken;
    private static String userName = null;
    private static String GoogleTeacherusername = null;
    private static String passWord = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
	private String teacherDetails1;
	private String studentDetails1;
	private String studentDetails2;
	private String studentDetails4;
	private String studentDetails5;
	private String studentDetails3;
	private ArrayList<String> studentRumbaIds;
	private String teacherId1;
	private String teacherId2;
	private String userName1;
	private ArrayList<String> teacherRumbaIds;
	private ArrayList<String> studentUserNames;
	private String studentOne;
	private String studentTwo;
	private String studentFour;
	private String studentFive;
	private String studentSix;

    @BeforeClass
    public void initTest( ITestContext context ) {
    	OrgId = RBSDataSetup.organizationIDs.get( school );
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        //userName = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
//        GoogleTeacherusername = Constants.GOOGLE_TEACHER_USERNAME;
        

        //Teacher Details
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherDetails1 = RBSDataSetup.getMyTeacher(school);
        teacherId1 = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        teacherId2 = SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERID );
        userName = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME);
        userName1 = SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERNAME);
        
        teacherRumbaIds = new ArrayList<>();
        teacherRumbaIds.add( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        teacherRumbaIds.add( SMUtils.getKeyValueFromResponse( teacherDetails1, RBSDataSetupConstants.USERID ) );
        
        //Student Details
        studentDetails1 = RBSDataSetup.getMyStudent( school, userName );
        studentDetails2 = RBSDataSetup.getMyStudent( school, userName );
        studentDetails4 = RBSDataSetup.getMyStudent( school, userName );
        studentDetails5 = RBSDataSetup.getMyStudent( school, userName );
        studentDetails3 = RBSDataSetup.getMyStudent( school, userName );
        
        studentOne = ( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ) );
        studentTwo = ( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERNAME ) );
        studentFour = ( SMUtils.getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERNAME ) );
        studentFive = ( SMUtils.getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERNAME ) );
        studentSix = ( SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERNAME ) );
      
        studentRumbaIds = new ArrayList<String>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERID ) );
        
        studentUserNames = new ArrayList<String>();
        studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ) );
        studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERNAME ) );
        
    }

    @Test ( description = "Verify ZeroState message and link buttons in group listing page ", priority = 1, groups = { "SMK-39180", "Groups", "Group Listing" } )
    public void tcSMGroupListing_001() throws Exception {
        // Deleting all the groups
        deleteAllGroupsByAPI();
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            SMUtils.logDescriptionTC( "SMK-7217 : Verify the Zero State message in Group listing page" );
            groupPageObject = new GroupPage( driver );
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( userName, passWord, true );
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            // Verify the Zero State message
            SMUtils.logDescriptionTC( "SMK-7220 :Verifying a zero state message" );
            groupPageObject.verifyZeroState();
            //  Verify link on zero Create Group  message 
            SMUtils.logDescriptionTC( "SMK-7218 :Verify the zero state page contains create new group link." );
            groupPageObject.clickCreateGroupinZeroState();
            String headerMessage = groupPageObject.getTextofCreateNewGroup();
            Log.assertThat( headerMessage.equals( "Create New Group" ), "The modal window header message is matching", "The modal window header message is not matching Actual is " + headerMessage );
            groupPageObject.clickCancelButtonOnCreateGroupPopup();
            SMUtils.logDescriptionTC( "SMK-7183 : Verify Clicking the \"Create a New Group\" button and verify if the Modal window opens" );
            groupPageObject.clickCreateGroup();
            headerMessage = groupPageObject.getTextofCreateNewGroup();
            Log.assertThat( headerMessage.equals( "Create New Group" ), "The modal window header message is matching", "The modal window header message is not matching Actual is " + headerMessage );
            groupPageObject.clickCancelButtonOnCreateGroupPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verification of Group listing on the Zero State", priority = 2, groups = { "SMK-39180", "Groups", "Group Listing" } )
    public void tcSMGroupListing_002() throws Exception {
        // Deleting all the groups
        Log.testCaseInfo( "Verification of Group listing on the Zero State" );
        Log.message( "Deleting all groups" );
        deleteAllGroupsByAPI();

        // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        groupPageObject = new GroupPage( driver );
        try {
            // Loggin in and goes to group tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( userName, passWord, true );
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            //        //Creating group
            String GroupName = "Group1";
            groupPageObject.createGroupWithoutStudent( GroupName );
            List<String> groupsList = new ArrayList<String>();
            groupsList.add( GroupName );

            Log.message( "checking if the group is present on the UI" );
            List<String> groupsFromUI = groupsTab.getGroupNames();
            // GroupName.tr
            Log.assertThat( groupsFromUI.equals( groupsList ), "The Created Group is present on the UI", "Group created" + groupsList + "is not present on the UI" + groupsFromUI );
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );

            SMUtils.logDescriptionTC( "SMK-7211 : Verify the empty group with # no of student is zero" );
            String noOfStudents = groupPageObject.getNo_Of_Students( GroupName );
            Log.assertThat( noOfStudents.equals( "0" ), "# of Student count is matching!", "# of Student count is not matching! expected 0" + " actual is " + noOfStudents );

            SMUtils.logDescriptionTC( "SMK-7212 : Verifying clicking \"view group\" button will opens the group section" );
            groupPageObject.clickGetViewGroupBtn( GroupName );
            String groupHeaderName = groupPageObject.getGroupNameinContainer();
            Log.assertThat( groupHeaderName.equals( GroupName ), "The Group name is mathcing!", "Group name is not matching expected " + GroupName + " groupHeaderName" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Group listing page when added 5 Students in the Group", priority = 3, groups = { "SMK-39180", "Groups", "Group Listing" } )
    public void tcSMGroupListing_003() throws Exception {
        // Deleting all the groups
        Log.message( "Deleting all groups" );
        deleteAllGroupsByAPI();
        teacherId1 = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        OrgId = RBSDataSetup.organizationIDs.get( school );

        // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {
            // Initializing the object
            groupPageObject = new GroupPage( driver );

            // Loggin in and goes to group tab

            // Creating Group
            String GroupName = "Group with 5 Students";

            HashMap<String, String> groupDetailsMap = new HashMap<>();
            groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( userName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
            groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, GroupName );
            new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( userName, passWord, true );
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            String noOfStudents = groupsTab.getNo_Of_Students( GroupName ).trim();
            SMUtils.logDescriptionTC( "SMK-7188 :Verify the students count displayed in # of students column." );
            SMUtils.logDescriptionTC( "SMK-7210 : Verify the number format of # of Students value is single digit without perfix zero" );
            Log.assertThat( noOfStudents.equals( "5" ), "The number are in format of single digit[" + noOfStudents + "]", "The number is not in the single digit format actual is=>" + noOfStudents );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Group with Different Naming convention", priority = 4, groups = { "SMK-39180", "Groups", "Group Listing" } )
    public void tcSMGroupListing_004() throws Exception {
        // Deleting all the groups
        Log.message( "Deleting all groups" );
        deleteAllGroupsByAPI();
        // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {
            groupPageObject = new GroupPage( driver );

            // Logging in and goes to group tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( userName, passWord, true );
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            // Clicking Create a new group button

            SMUtils.waitForElementToBeClickable( groupPageObject.getCreateGroupButton(), driver );
            SMUtils.clickJS( driver, groupPageObject.getCreateGroupButton() );
            SMUtils.nap( 2 );
            Log.message( "Create group popup loaded" );

            String expectedErrorMessage = "Group name must be between 3 and 75 characters";

            SMUtils.logDescriptionTC( "SMK-7203 : Verify the group name should contains minimum 3 characters" );
            groupPageObject.getGroupNameTextBoxInPopup().sendKeys( "tw" );
            //SMUtils.clickJS( driver, groupPageObject.getAllStudentsCheckBox() );
            groupPageObject.getGroupNameTextBoxInPopup().submit();
            groupPageObject.getAddStudentTextBox().sendKeys( "Test student" );
            // groupPageObject.clickCreateGroupButton();
            String actualErrorMessage = groupPageObject.getErrorMessageInGroupNameTextBox();
            Log.assertThat( actualErrorMessage.equals( expectedErrorMessage ), "The validation message is matching!", "The errorMessage is not matching" + actualErrorMessage );
            groupPageObject.getGroupNameTextBoxInPopup().clear();

            SMUtils.logDescriptionTC( "SMK-7204 :Verify the group name should not contains more 75 characters " );
            groupPageObject.getGroupNameTextBoxInPopup().sendKeys( "GroupNamewith75CharacterGroupNamewith75CharacterGroupNamewith75Character1234" );
            //SMUtils.clickJS( driver, groupPageObject.getAllStudentsCheckBox() );
            //groupPageObject.clickCreateGroupButton();
            actualErrorMessage = groupPageObject.getErrorMessageInGroupNameTextBox();
            Log.assertThat( actualErrorMessage.equals( expectedErrorMessage ), "The validation message is matching!", "The errorMessage is not matching" + actualErrorMessage );
            groupPageObject.clickCancelButtonOnCreateGroupPopup();

            List<String> groupNames = new ArrayList<String>();
            groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupNames.add( "12345" );
            groupNames.add( "#$%^&*!)" );
            groupNames.add( "GrOuP123" );
            groupNames.add( "Group,apostrophe'" );
            groupNames.add( "GroupNamewith75CharacterGroupNamewith75CharacterGroupNamewith75Character123" );

            SMUtils.logDescriptionTC( "SMK-7206 : Verify the group name contains only numbers." );
            groupPageObject.createGroupWithoutStudent( groupNames.get( 0 ) );

            SMUtils.logDescriptionTC( "SMK-7205 : Verify the group name contains only special characters." );
            groupPageObject.createGroupWithoutStudent( groupNames.get( 1 ) );

            SMUtils.logDescriptionTC( "SMK-7207 : Verify the group name contains alpha numerics" );
            groupPageObject.createGroupWithoutStudent( groupNames.get( 2 ) );

            SMUtils.logDescriptionTC( "SMK-7208 : Verify the group name contains aphastrophe" );
            groupPageObject.createGroupWithoutStudent( groupNames.get( 3 ) );

            SMUtils.logDescriptionTC( "SMK-7204 : Verify the group name should contains maximum 75 characters." );
            groupPageObject.createGroupWithoutStudent( groupNames.get( 4 ) );

            Log.message( " Checking if the group is present on the UI" );
            SMUtils.nap( 3 );
            List<String> groupsFromUI = groupsTab.getGroupNamesFromGroupsTab();
            Log.message( "Groups in the listing - " + groupsFromUI );
            Collections.sort( groupsFromUI );
            Collections.sort( groupNames );

            Log.assertThat( groupsFromUI.equals( groupNames ), "The Created Group is present on the UI!", "On UI Group Expected" + groupNames + "but Actual is " + groupsFromUI );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    //This case disabled due to SMK-59700
    @Test ( enabled = false, description = "Verify the Same group cannot be added again", priority = 5, groups = { "SMK-39180", "Groups", "Group Listing" } )
    public void tcSMGroupListing_005() throws Exception {

        // Deleting all the groups
        Log.message( "Deleting all groups" );
        deleteAllGroupsByAPI();

        // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {
            groupPageObject = new GroupPage( driver );

            // Logging in and goes to group tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( userName, passWord, false );
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            String GroupName = "GroupSame1";
            groupPageObject.createGroupWithoutStudent( GroupName );

            SMUtils.logDescriptionTC( "SMK-7232 : Verify the group name cannot be duplicated" );
            SMUtils.waitForElementToBeClickable( groupPageObject.getCreateGroupButton(), driver );
            groupPageObject.clickCreateGroup();
            groupPageObject.getGroupNameTextBoxInPopup().sendKeys( GroupName );
            //SMUtils.clickJS( driver, groupPageObject.getAllStudentsCheckBox() );
            groupPageObject.getGroupNameTextBoxInPopup().submit();
            groupPageObject.getAddStudentTextBox().sendKeys( "Test student" );
            groupPageObject.clickCreateGroupButtoninPopup();
            String expectedErrorMessage = "Group name taken. Please enter a unique group name.";
            String actualErrorMessage = groupPageObject.getErrorMessageInGroupNameTextBox().trim();

            Log.assertThat( actualErrorMessage.equals( expectedErrorMessage ), "The validation message is matching!", "The errorMessage is not matching[" + actualErrorMessage + "]Expected is [" + expectedErrorMessage + "]" );
            groupPageObject.clickCancelButtonOnCreateGroupPopup(); // SignOut from SM

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Group listing sorting", priority = 1, groups = { "SMK-39180", "Groups", "Group Listing" } )
    public void tcSMGroupListing_006() throws Exception {

        // Deleting all the groups 
        deleteAllGroupsByAPI();
        List<String> groupAsciiNames = getListOfRandomText( 20 );
        try {
            OrgId = RBSDataSetup.organizationIDs.get( school );
            Random random = new Random();
            Log.message( "Creating all the Groups with Random Names" );
            for ( String groupName : groupAsciiNames ) {
                List<String> studentRumbaIds = new ArrayList<String>();
                HashMap<String, String> groupDetailsMap = new HashMap<>();
                groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( userName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, groupName + random );
                new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );
            }
        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }

        // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {
            // Logging in and goes to group tab LoginPage 
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( userName, passWord, true );
            Log.message( "Logged in as " + userName + "/" + passWord );
            GroupPage groupPageObject = tHomePage.topNavBar.navigateToGroupsTab();

            List<String> actualGroupList = groupPageObject.getGroupNames();
            List<String> groupsAfterSort = groupPageObject.getGroupNames();
            Collections.sort( groupsAfterSort );
            SMUtils.logDescriptionTC( "SMK-7192 : Verify the list of groups sorted in ascending order with group name by default" );
            SMUtils.logDescriptionTC( "SMK-7195 : Verify the up arrow displayed in group name header." );
            SMUtils.logDescriptionTC( "SMK-7194 : Verify the groups are sorted in ascending order by name." );
            SMUtils.logDescriptionTC( "SMK-7199 : Verify the arrow direction is up when the sorting is ascending order." );
            SMUtils.logDescriptionTC( "SMK-7231 : Verify the display order when the teacher having the group names with numericals and valid text input" );

            String arrowOrder = groupPageObject.getArrowStateOfColumn();
            String columnName = groupPageObject.getColumnNameOfArrow();
            Log.assertThat( arrowOrder.equals( Constants.ASCENDING ), "The arrow  is in upward direction!", "The arrow is not in upward direction" );
            Log.assertThat( columnName.equals( Groups.COLUMN_GROUP_NAME ), "The Column header of the Arrow is as Expected!", "The column header is not matching" );
            Log.assertThat( groupsAfterSort.equals( actualGroupList ), "The Ascending order sort is matching", "The Asceding order sorting is not matching" );

            SMUtils.logDescriptionTC( "SMK-7193 : Verify the groups are sorted in descending order by name" );
            SMUtils.logDescriptionTC( "Verify the group is sorted descending order when the teacher clicks the arrow button." );
            SMUtils.logDescriptionTC( "SMK-7197 : Verify the up arrow changed as down arrow when the user clicks the up arrow in group name header." );
            SMUtils.logDescriptionTC( "SMK-7198 : Verify the arrow direction is down when the sorting is descending order." );

            // sorting by descending
            groupPageObject.clickColumnnAndSort( Groups.COLUMN_GROUP_NAME, Constants.DESCENDING );
            arrowOrder = groupPageObject.getArrowStateOfColumn();
            columnName = groupPageObject.getColumnNameOfArrow();
            List<String> actualList = groupPageObject.getGroupNames();

            List<String> groupsNamesAfterSort = groupPageObject.getGroupNames();
            Collections.sort( groupsNamesAfterSort, Collections.reverseOrder() );
            Log.assertThat( arrowOrder.equals( Constants.DESCENDING ), "The arrow  is in down direction!", "The arrow is not in down direction" );
            Log.assertThat( columnName.equals( Groups.COLUMN_GROUP_NAME ), "The Column header of the Arrow is as Expected!", "The column header is not matching" );

            Log.assertThat( actualList.equals( groupsNamesAfterSort ), "The Descending order sort is matching", "The Descending order sorting is not matching" );

            SMUtils.logDescriptionTC( "SMK-7226 : Verify the order change and navigate to other tab and validate the display of order " );
            tHomePage.topNavBar.navigateToStudentsTab();
            tHomePage.topNavBar.navigateToGroupsTab();
            arrowOrder = groupPageObject.getArrowStateOfColumn();
            columnName = groupPageObject.getColumnNameOfArrow();
            Log.assertThat( arrowOrder.equals( Constants.DESCENDING ), "The arrow  is in upward direction!", "The arrow is not in upward direction" );
            Log.assertThat( columnName.equals( Groups.COLUMN_GROUP_NAME ), "The Column header of the Arrow is as Expected!", "The column header is not matching" );

            SMUtils.logDescriptionTC( "SMK-7200 : Verify the groups are sorted in descending order based on students count" );
            SMUtils.logDescriptionTC( "SMK-7201 : Verify the arrow icon moved to students count when the user clicks the students count header." );
            // sorting by desc
            List<Integer> studentCountAfterSort = groupPageObject.getListofNoOfStudnets();
            Collections.sort( studentCountAfterSort, Collections.reverseOrder() );
            groupPageObject.clickColumnnAndSort( Groups.COLUMN_NO_OF_STUDENTS, Constants.DESCENDING );
            arrowOrder = groupPageObject.getArrowStateOfColumn();
            columnName = groupPageObject.getColumnNameOfArrow();
            List<Integer> actualListStudentsCount = groupPageObject.getListofNoOfStudnets();
            Log.assertThat( arrowOrder.equals( Constants.DESCENDING ), "The arrow  is in down direction!", "The arrow is not in down direction" );
            Log.assertThat( columnName.equals( Groups.COLUMN_NO_OF_STUDENTS ), "The Column header of the Arrow is as Expected!", "The column header is not matching" );
            Log.assertThat( actualListStudentsCount.equals( studentCountAfterSort ), "The Descending order sort is matching", "The Descending order sorting is not matching" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Group listing page color checking", priority = 1, groups = { "SMK-39180", "Groups", "Group Listing" } )
    public void tcSMGroupListing_007() throws Exception {
    	 // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {

            // Loggin in and goes to group tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( userName, passWord, true );

            GroupPage groupPageObject = tHomePage.topNavBar.navigateToGroupsTab();
            // view group button 
            SMUtils.logDescriptionTC( "SMK-7191 : Verify the create group button is in blue color." );
            Log.assertThat( SMUtils.checkBackgroundColor( groupPageObject.getCreateGroupButton(), Groups.CREATE_A_GROUP_COLOR ), "Create Group button color matches", "Create Group button color doesnot matches" );

            SMUtils.logDescriptionTC( "SMK-7225 : Verify the default sequence when new group was added" );
            groupPageObject.createGroupWithoutStudent( "NewGroup" );

            List<String> actualGroupList = groupPageObject.getGroupNames();
            groupPageObject.clickColumnnAndSort( Groups.COLUMN_GROUP_NAME, Constants.ASCENDING );
            Collections.sort( actualGroupList );
            List<String> groupsAfterSort = groupPageObject.getGroupNames();
            Log.assertThat( groupsAfterSort.equals( actualGroupList ), "The Ascending order sort is matching", "The Asceding order sorting is not matching" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "Verify that the group is displayed if the class is mapped with multiple teachers associated", priority = 1, groups = { "SMK-54902", "Groups", "Group Listing" } )
    public void tcSMGroupListing_008() throws Exception {
        
    	// Creating Group
    	String groupName = "Group with Multiple Teachers";
    	
    	HashMap<String, String> groupDetailsMap = new HashMap<>();
    	groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( userName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
    	groupDetailsMap.put( RBSDataSetupConstants.USERNAME, userName );
    	groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
    	groupDetailsMap.put( RBSDataSetupConstants.SECTION_NAME, groupName );
    	groupDetailsMap.put( RBSDataSetupConstants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );
    	String grpIDWithMultipleTeacher =  new RBSUtils().createClassWithMultipleTeacher( groupDetailsMap, teacherRumbaIds, studentRumbaIds );
    	Log.message(grpIDWithMultipleTeacher);
        String accessToken1 = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        JSONObject jsonnObject2 = new JSONObject( grpIDWithMultipleTeacher );
        String classId1 = jsonnObject2.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();

    	String addProductToClassGraphQL = new RBSUtils().addProductToClassGraphQL(groupDetailsMap.get(RBSDataSetupConstants.ORGANIZATION_ID), classId1, configProperty.getProperty(ConfigConstants.FLEXPRODUCT), accessToken1, teacherId1);
        Log.message(addProductToClassGraphQL); 
        // Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {

            // Logging in as Teacher1 and goes to group tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( userName, passWord, true );
            GroupPage groupPageObject = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat(groupPageObject.isGroupExist(groupName), "Pass! Class with Multiple teachers is displayed", "Failed!! Class with Multiple teachers is not get displayed");
            groupPageObject.viewGroup(groupName);
            groupPageObject.clickSettingsSubNav();
            groupPageObject.deleteGroup(groupName);
            //deleteGroup(  classId1,  teacherRumbaIds.get(0),groupDetailsMap.get(RBSDataSetupConstants.ORGANIZATION_ID), String accessToken )
            Log.assertThat( !groupPageObject.isGroupExist(groupName), "Pass! Deleted group is not displayed for Teacher1", "Failed!!!Deleted group is get displayed for Teacher1");
            tHomePage.topNavBar.signOutfromSM();
            driver.close();
            
            
            // Logging in as Teacher2 and goes to group tab
            // Get driver
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
            driver.register(eventListner);
            LoginPage smLoginPage1 = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage1 = smLoginPage1.loginToSM( userName1, passWord, true );
            GroupPage groupPageObject1 = tHomePage1.topNavBar.navigateToGroupsTab();
            Log.assertThat(!groupPageObject1.isGroupExist(groupName), "Pass! Deleted group is not gett displayed for Teacher2", "Failed!!!!!Deleted group is get displayed for Teacher2");

    
            // SignOut from SM
            tHomePage1.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "SMK-54902: Verify that google classes are displayed in the group listing", priority = 1, groups = { "SMK-54902", "Groups", "Group Listing" } )
    public void tcSMGroupListing_009() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {

    		// Logging in and goes to group tab
    		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( GoogleTeacherusername, passWord, true );

            GroupPage groupPageObject = tHomePage.topNavBar.navigateToGroupsTab();
            String GoogleClassName = "Google Class Test Group";
            Log.message(GoogleClassName);
            Log.assertThat(groupPageObject.isGroupExist(GoogleClassName), "Google classes are displayed in Group Listing", "Google classes are not displayed in Group Listing");
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }
    
    @Test ( description = "SMK-54902: Verify that count is updated based on the number of students.If student removed the count should be reduced,if the student added count should be increased", priority = 1, groups = { "SMK-54902", "Groups", "Group Listing" } )
    public void tcSMGroupListing_010() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {

    		// Logging in and goes to group tab
        	//groupPageObject = new GroupPage( driver );
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM(userName, passWord, true );
            GroupPage groupPageObject = tHomePage.topNavBar.navigateToGroupsTab();
           
            // Creating Group
            String groupName = "Validating Student Count Group";
            groupPageObject.createGroup(groupName, studentUserNames);
            
            String initialstudentCount = groupPageObject.getStudentsCount(groupName);
            Log.message(initialstudentCount);
            int initialstudentCount1 =  Integer.parseInt(initialstudentCount);
            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();
            studentTab.clickviewStudentByEllipsis(studentOne);
            //studentTab.clickRemoveStudentToGroupText(groupName);
            //studentTab.clickRemovebuttonForGroup(groupName);
            studentTab.removeStudentFromAllGroups();
            GroupPage navigateToGroupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            String studentCountAfterDeleting =  navigateToGroupsTab.getStudentsCount(groupName);
            Log.message(studentCountAfterDeleting);
            int studentCountAfterDeleting1 =  Integer.parseInt(studentCountAfterDeleting);
            Log.assertThat(initialstudentCount1>studentCountAfterDeleting1, "Test Passed!!", "Test Failed!!");
              
            
           
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    public void deleteAllGroupsByAPI() throws Exception {

        RBSDataSetup data = new RBSDataSetup();

        HashMap<String, String> groupDetails = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( userName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.STAFF_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );

        HashMap<String, String> groupListingForTeacherID = new GroupAPI().getGroupListingForTeacherID( smUrl, groupDetails );

        data.deleteAllGroupUnderTeacher( groupListingForTeacherID.get( Constants.REPORT_BODY ), groupDetails.get( GroupConstants.GROUP_OWNER_ID ), groupDetails.get( GroupConstants.GROUP_OWNER_ORG_ID ),
                new RBSUtils().getAccessToken( userName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

    }

    /**
     * To get the List of Random Text
     * 
     * @param int size of List
     * @return
     */
    public List<String> getListOfRandomText( int size ) {
        List<String> groupAsciiNames = new ArrayList<String>();
        IntStream.rangeClosed( 1, size ).forEach( element -> {
            groupAsciiNames.add( getSaltString() );
        } );
        return groupAsciiNames;
    }

    protected static String getSaltString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while ( salt.length() < 7 ) { // length of the random string.
            int index = (int) ( rnd.nextFloat() * SALTCHARS.length() );
            salt.append( SALTCHARS.charAt( index ) );
        }
        String saltStr = salt.toString();
        return saltStr;
    }
}
