package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class GroupsUsersListTest extends BaseTest {

    private String smUrl;
    private String browser;
    //private String groupDetails;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String school;
    private String groupDetails;
    private String student1;
    private String student2;

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        student1 = RBSDataSetup.getMyStudent( school, username );
        student2 = RBSDataSetup.getMyStudent( school, username );
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student1, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( student2, RBSDataSetupConstants.USERID ) );
        HashMap<String, String> groupDetailsMap = new HashMap<>();
        groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, "SM Regression Group" + System.nanoTime() );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );
        groupDetails = createGroup.get( Constants.BODY );
    }

    @Test ( description = "SMK-8690 - Verify by clicking View group button, teacher is able to see respective group name as title", priority = 1 )
    public void tcSMK8690( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "data,groupName" );
    	Log.testCaseInfo( "tcSMK-8690: Verify by clicking View group button, teacher is able to see respective group name as title <small><b><i>[" + browser + "]</b></i></small>" );
    	try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            // Navigate to Groups Tab
            groupsTab.viewGroup( groupName );
            Log.assertThat( groupsTab.getGroupHeaderName().equals( groupName ), "The title of the view group page is matching with group name", "The title of the view group page is not matching with group name" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-8691 - Verify a teacher accesses the details of a group, list of all the users associated to the group is loaded", priority = 2 )
    public void tcSMK8691( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "data,groupName" );
    	Log.testCaseInfo( "tcSMK-8691: Verify a teacher accesses the details of a group, list of all the users associated to the group is loaded <small><b><i>[" + browser + "]</b></i></small>" );

        String student1_UserName = SMUtils.getKeyValueFromResponse( student1, RBSDataSetupConstants.USERNAME );
        String student2_UserName = SMUtils.getKeyValueFromResponse( student2, RBSDataSetupConstants.USERNAME );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            String student1_UserName_App = groupsTab.getStudentDetailsBasedOnGroup( groupName ).get( "Student1" ).get( "userName" );
            String student2_UserName_App = groupsTab.getStudentDetailsBasedOnGroup( groupName ).get( "Student2" ).get( "userName" );
            Log.assertThat( ( student1_UserName_App.equals( student1_UserName ) | student1_UserName_App.equals( student2_UserName ) ), "The user " + student1_UserName + " associated to the group is displayed in users table",
                    "The user " + student1_UserName + " associated to the group is not displayed in users table" );
            Log.assertThat( ( student2_UserName_App.equals( student1_UserName ) | student2_UserName_App.equals( student2_UserName ) ), "The user " + student2_UserName + " associated to the group is displayed in users table",
                    "The user " + student2_UserName + " associated to the group is not displayed in users table" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-8692 - Verify by clicking on Users sub tab,list of all the users associated to the group is loaded", priority = 3 )
    public void tcSMK8692( ITestContext context ) throws Exception {
        List<String> userTableExpected = Arrays.asList( "First Name", "Last Name", "Username", "Student ID", "Grade" );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "data,groupName" );
        Log.testCaseInfo( "tcSMK-8692: Verify by clicking on Users sub tab,list of all the users associated to the group is loaded <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            List<String> headerValues = groupsTab.getUsersTabTableHeader();
            Log.assertThat( SMUtils.compareTwoList( headerValues, userTableExpected ), "The Users table headers are displayed correctly", "The Users table headers are not displayed correctly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-8693 - Validate the student details present on Group Users list", priority = 4 )
    public void tcSMK8693( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "data,groupName" );
        Log.testCaseInfo( "tcSMK-8693: Validate the student details present on Group Users list <small><b><i>[" + browser + "]</b></i></small>" );
        String student1_UserName = SMUtils.getKeyValueFromResponse( student1, RBSDataSetupConstants.USERNAME );
        String student1_FirstName = SMUtils.getKeyValueFromResponse( student1, RBSDataSetupConstants.FIRSTNAME );
        String student1_LastName = SMUtils.getKeyValueFromResponse( student1, RBSDataSetupConstants.LASTNAME );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            HashMap<String, HashMap<String, String>> studDetailsApp = groupsTab.getStudentDetailsBasedOnGroup( groupName );
            Log.assertThat( studDetailsApp.get( "Student1" ).get( "userName" ).equals( student1_UserName ) | studDetailsApp.get( "Student2" ).get( "userName" ).equals( student1_UserName ), "The userName " + student1_UserName + " is displayed correctly",
                    "The userName " + student1_UserName + " is not displayed correctly" );
            Log.assertThat( studDetailsApp.get( "Student1" ).get( "firstName" ).equals( student1_FirstName ) | studDetailsApp.get( "Student2" ).get( "firstName" ).equals( student1_FirstName ),
                    "The FirstName " + student1_FirstName + " is displayed correctly", "The FirstName  " + student1_FirstName + " is is not displayed correctly" );
            Log.assertThat( studDetailsApp.get( "Student1" ).get( "lastName" ).equals( student1_LastName ) | studDetailsApp.get( "Student2" ).get( "lastName" ).equals( student1_LastName ), "The LastName " + student1_LastName + " is displayed correctly",
                    "The LastName  " + student1_LastName + " is is not displayed correctly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-8694 - Create new group with multiple user and verify by clicking on Users sub tab,list of all the users associated to the group is loaded", priority = 5 )
    public void tcSMK8694( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "data,groupName" );

        String student1_UserName = SMUtils.getKeyValueFromResponse( student1, RBSDataSetupConstants.USERNAME );
        String student1_FirstName = SMUtils.getKeyValueFromResponse( student1, RBSDataSetupConstants.FIRSTNAME );
        String student1_LastName = SMUtils.getKeyValueFromResponse( student1, RBSDataSetupConstants.LASTNAME );

        String student2_UserName = SMUtils.getKeyValueFromResponse( student2, RBSDataSetupConstants.USERNAME );
        String student2_FirstName = SMUtils.getKeyValueFromResponse( student2, RBSDataSetupConstants.FIRSTNAME );
        String student2_LastName = SMUtils.getKeyValueFromResponse( student2, RBSDataSetupConstants.LASTNAME );

        Log.testCaseInfo( "tcSMK-8694: Create new group with multiple user and verify by clicking on Users sub tab,list of all the users associated to the group is loaded <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            HashMap<String, HashMap<String, String>> studDetailsApp = groupsTab.getStudentDetailsBasedOnGroup( groupName );
            //Verifying Student 1 Details
            Log.assertThat( studDetailsApp.get( "Student1" ).get( "userName" ).equals( student1_UserName ) | studDetailsApp.get( "Student2" ).get( "userName" ).equals( student1_UserName ), "The userName " + student1_UserName + " is displayed correctly",
                    "The userName " + student1_UserName + " is not displayed correctly" );
            Log.assertThat( studDetailsApp.get( "Student1" ).get( "firstName" ).equals( student1_FirstName ) | studDetailsApp.get( "Student2" ).get( "firstName" ).equals( student1_FirstName ),
                    "The FirstName " + student1_FirstName + " is displayed correctly", "The FirstName  " + student1_FirstName + " is is not displayed correctly" );
            Log.assertThat( studDetailsApp.get( "Student1" ).get( "lastName" ).equals( student1_LastName ) | studDetailsApp.get( "Student2" ).get( "lastName" ).equals( student1_LastName ), "The LastName " + student1_LastName + " is displayed correctly",
                    "The LastName  " + student1_LastName + " is is not displayed correctly" );
            //Verifying Student 2 Details
            Log.assertThat( studDetailsApp.get( "Student2" ).get( "userName" ).equals( student2_UserName ) | studDetailsApp.get( "Student1" ).get( "userName" ).equals( student2_UserName ), "The userName " + student1_UserName + " is displayed correctly",
                    "The userName " + student1_UserName + " is not displayed correctly" );
            Log.assertThat( studDetailsApp.get( "Student2" ).get( "firstName" ).equals( student2_FirstName ) | studDetailsApp.get( "Student1" ).get( "firstName" ).equals( student2_FirstName ),
                    "The FirstName " + student1_FirstName + " is displayed correctly", "The FirstName  " + student1_FirstName + " is is not displayed correctly" );
            Log.assertThat( studDetailsApp.get( "Student2" ).get( "lastName" ).equals( student2_LastName ) | studDetailsApp.get( "Student1" ).get( "lastName" ).equals( student2_LastName ), "The LastName " + student1_LastName + " is displayed correctly",
                    "The LastName  " + student1_LastName + " is is not displayed correctly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-8696 : Note: If the group is not Easy Bride integrated Verify 'Add Students to Group' link present on Group Users details page when the group has no students", priority = 6 )
    public void tcSMK8696( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "data,groupName" );
    	Log.testCaseInfo( "tcSMK-8696 : Note: If the group is not Easy Bride integrated Verify 'Add Students to Group' link present on Group Users details page when the group has no students <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            WebElement addBtn = groupsTab.getUsersSubnavAddStudentsToGroupBtn();
            Log.assertThat( addBtn.isDisplayed(), "The 'Add Students to Group' button is displayed", "The 'Add Students to Group' button is not displayed" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-8699 & SMK-8700 - Verify 'NO DATA YET' message and Add Students to Group link is displaying, if no user is associated to the group", priority = 7 )
    public void tcSMK8699( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMK-8699 : Verify 'NO DATA YET' message and Add Students to Group link is displaying, if no user is assciated to the group <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            String groupName = "RegGroup " + System.nanoTime();
            groupsTab.createGroupWithoutStudent( groupName );
            groupsTab.viewGroup( groupName );
            Map<String, String> noDataValues = groupsTab.getUsersSubNavNoDataValues();
            Log.assertThat( noDataValues.get( "header" ).equals( Constants.GroupUIConstants.ZEROSTATE_HEADER ), "The header '" + Constants.GroupUIConstants.ZEROSTATE_HEADER + "'  is displayed in Users subnav tab when no students in the Group",
                    "The header '" + Constants.GroupUIConstants.ZEROSTATE_HEADER + "' message is not displayed in Users subnav tab when no students in the Group" );
            Log.assertThat( noDataValues.get( "msg" ).equals( Constants.GroupUIConstants.ZEROSTATE_MESSAGE ), "The message '" + Constants.GroupUIConstants.ZEROSTATE_MESSAGE + "'  is displayed in Users subnav tab when no students in the Group",
                    "The message '" + Constants.GroupUIConstants.ZEROSTATE_MESSAGE + "' is not displayed in Users subnav tab when no students in the Group" );
            Log.assertThat( noDataValues.get( "link" ).equals( Constants.GroupUIConstants.ZEROSTATE_LINK ), "The link '" + Constants.GroupUIConstants.ZEROSTATE_LINK + "' is displayed in Users subnav tab when no students in the Group",
                    "The link '" + Constants.GroupUIConstants.ZEROSTATE_LINK + "' is not displayed in Users subnav tab when no students in the Group" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}