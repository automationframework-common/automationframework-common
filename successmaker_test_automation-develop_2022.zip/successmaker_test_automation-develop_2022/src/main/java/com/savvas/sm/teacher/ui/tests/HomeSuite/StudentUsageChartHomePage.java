package com.savvas.sm.teacher.ui.tests.HomeSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.RestAssuredAPI;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Students;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentUsage;
import com.savvas.sm.utils.sql.helper.FixupFunction;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.restassured.response.Response;

public class StudentUsageChartHomePage extends BaseTest {
    String smUrl;
    String browser;
    String username;
    String password = "testing123$";
    String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    String studentOneUsername;
    String studentTwoUsername;
    String studentThreeUsername;
    String orgId;
    String teacherId;
    RBSUtils rbsUtils = new RBSUtils();
    List<String> assignmentIdList = new ArrayList<String>();
    HashMap<String, HashMap<String, HashMap<String, Integer>>> usageHoursList = new HashMap<>();
    HashMap<String, HashMap<String, Integer>> individualFieldsList = new HashMap<>();
    public  String isItMt = null;

    @BeforeClass
    public void initTest( ITestContext context ) throws IOException {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host 
        String usernameSuffix = envUrl.split( "\\." )[0];
        String usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );
        username = String.format( configProperty.getProperty( ConfigConstants.TEACHER_USERNAME ), 5, 1, usernameSuffixTest );

        orgId = rbsUtils.getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        studentOneUsername = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 5, 1, 1, usernameSuffixTest );
        studentTwoUsername = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 5, 1, 2, usernameSuffixTest );
        studentTwoUsername = String.format( configProperty.getProperty( ConfigConstants.STUDENT_USERNAME ), 5, 1, 3, usernameSuffixTest );

        teacherId = rbsUtils.getUserIDByUserName( username );
        
        // Running fix-up query to get previous week data
        FixupFunction.executeFixupFunctions( orgId );
        isItMt = configProperty.getProperty( "isMTExecution" );
    }

    @Test ( description = "Verify 'NO DATA YET' message  shown if the student not  attended any course", groups = { "SMK-38826", "usageChart", "homePageStudentUsageChart" }, priority = 1 )
    public void tcSMHomePageStudentUsage001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMHomePageStudentUsage001: Verify 'NO DATA YET' message  shown if the student not  attended any course <small><b><i>[" + browser + "]</b></i></small>" );
        
        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( createTeacher(), password, true );

            SMUtils.logDescriptionTC( "SMk-10892 - Verify 'NO DATA YET' message  shown if the student not  attended any course" );
            //Verify zero state message for student usage chart
            Log.assertThat( teacherHomePage.verifyZeroStateForStudentUsageChart(), "Zero state message displayed sucessfully!", "Zero state message is not displayed properly." );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Teacher can view the  student usage chart on the  homepage.", groups = { "SMK-38826", "usageChart", "homePageStudentUsageChart" }, priority = 1 )
    public void tcSMHomePageStudentUsage002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMHomePageStudentUsage002: Verify Teacher can view the  student usage chart on the  homepage. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-10884 - Verify Teacher can view the  student usage chart on the  homepage." );
            //Verify student usage chart fields
            Log.assertThat( teacherHomePage.verifyStudentUsageChart(), "All fields displayed properly in student usage chart!", "Fields are not displayed properly in student usage chart." );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the chart is shown to the  student if he has attended any  course", groups = { "SMK-38826", "usageChart", "homePageStudentUsageChart" }, priority = 1 )
    public void tcSMHomePageStudentUsage003() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMHomePageStudentUsage003: Verify the chart is shown to the  student if he has attended any course <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-10893 - Verify the chart is shown to the  student if he has attended any  course" );
            
            getUsageDataFromAPI( Arrays.asList( getAssignmentId( "1" ) ) );
            teacherHomePage.loadUsageForParticularAssignments( Arrays.asList(  Constants.MATH  ) );

            //Verify usage chart individual field values
            Log.assertThat( teacherHomePage.verifyStudentUsageChartFieldsData( individualFieldsList.get( "individualFields" ) ), "All fields data displayed properly in student usage chart!", "Fields data are not displayed properly in student usage chart." );

            //Verify usage chart data
            Log.assertThat( teacherHomePage.verifyStudentUsageGraph( usageHoursList.get( "usageHours" ) ), "Student usage graph data displayed properly", "Student usage graph not data displayed properly!" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student usage chart when Math assignments selected", groups = { "SMK-38826", "usageChart", "homePageStudentUsageChart" }, priority = 2 )
    public void tcSMHomePageStudentUsage004() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMHomePageStudentUsage004: Verify the Student usage chart when Math assignments selected <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            //Selecting Assignments in Assignment dropdown
            teacherHomePage.loadUsageForParticularAssignments( Arrays.asList(  Constants.MATH  ) );
            HashMap<String, HashMap<String, Integer>> usageHoursForMathAlone = new HashMap<>();
            List<String> EightWeeksMonday = TeacherHomePage.getEightWeeksMonday();

            getUsageDataFromAPI( Arrays.asList( getAssignmentId( "1" ) ) );
            
            EightWeeksMonday.forEach( week -> {
                HashMap<String, Integer> hoursByWeek = new HashMap<>();
                
                hoursByWeek.put( Constants.UsageChart.MATH, usageHoursList.get( "usageHours" ).get( week ).get( Constants.UsageChart.MATH ) );
                hoursByWeek.put( Constants.UsageChart.READING, 0 );
                hoursByWeek.put( Constants.UsageChart.TOTAL, usageHoursList.get( "usageHours" ).get( week ).get( Constants.UsageChart.MATH ) );
                usageHoursForMathAlone.put( week, hoursByWeek );
            } );
            Log.message( usageHoursForMathAlone +"");
            SMUtils.logDescriptionTC( "SMK-10888 -Verify the Student usage chart when Math assignments selected" );
            //verify Usage chart for Math alone
            Log.assertThat( teacherHomePage.verifyStudentUsageGraph( usageHoursForMathAlone ), "Student usage graph data displayed properly", "Student usage graph not data displayed properly!" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Student usage chart when reading assignments selected", groups = { "SMK-38826", "usageChart", "homePageStudentUsageChart" }, priority = 2 )
    public void tcSMHomePageStudentUsage005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMHomePageStudentUsage005: Verify the Student usage chart when reading assignments selected <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            teacherHomePage.loadUsageForParticularAssignments( Arrays.asList(  Constants.READING  ) );
            HashMap<String, HashMap<String, Integer>> usageHoursForReadingAlone = new HashMap<>();
            List<String> EightWeeksMonday = TeacherHomePage.getEightWeeksMonday();

            getUsageDataFromAPI( Arrays.asList( getAssignmentId( "2" ) ) );

            EightWeeksMonday.forEach( week -> {
                HashMap<String, Integer> hoursByWeek = new HashMap<>();
                hoursByWeek.put( Constants.UsageChart.READING, usageHoursList.get( "usageHours" ).get( week ).get( Constants.UsageChart.READING ) );
                hoursByWeek.put( Constants.UsageChart.MATH, 0 );
                hoursByWeek.put( Constants.UsageChart.TOTAL, usageHoursList.get( "usageHours" ).get( week ).get( Constants.UsageChart.READING ) );
                usageHoursForReadingAlone.put( week, hoursByWeek );
            } );

            SMUtils.logDescriptionTC( "SMK-10889 - Verify the Student usage chart when reading assignments selected" );
            //verify Usage chart for Reading alone
            Log.assertThat( teacherHomePage.verifyStudentUsageGraph( usageHoursForReadingAlone ), "Student usage graph data displayed properly", "Student usage graph not data displayed properly!" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify if other teacher student has been added to the current teacher the student usage should display all students assignments usage", groups = { "SMK-38826", "usageChart",
            "homePageStudentUsageChart" }, priority = 2 )
    public void tcSMHomePageStudentUsage006() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMHomePageStudentUsage006: Verify if other teacher student has been added to the current teacher  the student usage should display all students assignments usage <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( createTeacher(), password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            String groupName = "Atutomation" + System.nanoTime();
            groupsTab.createGroupWithSchoolStudents( groupName, Arrays.asList( studentOneUsername, studentTwoUsername ), "All Grades" );

            // navigate to Home Page
            teacherHomePage.topNavBar.navigateToHomeTab();

            SMUtils.logDescriptionTC( "SMK-10919 - Verify if other teacher student has been added to the current teacher the student usage should display all students assignments usage" );
            //Verify student usage chart fields
            Log.assertThat( teacherHomePage.verifyStudentUsageChart(), "Student usage graph data displayed properly", "Student usage graph not data displayed properly!" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify if student assignment is deleted, then student usage will not show usage hours ", groups = { "SMK-38826", "usageChart", "homePageStudentUsageChart" }, priority = 2 )
    public void tcSMHomePageStudentUsage007() throws Exception {
		
        String cutomMathSettingAssignment = "Custom Math Course - 54840785079400"; //"Custom Math Course - " + System.nanoTime();
       
        String accessToken = getAccessToken( username, password );
        String courseId = new CourseAPI().createCourse( smUrl, accessToken, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, cutomMathSettingAssignment );
        Log.message( courseId );
        
        HashMap<String, String> assignmentDetails = new HashMap<>();
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );

        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( rbsUtils.getUserIDByUserName( studentOneUsername), rbsUtils.getUserIDByUserName( studentTwoUsername) ), Arrays.asList( courseId ) );
        Log.message( "Assignment Details" + assignmentResponse );

        executeSimulator( studentOneUsername, Constants.MATH,cutomMathSettingAssignment );

        // Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMHomePageStudentUsage007: Verify if student assignment is deleted, then student usage will not show usage hours. <small><b><i>[" + browser + "]</b></i></small>" );
        
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentPage.sortingColumnnHeaders( Students.COLUMN_USER_NAME );
            studentPage.clickFirstStudent();
            studentPage.clickSubNavigation( "Assignments" );
            studentPage.removeStudentFromAssignment( cutomMathSettingAssignment );

            // navigate to Home Page
            teacherHomePage.topNavBar.navigateToHomeTab();

            SMUtils.logDescriptionTC( "SMK-10921 - Verify if student assignment is deleted, then student usage will not show usage hours " );
            //Verify Zero state message after deleting assignment
            teacherHomePage.loadUsageForParticularAssignments(Arrays.asList( cutomMathSettingAssignment ) );

            Log.assertThat( teacherHomePage.verifyZeroStateForStudentUsageChart(), "Zero state message displayed sucessfully after delete the assignments!", "Zero state message is not displayed properly after delete the assignments." );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Assignments DropDown on Student Usage.", groups = { "SMK-38826", "usageChart", "homePageStudentUsageChart" }, priority = 3 )
    public void tcSMHomePageStudentUsage008() throws Exception {
    	EventFiringWebDriver driver = null;

        Log.testCaseInfo( "tcSMHomePageStudentUsage008: Verify Assignments DropDown on Student Usage. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            //executeSimulator();

    		// Get driver
    		driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    		EventListener eventListner = new EventListener();
    		driver.register(eventListner);

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-10891 - Verify Student Usage chart details when user select few reading assignments." );
            teacherHomePage.loadUsageForParticularAssignments( Arrays.asList( Constants.READING ) );

            SMUtils.logDescriptionTC( "SMK-10911 - Verify the chart shows only reading assignment information if student attends only reading assignment" );
            SMUtils.logDescriptionTC( "SMK-10913 - Verify the chart when student has  information for current week alone" );
            // Verify student usage graph data
            Log.assertThat( ( !teacherHomePage.isStudentUsageMathBarDisplayed() ) && teacherHomePage.isStudentUsageReadingBarDisplayed(), "The chart showed only reading assignment information if student attends only reading assignment",
                    "The chart not showed only reading assignment information if student attends only reading assignment" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-10902 - Verify the chart columns for each week which shows reading at the bottom and math at the top" );
            SMUtils.logDescriptionTC( "SMK-10917 - Verify the color code of reading and math assignment in the chart" );
            Log.assertThat( teacherHomePage.getOrderOfSubjectinUsageGraph().get( 0 ).equals( Constants.READING ), "The chart displayed the reading at bottom", "The chart not displayed the reading at bottom" );
            Log.assertThat( teacherHomePage.getOrderOfSubjectinUsageGraph().get( 1 ).equals( Constants.MATH ), "The chart displayed the math at top", "The chart not math the reading at top" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-10918 - Verify the order of the legends  in the chart" );
            List<String> legends = teacherHomePage.getLegends();
            Log.assertThat( legends.get( 0 ).equals( Constants.MATH ) && legends.get( 1 ).equals( Constants.READING ), "Legends are displayed in proper order.", "Legends are not displayed in proper order" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the chart shows only math  assignment information if student attends only math assignment", groups = { "SMK-38826", "usageChart", "studentUsageChart" }, priority = 3 )
    public void tcSMHomePageStudentUsage009() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMStudentUsage009: Verify the chart shows only math  assignment information if student attends only math assignment <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-10890 - Verify Student Usage chart details  when user select few maths  assignments." );

            //Selecting Assignments in Assignment dropdown
            teacherHomePage.loadUsageForParticularAssignments( Arrays.asList( Constants.MATH ) );

            HashMap<String, HashMap<String, Integer>> usageHoursForMathAlone = new HashMap<>();
            List<String> EightWeeksMonday = TeacherHomePage.getEightWeeksMonday();
            getUsageDataFromAPI( Arrays.asList( getAssignmentId( "1" ) ) );

            EightWeeksMonday.forEach( week -> {
                HashMap<String, Integer> hoursByWeek = new HashMap<>();
                hoursByWeek.put( Constants.UsageChart.MATH, usageHoursList.get( "usageHours" ).get( week ).get( Constants.UsageChart.MATH ) );
                hoursByWeek.put( Constants.UsageChart.READING, 0 );
                hoursByWeek.put( Constants.UsageChart.TOTAL, usageHoursList.get( "usageHours" ).get( week ).get( Constants.UsageChart.MATH ) );
                usageHoursForMathAlone.put( week, hoursByWeek );
            } );

            SMUtils.logDescriptionTC( "SMK-10922 - Verify if spent time is less than one  hour." );
            SMUtils.logDescriptionTC( "SMK-10894 - Verify the titles 'THIS WEEK', 'LAST WEEK' and 'SCHOOL YEAR' are shown in capital letters" );
            SMUtils.logDescriptionTC( "SMK-10895 - Verify the titles 'THIS WEEK', 'LAST WEEK' and 'SCHOOL YEAR' are  shown as like disabled state" );
            SMUtils.logDescriptionTC( "SMK-10899 - Verify the Math and Reading  legends are shown in the student  usage" );
            //Verify  student usage chart fields
            Log.assertThat( teacherHomePage.verifyStudentUsageChart(), "All fields displayed properly in student usage chart!", "Fields are not displayed properly in student usage chart." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-10903 - Verify the THIS WEEK information shows the sum of reading and math assignments" );
            SMUtils.logDescriptionTC( "SMK-10904 - Verify the LAST WEEK information  shows the sum of reading and  math assignments usage of last week" );
            SMUtils.logDescriptionTC( "SMK-10905 - Verify the SCHOOL YEAR  information shows the sum of reading and math assignments usage of entire school year" );
            SMUtils.logDescriptionTC( "SMK-10906 - Verify the hours of reading and  math courses are shown correctly in the chart" );
            SMUtils.logDescriptionTC( "SMK-10896 - Verify 'THIS WEEK' hours show in hours" );
            SMUtils.logDescriptionTC( "SMK-10897 - Verify 'LAST WEEK' hours show in hours" );
            SMUtils.logDescriptionTC( "SMK-10898 - Verify 'SCHOOL YEAR' hours show in hours" );
            //Verify This week, Last week and School year in
            Log.assertThat( teacherHomePage.verifyStudentUsageChartFieldsData( individualFieldsList.get( "individualFields" ) ), "All fields data displayed properly in student usage chart!", "Fields data are not displayed properly in student usage chart." );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-10907 - Verify the Hours in the y-axis are updated based on the usage hours spent" );
            SMUtils.logDescriptionTC( "SMK-10908 - Verify when hovering the mouse  over each week chart the total time  spent for the assignment is shown" );
            SMUtils.logDescriptionTC( "SMK-10900 - Verify the date's shown on the x-axis are start of the week and  it should be Monday" );
            SMUtils.logDescriptionTC( "SMK-10901 - Verify the date's shown in the chart are in the format mm/dd" );
            SMUtils.logDescriptionTC( "SMK-10909 - Verify the total time includes all  the math courses usage when math assignments alone selected" );
            SMUtils.logDescriptionTC( "SMK-10915 - Verify the 'Hours' information has been shown on the Y-axis are dynamic based on usage hours" );
            SMUtils.logDescriptionTC( "SMK-10925 - Verify the interval between the  values in the y axis are same" );
            // Verify student usage graph data
            Log.assertThat( teacherHomePage.verifyStudentUsageGraph( usageHoursForMathAlone ), "Student usage graph data displayed properly", "Student usage graph not data displayed properly!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-10912 - Verify the chart shows only math assignment information if student attends only math assignment" );
            // Verify student usage graph data
            Log.assertThat( teacherHomePage.isStudentUsageMathBarDisplayed() && ( !teacherHomePage.isStudentUsageReadingBarDisplayed() ), "The chart showed only math assignment information if student attends only math assignment",
                    "The chart not showed only math assignment information if student attends only math assignment" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Assignments DropDown on Student Usage.", groups = { "SMK-38826", "usageChart", "studentUsageChart" }, priority = 3 )
    public void tcSMHomePageStudentUsage010() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMStudentUsage010: Verify Assignments DropDown on Student Usage. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            //navigate to assignment page
            AssignmentsPage assignmentpage = teacherHomePage.topNavBar.navigateToAssignmentsPage();

            List<String> assignmentsListFromAssignemntPage = assignmentpage.assignmentsList();
            // navigate to Home Page
            teacherHomePage.topNavBar.navigateToHomeTab();
            SMUtils.logDescriptionTC( "SMK-10886 - Verify Assignments DropDown on Student Usage." );
            Log.assertThat( teacherHomePage.getAssignmentsFromUsageWidget().containsAll( assignmentsListFromAssignemntPage ), "All assignments are listed in Assignments dropdown", "Assignments dropdown is not listed all assignments" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-10887 - Verify Apply filter button on Student Usage." );
            Log.assertThat( teacherHomePage.isApplyFilterDisplayed(), "Apply Filter button is displayed properly", "Apply Filter button is not displayed properly" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'NO DATA YET' message shown  for student usage if teacher not  having any assignments", groups = { "SMK-38826", "usageChart", "studentUsageChart" }, priority = 3 )
    public void tcSMHomePageStudentUsage011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMHomePageStudentUsage011 - Verify 'NO DATA YET' message shown  for student usage if teacher not  having any assignments. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( createTeacher(), password, true );

            SMUtils.logDescriptionTC( "SMK-10926 - Verify 'NO DATA YET' message shown  for student usage if teacher not  having any assignments" );
            //Verify zero state message for student usage chart
            Log.assertThat( teacherHomePage.verifyZeroStateForStudentUsageChart(), "Zero state message displayed sucessfully!", "Zero state message is not displayed properly." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-10927 - Verify iniatially 'Student Usage' card is selected on home page" );
            Log.assertThat( teacherHomePage.isStudentUsageToggleButtonSelected().equals( "true" ), "Student Usage card is selected on home page initially", "Student Usage card is not selected on home page initially" );
            Log.testCaseResult();
            
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    public void getUsageDataFromAPI( List<String> assignments ) throws Exception {
        Map<String, String> response = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + getAccessToken( username, password ) );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.USERID_SM_HEADER, teacherId );
        
        // InputParams
        HashMap<String, String> params = new HashMap<>();

        // end point
        String endPoint = Constants.POST_STUDENT_USAGE;
        endPoint = endPoint.replace( Constants.ORG_ID, orgId );
        endPoint = endPoint.replace( Constants.STAFF_ID, teacherId );

        //getting student usage data from API
        //response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, "" );
        
        response = getStudentUsage( smUrl, headers, teacherId, orgId, assignments, "", "" );
        
        String reponseData = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data" );
        HashMap<String, HashMap<String, Integer>> usageHours = new HashMap<>();
        HashMap<String, Integer> individualFields = new HashMap<>();
        List<String> lastEightWeeks = TeacherHomePage.getEightWeeksMonday();
        
        IntStream.range( 0, 8 ).forEach( week -> {
            HashMap<String, Integer> subjectUsage = new HashMap<>();
            JSONObject jsonObj = new JSONObject( reponseData );
            JSONArray ja = jsonObj.getJSONArray( "studentUsageData" );
            JSONObject jObj = ja.getJSONObject( week );
            subjectUsage.put( Constants.UsageChart.MATH, Integer.parseInt( jObj.get( "mathMins" ).toString() ) );
            subjectUsage.put( Constants.UsageChart.READING, Integer.parseInt( jObj.get( "readingMins" ).toString() ) );
            subjectUsage.put( Constants.UsageChart.TOTAL, subjectUsage.get( "Math" ) + subjectUsage.get( "Reading" ) );
            usageHours.put( lastEightWeeks.get( week ), subjectUsage );
        });

        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 0 ), Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, "thisWeekMins" ) ) );
        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 1 ), Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, "lastWeekMins" ) ) );
        individualFields.put( Constants.UsageChart.USAGE_FIELDS.get( 2 ), Integer.parseInt( SMUtils.getKeyValueFromResponse( reponseData, "totalMinutes" ) ) );

        Object[][] studentUsagDataFromAPI = { { usageHours, individualFields } };
        usageHoursList.put( "usageHours", usageHours );
        individualFieldsList.put( "individualFields", individualFields );
    }

    private void executeSimulator(String studentUsername, String subject, String assignment) throws Exception {

        EventFiringWebDriver chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
        EventListener eventListner = new EventListener();
        chromeDriver.register(eventListner);
        LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
        StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );

        if ( subject.equals( Constants.READING ) ) {
            studentDashboardPage.executeReadingCourse( teacherId, "Reading", "95", "5", "20" );
            studentDashboardPage.logout();
            chromeDriver.quit();
        } else {
            chromeDriver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
            eventListner = new EventListener();
            chromeDriver.register(eventListner);

            studentDashboardPage.executeMathCourse( teacherId, "Math", "95", "10", "20" );
            studentDashboardPage.logout();
            chromeDriver.quit();
        }
    }
    
    private String createTeacher() throws Exception {
        String teacherUserName = "Auto Test Teacher - " + System.nanoTime();
        HashMap<String, String> userDetails = new HashMap<>();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, teacherUserName );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
        String teacherDetail = rbsUtils.createUser( userDetails );
        rbsUtils.resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( teacherDetail, "userId" ) );
        return teacherUserName;
    }
    
    //////////////////
    
    public String getAccessToken( String userId, String password ) throws Exception {

        try {
            String rbsLoginURL = configProperty.getProperty( "rbsLoginURL" );
            String castGCEndpoint = configProperty.getProperty( "castGCEndpoint" );
            String tokenURL = configProperty.getProperty( "rbsLoginURL" );
            String tokenEndpoint = configProperty.getProperty( "tokenEndpoint" );

            Map<String, String> accessTokenHeaders = new HashMap<>();
            Map<String, String> inputData = new HashMap<>();
            accessTokenHeaders.put( "Content-Type", "application/json" );
            String body = "\n" + "{\n" + "  \"username\": \"" + userId + "\",\n" + "  \"password\": \"" + password + "\"\n" + "}";
            Response postResponseMap = RestAssuredAPI.post( rbsLoginURL, accessTokenHeaders, inputData, body, castGCEndpoint );
            JSONObject responseContent = new JSONObject( postResponseMap.getBody().asString() );
            String castgcToken = (String) responseContent.getJSONObject( "cookies" ).get( "CASTGC" );
            accessTokenHeaders.put( "Authorization", configProperty.getProperty( "CASTGC_auth" ) );
            JSONObject postBody = new JSONObject();
            postBody.put( "scope", "test" );
            postBody.put( "userId", responseContent.get( "identityId" ) );
            postBody.put( "clientId", configProperty.getProperty( "clientID" ) );
            postBody.put( "grant_type", "custom_castgc" );
            accessTokenHeaders.put( "Castgc", castgcToken );
            postResponseMap = RestAssuredAPI.post( tokenURL, accessTokenHeaders, inputData, postBody.toString(), tokenEndpoint );
            responseContent = new JSONObject( postResponseMap.getBody().asString() );
            return (String) responseContent.get( "access_token" );
        } catch ( Exception ex ) {
            ex.printStackTrace();
            Log.event( "No valid username or password found" );
            return null;
        }

    }
    
    
    public Map<String, String> getStudentUsage( String smUrl, Map<String, String> headers, String staffId, String orgId, List<String> assignmentIds, String studentId, String groupId ) throws Exception {

        try {

            // Input Params
            HashMap<String, String> params = new HashMap<>();

            String body = "{}";
            if ( !Objects.isNull( studentId ) && !studentId.isEmpty() ) {
                params.put( StudentUsage.STUDENTID, studentId );
            } else if ( !Objects.isNull( groupId ) && !groupId.isEmpty() ) {
                params.put( StudentUsage.GROUPID, groupId );
            } else {
                body = "{" + "\"" + StudentUsage.ASSIGNMENTIDS + "\":" + assignmentIds.toString() + "}";
            }

            String endpoint = StudentUsage.POST_STUDENTUSAGE;
            endpoint = endpoint.replace( "{" + Constants.STAFF_ID_VALUE + "}", staffId );
            endpoint = endpoint.replace( "{" + Constants.ORGANIZATION_ID + "}", orgId );

            //Hitting Post call for student usage
            HashMap<String, String> responseAPI = RestHttpClientUtil.POST( smUrl, headers, params, endpoint, body );
            return responseAPI;

        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }
    
    public String createCourse( String envUrl, String token, String subject, String teacherId, String orgId, String courseType, String courseName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        // Input Params
        HashMap<String, String> params = new HashMap<>();
        // EndPoint Details
        String endPoint_post = CourseAPIConstants.CREATE_CUSTOM_COURSE;
        try {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            headers.put( Constants.ORGID_SM_HEADER, orgId );

            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgId );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherId );

            HashMap<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( courseType.equalsIgnoreCase( DataSetupConstants.SETTINGS ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = rbsUtils.generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SETTING_GENERIC_MATH ), courseDetails );
                } else {
                    requestBody = rbsUtils.generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SETTING_GENERIC_READING ), courseDetails );
                }
            }
            //TODO To get RandomSkills
            else if ( courseType.equalsIgnoreCase( DataSetupConstants.SKILL ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = rbsUtils.generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SKILLS_GENERIC_MATH ), courseDetails );
                } else {
                    requestBody = rbsUtils.generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_SKILLS_GENERIC_READING ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.STANDARD ) ) {
                List<String> standardDetails = new ArrayList<>();

                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    standardDetails = UserSqlHelper.getRandomStandardGradeID( CommonAPIConstants.TEACHER, DataSetupConstants.MATH,isItMt.equalsIgnoreCase( "true" ) );
                } else {
                    standardDetails = UserSqlHelper.getRandomStandardGradeID( CommonAPIConstants.TEACHER, DataSetupConstants.READING,isItMt.equalsIgnoreCase( "true" ) );
                }

                List<String> listLO = UserSqlHelper.getLOIDsRandomStandard( CommonAPIConstants.TEACHER, standardDetails.get( 0 ), standardDetails.get( 1 ),isItMt.equalsIgnoreCase( "true" ) );
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
                courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = rbsUtils.generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_MATH ), courseDetails );
                } else {
                    requestBody = rbsUtils.generateRequestBody( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.CUSTOM_BY_STANDARDS_READING ), courseDetails );
                }

            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.ONE_LO ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = rbsUtils.generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_ONE_LO, courseDetails );
                }
            }
            response_post = RestHttpClientUtil.POST( envUrl, headers, params, endPoint_post, requestBody );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }
    
    public String getAssignmentId( String courseId ) throws Exception {
        HashMap<String, String> assignmentDetails = new HashMap<>();
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, getAccessToken( username, password ) );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        
        HashMap<String, String> assignmentLists = new AssignmentAPI().getViewAssignment( smUrl, assignmentDetails );
        String assignmentId = SMUtils.getKeyValueFromJsonArray( assignmentLists.get( Constants.REPORT_BODY ), "assignmentId", 1 );
        return assignmentId;
    }

}
