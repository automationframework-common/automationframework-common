package com.savvas.sm.teacher.ui.tests.DataSetup;

import org.testng.annotations.BeforeTest;

import com.learningservices.utils.Log;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.utils.sql.helper.FixupFunction;

public class FixupTest extends BaseTest {
    private static String rumbaID;

    @BeforeTest ( alwaysRun = true )
    public static void Inittest() throws Exception {
        rumbaID = configProperty.getProperty( "OrgRumbaID" );
        FixupFunction.executeFixupFunctions( rumbaID );
        Log.pass( "Fixup function executed successfully for the org: " + rumbaID );

    }

}
