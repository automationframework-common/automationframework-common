package com.savvas.sm.teacher.ui.tests.ReportSuite;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.ReportComponent;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class ReportsListing extends BaseTest {
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher23" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( description = "Verify Report menu is shown for teacher when teacher school is having math and reading license", groups = { "SMK-38391", "reports", "reportListing" }, priority = 1 )
    public void tcSMReportsListing001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMReportsListing001: Verify Report menu is shown for teacher when teacher school is having math and reading license. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-8680 -Verify Report menu is shown for teacher when teacher school is having math license" );
            // Verify Cumulative Performance Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.CPR_REPORT ), "Cumulative Performance Report sub menu is Present under report menu", "Cumulative Performance Report sub menu is not Present under report menu" );

            // Verify Last Session Report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.LSR_REPORT ), "Last Session Report sub menu is Present under report menu", "Last Session Report sub menu is not Present under report menu" );

            // Verify Prescriptive scheduling report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.PSR_REPORT ), "Prescriptive Scheduling Report sub menu is Present under report menu",
                    "Prescriptive Scheduling Report sub menu is not Present under report menu" );

            // Verify Area of difficulty Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.AOD_REPORT ), "Area of Difficulty sub menu is Present under report menu", "Area of Difficulty Report sub menu is not Present under report menu" );

            // Verify Last session report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.SPR_REPORT ), "Student Performance Report sub menu is Present under report menu", "Student Performance Report sub menu is not Present under report menu" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Report menu is shown for teacher when teacher school is having Math focus license", dataProvider = "getTeacherUsernameWithMathFocus", groups = { "SMK-38391", "reports", "reportListing" }, priority = 1 )
    public void tcSMReportsListing002( String teacherUsername ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMReportsListing002: Verify Report menu is shown for teacher when teacher school is having math focus license <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            SMUtils.logDescriptionTC( "SMK-8682 - Verify Report menu is shown for teacher when teacher school is having Math focus license" );
            // Verify Cumulative Performance Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.CPR_REPORT ), "Cumulative Performance Report sub menu is Present under report menu", "Cumulative Performance Report sub menu is not Present under report menu" );

            // Verify Last Session Report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.LSR_REPORT ), "Last Session Report sub menu is Present under report menu", "Last Session Report sub menu is not Present under report menu" );

            // Verify Prescriptive scheduling report Sub menu
            Log.assertThat( !teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.PSR_REPORT ), "Prescriptive Scheduling Report sub menu is not present under report menu as expected for organization having focus license alone.",
                    "Prescriptive Scheduling Report sub menu is Present under report menu for organization having focus license alone. " );

            // Verify Area of difficulty Sub menu
            Log.assertThat( !teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.AOD_REPORT ), "Area of Difficulty sub menu is not Present under report menu as expected for organization having focus license alone.",
                    "Area of Difficulty Report sub menu is  Present under report menu for organization having focus license alone." );

            // Verify Last session report Sub menu
            Log.assertThat( !teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.SPR_REPORT ), "Student Performance Report sub menu is not Present under report menu as expected for organization having focus license alone.",
                    "Student Performance Report sub menu is  Present under report menu for organization having focus license alone." );

            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Report menu is shown for teacher when teacher school is not having license", dataProvider = "getTeacherUsernameWithoutLicense", groups = { "SMK-38391", "reports", "reportListing" }, priority = 3 )
    public void tcSMReportsListing003( String teacherUsername ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMReportsListing003: Verify Report menu is shown for teacher when teacher school is not having license <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            SMUtils.logDescriptionTC( "SMK-8679 - Verify Report menu is shown for teacher when teacher school is not having license" );
            // Verify Cumulative Performance Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.CPR_REPORT ), "Cumulative Performance Report sub menu is Present under report menu", "Cumulative Performance Report sub menu is not Present under report menu" );

            // Verify Last Session Report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.LSR_REPORT ), "Last Session Report sub menu is Present under report menu", "Last Session Report sub menu is not Present under report menu" );

            // Verify Prescriptive scheduling report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.PSR_REPORT ), "Prescriptive Scheduling Report sub menu is Present under report menu",
                    "Prescriptive Scheduling Report sub menu is not Present under report menu" );

            // Verify Area of difficulty Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.AOD_REPORT ), "Area of Difficulty sub menu is Present under report menu", "Area of Difficulty Report sub menu is not Present under report menu" );

            // Verify Last session report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.SPR_REPORT ), "Student Performance Report sub menu is Present under report menu", "Student Performance Report sub menu is not Present under report menu" );

            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Report menu is shown for teacher when teacher school is having Reading license", dataProvider = "getTeacherUsernameWithDefaultReading", groups = { "SMK-38391", "reports", "reportListing" }, priority = 3 )
    public void tcSMReportsListing004( String teacherUsername ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMReportsListing004: Verify Report menu is shown for teacher when teacher school is having Reading license <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            SMUtils.logDescriptionTC( "SMK-8681 - Verify Report menu is shown for teacher when teacher school is having Reading license" );
            SMUtils.logDescriptionTC( "SMK-8684 - Verify the report list available under Top header Report menu" );
            // Verify Cumulative Performance Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.CPR_REPORT ), "Cumulative Performance Report sub menu is Present under report menu", "Cumulative Performance Report sub menu is not Present under report menu" );

            // Verify Last Session Report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.LSR_REPORT ), "Last Session Report sub menu is Present under report menu", "Last Session Report sub menu is not Present under report menu" );

            // Verify Prescriptive scheduling report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.PSR_REPORT ), "Prescriptive Scheduling Report sub menu is Present under report menu",
                    "Prescriptive Scheduling Report sub menu is not Present under report menu" );

            // Verify Area of difficulty Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.AOD_REPORT ), "Area of Difficulty sub menu is Present under report menu", "Area of Difficulty Report sub menu is not Present under report menu" );

            // Verify Last session report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.SPR_REPORT ), "Student Performance Report sub menu is Present under report menu", "Student Performance Report sub menu is not Present under report menu" );

            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Report listing is shown for teacher when teacher school is having Reading focus license", dataProvider = "getTeacherUsernameWithReadingFocus", groups = { "SMK-38391", "reports", "reportListing" }, priority = 3 )
    public void tcSMReportsListing005( String teacherUsername ) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMReportsListing005: Verify Report listing is shown for teacher when teacher school is having Reading focus license <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            SMUtils.logDescriptionTC( "SMK-8683 -Verify Report listing is shown for teacher when teacher school is having Reading focus license" );
            // Verify Cumulative Performance Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.CPR_REPORT ), "Cumulative Performance Report sub menu is Present under report menu", "Cumulative Performance Report sub menu is not Present under report menu" );

            // Verify Last Session Report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.LSR_REPORT ), "Last Session Report sub menu is Present under report menu", "Last Session Report sub menu is not Present under report menu" );

            // Verify Prescriptive scheduling report Sub menu
            Log.assertThat( !teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.PSR_REPORT ), "Prescriptive Scheduling Report sub menu is not present under report menu as expected for organization having focus license alone.",
                    "Prescriptive Scheduling Report sub menu is Present under report menu for organization having focus license alone. " );

            // Verify Area of difficulty Sub menu
            Log.assertThat( !teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.AOD_REPORT ), "Area of Difficulty sub menu is not Present under report menu as expected for organization having focus license alone.",
                    "Area of Difficulty Report sub menu is  Present under report menu for organization having focus license alone." );

            // Verify Last session report Sub menu
            Log.assertThat( !teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.SPR_REPORT ), "Student Performance Report sub menu is not Present under report menu as expected for organization having focus license alone.",
                    "Student Performance Report sub menu is  Present under report menu for organization having focus license alone." );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher can access Reports", groups = { "SMK-38391", "reports", "reportListing" }, priority = 3 )
    public void tcSMReportsListing006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMReportsListing006: Verify teacher can access Reports <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-8686 - Verify teacher can access 'Cumulative Performance' report" );
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();
            ReportComponent reportComponent = new ReportComponent( driver );
            Log.assertThat( reportComponent.getReportPageHeader().equals( Constants.Reports.CPR_HEADER ), "Cumulative Performance report page is accessible.", "Cumulative Performance report page is not accessible." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8688 - Verify teacher can access 'Prescriptive Scheduling' report" );
            teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();
            Log.assertThat( reportComponent.getReportPageHeader().equals( Constants.Reports.PSR_HEADER ), "Last Session Report page is accessible.", "Last Session Report page is not accessible." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8687 - Verify teacher can access 'Last Session' report" );
            teacherHomePage.topNavBar.navigateToReportsLastSessionTab();
            Log.assertThat( reportComponent.getReportPageHeader().equals( Constants.Reports.LSR_HEADER ), "Prescriptive Scheduling page is accessible.", "Prescriptive Scheduling page is not accessible." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8685 - Verify teacher can access 'Areas of Difficulty'report" );
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();
            Log.assertThat( reportComponent.getReportPageHeader().equals( Constants.Reports.AOD_HEADER ), "Area of Difficulty page is accessible.", "Area of Difficulty page is not accessible." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-8689 - Verify teacher can access 'Student Performance' report" );
            teacherHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            Log.assertThat( reportComponent.getReportPageHeader().equals( Constants.Reports.SPR_HEADER ), "Student Performance page is accessible.", "Student Performance page is not accessible." );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @DataProvider ( name = "getTeacherUsernameWithMathFocus" )
    public Object[][] getTeacherUsernameWithMathFocus() throws Exception {
        String focusSchoolName = "Automation_OrgwithMathFocuLicense";
        SqlHelperOrganization orgHelper = new SqlHelperOrganization();
        orgHelper.deleteOrganization( focusSchoolName );
        int organizationId = orgHelper.createOrganization( focusSchoolName, focusSchoolName );
        orgHelper.addLicenseToOrg( organizationId, DataSetupConstants.FOCUS_LICENSE, DataSetupConstants.MATH, 20 );

        Faker teacherDetails = new Faker();
        String teacherUsername = "teacher_WithMathFocusLicense";
        new UserSqlHelper().createTeacher( teacherDetails.name().firstName(), teacherDetails.name().lastName(), teacherUsername, Constants.PASSWORD_HASH, organizationId );
        Log.message( "Created Teacher in organization with focus license : " + teacherUsername );
        Object[][] teacherWithFocusLicense = { { teacherUsername } };
        return teacherWithFocusLicense;
    }

    @DataProvider ( name = "getTeacherUsernameWithoutLicense" )
    public Object[][] getTeacherUsernameWithoutLicense() throws Exception {
        String focusSchoolName = "Automation_OrgwithoutLicense";
        SqlHelperOrganization orgHelper = new SqlHelperOrganization();
        orgHelper.deleteOrganization( focusSchoolName );
        int organizationId = orgHelper.createOrganization( focusSchoolName, focusSchoolName );

        Faker teacherDetails = new Faker();
        String teacherUsername = "teacher_WithoutLicense";
        new UserSqlHelper().createTeacher( teacherDetails.name().firstName(), teacherDetails.name().lastName(), teacherUsername, Constants.PASSWORD_HASH, organizationId );
        Log.message( "Created Teacher in organization with focus license : " + teacherUsername );
        Object[][] teacherWithFocusLicense = { { teacherUsername } };
        return teacherWithFocusLicense;
    }

    @DataProvider ( name = "getTeacherUsernameWithDefaultReading" )
    public Object[][] getTeacherUsernameWithDefaultReading() throws Exception {
        String focusSchoolName = "Automation_OrgwithDefaultReadingLicense";
        SqlHelperOrganization orgHelper = new SqlHelperOrganization();
        orgHelper.deleteOrganization( focusSchoolName );
        int organizationId = orgHelper.createOrganization( focusSchoolName, focusSchoolName );
        orgHelper.addLicenseToOrg( organizationId, DataSetupConstants.DEFAULT_LICENSE, DataSetupConstants.READING, 20 );

        Faker teacherDetails = new Faker();
        String teacherUsername = "teacher_WithDefaultReadingLicense";
        new UserSqlHelper().createTeacher( teacherDetails.name().firstName(), teacherDetails.name().lastName(), teacherUsername, Constants.PASSWORD_HASH, organizationId );
        Log.message( "Created Teacher in organization with focus license : " + teacherUsername );
        Object[][] teacherWithFocusLicense = { { teacherUsername } };
        return teacherWithFocusLicense;
    }

    @DataProvider ( name = "getTeacherUsernameWithReadingFocus" )
    public Object[][] getTeacherUsernameWithReadingFocus() throws Exception {
        String focusSchoolName = "Automation_OrgwithReadingFocuLicense";
        SqlHelperOrganization orgHelper = new SqlHelperOrganization();
        orgHelper.deleteOrganization( focusSchoolName );
        int organizationId = orgHelper.createOrganization( focusSchoolName, focusSchoolName );
        orgHelper.addLicenseToOrg( organizationId, DataSetupConstants.FOCUS_LICENSE, DataSetupConstants.READING, 20 );

        Faker teacherDetails = new Faker();
        String teacherUsername = "teacher_WithReadingFocusLicense";
        new UserSqlHelper().createTeacher( teacherDetails.name().firstName(), teacherDetails.name().lastName(), teacherUsername, Constants.PASSWORD_HASH, organizationId );
        Log.message( "Created Teacher in organization with focus license : " + teacherUsername );
        Object[][] teacherWithFocusLicense = { { teacherUsername } };
        return teacherWithFocusLicense;
    }
}
