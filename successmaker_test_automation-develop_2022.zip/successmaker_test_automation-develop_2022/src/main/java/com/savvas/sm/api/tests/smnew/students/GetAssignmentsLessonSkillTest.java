package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

import io.restassured.response.Response;

public class GetAssignmentsLessonSkillTest extends EnvProperties {

    private String smUrl;
    private String teacherDetails;
    private String teacherUsername;
    private String teacherUserId;
    private String orgId;
    private String studentDetails;
    private String studentUsername;
    private String studentUserId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private List<String> studentRumbaIds = new ArrayList<>();
    private Map<String, String> courseName = new HashMap<>();
    private Map<String, String> courseIds = new HashMap<>();
    private Map<String, String> assignmentIds = new HashMap<>();
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String browser;
    String assignmentUserId;
    List<String> lessonId;

    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {
        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        studentDetails = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );

        //Reading Course Names
        courseName.put( Constants.READING, AssignmentAPIConstants.READING_COURSE );
        courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );

        String teacherAccessToken = null;
        try {
            teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Issue in get the accces token - " + e.getMessage() );
            try {
                Log.message( "Retrying to get the access token!!!!" );
                teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            } catch ( Exception e1 ) {
                Log.fail( "Unable to create the access token for the teacher - " + teacherUsername );
            }
        }

        //Reading course Ids
        courseIds.put( Constants.READING, AssignmentAPIConstants.READING );
        courseIds.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
        courseIds.put( Constants.CUSTOM_BY_SKILLS_READING_COURSE,
                new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SKILL, courseName.get( Constants.CUSTOM_BY_SKILLS_READING_COURSE ) ) );

        courseIds.put( Constants.CUSTOM_BY_STANDARDS_READING_COURSE,
                new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.STANDARD, courseName.get( Constants.CUSTOM_BY_STANDARDS_READING_COURSE ) ) );
        try {
            courseIds.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );

        } catch ( Exception e ) {
            Log.message( "Issue in Reading Custom course creation!! - " + e.getMessage() );
        }

        Log.message( "Course Ids for " + school + ": " + courseIds );

        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        staffDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        try {
            //Assigning Assignment
            Log.message( "Assigning assignment..." );

            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, studentRumbaIds, new ArrayList<>( courseIds.values() ) );
            Log.message( "Assignment Response : " + assignmentResponse );

            JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
            JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

            for ( Object assignment : assignmentList ) {
                JSONObject assignmentInfo = new JSONObject( assignment.toString() );
                assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
            }
            Log.message( "Assignment IDs - " + assignmentIds );
        } catch ( Exception e ) {
            Log.fail( "Issue in Assigning the assignment to the student!! - " + e.getMessage() );
        }

    }

    @Test ( priority = 1, dataProvider = "studentUsagePositive", groups = { "smoke_test_case", "SMK-68093", "Students API", "Assignments Lesson Skill", "P1", "API" } )
    public void tcPositiveTestcases( String tcId, String description, String scenario, String statusCode ) throws Throwable {
        Log.testCaseInfo( tcId + ":-" + description );
        // Response response = null;
        String body = "";
        //Map<String, String> response = new HashMap<>();
        Response response;
        String sessionId;
        switch ( scenario ) {
            case "VALID_DEFAULTREADING":

                launchCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ), "90", "1", "60" );

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = assignmentLessonSkillGet( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                Log.message( response.getBody().asString() );
                Log.assertThat( response.getStatusCode() == 200, "Getting the 200 satus code for Assignments lesson skill case", "Not Getting the 200 satus code for Assignments lesson skill case" );

                break;

            case "VALID_READINGCUSTOM":

                launchCourse( studentUsername, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ), "90", "1", "20" );

                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
                sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = assignmentLessonSkillGet( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                new RBSUtils().getAccessToken( studentUsername, password );
                Log.message( response.getBody().asString() );

                Log.message( String.valueOf( response.getStatusCode() ) );
                Log.assertThat( response.getStatusCode() == 200, "Getting the 200 satus code for Assignments lesson skill case", "Not Getting the 200 satus code for Assignments lesson skill case" );

                if ( response.getBody().asString().contains( lessonId.get( 0 ).toString() ) ) {
                 
                    Log.assertThat( response.getBody().asString().contains( assignmentUserId ), "Value validation passed for assignments user id", "Value validation failed" );
               
                } else {

                    Log.message( "Response is showing without any body" );

                }

                if ( response.getBody().asString().contains( lessonId.get( 0 ).toString() ) ) {
                   
                    Log.assertThat( response.getBody().asString().contains( lessonId.get( 0 ).toString() ), "Value validation passed for lesson id", "Value validation failed" );
                
                } else {

                    Log.message( "Response is showing without any body" );
                }
                break;

        }

    }

    @DataProvider ( name = "studentUsagePositive" )
    public Object[][] studentUsagePositive() {

        Object[][] inputData = { { "assignmentsLessonSkill_01", "Verify the status code is 200 when valid data is given for Assignments lesson skill", "VALID_DEFAULTREADING", CommonAPIConstants.STATUS_CODE_OK },
                { "assignmentsLessonSkill_02", "Verify the status code is 200 when valid data is given for Assignments lesson skill", "VALID_READINGCUSTOM", CommonAPIConstants.STATUS_CODE_OK } };

        return inputData;
    }

    /**
     * To Create and get the session Id for given student
     *
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @return
     */
    public String getSessionId( String smUrl, String userId, String orgId, String studentUsername, String password, String assignmentUserId ) {
        String endPoint1 = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        List<String> pathParamsList = new ArrayList<>();
        HashMap<String, String> header = new HashMap<>();
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( LicenseAPIConstants.USERID, userId );
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        pathParamsList.add( assignmentUserId );
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint1, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, header, endPoint1, pathParams );
        Log.message( response.getBody().asString() );
        String sessionId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "sessionId" );
        Log.message( "Session ID  - " + sessionId );
        return sessionId;
    }

    /**
     * To get IPM complete student completed the assignment
     * 
     * @param smUrl
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @param sessionId
     * @return
     * @throws Throwable
     */
    public Response assignmentLessonSkillGet( String smUrl, String userId, String orgId, String studentUsername, String password, String assignemntUserId, String sessionId ) throws Throwable {
        String query1 = "SELECT pearson_cur_tax_id as lesson_id FROM school.read_assignment_sco_history ra inner join cttype c on c.cttype_id = ra.lesson_cttype_id where assignment_user_id ='" + assignemntUserId + "' order by date_created asc limit 1";
        String endPointNew = "";
        List<Object[]> lessonIds = SQLUtil.executeQuery( query1 );
        SMUtils.nap( 2 );//This wait is required to execute the query

        if ( lessonIds != null ) {
            lessonId = new ArrayList<String>();
            for ( Object[] list : lessonIds ) {
                lessonId.add( list[0].toString() );
            }
        } else {

            String query = "SELECT pearson_cur_tax_id as lesson_id FROM school.read_assignment_sco_history ra inner join cttype c on c.cttype_id = ra.lesson_cttype_id where assignment_user_id ='" + assignemntUserId + "' order by date_created ";
            List<Object[]> lessonIds1 = SQLUtil.executeQuery( query );
            SMUtils.nap( 2 );//This wait is required to execute the query
            lessonId = new ArrayList<String>();
            for ( Object[] list : lessonIds1 ) {
                lessonId.add( list[0].toString() );
            }
        }

        String endPoint = "/lms/web/assignments/lessonskills/{auId}?".replace( "{auId}", assignemntUserId );

        endPointNew = "lessonId={lesssonId}&phaseType=GuidedPractice".replace( "{lesssonId}", lessonId.toString() );

        String actualEndPoint = endPoint + endPointNew;

        //Parameters
        HashMap<String, String> params = new HashMap<>();
        Map<String, String> header = new HashMap<>();
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + "" + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            Log.fail( "Issue in getting the accesstoken for student - " + studentUsername );
        }
        header.put( LicenseAPIConstants.USERID, userId );
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( "Content-Type", "application/json" );
        header.put( "session-id", sessionId );
        return RestAssuredAPIUtil.GET( smUrl, header, params, actualEndPoint );

    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "90", "2", "80" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "90", "2", "80" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    /**
     * To execute the course
     *
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void launchCourse( String studentUserName, String courseName, String percentage, String numberOfSession, String loCount ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );

        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );
        studentsPage.launchReadingCourse( courseName, percentage, numberOfSession, loCount );

    }

}
