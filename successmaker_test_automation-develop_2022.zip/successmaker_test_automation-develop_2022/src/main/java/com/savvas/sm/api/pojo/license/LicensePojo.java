package com.savvas.sm.api.pojo.license;

public class LicensePojo {
    private int quantity;
    private int usedLicensesForThisOrg;
    private String productId;
    private String productDisplayName;

    // Getter Methods 

    public int getQuantity() {
        return quantity;
    }

    public int getUsedLicensesForThisOrg() {
        return usedLicensesForThisOrg;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductDisplayName() {
        return productDisplayName;
    }

    // Setter Methods 

    public void setQuantity( int quantity ) {
        this.quantity = quantity;
    }

    public void setUsedLicensesForThisOrg( int usedLicensesForThisOrg ) {
        this.usedLicensesForThisOrg = usedLicensesForThisOrg;
    }

    public void setProductId( String productId ) {
        this.productId = productId;
    }

    public void setProductDisplayName( String productDisplayName ) {
        this.productDisplayName = productDisplayName;
    }

}
