package com.savvas.sm.ui.tests.smnew.SmokeTests;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.GroupUIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EditUsageGoalsPopupPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MyProfilePage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.teacher.ui.pages.TopNavBar;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class TeacherDashboardSmokeTest {

    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String browser;

    private static String username = null;
    private static String googleTeacherUsername = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherID;
    private String studentLastName;
    String studentDetails;
    String studentDetailsSecond;
    String studentDetailsThree;
    String studentSMDetails;
    String studentSMDetailsSecond;
    String studentSMDetailsThree;
    String studentUserName;
    String firstName;
    String lastName;
    private String smUrl;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    List<String> addStudentsToGroup;
    List<String> studentListFromTheAssignmentPopup;
    List<String> studentListFromTheAssignmentPopupRead;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        studentDetails = RBSDataSetup.getMyStudent( school, username );
        studentUserName = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );
        firstName = SMUtils.getKeyValueFromResponseWithArray( studentDetails, RBSDataSetupConstants.FIRSTNAME );
        lastName = SMUtils.getKeyValueFromResponseWithArray( studentDetails, RBSDataSetupConstants.LASTNAME );

    }

    @Test ( description = "Verify Home Page Components and Widgets", priority = 1, groups = { "smoke_test_case", "Teacher_TC01", "HomePage", "P1" } )
    public void tcSMHomePageTest001() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Teacher_TC01 : Verify Home Page Components and Widgets <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage customCourses = new CoursesPage( driver );
            studentListFromTheAssignmentPopup = new ArrayList<>();
            studentListFromTheAssignmentPopupRead = new ArrayList<>();
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            tHomePage.clickAssignButton();
            tHomePage.clickAssignBtnMSDAPopup();
            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();
            tHomePage.topNavBar.navigateToStudentsTab();
            tHomePage.topNavBar.navigateToHomeTab();

            Log.assertThat( courseWidgetDisplayed, "Course widget is displayed", "Course widget is not displayed" );
            Log.assertThat( tHomePage.isCoursesWidgetDisplayed(), "Courses widget is displayed in HomePage", "Courses widget is not displayed in HomePage" );
            Log.assertThat( tHomePage.getCourseTitleFromCoursesWidget().size() == 4, "Title-Courses widget is displayed in HomePage", "Title-Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.getCourseAssignedDateFromCoursesWidget().size() == 2, "Assigned date-Courses widget is displayed in HomePage", "Assigned date-Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.getCourseTypesFromCoursesWidget().size() == 4, "Type-Courses widget is displayed in HomePage", "Type-Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.getAssignBtnFromCoursesWidget().size() == 4, "Assign Btn-Courses widget is displayed in HomePage", "Assign Btn-Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isViewAllDisplayed(), "View All-Courses widget is displayed in HomePage", "View All-Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isAnnouncementWidgetDisplayed(), "Announcement widget is displayed in HomePage", "Announcement widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isMasteryWidgetDisplayed(), "Mastery widget is displayed in HomePage", "Mastery widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isAssignmentWidgetDisplayed(), "Assignment widget is displayed in HomePage", "Assignment widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isStudentUsageWidgetDisplayed(), "Student Usage widget is displayed in HomePage", "Student Usage widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isDidYouKnowWidgetDisplayed(), "Did You Know widget is displayed in HomePage", "Did You Know widget is not displayed in HomePage" );
            tHomePage.clickViewALLInAssignmentWidget();
            AssignmentsPage assignmentsPage = new AssignmentsPage( driver );
            Log.assertThat( assignmentsPage.isAssignmentTitleDisplayed(), "Navigated to Assignments page on clicking View All- Assignment Widget", "Error in Navigating to Assignments page on clicking View All- Assignment Widget" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify TopNav Bar and Logo", priority = 1, groups = { "smoke_test_case", "Teacher_TC02", "HomePage", "P1" } )
    public void tcSMHomePageTest002() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Teacher_TC02 : Verify TopNav Bar and Logo <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            TopNavBar topNavBar = tHomePage.topNavBar;
            // Verify topNavBar items - Home, Students, Groups, Courseware, Mastery and
            // Reports
            Log.assertThat( topNavBar.isHomeTabDisplayed(), "Home Tab is displayed in TopNavBar", "Home Tab is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isStudentsTabDisplayed(), "Students Tab is displayed in TopNavBar", "Students Tab is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isGroupsTabDisplayed(), "Groups Tab is displayed in TopNavBar", "Groups Tab is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isCoursewareDisplayed(), "Courseware Tab is displayed in TopNavBar", "Courseware Tab is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isMasteryTabDisplayed(), "Mastery Tab is displayed in TopNavBar", "Mastery Tab is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isReportsTabDisplayed(), "Reports Tab is displayed in TopNavBar", "Reports Tab is not displayed in TopNavBar" );

            // Verify Announcement Icon, Help Icon, UserProfile menu
            Log.assertThat( topNavBar.isAnnouncementDisplayed(), "Announcement Icon is displayed in TopNavBar", "Announcement Icon is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isHelpDisplayed(), "Help Icon is displayed in TopNavBar", "Help Icon is not displayed in TopNavBar" );

            // expand user icon dropdown
            topNavBar.expandUserDropdown();

            Log.assertThat( topNavBar.isUserDropdownExpanded(), "User Icon dropdown is displayed in TopNavBar", "User Icon dropdown is not displayed in TopNavBar" );

            // Verify the presence of top left SM logo and bottom right Savvas Logo
            Log.assertThat( topNavBar.isSuccessMakerLogoDisplayed(), "SuccessMaker Logo is displayed in TopNavBar", "SuccessMaker Logo is not displayed in TopNavBar" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify UserProfile Update", priority = 1, groups = { "smoke_test_case", "Teacher_TC04", "TeacherProfile", "P1" } )
    public void tcSMHomePageTest003() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Teacher_TC04 : Verify UserProfile Update <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            TopNavBar topNavBar = tHomePage.topNavBar;
            // expand user icon dropdown
            topNavBar.expandUserDropdown();

            Log.assertThat( topNavBar.isUserDropdownExpanded(), "User Icon dropdown is displayed in TopNavBar", "User Icon dropdown is not displayed in TopNavBar" );

            // Navigating to the MyProfilePage page
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            Log.assertThat( !myProfilePage.isUsernameEnabled(), "Usename is not editable by default", "Usename is editable by default" );

            String modifiedPassword = password + System.nanoTime();

            Log.assertThat( myProfilePage.validateChangePaswordLink(), "ChangePassword link is Validated and all Password fields are enabled", "ChangePassword link fields is not working as " );

            // Passing Current password and New Password with same values
            myProfilePage.modifyPassword( modifiedPassword );

            // Passing modified Password as current password to check password changed
            Boolean validateChangedPassword = myProfilePage.validateChangedPassword( modifiedPassword );

            // Validate whether the Password changed Successfully
            Log.assertThat( validateChangedPassword, "Password Change Successfully completed", "Password Change failed" );
            tHomePage.topNavBar.signOutfromSM();

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, modifiedPassword );
            topNavBar.expandUserDropdown();
            // Navigating to the MyProfilePage page
            tHomePage.topNavBar.navigateToMyProfile();
            Log.assertThat( myProfilePage.validateChangePaswordLink(), "ChangePassword link is Validated and all Password fields are enabled", "ChangePassword link fields is not working as " );
            // Getting the old Values from the text fields

            // Passing modified Password as current password to check password changed
            validateChangedPassword = myProfilePage.validateChangedPassword( password );

            // Validate whether the Password changed Successfully
            Log.assertThat( validateChangedPassword, "Password Change Successfully completed", "Password Change failed" );

            String firstName = myProfilePage.getFirstName();
            String lastName = myProfilePage.getLastName();
            String midName = myProfilePage.getMiddleName();
            String emailId = myProfilePage.getEmail();

            // Modify the Values
            myProfilePage.selectValuesFromtheTitleDropDown( "Ms" );
            myProfilePage.modifyFirstName( firstName + System.nanoTime() );
            myProfilePage.modifyMiddleName( midName + System.nanoTime() );
            myProfilePage.modifyLastName( lastName + System.nanoTime() );
            myProfilePage.modifyEmail( emailId + System.nanoTime() );
            myProfilePage.saveChanges();

            // Getting theValues from the text fields after clicking Cancel button
            String firstNameAfterSave = myProfilePage.getFirstName();
            String midNameAfterSave = myProfilePage.getMiddleName();
            String lastNameAfterSave = myProfilePage.getLastName();
            String emailAfterSave = myProfilePage.getEmail();

            // Validate whether fields are updated 
            Log.assertThat( myProfilePage.getUserTitle().equals( "Ms" ), "Title is updated", "Title is not updated" );
            Log.assertThat( !firstName.equals( firstNameAfterSave ), "First Name  " + firstName + " is Updated and changed to " + firstNameAfterSave + " Successfully", "First Name not changed successfully" );
            Log.assertThat( !lastName.equals( lastNameAfterSave ), "Middle Name  " + midName + " is Updated and changed to " + midNameAfterSave + " Successfully", "Middle Name not changed successfully" );
            Log.assertThat( !lastName.equals( lastNameAfterSave ), "Last Name  " + lastName + " is Updated and changed to " + lastNameAfterSave + " Successfully", "Last Name not changed successfully" );
            Log.assertThat( !lastName.equals( lastNameAfterSave ), "Email Id  " + emailId + " is Updated and changed to " + emailAfterSave + " Successfully", "Email Id not changed successfully" );
            Log.testCaseResult();
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student Creation", priority = 1, groups = { "smoke_test_case", "Teacher_TC06", "Students", "P1" } )
    public void tcSMStudentPageTest001() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Teacher_TC06 : Verify Student Creation <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            String studentID = studentsPage.createStudent();
            Log.message( "New Student Details : " + studentID );
            studentsPage.closeStudentAddedToastPopUp();
            Log.testCaseResult();

            tHomePage.topNavBar.navigateToStudentsTab();
            Log.assertThat( !studentsPage.isStrudentPresent( studentID.toLowerCase() ), studentID.toLowerCase() + " is not present in the Students lsiting page as expected", studentID.toLowerCase() + " is present in the students listing page" );
            Log.testCaseResult();

            SMUtils.nap( 10 );
            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            String groupName = GroupUIConstants.SIMPLE_GROUP_NAME + System.nanoTime();

            String stuUserName = studentID.toLowerCase();
            groupsPage.createGroupWithoutStudent( groupName );
            SMUtils.nap( 5 );
            groupsPage.clickGetViewGroupBtn( groupName );
            SMUtils.nap( 5 );
            // Click add student to group button
            groupsPage.clickAddStudentToGrpBtnGrpPage();
            //wait for solr search
            SMUtils.nap( 120 );
            groupsPage.addNameInTextField( stuUserName );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickAddButton();
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickSaveBtnAddStudToGrpPopUp();
            SMUtils.nap( 10 );
            tHomePage.topNavBar.navigateToStudentsTab();
            Log.assertThat( studentsPage.isStrudentPresent( stuUserName ), stuUserName + " present in the Students lsiting page", stuUserName + " not present in the students listing page" );
            Log.testCaseResult();

            Log.testCaseResult();

            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "View Student Details", priority = 1, groups = { "smoke_test_case", "Teacher_TC09", "Students", "P1" } )
    public void tcSMStudentPageTest002() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Teacher_TC09 : View Student Details <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            String groupName = "Successmaker Group 1";

            studentsPage.clickviewStudentByEllipsis( studentUserName );

            System.out.println( studentsPage.getHeaderNameStudent() );
            Log.assertThat( studentsPage.getHeaderNameStudent().equals( firstName ), firstName + " is Present in the header", firstName + " is not present in the header" );

            studentsPage.clickSubNavigation( "User Profile" );

            String editedName = firstName + "Edited";
            studentsPage.changeFirstName( editedName );

            studentsPage.clickSubNavigation( "Groups" );

            Log.assertThat( studentsPage.isGroupnamePresent( groupName ), "Group name " + groupName + " Matched", "Group name " + groupName + " is not present in the page" );

            studentsPage.clickSubNavigation( "User Profile" );

            Log.assertThat( studentsPage.getFirstName().equals( editedName ), "First Name updated", "First name not updated properly" );
            Log.testCaseResult();

            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Remove student from group", priority = 1, groups = { "smoke_test_case", "Teacher_TC33", "Students", "P1" } )
    public void tcSMStudentPageTest003() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Teacher_TC33 : Verify Remove student from group <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            String groupName = "Successmaker Group 1";

            //Click ellipses icon for any student who is associated with any group and click "View Student" option
            studentsPage.clickviewStudentByEllipsis( studentUserName );
            //Click Groups section
            studentsPage.clickSubNavigation( "Groups" );
            //Click ellipses icon and select "Remove Student from Group" option
            Log.assertThat( studentsPage.verifyRemoveStudentToGroupText( groupName ), "Remove Student from Group text is displayed after clicking ellips icon", "Remove Student from text is not displayed after clicking ellips icon" );
            studentsPage.clickRemoveStudentToGroupText( groupName );
            Log.assertThat( studentsPage.verifyRemoveStudentFromGroupPopup( firstName + " " + lastName, groupName ), "Verified all the screen elements in Remove Student from Group popup", "Screen elements is not fully displayed" );
            Log.assertThat( studentsPage.isGroupnamePresent( groupName ), "Group name " + groupName + " is present in Students page", "Group name " + groupName + " is not present in the page" );
            studentsPage.clickRemoveStudentToGroupText( groupName );
            //Click "Remove" button
            studentsPage.clickRemoveButtonInPopup();
            //Verify the student is removed from the group
            Log.assertThat( !studentsPage.isGroupnamePresent( groupName ), "Group name " + groupName + " is  not present in Students page", "Group name " + groupName + " is present in the page" );
            Log.testCaseResult();

            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify UserProfile Update for student", priority = 1, groups = { "smoke_test_case", "Teacher_TC35", "Students", "P1" } )
    public void tcSMStudentPageTest004() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Teacher_TC35 : Verify UserProfile Update for student <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Click ellipses icon for any student who is associated with any group and click "View Student" option
            studentsPage.clickviewStudentByEllipsis( studentUserName );
            //Click User Profile section
            studentsPage.clickSubNavigation( "User Profile" );
            // Update the First Name
            String editedFirstName = firstName + "Edited";
            studentsPage.changeFirstName( editedFirstName );
            Log.assertThat( studentsPage.getFirstName().equals( editedFirstName ), "First Name updated", "First name not updated properly" );
            // Update the Last Name
            String editedLastName = lastName + "Edited";
            studentsPage.changeLastName( editedLastName );
            Log.assertThat( studentsPage.getLastName().equals( editedLastName ), "Last Name updated", "Last name not updated properly" );
            SMUtils.waitForElement( driver, studentsPage.ddSpecialServicesnUpdateStudent );
            // Update the Demographic
            List<String> migrantValues = studentsPage.getMigrantValues();
            SMUtils.clickJS( driver, studentsPage.ddMigrantUpdateStudent );
            Log.assertThat( migrantValues.equals( Constants.Students.MIGRANT_LISTING ), "migrantValues are updated", "migrantValues are not updated properly" );
            Log.testCaseResult();

            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the student listing displays correctly for usage goals in homepage for Math and Reading", priority = 1, groups = { "smoke_test_case", "Teacher_TC36", "UsageGoals", "P1" } )
    public void tcSMHomePageUsageGoalTest001() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Teacher_TC36 : Verify the student listing displays correctly for usage goals in homepage for Math and Reading <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            CoursesPage customCourses = new CoursesPage( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            // Navigate to Courses Tab
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.clickCourseName( Constants.READING );
            coursePage.clickAssignBtn();

            coursePage.addCourseToGroups();
            tHomePage.topNavBar.navigateToHomeTab();

            //navigate to Usage goal -student list for math assignment
            tHomePage.navigateToUsageGoalsStudentsList( Constants.MATH );
            //verifying usage goal - student list Math Headers
            Log.assertThat( tHomePage.verifyUsageGoalStudentListHeader( Constants.MATH ), "Math Usage goal - student List header displayed properly!", "Math Usage goal - student List header not  displayed properly!" );
            //Verifying columns in usage goal -student listing Page
            Log.assertThat( tHomePage.verifyColumnsInUsageGoalStudentListingPage(), "Column headers displayed properly for math!", "Column headers not displayed properly for math!" );

            tHomePage.clickBackIconInUsageGoalStudentListingPage();
            //navigate to Usage goal -student list for Reading assignment
            tHomePage.navigateToUsageGoalsStudentsList( Constants.READING );

            //verifying usage goal - student list Reading Headers
            Log.assertThat( tHomePage.verifyUsageGoalStudentListHeader( Constants.READING ), "Reading Usage goal - student List header displayed properly!", "Reading Usage goal - student List header not  displayed properly!" ); //Verifying columns in usage goal -student listing Page
            Log.assertThat( tHomePage.verifyColumnsInUsageGoalStudentListingPage(), "Column headers displayed properly for reading!", "Column headers not displayed properly for reading!" );

            Log.testCaseResult();

            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Usage Goals (Edit Goals) working properly", priority = 1, groups = { "smoke_test_case", "Teacher_TC39", "UsageGoals", "P1" } )
    public void tcSMHomePageUsageGoalTest002() throws Exception {
        EditUsageGoalsPopupPage editGoalsPage = null;
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Teacher_TC39 : Verify the Usage Goals (Edit Goals) working properly <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            studentDetails = RBSDataSetup.getMyStudent( school, username );
            studentLastName = SMUtils.getKeyValueFromResponse( studentDetails, "lastName" );

            // Navigate edit goals
            editGoalsPage = tHomePage.navigateToMathEditGoalsPopup();

            //Moving the slider to low range and high range.
            editGoalsPage.moveSlider( "24" );

            //Selecting dates from calendar
            editGoalsPage.clickCalenderIcon();
            editGoalsPage.clickDateFromCalender( "10" );

            //Submitting changes and verifying the change.
            editGoalsPage.clickOKButton();
            SMUtils.nap( 2 ); //Waiting to disappear the toast message
            Log.assertThat( editGoalsPage.getStudentTargetHour( studentLastName ).trim().equals( "24:00" ), "Target hours changed for students", "Target hours not changed for students!" );

            //Selecting single student and editing the goals settings
            editGoalsPage.selectStudentCheckBox( studentLastName );
            editGoalsPage.clickEditButton();

            //Moving the target hours slider
            editGoalsPage.moveSlider( "8" );

            //Selecting different dates
            editGoalsPage.clickCalenderIcon();
            editGoalsPage.clickDateFromCalender( "5" );

            //Submitting and verifying the changes.
            editGoalsPage.clickOKButton();
            SMUtils.nap( 2 ); //Waiting to disappear the toast message
            Log.assertThat( editGoalsPage.getStudentTargetHour( studentLastName ).trim().equals( "08:00" ), "Target hours changed for students", "Target hours not changed for students!" );
            Log.testCaseResult();

            //Navigating to Reading usage goals
            tHomePage.topNavBar.navigateToHomeTab();
            editGoalsPage = tHomePage.navigateToReadingEditGoalsPopup();

            //Moving the slider to low range and high range.
            editGoalsPage.moveSlider( "8" );

            //Selecting dates from calendar
            editGoalsPage.clickCalenderIcon();
            editGoalsPage.clickDateFromCalender( "10" );

            //Submitting changes and verifying the change.
            editGoalsPage.clickOKButton();
            SMUtils.nap( 2 ); //Waiting to disappear the toast message
            Log.assertThat( editGoalsPage.getStudentTargetHour( studentLastName ).trim().equals( "08:00" ), "Target hours changed for students", "Target hours not changed for students!" );
            Log.testCaseResult();
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the google class room present in successmaker", priority = 1, groups = { "smoke_test_case", "Teacher_TC62", "Groups", "P1" } )
    public void tcSMGroupTest001() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "Teacher_TC62 : Verify the google class room present in successmaker <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            googleTeacherUsername = configProperty.getProperty( "GoogleTeachusername" );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, googleTeacherUsername, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            GroupPage groupPageObject = tHomePage.topNavBar.navigateToGroupsTab();
            String googleClassName = Constants.GOOGLE_CLASS_GROUP;
            Log.message( googleClassName );
            Log.assertThat( groupPageObject.isGroupExist( googleClassName ), "Google classes are displayed in Group Listing", "Google classes are not displayed in Group Listing" );
            groupPageObject.viewGroup( googleClassName );
            Log.assertThat( groupPageObject.verifyMessageForGoogleClass(), "Google class is displayed correctly", "Google class is displayed correctly" );
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }
    //Added Smoke test for Newly created student not listed in student list
    public void tcCreateStudent001( ITestContext context ) throws Exception {
        // Get driver
      
        final WebDriver driver = WebDriverFactory.get( browser );
        
        SMUtils.logDescriptionTC( "Verify the created student added in current teacher homeroom group." );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Student Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Creating Student
            String studentID = studentsPage.createStudent();

            // Validating whether Created Student present by the Toast Message PopUp
            Log.assertThat( studentsPage.closeStudentAddedToastPopUp(), studentID + " is Created and present in the Students lsiting page", studentID + " not created and not present in the students listing page" );
            
            //Validate Created student is not shown until it is added to any group
            Log.assertThat( studentsPage.isStudentNotPresent( studentID ), studentID + " is Created and not listed in the Students lsiting page", studentID + "  created and student present in a group and it is showen in students listing page" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }


}

