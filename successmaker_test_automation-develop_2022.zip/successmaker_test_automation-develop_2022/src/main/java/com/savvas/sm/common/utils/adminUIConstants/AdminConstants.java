package com.savvas.sm.common.utils.adminUIConstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public interface AdminConstants {

    public String MFEURL = "https://ebsm-admin-dashboard-webapp-dev.smdemo.info/dashboard";

    public String SELECTED_SIDE_NAV_BAR_COLOR = "#2150a3";

    public enum SubNavigations {
        DASHBOARD,
        MASTERY,
        SHARED_COURSES,
        AUDIT_HISTORY,
        SETTINGS
    }

    public interface SettingPage {

        public String HEADER = "Settings";
        public String HOLIDAY_SCHEDULER = "Holiday Scheduler";
        public String MSDA = "Math Screener & Diagnostic Assessments (MSDA)";
        public String EDIT_BUTTON = "Edit";

    }

    /**
     * Constants related to Dashboard page
     *
     */
    public interface Dashboard {
        public String ARIA_PRESSED = "aria-pressed";
        public String SELECTED_ORGANIZATIONS_COUNT = "%s Organizations Selected";
        public String ALL_ORGANIZATIONS_SELECTED = "All Organizations (%s)";
        public String ALL_ORGANIZATION = "ALL (%s)";
        public String SEARCH_ORGANIZATIONS = "Search Organizations";
        public String NO_ORGANIZATION_FOUND = "No organization(s) found...";
        public String ORG_NAME_SPECIALCHARACTER = "@#  12Aa";
        public String INVALID_ORGNAME = "invalidOrgName";

        //Performance report widget
        public String PERFORMANCE_REPORT = "Performance Report";
        public String CURRENT_LEVEL_AND_GAIN = "Current Level and Gain";
        public List<String> GAIN_HEADERS = Arrays.asList( "LARGEST GAIN", "SMALLEST GAIN" );
        public List<String> Y_AXIS_INTERVALS = Arrays.asList( "K", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "" );
        public List<String> X_AXIS_INTERVALS = Arrays.asList( "0", "0.5", "1", "1.5", "2", "2.5", "3", "3.5", "4", "4.5", "5", "5.5", "6", "6.5", "7", "7.5", "8", "8.95", "" );
        public String X_AXIS_LABEL = "Course Level";
        public String Y_AXIS_LABEL = "Grade";
        public List<String> SUBJECTS = Arrays.asList( "Math", "Reading" );
        public List<String> HEXA_COLORS_FOR_GRADES = Arrays.asList( "#7356B6", "#9251AC", "#AE5775", "#C85D42", "#C23D4B", "#CE7C3A", "#6F8956", "#169570", "#217AB7", "#3D69BC", "#5458A7", "#52607F", "#3D4262" );

        public String GRADE = "Grade";
        public String INITIAL_PLACEMENT = "Initial Placement (IP)";
        public String CURRENT_LEVEL = "Current Level";
        public String TOTAL_GAIN = "Total Gain";

        // Student Usage
        public String ORGANIZATION_USAGE = "Organization Usage";
        public String STUDENT_USAGE = "Student Usage";
        public String STUDENT_AVERAGES = "Student Averages";
        List<String> STUDENT_AVERAGE_WEEK_HEADERS = new ArrayList<>( Arrays.asList( "THIS WEEK", "LAST WEEK", "SCHOOL YEAR" ) );
        List<String> X_AND_Y_AXIS_HEADERS = new ArrayList<>( Arrays.asList( "Weeks", "Hours" ) );
        public List<String> HEXA_COLORS_FOR_SUBJECTS = Arrays.asList( "#9ECA47", "#32325D" );

    }

    /**
     * Constants related to Shared Courses page
     *
     */
    public interface SharedCourses {
        public String HEADER = "Shared Courses";
        public String INVALID_SEARCH_RESULT = "No search results found";
        List<String> SHARED_COURSE_TABLE_HEADER = new ArrayList<>( Arrays.asList( "Course Name", "Course Owner", "Organizations Shared With" ) );

        public enum SHARED_COURSE_TABLE_HEADER {
            COURSE_NAME,
            COURSE_OWNER,
            ORGANIZATIONS_SHARED_WITH
        }

        public String ALPHA_NUMERIC_SPECIAL_CHAR = "Abc123!@#$   ";
        public String SEARCH_COURSE_NAME = "Search Course Name";
        public String COUNT_OF_COURSES = "%s-%s of %s";
        public String PAGE_COUNT = "Page %s of %s";
        public String ARIA_DISABLED = "aria-disabled";
        public String ORG_LIST_POPUP_HEADER = "Edit Share List";
        public String ORGANIZATIONS = "Organizations:";
        public String SHOW_SHARED_ONLY = "Show shared only";
        public String SHARE_ALL = "Share All";
        public String UNSAHERE_ALL = "Unshare All";
        public String CANCEL = "Cancel";
        public String SAVE = "Save";
        public String ORG = "org";
        public String NO_SHARED_ORGANIZATIONS = "No shared organizations.";

    }
    
    public interface AuditHistory {

        public String HEADER = "Audit History";
        public String URL = "https://ebsm-admin-dashboard-webapp-dev.smdemo.info/audit-history";
        public String TITLE = "Audit History: Assignments";
        public String ZERO_STATE_HEADER = "No results displayed";
        public String ZERO_STATE_MESSAGE = "Select from the organization list above to generate an audit history list for assignments.";
        public enum AUDIT_HISTORY_TABLE_HEADER {
            DELETED_BY,
            ASSIGNMENT_NAME,
            GROUP_STUDENT,
            TYPE,
            ASSIGNED_BY,
            COURSE,
            DATE_DELETED
        }
        public enum AUDIT_HISTORY_NAVIGATION_BUTTONS{
            FIRST,
            PREVIOUS,
            NEXT,
            LAST
        }
        public enum BUTTON_STATUS{
          ENABLED,
          DISABLED
        }
    }

}
