package com.savvas.sm.ui.tests.smnew.Mastery;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.mastery.pages.MasteryDetailsPage;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasteryPage;
import com.savvas.sm.ui.mastery.pages.MasterySummaryComponent;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class ContextualHelpMasteryTests extends BaseTest {
    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private String groupName;
    private String studentUserName1;
    String teacherDetails;
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = MasteryDataSetup.teacherUserName;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentUserName1 = MasteryDataSetup.studentUserName1;
        groupName = com.savvas.sm.utils.Constants.GROUP_NAME;
    }

    @Test ( description = "Verify the 'Group Details - Mastery' page", groups = { "SMK-59851" }, priority = 1 )
    public void tccontextualHelpGroupMastery001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "Verify the SM help Mastery page is loaded in a new tab when user is clicked 'i' icon present in the Mastery page. <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );
            // navigate to Groups Listing Page
            GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupPage.viewGroup( groupName );
            SMUtils.nap( 0.5 );
            groupPage.clickGroupsSubNav( Constants.MASTERY );

            //Group mastery help icon check
            SMUtils.logDescriptionTC( "Group Mastery Page - Verify the 'Group Details - Mastery' page is loaded in a new tab when user is clicked 'i' icon" );
            MasteryPage masteryPage = new MasteryPage( driver );
            SMUtils.clickJS( driver, masteryPage.getCellIcon() );
            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, masteryPage.getMasteryFromHelpPage(), 30 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( MasteryConstants.Labels.GROUP_MASTERY_HEADING ), "SM help Mastery page is loaded in a new tab", "SM help Mastery page is not loaded in a new tab" );
            driver.close();
            driver.switchTo().window( currentwindow );

            //Group Mastery Page -> LO view page top right corner help icon check
            SMUtils.logDescriptionTC( "Group Mastery LO details Page - Verify the 'Group Details - Mastery' page is loaded in a new tab when user is clicked the contextual help icon ('?') is present top right right side of the application page" );

            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();
            tHomePage.topNavBar.navigateToHelpPage();
            String currentwindowLOPage = driver.getWindowHandle();
            Set<String> windowsPage = driver.getWindowHandles();
            for ( String window : windowsPage ) {
                if ( !window.equalsIgnoreCase( currentwindowLOPage ) ) {
                    SMUtils.waitForElement( driver, masteryPage.getMasteryFromHelpPage(), 30 );
                    driver.switchTo().window( window );
                }
            }
            String titleLOPage = driver.getTitle();
            Log.assertThat( titleLOPage.equals( MasteryConstants.Labels.GROUP_MASTERY_HEADING ), "SM help Mastery page is loaded in a new tab", "SM help Mastery page is not loaded in a new tab" );
            driver.close();
            driver.switchTo().window( currentwindowLOPage );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Mastery sub tab in group details page", groups = { "SMK-59851" }, priority = 2 )
    public void tccontextualHelpStudentMastery002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tccontextualHelpStudentMastery002: Verify the SM help Mastery page is loaded in a new tab when user is clicked 'i' icon present in the Mastery page. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );
            // navigate to Groups Listing Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickviewStudentByEllipsis( studentUserName1.toLowerCase() );
            studentsPage.clickSubNavigation( com.savvas.sm.utils.Constants.Students.NAVIGATE_MASTERY );

            SMUtils.logDescriptionTC( "Students Mastery Page - Verify the 'Student Details - Mastery' page is loaded in a new tab when user is clicked 'i' icon" );
            MasteryPage masteryPage = new MasteryPage( driver );
            //Student mastery help icon check
            SMUtils.clickJS( driver, masteryPage.getCellIcon() );
            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, masteryPage.getMasteryFromHelpPage(), 30 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( MasteryConstants.Labels.STUDENT_MASTERY_HEADING ), "SM help Mastery page is loaded in a new tab", "SM help Mastery page is not loaded in a new tab" );
            driver.close();
            driver.switchTo().window( currentwindow );

            //Student Mastery -> LO view page top right corner help icon check
            SMUtils.logDescriptionTC( "Students Mastery LO details Page - Verify the 'Student Details - Mastery' page is loaded in a new tab when user is clicked the contextual help icon ('?') is present top right right side of the application page" );

            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();
            tHomePage.topNavBar.navigateToHelpPage();
            String currentwindowLOPage = driver.getWindowHandle();
            Set<String> windowsPage = driver.getWindowHandles();
            for ( String window : windowsPage ) {
                if ( !window.equalsIgnoreCase( currentwindowLOPage ) ) {
                    SMUtils.waitForElement( driver, masteryPage.getMasteryFromHelpPage(), 30 );
                    driver.switchTo().window( window );
                }
            }
            String titleLOPage = driver.getTitle();
            Log.assertThat( titleLOPage.equals( MasteryConstants.Labels.STUDENT_MASTERY_HEADING ), "SM help Mastery page is loaded in a new tab", "SM help Mastery page is not loaded in a new tab" );
            driver.close();
            driver.switchTo().window( currentwindowLOPage );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Mastery sub tab in group details page", groups = { "SMK-59851" }, priority = 3 )
    public void tccontextualHelpMastery003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tccontextualHelpMastery003: Verify the SM help Mastery page is loaded in a new tab when user is clicked 'i' icon present in the Mastery page. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            TeacherHomePage tHomePage = LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );
            tHomePage.topNavBar.navigateToMasteryTab();

            //Mastery help icon check
            SMUtils.logDescriptionTC( "Mastery Page - Verify the 'Mastery' page is loaded in a new tab when user is clicked 'i' icon" );
            MasteryPage masteryPage = new MasteryPage( driver );
            SMUtils.clickJS( driver, masteryPage.getCellIcon() );
            String currentwindow = driver.getWindowHandle();
            Set<String> windows = driver.getWindowHandles();
            for ( String window : windows ) {
                if ( !window.equalsIgnoreCase( currentwindow ) ) {
                    SMUtils.waitForElement( driver, masteryPage.getMasteryFromHelpPage(), 30 );
                    driver.switchTo().window( window );
                }
            }
            String title = driver.getTitle();
            Log.assertThat( title.equals( MasteryConstants.Labels.MASTERY_HEADING ), "SM help Mastery page is loaded in a new tab", "SM help Mastery page is not loaded in a new tab" );
            driver.close();
            driver.switchTo().window( currentwindow );

            //Mastery Page -> LO view page top right corner help icon check
            SMUtils.logDescriptionTC( "Mastery LO details Page - Verify the 'Mastery' page is loaded in a new tab when user is clicked the contextual help icon ('?') is present top right right side of the application page" );
            MasteryFiltersComponent masteryFiltersComponent = new MasteryFiltersComponent( driver );
            masteryFiltersComponent.applyFilter();

            MasterySummaryComponent masterySummaryComponent = new MasterySummaryComponent( driver );
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();
            tHomePage.topNavBar.navigateToHelpPage();
            String currentwindowLOPage = driver.getWindowHandle();
            Set<String> windowsPage = driver.getWindowHandles();
            for ( String window : windowsPage ) {
                if ( !window.equalsIgnoreCase( currentwindowLOPage ) ) {
                    SMUtils.waitForElement( driver, masteryPage.getMasteryFromHelpPage(), 30 );
                    driver.switchTo().window( window );
                }
            }
            String titleLOPage = driver.getTitle();
            Log.assertThat( titleLOPage.equals( MasteryConstants.Labels.GROUP_MASTERY_ASSESSMENT ), "SM help Mastery page is loaded in a new tab", "SM help Mastery page is not loaded in a new tab" );
            driver.close();
            driver.switchTo().window( currentwindowLOPage );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
