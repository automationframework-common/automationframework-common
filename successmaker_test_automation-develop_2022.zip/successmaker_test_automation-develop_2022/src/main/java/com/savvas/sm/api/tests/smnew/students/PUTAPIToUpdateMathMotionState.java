package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

import io.restassured.response.Response;

public class PUTAPIToUpdateMathMotionState extends EnvProperties {
	
	private String smUrl;
    private String teacherDetails;
    private String teacherUsername;
    private String teacherUserId;
    private String orgId;
    private String studentDetails;
    private String studentUsername;
    private String studentUserId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private List<String> studentRumbaIds = new ArrayList<>();
    private Map<String, String> courseName = new HashMap<>();
    private Map<String, String> courseIds = new HashMap<>();
    private Map<String, String> assignmentIds = new HashMap<>();
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String browser;
    String assignmentUserId;
    HashMap<String, String> payLoad = new HashMap<>();
    String lo;
    public static String isItMt = "";
    
    @BeforeClass ( alwaysRun = true )
    public void init() throws Exception {
        // Retrieving URL from Config.properites
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        studentDetails = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );

        //Math Course Names
        courseName.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
        
        String teacherAccessToken = null;
        try {
            teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Issue in get the accces token - " + e.getMessage() );
            try {
                Log.message( "Retrying to get the access token!!!!" );
                teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            } catch ( Exception e1 ) {
                Log.fail( "Unable to create the access token for the teacher - " + teacherUsername );
            }
        }

        try {
            courseIds.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );

        } catch ( Exception e ) {
            Log.message( "Issue in Reading Custom course creation!! - " + e.getMessage() );
        }

        Log.message( "Course Ids for " + school + ": " + courseIds );

        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        staffDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        try {
            //Assigning Assignment
            Log.message( "Assigning assignment..." );

            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, studentRumbaIds, new ArrayList<>( courseIds.values() ) );
            Log.message( "Assignment Response : " + assignmentResponse );

            JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
            JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

            for ( Object assignment : assignmentList ) {
                JSONObject assignmentInfo = new JSONObject( assignment.toString() );
                assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
            }
            Log.message( "Assignment IDs - " + assignmentIds );
        } catch ( Exception e ) {
            Log.fail( "Issue in Assigning the assignment to the student!! - " + e.getMessage() );
        }
        isItMt = configProperty.getProperty( "isMTExecution" );
        
    }
    
    @Test ( priority = 1, dataProvider = "putAPIUpdateMotionPositive", groups = { "smoke_test_case", "SMK-51959", "SMK-66848", "Students", "Update Math Motion State", "P1", "API" } )
    public void tcPositiveTestcases( String tcId, String description, String scenario, String statusCode ) throws Throwable {
        Log.testCaseInfo( tcId + ":-" + description );
       // Response response = null;
        String body = "";
        Map<String, String> response = new HashMap<>();        
        String sessionId;
        List<String> dbUpdatedLoData;
        
        switch ( scenario ) {
        case "VALID_DEFAULT_MATH":
        	lo = getLOID( Constants.MATH );
            payLoad = getLoDetailsForPayload( lo );
            
        	assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );
            sessionId = getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );            
            
            response = putUpdateMathMotionState( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId, payLoad, scenario );
            new RBSUtils().getAccessToken( studentUsername, password );
            Log.message( response.get( Constants.STATUS_CODE ) );
            Log.message( response.get( Constants.REPORT_BODY ) );
            //Status code validation
            Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
            dbUpdatedLoData = getDBUpdatedLOData( assignmentUserId );
            Log.message( "Strand Level: "+dbUpdatedLoData.get( 0 ) );
            Log.message( "Tutorial Seen Flag: "+dbUpdatedLoData.get( 1 ) );
            Log.assertThat( payLoad.get( "strandLoLevel" ).contains( dbUpdatedLoData.get( 0 ) ), "Strand Level is same as DB details", "Strand Level is not same as DB details" );
            Log.assertThat( CourseAPIConstants.STRING_ONE.equals( dbUpdatedLoData.get( 1 ) ), "Tutorial Seen Flag is same as DB details", "Tutorial Seen Flag is not same as DB details" );
            break;
        }
    }
    
    @DataProvider ( name = "putAPIUpdateMotionPositive" )
    public Object[][] putAPIUpdateMotionPositive() {

        Object[][] inputData = {
                { "TC_001PUTUpdateMathMotion", "Verify the status code as 200 for PUT call for Update Math Motion State API changes", "VALID_DEFAULT_MATH", CommonAPIConstants.STATUS_CODE_OK },
                };

        return inputData;
    }
    
    /**
     * To Update Math Motion State
     * 
     * @param smUrl
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @param sessionId
     * @param mathMotionState
     * @param scenario
     * @return
     * @throws Throwable 
     */
    public HashMap<String, String> putUpdateMathMotionState( String smUrl, String userId, String orgId, String studentUsername, String password, String assignemntUserId, String sessionId, HashMap<String, String> mathMotionPayload, String scenario ) throws Throwable {
        String endPoint = "/lms/web/assignments/math/motion/{auId}".replace( "{auId}", assignemntUserId );
        String payload = null;
        if(scenario.equalsIgnoreCase( "VALID_DEFAULT_MATH" ) ) {
        payload = SMUtils.convertFileToString( new EnvProperties().configProperty.getProperty( "putUpdateMathMotionState_ValidMath" ) );
        }
        //Parameters
        HashMap<String, String> params = new HashMap<>();
        Map<String, String> header = new HashMap<>();
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + "" + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            Log.fail( "Issue in getting the accesstoken for student - " + studentUsername );
        }
        header.put( LicenseAPIConstants.USERID, userId );
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( "session-id", sessionId );
        header.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        
        payload = payload.replace( "{strand_Id}", mathMotionPayload.get( "strandName" ) );
        payload = payload.replace( "{strand_Level}", mathMotionPayload.get( "strandLoLevel" ) );
        payload = payload.replace( "{tutorial_Seen_Flag}", CourseAPIConstants.STRING_ONE );
        payload = payload.replace( "{lo_performance}", "" );
        payload = payload.replace( "{course_level}", mathMotionPayload.get( "strandLoLevel" ) );
        Log.message( "Updated Payload: "+payload );
        
        return RestHttpClientUtil.PUT( smUrl, header, params, endPoint, payload );
       
    }
    /**
     * To Create and get the session Id for given student
     *
     * @param userId
     * @param orgId
     * @param studentUsername
     * @param password
     * @param assignemntUserId
     * @return
     */
    public String getSessionId( String smUrl, String userId, String orgId, String studentUsername, String password, String assignmentUserId ) {
        String endPoint1 = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        List<String> pathParamsList = new ArrayList<>();
        HashMap<String, String> header = new HashMap<>();
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( LicenseAPIConstants.USERID, userId );
        try {
            header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( studentUsername, password ) );
        } catch ( Exception e ) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        pathParamsList.add( assignmentUserId );
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint1, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, header, endPoint1, pathParams );
        Log.message( response.getBody().asString() );
        String sessionId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ), "sessionId" );
        Log.message( "Session ID  - " + sessionId );
        return sessionId;
    }
    
    /**
     * This method is used to get Lo details for Math from DB.
     * 
     * @param Lo
     */
    public static HashMap<String, String> getLoDetailsForPayload( String lo) {
        HashMap<String, String> payLoad = new HashMap<String, String>();
        String queryString = "Select ms.strand_name, lo.catalog_num, mslo.strand_lo_level from math_strand ms, learning_object lo, math_strand_learning_object mslo where ms.strand_id=mslo.strand_id and mslo.learning_object_id=lo.learning_object_id and catalog_num='" + lo + "'";
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
                arrList.add( list[1].toString() );
                arrList.add( list[2].toString() );
            }
        }
        payLoad.put( "strandName", arrList.get( 0 ) );
        payLoad.put( "loName", arrList.get( 1 ) );
        payLoad.put( "strandLoLevel", arrList.get( 2 ) );
        
        return payLoad;
    }
    
    /**
     * To get LOID with bankID for Different subjects
     * 
     * @param courseType
     * @return
     * @throws IOException
     */
    public static String getLOID( String courseType ) throws IOException {
        String bankID = "";
        String loID = "";
        List<String> standardID = SqlHelperAssignment.getRandomStandardGradeID( courseType, isItMt.equalsIgnoreCase( "true" ) );
        String query = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getLObyStandard.sql" );
        List<String> loIds = new ArrayList<String>();
        query = query.replace( "<standard_id>", standardID.get( 0 ) ).replace( "<grade_id>", standardID.get( 1 ) );
        List<Object[]> result = SQLUtil.executeQuery( query );
        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                bankID = list[0].toString();
                loID = list[1].toString();
            }
        }
        String[] splitIndividualID = loID.split( ";" );
        for ( int loCount = 0; loCount < 1; loCount++ ) {
            loIds.add( splitIndividualID[loCount] );
        }
        loID = loIds.get( 0 );
        Log.message( "LO id is " + loIds.get( 0 ) );
        return loID;
    }
    
    public static List<String> getDBUpdatedLOData( String auid ) {
        String queryString = "SELECT strand_level, tutorial_seen_flag FROM school.math_auser_motion_strand WHERE assignment_user_id = '" + auid + "'";
        List<Object[]> result = SQLUtil.executeQuery( queryString );
        List<String> details = new ArrayList<String>();
        for ( Object[] list : result ) {
            details.add( list[0].toString() );
            details.add( list[1].toString() );
        }
        return details;
    }

}
