package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

/**
 * This class used to test the API of POST method for Assignments for Unassigned
 * Students
 * 
 * 
 *
 */

public class PostAssignmentsforUnassignedStudents extends AssignmentAPI {

	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	private String smUrl;
	private String teacherDetails = null;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	String orgId;
	String districtId;
	String teacherId;
	String token;
	List<String> studentRumbaIds;
	String endpoint;
	List<String> StudentA = new ArrayList<>();
	List<String> mathSchoolStudentRumbaIds = new ArrayList<>();
	HashMap<String, String> mathSchoolStudentDetails = new HashMap<>();
	HashMap<String, String> mathSchoolAssignmentDetails = new HashMap<>();
	HashMap<String, String> readingSchoolAssignmentDetails = new HashMap<>();
	SMAPIProcessor smAPIprocessor;
	String studentDetail;
	String studentUserID;
	String studentUsername;
	String teacherusername;
	String studentDetail1;
	String studentDetail2;
	String studentDetail3;
	String studentUserID1;
	String studentUserID2;
	String studentUserID3;
	String studentusername1;
	String studentusername2;
	String studentusername3;
	GroupAPI add = new GroupAPI();
	String CourseId;
	CourseAPI courseAPI = new CourseAPI();
	String groupId;
	String customCourse;
	List<String> groupIds = new ArrayList<>();

	@BeforeClass(alwaysRun = true)
	public void BeforeTest() throws Exception {

		smUrl = configProperty.getProperty("SMAppUrl");
		districtId = configProperty.getProperty("district_ID");
		orgId = RBSDataSetup.organizationIDs.get(school);

		teacherDetails = RBSDataSetup.getMyTeacher(school);
		teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		teacherusername = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);

		studentDetail1 = RBSDataSetup.getMyStudent(school, teacherusername);
		studentUserID1 = SMUtils.getKeyValueFromResponse(studentDetail1, Constants.USERID_HEADER);
		studentusername1 = SMUtils.getKeyValueFromResponse(studentDetail1, RBSDataSetupConstants.USERNAME);

		studentDetail2 = RBSDataSetup.getMyStudent(school, teacherusername);
		studentUserID2 = SMUtils.getKeyValueFromResponse(studentDetail2, Constants.USERID_HEADER);
		studentusername2 = SMUtils.getKeyValueFromResponse(studentDetail2, RBSDataSetupConstants.USERNAME);

		studentDetail3 = RBSDataSetup.getMyStudent(school, teacherusername);
		studentUserID3 = SMUtils.getKeyValueFromResponse(studentDetail3, Constants.USERID_HEADER);
		studentusername3 = SMUtils.getKeyValueFromResponse(studentDetail3, RBSDataSetupConstants.USERNAME);

		HashMap<String, String> assignmentDetails = new HashMap<>();
		HashMap<String, String> groupDetails = new HashMap<>();
		HashMap<String, String> userDetails = new HashMap<>();
		HashMap<String, String> studentResponse = new HashMap<>();
		List<String> courseIDs = new ArrayList<>();

		customCourse = "Custom Math - " + System.nanoTime();
		token = new RBSUtils().getAccessToken(teacherusername, RBSDataSetupConstants.DEFAULT_PASSWORD);
		CourseId = courseAPI.createCourse(smUrl, token, DataSetupConstants.MATH, teacherId, orgId,
				DataSetupConstants.SETTINGS, customCourse);
		assignmentDetails.put(AssignmentAPIConstants.COURSE_ID, CourseId);

		groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN,
				new RBSUtils().getAccessToken(teacherusername, RBSDataSetupConstants.DEFAULT_PASSWORD));
		groupDetails.put(CreateGroupAPIConstants.GROUP_OWNER_ID,
				SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		groupDetails.put(CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetails.put(CreateGroupAPIConstants.GROUP_NAME, "Maths Course Group");

		HashMap<String, String> response = add.createGroup(smUrl, groupDetails,
				Arrays.asList(studentUserID1, studentUserID2, studentUserID3));
		if (response.get(Constants.STATUS_CODE).equals(CommonAPIConstants.STATUS_CODE_CREATED)) {
			Log.message("Group created for the student !");
		}
		Log.message(response.get("body"));
		String groupId = SMUtils.getKeyValueFromResponse(response.get(Constants.REPORT_BODY),
				Constants.GROUP_ID_DATAVALUE);

		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);

		response = assignMultipleAssignments(smUrl, assignmentDetails, Arrays.asList(studentUserID3),
				Arrays.asList(CourseId));

	}

	@Test(priority = 1, dataProvider = "getassignmentsUnassignedStudents_PositiveFlow", groups = { "SMK-51900",
			"smoke_test_case", "Assignments", "Unassigned_Assignment", "P1", "API" })
	public void tc01_getassignmentsUnassignedStudetns(String description, String scenario, String statusCode)
			throws Exception {

		Log.testCaseInfo(description);

		HashMap<String, String> assignmentDetails = new HashMap<>();

		endpoint = "null";

		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);

		switch (scenario) {

		case "TC01":
			HashMap<String, String> getresponse = getAssignmentsunassignedStudent(smUrl, assignmentDetails,
					studentUserID1, endpoint);
			Log.message(getresponse.get("body"));
			Log.assertThat(getresponse.get("statusCode").equals(statusCode), "Status code is matched",
					"Status code is mismatched");
			VerifySchema(getresponse.get("statusCode"), getresponse);
			break;

		default:
			Log.fail("Case is invalid");
			break;
		}

		Log.testCaseResult();
		Log.endTestCase();

	}

	/**
	 * Data provider to give the positive data
	 * 
	 * @return
	 */
	@DataProvider(name = "getassignmentsUnassignedStudents_PositiveFlow")
	public Object[][] postAssignmentsforUnassignedStudents_PositiveFlow() {
		Object[][] inputData = { {
				"Verify that the status code is 200 and response is as expected while passing valid input for users type",
				"TC01", CommonAPIConstants.STATUS_CODE_OK },

		};
		return inputData;
	}

	@Test(priority = 2, dataProvider = "getassignmentsUnassignedStudetns_NegativeFlow", groups = { "SMK-51900",
			"Assignments", "AssignmentUserSettings", "P2", "API" })
	public void tc02_UpdateAssignmentUserSettings(String description, String scenario, String statusCode)
			throws Exception {

		Log.testCaseInfo(description);

		HashMap<String, String> assignmentDetails = new HashMap<>();
		endpoint = "null";
		assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);

		switch (scenario) {
		case "TC001_INVALID_ORG_ID_IN_HEADER":
			endpoint = AssignmentAPIConstants.GET_ASSIGNMENTS_UNASSIGNED_STUDENTS;
			endpoint = endpoint.replace("{orgID}", assignmentDetails.get(AssignmentAPIConstants.ORG_ID))
					.replace("{teacherID}", assignmentDetails.get(AssignmentAPIConstants.TEACHER_ID));
			assignmentDetails.put(AssignmentAPIConstants.ORG_ID, "1234$");
			break;

		case "TC002_INVALID_STAFF_ID_IN_HEADER":
			endpoint = AssignmentAPIConstants.GET_ASSIGNMENTS_UNASSIGNED_STUDENTS;
			endpoint = endpoint.replace("{orgID}", assignmentDetails.get(AssignmentAPIConstants.ORG_ID))
					.replace("{teacherID}", assignmentDetails.get(AssignmentAPIConstants.TEACHER_ID));
			assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, "1234$");
			break;

		case "TC003_INVALID_AUTHORIZATION":
			assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN);
			break;

		case "TC004_INVALID_ORG_ID_PATH_PARAM":
			endpoint = AssignmentAPIConstants.GET_ASSIGNMENTS_UNASSIGNED_STUDENTS;
			endpoint = endpoint.replace("{orgID}", "1234$").replace("{teacherID}",
					assignmentDetails.get(AssignmentAPIConstants.TEACHER_ID));
			break;

		case "TC005_INVALID_STAFF_ID_PATH_PARAM":
			endpoint = AssignmentAPIConstants.GET_ASSIGNMENTS_UNASSIGNED_STUDENTS;
			endpoint = endpoint.replace("{orgID}", assignmentDetails.get(AssignmentAPIConstants.ORG_ID))
					.replace("{teacherID}", "123");
			break;

		case "TC006_INVALID_DATA_TYPE_PATH_PARAM":
			endpoint = AssignmentAPIConstants.GET_ASSIGNMENTS_UNASSIGNED_STUDENTS;
			endpoint = endpoint.replace("{orgID}", "aa").replace("{teacherID}", "bb");
			break;

		case "TC007_INVALID_URL":
			endpoint = AssignmentAPIConstants.GET_ASSIGNMENTS_UNASSIGNED_STUDENTS;
			endpoint = endpoint.replace("{orgID}", assignmentDetails.get(AssignmentAPIConstants.ORG_ID))
					.replace("{teacherID}", assignmentDetails.get(AssignmentAPIConstants.TEACHER_ID))
					.replace("organizations", "organizationssss");
			break;

		default:
			Log.fail("Case is invalid");
			break;

		}

		HashMap<String, String> getresponse = getAssignmentsunassignedStudent(smUrl, assignmentDetails, studentUserID3,
				endpoint);
		Log.message("StatusCode: " + getresponse.get("statusCode"));
		Log.message(getresponse.get("body"));
		Log.assertThat(getresponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
				"Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode
						+ " Actual - " + getresponse.get(Constants.STATUS_CODE));

		Log.testCaseResult();
		Log.endTestCase();

	}

	/**
	 * Data provider to give the Negative data
	 * 
	 * @return
	 */
	@DataProvider(name = "getassignmentsUnassignedStudents_NegativeFlow")
	public Object[][] updateAssignmentUserSettings_NegativeFlow() {
		Object[][] inputData = {

				{ "Verify the status code is 403 and response body - Incorrect orgId in Headers",
						"TC001_INVALID_ORG_ID_IN_HEADER", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
				{ "Verify the status code is 401 and response body - invalid Staff-Id in headers",
						"TC002_INVALID_STAFF_ID_IN_HEADER", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
				{ "Verify the response body of 401 and response body - Invalid Bearer Token",
						"TC003_INVALID_AUTHORIZATION", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
				{ "Verify 400 status code and response body, with invalid organisationId in the path params",
						"TC004_INVALID_ORG_ID_PATH_PARAM", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify 400 status code and response body, with Invalid staffId in path params",
						"TC005_INVALID_STAFF_ID_PATH_PARAM", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify 400 status code and response body, for Path parameters with Invalid Datatype",
						"TC006_INVALID_DATA_TYPE_PATH_PARAM", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify 400 status code and response body, for Path parameters with Invalid Datatype",
						"TC006_INVALID_DATA_TYPE_PATH_PARAM", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify the status code is 404 when the URL is wrong", "TC007_INVALID_URL",
						CommonAPIConstants.STATUS_CODE_NOTFOUND }, };
		return inputData;
	}

	/**
	 * Verify the Schema for the API
	 * 
	 * @param StatusCode
	 * @param Body
	 */
	public void VerifySchema(String StatusCode, HashMap<String, String> response) {
		boolean isValid = false;
		try {
			isValid = new SMAPIProcessor().isSchemaValid("assignmentsforUnassignedStudents", StatusCode,
					response.get("body"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Log.assertThat(isValid, "The schema is valid and matching",
				"The schema is not valid and not  mathcing for the Status code :" + StatusCode);
	}

}
