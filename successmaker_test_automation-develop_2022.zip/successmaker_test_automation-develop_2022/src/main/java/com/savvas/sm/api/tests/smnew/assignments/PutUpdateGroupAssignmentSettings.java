package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetupProcessor;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class PutUpdateGroupAssignmentSettings extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String flexSchoolTeacherDetails = null;
    private String mathSchoolTeacherDetails = null;
    private String readingSchoolTeacherDetails = null;
    private String focusReadingSchoolTeacherDetails = null;
    private String focusMathSchoolTeacherDetails = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String readingSchool = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String focusMathSchool = RBSDataSetup.getSchools( Schools.MATH_FOCUS_SCHOOL );
    private String focusReadingSchool = RBSDataSetup.getSchools( Schools.READING_FOCUS_SCHOOL );
    private String token = null;
    private String userName = null;
    private String schoolType = null;
    private String courseId;
    private String orgId;
    private String teacherId;
    private String groupId = null;
    private String sessionLengthName = null;
    private Long sessionLengthId = null;
    private String sessionLengthValue = null;
    private String idleTimeName = null;
    private Long idleTimeId = null;
    private String idleTimeValue = null;
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        mathSchoolTeacherDetails = RBSDataSetup.getMyTeacher( mathSchool );
        readingSchoolTeacherDetails = RBSDataSetup.getMyTeacher( readingSchool );
        focusMathSchoolTeacherDetails = RBSDataSetup.getMyTeacher( focusMathSchool );
        focusReadingSchoolTeacherDetails = RBSDataSetup.getMyTeacher( focusReadingSchool );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    //Positive flow
    @Test ( priority = 1, dataProvider = "putUpdateGroupAssignmentSetting_PositiveFlow", groups = { "SMK-51913", "GroupAssignmentsSettings", "GroupAssignments", "P1", "API", "smoke_test_case" } )
    public void tcPutUpdateGroupAssignmentSetting_01( String testCaseDescription, String testScenario, String courseType, String statusCode, String schoolTypeForTokenCreation ) throws Exception {

        //Test case description
        Log.testCaseInfo( testCaseDescription );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> updatedGroupAssignmentSettings = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        HashMap<String, String> response = new HashMap<>();

        //Creating school based one the licenses
        tokenCreation( schoolTypeForTokenCreation );

        //Adding students to group
        studentRumbaIds = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, userName, schoolType );

        //Assignment details
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.GROUP_ID, groupId );

        updatedGroupAssignmentSettings.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.GROUP_ID, groupId );

        List<String> groupIds = new ArrayList<>();
        groupIds.add( groupId );

        //Different test scenarios
        switch ( testScenario ) {

            case "TEACHER ASSIGNED DEFAULT MATH":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );

                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                break;

            case "TEACHER ASSIGNED DEFAULT READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );

                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                break;

            case "TEACHER ASSIGNED FOCUS READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );

                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                break;

            case "TEACHER ASSIGNED FOCUS MATH":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );

                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                break;

            case "CUSTOM SETTINGS MATH":
                courseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.SETTINGS,
                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, courseId );

                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                break;

            case "CUSTOM SKILL MATH":
                courseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.SKILL,
                        String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, courseId );

                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                break;

            case "CUSTOM STANDARD MATH":
                courseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.STANDARD,
                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, courseId );

                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                break;

            case "CUSTOM SETTINGS READING":
                courseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.SETTINGS,
                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, courseId );

                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                break;

            case "CUSTOM SKILL READING":
                courseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.SKILL,
                        String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, courseId );

                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                break;

            case "CUSTOM STANDARD READING":
                courseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.STANDARD,
                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.COURSE_ID, courseId );

                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                break;

            default:
                Log.fail( "Case is invalid" );
                break;
        }

        HashMap<String, String> apiResponseGetGroupAssignmentSettings = getGroupAssignmentSettings( smUrl, assignmentDetails );

        //Please remove before final merge
        Log.message( "Response is " + apiResponseGetGroupAssignmentSettings );

        JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj( apiResponseGetGroupAssignmentSettings.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

        JSONObject data2 = getSettingsResp.getJSONObject( "SESSION_LENGTH" );
        sessionLengthName = data2.getString( "name" );
        sessionLengthId = data2.getLong( "id" );
        sessionLengthValue = data2.getString( "currentValue" );
        Log.message( "Name of the session length : " + sessionLengthName );
        Log.message( "Id of the session length : " + sessionLengthId );
        Log.message( "CurrentValue of the session length : " + sessionLengthValue );

        JSONObject data3 = getSettingsResp.getJSONObject( "IDLE_TIME" );
        idleTimeName = data3.getString( "name" );
        idleTimeId = data3.getLong( "id" );
        idleTimeValue = data3.getString( "currentValue" );
        Log.message( "Name of the idleTime : " + idleTimeName );
        Log.message( "Id of the idleTime : " + idleTimeId );
        Log.message( "CurrentValue of the idleTime : " + idleTimeValue );

        //Updating the Settings As per Scenarios

        //Update the setting as per your need
        updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_ID, String.valueOf( sessionLengthId ) );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_NAME, sessionLengthName );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_VALUE, "14" );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
        updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, "4" );

        //Updating the Custom By Settings
        HashMap<String, String> apiResponseUpdatedGroupAssignmentSetting = updateGroupAssignmentSetting1( smUrl, assignmentDetails, updatedGroupAssignmentSettings, courseType );
        Log.message( "Update course setting response: " + apiResponseUpdatedGroupAssignmentSetting );

        apiResponseGetGroupAssignmentSettings = getGroupAssignmentSettings( smUrl, assignmentDetails );

        getSettingsResp = SMUtils.convertResponseAsJsonObj( apiResponseGetGroupAssignmentSettings.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

        data2 = getSettingsResp.getJSONObject( "SESSION_LENGTH" );

        Log.softAssertThat( data2.getString( "currentValue" ).equals( "14" ), "Current value of session length is as expected", "Current value of session length is not as expected" );

        data3 = getSettingsResp.getJSONObject( "IDLE_TIME" );

        Log.softAssertThat( data3.getString( "currentValue" ).equals( "4" ), "Current value of idle time is as expected", "Current value of idle time  is not as expected" );

        Log.testCaseResult();
    }

    /**
     * Data provider to give the postive data
     * 
     * @return
     */
    @DataProvider ( name = "putUpdateGroupAssignmentSetting_PositiveFlow" )
    public Object[][] put1UpdateGroupAssignmentSetting_PositiveFlow() {

        Object[][] inputData = {

                { "Verify the status code is 200 and the response is as expected while updating assignment setting for Default Math", "TEACHER ASSIGNED DEFAULT MATH", DataSetupConstants.MATH, CommonAPIConstants.STATUS_CODE_OK,
                        CommonAPIConstants.MATH_LICENSE_SCHOOL },
                { "Verify the status code is 200 and the response is as expected while updating assignment setting for Default Reading", "TEACHER ASSIGNED DEFAULT READING", DataSetupConstants.READING, CommonAPIConstants.STATUS_CODE_OK,
                        CommonAPIConstants.READING_LICENSE_SCHOOL },
                { "Verify the status code is 200 and the response is as expected while updating assignment setting for Focus Reading", "TEACHER ASSIGNED FOCUS READING", DataSetupConstants.READING, CommonAPIConstants.STATUS_CODE_OK,
                        CommonAPIConstants.FOCUS_READING_LICENSE_SCHOOL },
                { "Verify the status code is 200 and the response is as expected while updating assignment setting for Focus Math", "TEACHER ASSIGNED FOCUS MATH", DataSetupConstants.MATH, CommonAPIConstants.STATUS_CODE_OK,
                        CommonAPIConstants.FOCUS_MATH_LICENSE_SCHOOL },
                { "Verify the status code is 200 and the response is as expected while updating assignment setting for Custom Settings Math", "CUSTOM SETTINGS MATH", DataSetupConstants.MATH, CommonAPIConstants.STATUS_CODE_OK,
                        CommonAPIConstants.FLEX_LICENSE_SCHOOL },
                { "Verify the status code is 200 and the response is as expected while updating assignment setting for Custom Skill Math", "CUSTOM SKILL MATH", DataSetupConstants.MATH, CommonAPIConstants.STATUS_CODE_OK,
                        CommonAPIConstants.FLEX_LICENSE_SCHOOL },
                { "Verify the status code is 200 and the response is as expected while updating assignment setting for Custom Standards Math", "CUSTOM STANDARD MATH", DataSetupConstants.MATH, CommonAPIConstants.STATUS_CODE_OK,
                        CommonAPIConstants.FLEX_LICENSE_SCHOOL },
                { "Verify the status code is 200 and the response is as expected while updating assignment setting for Custom Settings Reading", "CUSTOM SETTINGS READING", DataSetupConstants.READING, CommonAPIConstants.STATUS_CODE_OK,
                        CommonAPIConstants.FLEX_LICENSE_SCHOOL },
                { "Verify the status code is 200 and the response is as expected while updating assignment setting for Custom Skill Reading", "CUSTOM SKILL READING", DataSetupConstants.READING, CommonAPIConstants.STATUS_CODE_OK,
                        CommonAPIConstants.FLEX_LICENSE_SCHOOL },
                { "Verify the status code is 200 and the response is as expected while updating assignment setting for for Custom Standards Reading", "CUSTOM STANDARD READING", DataSetupConstants.READING, CommonAPIConstants.STATUS_CODE_OK,
                        CommonAPIConstants.FLEX_LICENSE_SCHOOL } };

        return inputData;
    }

    //Negative flow
    @Test ( priority = 2, dataProvider = "putUpdateGroupAssignmentSetting_NegativeFlow", groups = { "SMK-51913", "GroupAssignmentsSettings", "GroupAssignments", "P1", "API" } )
    public void tcPutUpdateGroupAssignmentSetting_02( String testCaseDescription, String testScenario, String courseType, String statusCode, String schoolTypeForTokenCreation ) throws Exception {

        //Test case description
        Log.testCaseInfo( testCaseDescription );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        HashMap<String, String> response = new HashMap<>();
        HashMap<String, String> updatedGroupAssignmentSettings = new HashMap<>();
        HashMap<String, String> apiResponseGetGroupAssignmentSettings = new HashMap<>();

        //Exception message checks variables
        String message = null;
        String exception = null;
        boolean status = false;

        //Creating school based one the licenses
        tokenCreation( schoolTypeForTokenCreation );

        //Adding students to group
        studentRumbaIds = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, userName, schoolType );

        //Assignment details
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.GROUP_ID, groupId );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        List<String> groupIds = new ArrayList<>();
        groupIds.add( groupId );

        switch ( testScenario ) {
            case "NON EXISTING COURSEID MATH":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                apiResponseGetGroupAssignmentSettings = getGroupAssignmentSettings( smUrl, assignmentDetails );
                updatedGroupAssignmentSettings = commonCodeForNegativeFlow( apiResponseGetGroupAssignmentSettings );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.GROUP_ID, groupId );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.COURSE_ID, "10000" );

                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.NONEXIST_COURSEID_MATH;
                status = true;
                break;

            case "NON EXISTING COURSEID READING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                apiResponseGetGroupAssignmentSettings = getGroupAssignmentSettings( smUrl, assignmentDetails );
                updatedGroupAssignmentSettings = commonCodeForNegativeFlow( apiResponseGetGroupAssignmentSettings );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.GROUP_ID, groupId );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.COURSE_ID, "20000" );

                exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
                message = CommonAPIConstants.NONEXIST_COURSEID_READING;
                status = true;
                break;

            case "INVALID ORGANIZATION":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                apiResponseGetGroupAssignmentSettings = getGroupAssignmentSettings( smUrl, assignmentDetails );
                updatedGroupAssignmentSettings = commonCodeForNegativeFlow( apiResponseGetGroupAssignmentSettings );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.GROUP_ID, groupId );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, "zzinvalidorgId" );

                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                status = true;
                break;

            case "INVALID AUTHORIZATION":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                apiResponseGetGroupAssignmentSettings = getGroupAssignmentSettings( smUrl, assignmentDetails );
                updatedGroupAssignmentSettings = commonCodeForNegativeFlow( apiResponseGetGroupAssignmentSettings );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.GROUP_ID, groupId );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );

                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "INVALID COURSE_ID":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                apiResponseGetGroupAssignmentSettings = getGroupAssignmentSettings( smUrl, assignmentDetails );
                updatedGroupAssignmentSettings = commonCodeForNegativeFlow( apiResponseGetGroupAssignmentSettings );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.GROUP_ID, groupId );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.COURSE_ID, "!@$" );

                message = null;
                status = true;
                break;

            case "INVALID COURSE_ID_STRING":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                apiResponseGetGroupAssignmentSettings = getGroupAssignmentSettings( smUrl, assignmentDetails );
                updatedGroupAssignmentSettings = commonCodeForNegativeFlow( apiResponseGetGroupAssignmentSettings );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.GROUP_ID, groupId );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.COURSE_ID, "RRR" );

                message = null;
                status = true;
                break;

            case "NULL COURSE_ID":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                response = assignAssignment( smUrl, assignmentDetails, groupIds, AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( response.get( Constants.RESPONSE_BODY ) );
                apiResponseGetGroupAssignmentSettings = getGroupAssignmentSettings( smUrl, assignmentDetails );
                updatedGroupAssignmentSettings = commonCodeForNegativeFlow( apiResponseGetGroupAssignmentSettings );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                updatedGroupAssignmentSettings.put( CourseAPIConstants.GROUP_ID, groupId );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolType ) );
                updatedGroupAssignmentSettings.put( AssignmentAPIConstants.COURSE_ID, "" );

                message = null;
                status = true;
                break;

            default:
                Log.message( "Case is invalid" );
                break;

        }

        //Updating the Custom By Settings
        HashMap<String, String> apiResponseUpdatedGroupAssignmentSetting = updateGroupAssignmentSetting1( smUrl, assignmentDetails, updatedGroupAssignmentSettings, courseType );
        Log.message( "Update course setting response: " + apiResponseUpdatedGroupAssignmentSetting );
        Log.assertThat( apiResponseUpdatedGroupAssignmentSetting.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                "Issue in returning status code! Expected - " + statusCode + " Actual - " + apiResponseUpdatedGroupAssignmentSetting.get( Constants.STATUS_CODE ) );
        Log.message( apiResponseUpdatedGroupAssignmentSetting.get( Constants.STATUS_CODE ) );
        Log.message( apiResponseUpdatedGroupAssignmentSetting.get( Constants.RESPONSE_BODY ) );
        if ( message != null ) {
            verifyException( apiResponseUpdatedGroupAssignmentSetting.get( Constants.RESPONSE_BODY ), exception, status, message );
        }

        Log.testCaseResult();

    }

    /**
     * Data provider to give the negative data
     * 
     * @return
     */

    @DataProvider ( name = "putUpdateGroupAssignmentSetting_NegativeFlow" )
    public Object[][] putUpdateGroupAssignmentSetting_NegativeFlow() {

        Object[][] inputData = { { "Verify the non existing course id for Math", "NON EXISTING COURSEID MATH", DataSetupConstants.MATH, CommonAPIConstants.STATUS_CODE_OK, CommonAPIConstants.FLEX_LICENSE_SCHOOL },
                { "Verify the non existing course id for Reading.", "NON EXISTING COURSEID READING", DataSetupConstants.READING, CommonAPIConstants.STATUS_CODE_OK, CommonAPIConstants.FLEX_LICENSE_SCHOOL },
                { "Verify the API returns exception when the organization is invalid.", "INVALID ORGANIZATION", DataSetupConstants.MATH, CommonAPIConstants.STATUS_CODE_FORBIDDAN, CommonAPIConstants.FLEX_LICENSE_SCHOOL },
                { "Verify the API throwing exception when the authorization is invalid.", "INVALID AUTHORIZATION", DataSetupConstants.READING, CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, CommonAPIConstants.FLEX_LICENSE_SCHOOL },
                { "Verify the API throwing exception when the Course id is invalid. ", "INVALID COURSE_ID", DataSetupConstants.READING, CommonAPIConstants.STATUS_CODE_BAD_REQUEST, CommonAPIConstants.FLEX_LICENSE_SCHOOL },
                { "Verify the API throwing exception when the Course id is String. ", "INVALID COURSE_ID_STRING", DataSetupConstants.READING, CommonAPIConstants.STATUS_CODE_BAD_REQUEST, CommonAPIConstants.FLEX_LICENSE_SCHOOL },
                { "Verify the API throwing exception when the Course id is non null ", "NULL COURSE_ID", DataSetupConstants.READING, CommonAPIConstants.STATUS_EMPTY, CommonAPIConstants.FLEX_LICENSE_SCHOOL }

        };
        return inputData;
    }

    /**
     * Token creation
     * 
     * @param school
     */
    public void tokenCreation( String school ) {
        try {
            switch ( school ) {
                case CommonAPIConstants.FLEX_LICENSE_SCHOOL:
                    schoolType = flexSchool;
                    teacherDetails = flexSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.MATH_LICENSE_SCHOOL:
                    schoolType = mathSchool;
                    teacherDetails = mathSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.READING_LICENSE_SCHOOL:
                    schoolType = readingSchool;
                    teacherDetails = readingSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.FOCUS_MATH_LICENSE_SCHOOL:
                    schoolType = focusMathSchool;
                    teacherDetails = focusMathSchoolTeacherDetails;
                    break;
                case CommonAPIConstants.FOCUS_READING_LICENSE_SCHOOL:
                    schoolType = focusReadingSchool;
                    teacherDetails = focusReadingSchoolTeacherDetails;
                    break;
            }
            userName = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
            token = new RBSUtils().getAccessToken( userName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Error occurred in the token creation. Please check!!" );
        }
    }

    /**
     * Adding Students to group
     * 
     * @param statusCode
     * @param userName
     * @param school
     * 
     * @return studentRumbaIds
     */
    public List<String> addStudentsToGroup( String statusCode, String userName, String school ) {
        HashMap<String, String> response;
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        try {
            //Adding students to group
            String groupName = "Successmaker API Test Group " + System.nanoTime();
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), "userId" ) );
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            response = groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );
            groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.BODY ), "data,groupId" );
            Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        } catch ( Exception e ) {
            Log.message( "Error occurred in while adding students to group. Please check!!" );
        }
        return studentRumbaIds;
    }

    /**
     * Common code for negative flow
     * 
     * @param apiResponseGetGroupAssignmentSettings
     * 
     * @return updatedGroupAssignmentSettings
     */
    public HashMap<String, String> commonCodeForNegativeFlow( HashMap<String, String> apiResponseGetGroupAssignmentSettings ) {
        JSONObject getSettingsResp;
        HashMap<String, String> updatedGroupAssignmentSettings = new HashMap<>();
        try {
            getSettingsResp = SMUtils.convertResponseAsJsonObj( apiResponseGetGroupAssignmentSettings.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );

            JSONObject data2 = getSettingsResp.getJSONObject( "SESSION_LENGTH" );
            sessionLengthName = data2.getString( "name" );
            sessionLengthId = data2.getLong( "id" );
            sessionLengthValue = data2.getString( "currentValue" );
            Log.message( "Name of the session length : " + sessionLengthName );
            Log.message( "Id of the session length : " + sessionLengthId );
            Log.message( "CurrentValue of the session length : " + sessionLengthValue );

            JSONObject data3 = getSettingsResp.getJSONObject( "IDLE_TIME" );
            idleTimeName = data3.getString( "name" );
            idleTimeId = data3.getLong( "id" );
            idleTimeValue = data3.getString( "currentValue" );
            Log.message( "Name of the idleTime : " + idleTimeName );
            Log.message( "Id of the idleTime : " + idleTimeId );
            Log.message( "CurrentValue of the idleTime : " + idleTimeValue );

            //Update the setting as per your need
            updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_ID, String.valueOf( sessionLengthId ) );
            updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_NAME, sessionLengthName );
            updatedGroupAssignmentSettings.put( CourseAPIConstants.SESSION_LENGTH_VALUE, "14" );
            updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
            updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
            updatedGroupAssignmentSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, "4" );
        } catch ( Exception e ) {
            Log.message( "Some issue occured in commonCodeForNegativeFlow.Please check!!" );
        }
        return updatedGroupAssignmentSettings;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

    //*************************** Common method modified

    public Map<String, String> getHeaders1( HashMap<String, String> userreqDetails ) {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userreqDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        headers.put( Constants.USERID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.ORG_ID ) );
        return headers;
    }

    public HashMap<String, String> updateGroupAssignmentSetting1( String envUrl, HashMap<String, String> assignmentDetails, HashMap<String, String> updateGroupAssignmentSettings, String courseType ) {
        DataSetupProcessor dataprocess = new DataSetupProcessor();
        try {

            String endpoint = AssignmentAPIConstants.PUT_GROUP_ASSIGNMENT_SETTINGS_API;
            Map<String, String> headers = getHeaders1( assignmentDetails );
            Log.message( "Update assignment setting which is assigned to a group" + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID_ENDPOINT, updateGroupAssignmentSettings.get( CourseAPIConstants.ORG_ID ) );
            endpoint = endpoint.replace( Constants.TEACHER_ID_ENDPOINT, updateGroupAssignmentSettings.get( CourseAPIConstants.TEACHER_ID ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, updateGroupAssignmentSettings.get( CourseAPIConstants.COURSE_ID ) );
            endpoint = endpoint.replace( Constants.GROUPID, updateGroupAssignmentSettings.get( CourseAPIConstants.GROUP_ID ) );

            //Parameters
            HashMap<String, String> params = new HashMap<>();

            Log.message( "Endpoint is : " + envUrl + endpoint );
            String requestBody = null;
            if ( courseType.contains( DataSetupConstants.READING ) ) {
                requestBody = generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "updateGroupAssignmentSettingReading.json" ), updateGroupAssignmentSettings );
            } else {
                requestBody = generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "updateGroupAssignmentSettingMath.json" ), updateGroupAssignmentSettings );
            }

            Log.message( "Payload is : " + requestBody );
            Log.message( headers.toString() );

            return RestHttpClientUtil.PUT( envUrl, headers, params, endpoint, requestBody );

        } catch ( Exception e ) {
            Log.message( "Error in updating the assignment setting of the group. Please check 'updateGroupAssignmentSetting' in 'BaseAPITest.java' class file" );
            return null;
        }
    }

    public String generateRequestBody( String requestBodyTemplate, Map<String, String> requestDetails ) {
        String requestBody = requestBodyTemplate;
        if ( requestBody.contains( Constants.SESSION_LENGTH_ID ) ) {
            requestBody = requestBody.replace( Constants.SESSION_LENGTH_ID, requestDetails.get( CourseAPIConstants.SESSION_LENGTH_ID ) );
        }
        if ( requestBody.contains( Constants.SESSION_LENGTH_NAME ) ) {
            requestBody = requestBody.replace( Constants.SESSION_LENGTH_NAME, requestDetails.get( CourseAPIConstants.SESSION_LENGTH_NAME ) );
        }
        if ( requestBody.contains( Constants.SESSION_LENGTH_VALUE ) ) {
            requestBody = requestBody.replace( Constants.SESSION_LENGTH_VALUE, requestDetails.get( CourseAPIConstants.SESSION_LENGTH_VALUE ) );
        }
        if ( requestBody.contains( Constants.IDLE_TIME_ID ) ) {
            requestBody = requestBody.replace( Constants.IDLE_TIME_ID, requestDetails.get( CourseAPIConstants.IDLE_TIME_ID ) );
        }
        if ( requestBody.contains( Constants.IDLE_TIME_NAME ) ) {
            requestBody = requestBody.replace( Constants.IDLE_TIME_NAME, requestDetails.get( CourseAPIConstants.IDLE_TIME_NAME ) );
        }
        if ( requestBody.contains( Constants.IDLE_TIME_VALUE ) ) {
            requestBody = requestBody.replace( Constants.IDLE_TIME_VALUE, requestDetails.get( CourseAPIConstants.IDLE_TIME_VALUE ) );
        }
        return requestBody;
    }
}