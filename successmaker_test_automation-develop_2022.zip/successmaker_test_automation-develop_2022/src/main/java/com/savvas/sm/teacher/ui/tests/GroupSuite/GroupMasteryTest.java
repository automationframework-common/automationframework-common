package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryDetailsPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperMastery;
import com.savvas.sm.utils.sql.helper.StandardVersionTable.StandardVersionMastery;

import LSTFAI.customfactories.EventFiringWebDriver;

public class GroupMasteryTest extends BaseTest {
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    // private static String studentOne;
    private static String studentTwo;
    private static String studentThree;
    private static String studentOne;
    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    private static String groupName;
    private static String groupName1;
    private static String teacherDetails;
    private static String groupDetails;
    private static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String courseNameStandard = Constants.CUSTOM_BY_STANDARDS_COURSE + RandomStringUtils.randomAlphabetic( 6 );

    WebDriver driver;
    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    @BeforeClass
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );

        String studentDetails1 = RBSDataSetup.getMyStudent( school, username );
        String studentDetails2 = RBSDataSetup.getMyStudent( school, username );
        String studentDetails3 = RBSDataSetup.getMyStudent( school, username );

        studentOne = ( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ) );
        studentTwo = ( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERNAME ) );
        studentThree = ( SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERNAME ) );

        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERID ) );

        HashMap<String, String> groupDetailsMap = new HashMap<>();
        groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, "SM Regression Group" + System.nanoTime() );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );
        groupDetails = createGroup.get( Constants.BODY );
        groupName = SMUtils.getKeyValueFromResponse( groupDetails, "data,groupName" );

    }

    @Test ( description = "Verify Mastery sub tab in group details page", groups = { "SMK-43593", "groups", "groupsMastery" }, priority = 1 )
    public void tcGroupMastery001() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "tcGroupMastery001: Verify Mastery sub tab in group details page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Groups Listing Page
            GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();

            groupName1 = "SM Group For Mastery" + System.nanoTime();
            groupPage.createGroupWithSchoolStudents( groupName, Arrays.asList( studentOne, studentTwo, studentThree ), "All Grades" );

            SMUtils.logDescriptionTC( "Verify the Mastery filters are not shown if the teacher doesn't have any students assigned to the group" );
            // Creating new group with no student
            String groupname = Constants.Groups.CREATE_NEW_GROUP + System.nanoTime();
            groupPage.createGroupWithoutStudent( groupname );
            groupPage.viewGroup( groupname );
            groupPage.clickGroupsSubNav( Constants.MASTERY );
            Log.assertThat( groupPage.verifyMasteryZeroState(), "Mastery filters are not shown for a group with no students", "Mastery filters are shown for a group with no students" );

            // navigate to Groups Listing Page
            teacherHomePage.topNavBar.navigateToGroupsTab();
            groupPage.viewGroup( groupName );

            SMUtils.logDescriptionTC( "Verify Mastery sub tab is displaying on Groups details page" );
            SMUtils.logDescriptionTC( "Verify Mastery sub tab is displaying below Assignment sub tab and above Settings subtab" );
            Log.assertThat( groupPage.getGroupSubNav().contains( Constants.MASTERY ), "Mastery sub tab is displayed in in group details page", "Mastery sub tab is displayed in in group details page" );

            SMUtils.logDescriptionTC( "On clicking Mastery Subtab, Verify 'Mastery' header is displaying" );
            groupPage.clickGroupsSubNav( Constants.MASTERY );
            Log.assertThat( groupPage.verifySubNavHeader( Constants.MASTERY ), "Mastery is displayed on clicking mastery sub tab in group details page", "Mastery is displayed on clicking mastery sub tab in group details page" );

            SMUtils.logDescriptionTC( "Verify Teacher able to view Mastery details on clicking Mastery sub tab" );
            SMUtils.logDescriptionTC( "On Mastery sub tab, Verify Subject, Skill/Standards and Assignments dropdown are present" );
            MasteryFiltersComponent masteryComponent = new MasteryFiltersComponent( driver );
            Log.assertThat( masteryComponent.isSubjectDropDownCollapsed() && masteryComponent.isSkillsStandardsDropdownPresent() && masteryComponent.isAssignmentDropdownPresent(),
                    "Mastery details are displayed and all filter dropdowns are present on clicking Mastery sub tab", "Mastery details are not displayed or all filter dropdowns are not present on clicking Mastery sub tab" );

            SMUtils.logDescriptionTC( "On Mastery sub tab, Verify Apply Filter button is present" );
            Log.assertThat( masteryComponent.isApplyFilterButtonPresent(), "Apply Filter button is present in Mastery tab", "Apply Filter button is not present in Mastery tab" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify subject and Skills/Standards dropdowns functionality in Mastery sub tab.", groups = { "SMK-43593", "groups", "groupsMastery" }, priority = 1 )
    public void tcGroupMastery002() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "tcGroupMastery002: Verify subject and Skills/Standards dropdowns functionality in Mastery sub tab.. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // get values from Database for Math subject
            List<StandardVersionMastery> listStandardVersionDBMath = SqlHelperMastery.getStandards( Constants.MasteryUI.SUBJECT_MATH );

            // Get Standards name from DB data
            List<String> skillStandardsAvailableDBMath = new ArrayList<>();
            skillStandardsAvailableDBMath.add( Constants.MasteryUI.SKILL_MATH );
            for ( StandardVersionMastery standardVersionMastery : listStandardVersionDBMath ) {
                skillStandardsAvailableDBMath.add( standardVersionMastery.getStandardsName() );
            }
            skillStandardsAvailableDBMath = skillStandardsAvailableDBMath.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to group mastery Page
            GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupPage.viewGroup( groupName );
            groupPage.clickGroupsSubNav( Constants.MASTERY );

            MasteryFiltersComponent masteryComponent = new MasteryFiltersComponent( driver );

            SMUtils.logDescriptionTC( "Verify the default value for Skills/Standards is 'SuccessMaker Mastery Skills - Math'" );
            Log.assertThat( masteryComponent.getSkillStandardDropDownSelectedValue().equals( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 0 ) ), "SuccessMaker Mastery Skills - Math is selected as default value for Skills/Standards",
                    "SuccessMaker Mastery Skills - Math is not selected as default value for Skills/Standards" );

            SMUtils.logDescriptionTC( "Verify the teacher is not able to select multiple standards in the Skills/Standards dropdown(Mastery Page)" );
            masteryComponent.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            masteryComponent.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 2 ) );
            Log.assertThat( masteryComponent.getSkillStandardDropDownSelectedValue().equalsIgnoreCase( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 2 ) ), "Skills/Standards dropdown is a single select dropdown",
                    "Skills/Standards dropdown is not a single select dropdown" );

            SMUtils.logDescriptionTC( "Verify the defalut value for Subject dropdown is 'Math'" );
            Log.assertThat( masteryComponent.getSubjectDropDownSelectedValue().equalsIgnoreCase( Constants.MATH ), "Math is selected as default value for Subject dropdown", "Math is selected as default value for Subject dropdown" );

            SMUtils.logDescriptionTC( "Select Math from subject dropdown, Verify Skill/Standards dropdown having options with respect to selected subject only" );
            Log.assertThat( masteryComponent.getAllSkillStandardsDropDownValues().stream().map( String::toLowerCase ).collect( Collectors.toList() ).containsAll( skillStandardsAvailableDBMath ),
                    "Skill/Standards dropdown is having options with respect to Math subject only", "Skill/Standards dropdown is not having options with respect to Math subject only" );

            SMUtils.logDescriptionTC( "Verify teacher is able to select 'Reading' from subject dropdown" );
            masteryComponent.selectSubject( Constants.READING );
            Log.assertThat( masteryComponent.getSubjectDropDownSelectedValue().equals( Constants.READING ), "Reading is able to select in subject dropdown", "Reading is able to select in subject dropdown" );

            SMUtils.logDescriptionTC( "Select Reading from subject dropdown, Verify Skill/Standards dropdown having options with respect to selected subject only" );
            Log.assertThat(
                    masteryComponent.getAllSkillStandardsDropDownValues().stream().map( String::toLowerCase ).collect( Collectors.toList() ).containsAll(
                            Constants.READING_SKILLS_DROPDOWN_LIST.stream().map( String::toLowerCase ).collect( Collectors.toList() ) ),
                    "Skill/Standards dropdown are having options with respect to Reading subject only", "Skill/Standards dropdown are not having options with respect to Reading subject only" );

            SMUtils.logDescriptionTC( "Verify subject dropdown will have both Math and Reading option irrespective of the type of assignments assigned to the group" );
            Log.assertThat( masteryComponent.getAllSubjectDropDownValues().containsAll( Constants.SUBJECT_DROPDOWN_LIST ), "Subject dropdown is having both Math and Reading option", "Subject dropdown is not having both Math and Reading option" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Assignments dropdown functionality in Mastery sub tab.", groups = { "SMK-43593", "groups", "groupsMastery" }, priority = 1 )
    public void tcGroupMastery003() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "tcGroupMastery003: Verify Assignments dropdown functionality in Mastery sub tab.. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to group assignment listing Page
            AssignmentsPage assignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentNames = assignmentsPage.getAllAssignmentNames();
            List<String> mathAssignments = assignmentNames.stream().filter( name -> name.contains( Constants.MATH ) ).collect( Collectors.toList() );
            List<String> readingAssignments = assignmentNames.stream().filter( name -> name.contains( Constants.READING ) ).collect( Collectors.toList() );

            // navigate to group mastery Page
            GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupPage.viewGroup( groupName );
            groupPage.clickGroupsSubNav( Constants.MASTERY );

            MasteryFiltersComponent masteryComponent = new MasteryFiltersComponent( driver );
            masteryComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );

            SMUtils.logDescriptionTC( "Verify the default value for Assignments dropdown is 'All Assignemnts'" );
            Log.assertThat( masteryComponent.getDropDownMSSelectedValue().contains( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, Integer.toString( mathAssignments.size() ) ) ),
                    "The default value for Assignments dropdown is displayed as excepted", "The default value for Assignments dropdown is wrong" );

            SMUtils.logDescriptionTC( "Select Math from subject dropdown, Verify Assignments dropdown having options with respect to selected subject only" );
            Log.assertThat( masteryComponent.getSelectedValuesFromDropDownMS().containsAll( mathAssignments ), "Assignments dropdown having options with respect to math subject only",
                    "Assignments dropdown is not having options with respect to math subject only" );

            SMUtils.logDescriptionTC( "Select Reading from subject dropdown, Verify Assignments dropdown having options with respect to selected subject only" );
            masteryComponent.selectSubject( Constants.READING );
            Log.assertThat( masteryComponent.getSelectedValuesFromDropDownMS().containsAll( readingAssignments ), "Assignments dropdown having options with respect to reading subject",
                    "Assignments dropdown is not having options with respect to reading subject" );

            SMUtils.logDescriptionTC( "On Mastery sub tab, Verify Assignemnts dropdown is multi selection dropdown" );
            masteryComponent.selectValuesByIndexFromDropDownMS( Arrays.asList( 1, 2, 3 ) );
            Log.assertThat( masteryComponent.getDropDownMSSelectedValue().contains( Constants.Reports.SELECTED_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Assignments dropdown is a multi select dropdown",
                    "Assignments dropdown is not a multi select dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the zero state message displayed when No students have taken the assignment or they have not been assessed any of the skills in the assignment.", groups = { "SMK-43593", "groups", "groupsMastery" }, priority = 1 )
    public void tcGroupMastery004() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "tcGroupMastery004: Verify the zero state message displayed when No students have taken the assignment or they have not been assessed any of the skills in the assignment. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            //coursepage.clickCourseName(Constants.MATH);

            // navigate to Course Listing Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            coursePage.copyOfCourse( courseNameStandard, Constants.STANDARDS, Constants.MATH );
            teacherHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( courseNameStandard );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroup();

            SMUtils.logDescriptionTC( "Verify the zero state message is displayed when No default courseware has been assigned to any students in the group" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            // Navigate to Mastery sub-tab
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            SMUtils.waitForElement( driver, groupsTab.masteryHeader );
            Log.assertThat( groupsTab.masteryHeader.getText().equals( Constants.MASTERY ), "The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully" );

            // Verify zero state message
            Log.assertThat( groupsTab.verifyMasteryZeroState(), "Zero state message is displayed sucessfully for mastery!", "Zero state message is not displayed sucessfully for mastery!" );

            SMUtils.logDescriptionTC( "Verify the zero state message is displayed when  0 assignments is selected from the assignment dropdown\r\n" );

            //Unchecked select all drop down
            MasteryFiltersComponent masteryPage = new MasteryFiltersComponent( driver );
            masteryPage.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            masteryPage.unCheckSelectAllDropdownMS();
            Log.assertThat( groupsTab.verifyMasteryZeroState(), "Zero state message is displayed sucessfully for mastery!", "Zero state message is not displayed sucessfully for mastery!" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the zero state message displayed when No students have taken the assignment or they have not been assessed any of the skills in the assignment.", groups = { "SMK-43593", "groups", "groupsMastery" }, priority = 1 )
    public void tcGroupMastery005() throws Exception {

        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcGroupMastery005: Verify the apply filter is in disable state  by default <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "Verify the zero state message is displayed when No default courseware has been assigned to any students in the group" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            // Navigate to Mastery sub-tab
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            SMUtils.waitForElement( driver, groupsTab.masteryHeader );
            Log.assertThat( groupsTab.masteryHeader.getText().equals( Constants.MASTERY ), "The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully" );

            /// Verify apply filter button disabled
            SMUtils.logDescriptionTC( "Verify the apply filter is in disable state  by default" );
            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );
            masteryComponent.applyFilter();

            //Verify the apply filter is enabled once the new selection is made in the Subject/Standards/assignment dropdown
            SMUtils.logDescriptionTC( "Verify the apply filter is enabled once the new selection is made in the Subject/Standards/assignment dropdown" );
            MasteryFiltersComponent masteryPage = new MasteryFiltersComponent( driver );
            masteryPage.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            Log.assertThat( masteryPage.getSelectedValueFromSkillStandardsDropDown().equalsIgnoreCase( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) ), "Selected Skills/Standards name is displayed in Skills/Standards dropdown",
                    "Selected Skills/Standards name is not displayed in Skills/Standards dropdown" );

            //apply filter modified
            SMUtils.logDescriptionTC( "Verify the applied filters can be modified" );
            masteryPage.expandSubjectDropDown();
            masteryPage.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            Log.assertThat( masteryPage.getSelectedValueFromSubjectDropDown().equalsIgnoreCase( Constants.MasteryUI.SUBJECT_MATH ), "The teacher is able to select the subject in the Subjects dropdown",
                    "The teacher is not able to select the subject in the Subjects dropdown" );
            masteryPage.expandSkillStandardsDropDown();
            masteryPage.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            Log.assertThat( masteryPage.getSelectedValueFromSkillStandardsDropDown().equalsIgnoreCase( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) ), "Selected Skills/Standards name is displayed in Skills/Standards dropdown",
                    "Selected Skills/Standards name is not displayed in Skills/Standards dropdown" );
            masteryPage.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            masteryPage.selectValuesByIndexFromDropDownMS( Arrays.asList( 2 ) );
            Log.assertThat( masteryComponent.applyFilter(), "Apply filter button is modified successfully", "Apply filter button is not modified successfully" );

            //Verify the apply filter is enabled when there are no assignment found  in the assignment dropdown
            SMUtils.logDescriptionTC( "Verify the apply filter is enabled when there are no assignment found  in the assignment dropdown" );
            masteryPage.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            masteryPage.unCheckSelectAllDropdownMS();
            Log.assertThat( groupsTab.verifyMasteryZeroState(), "Zero state message is displayed sucessfully for mastery!", "Zero state message is not displayed sucessfully for mastery!" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the teacher is able to view the LO & LO details as a blue link in Groups-Mastery tab\\r\\n", groups = { "SMK-43593", "groups", "groupsMastery" }, priority = 1 )
    public void tcGroupMastery006() throws Exception {

        //final WebDriver driver = WebDriverFactory.get( browser );
        WebDriver driver = null;
        WebDriver chromeDriver = WebDriverFactory.get( chromePlatform ); //for simulator run//

        Log.testCaseInfo( "tcGroupMastery006: Verify the teacher is able to view the LO & LO details as a blue link in Groups-Mastery tab\\r\\n <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            //Executing math assignments in student dash-board
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage = smStudentLoginPage.loginToSMasStudent( studentTwo, password, true );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ), courseNameStandard, "100", "1", "30" );
            studentOneDashboardPage.logout();
            chromeDriver.quit();

            // Get driver
            driver = WebDriverFactory.get( browser );
            // Login as Teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            // Navigate to Mastery sub-tab
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            SMUtils.waitForElement( driver, groupsTab.masteryHeader );
            Log.assertThat( groupsTab.masteryHeader.getText().equals( Constants.MASTERY ), "The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully" );
            //LO as blue color
            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );
            SMUtils.logDescriptionTC( "Verify the teacher is able to view the LO & LO details as a blue link in Groups-Mastery tab\r\n" );
            Log.assertThat( masteryComponent.verifyLOColor( browser ), "Teacher is able to see the LO as a blue link", "Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills" );

            // Student assessment count
            SMUtils.logDescriptionTC( "Verify the text displayed as \" Numbers Student Assessments  \" above the progress bar if more than one student has taken assessment \r\n" );

            Log.assertThat( masteryComponent.getStudentAssessmentOfLeafNodeLO().stream().allMatch( studentCount -> !studentCount.isEmpty() ),
                    "The teacher is able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO only",
                    "The teacher is not able to view the total count of Assessments Taken by the students above the progress bar corresponding to the LO" );

            SMUtils.logDescriptionTC( "SMK-15004 Verify the text displayed as Numbers Student Assessments above the progress bar if more than one student has taken assessment corresponding to the LO only" );
            String singleStudentAssessCount = Constants.MasteryUI.STUDENT_ASSESSMENT_COUNT.replace( Constants.STUDENTS_COUNT, "1" );
            String multiStudentAssessCount = Constants.MasteryUI.STUDENT_ASSESSMENT_COUNT.replace( Constants.STUDENTS_COUNT, "2" );

            Log.assertThat( masteryComponent.getStudentAssessmentOfLeafNodeLO().stream().allMatch( list -> list.contains( singleStudentAssessCount ) || list.contains( multiStudentAssessCount ) ),
                    "Student assessed count is displayed if one or more student has taken an assessment", "Student assessed count is not displayed if one or more student has taken an assessment" );

            //Assessed objectives legends
            SMUtils.logDescriptionTC( "On clicking 'Apply Filters' button on Mastery Page, verify teacher is able to see the 'Mastered', 'At Risk', 'Not Mastered', and \"Unassessed' breakdown per skills on progress bar\r\n" );
            Log.assertThat( masteryComponent.getAssessedObjectivesHeaders(), "Assessed objectives are present", "Assessed objectives are not present" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify teacher is able to change Skills/Standards option", groups = { "SMK-43593", "groups", "groupsMastery" }, priority = 1 )
    public void tcGroupMastery007() throws Exception {

        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcGroupMastery007: Verify teacher is able to change Skills/Standards option <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "Verify the teacher is not able to select multiple standards in the Skills/Standards dropdown(Mastery Page)" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            // Navigate to Mastery sub-tab
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            SMUtils.waitForElement( driver, groupsTab.masteryHeader );
            Log.assertThat( groupsTab.masteryHeader.getText().trim().equals( Constants.MASTERY ), "The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully" );

            //modified skill drop down
            MasteryFiltersComponent masteryPage = new MasteryFiltersComponent( driver );
            masteryPage.selectSkillStandards( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) );
            Log.assertThat( masteryPage.getSelectedValueFromSkillStandardsDropDown().equalsIgnoreCase( Constants.MATH_SKILLS_DROPDOWN_LIST.get( 1 ) ), "Selected Skills/Standards name is displayed in Skills/Standards dropdown",
                    "Selected Skills/Standards name is not displayed in Skills/Standards dropdown" );
            /// Verify apply filter button disabled
            SMUtils.logDescriptionTC( "Verify the apply filter is in disable state  by default" );
            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );
            masteryComponent.applyFilter();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify teacher is able to change Skills/Standards option", groups = { "SMK-43593", "groups", "groupsMastery" }, priority = 1 )
    public void tcGroupMastery008() throws Exception {

        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcGroupMastery008: Verify teacher is able to change Skills/Standards option <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "Verify the teacher is not able to select multiple standards in the Skills/Standards dropdown(Mastery Page)" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            // Navigate to Mastery sub-tab
            groupsTab.clickGroupsSubNav( Constants.MASTERY );
            SMUtils.waitForElement( driver, groupsTab.masteryHeader );
            Log.assertThat( groupsTab.masteryHeader.getText().trim().equals( Constants.MASTERY ), "The 'Mastery' tab is loaded successfully", "The 'Mastery' tab is not loaded successfully" );
            MasterySummaryComponent masteryComponent = new MasterySummaryComponent( driver );
            MasteryFiltersComponent masteryPage = new MasteryFiltersComponent( driver );
            List<String> contentsInGroupMasteryPage = masteryComponent.getLeafNodeContent();

            //Navigate to Mastery page
            teacherHomePage.topNavBar.navigateToMasteryTab();

            masteryPage.applyFilter();
            List<String> contentsInmasteryPage = masteryComponent.getLeafNodeContent();

            SMUtils.logDescriptionTC( "Verify the Mastery report/details is identical to the details present in the  Mastery primary tab.for the selected single / multiple assignment (s)\r\n" );
            Log.assertThat( contentsInGroupMasteryPage.containsAll( contentsInmasteryPage ),
                    "The details displayed based on the skills/standard dropdown selection in the groups mastery details page is matching with the details present under primary mastery tab for the same selection",
                    "The details displayed based on the skills/standard dropdown selection in the groups mastery details page is not matching with the details present under primary mastery tab for the same selection" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "On Mouse hovering on Progress bar, Verify tooltip message is displaying", groups = { "SMK-43596", "assignments", "assignmentsMastery" }, priority = 1 )
    public void tcGroupMastery009() throws Exception {

        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcGroupMastery009: On Mouse hovering on Progress bar, Verify tooltip message is displaying <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            //Executing math assignments in student dash-board
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage = smStudentLoginPage.loginToSMasStudent( studentOne, password, true );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ), courseNameStandard, "100", "1", "30" );
            studentOneDashboardPage.logout();
            driver.quit();

            // Get driver
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );
            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );

            SMUtils.logDescriptionTC( "SMK-14952 : On Mouse hovering on Progress bar, Verify tooltip message is displaying" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();

            groupName1 = "SM Group For Mastery" + System.nanoTime();
            groupsTab.createGroupWithSchoolStudents( groupName, Arrays.asList( studentOne, studentTwo, studentThree ), "All Grades" );

            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( courseNameStandard );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroup();

            groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();

            // Click View Group
            groupsTab.viewGroup( groupName );

            groupsTab.clickGroupsSubNav( Constants.MASTERY );

            SMUtils.nap( 2 );
            // Get webElement of Progress Bar
            List<WebElement> progressBarLink = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );

            SMUtils.clickJS( driver, progressBarLink.get( 0 ) );

            //Get Tool Tip Text
            String tooltipOfProgressBar = masteryDetail.getProgressBarToolTipText();

            // Validation 1:
            Log.assertThat( tooltipOfProgressBar.contains( "mastered" ), "Text mastered is present in the Tool tip in the Progress Bar", "Not present in the tool tip" );

            // Validation 2:
            Log.assertThat( tooltipOfProgressBar.contains( "at risk" ), "Text at risk is present in the Tool tip in the Progress Bar", "Not present in the tool tip" );

            // Validation 3:
            Log.assertThat( tooltipOfProgressBar.contains( "not mastered" ), "Text not mastered is present in the Tool tip in the Progress Bar", "Not present in the tool tip" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Mastery data is displayed with respect to the selected assignments only", groups = { "SMK-43596", "assignments", "assignmentsMastery" }, priority = 1 )
    public void tcGroupMastery010() throws Exception {

        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcGroupMastery010: Verify Mastery data is displayed with respect to the selected assignments only <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Executing math assignments in student dash-board
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage = smStudentLoginPage.loginToSMasStudent( studentThree, password, true );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), courseNameStandard, "100", "1", "30" );
            studentOneDashboardPage.logout();
            driver.quit();

            // Get driver
            driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
            eventListner = new EventListener();
            driver.register( eventListner );

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );

            SMUtils.logDescriptionTC( "SMK-14937 :Verify Mastery data is displayed with respect to the selected assignments only" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            String groupName = "SMGroupMastery" + System.nanoTime();
            List<String> usernames = new ArrayList<>();
            usernames.add( studentOne );
            usernames.add( studentTwo );
            usernames.add( studentThree );
            groupsTab.createGroupWithSchoolStudents( groupName, usernames, "All Grades" );

            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( courseNameStandard );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroup();

            teacherHomePage.topNavBar.navigateToGroupsTab();
            // Click View Group
            groupsTab.viewGroup( groupName );

            groupsTab.clickGroupsSubNav( Constants.MASTERY );

            masteryFilter.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );

            masteryFilter.selectValuesFromDropDownMS( Arrays.asList( courseNameStandard ) );

            masteryFilter.clickApplyFilter();

            Log.assertThat( masterySummary.verifySkillHeadingIsDisplayed(), "Report Displayed for Selected assignment", "Report Not Displayed for selected Assignment" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the mastery data should display for the respective filter combination given by the teacher", groups = { "SMK-43596", "assignments", "assignmentsMastery" }, priority = 1 )
    public void tcGroupMastery011() throws Exception {

        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcGroupMastery011: Verify the mastery data should display for the respective filter combination given by the teacher <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            SMUtils.logDescriptionTC( "SMK-14969 : Verify the mastery data should display for the respective filter combination given by the teacher" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();

            // Click View Group
            groupsTab.viewGroup( groupName );

            groupsTab.clickGroupsSubNav( Constants.MASTERY );

            masteryFilter.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );

            masteryFilter.selectValuesFromDropDownMS( Arrays.asList( courseNameStandard ) );

            masteryFilter.clickApplyFilter();

            // Get webElement of Progress Bar
            List<WebElement> progressBarLink = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );

            WebElement progressBarElement = progressBarLink.get( 0 );

            SMUtils.clickJS( driver, progressBarElement );

            List<String> assignmentNameList = masteryDetail.getAssignmentNameList();

            Log.assertThat( assignmentNameList.size() == 1, "Selected Assigment Filtered and Shown report for applied filter", "Not filtered as Expected" );

            Log.assertThat( assignmentNameList.contains( courseNameStandard ), "Selected Assigment Filtered and Shown report for applied filter", "Not filtered as Expected" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Mastery data displaying is with respect to all the students present in the group", groups = { "SMK-43596", "assignments", "assignmentsMastery" }, priority = 1 )
    public void tcGroupMastery012() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "tcGroupMastery012: Verify Mastery data displaying is with respect to all the students present in the group <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            MasteryDetailsPage masteryDetail = new MasteryDetailsPage( driver );
            MasteryFiltersComponent masteryFilter = new MasteryFiltersComponent( driver );
            MasterySummaryComponent masterySummary = new MasterySummaryComponent( driver );

            SMUtils.logDescriptionTC( "SMK-14936 : Verify Mastery data displaying is with respect to all the students present in the group" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();

            int totalStudentsInGrp = Integer.parseInt( groupsTab.getStudentsCount( groupName ) );

            // Click View Group
            groupsTab.viewGroup( groupName );

            groupsTab.clickGroupsSubNav( Constants.MASTERY );

            masteryFilter.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );

            masteryFilter.selectValuesFromDropDownMS( Arrays.asList( courseNameStandard ) );

            masteryFilter.clickApplyFilter();

            // Get webElement of Progress Bar
            List<WebElement> progressBarLink = masterySummary.getProgressBarLink( Constants.MasteryUI.MASTERED );

            WebElement progressBarElement = progressBarLink.get( 0 );

            SMUtils.clickJS( driver, progressBarElement );

            int totalStudentcountInDetailPage = masteryDetail.getStudentCountsFromDetailsPage();

            // Validation :
            Log.assertThat( totalStudentcountInDetailPage == totalStudentsInGrp, "Reports Displayed for all the students present in the Group", "Report Not displayed for all students" );

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

}
