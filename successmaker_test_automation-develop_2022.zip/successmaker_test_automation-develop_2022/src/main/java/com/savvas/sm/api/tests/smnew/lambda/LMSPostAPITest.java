package com.savvas.sm.api.tests.smnew.lambda;

import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.smnew.users.CreateStudentAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.LMSAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class LMSPostAPITest extends UserAPI {
	private String smUrl;
	private String teacherDetails;
	private String teacherUsername;
	private String teacherUserId;
	private String orgId;
	private String studentDetails;
	private String studentUsername;
	private String studentUserId;
	String schoolAdminDetails;
	String schoolAdminUserID;
	String schoolAdminUsername;
	
	private HashMap<String, String> response;
	String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String browser;

	@BeforeClass(alwaysRun = true)
	public void beforeTest() throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		orgId = RBSDataSetup.organizationIDs.get(school);
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		teacherUsername = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		teacherUserId = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID);
		studentDetails = RBSDataSetup.getMyStudent(school, teacherUsername);
		studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERNAME);
		studentUserId = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERID);
		Log.message("Student : " + studentUserId);
		
		 // Getting School admin details
         schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
         schoolAdminUserID = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
         schoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
	}

		@Test(dataProvider = "getData", groups = { "smoke_test_case", "Smoke testLMSPostAPI", "autoassigncourse", "P1",
			"SMK-52695", "LMS Post API Test", "API" }, priority = 1)
	public void testLMSPostAPI(String testcaseName, String statusCode, String testcaseDescription, String scenarioType)
			throws Exception {
		HashMap<String, String> headers = new HashMap<>();
		HashMap<String, String> params = new HashMap<>();

		Log.testCaseInfo(testcaseName + testcaseDescription);

		// Test Data
		String authorization = "Basic dXNlcjE6dXNlcjFwYXNz";
		String endPoint = LMSAPIConstants.LMS_POST_ENDPOINT;
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);

		switch (scenarioType) {
		case "GET METHOD":
			headers.put(LMSAPIConstants.AUTHORISATION, authorization);
			headers.put(LMSAPIConstants.ORG_ID, orgId);
			endPoint = endPoint.replace(LMSAPIConstants.ORG_ID, orgId);
			endPoint = endPoint.replace(LMSAPIConstants.USER_ID, studentUserId);
			endPoint = endPoint.replace(LMSAPIConstants.SCALE_SCORE, "1250");
			response = RestHttpClientUtil.GET(smUrl, endPoint, headers, params);
			break;
		case "VALID_DATA":
			headers.put(LMSAPIConstants.AUTHORISATION, authorization);
			headers.put(LMSAPIConstants.ORG_ID, orgId);
			endPoint = endPoint.replace(LMSAPIConstants.ORG_ID, orgId);
			endPoint = endPoint.replace(LMSAPIConstants.USER_ID, studentUserId);
			endPoint = endPoint.replace(LMSAPIConstants.SCALE_SCORE, "1250");
			response = RestHttpClientUtil.POST(smUrl, headers, params, endPoint, null);
			break;
		case "WITHOUT_STUDENT_ID":
			headers.put(LMSAPIConstants.AUTHORISATION, authorization);
			headers.put(LMSAPIConstants.ORG_ID, orgId);
			endPoint = endPoint.replace(LMSAPIConstants.ORG_ID, orgId);
			endPoint = endPoint.replace(LMSAPIConstants.USER_ID, "");
			endPoint = endPoint.replace(LMSAPIConstants.SCALE_SCORE, "1250");
			response = RestHttpClientUtil.POST(smUrl, headers, params, endPoint, null);
			break;
		case "WITHOUT_ORG_ID":
			headers.put(LMSAPIConstants.AUTHORISATION, authorization);
			headers.put(LMSAPIConstants.ORG_ID, orgId);
			endPoint = endPoint.replace(LMSAPIConstants.ORG_ID, "");
			endPoint = endPoint.replace(LMSAPIConstants.USER_ID, studentUserId);
			endPoint = endPoint.replace(LMSAPIConstants.SCALE_SCORE, "1250");
			response = RestHttpClientUtil.POST(smUrl, headers, params, endPoint, null);
			break;
		case "INVALID_SCALE_SCORE":
			headers.put(LMSAPIConstants.AUTHORISATION, authorization);
			headers.put(LMSAPIConstants.ORG_ID, orgId);
			endPoint = endPoint.replace(LMSAPIConstants.ORG_ID, orgId);
			endPoint = endPoint.replace(LMSAPIConstants.USER_ID, studentUserId);
			endPoint = endPoint.replace(LMSAPIConstants.SCALE_SCORE, LMSAPIConstants.INVALID);
			response = RestHttpClientUtil.POST(smUrl, headers, params, endPoint, null);
			break;
		case "WITHOUT_TOKEN":
			headers.put(LMSAPIConstants.ORG_ID, orgId);
			endPoint = endPoint.replace(LMSAPIConstants.ORG_ID, orgId);
			endPoint = endPoint.replace(LMSAPIConstants.USER_ID, studentUserId);
			endPoint = endPoint.replace(LMSAPIConstants.SCALE_SCORE, "1250");
			response = RestHttpClientUtil.POST(smUrl, headers, params, endPoint, null);
			break;
		case "WITHOUT_SCALE_SCORE":
		    headers.put(LMSAPIConstants.AUTHORISATION, authorization);
		    headers.put(LMSAPIConstants.ORG_ID, orgId);
            endPoint = endPoint.replace(LMSAPIConstants.ORG_ID, orgId);
            endPoint = endPoint.replace(LMSAPIConstants.USER_ID, studentUserId);
            endPoint = endPoint.replace(LMSAPIConstants.SCALE_SCORE, "");
            response = RestHttpClientUtil.POST(smUrl, headers, params, endPoint, null);
            break;
		case "InVAILD_ENDPOINT":
            headers.put(LMSAPIConstants.AUTHORISATION, authorization);
            headers.put(LMSAPIConstants.ORG_ID, orgId);
            endPoint = endPoint.replace(LMSAPIConstants.ORG_ID, orgId);
            endPoint = endPoint.replace(LMSAPIConstants.USER_ID, studentUserId);
            endPoint = endPoint.replace(LMSAPIConstants.SCALE_SCORE, "1250");
            response = RestHttpClientUtil.POST(smUrl, headers, params,LMSAPIConstants.INVALID, null);
            break;
		case "INVAILD_USERID":
            headers.put(LMSAPIConstants.AUTHORISATION, authorization);
            headers.put(LMSAPIConstants.ORG_ID, orgId);
            endPoint = endPoint.replace(LMSAPIConstants.ORG_ID, orgId);
            endPoint = endPoint.replace(LMSAPIConstants.USER_ID, teacherUserId);
            endPoint = endPoint.replace(LMSAPIConstants.SCALE_SCORE, "1250");
            response = RestHttpClientUtil.POST(smUrl, headers, params, endPoint, null);
            break;
		case "INVAILD_USERNAME":
            headers.put(LMSAPIConstants.AUTHORISATION, authorization);
            headers.put(LMSAPIConstants.ORG_ID, orgId);
            endPoint = endPoint.replace(LMSAPIConstants.ORG_ID, orgId);
            endPoint = endPoint.replace(LMSAPIConstants.USER_ID, schoolAdminUserID);
            endPoint = endPoint.replace(LMSAPIConstants.SCALE_SCORE, "1250");
            response = RestHttpClientUtil.POST(smUrl, headers, params, endPoint, null);
            break;
            
		}
		Log.message(response.toString());
		// Validation
		Log.assertThat(response.get(Constants.STATUS_CODE).equals(statusCode),
				"The Status code is expected " + statusCode + " and actual " + response.get(Constants.STATUS_CODE)
						+ " Verified",
				"The Status code is expected " + statusCode + " and actual " + response.get(Constants.STATUS_CODE)
						+ "is not Verified");
		if ( statusCode.contains( CommonAPIConstants.STATUS_CODE_OK ) ) {
		// schema validation
		Log.message( response.get( Constants.REPORT_BODY ));
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "scalescore", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
		 }
        Log.testCaseResult();
		Log.endTestCase();
	}

	@DataProvider
	public Object[][] getData() {
		return new Object[][] {
				{ "TC001", "200", "Verify the status code 200 for response body for providing valid data",
						"VALID_DATA" },
				{ "TC002", "500",
						"Verify the status code 400 for response body for providing without studentIds in request body and validate response message",
						"WITHOUT_STUDENT_ID" },
				{ "TC003", "401",
						"Verify the status code 401 for response body for providing not providing Authorization in header",
						"WITHOUT_TOKEN" },
				{ "TC004", "500",
						"Verify the status code 400 for response body for providing without orgId in request body ",
						"WITHOUT_ORG_ID" },
				{ "TC005", "400",
						"Verify the status code 400 for response body for providing invalid scaleScore in request body ",
						"INVALID_SCALE_SCORE" },
				{ "TC006 ", "405", "Verify status code 405 when method type is GET", "GET METHOD" } ,
				{ "TC007", "500", "Verify the status code 404 for response body for providing data without scalescore value in path",
                "WITHOUT_SCALE_SCORE" },
				{ "TC008", "500", "Verify the status code 404 for response body for providing invaild endpoint in path",
                "INVAILD_ENDPOINT" },
				{ "TC009", "200", "Verify the status code 200 for response body for providing valid data",
                "INVAILD_USERID" },
				{ "TC010", "200", "Verify the status code 200 for response body for providing valid data",
                "INVAILD_USERNAME" }};
	}

}
