package com.savvas.sm.teacher.ui.tests.UsersSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.UserUIConstants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AddStudentToAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.restoreassignment.RestoreAssignment;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * Test the add student to assignment functionality
 * 
 * @author ajith.mohan
 *
 */
@Listeners ( EmailReport.class )
public class AddStudentToAssignment extends BaseTest {

    private static final Object anObject = null;
    private String teacherDetails;
    private String teacherDetails2;

    private String teacherId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    List<String> studentIdList = null;
    List<String> studentUserNames = null;

    private AtomicReference<String> schoolUsed = new AtomicReference<String>();

    @BeforeClass
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        teacherDetails2 = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        ArrayList<String> studentDetails = new ArrayList<String>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<String>();
        studentUserNames = new ArrayList<String>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

    }

    @Test ( priority = 5, groups = { "SMK-39141", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment01( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the assignment list when the teacher have multiple courses." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Creating new student
            String newStudentName = "newStudent" + System.nanoTime();

            HashMap<String, String> userDetails = new HashMap<>();
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, newStudentName );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            String createUserResponse = new RBSUtils().createUser( userDetails );

            List<String> studentRumbaIds = new ArrayList<>();
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( createUserResponse, RBSDataSetupConstants.USERID ) );

            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "SMNewStudentGroup" );
            HashMap<String, String> response = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Get Assignments Page and getting assignments
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentFromAssignmentPage = assignmentsPage.getAllAssignmentNames();

            // Navigate to Students Page.
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Selecting all the students and clicking assignment button.
            AddStudentToAssignmentPopup addStudentToAssignmentUsingButton = studentsPage.addStudentToAssignmentButton();
            Log.assertThat( addStudentToAssignmentUsingButton.getAddStudentToAssignmentTitle().trim().equals( UserUIConstants.ADD_STUDENT_TO_ASSIGNMENT_TITLE.trim() ), "Add Student to assignment popup loaded and Title displayed Successfully!",
                    "Add student to assignment title not displayed properly!" );

            //Clicking add student to assignment for individual student
            AddStudentToAssignmentPopup assignmentFromAddStudentPopup = studentsPage.addStudentToAssignmentButton();
            List<String> assignmentFromStudentsPage = assignmentFromAddStudentPopup.getAllAssignmentNames();
            SMUtils.clickJS( driver, addStudentToAssignmentUsingButton.getCancelButton() );

            SMUtils.logDescriptionTC( "SMK-8357 : Verify the add student to assignment popup displayed when the teacher click add student to assignment." );
            SMUtils.logDescriptionTC( "SMK-8360 : Verify the assignment list when the teacher have multiple courses." );

            //Verifications
            Log.assertThat( SMUtils.sortList( assignmentFromAssignmentPage ).equals( SMUtils.sortList( assignmentFromStudentsPage ) ), "Assignments are listed properly!",
                    "Issue in assignment listing! Expected - " + assignmentFromAssignmentPage + " Actual - " + assignmentFromStudentsPage );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-39141", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment02( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-8361 : Verify the assignment list displayes zero assignment error when the teacher don't have assignments." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Logging in as a teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            String studentName = studentUserNames.get( 0 );

            // Navigate to Students Page.
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            AddStudentToAssignmentPopup assignmentFromAddStudentPopup = studentsPage.clickAddStudentToAssignment( studentName );

            //Verifying zero state page.
            String zeroStateMessageFromUI = assignmentFromAddStudentPopup.getZeroStateMessage();
            Log.assertThat( zeroStateMessageFromUI.trim().equals( UserUIConstants.ADD_STUDENT_TO_ASSIGNMENT_ZERO_STAGE.trim() ), "Zero state message displayed!", "Error in displaying zero stage." );
            SMUtils.clickJS( driver, assignmentFromAddStudentPopup.getOkayButton() );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 4, groups = { "SMK-39141", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment03( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner); 
    	Log.testCaseInfo( "SMK-8366 : Verify the assignment list should not displayed from other teacher." + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {
            //Logging in as teacher 2 
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ), password, true );

            AssignmentsPage navigateToAssignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentsListFromTeacher2 = navigateToAssignmentsPage.assignmentsList();

            tHomePage.topNavBar.signOutfromSM();
            driver.quit();

            //Creating new student
            String newStudentName = "newStudent" + System.nanoTime();

            HashMap<String, String> userDetails = new HashMap<>();
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, newStudentName );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            String createUserResponse = new RBSUtils().createUser( userDetails );

            HashMap<String, String> studentInfo = new HashMap<>();
            studentInfo = new RBSDataSetup().generateRequestValues( createUserResponse, studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

            List<String> studentRumbaIds = new ArrayList<>();
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( createUserResponse, RBSDataSetupConstants.USERID ) );

            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "SMNewStudentGroup" );
            HashMap<String, String> response = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );

            //Logging in as teacher 1
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Page.
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Clicking add student to assignment and getting all the assignments
            AddStudentToAssignmentPopup assignmentFromAddStudentPopup = studentsPage.clickAddStudentToAssignment( newStudentName );
            List<String> assignmentList = assignmentFromAddStudentPopup.getAllAssignmentNames();
            SMUtils.clickJS( driver, assignmentFromAddStudentPopup.getCancelButton() );

            SMUtils.logDescriptionTC( "SMK-8376 : Verify the teacher can assign single assignment and again the assignment should not be displayed." );
            //Verifications
            List<String> sortListT2 = SMUtils.sortList( assignmentsListFromTeacher2 );

            if ( assignmentList.size() <= 0 | assignmentList == null ) {
                Log.pass( "Other teacher assignment not listed in add student to assignment." );
            } else {
                List<String> sortListAdStudAssignmentList = SMUtils.sortList( assignmentList );
                Log.assertThat( !sortListT2.containsAll( sortListAdStudAssignmentList ), "Other teacher assignment not listed in add student to assignment.", "Other teacher assignment is listed in add student to assignment." );
            }
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 2, groups = { "SMK-39141", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment04( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-8367 : Verify the assignment list for the shared student." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            String studentName = RBSDataSetup.getMyStudent( schoolUsed.get(), SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ) );

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( SMUtils.getKeyValueFromResponse( teacherDetails2, RBSDataSetupConstants.USERNAME ), password, true );

            AssignmentsPage navigateToAssignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentsListFromTeacher2 = navigateToAssignmentsPage.assignmentsList();

            tHomePage.topNavBar.signOutfromSM();
            driver.quit();

            //Logging in as teacher
            driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
            eventListner = new EventListener();
    		driver.register(eventListner);
            smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            GroupPage navigateToGroupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            String userID = SMUtils.getKeyValueFromResponse( studentName, RBSDataSetupConstants.USERID );
            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "SMNewStudentGroup" + System.nanoTime() );
            HashMap<String, String> response = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( userID ) );

            // Navigate to Students Page.
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Clicking add student to assignment and getting all the assignments
            AddStudentToAssignmentPopup assignmentFromAddStudentPopup = studentsPage.clickAddStudentToAssignment( studentUserNames.get( 0 ) );
            List<String> assignmentList = assignmentFromAddStudentPopup.getAllAssignmentNames();

            for ( String assignment : assignmentList ) {
                assignmentFromAddStudentPopup.selectAssignmentCheck( assignment );
            }

            //Selecting assignment and adding to student

            SMUtils.waitForElementToBeClickable( assignmentFromAddStudentPopup.getAddButton(), driver );
            SMUtils.clickJS( driver, assignmentFromAddStudentPopup.getAddButton() );
            Log.assertThat( assignmentList.equals( assignmentsListFromTeacher2 ), "Shared student assignment listed in add student to assignment.",
                    "Shared student assignment is not listed in add student to assignment. Expected-" + assignmentsListFromTeacher2 + " Actual- " + assignmentList );
            SMUtils.nap( 3 ); //This wait is for disappearing the toast message frame

            //Navigating student tab and again trying to add th same assignment.
            studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            SMUtils.scrollToTopOfPage( driver );
            assignmentFromAddStudentPopup = studentsPage.clickAddStudentToAssignment( studentUserNames.get( 0 ) );

            //Verifications
            Log.assertThat( assignmentFromAddStudentPopup.getZeroStateMessage().trim().equals( UserUIConstants.ADD_STUDENT_TO_ASSIGNMENT_ZERO_STAGE.trim() ), "Zero state message displayed!", "Error in displaying zero stage." );
            SMUtils.clickJS( driver, assignmentFromAddStudentPopup.getOkayButton() );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 5, groups = { "SMK-39141", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment05( ITestContext context ) throws Exception {
        //Creating new student
        String newStudentName = "newStudent" + System.nanoTime();

        HashMap<String, String> userDetails = new HashMap<>();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, newStudentName );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
        String createUserResponse = new RBSUtils().createUser( userDetails );

        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( createUserResponse, RBSDataSetupConstants.USERID ) );

        HashMap<String, String> groupDetails = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "SMNewStudentGroup" );
        HashMap<String, String> response = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        Log.testCaseInfo( "SMK-8362 : Verify the assignment list displayes only the assignments which is not already assigned to students." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Logging in as teacher. 
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Get Assignments Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentFromAssignmentPage = assignmentsPage.getAllAssignmentNames();

            // Navigate to Students Page.
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            AddStudentToAssignmentPopup addStudentToAssignmentUsingButton = studentsPage.addStudentToAssignmentButton();
            Log.assertThat( addStudentToAssignmentUsingButton.getAddStudentToAssignmentTitle().trim().equals( UserUIConstants.ADD_STUDENT_TO_ASSIGNMENT_TITLE.trim() ), "Add Student to assignment popup loaded and Title displayed Successfully!",
                    "Add student to assignment title not displayed properly!" );

            //clicking add student to assignment and getting all the assignment.
            tHomePage.topNavBar.navigateToStudentsTab();
            AddStudentToAssignmentPopup assignmentFromAddStudentPopup = studentsPage.clickAddStudentToAssignment( newStudentName );
            List<String> assignmentFromStudentsPage = assignmentFromAddStudentPopup.getAllAssignmentNames();
            SMUtils.logDescriptionTC( "SMK-8363 : Verify the assignment list displayes all the assignments when the student not part of any assignments." );
            //Validations
            Log.assertThat( SMUtils.sortList( assignmentFromAssignmentPage ).equals( SMUtils.sortList( assignmentFromStudentsPage ) ), "Assignments that not part of students are listed properly!",
                    "Issue in assignment listing! Expected - " + assignmentFromAssignmentPage + " Actual - " + assignmentFromStudentsPage );
            SMUtils.clickJS( driver, assignmentFromAddStudentPopup.getCancelButton() );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 6, groups = { "SMK-39141", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment06( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-8375 : Verify the teacher can assign multiple assignments at the same time by checking the checkbox." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Creating new student
            String newStudentName = "newstudent" + System.nanoTime();

            HashMap<String, String> userDetails = new HashMap<>();
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, newStudentName );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            String createUserResponse = new RBSUtils().createUser( userDetails );

            HashMap<String, String> studentInfo = new HashMap<>();
            studentInfo = new RBSDataSetup().generateRequestValues( createUserResponse, studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

            List<String> studentRumbaIds = new ArrayList<>();
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( createUserResponse, RBSDataSetupConstants.USERID ) );

            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "SMNewStudentGroup" + System.nanoTime() );
            HashMap<String, String> response = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Page.
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Assigning all the assignment to student.
            AddStudentToAssignmentPopup assignmentFromAddStudentPopup = studentsPage.clickAddStudentToAssignment( newStudentName );
            List<String> assignmentFromStudentsPage = assignmentFromAddStudentPopup.getAllAssignmentNames();
            for ( String assignment : assignmentFromStudentsPage ) {
                assignmentFromAddStudentPopup.selectAssignmentCheck( assignment );
            }
            SMUtils.nap( 1 ); //Waiting for selecting all assignments.
            SMUtils.clickJS( driver, assignmentFromAddStudentPopup.getAddButton() );
            SMUtils.nap( 2 ); // Wait for disappearing toast frame

            //Validations
            Log.assertThat( SMUtils.isElementPresent( assignmentFromAddStudentPopup.getToastMessage() ), "Multiple assignment assigned successfully!", "Issue in assigning multiple students." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 7, groups = { "SMK-39141", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment07( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-8381 : Verify the assignment list should display all the assignments when the selected student are mixed with assigned and unassigned." + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {

            //Creating new student
            String newStudentName = "newstudent" + System.nanoTime();

            HashMap<String, String> userDetails = new HashMap<>();
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
            userDetails.put( RBSDataSetupConstants.USERNAME, newStudentName );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            String createUserResponse = new RBSUtils().createUser( userDetails );

            HashMap<String, String> studentInfo = new HashMap<>();
            studentInfo = new RBSDataSetup().generateRequestValues( createUserResponse, studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
            studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );

            List<String> studentRumbaIds = new ArrayList<>();
            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( createUserResponse, RBSDataSetupConstants.USERID ) );

            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "SMNewStudentGroup" );
            HashMap<String, String> response = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );
            // Login as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Get Assignments Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentFromAssignmentPage = assignmentsPage.getAllAssignmentNames();

            // Navigate to Students Page.
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            SMUtils.logDescriptionTC( "SMK-8398 : verify all the assignments are displaying for the new student" );
            //Getting all the assignment from add student to assignment.
            AddStudentToAssignmentPopup addStudentToAssignmentUsingButton = studentsPage.addStudentToAssignmentButton();
            List<String> assignmentFromStudentPage = addStudentToAssignmentUsingButton.getAllAssignmentNames();
            //Validations
            Log.assertThat( SMUtils.sortList( assignmentFromAssignmentPage ).equals( SMUtils.sortList( assignmentFromStudentPage ) ), "Assignments are listed properly!",
                    "Issue in assignment listing! Expected - " + assignmentFromAssignmentPage + " Actual - " + assignmentFromStudentPage );

            //Assigning all the assignment to students
            for ( String assignment : assignmentFromStudentPage ) {
                addStudentToAssignmentUsingButton.selectAssignmentCheck( assignment );
            }
            SMUtils.logDescriptionTC( "SMK-8386 : Verify When the teacher successfully adds the students to the assignment, the pop up should be closed and a toast message should be displayed." );

            SMUtils.clickJS( driver, addStudentToAssignmentUsingButton.getAddButton() );
            SMUtils.nap( 2 ); // Waiting for disappearing toast message
            Log.assertThat( UserUIConstants.ADD_STUDENT_TO_ASSIGNMENT_TOAST_MESSAGE.trim().equals( addStudentToAssignmentUsingButton.getToastMessage().getText().trim() ), "Toast message displayed successfully!", "Error in toast message!." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    //Disabled due to transfer and delete course owner is not possible in 2022 system
    @Test ( enabled = false, priority = 10, groups = { "SMK-39141", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment08( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner); 
    	Log.testCaseInfo( "SMK-8401 : Verify the assignment is displayed in assignment popup when the course owner is deleted." + "<small><b><i>[" + browser + "]</b></i></small>" );

        String newOrgName = "Automation_Transfer_Org";
        String newStudentName = "Transferd_School_Stu" + System.nanoTime();
        try {

            //Creating new school to transfer teacher and student.
            String teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" );
            new SqlHelperOrganization().deleteOrganization( newOrgName );
            Integer newOrgId = new SqlHelperOrganization().createOrganization( newOrgName, newOrgName );

            SMUtils.logDescriptionTC( "SMK-8403 : Verify the assignment is displayed in assignment popup when the course owner transfered to other school." );
            //Transferring teacher
            //    new BaseAPITest().transferUser( smUrl, sessionCookie, DataSetup.organizationId.toString(), newOrgId.toString(), "teacher", teacherId );
            //  new BaseAPITest().createStudent( smUrl, sessionCookie, newStudentName, newStudentName, newStudentName, newStudentName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), newOrgId.toString(), "5" );

            //Login as teacher.
            //   teacherDetails = DataSetup.teacherDetailsMap.get( teacher );
            username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Page.
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            AddStudentToAssignmentPopup addStudentToAssignmentUsingButton = studentsPage.addStudentToAssignmentButton();

            //Validations
            Log.assertThat( addStudentToAssignmentUsingButton.getZeroStateMessage().trim().equals( UserUIConstants.ADD_STUDENT_TO_ASSIGNMENT_ZERO_STAGE.trim() ), "Zero state message displayed!", "Error in displaying zero stage." );
            SMUtils.clickJS( driver, addStudentToAssignmentUsingButton.getOkayButton() );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    //Disabled due to transfer and delete course owner is not possible in 2022 system
    @Test ( enabled = false, priority = 9, groups = { "SMK-39141", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment09( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-8402 : Verify the assignment should not be displayed in assignment popup in transfered new school." + "<small><b><i>[" + browser + "]</b></i></small>" );

        String newOrgName = "Automation_Transfer_Org";
        String newTeacherName = "Transferd_School_Teacher" + System.nanoTime();
        String newStudentName = "Transferd_School_Student" + System.nanoTime();

        UserSqlHelper helper = new UserSqlHelper();

        try {

            LoginPage smLoginPage = null;
            TeacherHomePage tHomePage = null;

            //Login as teacher from old school
            smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Get Assignments Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentFromAssignmentPage = assignmentsPage.getAllAssignmentNames();

            //Logout the teacher
            tHomePage.topNavBar.signOutfromSM();

            //Creating new school for transfer
            //      String studentId = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,personId" );
            new SqlHelperOrganization().deleteOrganization( newOrgName );
            Integer newOrgId = new SqlHelperOrganization().createOrganization( newOrgName, newOrgName );

            //Transfer the student
            // sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
            //   new BaseAPITest().transferUser( smUrl, sessionCookie, DataSetup.organizationId.toString(), newOrgId.toString(), "student", studentId );

            //Creating new teacher in new school for verifying the transfered student.
            Integer newTeacherID = helper.createTeacher( newTeacherName, newTeacherName, newTeacherName, Constants.PASSWORD_HASH, newOrgId );
            //  new BaseAPITest().createStudent( smUrl, sessionCookie, newStudentName, newStudentName, newStudentName, newStudentName, newTeacherID.toString(), newOrgId.toString(), "5" );

            //Login as new teacher 
            smLoginPage.enterCredentialsAndLogIn( newTeacherName, password );

            // Navigate to Students Page.
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            AddStudentToAssignmentPopup addStudentToAssignmentUsingButton = studentsPage.addStudentToAssignmentButton();

            //Validations
            Log.assertThat( addStudentToAssignmentUsingButton.getZeroStateMessage().trim().equals( UserUIConstants.ADD_STUDENT_TO_ASSIGNMENT_ZERO_STAGE.trim() ), "Zero state message displayed!", "Error in displaying zero stage." );
            SMUtils.clickJS( driver, addStudentToAssignmentUsingButton.getOkayButton() );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = false, priority = 8, groups = { "SMK-39141", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment10( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the restored assignments are not displayed for already added assignments." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Login as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Get Assignments Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentFromAssignmentPage = assignmentsPage.getAllAssignmentNames();
            AssignmentDetailsPage assignmentDetails = assignmentsPage.viewAssignmentDetailsByAssignmentName( assignmentFromAssignmentPage.get( 0 ) );

            //Deleting the assignment
            assignmentDetails.deleteAssignmenttab();
            SMUtils.nap( 2 ); //Waiting for deleting 
            assignmentDetails.deleteAssignmentButton();

            //Restoring the assignment
            HashMap<String, String> assignmentUser = new SqlHelperCourses().getAssignmentUserDetails( assignmentFromAssignmentPage.get( 0 ) );
            HashMap<String, String> assignmentDetailsMap = new HashMap<>();
            assignmentDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
            assignmentDetailsMap.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
            assignmentDetailsMap.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
            assignmentDetailsMap.put( AssignmentAPIConstants.COURSE_ID, "1" );
            assignmentDetailsMap.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUser.get( Constants.ASSIGNMENT_USER_ID ) );
            HashMap<String, String> restoreDeletedAssignment = new RestoreAssignment().restoreDeletedAssignment( smUrl, assignmentDetailsMap, null );

            // Navigate to Students Page.
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            AddStudentToAssignmentPopup addStudentToAssignmentUsingButton = studentsPage.addStudentToAssignmentButton();

            //Validations
            Log.assertThat( addStudentToAssignmentUsingButton.getAddStudentToAssignmentTitle().trim().equals( UserUIConstants.ADD_STUDENT_TO_ASSIGNMENT_TITLE.trim() ), "Add Student to assignment popup loaded and Title displayed Successfully!",
                    "Add student to assignment title not displayed properly!" );

            Log.assertThat( !addStudentToAssignmentUsingButton.isAssignmentExist( assignmentFromAssignmentPage.get( 0 ) ), "Restored assignment not exist", "Restored assignment still exist" );
            SMUtils.clickJS( driver, addStudentToAssignmentUsingButton.getOkayButton() );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 9, groups = { "SMK-54908", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment11( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify paused Students are not Displayed for any of the selected Course." + "<small><b><i>[" + browser + "]</b></i></small>" );
    	SMUtils.logDescriptionTC( "SMK-54908 : Verify the Search field will filter Student Using Student Username" );
        SMUtils.logDescriptionTC( "SMK-54908 : Verify the Search field will filter Student Using Student First name and Last Name." );
        SMUtils.logDescriptionTC( "SMK-54908 : Verify Minimum 3 characters should be entered for filter." );
        try {

            //Login as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Get Assignments Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> allAssignmentNames = assignmentsPage.getAllAssignmentNames();
            AssignmentDetailsPage assignmentDetails = assignmentsPage.clickViewAssignment();
            List<String> studentListfromAssignementDetails = assignmentDetails.getStudentListfromAssignementDetails();
            assignmentDetails.pauseAssignmentForAllStudents();
            //Get courses page
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            //Assign course to the students
            coursesPage.clickCourseFromTheListing( allAssignmentNames.get( 0 ) );
            coursesPage.clickAssignButton();
            List<String> allStudentNameFromAssignPopUp = coursesPage.getAllStudentNameFromAssignPopUp();
            Log.assertThat( !allStudentNameFromAssignPopUp.equals( studentListfromAssignementDetails ), "The Paused Student are not displayed", "The paused student are displayed" );
            coursesPage.clickCloseBtn();

            SMUtils.logDescriptionTC( "SMK-54908 : Verify the Search field will filter Student Using Student Username" );
            SMUtils.logDescriptionTC( "SMK-54908 : Verify the Search field will filter Student Using Student First name." );
            SMUtils.logDescriptionTC( "SMK-54908 : Verify the Search field will filter Student Using Student last name" );
            SMUtils.logDescriptionTC( "SMK-54908 : Verify Minimum 3 characters should be entered for filter." );

            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickFirstStudent();
            studentsPage.clickSubNavigation( "User Profile" );
            String studentUsername = studentsPage.getUserName();
            String studentfirstName = studentsPage.getFirstName();
            String studentlastname = studentsPage.getLastName();
            CoursesPage coursesPage1 = tHomePage.topNavBar.navigateToCourseListingPage();
            coursesPage1.clickCourseFromTheListing( Constants.SM_FOCUS_MATH_GRADE1 );
            coursesPage1.clickAssignButton();
            coursesPage1.enterStudentNameinSearchField( studentUsername );
            Log.assertThat( new AssignAssignmentPopup( driver ).getStudentUserNameList().contains( studentUsername ), "The Specified student are displayed when student user name is entered in the search field",
                    "The Specified student are not displayed when student user name is entered in the search field" );

            coursesPage.enterStudentNameinSearchField( studentfirstName );
            Log.assertThat( new AssignAssignmentPopup( driver ).getStudentFirstNameList().contains( studentfirstName ), "The Specified student are displayed when student firstname is entered in the search field",
                    "The Specified student are not displayed when student first name is entered in the search field" );

            coursesPage.enterStudentNameinSearchField( studentlastname );
            Log.assertThat( new AssignAssignmentPopup( driver ).getStudentLastNamelist().contains( studentlastname ), "The Specified student are displayed when student lastname is entered in the search field",
                    "The Specified student are not displayed when student last name is entered in the search field" );

            coursesPage1.enterStudentNameinSearchField( studentfirstName.substring( 0, 3 ) );
            Log.assertThat( new AssignAssignmentPopup( driver ).getStudentFirstNameList().stream().allMatch( name -> name.contains( studentfirstName.substring( 0, 3 ) ) ), "Minimum 3 characters are entered to filter the student using search field",
                    "Minimum 3 characters are not entered to filter the student using search field" );
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 10, groups = { "SMK-54908", "Students", "AddStudentToAssignment" } )
    public void tcAddStudentToAssignment12( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify the Add Button at the side of Each Student." + "<small><b><i>[" + browser + "]</b></i></small>" );
    	SMUtils.logDescriptionTC( "SMK-54908 : Verify the Remove Button changed to Add Button when Remove Button Clicked" );
        SMUtils.logDescriptionTC( "SMK-54908 : Verify the Zero State Icon when no students to assign" );

        try {

            //Login as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            List<String> CoursesFromCoursesPage = coursesPage.getCourseNameList();
            coursesPage.clickCourseFromTheListing( Constants.MATH );
            coursesPage.clickAssignButton();
            coursesPage.clickContinueToAssignButtonMSDA();
            coursesPage.getAllStudentNameFromAssignPopUp();
            List<String> allStudentNameFromAssignPopUp = coursesPage.getAllStudentNameFromAssignPopUp();
            coursesPage.isAddButtonEnabled();
            Log.assertThat( coursesPage.isAddButtonEnabled(), "Add button are displayed at the end each student name", "Add button are not displayed at the end each student name" );
            coursesPage.clickCloseBtn();

            SMUtils.logDescriptionTC( "SMK-54908 : Verify the Remove Button changed to Add Button when Remove Button Clicked" );

            CoursesPage coursesPage1 = tHomePage.topNavBar.navigateToCourseListingPage();
            List<String> CoursesFromCoursesPage1 = coursesPage.getCourseNameList();
            coursesPage1.clickCourseFromTheListing( Constants.MATH );
            coursesPage1.clickAssignButton();
            coursesPage.clickContinueToAssignButtonMSDA();
            coursesPage1.getAllStudentNameFromAssignPopUp();
            coursesPage1.isAddButtonEnabled();
            coursesPage1.addCourseToStudents();
            coursesPage1.verifyRemoveBtnIsPresent();

            Log.assertThat( allStudentNameFromAssignPopUp.contains( allStudentNameFromAssignPopUp.get( 0 ) ), "The Remove button are Change to Add button when remove button is clicked",
                    "The Remove button are not Change to Add button when remove button is clicked" );

            SMUtils.logDescriptionTC( "SMK-54908 : Verify the Zero State Icon when no students to assign" );

            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.addStudentToAssignmentButton();
            CoursesPage coursesPage2 = tHomePage.topNavBar.navigateToCourseListingPage();
            List<String> CoursesFromCoursesPage2 = coursesPage.getCourseNameList();
            coursesPage2.clickCourseFromTheListing( Constants.MATH );
            coursesPage2.clickAssignButton();
            coursesPage2.clickContinueToAssignButtonMSDA();
            coursesPage2.getAllStudentNameFromAssignPopUp();
            AssignAssignmentPopup assignmentPopUp = new AssignAssignmentPopup( driver );
            Log.assertThat( assignmentPopUp.verifyZeroState().contains( "No Unassigned Students Found" ), "Zero State Icon are Display When there is no student to Select", "Zero State Icon are not Display When there is no student to Select" );
            coursesPage2.clickCloseBtn();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}