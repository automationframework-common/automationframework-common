package com.savvas.sm.api.tests.smnew.license;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

/***
 * This class contains test scripts for license consumption report from lms
 * 
 * @author sudarshan.govindarajan
 *
 */

public class GetFocusLicense extends BaseAPITest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private Response response;
    //private String password = LicenseAPIConstants.password;

    private String focusMathTeacherDetails;
    private String focusReadingTeacherDetails;

    private String defaultMathTeacherDetails;
    private String defaultReadingTeacherDetails;

    private String flexTeacherDetails;

    public String focusMathSchool = null;
    public String focusReadingSchool = null;
    public String defaultMathSchool = null;
    public String defaultReadingSchool = null;
    public String flexSchool = null;

    public String focus_Math_User_Id = null;

    public String focus_Math_User_name = null;

    public String focus_Reading_User_Id = null;

    public String focus_Reading_User_name = null;

    public String default_Math_User_Id = null;

    public String default_Math_User_name = null;

    public String default_Reading_User_Id = null;

    public String default_Reading_User_name = null;

    public String flex_User_Id = null;

    public String flex_User_name = null;

    HashMap<String, String> focusMathSchoolCreateStudentResponse = new HashMap<>();

    HashMap<String, String> focusReadingSchoolCreateStudentResponse = new HashMap<>();

    HashMap<String, String> defaultMathSchoolCreateStudentResponse = new HashMap<>();
    HashMap<String, String> defaultReadingSchoolCreateStudentResponse = new HashMap<>();
    HashMap<String, String> flexSchoolCreateStudentResponse = new HashMap<>();

    @BeforeClass(alwaysRun = true)
    public void BeforeTest() {

        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        focusMathSchool = RBSDataSetup.getSchools( RBSDataSetupConstants.Schools.MATH_FOCUS_SCHOOL );
        focusReadingSchool = RBSDataSetup.getSchools( RBSDataSetupConstants.Schools.READING_FOCUS_SCHOOL );
        defaultMathSchool = RBSDataSetup.getSchools( RBSDataSetupConstants.Schools.MATH_SCHOOL );
        defaultReadingSchool = RBSDataSetup.getSchools( RBSDataSetupConstants.Schools.READING_SCHOOL );
        flexSchool = RBSDataSetup.getSchools( RBSDataSetupConstants.Schools.FLEX_SCHOOL );
        focusMathTeacherDetails = RBSDataSetup.getMyTeacher( focusMathSchool );
        focusReadingTeacherDetails = RBSDataSetup.getMyTeacher( focusReadingSchool );

        defaultMathTeacherDetails = RBSDataSetup.getMyTeacher( defaultMathSchool );
        defaultReadingTeacherDetails = RBSDataSetup.getMyTeacher( defaultReadingSchool );
        flexTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );

    }

    /**
     * Method for testing Check Focus License API test case
     * 
     * 
     * @throws Exception
     */

    @Test ( dataProvider = "getDataForPositiveScenarios", groups = { "SMK-51571", "smoke_test_case", "P1", "Check Focus License API", "API" }, priority = 1 )
    public void getFocusLicenseResult001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        HashMap<String, String> Dummy = new HashMap<>();
        // End point for API
        String endPoint = LicenseAPIConstants.GET_FOCUS_LICENSE_USAGE;
        String pathparameter = "orgIds";
        List<String> queryParamsList = new ArrayList<String>();
        List<String> focusReadingQueryParameterList = new ArrayList<String>();

        HashMap<String, String> LicenseSchoolGroupDetails = new HashMap<>();
        HashMap<String, String> LicenseSchoolAssignmentDetails = new HashMap<>();
        List<String> LicenseSchoolStudentRumbaIds = new ArrayList<>();
        String token;
        Log.testCaseInfo( testcaseName + testcaseDescription );

        switch ( scenarioType ) {
            case "FOCUS_MATH_LICENSE":
                String studentDetails = RBSDataSetup.getMyStudent( focusMathSchool, SMUtils.getKeyValueFromResponse( focusMathTeacherDetails, "userName" ) );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( focusMathSchool ) );
                headers.put( LicenseAPIConstants.USERID, SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
                token = new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.AUTHORIZATION, "Bearer " + token );
                queryParamsList.add( RBSDataSetup.organizationIDs.get( focusMathSchool ) );

                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( focusMathSchool ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( focusMathTeacherDetails, "userId" ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH_1 );
                LicenseSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( focusMathTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolAssignmentDetails = new AssignmentAPI().assignAssignment( smUrl, LicenseSchoolAssignmentDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) ), "users" );

                break;

            case "FOCUS_READING_LICENSE":

                String studentReadingDetails = RBSDataSetup.getMyStudent( focusReadingSchool, SMUtils.getKeyValueFromResponse( focusReadingTeacherDetails, "userName" ) );

                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( focusReadingSchool ) );
                headers.put( LicenseAPIConstants.USERID, SMUtils.getKeyValueFromResponse( studentReadingDetails, "userId" ) );
                token = new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentReadingDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.AUTHORIZATION, "Bearer " + token );
                focusReadingQueryParameterList.add( RBSDataSetup.organizationIDs.get( focusReadingSchool ) );

                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( focusReadingSchool ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( focusReadingTeacherDetails, "userId" ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING_1 );
                LicenseSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( focusReadingTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolAssignmentDetails = new AssignmentAPI().assignAssignment( smUrl, LicenseSchoolAssignmentDetails, Arrays.asList( SMUtils.getKeyValueFromResponse( studentReadingDetails, "userId" ) ), "users" );

                break;
            default:
                Log.message( "Invalid Scenario Type" );
        }

        if ( queryParamsList.size() > 0 ) {
            endPoint = endPoint + "?" + pathparameter + "=" + queryParamsList.get( 0 );
        } else if ( focusReadingQueryParameterList.size() > 0 ) {
            endPoint = endPoint + "?" + pathparameter + "=" + focusReadingQueryParameterList.get( 0 );
        }
        Response response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint );

        Log.message( "Response Code : " + response.getStatusCode() );
        int actual_StatusCode = response.getStatusCode();

        Log.assertThat( actual_StatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode );

        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataForPositiveScenarios() {
        Object[][] data = { { "TC:01", "200", "Verify the status code as 200 for valid data when the valid organization id is set to  To GET - Focus License.\n" + "An Organization should have a Focus math license", "FOCUS_MATH_LICENSE" },
                { "TC:02", "200", "Verify the status code as 200 for valid data when the valid organization id is set to  To GET - Focus License\n" + "An Organization should have a Focus Reading license,", "FOCUS_READING_LICENSE" }, };
        return data;
    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51571", "Check Focus License API", "API" }, priority = 2 )
    public void getFocusLicenseResult002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        // End point for API
        String endPoint = LicenseAPIConstants.GET_FOCUS_LICENSE_USAGE;
        String pathparameter = "orgIds";
        List<String> queryParamsList = new ArrayList<String>();
        HashMap<String, String> LicenseSchoolGroupDetails = new HashMap<>();
        HashMap<String, String> LicenseSchoolAssignmentDetails = new HashMap<>();
        List<String> LicenseSchoolStudentRumbaIds = new ArrayList<>();
        String cmsResponse = null;
        String token = null;
        Log.testCaseInfo( testcaseName + testcaseDescription );
        HashMap<String, String> Dummy = new HashMap<>();
        List<String> invalidSchoolStudentRumbaIds = new ArrayList<>();
        List<String> defaultMathSchoolStudentRumbaIds = new ArrayList<>();
        List<String> defaultMathQueryParmaterList = new ArrayList<String>();
        List<String> defaultReadingQueryParmaterList = new ArrayList<String>();
        List<String> flexQueryParmaterList = new ArrayList<String>();
        List<String> accessDeniedQueryParmaterList = new ArrayList<String>();

        switch ( scenarioType ) {
            case "DEFAULT_MATH_LICENSE":
                HashMap<String, String> DefaultmathSchoolStudentDetails = new HashMap<>();
                DefaultmathSchoolStudentDetails = generateRequestValues( DefaultmathSchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( defaultMathSchool ) );
                DefaultmathSchoolStudentDetails = updateRequestBodyValues( DefaultmathSchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( defaultMathSchool ) );
                DefaultmathSchoolStudentDetails = updateRequestBodyValues( DefaultmathSchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.TEACHER_ID,
                        SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                DefaultmathSchoolStudentDetails = updateRequestBodyValues( DefaultmathSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                defaultMathSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, DefaultmathSchoolStudentDetails );
                cmsResponse = new com.savvas.sm.utils.rbs.RBSUtils().getUserWithUserService(
                        SMUtils.getKeyValueFromResponse( defaultMathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( defaultMathSchool ) );

                default_Math_User_Id = SMUtils.getKeyValueFromResponse( defaultMathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.CreateStudentAPIConstants.PERSONID );
                default_Math_User_name = SMUtils.getKeyValueFromResponse( defaultMathSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new com.savvas.sm.utils.rbs.RBSUtils().updateUserOrgId( new com.savvas.sm.utils.rbs.RBSUtils().getUser( default_Math_User_Id ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( defaultMathSchool ) ) );
                defaultMathSchoolStudentRumbaIds.add( default_Math_User_Id );
                token = LicenseAPIConstants.BEARER + new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( default_Math_User_name, RBSDataSetupConstants.DEFAULT_PASSWORD );

                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( defaultMathSchool ) );
                headers.put( LicenseAPIConstants.USERID, default_Math_User_Id );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                defaultMathQueryParmaterList.add( RBSDataSetup.organizationIDs.get( defaultMathSchool ) );
                LicenseSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, "userId" ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( defaultMathSchool ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, LicenseSchoolGroupDetails, defaultMathSchoolStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( defaultMathSchool ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, "userId" ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                LicenseSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolAssignmentDetails = new AssignmentAPI().assignAssignment( smUrl, LicenseSchoolAssignmentDetails, defaultMathSchoolStudentRumbaIds, "users" );
                if ( LicenseSchoolAssignmentDetails.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Assignment created for the student !" );
                }
                break;

            case "DEFAULT_READING_LICENSE":
                HashMap<String, String> defaultReadingSchoolStudentDetails = new HashMap<>();
                defaultReadingSchoolStudentDetails = generateRequestValues( defaultReadingSchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( defaultReadingSchool ) );
                defaultReadingSchoolStudentDetails = updateRequestBodyValues( defaultReadingSchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( defaultReadingSchool ) );
                defaultReadingSchoolStudentDetails = updateRequestBodyValues( defaultReadingSchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.TEACHER_ID,
                        SMUtils.getKeyValueFromResponse( defaultReadingTeacherDetails, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                defaultReadingSchoolStudentDetails = updateRequestBodyValues( defaultReadingSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( defaultReadingTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                defaultReadingSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, defaultReadingSchoolStudentDetails );
                cmsResponse = new com.savvas.sm.utils.rbs.RBSUtils().getUserWithUserService(
                        SMUtils.getKeyValueFromResponse( defaultReadingSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( defaultReadingSchool ) );

                default_Reading_User_Id = SMUtils.getKeyValueFromResponse( defaultReadingSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.CreateStudentAPIConstants.PERSONID );
                default_Reading_User_name = SMUtils.getKeyValueFromResponse( defaultReadingSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new com.savvas.sm.utils.rbs.RBSUtils().updateUserOrgId( new com.savvas.sm.utils.rbs.RBSUtils().getUser( default_Reading_User_Id ), RBSDataSetupConstants.STUDENT_ROLE,
                        Arrays.asList( RBSDataSetup.organizationIDs.get( defaultReadingSchool ) ) );
                List<String> defaultReadingSchoolStudentRumbaIds = new ArrayList<>();
                defaultReadingSchoolStudentRumbaIds.add( default_Reading_User_Id );
                token = LicenseAPIConstants.BEARER + new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( default_Reading_User_name, RBSDataSetupConstants.DEFAULT_PASSWORD );

                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( defaultReadingSchool ) );
                headers.put( LicenseAPIConstants.USERID, default_Reading_User_Id );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                defaultReadingQueryParmaterList.add( RBSDataSetup.organizationIDs.get( defaultReadingSchool ) );
                LicenseSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( defaultReadingTeacherDetails, "userId" ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( defaultReadingSchool ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, LicenseSchoolGroupDetails, defaultReadingSchoolStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( defaultReadingSchool ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( defaultReadingTeacherDetails, "userId" ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_READING );
                LicenseSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( defaultReadingTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolAssignmentDetails = new AssignmentAPI().assignAssignment( smUrl, LicenseSchoolAssignmentDetails, defaultReadingSchoolStudentRumbaIds, "users" );
                if ( LicenseSchoolAssignmentDetails.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Assignment created for the student !" );
                }
                break;

            case "FLEX_LICENSE_SCHOOL":
                HashMap<String, String> flexSchoolStudentDetails = new HashMap<>();
                flexSchoolStudentDetails = generateRequestValues( flexSchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                flexSchoolStudentDetails = updateRequestBodyValues( flexSchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                flexSchoolStudentDetails = updateRequestBodyValues( flexSchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.TEACHER_ID,
                        SMUtils.getKeyValueFromResponse( flexTeacherDetails, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                flexSchoolStudentDetails = updateRequestBodyValues( flexSchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                flexSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, flexSchoolStudentDetails );
                cmsResponse = new com.savvas.sm.utils.rbs.RBSUtils().getUserWithUserService(
                        SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );

                flex_User_Id = SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.CreateStudentAPIConstants.PERSONID );
                flex_User_name = SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new com.savvas.sm.utils.rbs.RBSUtils().updateUserOrgId( new com.savvas.sm.utils.rbs.RBSUtils().getUser( flex_User_Id ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) ) );
                List<String> flexStudentRumbaIds = new ArrayList<>();
                flexStudentRumbaIds.add( flex_User_Id );
                token = LicenseAPIConstants.BEARER + new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( flex_User_name, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                headers.put( LicenseAPIConstants.USERID, flex_User_Id );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                flexQueryParmaterList.add( RBSDataSetup.organizationIDs.get( flexSchool ) );
                LicenseSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( flexTeacherDetails, "userId" ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, LicenseSchoolGroupDetails, flexStudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( flexTeacherDetails, "userId" ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_READING );
                LicenseSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolAssignmentDetails = new AssignmentAPI().assignAssignment( smUrl, LicenseSchoolAssignmentDetails, flexStudentRumbaIds, "users" );
                if ( LicenseSchoolAssignmentDetails.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Assignment created for the student !" );
                }
                break;

            case "ACCESS_DENIED":
                HashMap<String, String> SchoolStudentDetails = new HashMap<>();
                SchoolStudentDetails = generateRequestValues( SchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                SchoolStudentDetails = updateRequestBodyValues( SchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                SchoolStudentDetails = updateRequestBodyValues( SchoolStudentDetails, UserAPIConstants.CreateStudentAPIConstants.TEACHER_ID,
                        SMUtils.getKeyValueFromResponse( flexTeacherDetails, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                SchoolStudentDetails = updateRequestBodyValues( SchoolStudentDetails, RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                flexSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, SchoolStudentDetails );
                cmsResponse = new com.savvas.sm.utils.rbs.RBSUtils().getUserWithUserService(
                        SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );

                flex_User_Id = SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.CreateStudentAPIConstants.PERSONID );
                flex_User_name = SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new com.savvas.sm.utils.rbs.RBSUtils().updateUserOrgId( new com.savvas.sm.utils.rbs.RBSUtils().getUser( flex_User_Id ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( defaultMathSchool ) ) );
                List<String> StudentRumbaIds = new ArrayList<>();
                StudentRumbaIds.add( flex_User_Id );
                String invalid_org_id = RBSDataSetup.organizationIDs.get( flexSchool ) + "12345";
                token = LicenseAPIConstants.BEARER + new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( flex_User_name, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, invalid_org_id );
                headers.put( LicenseAPIConstants.USERID, flex_User_Id );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );

                accessDeniedQueryParmaterList.add( RBSDataSetup.organizationIDs.get( flexSchool ) );
                LicenseSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, "userId" ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, LicenseSchoolGroupDetails, StudentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( defaultMathSchool ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, "userId" ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                LicenseSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolAssignmentDetails = new AssignmentAPI().assignAssignment( smUrl, LicenseSchoolAssignmentDetails, StudentRumbaIds, "users" );
                if ( LicenseSchoolAssignmentDetails.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Assignment created for the student !" );
                }
                break;

            case "VALID_ORG_INVALID_USER":
                HashMap<String, String> SchoolStudentDetailsInvalid = new HashMap<>();
                SchoolStudentDetailsInvalid = generateRequestValues( SchoolStudentDetailsInvalid, UserAPIConstants.CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                SchoolStudentDetailsInvalid = updateRequestBodyValues( SchoolStudentDetailsInvalid, UserAPIConstants.CreateStudentAPIConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                SchoolStudentDetailsInvalid = updateRequestBodyValues( SchoolStudentDetailsInvalid, UserAPIConstants.CreateStudentAPIConstants.TEACHER_ID,
                        SMUtils.getKeyValueFromResponse( flexTeacherDetails, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERID_FIELD ) );
                SchoolStudentDetailsInvalid = updateRequestBodyValues( SchoolStudentDetailsInvalid, RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( flexTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                flexSchoolCreateStudentResponse = new UserAPI().createStudent( smUrl, SchoolStudentDetailsInvalid );
                cmsResponse = new com.savvas.sm.utils.rbs.RBSUtils().getUserWithUserService(
                        SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.CreateStudentAPIConstants.PERSONID ) );
                Dummy = new RBSDataSetup().generateRequestValues( cmsResponse, Dummy, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( flexSchool ) );

                flex_User_Id = SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.CreateStudentAPIConstants.PERSONID );
                flex_User_name = SMUtils.getKeyValueFromResponse( flexSchoolCreateStudentResponse.get( Constants.BODY ), Constants.DATA + "," + UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD );
                new com.savvas.sm.utils.rbs.RBSUtils().updateUserOrgId( new com.savvas.sm.utils.rbs.RBSUtils().getUser( flex_User_Id ), RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( defaultMathSchool ) ) );
                List<String> StudentRumbaIdsInvalid = new ArrayList<>();
                StudentRumbaIdsInvalid.add( flex_User_Id );
                String invalid_user_id = new com.savvas.sm.utils.rbs.RBSUtils().getUser( flex_User_Id ) + "123";
                token = LicenseAPIConstants.BEARER + new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( flex_User_name, RBSDataSetupConstants.DEFAULT_PASSWORD );
                headers.put( LicenseAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( defaultMathSchool ) );
                headers.put( LicenseAPIConstants.USERID, invalid_user_id );
                headers.put( LicenseAPIConstants.AUTHORIZATION, token );
                flexQueryParmaterList.add( RBSDataSetup.organizationIDs.get( flexSchool ) );
                LicenseSchoolGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, "userId" ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( defaultMathSchool ) );
                LicenseSchoolGroupDetails.put( GroupAPIConstants.CreateGroupAPIConstants.GROUP_NAME, "groupName" );
                if ( new GroupAPI().createGroup( smUrl, LicenseSchoolGroupDetails, StudentRumbaIdsInvalid ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student !" );
                }
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( defaultMathSchool ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, "userId" ) );
                LicenseSchoolAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                LicenseSchoolAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN,
                        new com.savvas.sm.utils.rbs.RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( defaultMathTeacherDetails, RBSDataSetupConstants.USERNAME ), LicenseAPIConstants.focus_License_Password ) );
                LicenseSchoolAssignmentDetails = new AssignmentAPI().assignAssignment( smUrl, LicenseSchoolAssignmentDetails, StudentRumbaIdsInvalid, "users" );
                if ( LicenseSchoolAssignmentDetails.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Assignment created for the student !" );
                }
                break;

            default:
                Log.message( "Invalid Scenario Type" );
        }

        if ( !defaultMathQueryParmaterList.isEmpty() ) {
            endPoint = endPoint + "?" + pathparameter + "=" + defaultMathQueryParmaterList.get( 0 );
        } else if ( !defaultReadingQueryParmaterList.isEmpty() ) {
            endPoint = endPoint + "?" + pathparameter + "=" + defaultReadingQueryParmaterList.get( 0 );
        } else if ( !flexQueryParmaterList.isEmpty() ) {
            endPoint = endPoint + "?" + pathparameter + "=" + flexQueryParmaterList.get( 0 );
        } else if ( !accessDeniedQueryParmaterList.isEmpty() ) {
            endPoint = endPoint + "?" + pathparameter + "=" + accessDeniedQueryParmaterList.get( 0 );
        }
        Response response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint );

        Log.message( "Response Code : " + response.getStatusCode() );
        Log.message( "Response Body : " + response.getBody().asString() );
        if ( response.getStatusCode() == 200 ) {
            String responseBody = response.getBody().asString();
            Log.assertThat( responseBody.equalsIgnoreCase( "false" ), "Response should be false", "Response is not false" );
        }
        int actual_StatusCode = response.getStatusCode();

        Log.assertThat( actual_StatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC:01", "200", "Verify the status code as 200 for valid data when the valid organization id is set to  To GET - Focus License\n" + "An Organization should have a Default and Focus Math License", "DEFAULT_MATH_LICENSE" },
                { "TC:02", "200", "Verify the status code as 200 for valid data when the valid organization id is set to  To GET - Focus License\n" + "An Organization should have a Default and Focus Reading License", "DEFAULT_READING_LICENSE" },
                { "TC:03", "200", "Verify the status code as 200 for valid data when the valid organization id is set to  To GET - Focus License\n" + "An Organization should have a only Flex ", "FLEX_LICENSE_SCHOOL" },
                { "TC:04", "403", "Verify the status code as 403 for wrong credentials To GET - Focus License ", "ACCESS_DENIED" },
                { "TC:05", "401", "Verify 401 status code when invalid user-id and valid authorization is given To GET - Focus License", "VALID_ORG_INVALID_USER" } };
        return data;
    }

    public HashMap<String, String> generateRequestValues( HashMap<String, String> studentDetails, String key, String value ) {
        HashMap<String, String> generatedStudentDetails = studentDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, new Faker().name().firstName() );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, new Faker().name().firstName().substring( 1 ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, new Faker().name().lastName() );
        generatedStudentDetails.put( UserAPIConstants.CreateStudentAPIConstants.GRADE, UserAPIConstants.CreateStudentAPIConstants.grade.FIRST.toString() );
        generatedStudentDetails.put( UserAPIConstants.CreateStudentAPIConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserAPIConstants.CreateStudentAPIConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, new Faker().name().username() );
        generatedStudentDetails.put( UserAPIConstants.CreateStudentAPIConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserAPIConstants.CreateStudentAPIConstants.ETHINICITY, UserAPIConstants.CreateStudentAPIConstants.ethnicity.NOT_HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserAPIConstants.CreateStudentAPIConstants.SPECIAL_SERVICES, UserAPIConstants.CreateStudentAPIConstants.specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserAPIConstants.CreateStudentAPIConstants.HAS_DISABILITY, UserAPIConstants.CreateStudentAPIConstants.hasDisability.YES.toString() );
        generatedStudentDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.GENDER_FIELD, UserAPIConstants.CreateStudentAPIConstants.gender.FEMALE.toString() );
        generatedStudentDetails.put( UserAPIConstants.CreateStudentAPIConstants.HAS_ECONOMIC_DISADVANTAGE, UserAPIConstants.CreateStudentAPIConstants.hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserAPIConstants.CreateStudentAPIConstants.HAS_ENGLISH_PROFICIENCY, UserAPIConstants.CreateStudentAPIConstants.hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserAPIConstants.CreateStudentAPIConstants.ISMIGRANT, UserAPIConstants.CreateStudentAPIConstants.isMigrant.MIGRANT.toString() );
        return generatedStudentDetails;
    }

    public HashMap<String, String> updateRequestBodyValues( HashMap<String, String> studentDetails, String key, String value ) {
        HashMap<String, String> generatedStudentDetails = studentDetails;
        if ( generatedStudentDetails.containsKey( key ) ) {
            generatedStudentDetails.put( key, value );
        } else {
            generatedStudentDetails.put( key, value );
        }
        return generatedStudentDetails;
    }

}
