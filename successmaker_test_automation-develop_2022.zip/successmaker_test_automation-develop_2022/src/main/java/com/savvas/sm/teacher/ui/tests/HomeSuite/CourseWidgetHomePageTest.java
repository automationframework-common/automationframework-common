package com.savvas.sm.teacher.ui.tests.HomeSuite;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class CourseWidgetHomePageTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String usernameTeacher = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    TeacherHomePage tHomePage;
    LoginPage smLoginPage;
    String teacherDetailsAgain;
    List<String> studentListFromTheAssignmentPopup;
    List<String> studentList;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );


    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        String teacherDetailsAgain = RBSDataSetup.getMyTeacher( school );

        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        usernameTeacher = SMUtils.getKeyValueFromResponse( teacherDetailsAgain, RBSDataSetupConstants.USERNAME );

    }

    @Test ( description = "Verify the image display & rule for default courses in Home Page for teacher user", groups = { "SMK-41833", "HomePage", "Rule for course" }, priority = 1 )
    public void tc_SMCourseRule001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseRule001:Verify the image display & rule for default courses in Home Page for teacher user <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.createStudent();
            tHomePage.topNavBar.navigateToHomeTab();
            //Validate Rule for Math course
            Log.assertThat( tHomePage.getCourseRule( Constants.HomePage.RULE_FOR_DEFAULT_MATH, Constants.HomePage.MATH_COURSE ).equals( Constants.HomePage.RULE_FOR_DEFAULT_MATH ), "Rule for default Math is diplaying", "Rule for Math is not displaing" );
            //Validate Rule for Reading course
            Log.assertThat( tHomePage.getCourseRule( Constants.HomePage.RULE_FOR_DEFAULT_READING, Constants.HomePage.READING_COURSE ).equals( Constants.HomePage.RULE_FOR_DEFAULT_READING ), "Rule for Reading is displaying",
                    "Rule for reading is not displaying" );
            // Sign Out
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    //UI automation supports only Flex licensed org. Hence making this case as skip
    @Test ( enabled = false, description = "Verify the image display & rule for Math Focus and Read Focus courses in Home Page for teacher user",  groups = { "SMK-41833", "HomePage", "Rule for course" }, priority = 2 )
    public void tc_SMCourseRule002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseRule002:Verify the image display & rule for Math Focus and Read Focus courses in Home Page for teacher user<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );
            //Validate Rule for Math course
            Log.assertThat( tHomePage.getCourseRule( Constants.HomePage.RULE_FOR_FOCUS_MATH, Constants.HomePage.FOCUS_MATH_COURSE ).equals( Constants.HomePage.RULE_FOR_FOCUS_MATH ), "Rule for focus Math is diplaying",
                    "Rule for focus Math is not displaing" );

            //Validate Rule for Reading course
            Log.assertThat( tHomePage.getCourseRule( Constants.HomePage.RULE_FOR_FOCUS_READING, Constants.HomePage.FOCUS_READING_COURSE ).equals( Constants.HomePage.RULE_FOR_FOCUS_READING ), "Rule for focus Reading is displaying",
                    "Rule for reading is not displaying" );
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the image display & rule for Custom Math and Custom Read courses in Home Page for teacher user", groups = { "SMK-41833", "HomePage", "Rule for course" }, priority = 3 )
    public void tc_SMCourseRule003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseRule003:Verify the image display & rule for Custom Math and Custom Read courses in Home Page for teacher user <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            //Validate Rule for Math course
            Log.assertThat( tHomePage.getCourseRule( Constants.HomePage.RULE_FOR_CUSTOM_MATH, Constants.HomePage.FOCUS_MATH_COURSE ).equals( Constants.HomePage.RULE_FOR_CUSTOM_MATH ), "Rule for custom Math is diplaying",
                    "Rule for custom Math is not displaing" );
            //Validate Rule for Reading course
            Log.assertThat( tHomePage.getCourseRule( Constants.HomePage.RULE_FOR_CUSTOM_READING, Constants.HomePage.FOCUS_MATH_COURSE ).equals( Constants.HomePage.RULE_FOR_CUSTOM_READING ), "Rule for custom Reading is displaying",
                    "Rule for custom reading is not displaying" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the screen elements for course section present in home page for teacher user", groups = { "SMK-40738", "HomePage", "HomePage Course" }, priority = 7 )
    public void tc_SMCourseRule004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseRule004:Verify the screen elements for course section present in home page for teacher user and Verify whether 4 maximum course coun,assign button<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            Log.assertThat( tHomePage.isCoursesWidgetDisplayed(), "Courses widget is displayed in HomePage", "Courses widget is not displayed in HomePage" );
            List<String> courseName = tHomePage.getCourseTitleFromCoursesWidget();

            Log.assertThat( courseName.get( 0 ).contains( Constants.HomePage.MATH_COURSE ), "Math Title is displaying in course widget", "Math Title is not displaying in course widget" );

            Log.assertThat( courseName.get( 1 ).contains( Constants.HomePage.READING_COURSE ), "Reading Title is displaying in course widget", "Math Title is not displaying in course widget" );

            Log.assertThat( tHomePage.isViewAllLinkDisplayed(), "View All Link Diaplyed", "View all link has not diaplyed" );

            Log.assertThat( tHomePage.getCourseTypesFromCoursesWidget().contains( Constants.HomePage.COURSE_WIDGET ), "Type-Courses widget is displayed in HomePage", "Type-Courses widget is not displayed in HomePage" );

            if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ), "Edited or Created date is diaplayed", "Edited or created is not displayed" );

            } else {
                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ), "Assigned date is displayed", "Assigned date is not displayed" );
            }
            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify whether 4 maximum course count are displayed in courses section for teacher user when there are more than 4 coureses associated with it ", groups = { "SMK-40738", "HomePage", "HomePage Course" }, priority = 5 )
    public void tc_SMCourseRule005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseRule005:Verify whether 4 maximum course count are displayed in courses section for teacher user when there are more than 4 coureses associated with it<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            Log.assertThat( tHomePage.getCourseTitleFromCoursesWidget().size() == 4, "Title-Courses widget is displayed in HomePage with maximum 4 count", "Title-Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.getCourseTypesFromCoursesWidget().size() == 4, "Type-Courses widget is displayed in HomePage with maximum 4 count", "Type-Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.getAssignBtnFromCoursesWidget().size() == 4, "Assign Btn-Courses widget is displayed in HomePage with maximum 4 count", "Assign Btn-Courses widget is not displayed in HomePage" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = " Verify the Course Details page display for teacher user when teacher clicked on any of the course in Home page", groups = { "SMK-40738", "HomePage", "HomePage Course" }, priority = 6 )
    public void tc_SMCourseRule006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseRule006:Verify the Course Details page display for teacher user when teacher clicked on any of the course in Home page <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );
            tHomePage.clickAssignButton();
            Log.assertThat( tHomePage.isDialougeHeaderDisplayed(), "Assign window pop up Page is displaying", "Assign window pop up Page is displaying" );

            tHomePage.topNavBar.navigateToHomeTab();

            tHomePage.clickCourse();

            //Validate course details
            Log.assertThat( tHomePage.isCourseDisplayed(), "Course details Page is displaying", "Course details  Page is displaying" );

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the recently assigned courses in Courses section when teacher assigned the respective course to the student", groups = { "SMK-40738", "HomePage", "HomePage Course" }, priority = 4 )
    public void tc_SMCourseRule007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseRule007:Verify the recently assigned courses in Courses section when teacher assigned the respective course to the student <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );
            studentListFromTheAssignmentPopup = new ArrayList<>();
            studentList = new ArrayList<>();
            CoursesPage customCourses = new CoursesPage( driver );
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            //Create student
            studentsPage.createStudent();

            //Navigate to home page
            tHomePage.topNavBar.navigateToHomeTab();

            tHomePage.clickAssignButton();
            tHomePage.clickAssignBtnMSDAPopup();
            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            Log.assertThat( tHomePage.getCourseTitleFromCoursesWidget().contains( Constants.HomePage.MATH_COURSE ), "Recently assigned Title-Courses widget is displayed in HomePage ", "Recently assigned Title-Courses widget is not displayed in HomePage" );

            tHomePage.topNavBar.navigateToHomeTab();

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Last Edited date display for My Custom courses in Courses section when the respective course is not edited by teacher user", groups = { "SMK-40738", "HomePage", "HomePage Course" }, priority = 8 )
    public void tc_SMCourseRule008() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseRule008:Verify the Last Edited date display for My Custom courses in Courses section when the respective course is not edited by teacher user<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );
            studentListFromTheAssignmentPopup = new ArrayList<>();
            CoursesPage customCourses = new CoursesPage( driver );
            String staticCourseName = customCourses.generateRandomCourseName();
            String newCourseName = customCourses.generateRandomCourseName();
            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfMathCourse( staticCourseName, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            tHomePage.topNavBar.navigateToHomeTab();
            if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.CREATED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.CREATED_DATE ), "Edited or Created date is diaplayed", "Edited or created is not displayed" );

            } else if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ), "Assigned date is displayed", "Assigned date is not displayed" );
            }

            tHomePage.topNavBar.getCourseListingPage();

            //Click on the course
            customCourses.clickCourseFromTheListing( staticCourseName );

            //Edit the course settings
            customCourses.clickEditBtnCourseLevel();

            //Verify edit button
            customCourses.verifyEditAndRemoveBtnPresent();
            //Enter name again
            customCourses.enterCourseName( newCourseName );

            customCourses.clickNextBtn();

            ///Click Next from Setting page
            customCourses.clickNextBtn();

            //Click Save button
            customCourses.clickSaveBtnForEdit();

            tHomePage.topNavBar.navigateToHomeTab();
            if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.LAST_EDIATED_DATE ), "Edited or Created date is diaplayed", "Edited or created is not displayed" );

            } else if ( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ) ) {

                Log.assertThat( tHomePage.isUpdatedDateDisplayed( Constants.HomePage.ASSIGNED_DATE ), "Assigned date is displayed", "Assigned date is not displayed" );
            }

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Last Edited date display for shared in Courses section when the respective course is not edited by teacher user", groups = { "SMK-40738", "HomePage", "HomePage Course" }, priority = 9 )
    public void tc_SMCourseRule009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMCourseRule009:Verify the Last Edited date display for shared courses in Courses section when the respective course is not edited by teacher user <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );
            studentListFromTheAssignmentPopup = new ArrayList<>();
            studentList = new ArrayList<>();
            CoursesPage customCourses = new CoursesPage( driver );
            String staticCourseName = customCourses.generateRandomCourseName();
            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.copyOfMathCourse( staticCourseName, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();
            tHomePage.topNavBar.navigateToHomeTab();
            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            smLoginPage.enterCredentialsAndLogIn( usernameTeacher, password );

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickFromCourseListingPage( staticCourseName );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            tHomePage.topNavBar.navigateToHomeTab();

            if ( tHomePage.getCourseTypesFromCoursesWidget().contains( Constants.HomePage.COURSE_WIDGET_SHARED ) ) {

                Log.assertThat( tHomePage.getCourseTypesFromCoursesWidget().contains( Constants.HomePage.COURSE_WIDGET_SHARED ), "Shared course is displaying", "Shared course is not displaying" );

            } else if ( tHomePage.getCourseTypesFromCoursesWidget().contains( Constants.HomePage.COURSE_WIDGET_CUSTOM ) ) {

                Log.assertThat( tHomePage.getCourseTypesFromCoursesWidget().contains( Constants.HomePage.COURSE_WIDGET_CUSTOM ), "custome course is displaying", "custom widget course is not displaying" );
            }

            // Sign Out
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
