package com.savvas.sm.api.tests.smnew.students;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.CreateStudentAPIConstants.grade;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.student.api.licenses.LicenseConstants;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.response.Response;

public class UpdateSixToEightReadingTheme extends EnvProperties {
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String teacherUsername;
    private String teacherAccessToken;
    private String readingAssignmentId;
    private String readingAssignmentUserId1;
    private String readingAssignmentUserId2;
    private String readingAssignmentUserId3;
    private String studentUserName1;
    private String studentUserName2;
    private String studentUserName3;
    private String student1AccessToken;
    private String student2AccessToken;
    private String student3AccessToken;
    private String contectType;

    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private static HashMap<String, String> readingAssignmentDetails = new HashMap<>();
    HashMap<String, String> userDetails = null;

    private Map<String, String> response = new HashMap<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    AssignmentAPI assign = new AssignmentAPI();
    UserAPI userAPI = new UserAPI();

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        // Getting teacher details
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, password );
        Log.message( "Teacher access token: " + teacherAccessToken );

        String studentDetail1 = RBSDataSetup.getMyStudent( school, teacherUsername );
        String studentDetail2 = RBSDataSetup.getMyStudent( school, teacherUsername );
        String studentDetail3 = RBSDataSetup.getMyStudent( school, teacherUsername );

        // getting student details
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetail1, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetail2, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetail3, "userId" ) );

        studentUserName1 = SMUtils.getKeyValueFromResponse( studentDetail1, "userName" );
        studentUserName2 = SMUtils.getKeyValueFromResponse( studentDetail2, "userName" );
        studentUserName3 = SMUtils.getKeyValueFromResponse( studentDetail3, "userName" );

        //Updating grade6 for student1
        String firstName = new Faker().name().firstName();
        String lastName = new Faker().name().lastName();
        HashMap<String, String> studentInfo = new HashMap<>();
        studentInfo = generateRequestValues( new RBSUtils().getUser( studentRumbaIds.get( 0 ) ), studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ), grade.SIXTH.toString() );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        // Updating student grade
        String studentResponce = userAPI.updateStudentProfile( smUrl, studentInfo ).get( Constants.STATUS_CODE );
        Log.message( studentResponce );

        //Updating grade6 for student1
        firstName = new Faker().name().firstName();
        lastName = new Faker().name().lastName();
        HashMap<String, String> studentInfo1 = new HashMap<>();
        studentInfo1 = generateRequestValues( new RBSUtils().getUser( studentRumbaIds.get( 1 ) ), studentInfo1, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ), grade.SEVENTH.toString() );
        studentInfo1 = SMUtils.updateRequestBodyValues( studentInfo1, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
        studentInfo1 = SMUtils.updateRequestBodyValues( studentInfo1, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        studentInfo1 = SMUtils.updateRequestBodyValues( studentInfo1, RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        // Updating student first and last name
        String student1Responce = userAPI.updateStudentProfile( smUrl, studentInfo1 ).get( Constants.STATUS_CODE );
        Log.message( student1Responce );

        //Updating grade6 for student1
        firstName = new Faker().name().firstName();
        lastName = new Faker().name().lastName();
        HashMap<String, String> studentInfo2 = new HashMap<>();
        studentInfo2 = generateRequestValues( new RBSUtils().getUser( studentRumbaIds.get( 2 ) ), studentInfo2, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ), grade.EIGHT.toString() );
        studentInfo2 = SMUtils.updateRequestBodyValues( studentInfo2, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
        studentInfo2 = SMUtils.updateRequestBodyValues( studentInfo2, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        studentInfo2 = SMUtils.updateRequestBodyValues( studentInfo2, RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        // Updating student first and last name
        String student2Responce = userAPI.updateStudentProfile( smUrl, studentInfo2 ).get( Constants.STATUS_CODE );
        Log.message( student2Responce );

        // Getting group details
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" + System.nanoTime() );
        // Creating a group
        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        // Assigning Reading assignment
        readingAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        readingAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        readingAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
        readingAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
        HashMap<String, String> readingAssignmentResponse = assign.assignMultipleAssignments( smUrl, readingAssignmentDetails, studentRumbaIds, Arrays.asList( "2" ) );

        // Getting assignment id
        JSONObject readingAssignmentDetailsJson = new JSONObject( readingAssignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray readingAssignmentList = readingAssignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject readingAssignmentInfo = new JSONObject( readingAssignmentList.get( 0 ).toString() );
        readingAssignmentId = readingAssignmentInfo.get( "assignmentId" ).toString();
        readingAssignmentUserId1 = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), readingAssignmentId );
        readingAssignmentUserId2 = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 1 ), readingAssignmentId );
        readingAssignmentUserId3 = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 2 ), readingAssignmentId );

        student1AccessToken = new RBSUtils().getAccessToken( studentUserName1, password );
        student2AccessToken = new RBSUtils().getAccessToken( studentUserName2, password );
        student3AccessToken = new RBSUtils().getAccessToken( studentUserName3, password );

    }

    @Test ( dataProvider = "getDataforPostive", priority = 1, groups = { "SMK-66853", "Reading theme", "Update six to eight reading theme", "API", "smoke_test_case" } )
    public void updateSix_EightReadingTheme( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseID + " - " + testDescription );
        Map<String, String> headers = new HashMap<>();
        Map<String, String> params = new HashMap<>();
        String endPoint = LicenseConstants.SIX_TO_EIGHT_READING_THEAME;
        HashMap<String, String> getResponse = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( UserConstants.USERID, studentRumbaIds.get( 0 ) );
        headers.put( UserConstants.ORGID, orgId );
        headers.put( Constants.AUTHORIZATION, "Bearer " + student1AccessToken );
        headers.put( "session-id", getSessionID( studentRumbaIds.get( 0 ), student1AccessToken, readingAssignmentUserId1 ) );
        endPoint = endPoint.replace( Constants.ASSIGNMENT_USER_ID_VALUE, readingAssignmentUserId1 );
        endPoint = endPoint.replace( LicenseConstants.BACKGROUNDID_VALUE, "42" );
        endPoint = endPoint.replace( LicenseConstants.HUE_VALUE, "0" );
        endPoint = endPoint.replace( LicenseConstants.SATURATION_VALUE, "0" );

        switch ( scenario ) {

            case "VAILD_DATA":
                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                headers.put( Constants.AUTHORIZATION, "Bearer " + student2AccessToken );
                headers.put( UserConstants.USERID, studentRumbaIds.get( 1 ) );
                headers.put( "session-id", getSessionID( studentRumbaIds.get( 1 ), student2AccessToken, readingAssignmentUserId2 ) );

                endPoint = endPoint.replace( readingAssignmentUserId1, readingAssignmentUserId2 );

                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                headers.put( Constants.AUTHORIZATION, "Bearer " + student3AccessToken );
                headers.put( UserConstants.USERID, studentRumbaIds.get( 2 ) );
                headers.put( "session-id", getSessionID( studentRumbaIds.get( 2 ), student3AccessToken, readingAssignmentUserId3 ) );

                endPoint = endPoint.replace( readingAssignmentUserId2, readingAssignmentUserId3 );

                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                break;

            case "OTHER_VAILD_BACKGROUNDID":

                endPoint = endPoint.replace( LicenseConstants.BACKGROUNDID_VALUE, "11111142" );
                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                headers.put( Constants.AUTHORIZATION, "Bearer " + student2AccessToken );
                headers.put( UserConstants.USERID, studentRumbaIds.get( 1 ) );
                headers.put( "session-id", getSessionID( studentRumbaIds.get( 1 ), student2AccessToken, readingAssignmentUserId2 ) );

                endPoint = endPoint.replace( readingAssignmentUserId1, readingAssignmentUserId2 );

                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                headers.put( Constants.AUTHORIZATION, "Bearer " + student3AccessToken );
                headers.put( UserConstants.USERID, studentRumbaIds.get( 2 ) );
                headers.put( "session-id", getSessionID( studentRumbaIds.get( 2 ), student3AccessToken, readingAssignmentUserId3 ) );

                endPoint = endPoint.replace( readingAssignmentUserId2, readingAssignmentUserId3 );

                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "OTHER_VAILD_HUE":

                endPoint = endPoint.replace( LicenseConstants.HUE_VALUE, "0123456789" );
                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                headers.put( Constants.AUTHORIZATION, "Bearer " + student2AccessToken );
                headers.put( UserConstants.USERID, studentRumbaIds.get( 1 ) );
                headers.put( "session-id", getSessionID( studentRumbaIds.get( 1 ), student2AccessToken, readingAssignmentUserId2 ) );

                endPoint = endPoint.replace( readingAssignmentUserId1, readingAssignmentUserId2 );

                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                headers.put( Constants.AUTHORIZATION, "Bearer " + student3AccessToken );
                headers.put( UserConstants.USERID, studentRumbaIds.get( 2 ) );
                headers.put( "session-id", getSessionID( studentRumbaIds.get( 2 ), student3AccessToken, readingAssignmentUserId3 ) );

                endPoint = endPoint.replace( readingAssignmentUserId2, readingAssignmentUserId3 );

                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "OTHER_VAILD_SATURATION":

                endPoint = endPoint.replace( LicenseConstants.SATURATION_VALUE, "0123456789" );
                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                headers.put( Constants.AUTHORIZATION, "Bearer " + student2AccessToken );
                headers.put( UserConstants.USERID, studentRumbaIds.get( 1 ) );
                headers.put( "session-id", getSessionID( studentRumbaIds.get( 1 ), student2AccessToken, readingAssignmentUserId2 ) );

                endPoint = endPoint.replace( readingAssignmentUserId1, readingAssignmentUserId2 );

                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                headers.put( Constants.AUTHORIZATION, "Bearer " + student3AccessToken );
                headers.put( UserConstants.USERID, studentRumbaIds.get( 2 ) );
                headers.put( "session-id", getSessionID( studentRumbaIds.get( 2 ), student3AccessToken, readingAssignmentUserId3 ) );

                endPoint = endPoint.replace( readingAssignmentUserId2, readingAssignmentUserId3 );

                getResponse = RestHttpClientUtil.PUT( smUrl, headers, params, endPoint, contectType );
                Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!",
                        "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                break;

        }

        Log.assertThat( getResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

    }

    @DataProvider ( name = "getDataforPostive" )
    public Object[][] getDataforPostive() {

        Object[][] data = { { "tcUpdateSixEightReadingTheme001", "Verify the status code as 200 for valid data when upding the SixEightReading Theme for students", "200", "VAILD_DATA" },
                { "tcUpdateSixEightReadingTheme002", "Verify the status code as 200 when changing the backgroundId value for upding the SixEightReading Theme for students", "200", "OTHER_VAILD_BACKGROUNDID" },
                { "tcUpdateSixEightReadingTheme003", "Verify the status code as 200 when changing the hue value for upding the SixEightReading Theme for students", "200", "OTHER_VAILD_HUE" },
                { "tcUpdateSixEightReadingTheme004", "Verify the status code as 200 when changing the saturation value for upding the SixEightReading Theme for students", "200", "OTHER_VAILD_SATURATION" }, };
        return data;

    }

    /**
     * Generating request values
     * 
     * @param studentExistingData
     * @param newDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value, String grade ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

    public String getSessionID( String studentUserId, String studentAccessToken, String studentAssignmentUserId ) {
        String endPoint1 = LicenseAPIConstants.GET_STUDENT_ASSIGNMENT_LICENSE_USAGE;
        List<String> pathParamsList = new ArrayList<String>();
        HashMap<String, String> header = new HashMap<String, String>();
        header.put( LicenseAPIConstants.ORGID, orgId );
        header.put( LicenseAPIConstants.USERID, studentUserId );
        header.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + studentAccessToken );
        pathParamsList.add( studentAssignmentUserId );
        HashMap<String, String> pathParams = SMUtils.setPathParametersFromEndpoint( endPoint1, pathParamsList );
        Response response = RestAssuredAPIUtil.GET( smUrl, header, endPoint1, pathParams );
        String sessionId = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data,sessionId" );

        return sessionId;
    }

}
