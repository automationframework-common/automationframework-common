package com.savvas.sm.teacher.ui.tests.SmokeSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.GroupUIConstants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class StudentsTabSmokeTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherID;
    List<String> expectedCourseTypesInDropdown = Arrays.asList( "Focus Courses", "Default Courses", "Custom Courses", "All Courses" );
    private String studentDetails;
    String studentDetailsSecond;
    String teacherDetails;
    CourseAPI courseAPI = new CourseAPI();
    AssignmentAPI assignmentAPI = new AssignmentAPI();

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "Verify Student Tab", priority = 1 )
    public void tcSMBVT005( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

        Log.testCaseInfo( "tcSMBVT005: Verify Student Tab <small><b><i>[" + browser + "]</b></i></small>" );

        String studentDetails = RBSDataSetup.teacherStudentMap.get( username ).get( "Student1" );
        System.out.println( "studentDetails: " + studentDetails );
        String stuUserName = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );
        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        System.out.println( "teacherDetails : " + teacherDetails );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            Log.assertThat( studentsPage.addStudentElement().isDisplayed(), "Add student button is displayed", "Add student button is not displayed" );

            Log.assertThat( !studentsPage.groupAssignmentIsEnable(), "Group & Assignment button is disabled", "Group & Assignment button is Enabled" );
            SMUtils.nap( 5 );
            studentsPage.selectStudentByUsername( stuUserName );
            SMUtils.nap( 5 );
            Log.assertThat( studentsPage.groupAssignmentIsEnable(), "Group & Assignment button is enabled", "Group & Assignment button is disabled" );
            
            

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student Creation", priority = 1 )
    public void tcSMBVT006( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data
    	String studentDetails = RBSDataSetup.getMyStudent( school, username );
    	System.out.println( studentDetails );
    	Log.testCaseInfo( "tcSMBVT006: Verify Student Creation <small><b><i>[" + browser + "]</b></i></small>" );

    	try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            String studentID = studentsPage.createStudent();
            System.out.println( "New Student Details : " + studentID );

            SMUtils.nap( 10 );
            // Navigate to Groups Tab
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            String groupName = GroupUIConstants.SIMPLE_GROUP_NAME + System.nanoTime();
            String stuUserName = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );
            groupsPage.createGroupWithoutStudent( groupName );
            SMUtils.nap( 5 );
            groupsPage.clickGetViewGroupBtn( groupName );
            SMUtils.nap( 5 );
            // Click add student to group button
            groupsPage.clickAddStudentToGrpBtnGrpPage();
            groupsPage.addNameInTextField( stuUserName );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickAddButton();
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickSaveBtnAddStudToGrpPopUp();
            SMUtils.nap( 10 );
            tHomePage.topNavBar.navigateToStudentsTab();
            Log.assertThat( studentsPage.isStrudentPresent( stuUserName ), stuUserName + " present in the Students lsiting page", stuUserName + " not present in the students listing page" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify add student to Group", priority = 1 )
    public void tcSMBVT007( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        // Get Test Data
        String groupName = "SmokeGroup" + System.nanoTime();

        Log.testCaseInfo( "tcSMBVT007: Verify add student to Group <small><b><i>[" + browser + "]</b></i></small>" );

        // Create Group
        List<String> studentRumbaIds = new ArrayList<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        String studentDetails = RBSDataSetup.getMyStudent( school, username );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );
        groupDetails.put( CreateGroupAPIConstants.GROUP_ID, groupId );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            context.setAttribute( "groupName", groupName );
            String studentID = "";

            String student2 = RBSDataSetup.teacherStudentMap.get( username ).get( "Student2" );
            studentID = SMUtils.getKeyValueFromResponse( student2, "userId" );

            String firstName = SMUtils.getKeyValueFromResponse( student2, "firstName" );
            String lastName = SMUtils.getKeyValueFromResponse( student2, "lastName" );
            String UserName = SMUtils.getKeyValueFromResponse( student2, "userName" );
            studentsPage.selectStudentByUsername( UserName );
            context.setAttribute( "studentIDtoGroup", studentID );
            context.setAttribute( "firstName", firstName );

            SMUtils.nap( 5 );
            studentsPage.addStudentstoGroup( groupName );
            SMUtils.nap( 5 );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.clickGetViewGroupBtn( groupName );

            HashMap<String, HashMap<String, String>> studentDetailsFromGroup = groupsTab.getStudentDetailsBasedOnGroup( groupName );
            String Student_Details = studentDetailsFromGroup.toString();

            Log.assertThat( Student_Details.contains( UserName ), "UserName : " + UserName + "is mapped to the group " + groupName, "UserName : " + UserName + "is not mapped to the group " + groupName );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify add student to Assignment", priority = 1 )
    public void tcSMBVT008( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	// Get Test Data
    	String courseName = "SmokeCourse" + System.nanoTime();

    	Log.testCaseInfo( "tcSMBVT008: Verify add student to Assignment <small><b><i>[" + browser + "]</b></i></small>" );

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        String teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        String organizationId = RBSDataSetup.organizationIDs.get( school );
        List<String> requestIds = new ArrayList<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, organizationId );

        // Create Course
        List<String> CourseIds = new ArrayList<>();

        CourseIds.add( courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), organizationId.toString(), DataSetupConstants.SETTINGS, courseName ) );

        List<String> studentList = new ArrayList<>();
        List<String> studentIDList = new ArrayList<>();

        String student1 = RBSDataSetup.getMyStudent( school, username );
        String student2 = RBSDataSetup.getMyStudent( school, username );
        studentIDList.add( SMUtils.getKeyValueFromResponse( student1, "userId" ) );
        studentIDList.add( SMUtils.getKeyValueFromResponse( student2, "userId" ) );
        String stuUserName1 = SMUtils.getKeyValueFromResponse( student1, "userName" );
        String stuUserName2 = SMUtils.getKeyValueFromResponse( student2, "userName" );

        studentList.add( stuUserName1 );
        studentList.add( stuUserName2 );

        CourseIds.forEach( courseID -> {
            HashMap<String, String> response = new HashMap<>();
            try {
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseID );
                requestIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), "userId" ) );
                requestIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), "userId" ) );

                response = assignmentAPI.assignAssignment( smUrl, assignmentDetails, requestIds, AssignmentAPIConstants.USERS_TYPE );
            } catch ( Exception e ) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            System.out.println( "Response : " + response );
        } );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            SMUtils.nap( 5 );

            for ( String element : studentList ) {
                studentsPage.selectStudentByUsername( element );
            }

            studentsPage.addStudentstoAssignment( courseName );

            // validation

            for ( int i = 0; i < studentIDList.size(); i++ ) {
                String responseBody = assignmentAPI.getAssignmentByStudent( smUrl, token, studentIDList.get( i ), organizationId, teacherID );
                System.out.println( "responseBody: " + responseBody );
                Log.assertThat( responseBody.contains( courseName ), "Studend ID: " + studentIDList.get( i ) + "is mapped to the Assignment " + courseName, "Studend ID: " + studentList.get( i ) + "is not mapped to the Assignment " + courseName );
            }
            Log.testCaseResult();
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "View Student Details", priority = 1 )
    public void tcSMBVT009( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	// Get Test Data

    	Log.testCaseInfo( "tcSMBVT009: View Student Details <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            String groupNamea = "Successmaker Group 1";

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            //            studentDetails = RBSDataSetup.teacherStudentMap.get( username ).get( "Student1" );
            studentDetails = RBSDataSetup.getMyStudent( school, username );
            String stuUserName = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );
            studentsPage.clickviewStudentByEllipsis( stuUserName );
            String stuFName = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" );
            System.out.println( studentsPage.getHeaderNameStudent() );
            Log.softAssertThat( studentsPage.getHeaderNameStudent().equals( stuFName ), stuFName + " is Present in the header", stuFName + " is not present in the header" );

            studentsPage.clickSubNavigation( "User Profile" );

            String editedName = stuFName + "Edited";
            studentsPage.changeFirstName( editedName );

            studentsPage.clickSubNavigation( "Groups" );

            Log.softAssertThat( studentsPage.isGroupnamePresent( groupNamea ), "Group name " + groupNamea + " Matched", "Group name " + groupNamea + " is not present in the page" );

            studentsPage.clickSubNavigation( "User Profile" );

            Log.assertThat( studentsPage.getFirstName().equals( editedName ), "First Name updated", "First name not updated properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify other ellipsis menu options", priority = 1 )
    public void tcSMBVT010( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data
    	Log.testCaseInfo( "tcSMBVT010: Verify other ellipsis menu options <small><b><i>[" + browser + "]</b></i></small>" );

    	String studentDetails = RBSDataSetup.getMyStudent( school, username );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            String stuUserName = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );
            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            studentsPage.clickAddStudentToGroupByEllipsis( stuUserName );

            studentsPage.closePopup();

            studentsPage.clickAddStudentToAssignmentByEllipsis( stuUserName );

            studentsPage.closePopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
