package com.savvas.sm.teacher.ui.pages;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.github.javafaker.Faker;
import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Students;
import com.savvas.sm.common.utils.Constants.UserUIConstants;
import com.savvas.sm.data.sme7.TestDataConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class StudentsPage extends LoadableComponent<StudentsPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    private WebDriver driver;
    boolean isPageLoaded;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    public TopNavBar topNavBar;

    // ********* SuccessMaker Students Page Elements ***************

    @IFindBy ( how = How.CSS, using = "div .main-container-header cel-button", AI = false )
    public WebElement btnAddStudentRoot;

    @IFindBy ( how = How.CSS, using = "div .main-container-body .group-button", AI = false )
    public WebElement btnGroupRoot;

    @IFindBy ( how = How.CSS, using = "div .main-container-body .assignment-button", AI = false )
    public WebElement btnAssignmentRoot;

    @IFindBy ( how = How.CSS, using = "table.table th.th-check cel-checkbox", AI = false )
    public WebElement chkboxSelectAllStudentsRoot;

    @IFindBy ( how = How.CSS, using = "create-student-popup div .create-student-body", AI = false )
    public WebElement formCreateStudentPopup;

    @IFindBy ( how = How.ID, using = "firstName", AI = false )
    public WebElement txtboxFirstName;

    @IFindBy ( how = How.ID, using = "middleName", AI = false )
    public WebElement txtboxMiddleName;

    @IFindBy ( how = How.ID, using = "lastName", AI = false )
    public WebElement txtboxLastName;

    @IFindBy ( how = How.ID, using = "birthday", AI = false )
    public WebElement txtboxDatOfBirth;

    @IFindBy ( how = How.ID, using = "studentIdentificationNumber", AI = false )
    public WebElement txtboxStudentID;

    @IFindBy ( how = How.ID, using = "userName", AI = false )
    public WebElement txtboxUserName;

    @IFindBy ( how = How.ID, using = "userPassword", AI = false )
    public WebElement txtboxPassWord;

    @IFindBy ( how = How.ID, using = "confirmPassword", AI = false )
    public WebElement txtboxConfirmPassword;

    //@IFindBy(how = How.CSS, using="label[for='userPassword']+input+span" , AI =false)
    @IFindBy ( how = How.CSS, using = "Change Password", AI = false )
    public WebElement changePasssword;

    @IFindBy ( how = How.CSS, using = "cel-dropdown-select#grade>div>button", AI = false )
    public WebElement ddGradeSelection;

    @IFindBy ( how = How.CSS, using = "#grade > div > button", AI = false )
    public WebElement ddGradeSelectionUpdateStudent;

    @IFindBy ( how = How.CSS, using = "#grade span.dropdown-select-label", AI = false )
    public WebElement gradeValue;

    @FindBy ( css = "a.dropdown-option-link" )
    List<WebElement> listofGrades;

    @IFindBy ( how = How.CSS, using = "#ethnicity > div > button", AI = false )
    public WebElement ddEthnicitySelectionUpdateStudent;

    @IFindBy ( how = How.CSS, using = "#race > div > button", AI = false )
    public WebElement ddRaceSelectionUpdateStudent;

    @IFindBy ( how = How.CSS, using = "#specialServices > div > button", AI = false )
    public WebElement ddSpecialServicesnUpdateStudent;

    @IFindBy ( how = How.CSS, using = "#disabilityStatus > div > button", AI = false )
    public WebElement dddisabilityStatusUpdateStudent;

    @IFindBy ( how = How.CSS, using = "#gender > div > button", AI = false )
    public WebElement ddGenderUpdateStudent;

    @IFindBy ( how = How.CSS, using = "#economicStatus > div > button", AI = false )
    public WebElement ddEconomicStatusUpdateStudent;

    @IFindBy ( how = How.CSS, using = "#hasEnglishProficiency > div > button", AI = false )
    public WebElement ddEnglishUpdateStudent;

    @IFindBy ( how = How.CSS, using = "#migrantStatus > div > button", AI = false )
    public WebElement ddMigrantUpdateStudent;

    @FindBy ( css = "a.dropdown-option-link span" )
    List<WebElement> listofDropdownValues;

    @IFindBy ( how = How.CSS, using = "div.create-student-footer>cel-button:nth-of-type(2)", AI = false )
    public WebElement btnCreateStudent;

    @IFindBy ( how = How.CSS, using = "div.main-container-body table", AI = false )
    public WebElement tableStudentList;

    @IFindBy ( how = How.CSS, using = "div.create-student-footer>cel-button:nth-of-type(1)", AI = false )
    public WebElement btnCancelStudentCreation;

    @FindBy ( css = "table.table td:nth-of-type(5)" )
    List<WebElement> listStudentID;

    @FindBy ( css = "table.table td:nth-of-type(4)" )
    List<WebElement> listStudentUsernames;

    @FindBy ( css = "table.table tr" )
    List<WebElement> listStudentDetails;

    @IFindBy ( how = How.CSS, using = "div.create-group-container", AI = false )
    public WebElement formGroupPopup;

    @IFindBy ( how = How.CSS, using = "div[class='form-group col-md-4 d-flex align-center show-demographics'] span", AI = false )
    public WebElement showMoreDemographics;

    @IFindBy ( how = How.CSS, using = "div.demographics span.show-hide-demographics", AI = false )
    public WebElement hideMoreDemographics;

    @FindBy ( css = "label.text-label" )
    List<WebElement> textFieldNames;

    @IFindBy ( how = How.CSS, using = "input[placeholder='Enter Name of Group(s)']", AI = false )
    public WebElement txtboxGroupfilter;

    @IFindBy ( how = How.CSS, using = "div.add-button", AI = false )
    public WebElement btnAddGroup;

    @IFindBy ( how = How.CSS, using = "div.add-students-footer>cel-button:nth-of-type(2)", AI = false )
    public WebElement btnSaveGroup;

    @IFindBy ( how = How.CSS, using = "cel-icon#dialogHeaderClose", AI = false )
    public WebElement btnClosePopupRoot;

    @IFindBy ( how = How.CSS, using = "div.dialog-wrapper", AI = false )
    public WebElement formAssignmentPopup;

    @FindBy ( css = "div.assignment-name-detail" )
    List<WebElement> assignmentLists;

    @IFindBy ( how = How.CSS, using = "add-student-to-assignment div >cel-button:nth-of-type(2)", AI = false )
    public WebElement btnAddtoAssignment;

    @IFindBy ( how = How.CSS, using = "#studentIdentificationNumber", AI = false )
    public WebElement userProfileStudentId;

    // Limit 100  Student to Group pop up
    @IFindBy ( how = How.CSS, using = "cel-dialog-header h1", AI = false )
    public WebElement headerForStudentLimit;

    @IFindBy ( how = How.CSS, using = "div.dialog-wrapper__content span", AI = false )
    public WebElement MessageForStudentLimit;

    @IFindBy ( how = How.CSS, using = "cel-button.dialog-button", AI = false )
    public WebElement okButtonRoot;

    @IFindBy ( how = How.CSS, using = "div.toast-wrapper-content span", AI = false )
    public WebElement ToastElement;

    @IFindBy ( how = How.CSS, using = "cel-button.dialog-button", AI = false )
    public WebElement dialoguePopUpAfterStudentCreationRoot;

    public static String STUDENTS_ADDED_TO_GROUP_SUCCESSFULLY = "Students Added to Group Successfully";
    public static String STUDENTS_REMOVED_FROM_GROUP_SUCCESSFULLY = "Success! Your student has been removed from the group.";

    public static String TOO_MANY_STUDENTS_SELECTED = "Too many students selected";
    public static String PLEAE_LIMIT_NUMBER_OF_STUDENT_TO_100_OR_LESS_MESSAGE = "Please limit the number of students in your group to 100 or less.";
    public static String ZERO_STATE_MESSAGE = "h3.header";
    // View Student Section

    @IFindBy ( how = How.CSS, using = "div.header span", AI = false )
    public WebElement headerText;

    public @FindBy ( css = "span.side-nav-item" ) List<WebElement> listSideNvaBar;

    @FindBy ( css = "table.table td:nth-of-type(1)" )
    List<WebElement> lblGroupName;

    @IFindBy ( how = How.CSS, using = "app-create-student div.create-student-footer cel-button:nth-of-type(1)", AI = false )
    public WebElement btnSaveStudentDetailsRoot;

    @IFindBy ( how = How.CSS, using = "thead tr th:nth-of-type(5) span.d-flex span", AI = false )
    public WebElement sortbyStudentID;

    @IFindBy ( how = How.CSS, using = "div.table-container thead tr th:nth-of-type(4) span span[class='sort-icon']", AI = false )
    public WebElement sortbyStudentUserName;

    @IFindBy ( how = How.CSS, using = "grid-table div table tbody", AI = false )
    public WebElement studentListTable;

    @IFindBy ( how = How.CSS, using = "div.analytics-container:nth-child(3) div.zero-state-content h3", AI = false )
    public WebElement noDataForStudentProgress;

    @IFindBy ( how = How.CSS, using = "div.view-link a", AI = false )
    public WebElement viewDetailsLink;

    @IFindBy ( how = How.CSS, using = "div .skills-tested-graph-filter div>span", AI = false )
    public WebElement skillTestedTextInAssignmentDetailsPage;

    @IFindBy ( how = How.CSS, using = "div .skilled-header", AI = false )
    public WebElement skillTestedAlternate;

    @IFindBy ( how = How.CSS, using = "div.progress-chart .dropdown-select-value >span", AI = false )
    public WebElement progressDropDownDefaultSubject;

    @FindBy ( css = "g.highcharts-yaxis-labels > text" )
    List<WebElement> studentProgressBarYAxisValues;

    @IFindBy ( how = How.CSS, using = "div.progress-chart cel-dropdown-select button", AI = false )
    public WebElement studentGraphDropDownButton;

    @FindBy ( css = "div.progress-chart cel-dropdown-select ul li span" )
    List<WebElement> studentGraphDropDownValues;

    @FindBy ( css = "div.progress-chart div.d-flex>div p.text-grey" )
    List<WebElement> leftSideFields;

    @IFindBy ( how = How.CSS, using = "div.progress-chart div.d-flex>div p.text-grey+p", AI = false )
    public WebElement leftSideFieldValues;

    @IFindBy ( how = How.CSS, using = "g.highcharts-yaxis-labels>text:first-child", AI = false )
    public WebElement firstValueOnYaxisAssignDetailsPage;

    @FindBy ( css = "div.progress-chart div.d-flex>div p.text-grey+p" )
    List<WebElement> valuesOfLeftSideFields;

    @FindBy ( css = "div.progress-chart cel-dropdown-select ul li.dropdown-tooltip" )
    List<WebElement> toolTipValuesInDropDown;

    @IFindBy ( how = How.CSS, using = "cel-dialog-header div div button", AI = false )
    public WebElement btnCreateStudentPopupIicon;

    @FindBy ( css = "span.ml-1" )
    List<WebElement> ErrorMessages;

    @FindBy ( css = "tbody>tr" )
    List<WebElement> stuDetails;

    //Student usage chart   
    @IFindBy ( how = How.CSS, using = "div.analytics-container  graphs-usage-chart", AI = false )
    public WebElement studentUsagechartRoot;

    @FindBy ( css = "div.analytics-container div.student-chart-title" )
    List<WebElement> lblstudentUsagechartForZeroState;

    @FindBy ( css = "graphs-usage-chart p.text-grey" )
    List<WebElement> lblUsageFields;

    @FindBy ( css = "graphs-usage-chart svg.legend-font g" )
    List<WebElement> lblStudentUsageLegends;

    @IFindBy ( how = How.CSS, using = "graphs-usage-chart svg g#yaxis text.axis-label", AI = false )
    public WebElement lblYaxis;

    @FindBy ( css = "graphs-usage-chart g#xaxis g.tick text" )
    List<WebElement> lblXaxisIntervals;

    @FindBy ( css = "graphs-usage-chart g#yaxis g.tick text" )
    List<WebElement> lblYaxisIntervals;

    @FindBy ( css = "graphs-usage-chart app-chart svg  g[fill ='#32325D'] rect" )
    List<WebElement> readingBars;

    @FindBy ( css = "graphs-usage-chart app-chart svg  g[fill ='#9ECA47'] rect" )
    List<WebElement> mathBars;

    @FindBy ( css = "graphs-usage-chart app-chart svg  g[fill]:not([fill='none'])" )
    List<WebElement> mathandReadingBars;

    @IFindBy ( how = How.CSS, using = "graphs-usage-chart app-chart svg  g#recttooltip_charts text", AI = false )
    public WebElement toolTipUsageChart;

    @IFindBy ( how = How.CSS, using = "div.analytics-container div.student-chart-title", AI = false )
    public WebElement studentUsgechartHeader;

    //assignments sub-nav
    @FindBy ( css = "table#report tr.accordion-table-row" )
    List<WebElement> assignmentListRoot;

    @IFindBy ( how = How.CSS, using = "table#report tr.accordion-table-row div.cell-tooltip span.align-right", AI = false )
    public WebElement assignmentNames;

    @IFindBy ( how = How.CSS, using = "div.student-assignment-header h5", AI = false )
    public WebElement assignmentSubNavHeader;

    @IFindBy ( how = How.CSS, using = "div.dialog-header h1", AI = false )
    public WebElement popupHeader;

    @FindBy ( css = "cel-button.hydrated" )
    List<WebElement> PopupButtonsRoot;

    // Remove Student from Group elements

    @IFindBy ( how = How.CSS, using = "cel-button-menu.table-dropdown-menu", AI = false )
    public WebElement removeStuFromGrpGrandRoot;

    @IFindBy ( how = How.CSS, using = "cel-dialog-header h1", AI = false )
    public WebElement removeStuFromGrpTextInPopUp;

    @IFindBy ( how = How.CSS, using = "div create-confirm-popup .subtext", AI = false )
    public WebElement removeStuFromGrpMessagetInPopUp;

    @FindBy ( css = "div.confirm-modal cel-button.hydrated" )
    List<WebElement> removeAndCancelButtonPopup;

    @IFindBy ( how = How.CSS, using = "cel-icon#dialogHeaderClose", AI = false )
    public WebElement closeIconInPopup;

    //zeroState Message1 - 
    @IFindBy ( how = How.CSS, using = "h3.header", AI = false )
    public WebElement NO_DATA_YET;

    //zeroState Message1 - You haven't added any students to a list yet.
    @IFindBy ( how = How.CSS, using = "span.message", AI = false )
    public WebElement zeroStateMessage;

    @IFindBy ( how = How.CSS, using = "tbody tr", AI = false )
    public WebElement studentTable;

    //zeroState Message3 - "Add Student" button
    @IFindBy ( how = How.CSS, using = "button.btn.btn-link.link", AI = false )
    public WebElement btnAddStudent;

    @IFindBy ( how = How.CSS, using = "div .dialog-header h1", AI = false )
    public WebElement addStudentHeader;

    @IFindBy ( how = How.CSS, using = "cel-icon.chevron-left-icon.hydrated", AI = false )
    public WebElement btnBack;
    @IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
    public WebElement popupHeaderTitle;

    @IFindBy ( how = How.CSS, using = "cel-button.main-container-header-button.hydrated", AI = false )
    public WebElement btnAddStudenttoGroups;

    @IFindBy ( how = How.CSS, using = "div.side-nav-wrapper-active span", AI = false )
    public WebElement groupSideNav;

    @IFindBy ( how = How.CSS, using = "div.main-container-header span.main-container-heading-text", AI = false )
    public WebElement groupHeaderContainer;

    @FindBy ( css = "div.list-data div.student-firstName-lastName" )
    List<WebElement> groupNameList;

    @FindBy ( css = "div.container-wrapper div.assignment-name-detail" )
    List<WebElement> assignmentNameList;

    @FindBy ( css = ".side-nav div span.side-nav-item" )
    List<WebElement> sideNavOptions;

    @FindBy ( css = "g.highcharts-xaxis-labels text" )
    List<WebElement> dateValuesXAxis;

    @FindBy ( css = "g.highcharts-yaxis-labels text" )
    List<WebElement> courseValuesYAxis;

    //Add Students to Group Element

    @FindBy ( css = "div.student-name" )
    List<WebElement> groupListInPopup;

    @FindBy ( css = "cel-button-menu.table-dropdown-menu" )
    List<WebElement> ellipsesRoot;

    @IFindBy ( how = How.CSS, using = "div.header span.text-overflow-nowrap", AI = false )
    public WebElement headerTextStudent;
    
    @IFindBy(how = How.CSS, using="cel-button.dialog-button.hydrated" , AI =false)
    public WebElement createStudentPOPupCloseRoot;
    
    String removeStudentFromGroupChilds = "cel-dropdown-menu-box[class='hydrated']";
    String createStudentPOPupCloseChild = "button.primary_button";

    /**
     * To get Ellipses in the Root Element in Student listing page for student
     * username
     * 
     * @param username
     * @return
     */
    public WebElement geEllipsesRootElement( String username ) {
        ArrayList<String> allStudentUserNames = getAllStudentsUserNames();
        int index = allStudentUserNames.indexOf( username );
        return ellipsesRoot.get( index );
    }
    
    /**
     * click Ellipses element by the Student username
     * 
     * @param username
     * @return
     */
    public WebElement clickElipsesByStudent( String username ) {
        WebElement root = geEllipsesRootElement( username );
        WebElement ellipse = SMUtils.getWebElementDirect( driver, root, "cel-icon", "img" );
        SMUtils.scrollIntoView( driver, ellipse );
        SMUtils.click( driver, ellipse );
        Log.message( "Clicked Ellipses for Student: " + username );
        return root;
    }
    
    public void getAllEllipsesNames(String username) {
    	WebElement Ellipsesroot = clickElipsesByStudent( username );
    	WebElement names = SMUtils.getWebElementDirect( driver, Ellipsesroot, "cel-dropdown-menu-box", "a" );
//        for (int i = 0; i < names.size(); i++) {
//			WebElement webElement = names.get(i);
//			webElement.getText().trim();
//			System.out.println(webElement);
    	  names.getText().trim();
    	  System.out.println(names);
//		}
    }

    /**
     * click View Student for the Student username
     * 
     * @param username
     */
    public void clickViewStudentByEllipseForStudent( String username ) {
        WebElement Ellipsesroot = clickElipsesByStudent( username );
        WebElement viewStudentElement = SMUtils.getWebElementDirect( driver, Ellipsesroot, "cel-dropdown-menu-box", "a" );
        SMUtils.scrollIntoView( driver, viewStudentElement );
        SMUtils.click( driver, viewStudentElement );
        Log.message( "Clicked View Student  for Student: " + username );
    }

    @FindBy ( css = "span.chip-text" )
    List<WebElement> groupNameText;

    @IFindBy ( how = How.CSS, using = "cel-button.action-btn-wrapper", AI = false )
    public WebElement saveButtonInPopup;

    @IFindBy ( how = How.CSS, using = "cel-button.cancel-btn-wrapper", AI = false )
    public WebElement cancelButtonInPopup;

    @IFindBy ( how = How.CSS, using = "cel-dialog-header div div button", AI = false )
    public WebElement helpIcon;

    @IFindBy ( how = How.CSS, using = "div.dialog-wrapper__content h3", AI = false )
    public WebElement zeroStateHeaderMsg;

    @IFindBy ( how = How.CSS, using = "div.dialog-wrapper__content span", AI = false )
    public WebElement zeroStateDescriptionMsg;

    // Mastery Sub Navigation WebElements

    @IFindBy ( how = How.CSS, using = "mastery-filter-subject div > button > span > span", AI = false )
    public WebElement subjectDefaultText;

    @IFindBy ( how = How.CSS, using = "a.contextual-help-link cel-icon", AI = false )
    public WebElement masteryHelpIconroot;

    @IFindBy ( how = How.CSS, using = "mastery-zero-state h3", AI = false )
    public WebElement masteryNoData;

    @IFindBy ( how = How.CSS, using = "mastery-zero-state p", AI = false )
    public WebElement masteryZeroState;

    @IFindBy ( how = How.CSS, using = "div[class='header-title']", AI = false )
    public WebElement masteryLabel;

    @IFindBy ( how = How.CSS, using = "mastery-filter-subject div > button", AI = false )
    public WebElement subjectDropDown;

    @IFindBy ( how = How.CSS, using = "mastery-filter-skills div > button", AI = false )
    public WebElement masterySkillsDropDown;

    @IFindBy ( how = How.CSS, using = "mastery-filter-assignments cel-multi-check-dropdown", AI = false )
    public WebElement assignmentsDropDownroot;

    @FindBy ( css = "mastery-filter-subject ul a" )
    List<WebElement> subjectDropDownValues;

    @FindBy ( css = "mastery-filter-skills ul a" )
    List<WebElement> masterySkillsDropDownValues;

    @IFindBy ( how = How.CSS, using = "mastery-filter-subject div > button  span[class='dropdown-select-label sc-cel-dropdown-select']", AI = false )
    public WebElement subjectDropDownSelectedValue;

    @IFindBy ( how = How.CSS, using = "mastery-filter-skills div > button  span[class='dropdown-select-label sc-cel-dropdown-select']", AI = false )
    public WebElement masterySkillsDropDownSelectedValue;

    @IFindBy ( how = How.CSS, using = "mastery-hierarchy-header div[class='header-color mastered']", AI = false )
    public WebElement masteryLegendMastered;

    @IFindBy ( how = How.CSS, using = "mastery-hierarchy-header div[class='header-color at-risk']", AI = false )
    public WebElement masteryLegendAtRisk;

    @IFindBy ( how = How.CSS, using = "mastery-hierarchy-header div[class='header-color not-mastered']", AI = false )
    public WebElement masteryLegendNotMastered;

    @IFindBy ( how = How.CSS, using = "mastery-hierarchy-header div[class='header-color unassessed']", AI = false )
    public WebElement masteryLegendUnaccessed;

    @IFindBy ( how = How.CSS, using = "cel-button[class='apply-button pl-0 hydrated']", AI = false )
    public WebElement masteryApplyFilter;

    @IFindBy ( how = How.CSS, using = "div[class='grade-name']", AI = false )
    public WebElement masteryStudentGrade;

    @FindBy ( css = "div[class='strand-name']" )
    List<WebElement> masteryTopLevelHierarcy;

    @FindBy ( css = "div[class='header-text']" )
    List<WebElement> masteryMiddleLevelHierarcy;

    @FindBy ( css = "div[class='col-sm-8 header-text']" )
    List<WebElement> masteryLeafNode;

    @FindBy ( css = "div[class='col objective leaf-node-text']" )
    List<WebElement> masteryLODescription;

    @FindBy ( css = "cel-multi-part-progress-bar.hydrated" )
    List<WebElement> masteryProgressBarRoot;
    
    @FindBy ( css = ".lo-catalog-link" )
    List<WebElement> LOLinks;
    
    @IFindBy(how = How.CSS, using=".select-lo" , AI =false)
    public WebElement arrowRoot;

    // Assignments Sub-navigation WebElements

    @IFindBy ( how = How.CSS, using = "div.student-assignment-header > h5", AI = false )
    public WebElement assignmentHeader;

    @FindBy ( css = "#report > tbody  td div[class='cell-group cell-tooltip'] span[class='text-overflow-nowrap align-right']" )
    List<WebElement> allAssignmentsList;

    @FindBy ( css = "cel-button-menu[class='table-dropdown-menu th-action-dropdown hydrated']" )
    List<WebElement> removeStudentFromGroupGrandRoot;

    @FindBy ( css = "div[class='student-firstName-lastName']" )
    List<WebElement> lblGroupNames;

    @FindBy ( css = "cel-button[color='secondary'][class='hydrated']" )
    List<WebElement> addButtons;

    @IFindBy ( how = How.CSS, using = "h1[class='dialog-header__message']", AI = false )
    public WebElement addStudentToGroupHeader;

    @IFindBy ( how = How.CSS, using = "cel-dialog[id=cel-overlay-1] h1.dialog-header__message", AI = false )
    public WebElement lastSessionPopupHeader;

    @IFindBy ( how = How.CSS, using = "div.skills-correct small", AI = false )
    public WebElement pointValue;

    @IFindBy ( how = How.CSS, using = "div.skills-footer cel-button.cancel-btn-wrapper", AI = false )
    public WebElement closeButton;

    @FindBy ( css = "div.student-skills-tested cel-dropdown-select ul li span" )
    List<WebElement> lastSessionDropDownValues;

    @IFindBy ( how = How.CSS, using = "div.student-skills-tested .dropdown-select-value span", AI = false )
    public WebElement lastSessionDefaultSubject;

    @IFindBy ( how = How.CSS, using = "student-skills-tested div.zero-state-content", AI = false )
    public WebElement zeroStateLastSessionSkills;

    @FindBy ( css = "div[class='description cell-tooltip-if-ellipsis'] a" )
    List<WebElement> skillLink;

    @FindBy ( css = "div.description a.text-truncate" )
    List<WebElement> lastSessionSkillTestedNames;

    @FindBy ( css = "div.correct label" )
    List<WebElement> skillsCorrectList;

    @FindBy ( css = "cel-progress-bar.hydrated" )
    List<WebElement> progressBarRoot;

    @IFindBy ( how = How.CSS, using = "div.student-skills-tested cel-dropdown-select button", AI = false )
    public WebElement lastSessionDropDown;

    // To get the first last skill points value in widget
    @IFindBy ( how = How.CSS, using = "div.graph div.row:first-child>div:first-child div.correct label", AI = false )
    public WebElement lastSessionFirstSkill;

    // To get the first skill name from widget
    @IFindBy ( how = How.CSS, using = "div.graph div.row:first-child>div:first-child div.description.cell-tooltip-if-ellipsis", AI = false )
    public WebElement lastSessionFirstSkillName;

    // To get the skill points value from popup
    @IFindBy ( how = How.CSS, using = "div.skills-correct.ml-auto small", AI = false )
    public WebElement lastSessionValueInPopup;

    // To get the skill name from popup
    @IFindBy ( how = How.CSS, using = "div.text-truncate", AI = false )
    public WebElement lastSessionNameInPopup;

    @IFindBy ( how = How.CSS, using = "div[class='description cell-tooltip-if-ellipsis'] a", AI = false )
    public WebElement skillLinkClick;

    @IFindBy ( how = How.CSS, using = "div.student-skills-tested div.student-chart-title", AI = false )
    public WebElement lastSessionHeader;

    @IFindBy ( how = How.CSS, using = "div.graph", AI = false )
    public WebElement lastSessionGraph;

    @IFindBy ( how = How.CSS, using = "div.student-skills-tested div.student-chart-title", AI = false )
    public WebElement skillTestedHeader;

    @FindBy ( css = "div[class='description cell-tooltip-if-ellipsis'] a" )
    List<WebElement> skillNames;

    @IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
    public WebElement skillTestedPopupHeader;

    @IFindBy ( how = How.CSS, using = "cel-icon#dialogHeaderClose", AI = false )
    public WebElement closeIconParentRoot;

    @IFindBy ( how = How.CSS, using = "div.skills-popup div.skills-correct", AI = false )
    public WebElement countOFCorrectAandAttemptedInPopup;

    @IFindBy ( how = How.CSS, using = "div.skills-desc div.text-truncate", AI = false )
    public WebElement lblSkillNameInPopup;

    @IFindBy ( how = How.CSS, using = "div.cell-data a", AI = false )
    public WebElement catalogNumber;

    @IFindBy ( how = How.CSS, using = "div.cell-data span", AI = false )
    public WebElement txtSkillDescription;

    @IFindBy ( how = How.CSS, using = "div.skills-footer cel-button", AI = false )
    public WebElement closeBtnInSkillTestedPopup;

    // Students Tab > Assignments SubNavigation WebElements

    @IFindBy ( how = How.CSS, using = "tbody.table-body", AI = false )
    public WebElement assignmentTable;

    @IFindBy ( how = How.CSS, using = "span[title='Title'] span[class='sort-type-none']", AI = false )
    public WebElement columnTitle;

    @IFindBy ( how = How.CSS, using = "span[title='Last Session'] span[class='sort-type-none']", AI = false )
    public WebElement columnLastSession;

    @IFindBy ( how = How.CSS, using = "span[title='IP Level'] span[class='sort-type-none']", AI = false )
    public WebElement columnIPLevel;

    @IFindBy ( how = How.CSS, using = "span[title='Assigned Level'] span[class='sort-type-none']", AI = false )
    public WebElement columnAssignedLevel;

    @IFindBy ( how = How.CSS, using = "span[title='Current Level'] span[class='sort-type-none']", AI = false )
    public WebElement columnCurrentLevel;

    @IFindBy ( how = How.CSS, using = "span[title='Gain'] span[class='sort-type-none']", AI = false )
    public WebElement columnGain;

    @IFindBy ( how = How.CSS, using = "span[title='% Correct'] span[class='sort-type-none']", AI = false )
    public WebElement columnPercentageCorrect;

    @IFindBy ( how = How.CSS, using = "student-assignments div.zero-state-content h3", AI = false )
    public WebElement zeroStateHeaderMsgForStudentAssignments;

    @IFindBy ( how = How.CSS, using = "student-assignments div.zero-state-content span", AI = false )
    public WebElement zeroStateDescriptionMsgForStudentAssignments;

    @IFindBy ( how = How.CSS, using = "cel-button-menu.table-dropdown-menu", AI = false )
    public WebElement AssignmentEllispeGrandRoot;

    @IFindBy ( how = How.CSS, using = ".cancel-btn-wrapper cel-button", AI = false )
    public WebElement cancelBtnRootFluencyPopup;

    @IFindBy ( how = How.CSS, using = "div.status span", AI = false )
    public WebElement capturePaused;

    @IFindBy ( how = How.CSS, using = "div.status span", AI = false )
    public WebElement captureCompleted;

    @IFindBy ( how = How.CSS, using = "div .student-skills-tested a", AI = false )
    public WebElement lastSessionViewDetails;

    //Tooltip Headers for assignments 
    @IFindBy ( how = How.CSS, using = "span[title='Title'] span[class='sort-type-none']", AI = false )
    public WebElement titleTooltip;

    @IFindBy ( how = How.CSS, using = "span[title='Last Session'] span[class='sort-type-none']", AI = false )
    public WebElement lastSessionTooltip;

    @IFindBy ( how = How.CSS, using = "span[title='IP Level'] span[class='sort-type-none']", AI = false )
    public WebElement ipLevelTooltip;

    @IFindBy ( how = How.CSS, using = "span[title='Assigned Level'] span[class='sort-type-none']", AI = false )
    public WebElement assignedLevelTooltip;

    @IFindBy ( how = How.CSS, using = "span[title='Current Level'] span[class='sort-type-none']", AI = false )
    public WebElement currentLevelTooltip;

    @IFindBy ( how = How.CSS, using = "span[title='Gain'] span[class='sort-type-none']", AI = false )
    public WebElement gainTooltip;

    @IFindBy ( how = How.CSS, using = "span[title='% Correct'] span[class='sort-type-none']", AI = false )
    public WebElement percentageCorrectTooltip;

    @IFindBy ( how = How.CSS, using = "span[aria-label='Student is INACTIVE']", AI = false )
    public WebElement pausedTag;

    @IFindBy ( how = How.CSS, using = "span[aria-label='assignments.completeStatus COMPLETE']", AI = false )
    public WebElement completedTag;

    @FindBy ( css = "table#report th>span" )
    List<WebElement> columnNamesList;

    @IFindBy ( how = How.CSS, using = ".mastery-container .zero-state-content .header", AI = false )
    public WebElement masteryZeroStateHeader;

    @IFindBy ( how = How.CSS, using = ".mastery-container .zero-state-content .message", AI = false )
    public WebElement masteryZeroStateMessage;

    @IFindBy ( how = How.CSS, using = "thead cel-checkbox", AI = false )
    public WebElement topCheckBox;

    @FindBy ( css = studentIdCSS )
    List<WebElement> studentIdColumnValues;

    @FindBy ( css = firstNameCSS )
    List<WebElement> firstNameColumnValues;

    @FindBy ( css = lastNameCSS )
    List<WebElement> lastNameColumnValues;

    @FindBy ( css = userNameCSS )
    List<WebElement> userNameColumnValues;

    @FindBy ( css = gradeCSS )
    List<WebElement> gradeColumnValues;

    @FindBy ( css = "tbody tr " )
    List<WebElement> tableRow;

    @IFindBy ( how = How.CSS, using = "table cel-icon", AI = false )
    public WebElement arrowIcon;

    @FindBy ( css = "table span.sort-type-none" )
    List<WebElement> columnNames;

    @FindBy ( css = "thead span.d-flex" )
    List<WebElement> ColumnHeader;

    @IFindBy ( how = How.CSS, using = "div.text-truncate", AI = false )
    public WebElement skillnameInPopup;

    @IFindBy ( how = How.CSS, using = "div.report.green cel-progress-bar", AI = false )
    public WebElement progressBarPopup;

    @IFindBy ( how = How.CSS, using = "div.report.blue cel-progress-bar", AI = false )
    public WebElement progressBarPopupReading;

    @IFindBy ( how = How.CSS, using = "cel-icon.dialog-header__icon-close", AI = false )
    public WebElement lastSessionPopupCloseIcon;

    // To get the LO number in last session skills popup
    @IFindBy ( how = How.CSS, using = "div.dialog-wrapper__content div.cell-data a", AI = false )
    public WebElement loNumberinSkillsPopup;

    @FindBy ( css = "div.course-info" )
    List<WebElement> assignmentList;

    @IFindBy ( how = How.CSS, using = "cel-icon.on-hover.hydrated", AI = false )
    public WebElement iIconRoot;
    @IFindBy ( how = How.CSS, using = "tbody tr:nth-child(1)", AI = false )
    public WebElement firstStudent;
    @IFindBy ( how = How.ID, using = "userPassword", AI = false )
    public WebElement txbNewPassword;

    @IFindBy ( how = How.ID, using = "confirmPassword", AI = false )
    public WebElement txbConfirmNewPassword;

    @IFindBy ( how = How.CSS, using = "div[class='form-group col-md-4 passwordRequirementCard'] span[class='show-hide-demographics cursor-pointer']", AI = false )
    public WebElement changePassswordLink;

    @IFindBy ( how = How.CSS, using = "span.change-password-disabled", AI = false )
    public WebElement disabledChangePasswordLink;

    @IFindBy ( how = How.CSS, using = ".create-student-button.add-student-button.hydrated", AI = false )
    public WebElement saveBtnShadow;

    @IFindBy ( how = How.CSS, using = ".dialog-button.hydrated", AI = false )
    public WebElement closeBtnShadow;

    private String closeBtnCSS = ".primary_button";

    @IFindBy ( how = How.CSS, using = ".create-student-button.close-button.hydrated", AI = false )
    public WebElement cancelBtnShadow;

    @IFindBy ( how = How.CSS, using = "#alert__messageBody", AI = false )
    public WebElement alertElement;

    @IFindBy ( how = How.CSS, using = "input#firstName", AI = false )
    public WebElement firstNameField;

    @IFindBy ( how = How.CSS, using = "input#userName", AI = false )
    public WebElement userNameField;

    public static String alertMessageCSS = "#alert__messageBody";

    @IFindBy ( how = How.CSS, using = "div.cell-tooltip", AI = false )
    public WebElement PasswordRequirementRoot;

    @IFindBy ( how = How.CSS, using = "span cel-icon.arrow-up", AI = false )
    public WebElement sortBasedOnStudentID;

    @FindBy ( css = "div.list-data div.student-firstName-lastName" )
    List<WebElement> listOfGroupsForStudents;

    @FindBy ( css = "div.container-wrapper div.assignment-name-detail" )
    List<WebElement> listofAssignmentsForStudents;

    //Web Elements for Warning Message Pop-Up

    @IFindBy ( how = How.CSS, using = "h1[class=dialog-header__message]", AI = false )
    public WebElement warningMessageHeader;

    @IFindBy ( how = How.CSS, using = "div[class=error-content]", AI = false )
    public WebElement warningMessageContent;

    @IFindBy ( how = How.ID, using = "closeBtn", AI = false )
    public WebElement warningpopupXBtn;

    @IFindBy ( how = How.CSS, using = "cel-button[class='dialog-button hydrated']", AI = false )
    public WebElement warningpopupCloseBtn;

    // Root Child Elements
    private String saveBtnCSS = ".primary_button";
    public static String erroMessgaeCSS = ".error-message span";
    private String cancelBtnCSS = ".secondary_button";
    private static String btnAddStrudent = ".primary_button";
    private static String btnGrpAssign = ".secondary_button";
    private static String chkboxSelectAllStudents = "div.primary__checkbox label.checkbox__container input";
    private static String ellipsisGrandRootCSS = "cel-button-menu.table-dropdown-menu";
    private static String elliipsisParentRootCSS = "cel-icon.hydrated";
    private static String ellipsisDotCSS = "img.icon-inner";
    private static String ellipsisMenuRootCSS = "div.buttonmenu cel-dropdown-menu-box";
    private static String ellipsisViewStudent = "ul.menu>li:nth-of-type(1)>a>span";
    private static String ellipsisAddtoGroup = "ul.menu>li:nth-of-type(2)>a>span";
    private static String ellipsisAddtoAssignment = "ul.menu>li:nth-of-type(3)>a>span";
    private static String btnCloseIcon = "img.icon-inner";
    private static String lblstudentUsername = "tr:nth-child(%s) td:nth-child(4) span";
    private static String lblstudentFirstname = "tr:nth-child(%s) td:nth-child(2) span";
    private static String lblstudentLastname = "tr:nth-child(%s) td:nth-child(3) span";
    private static String lblstudentGrade = "tr:nth-child(%s) td:nth-child(6) span";
    private static String elipsisChild = "div.buttonmenu cel-icon";
    private static String pauseBtnChild = " div cel-dropdown-menu-box";
    private static String pauseBtnGrandChild = "div ul li[aria-label=\"Pause Assignment For Student\"]";
    private static String removeStudentFromGroupParent = "cel-dropdown-menu-box.hydrated";
    private static String removeStudentFromGroupChild = "li[class='menu-item']";
    private static String removeAndCancelButtonInPopup = "button";
    private static String xIconInPopup = "img.icon-inner";

    private static String lblStudentUsageHeader = "div.student-chart-title";
    private static String lblZeroStateMessage = "div.zero-state-content";
    private static String txtindividualField = "p.text-black";
    private static String topCheckBoxCSS = "div span.checkbox__custom";

    private static String lblAssignmentsName = "div.cell-tooltip span.align-right";
    private static String menuRemovestudentFromAssignment = "div ul li[aria-label='Remove Student From Assignment'] a";
    private static String popupButtonChild = "button";
    private static String lblstudentStudentId = "tr:nth-child(%s) td:nth-child(5) span";
    public static String zeroStateCSS = "h3.header";
    public static String checkBoxCSS = "td.td-check cel-checkbox";
    public static String addBtnCSS = "div label span.checkbox__custom";
    private static String ellipsesOptionsCSS = "ul.menu>li>a>span";
    public static String addStudenttoAssignmentparentCSS = "cel-checkbox.hydrated";
    public static String btnAddStudentstoAssignmentCSS = "div label span";
    private static String groupXIcon = "span.cross-mark cel-icon";
    private static String removeButAddStuPopUp = "div.remove-button";
    private static String addButAddStuPopUp = "div.add-button";
    public static String progressBarCSS = "div > div.progressBar";
    public static String progressBarTextZeroCSS = "span.textOutside.progressBarText";
    public static String SKILL_CORRECT = "Skill Correct";
    public static String SKILL_PERCENT_VALUE = "Bar Percent Value";
    public static String BAR_WIDTH = "Bar Width";
    private static String assignmentsDropdownchild = "button";
    private static String assignmentsDropdownvalueschild = "cel-checkbox.hydrated";
    private static String assignmentsDropdowniconchild = "cel-icon";
    private static String assignmentsDropdownEachValueChild = ".checkbox__label";
    private static String assignmentDropdownEachCheckbox = "input";
    private static String txtDropDownMSValue = ".primary__checkbox input";
    private static String progressBarChild = ".multi-part-progress-bar";
    private static String closeIconChild = "img.icon-inner";
    private static String closeButtonChild = "button.primary_button";
    private static String progressBarSkillsPopup = "div.progressBar";
    private static String lastSessionPopupIconClose = "img.icon-inner";
    private static String masteryHelpIconChild = "img.icon-inner";
    private static String masteryApplyFilterchild = "button.primary_button";

    static String assingmentNameTable = "tbody.table-body tr:nth-child(%s) td:nth-child(1) div span:nth-child(1)";
    static String fluencyFileschild = "div ul li[aria-label='Fluency Files (0)'] a";
    static String viewAssignmentchild = "div ul li[aria-label='View Assignment'] a";
    static String editAssignmentchild = "div ul li[aria-label='Edit Assignment Settings'] a";
    static String pauseAssignmentForStudentchild = "div ul li[aria-label='Pause Assignment For Student'] a";
    static String resumeAssignmentForStudentchild = "div ul li[aria-label='Resume Assignment For Student'] a";
    static String removeStudentFromAssignmentchild = "div ul li[aria-label='Remove Student From Assignment'] a";
    static String assignmentCancelBtn = ".secondary_button";

    public static final String firstNameCSS = "td:nth-of-type(2) span";
    public static final String lastNameCSS = "td:nth-of-type(3) span";
    public static final String userNameCSS = "td:nth-of-type(4) span";
    public static final String studentIdCSS = "td:nth-of-type(5) span";
    public static final String gradeCSS = "td:nth-of-type(6) span";
    public static String arrowUp = "icon_arrow_thin_up";
    public static String arrowDown = "icon_arrow_thin_down";
    public static String STUDENTS_ADDED_SUCCESSFULLY = "Student Added Successfully";

    String tableColumn = "td";
    String labelStudentIPandGain = "span.text-overflow-nowrap";
    String labelLastSession = "span.date-cell";
    String afterSortingElement = "th[class='th-text table-header'] span[title='%s']";
    String groupNameFromViewStudent = "span[title='%s']";

    public StudentsPage() {}

    /**
     * 
     * Constructor class for Mastery page and initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public StudentsPage( WebDriver driver ) {
        this.driver = driver;
        // Have Topbar here and init
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
        topNavBar = new TopNavBar( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, btnAddStudentRoot );

    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, btnAddStudentRoot ) ) {
            Log.message( "SM Student loaded successfully." );
        } else {
            Log.fail( "SM Students page did not load." );
        }

    }

    /**
     * To get add student button element
     * 
     * @return
     */
    public WebElement addStudentElement() {
        SMUtils.waitForElement( driver, btnAddStudentRoot );
        WebElement addStudent = SMUtils.getWebElementDirect( driver, btnAddStudentRoot, btnAddStrudent );
        return addStudent;
    }

    /**
     * To click Add student button in create Student popup
     */
    public void clikAddStudentInStudentListingPage() {
        SMUtils.waitForElement( driver, btnAddStudentRoot );
        //      WebElement addStrudent = SMUtils.getWebElementDirect(driver, btnAddStudentRoot, btnAddStrudent);
        SMUtils.clickJS( driver, addStudentElement() );
        Log.message( "Clicked Add Student Button" );
    }

    /**
     * Clicking i icon
     * 
     * @throws InterruptedException
     */
    public void clickiIcon() throws InterruptedException {
        SMUtils.clickJS( driver, btnCreateStudentPopupIicon );
        Log.message( "Clicked i icon" );
        SMUtils.nap( 3 ); //Waiting for i icon window handling
    }

    /**
     * To get the i icon
     * 
     * @return
     */
    public WebElement getIicon() {
        return btnCreateStudentPopupIicon;
    }

    /**
     * To click group button from Students page
     */
    public void clickGroupButtoninStudentLisitngPage() {
        SMUtils.clickJS( driver, getGroupButton() );
        Log.message( "Clicked Group Button" );
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 10 );
        } catch ( InterruptedException e ) {
            e.printStackTrace();
        }
    }

    public WebElement getGroupButton() {
        return SMUtils.getWebElementDirect( driver, btnGroupRoot, btnGrpAssign );
    }

    /**
     * To click Assignment button from Students page
     */
    public void clickAssignmentButton() {
        SMUtils.clickJS( driver, getAssignmentButton() );
        Log.message( "Clicked Assignment Button" );
    }

    public WebElement getAssignmentButton() {
        return SMUtils.getWebElementDirect( driver, btnAssignmentRoot, btnGrpAssign );
    }

    /**
     * To check Group & Assignment button is enable or not
     * 
     * @return true / false
     */

    public Boolean groupAssignmentIsEnable() {
        Boolean status = true;

        WebElement addAssign = SMUtils.getWebElementDirect( driver, btnAssignmentRoot, btnGrpAssign );
        WebElement addGroup = SMUtils.getWebElementDirect( driver, btnGroupRoot, btnGrpAssign );
        if ( addAssign.isEnabled() == false && addGroup.isEnabled() == false ) {
            status = false;
        }
        return status;
    }

    /**
     * To create a student
     * 
     * @throws Exception
     */

    public String createStudent() throws Exception {
        SMUtils.nap( 1 ); //Waiting to disappear the loading icon
        clikAddStudentInStudentListingPage();
        SMUtils.waitForElement( driver, formCreateStudentPopup, 10 );

        if ( !formCreateStudentPopup.isDisplayed() ) {
            throw new Exception( "Create Student pop not visible" );
        }
        Faker studentDetails = new Faker();
        String firstName = studentDetails.name().firstName();
        String studentID = firstName + System.nanoTime();
        String password = "testing123$";
        txtboxFirstName.sendKeys( studentDetails.name().firstName() );
        txtboxLastName.sendKeys( studentDetails.name().lastName() );
        SMUtils.waitForElement( driver, ddGradeSelection );
        clickSelectGradeDropdown();
        selectGrade( "Grade 1" );
        txtboxDatOfBirth.sendKeys( "11/20/2010" );
        txtboxStudentID.sendKeys( studentID );
        txtboxUserName.sendKeys( studentID.toLowerCase() );
        txtboxPassWord.sendKeys( RBSDataSetupConstants.DEFAULT_PASSWORD );
        txtboxConfirmPassword.sendKeys( RBSDataSetupConstants.DEFAULT_PASSWORD );
        SMUtils.clickJS( driver, btnCreateStudent );
        Log.message( "Successfully Created the student: " + studentID );
        SMUtils.nap( 1.5 ); //Waiting to disappear the toast message

        return studentID.toLowerCase();
    }

    /**
     * 
     * To create a student with Mandatory Fields
     * 
     * @param mandatoryValues
     * @return
     * @throws Exception
     */

    public void createStudentWithMandatoryField( HashMap<String, String> mandatoryValues ) throws Exception {
        clikAddStudentInStudentListingPage();
        SMUtils.waitForElement( driver, formCreateStudentPopup, 10 );

        if ( !formCreateStudentPopup.isDisplayed() ) {
            throw new Exception( "Create Student pop not visible" );
        }

        String firstName = mandatoryValues.get( Students.COLUMN_FIRST_NAME );
        String lastName = mandatoryValues.get( Students.COLUMN_LAST_NAME );
        String studentId = mandatoryValues.get( Students.COLUMN_STUDNET_ID );
        String Grade = mandatoryValues.get( Students.COLUMN_GRADE );
        String userName = mandatoryValues.get( Students.COLUMN_USER_NAME );
        String password = mandatoryValues.get( Constants.PASSWORD_TEXT );

        txtboxFirstName.sendKeys( firstName );
        txtboxLastName.sendKeys( lastName );
        SMUtils.waitForElement( driver, ddGradeSelection );
        clickSelectGradeDropdown();
        selectGrade( Grade );
        txtboxDatOfBirth.sendKeys( Constants.Students.CREATE_STUDENT_DOB );
        txtboxStudentID.sendKeys( studentId );
        txtboxUserName.sendKeys( userName.toLowerCase() );
        txtboxPassWord.sendKeys( password );
        txtboxConfirmPassword.sendKeys( password );
        SMUtils.clickJS( driver, btnCreateStudent );
        SMUtils.waitForToastMessageToDisapper( driver );
        clickCloseButton();
    }

    public void clickSelectGradeDropdown() {
        String queryToExecute = "document.querySelector('#grade > div > button > span.dropdown-select-caret-outer.sc-cel-dropdown-select > cel-icon').shadowRoot.querySelector('img').click()";
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript( queryToExecute );
    }

    /**
     * To Select grade
     * 
     * @param grade
     */
    public void selectGrade( String grade ) {
        for ( int i = 0; i < listofGrades.size(); i++ ) {
            String elementText = listofGrades.get( i ).getText();
            if ( elementText.equals( grade ) ) {
                SMUtils.clickJS( driver, listofGrades.get( i ) );

                break;
            }
        }
        Log.message( "Selected the Grade: " + grade );
    }

    /**
     * To check studentUsername is present or not
     * 
     * @param studentUsername
     * @return
     */
    public Boolean isStrudentPresent( String studentUsername ) {
        return ( getAllStudentsUserNames().contains( studentUsername ) ) ? true : false;
    }

    /**
     * To Select All students under the teacher
     */
    public void selectAllStudents() {
        SMUtils.waitForElement( driver, tableStudentList );

        WebElement selectAllStudentElement = SMUtils.getWebElementDirect( driver, chkboxSelectAllStudentsRoot, chkboxSelectAllStudents );
        SMUtils.clickJS( driver, selectAllStudentElement );
        Log.message( "Selected All students" );
    }

    /**
     * To add a student(s) a group From clicking Group button to Save
     * 
     * @param groupName
     */
    public void addStudentstoGroup( String groupName ) {
        clickGroupButtoninStudentLisitngPage();
        SMUtils.waitForElement( driver, formGroupPopup, 5 );
        txtboxGroupfilter.sendKeys( groupName );
        SMUtils.nap( 1 ); //Waiting to disappear the loading icon
        SMUtils.click( driver, btnAddGroup );
        SMUtils.click( driver, btnSaveGroup );
        Log.message( "Students Added to the group: " + groupName );
    }

    /**
     * To click view student menu from ellipsis
     * 
     * @param studentUsername
     * @throws InterruptedException
     */
    public void clickviewStudentByEllipsis( String studentUsername ) throws InterruptedException {
        // sortbyStudentID.click();
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        // SMUtils.click( driver, sortbyStudentUserName );
        WebElement ellipsisRootMenu = getEllipsisMenuRootElement( studentUsername );
        WebElement viewStudentMenu = SMUtils.getWebElementDirect( driver, ellipsisRootMenu, ellipsisViewStudent );
        SMUtils.waitForElementToBeClickable( viewStudentMenu, driver );
        SMUtils.clickJS( driver, viewStudentMenu );
        Log.message( "Clicked on the View student from the Ellipsis menu for the student: " + studentUsername );
    }

    /**
     * To click add student to group menu from ellipsis
     * 
     * @param studentID
     */
    public void clickAddStudentToGroupByEllipsis( String studentID ) {
        sortbyStudentUserName.click();
        WebElement ellipsisRootMenu = getEllipsisMenuRootElement( studentID );
        WebElement ellipsisgrp = SMUtils.getWebElementDirect( driver, ellipsisRootMenu, ellipsisAddtoGroup );
        SMUtils.waitForElementToBeClickable( ellipsisgrp, driver );
        SMUtils.clickJS( driver, ellipsisgrp );
        Log.message( "Clicked on Add student to the Group from the Ellipsis menu for the student: " + studentID );
    }

    /**
     * To click add student to assignment menu from ellipsis
     * 
     * @param studentID
     */
    public void clickAddStudentToAssignmentByEllipsis( String studentID ) {
        WebElement ellipsisRootMenu = getEllipsisMenuRootElement( studentID );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, ellipsisRootMenu, ellipsisAddtoAssignment ) );
        Log.message( "Clicked on Add student to the Assignment from the Ellipsis menu for the student: " + studentID );
    }

    /**
     * To close add group / assignment popup
     */
    public void closePopup() {
        SMUtils.nap( 2 );
        SMUtils.waitForElement( driver, btnClosePopupRoot );
        //        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnClosePopupRoot, btnCloseIcon ) );
        SMUtils.clickJS( driver, btnClosePopupRoot );
        Log.message( "Clicked on Close icon from the Pop up" );
    }

    // View Student Section
    /**
     * To get header name
     * 
     * @return
     */
    public String getHeaderName() {
        SMUtils.waitForElement( driver, headerText );
        return headerText.getText();
    }

    // View Student Section
    /**
     * To get header name
     * 
     * @return
     */
    public String getHeaderNameStudent() {
        SMUtils.waitForElement( driver, headerTextStudent );
        return headerText.getText();
    }

    /**
     * To change the first name of the student
     * 
     * @param editName
     */
    public void changeFirstName( String editName ) {
        SMUtils.waitForElement( driver, txtboxFirstName );
        txtboxFirstName.clear();
        txtboxFirstName.sendKeys( editName );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnSaveStudentDetailsRoot, btnAddStrudent ) );
        SMUtils.waitForElement( driver, txtboxFirstName );
        Log.message( "Changed Student first name as: " + editName );
    }

    /**
     * To change the Middle name of the student
     * 
     * @param editMiddleName
     */
    public void changeMiddleName( String editMiddleName ) {
        SMUtils.waitForElement( driver, txtboxMiddleName );
        SMUtils.clickJS( driver, txtboxMiddleName );
        txtboxMiddleName.clear();
        SMUtils.enterValue( txtboxMiddleName, editMiddleName );

        //( (JavascriptExecutor) driver ).executeScript( "arguments[0].setAttribute('value','"+editMiddleName+"' )", txtboxMiddleName );

        //txtboxMiddleName.sendKeys( editMiddleName);
        SMUtils.clickJS( driver, txtboxFirstName );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnSaveStudentDetailsRoot, btnAddStrudent ) );
        SMUtils.waitForElement( driver, txtboxMiddleName );
        Log.message( "Changed Student middle name as: " + editMiddleName );
    }

    /**
     * To change the Last name of the student
     * 
     * @param editLastName
     */
    public void changeLastName( String editLastName ) {
        SMUtils.waitForElement( driver, txtboxLastName );
        txtboxLastName.clear();
        txtboxLastName.sendKeys( editLastName );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnSaveStudentDetailsRoot, btnAddStrudent ) );
        SMUtils.waitForElement( driver, txtboxLastName );
        Log.message( "Changed Student first name as: " + editLastName );
    }

    /**
     * To change the StudentID of the student
     * 
     * @param editStudentID
     * @throws InterruptedException
     */
    public void changeStudentId( String editStudentID ) throws InterruptedException {
        SMUtils.waitForElement( driver, txtboxStudentID );
        txtboxStudentID.clear();
        txtboxStudentID.sendKeys( editStudentID );
        clickSaveButtoninUserProfile();
        SMUtils.waitForElement( driver, txtboxStudentID );
        Log.message( "Changed Student ID as: " + editStudentID );
    }

    /**
     * Click save Button in Students-UserPorfile Sub Nav Tab
     * 
     * @throws InterruptedException
     */
    public void clickSaveButtoninUserProfile() throws InterruptedException {
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, btnSaveStudentDetailsRoot, "button" ) );
        SMUtils.waitForSpinnertoDisapper( driver, 5 );
        SMUtils.waitForToastMessageToDisapper( driver );
    }

    /**
     * To change the username of the student
     * 
     * @param editUserName
     */
    public void changeUserName( String editUserName ) {
        SMUtils.waitForElement( driver, txtboxUserName );
        txtboxUserName.clear();
        txtboxUserName.sendKeys( editUserName );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnSaveStudentDetailsRoot, btnAddStrudent ) );
        SMUtils.waitForElement( driver, txtboxUserName );
        Log.message( "Changed Student ld as: " + editUserName );
    }

    /**
     * To change the date of birth of the student
     * 
     * @param editDateOfBirth
     */
    public void updateDateOfBirth( String editDateOfBirth ) {
        SMUtils.waitForElement( driver, txtboxDatOfBirth );
        txtboxDatOfBirth.clear();
        txtboxDatOfBirth.sendKeys( editDateOfBirth );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnSaveStudentDetailsRoot, btnAddStrudent ) );
        SMUtils.waitForElement( driver, txtboxDatOfBirth );
        Log.message( "Changed Student date of birth as: " + editDateOfBirth );
    }

    /**
     * To change the passsword of the student
     * 
     * @param editPassword
     */
    public void changePassword( String editPassword ) {
        SMUtils.scrollToBottomOfPage( driver );
        SMUtils.waitForElement( driver, changePassswordLink );
        SMUtils.clickJS( driver, changePassswordLink );
        txtboxPassWord.sendKeys( editPassword );
        txtboxConfirmPassword.sendKeys( editPassword );
        SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, btnSaveStudentDetailsRoot, btnAddStrudent ) );
        Log.message( "Changed  password as: " + editPassword );
    }

    /**
     * To get the modified student name
     * 
     * @return
     */
    public String getFirstName() {
        SMUtils.waitForElement( driver, txtboxFirstName );
        return txtboxFirstName.getAttribute( "value" ).trim();
    }

    /**
     * To get the modified student middle name
     * 
     * @return
     */
    public String getMiddleName() {
        SMUtils.waitForElement( driver, txtboxMiddleName );
        return txtboxMiddleName.getAttribute( "value" ).trim();
    }

    /**
     * To get the modified student Date of Birth
     * 
     * @return
     */
    public String getDateOfBirth() {
        SMUtils.waitForElement( driver, txtboxDatOfBirth );
        return txtboxDatOfBirth.getAttribute( "value" ).trim();
    }

    /**
     * To get the modified student last name
     * 
     * @return
     */
    public String getLastName() {
        SMUtils.waitForElement( driver, txtboxLastName );
        return txtboxLastName.getAttribute( "value" ).trim();
    }

    /**
     * To get the modified student ID
     * 
     * @return
     */
    public String getStudentId() {
        SMUtils.waitForElement( driver, txtboxStudentID );
        return txtboxStudentID.getAttribute( "value" ).trim();
    }

    /**
     * To get the modified Grade
     * 
     * @return
     */
    public String getGradeValue() {
        SMUtils.waitForElement( driver, gradeValue );
        String grade = gradeValue.getText().trim();
        Log.message( grade );
        return grade;
    }

    /**
     * To get the modified student username
     * 
     * @return
     */
    public String getUserName() {
        SMUtils.waitForElement( driver, txtboxUserName );
        return txtboxUserName.getAttribute( "value" ).trim();
    }

    /**
     * To get the modified get user password
     * 
     * @return
     */
    public String getUserPassword() {
        SMUtils.waitForElement( driver, txtboxPassWord );
        return txtboxPassWord.getAttribute( "value" );
    }

    /**
     * To getGradeListing
     * 
     * @param grade
     */

    public List<String> getAllGradeValuesinUserProfile() {
        SMUtils.waitForElement( driver, txtboxStudentID );
        SMUtils.scrollDownPage( driver );
        SMUtils.waitForElement( driver, ddGradeSelectionUpdateStudent );
        SMUtils.clickJS( driver, ddGradeSelectionUpdateStudent );
        List<String> grade = new ArrayList<String>();
        /*
         * for ( int i = 0; i < listofDropdownValues.size(); i++ ) { String
         * elementText = listofDropdownValues.get( i ).getText(); grade.add(
         * elementText );
         * 
         * }
         */
        for ( WebElement dropDownValue : listofDropdownValues ) {
            String elementText = dropDownValue.getText();
            grade.add( elementText );

        }
        return grade;
    }

    /**
     * To getSpecialServiceValues
     * 
     * @param specialService
     */
    public List<String> getSpecialServiceValues() {
        SMUtils.scrollIntoView( driver, ddSpecialServicesnUpdateStudent );
        SMUtils.waitForElement( driver, showMoreDemographics );
        SMUtils.clickJS( driver, showMoreDemographics );
        SMUtils.waitForElement( driver, ddSpecialServicesnUpdateStudent );
        SMUtils.clickJS( driver, ddSpecialServicesnUpdateStudent );
        List<String> specialService = new ArrayList<String>();
        for ( WebElement dropDownValue : listofDropdownValues ) {
            String elementText = dropDownValue.getText();
            specialService.add( elementText );

        }
        return specialService;
    }

    /**
     * To getEthnicityValues
     * 
     * @param ethnicity
     */

    public List<String> getEthnicityValues() {
        SMUtils.scrollIntoView( driver, ddSpecialServicesnUpdateStudent );
        SMUtils.waitForElement( driver, ddEthnicitySelectionUpdateStudent );
        SMUtils.clickJS( driver, ddEthnicitySelectionUpdateStudent );
        List<String> ethnicity = new ArrayList<String>();
        for ( WebElement dropDownValue : listofDropdownValues ) {
            String elementText = dropDownValue.getText();
            ethnicity.add( elementText );

        }
        return ethnicity;
    }

    /**
     * To getRaceValues
     * 
     * @param race
     */

    public List<String> getRaceValues() {
        SMUtils.scrollIntoView( driver, ddSpecialServicesnUpdateStudent );
        SMUtils.waitForElement( driver, ddRaceSelectionUpdateStudent );
        SMUtils.clickJS( driver, ddRaceSelectionUpdateStudent );
        List<String> race = new ArrayList<String>();
        for ( WebElement dropDownValue : listofDropdownValues ) {
            String elementText = dropDownValue.getText();
            race.add( elementText );
        }
        return race;
    }

    /**
     * To get the demographics values
     * 
     * @param demographics
     * @return
     */
    public String getSelectedValues( String demographics ) {
        String defaultValue = null;
        try {
            switch ( demographics ) {
                case UserConstants.ETHINICITY:
                    SMUtils.scrollIntoView( driver, ddSpecialServicesnUpdateStudent );
                    SMUtils.waitForElement( driver, ddEthnicitySelectionUpdateStudent );
                    SMUtils.clickJS( driver, ddEthnicitySelectionUpdateStudent );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim();
                        WebElement findElement = dropDownValue.findElement( By.xpath( "./../.." ) );
                        if ( findElement.getAttribute( "aria-selected" ).equalsIgnoreCase( "true" ) ) {
                            defaultValue = elementText;
                            SMUtils.clickJS( driver, ddEthnicitySelectionUpdateStudent );
                            break;
                        }
                    }

                    break;
                case UserConstants.SPECIAL_SERVICES:
                    SMUtils.scrollIntoView( driver, ddSpecialServicesnUpdateStudent );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.waitForElement( driver, ddSpecialServicesnUpdateStudent );
                    SMUtils.clickJS( driver, ddSpecialServicesnUpdateStudent );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim();
                        WebElement findElement = dropDownValue.findElement( By.xpath( "./../.." ) );
                        if ( findElement.getAttribute( "aria-selected" ).equalsIgnoreCase( "true" ) ) {
                            defaultValue = elementText;
                            SMUtils.clickJS( driver, ddSpecialServicesnUpdateStudent );
                            break;
                        }
                    }

                    break;
                case UserConstants.HAS_DISABILITY:
                    SMUtils.scrollDownPage( driver );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.scrollIntoView( driver, dddisabilityStatusUpdateStudent );
                    SMUtils.waitForElement( driver, dddisabilityStatusUpdateStudent );
                    SMUtils.clickJS( driver, dddisabilityStatusUpdateStudent );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim().trim();
                        WebElement findElement = dropDownValue.findElement( By.xpath( "./../.." ) );
                        if ( findElement.getAttribute( "aria-selected" ).equalsIgnoreCase( "true" ) ) {
                            defaultValue = elementText;
                            SMUtils.clickJS( driver, dddisabilityStatusUpdateStudent );
                            break;
                        }
                    }

                    break;
                case UserConstants.HAS_ECONOMIC_DISADVANTAGE:
                    SMUtils.scrollDownPage( driver );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.scrollIntoView( driver, ddEconomicStatusUpdateStudent );
                    SMUtils.waitForElement( driver, ddEconomicStatusUpdateStudent );
                    SMUtils.clickJS( driver, ddEconomicStatusUpdateStudent );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim().trim();
                        WebElement findElement = dropDownValue.findElement( By.xpath( "./../.." ) );
                        if ( findElement.getAttribute( "aria-selected" ).equalsIgnoreCase( "true" ) ) {
                            defaultValue = elementText;
                            SMUtils.clickJS( driver, ddEconomicStatusUpdateStudent );
                            break;
                        }
                    }

                    break;
                case UserConstants.HAS_ENGLISH_PROFICIENCY:
                    SMUtils.scrollDownPage( driver );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.scrollIntoView( driver, ddEnglishUpdateStudent );
                    SMUtils.waitForElement( driver, ddEnglishUpdateStudent );
                    SMUtils.clickJS( driver, ddEnglishUpdateStudent );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim().trim();
                        WebElement findElement = dropDownValue.findElement( By.xpath( "./../.." ) );
                        if ( findElement.getAttribute( "aria-selected" ).equalsIgnoreCase( "true" ) ) {
                            defaultValue = elementText;
                            SMUtils.clickJS( driver, ddEnglishUpdateStudent );
                            break;
                        }
                    }

                    break;
                case UserConstants.ISMIGRANT:
                    SMUtils.scrollToBottomOfPage( driver );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.scrollToBottomOfPage( driver );
                    SMUtils.waitForElement( driver, ddMigrantUpdateStudent );
                    SMUtils.clickJS( driver, ddMigrantUpdateStudent );
                    List<String> migrant = new ArrayList<String>();
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim().trim();
                        WebElement findElement = dropDownValue.findElement( By.xpath( "./../.." ) );
                        if ( findElement.getAttribute( "aria-selected" ).equalsIgnoreCase( "true" ) ) {
                            defaultValue = elementText;
                            SMUtils.clickJS( driver, ddMigrantUpdateStudent );
                            break;
                        }
                    }

                    break;
                case UserConstants.GENDER_FIELD:
                    SMUtils.scrollDownPage( driver );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.scrollToBottomOfPage( driver );
                    SMUtils.waitForElement( driver, ddGenderUpdateStudent );
                    SMUtils.clickJS( driver, ddGenderUpdateStudent );
                    List<String> gender = new ArrayList<String>();
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim();
                        gender.add( elementText );
                        WebElement findElement = dropDownValue.findElement( By.xpath( "./../.." ) );
                        if ( findElement.getAttribute( "aria-selected" ).equalsIgnoreCase( "true" ) ) {
                            defaultValue = elementText;
                            SMUtils.clickJS( driver, ddGenderUpdateStudent );
                            break;
                        }
                    }
                    break;

            }
            return defaultValue;
        } catch ( Exception e ) {
            Log.message( "Issue in verifying the default values" );
            return defaultValue;
        }

    }

    public void selectDemographicValues( String demographics, String value ) {
        try {
            switch ( demographics ) {
                case UserConstants.ETHINICITY:
                    SMUtils.scrollIntoView( driver, ddSpecialServicesnUpdateStudent );
                    SMUtils.waitForElement( driver, ddEthnicitySelectionUpdateStudent );
                    SMUtils.clickJS( driver, ddEthnicitySelectionUpdateStudent );
                    Log.message( "To be selected - " + value );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText();
                        if ( elementText.equalsIgnoreCase( value ) ) {
                            dropDownValue.click();
                        }
                    }

                    break;
                case UserConstants.SPECIAL_SERVICES:
                    SMUtils.scrollIntoView( driver, ddSpecialServicesnUpdateStudent );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.waitForElement( driver, ddSpecialServicesnUpdateStudent );
                    SMUtils.clickJS( driver, ddSpecialServicesnUpdateStudent );
                    Log.message( "To be selected - " + value );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText();
                        if ( elementText.equalsIgnoreCase( value ) ) {
                            dropDownValue.click();
                        }
                    }

                    break;
                case UserConstants.HAS_DISABILITY:
                    SMUtils.scrollDownPage( driver );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.scrollIntoView( driver, dddisabilityStatusUpdateStudent );
                    SMUtils.waitForElement( driver, dddisabilityStatusUpdateStudent );
                    SMUtils.clickJS( driver, dddisabilityStatusUpdateStudent );
                    Log.message( "To be selected - " + value );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim();
                        if ( elementText.equalsIgnoreCase( value ) ) {
                            dropDownValue.click();
                        }
                    }

                    break;
                case UserConstants.HAS_ECONOMIC_DISADVANTAGE:
                    SMUtils.scrollDownPage( driver );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.scrollIntoView( driver, ddEconomicStatusUpdateStudent );
                    SMUtils.waitForElement( driver, ddEconomicStatusUpdateStudent );
                    SMUtils.clickJS( driver, ddEconomicStatusUpdateStudent );
                    Log.message( "To be selected - " + value );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim();
                        if ( elementText.equalsIgnoreCase( value ) ) {
                            dropDownValue.click();
                        }

                    }

                    break;
                case UserConstants.HAS_ENGLISH_PROFICIENCY:
                    SMUtils.scrollDownPage( driver );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.scrollIntoView( driver, ddEnglishUpdateStudent );
                    SMUtils.waitForElement( driver, ddEnglishUpdateStudent );
                    SMUtils.clickJS( driver, ddEnglishUpdateStudent );
                    Log.message( "To be selected - " + value );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim();
                        if ( elementText.equalsIgnoreCase( value ) ) {
                            dropDownValue.click();
                        }
                    }

                    break;
                case UserConstants.ISMIGRANT:
                    SMUtils.scrollToBottomOfPage( driver );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.scrollToBottomOfPage( driver );
                    SMUtils.waitForElement( driver, ddMigrantUpdateStudent );
                    SMUtils.clickJS( driver, ddMigrantUpdateStudent );
                    List<String> migrant = new ArrayList<String>();
                    Log.message( "To be selected - " + value );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim();
                        if ( elementText.equalsIgnoreCase( value ) ) {
                            dropDownValue.click();
                        }
                    }

                    break;
                case UserConstants.GENDER_FIELD:
                    SMUtils.scrollDownPage( driver );
                    SMUtils.waitForElement( driver, showMoreDemographics );
                    SMUtils.clickJS( driver, showMoreDemographics );
                    SMUtils.scrollToBottomOfPage( driver );
                    SMUtils.waitForElement( driver, ddGenderUpdateStudent );
                    SMUtils.clickJS( driver, ddGenderUpdateStudent );
                    List<String> gender = new ArrayList<String>();
                    Log.message( "To be selected - " + value );
                    for ( WebElement dropDownValue : listofDropdownValues ) {
                        String elementText = dropDownValue.getText().trim();
                        gender.add( elementText );
                        if ( elementText.equalsIgnoreCase( value ) ) {
                            dropDownValue.click();
                        }
                    }
                    break;

            }
        } catch ( Exception e ) {
            Log.message( "Given value already selected" );
        }

    }

    /**
     * To getDisabilityStatusValues
     * 
     * @param disability
     */
    public List<String> getDisabilityStatusValues() {
        SMUtils.scrollDownPage( driver );
        SMUtils.waitForElement( driver, showMoreDemographics );
        SMUtils.clickJS( driver, showMoreDemographics );
        SMUtils.scrollIntoView( driver, dddisabilityStatusUpdateStudent );
        SMUtils.waitForElement( driver, dddisabilityStatusUpdateStudent );
        SMUtils.clickJS( driver, dddisabilityStatusUpdateStudent );
        List<String> disability = new ArrayList<String>();
        for ( WebElement dropDownValue : listofDropdownValues ) {
            String elementText = dropDownValue.getText().trim();
            disability.add( elementText );

        }
        return disability;

    }

    /**
     * To getGenderValues
     * 
     * @param gender
     */

    public List<String> getGenderValues() {
        SMUtils.scrollDownPage( driver );
        SMUtils.waitForElement( driver, showMoreDemographics );
        SMUtils.clickJS( driver, showMoreDemographics );
        SMUtils.scrollToBottomOfPage( driver );
        SMUtils.waitForElement( driver, ddGenderUpdateStudent );
        SMUtils.clickJS( driver, ddGenderUpdateStudent );
        List<String> gender = new ArrayList<String>();
        /*
         * for ( int i = 0; i < listofDropdownValues.size(); i++ ) { String
         * elementText = listofDropdownValues.get( i ).getText(); gender.add(
         * elementText );
         * 
         * } return gender;
         */
        for ( WebElement dropDownValue : listofDropdownValues ) {
            String elementText = dropDownValue.getText().trim();
            gender.add( elementText );

        }
        return gender;
    }

    /**
     * To getEconomicValues
     * 
     * @param socioeconomic
     */
    public List<String> getEconomicValues() {
        SMUtils.scrollDownPage( driver );
        SMUtils.waitForElement( driver, showMoreDemographics );
        SMUtils.clickJS( driver, showMoreDemographics );
        SMUtils.scrollIntoView( driver, ddEconomicStatusUpdateStudent );
        SMUtils.waitForElement( driver, ddEconomicStatusUpdateStudent );
        SMUtils.clickJS( driver, ddEconomicStatusUpdateStudent );
        List<String> socioeconomic = new ArrayList<String>();
        for ( WebElement dropDownValue : listofDropdownValues ) {
            String elementText = dropDownValue.getText().trim();
            socioeconomic.add( elementText );

        }
        return socioeconomic;
    }

    /**
     * To getHasEnglishValues
     * 
     * @param english
     */

    public List<String> getHasEnglishValues() {
        SMUtils.scrollDownPage( driver );
        SMUtils.waitForElement( driver, showMoreDemographics );
        SMUtils.clickJS( driver, showMoreDemographics );
        SMUtils.scrollIntoView( driver, ddEnglishUpdateStudent );
        SMUtils.waitForElement( driver, ddEnglishUpdateStudent );
        SMUtils.clickJS( driver, ddEnglishUpdateStudent );
        List<String> english = new ArrayList<String>();
        for ( WebElement dropDownValue : listofDropdownValues ) {
            String elementText = dropDownValue.getText().trim();
            english.add( elementText );

        }
        return english;
    }

    /**
     * To getMigrantValues
     * 
     * 
     */

    public List<String> getMigrantValues() {
        SMUtils.scrollToBottomOfPage( driver );
        SMUtils.waitForElement( driver, showMoreDemographics );
        SMUtils.clickJS( driver, showMoreDemographics );
        SMUtils.scrollToBottomOfPage( driver );
        SMUtils.waitForElement( driver, ddMigrantUpdateStudent );
        SMUtils.clickJS( driver, ddMigrantUpdateStudent );
        List<String> migrant = new ArrayList<String>();
        for ( WebElement dropDownValue : listofDropdownValues ) {
            String elementText = dropDownValue.getText().trim();
            migrant.add( elementText );

        }
        return migrant;
    }

    /**
     * To click SubNavigation from edit student section Possible Values [ Groups
     * / User Profile ]
     * 
     * @param subNav
     */
    public void clickSubNavigation( String subNav ) {
        String[] possibleValues = { "Groups", "Assignments", "Mastery", "User Profile" };
        if ( Arrays.asList( possibleValues ).contains( subNav ) ) {
            SMUtils.waitForElement( driver, headerText );
            for ( WebElement ele : listSideNvaBar ) {
                if ( ele.getText().trim().equals( subNav ) )
                    //ele.click();
                    SMUtils.click( driver, ele );
            }
            Log.message( subNav + " sub tab is clicked" );
        } else {
            Log.fail( "Invalid SubNavigation passed to the method: " + subNav );
        }
    }

    /**
     * To find group name is mapped to the student
     * 
     * @return
     */
    public Boolean isGroupnamePresent( String groupName ) {
        SMUtils.nap( 2 ); //Waiting to disappear the loading icon
        Boolean status = false;
        for ( WebElement ele : lblGroupName ) {
            SMUtils.scrollWebElementToView( driver, ele );
            if ( ele.getText().trim().equals( groupName ) )
                status = true;
            ;
        }

        return status;
    }

    /**
     * To get the ellipsis menu root element
     * 
     * @param studentID
     * @return
     */

    private WebElement getEllipsisMenuRootElement( String studentUsernames ) {
        SMUtils.nap( 2 ); //Waiting to disappear the loading icon
        WebElement ellipsisMenusParentRoot = null;
        for ( int index = 0; index < listStudentUsernames.size(); index++ ) {
            WebElement tdElement = listStudentUsernames.get( index );
            String elementText = tdElement.getText().trim();
            if ( elementText.trim().equals( studentUsernames ) ) {
                WebElement parentElement = tdElement.findElement( By.xpath( "./.." ) );
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript( "arguments[0].scrollIntoView(true)", parentElement );
                WebElement ellipsisGrandRoot = parentElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) );
                SMUtils.scrollWebElementToView( driver, ellipsisGrandRoot );
                WebElement ellipsisParentRoot = SMUtils.getWebElementDirect( driver, ellipsisGrandRoot, elliipsisParentRootCSS );
                SMUtils.nap( 5 );
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, ellipsisParentRoot, ellipsisDotCSS ) );
                SMUtils.nap( 1 );//Waiting to disappear the toast message
                ellipsisMenusParentRoot = SMUtils.getWebElementDirect( driver, ellipsisGrandRoot, ellipsisMenuRootCSS );
                break;
            }
        }
        return ellipsisMenusParentRoot;
    }

    /**
     * To get all the students from student listing page. To Verify whether
     * student not present
     * 
     * @param username
     * @return
     */
    public Boolean isStudentNotPresent( String username ) {
        return ( getAllStudentsUserNames().contains( username ) ) ? false : true;
    }

    /**
     * To Validate the Error Message
     * 
     * @param Error Message
     * @return
     */

    public Boolean validateErrorMessage( String message ) {
        SMUtils.nap( 2 );
        Boolean status = false;
        for ( WebElement errorMessage : ErrorMessages ) {
            String err = errorMessage.getText();
            if ( err.equals( message ) ) {
                status = true;
                Log.message( "Validation Completed" );
                break;
            }
        }
        return status;
    }

    /**
     * To find whether POP UP is Displayed
     * 
     * 
     * @return
     * @throws Exception
     */

    public Boolean isCreateStudentPopUpDisplayed() throws Exception {
        Boolean status = false;
        SMUtils.waitForElement( driver, formCreateStudentPopup );
        try {
            SMUtils.isElementPresent( formCreateStudentPopup );
            status = true;
        } catch ( Exception e ) {
            Log.message( "Student Popup not Displayed" );
            Log.exception( e, driver );
        }
        return status;

    }

    /**
     * To create student with blank fields and validate error message
     * 
     * @param Text Field
     * 
     */

    public void createStudentwithBlankFields( String field ) throws Exception {
        SMUtils.nap( 0.5 ); //Waiting to disappear the loading icon
        clikAddStudentInStudentListingPage();
        SMUtils.waitForElement( driver, formCreateStudentPopup );
        if ( !formCreateStudentPopup.isDisplayed() ) {
            throw new Exception( "Create Student pop not visible" );
        }

        Faker studentDetails = new Faker();
        String firstName = studentDetails.name().firstName();
        String studentID = firstName + System.nanoTime();

        if ( field.equalsIgnoreCase( "firstName" ) ) {
            txtboxLastName.sendKeys( studentDetails.name().lastName() );
            txtboxStudentID.sendKeys( studentID );
            txtboxUserName.sendKeys( studentID );
            txtboxFirstName.click();
            txtboxUserName.click();
            Log.message( "First Name Passed Successfully" );
        } else if ( field.equalsIgnoreCase( "lastName" ) ) {
            txtboxFirstName.sendKeys( studentDetails.name().firstName() );
            txtboxStudentID.sendKeys( studentID );
            txtboxUserName.sendKeys( studentID );
            txtboxLastName.click();
            txtboxFirstName.click();
            Log.message( "Last Name Passed Successfully" );
        } else if ( field.equalsIgnoreCase( "userName" ) ) {
            txtboxFirstName.sendKeys( studentDetails.name().firstName() );
            txtboxLastName.sendKeys( studentDetails.name().lastName() );
            txtboxStudentID.sendKeys( studentID );
            txtboxUserName.click();
            txtboxFirstName.click();
            Log.message( "First Name Passed Successfully" );
        } else if ( field.equalsIgnoreCase( "studentID" ) ) {
            txtboxFirstName.sendKeys( studentDetails.name().firstName() );
            txtboxLastName.sendKeys( studentDetails.name().lastName() );
            txtboxUserName.sendKeys( studentID );
            txtboxStudentID.click();
            txtboxUserName.click();
            Log.message( "Student ID passed Successfully" );
        }

        txtboxPassWord.sendKeys( studentID );
        txtboxConfirmPassword.sendKeys( studentID );
        btnCreateStudent.click();

    }

    /**
     * Click the Add Student Button in Add Student Popup windows
     */
    public void clickAddStudentinAddStudentPopup() {
        WebElement addButton = SMUtils.getWebElementDirect( driver, AddStudentButtonRoot, "button" );
        SMUtils.click( driver, addButton );

    }

    @IFindBy ( how = How.CSS, using = "div.create-student-container cel-button.create-student-button:nth-of-type(2)" )
    WebElement AddStudentButtonRoot;

    /**
     * To Enter student Details alone
     * 
     * 
     * @return
     */

    public String enterOnlyStudentDetails() throws Exception {
        SMUtils.nap( 1 ); //Waiting to disappear the grade and demographics to load
        SMUtils.waitForElement( driver, formCreateStudentPopup, 10 );
        if ( !formCreateStudentPopup.isDisplayed() ) {
            throw new Exception( "Create Student pop not visible" );
        }
        Faker studentDetails = new Faker();
        String firstName = studentDetails.name().firstName();
        String studentID = firstName + System.nanoTime();
        txtboxFirstName.sendKeys( studentDetails.name().firstName() );
        txtboxLastName.sendKeys( studentDetails.name().lastName() );
        SMUtils.waitForElement( driver, ddGradeSelection );
        ddGradeSelection.click();
        selectGrade( "Grade 1" );
        txtboxDatOfBirth.sendKeys( "11/20/2010" );
        txtboxStudentID.sendKeys( studentID );
        txtboxUserName.sendKeys( studentID );
        txtboxPassWord.sendKeys( RBSDataSetupConstants.DEFAULT_PASSWORD );
        txtboxConfirmPassword.sendKeys( RBSDataSetupConstants.DEFAULT_PASSWORD );
        Log.message( "Student Details Entered Successfully" );
        return studentID;
    }

    /**
     * To Rename the Text Fields
     * 
     * @return
     */

    public String reNameTextFields( String valueToReplace, String FieldName ) {

        if ( FieldName.contains( "studentId" ) ) {
            SMUtils.waitForElement( driver, txtboxStudentID );
            txtboxStudentID.clear();
            txtboxStudentID.sendKeys( valueToReplace );
            Log.message( "StudentID Replaced Successfully" );
        } else if ( FieldName.contains( "firstName" ) ) {
            SMUtils.waitForElement( driver, txtboxFirstName );
            txtboxFirstName.clear();
            txtboxFirstName.sendKeys( valueToReplace );
            Log.message( "FirstName Replaced Successfully" );
        } else if ( FieldName.contains( "lastName" ) ) {
            SMUtils.waitForElement( driver, txtboxLastName );
            txtboxLastName.clear();
            txtboxLastName.sendKeys( valueToReplace );
            Log.message( "LastName Replaced Successfully" );
        } else if ( FieldName.contains( "userName" ) ) {
            SMUtils.waitForElement( driver, txtboxUserName );
            txtboxUserName.clear();
            txtboxUserName.sendKeys( valueToReplace );
            Log.message( "UserName Replaced Successfully" );
        } else if ( FieldName.contains( "ConfirmPassword" ) ) {
            SMUtils.waitForElement( driver, txtboxConfirmPassword );
            txtboxConfirmPassword.clear();
            txtboxConfirmPassword.sendKeys( valueToReplace );
            Log.message( "ConfirmPassword Replaced Successfully" );
        }
        return valueToReplace;
    }

    /**
     * Pass invalid Date Format
     * 
     * @param invalidDate
     * @return
     */

    public String enterDOB( String date ) {
        SMUtils.waitForElement( driver, txtboxDatOfBirth );
        txtboxDatOfBirth.clear();
        txtboxDatOfBirth.sendKeys( date );
        Log.message( "Entered date: " + date );
        return date;
    }

    /**
     * To Click Create Button
     * 
     */
    public void clickcreateStudentButton() {
        SMUtils.waitForElement( driver, btnCreateStudent );
        SMUtils.clickJS( driver, btnCreateStudent );
        Log.message( "Create Student Button CLicked" );
    }

    /**
     * To click clickShowMoreDemographics
     * 
     */
    public void clickShowMoreDemographics() {
        SMUtils.waitForElement( driver, showMoreDemographics );
        SMUtils.clickJS( driver, showMoreDemographics );
        Log.message( "Show More Demographics clicked Successfully" );
    }

    /**
     * Get Number of text fields
     * 
     * 
     * @return
     */
    public int getSizeofTextFieldsCreatePopup() {

        int size = textFieldNames.size();
        for ( WebElement name : textFieldNames ) {

            Log.message( name.getText() );
        }
        Log.message( "Size of TextFieldsCreatePopup Fetched Successfully" );
        return size;
    }

    /**
     * To Get Elements of Text Fields
     * 
     * @return
     */
    public List<WebElement> getElementsofTextFields() {
        List<WebElement> textFieldElements = textFieldNames;
        Log.message( "Elements of TextField Fetched Successfully" );
        return textFieldElements;
    }

    /**
     * To click clickHideMoreDemographics
     */
    public void clickHideMoreDemographics() {
        SMUtils.waitForElement( driver, hideMoreDemographics );
        SMUtils.clickJS( driver, hideMoreDemographics );
    }

    /**
     * To click CancelButton
     */
    public void clickCancelButtonInCreateStudentPopup() {
        // Clicking Cancel Button
        SMUtils.waitForElement( driver, btnCancelStudentCreation );
        SMUtils.clickJS( driver, btnCancelStudentCreation );
        Log.message( "Cancel Button clicked Successfully" );

    }

    /**
     * To get all field names under show more demo
     */
    public List<String> getFieldNamesShowMore() {
        int sizeOfTextField_AfterClickingShowMore = getSizeofTextFieldsCreatePopup();
        List<String> textfieldsUnderShowMoreOption = new ArrayList<>();
        for ( int i = 11; i < sizeOfTextField_AfterClickingShowMore; i++ ) {
            WebElement eachFieldUnderShowMore = getElementsofTextFields().get( i );
            String fieldName = eachFieldUnderShowMore.getText();
            textfieldsUnderShowMoreOption.add( fieldName );
            Log.message( "Field Values Fetched Successfully" );
        }
        return textfieldsUnderShowMoreOption;
    }

    /**
     * To click on the hovered student
     * 
     * @param studentId
     * @return
     */
    public void clickOnTheHoveredStudent( String studentId ) {
        //This nap is required for Safari
        SMUtils.nap( 5 );
        try {
            listStudentID.stream().forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( studentIdDetail -> {
                if ( studentId.equals( studentIdDetail ) ) {
                    SMUtils.moveToElementSelenium( driver, element );
                    SMUtils.clickJS( driver, element );
                }
            } ) );
        } catch ( StaleElementReferenceException | NoSuchElementException e ) {
            Log.message( "Student selected is " + studentId );
        }
    }

    /**
     * To click on the hovered student
     * 
     * @param studentUserName
     * @return
     */
    public void clickOnTheHoveredStudentUserName( String studentUserName ) {
        //This nap is required for Safari
        SMUtils.nap( 5 );
        try {
            listStudentUsernames.stream().forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( studentUserNameDetail -> {
                if ( studentUserName.equals( studentUserNameDetail ) ) {
                    SMUtils.moveToElementSelenium( driver, element );
                    SMUtils.clickJS( driver, element );
                }
            } ) );
        } catch ( StaleElementReferenceException | NoSuchElementException e ) {
            Log.message( "Student selected is " + studentUserName );
        }
    }

    /**
     * To check No data Message Displayed on the Student Progress graph
     * 
     * 
     */

    public void isNoDataTextDisplayedOnStudentProgressGraph() throws Exception {
        Boolean status = false;
        SMUtils.waitForElement( driver, noDataForStudentProgress );
        try {
            noDataForStudentProgress.isDisplayed();
            status = true;
            Log.message( "No Data Text Found" );

        } catch ( Exception e ) {
            Log.message( "No Data Text Not Found" );
            Log.exception( e, driver );
        }

    }

    /**
     * To get No data Text
     * 
     * @return
     */

    public String getNoDataTextFromStudentProgress() throws Exception {
        String text = null;
        SMUtils.waitForElement( driver, noDataForStudentProgress );
        try {
            text = noDataForStudentProgress.getText();
            Log.message( "Message Fetched Successfully" );

        } catch ( Exception e ) {
            Log.message( "No Data Message Not Found" );
            Log.exception( e );
        }
        return text;

    }

    /**
     * To Click View Details Link
     * 
     */

    public void clickViewDetails() {
        SMUtils.waitForElement( driver, viewDetailsLink );
        SMUtils.clickJS( driver, viewDetailsLink );
        Log.message( "View Details Link Clicked Successfully" );
    }

    /**
     * To get Text In Assignment Details Page
     * 
     * @return
     */

    public String getSkillsTestedTextInAssignmentDetailsPage() {
        String title = null;
        try {
            SMUtils.waitForElement( driver, skillTestedAlternate, 8 );
            title = skillTestedAlternate.getText();
        } catch ( Exception e ) {
            SMUtils.waitForElement( driver, skillTestedTextInAssignmentDetailsPage, 8 );
            title = skillTestedTextInAssignmentDetailsPage.getText();
        }
        return title;
    }

    /**
     * To get Default Subject From ProgressDropDown
     * 
     * @return
     */

    public String getDefaultSubjectFromProgressDropDown() {
        SMUtils.waitForElement( driver, progressDropDownDefaultSubject );
        String defaultSubject = progressDropDownDefaultSubject.getText();
        Log.message( "Default DropDown Value Fetched Successfully - " + defaultSubject );
        return defaultSubject;
    }

    /**
     * To get size of YAxis Values in Graph
     * 
     * @return
     */

    public int getSizeOfYAxisValues() {
        SMUtils.nap( 2 );// wait for page to load
        int sizeOfYAxisValues = studentProgressBarYAxisValues.size();
        Log.message( "Y Axis Size Fetched Successfully" );
        return sizeOfYAxisValues;
    }

    /**
     * To verify the assignment present in the DropDown of student progress
     * graph
     * 
     * @return
     */

    public Boolean isSubjectAvailableFromTheProgressDropDown( String SubjectToCheck ) throws Exception {
        SMUtils.nap( 2 );// wait for page to load
        Boolean status = false;
        try {
            for ( int subject = 0; subject < studentGraphDropDownValues.size(); subject++ ) {
                String eachSubject = studentGraphDropDownValues.get( subject ).getText();
                if ( eachSubject.equals( SubjectToCheck ) ) {
                    status = true;
                    Log.message( "Subject Found in the Drop Down" );
                    break;
                }
            }
        } catch ( Exception e ) {
            Log.message( "Subject Not Found" );
            Log.exception( e, driver );
        }
        return status;
    }

    /**
     * To Select the assignment present in the DropDown of student progress
     * graph
     * 
     */

    public void selectSubjectFromStudentProgressDropDown( String SubjectToCheck ) throws Exception {

        SMUtils.waitForElement( driver, progressDropDownDefaultSubject );
        try {
            for ( int subject = 0; subject < studentGraphDropDownValues.size(); subject++ ) {
                WebElement eachSubject = studentGraphDropDownValues.get( subject );
                String subjectName = eachSubject.getText();
                if ( subjectName.equals( SubjectToCheck ) ) {
                    SMUtils.clickJS( driver, eachSubject );
                    Log.message( "Subject Found in the Drop Down" );
                    break;
                }
            }
        } catch ( Exception e ) {
            Log.message( "Subject Not Found" );
            Log.exception( e, driver );
        }
    }

    /**
     * To sort the Student ID column
     */
    public void sortStudentId() {
        try {
            SMUtils.clickJS( driver, sortbyStudentID );
        } catch ( NoSuchElementException e ) {
            Log.message( "Page refreshed" );
        }
    }

    /**
     * To verify LeftSide Fields On ProgressGraph
     * 
     */

    public Boolean verifyLeftSideFieldsOnProgressGraph( String fieldName ) {
        SMUtils.nap( 2 );// wait for page to load
        Boolean status = false;
        for ( int field = 0; field < leftSideFields.size(); field++ ) {
            String nameOfField = leftSideFields.get( field ).getText().trim();
            if ( nameOfField.equals( fieldName ) ) {
                Log.message( " " + fieldName + " is Available in the Student Progress Graph" );
                status = true;
                break;
            }
        }
        return status;
    }

    /**
     * To Click Dropdown button on the student progress graph
     * 
     */

    public void clickDropDownInStudentProgressgraph() {
        SMUtils.waitForElement( driver, studentGraphDropDownButton );
        SMUtils.clickJS( driver, studentGraphDropDownButton );
        Log.message( "Drop Down Button Clicked" );

    }

    /**
     * To get the starting level y axis in assignment details page
     * 
     * @return
     */

    public double getStartingLevelYAxisInStudentProgressGraph() {
        SMUtils.waitForElement( driver, firstValueOnYaxisAssignDetailsPage );
        String initialValueOfYAxis = firstValueOnYaxisAssignDetailsPage.getText().trim();
        double parseDouble = Double.parseDouble( initialValueOfYAxis );
        return parseDouble;
    }

    /**
     * To get the value of the field present in the progress graph
     * 
     * @return
     */

    public double getTheValueOfTheField( String fieldName ) {
        SMUtils.nap( 2 );// wait for page to load
        WebElement valueOfField;
        if ( fieldName.equals( "GAIN" ) ) {
            valueOfField = driver.findElement( By.xpath( "//p[text()='" + fieldName + " ']/following-sibling::p" ) );
        } else {
            valueOfField = driver.findElement( By.xpath( "//p[text()='" + fieldName + "']/following-sibling::p" ) );
        }
        String Stringvalue = valueOfField.getText().replace( "+", "" ).trim();
        double parseDouble = Double.parseDouble( Stringvalue );
        return parseDouble;
    }

    /**
     * To verify the gain field
     * 
     * @return
     */

    public Boolean verifyTheGainField() {
        final DecimalFormat df = new DecimalFormat( "0.00" );
        Boolean status = false;
        double gainValue = getTheValueOfTheField( "GAIN" );
        double currentLevelValue = getTheValueOfTheField( "CURRENT LEVEL" );
        double iPLevelValue = getTheValueOfTheField( "IP LEVEL" );
        double ans = currentLevelValue - iPLevelValue;
        String actual = df.format( ans );
        double parseDouble1 = Double.parseDouble( actual );
        if ( gainValue == parseDouble1 ) {
            status = true;
            Log.message( "Gain Value is the diff of Current Value and Ip Value" );
        }
        return status;
    }

    /**
     * To verify the tool tip
     * 
     * @return
     */

    public Boolean verifyToolTip( String courseName ) {
        Boolean status = false;
        for ( int title = 0; title < toolTipValuesInDropDown.size(); title++ ) {
            WebElement eachToolTip = toolTipValuesInDropDown.get( title );
            String eachValue = eachToolTip.getText().replace( ".", "" ).trim();
            if ( courseName.contains( eachValue ) ) {
                Log.message( "Tool Tip is Found for the Assignment :" + courseName + " " );
                status = true;
                break;
            }
        }
        return status;
    }

    /**
     * To click Elipsis Button Of Assignment in student details page
     */

    public void clickElipsisButtonOfAssignment( String assignmentName ) {
        SMUtils.nap( 2 );// wait for page to load
        try {
            WebElement parentElement = driver.findElement( By.xpath( "//span[text()='" + assignmentName + "']/ancestor::td/following-sibling::td[7]/child::cel-button-menu" ) );
            WebElement webElementDirect = SMUtils.getWebElementDirect( driver, parentElement, elipsisChild );
            SMUtils.clickJS( driver, webElementDirect );
            Log.message( " " + assignmentName + " Ellipsis Button Clicked" );
        } catch ( Exception e ) {
            Log.message( "Not Clicked" );
        }

    }

    /**
     * To click Pause Button Option On AssignmentTab
     */

    public void clickPauseButtonOptionOnAssignmentTab( String assignmentName ) {
        try {
            WebElement parentElement = driver.findElement( By.xpath( "//span[text()='" + assignmentName + "']/ancestor::td/following-sibling::td[7]/child::cel-button-menu" ) );
            WebElement parentRootBtn = SMUtils.getWebElementDirect( driver, parentElement, pauseBtnChild );
            WebElement assignmentOption = SMUtils.getWebElementDirect( driver, parentRootBtn, pauseBtnGrandChild );
            SMUtils.clickJS( driver, assignmentOption );
            Log.message( " " + assignmentName + " Pause Assignment Button clicked Button Clicked" );
        } catch ( Exception e ) {
            Log.message( "Not Clicked" );
        }
    }

    /**
     * To verify the Student ID from the User profile section of the student
     * 
     * @param studentName
     * 
     * @return
     */
    public boolean verifyStudentIdInProfile( String studentID ) {
        SMUtils.waitForElement( driver, userProfileStudentId, 4 );
        return studentID.equals( userProfileStudentId.getAttribute( "value" ) );
    }

    /**
     * Clicking add student to assignment.
     * 
     * @param studentID
     * @return add student to assignment popup
     */
    public AddStudentToAssignmentPopup clickAddStudentToAssignment( String studentID ) {
        try {
            WebElement ellipsisRootMenu = getEllipsisMenuRootElement( studentID );
            SMUtils.clickJS( driver, SMUtils.getWebElement( driver, ellipsisRootMenu, ellipsisAddtoAssignment ) );
            SMUtils.nap( 3 ); //Waiting to disappear the loading icon
            Log.message( "Clicked on Add student to the Assignment from the Ellipsis menu for the student: " + studentID );
            return new AddStudentToAssignmentPopup( driver );
        } catch ( Exception e ) {
            if ( new AddStudentToAssignmentPopup( driver ).getAddStudentToAssignmentTitle().trim().equals( UserUIConstants.ADD_STUDENT_TO_ASSIGNMENT_TITLE.trim() ) ) {
                return new AddStudentToAssignmentPopup( driver );
            } else {
                Log.message( "Error in loading the add student to assignment popup", driver );
                return null;
            }
        }
    }

    /**
     * Add student to assignment using assignment button.
     * 
     * @return
     */
    public AddStudentToAssignmentPopup addStudentToAssignmentButton() {
        selectAllStudents();
        clickAssignmentButton();
        SMUtils.nap( 3 ); //Waiting to disappear the loading icon
        return new AddStudentToAssignmentPopup( driver );
    }

    /**
     * Sort by user ID
     */
    public void sortByUserID() {
        sortbyStudentID.click();
    }

    /**
     * To remove assignment from student page
     * 
     * @return
     */
    public void removeStudentFromAssignment( String assignmentName ) {
        SMUtils.waitForElement( driver, assignmentNames );
        for ( WebElement trElement : assignmentListRoot ) {
            WebElement lblAssignmentName = trElement.findElement( By.cssSelector( lblAssignmentsName ) );
            if ( lblAssignmentName.getText().trim().equals( assignmentName ) ) {
                SMUtils.scrollIntoView( driver, lblAssignmentName );
                WebElement elipsis = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), elliipsisParentRootCSS );
                SMUtils.clickJS( driver, elipsis );
                WebElement removeStudentFromAssignment = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), ellipsisMenuRootCSS, menuRemovestudentFromAssignment );
                SMUtils.clickJS( driver, removeStudentFromAssignment );
                SMUtils.clickJS( driver, getButtonsFromPopup( "Remove" ) );
                Log.message( assignmentName + " assignment removed to student sucesfully!" );
                SMUtils.nap( 2 ); //required for page refresh
                break;
            }
        }
    }

    /**
     * To get Remove and Cancel buttons from popup
     * 
     * @return
     */
    public WebElement getButtonsFromPopup( String buttonName ) {
        WebElement popupButton = null;
        SMUtils.waitForElement( driver, popupHeader );
        for ( WebElement buttonRoot : PopupButtonsRoot ) {
            if ( buttonRoot.getText().trim().equals( buttonName ) ) {
                popupButton = SMUtils.getWebElementDirect( driver, buttonRoot, popupButtonChild );
                break;
            }
        }
        return popupButton;
    }

    /**
     * To verify field under Student usage chart
     * 
     * @return
     */
    public boolean verifyStudentUsageChart() {
        try {
            SMUtils.waitForElement( driver, studentUsagechartRoot );
            WebElement parentElement = studentUsagechartRoot.findElement( By.xpath( "./.." ) );
            WebElement lblheader = parentElement.findElement( By.cssSelector( lblStudentUsageHeader ) );
            if ( lblheader.getText().trim().equals( Constants.UsageChart.STUDENT_USAGE_HEADER ) ) {
                Log.pass( "Student usage header " + "\"" + Constants.UsageChart.STUDENT_USAGE_HEADER + "\"" + " displayed successfully!" );
            } else {
                Log.fail( "Student usage header is not displayed properly! - " + lblheader.getText(), driver );
            }

            Constants.UsageChart.USAGE_FIELDS.forEach( usageField -> {
                String txtUsageField = lblUsageFields.stream().filter( lblUsageField -> lblUsageField.getText().trim().equals( usageField ) ).map( WebElement::getText ).findAny().orElse( null );
                if ( Objects.nonNull( txtUsageField ) ) {
                    Log.pass( txtUsageField + "  is displayed successfully!" );
                } else {
                    Log.fail( usageField + "  is not displayed properly!" );
                }
            } );

            Constants.UsageChart.LEGENDS.forEach( legend -> {
                String txtlegend = lblStudentUsageLegends.stream().filter( lbllegend -> lbllegend.getText().trim().equals( legend ) ).map( WebElement::getText ).findAny().orElse( null );
                if ( Objects.nonNull( txtlegend ) ) {
                    Log.pass( txtlegend + "  is displayed successfully!" );
                } else {
                    Log.fail( txtlegend + "  is not displayed properly!" );
                }
            } );

            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify zero state for student usage chart
     *
     * @return
     */
    public boolean verifyZeroStateForStudentUsageChart() {
        try {
            SMUtils.waitForElement( driver, studentUsgechartHeader );
            for ( WebElement chartheader : lblstudentUsagechartForZeroState ) {
                if ( chartheader.getText().trim().equals( Constants.UsageChart.STUDENT_USAGE_HEADER ) ) {
                    Log.pass( "Student usage header " + "\"" + Constants.UsageChart.STUDENT_USAGE_HEADER + "\"" + " displayed successfully!" );
                    WebElement parentElement = chartheader.findElement( By.xpath( "./.." ) );
                    WebElement lblZeroState = parentElement.findElement( By.cssSelector( lblZeroStateMessage ) );
                    String zeroStateFromUI = lblZeroState.getText().trim();
                    if ( zeroStateFromUI.contains( Constants.UsageChart.STUDENTUSAGE_ZEROSTATEMESSAGE.get( 0 ) ) && zeroStateFromUI.contains( Constants.UsageChart.STUDENTUSAGE_ZEROSTATEMESSAGE.get( 1 ) )
                            && zeroStateFromUI.contains( Constants.UsageChart.STUDENTUSAGE_ZEROSTATEMESSAGE.get( 2 ) ) ) {
                        Log.pass( "Zero state message is displayed successfully! - " + lblZeroState.getText().trim() );
                        return true;
                    } else {
                        Log.fail( "Zero state message is not displayed successfully! - " + lblZeroState.getText().trim() );
                    }
                }
            }
            Log.fail( "Student usage header is not displayed properly! - Student Usage", driver );
            return false;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify data in student usage chart
     *
     * @return
     */
    public boolean verifyStudentUsageChartFieldsData( Map<String, Integer> individualFieldsFromAPI, boolean isStudentCrossedHours ) {
        try {
            SMUtils.waitForElement( driver, studentUsagechartRoot );
            Constants.UsageChart.USAGE_FIELDS.forEach( usageField -> {
                WebElement lblUsageField = lblUsageFields.stream().filter( txtUsageField -> txtUsageField.getText().trim().equals( usageField ) ).findAny().get();
                if ( Objects.nonNull( lblUsageField ) ) {
                    if ( lblUsageField.getText().trim().equals( usageField ) ) {
                        WebElement parentElement = lblUsageField.findElement( By.xpath( "./.." ) );
                        WebElement lblValue = parentElement.findElement( By.cssSelector( txtindividualField ) );
                        String actualValueFromUI = lblValue.getText().trim().replace( "  ", " " );
                        int expectedMins = individualFieldsFromAPI.get( usageField );
                        String expectedValue;
                        if ( isStudentCrossedHours ) {
                            if ( expectedMins == 0 ) {
                                expectedValue = Constants.UsageChart.ZERO_HOURS;
                            } else if ( expectedMins < 60 ) {
                                expectedValue = Constants.UsageChart.LESS_THAN_ONE_HOUR;
                            } else if ( expectedMins / 60 == 1 && expectedMins % 60 < 30 ) {
                                expectedValue = Constants.UsageChart.ONE_HOUR;
                            } else {
                                if ( expectedMins % 60 < 30 ) {
                                    expectedValue = String.valueOf( expectedMins / 60 ) + " " + Constants.UsageChart.HOURS.toLowerCase();
                                } else {
                                    expectedValue = String.valueOf( ( expectedMins / 60 ) + 1 ) + " " + Constants.UsageChart.HOURS.toLowerCase();
                                }
                            }
                        } else {
                            if ( expectedMins == 0 ) {
                                expectedValue = Constants.UsageChart.ZERO_MINUTES;
                            }
                            if ( expectedMins == 1 ) {
                                expectedValue = Constants.UsageChart.ONE_MINUTE;
                            } else {
                                expectedValue = String.valueOf( expectedMins ) + " " + Constants.UsageChart.MINUTES.toLowerCase();
                            }
                        }
                        if ( actualValueFromUI.equals( expectedValue ) ) {
                            Log.pass( usageField + " - " + lblValue.getText().trim() + " value  is displayed successfully!" );
                        } else {
                            Log.pass( usageField + " - " + lblValue.getText().trim() + " value  is not displayed properly!.Actual - " + expectedValue );
                        }
                    }
                } else {
                    Log.fail( usageField + " value is not displayed properly!" );
                }
            } );
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify data in student usage bar
     *
     * @return
     */
    public boolean verifyStudentUsageGraph( Map<String, HashMap<String, Integer>> usageHours, boolean isStudentCrossedHours ) {
        List<String> xAxisIntervals = getFourWeeksMonday();
        List<Double> yAxisIntervals = getYaxisIntervals( usageHours, isStudentCrossedHours );
        try {
            SMUtils.waitForElement( driver, studentUsagechartRoot );
            if ( isStudentCrossedHours ) {
                if ( lblYaxis.getText().trim().equals( Constants.UsageChart.HOURS ) ) {
                    Log.pass( "Y axis label " + "\"" + Constants.UsageChart.HOURS + "\"" + " displayed successfully!" );
                } else {
                    Log.fail( "Y axis label is not displayed properly! - " + lblYaxis.getText().trim(), driver );
                }
            } else {
                if ( lblYaxis.getText().trim().equals( Constants.UsageChart.MINUTES ) ) {
                    Log.pass( "Y axis label " + "\"" + Constants.UsageChart.MINUTES + "\"" + " displayed successfully!" );
                } else {
                    Log.fail( "Y axis label is not displayed properly! - " + lblYaxis.getText().trim(), driver );
                }
            }

            xAxisIntervals.forEach( xAxisInterval -> {
                String txtInterval = lblXaxisIntervals.stream().filter( lblXaxisInterval -> lblXaxisInterval.getText().equals( xAxisInterval ) ).map( WebElement::getText ).findAny().orElse( null );
                if ( Objects.nonNull( txtInterval ) ) {
                    Log.pass( txtInterval + "  is present in the x axis intervals!" );
                } else {
                    Log.fail( xAxisInterval + "  is not present in the x axis intervals!" );
                }
            } );

            yAxisIntervals.forEach( yAxisInterval -> {
                String txtInterval = lblYaxisIntervals.stream().filter( lblYaxisInterval -> Double.valueOf( lblYaxisInterval.getText().trim() ) >= yAxisInterval - 0.1 && Double.valueOf( lblYaxisInterval.getText().trim() ) <= yAxisInterval + 0.1 ).map(
                        WebElement::getText ).findAny().orElse( null );
                if ( Objects.nonNull( txtInterval ) ) {
                    Log.pass( txtInterval + "  is present in the y axis intervals!" );
                } else {
                    Log.fail( yAxisInterval + "  is not present in the y axis intervals!" );
                }
            } );

            if ( verifyStudentUsageBarMathData( usageHours, isStudentCrossedHours ) ) {
                Log.pass( "All math usage hours are displayed properly." );
            } else {
                Log.fail( "Math usage hours are not displayed properly!" );
            }

            if ( verifyStudentUsageBarReadingData( usageHours, isStudentCrossedHours ) ) {
                Log.pass( "All reading usage hours are displayed properly." );
            } else {
                Log.fail( "Reading usage hours are not displayed properly!" );
            }

            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify data in student usage bar for math
     *
     * @return
     */
    public boolean verifyStudentUsageBarMathData( Map<String, HashMap<String, Integer>> usageHours, boolean isStudentCrossedHours ) {
        try {
            List<String> weeks = getFourWeeksMonday();
            Collections.reverse( weeks );
            Iterator<String> weeksList = weeks.iterator();
            Iterator<WebElement> mathBar = mathBars.iterator();
            while ( weeksList.hasNext() && mathBar.hasNext() ) {
                WebElement bar = mathBar.next();
                String week = weeksList.next();
                if ( bar.isDisplayed() ) {
                    SMUtils.moveToElementJS( driver, bar );
                    String actualHoursFromUI = toolTipUsageChart.getText().trim().replace( " Total", Constants.UsageChart.TOTAL );
                    String expectedHours = "Math : " + convertMinutesIntoHours( usageHours.get( week ).get( Constants.UsageChart.MATH ), isStudentCrossedHours );
                    expectedHours = expectedHours.trim() + "Total : " + convertMinutesIntoHours( usageHours.get( week ).get( "Total" ), isStudentCrossedHours );
                    if ( actualHoursFromUI.equals( expectedHours.trim() ) ) {
                        Log.pass( "Expected math usage hours - " + actualHoursFromUI + " is displayed properly for " + week + " week!", driver );
                    } else {
                        Log.fail( "Expected math usage hours - " + expectedHours + " is not displayed properly for " + week + " week!. Actual - " + actualHoursFromUI, driver );
                    }
                } else {
                    if ( usageHours.get( week ).get( Constants.UsageChart.MATH ) != 0 ) {
                        Log.fail( " Math usage hours is mismatched for " + week, driver );
                    } else {
                        Log.pass( week + " week don't have Math usage data! - Expected" );
                    }
                }
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify Math Bar is Displayed or not
     * 
     * @return
     */
    public boolean isStudentUsageMathBarDisplayed() {
        return mathBars.stream().anyMatch( WebElement::isDisplayed );
    }

    /**
     * To verify Reading Bar is Displayed or not
     * 
     * @return
     */
    public boolean isStudentUsageReadingBarDisplayed() {
        return readingBars.stream().anyMatch( WebElement::isDisplayed );
    }

    /**
     * To get the order of graph
     * 
     * @return
     */
    public List<String> getOrderOfSubjectinUsageGraph() {
        List<String> subjectOrder = new ArrayList<>();
        mathandReadingBars.stream().forEach( element -> {
            if ( element.getAttribute( "fill" ).trim().equals( "#32325D" ) ) {
                subjectOrder.add( Constants.READING );
            }
            if ( element.getAttribute( "fill" ).trim().equals( "#9ECA47" ) ) {
                subjectOrder.add( Constants.MATH );
            }
        } );
        return subjectOrder;
    }

    /**
     * To get the Legends in usage chart
     * 
     * @return
     */
    public List<String> getLegends() {
        return lblStudentUsageLegends.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To verify data in student usage bar for Reading
     *
     * @return
     */
    public boolean verifyStudentUsageBarReadingData( Map<String, HashMap<String, Integer>> usageHours, boolean isStudentCrossedHours ) {
        try {
            List<String> weeks = getFourWeeksMonday();
            Collections.reverse( weeks );
            Iterator<String> weeksList = weeks.iterator();
            Iterator<WebElement> readingBar = readingBars.iterator();
            while ( weeksList.hasNext() && readingBar.hasNext() ) {
                WebElement bar = readingBar.next();
                String week = weeksList.next();
                if ( bar.isDisplayed() ) {
                    SMUtils.moveToElementJS( driver, bar );
                    String actualHoursFromUI = toolTipUsageChart.getText().trim().replace( " Total", Constants.UsageChart.TOTAL );
                    String expectedHours = "Reading : " + convertMinutesIntoHours( usageHours.get( week ).get( Constants.UsageChart.READING ), isStudentCrossedHours );
                    expectedHours = expectedHours.trim() + "Total : " + convertMinutesIntoHours( usageHours.get( week ).get( Constants.UsageChart.TOTAL ), isStudentCrossedHours );
                    if ( actualHoursFromUI.equals( expectedHours.trim() ) ) {
                        Log.pass( "Expected reading usage hours - " + actualHoursFromUI + " is displayed properly for " + week + " week!", driver );
                    } else {
                        Log.fail( "Expected reading usage hours - " + expectedHours + " is not displayed properly for " + week + " week!. Actual - " + actualHoursFromUI, driver );
                    }
                } else {
                    if ( usageHours.get( week ).get( Constants.UsageChart.READING ) != 0 ) {
                        Log.fail( "Reading usage hours is mismatched for " + week, driver );
                    } else {
                        Log.pass( week + " week don't have reading usage data! - Expected" );
                    }
                }
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To convert minutes into hours and minutes
     *
     * @return
     */
    public String convertMinutesIntoHours( int minutes, boolean isStudentCrossedHours ) {
        String result = "";
        if ( isStudentCrossedHours ) {
            if ( minutes == 60 || minutes / 60 == 1 ) {
                result = result + Constants.UsageChart.ONE_HOUR + " ";
            } else if ( minutes > 60 ) {
                result = result + String.valueOf( minutes / 60 ) + " " + Constants.UsageChart.HOURS.toLowerCase() + " ";
            }
            if ( minutes == 1 ) {
                result = result + Constants.UsageChart.ONE_MINUTE;
            } else if ( minutes % 60 != 0 ) {
                result = result + minutes % 60 + " " + Constants.UsageChart.MINUTES.toLowerCase();
            }
        } else {
            if ( minutes == 1 ) {
                result = Constants.UsageChart.ONE_MINUTE;
            } else {
                result = minutes + " " + Constants.UsageChart.MINUTES.toLowerCase();
            }
        }
        return result;
    }

    /**
     * To get y axis intervals for student usage
     * 
     * @return
     */
    public List<Double> getYaxisIntervals( Map<String, HashMap<String, Integer>> usageHours, boolean isStudentCrossedHours ) {
        List<String> weeks = getFourWeeksMonday();
        List<Double> yaxisInterval = new ArrayList<>();
        if ( isStudentCrossedHours ) {
            int highestWeekMinFromAPI = weeks.stream().mapToInt( week -> usageHours.get( week ).get( Constants.UsageChart.TOTAL ) ).max().orElse( 0 );
            double highestWeekHourFromAPI = (double) highestWeekMinFromAPI / 60;
            DecimalFormat decimalFormat = new DecimalFormat( "#.#" );
            double interval = 0;
            while ( interval < highestWeekHourFromAPI ) {
                interval = interval + highestWeekHourFromAPI / 4;
                double formattedInterval = Double.valueOf( decimalFormat.format( interval ) );
                yaxisInterval.add( formattedInterval );
            }
        } else {
            yaxisInterval = Arrays.asList( 15.0, 30.0, 45.0, 60.0 );
        }
        return yaxisInterval;
    }

    /**
     * To get past four weeks Monday
     * 
     * @return
     */
    public static List<String> getFourWeeksMonday() {
        List<String> fourWeeksMonday = new ArrayList<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd" );
        Calendar weekStartDate = Calendar.getInstance();
        weekStartDate.setTime( new Date() );
        int iter = 0;
        while ( iter < 4 ) {
            if ( weekStartDate.get( Calendar.DAY_OF_WEEK ) == Calendar.SUNDAY ) {
                weekStartDate.add( Calendar.DATE, -1 );
                weekStartDate.set( Calendar.DAY_OF_WEEK, Calendar.MONDAY );
                fourWeeksMonday.add( dateFormat.format( weekStartDate.getTime() ) );
            } else {
                weekStartDate.set( Calendar.DAY_OF_WEEK, Calendar.MONDAY );
                fourWeeksMonday.add( dateFormat.format( weekStartDate.getTime() ) );
            }
            weekStartDate.add( Calendar.DATE, -7 );
            iter++;
        }
        return fourWeeksMonday;
    }

    /**
     * To click add student to group menu from ellipsis
     * 
     * @param studentID
     */
    public boolean verifyRemoveStudentToGroupText( String groupName ) {
        boolean status = false;
        SMUtils.clickJS( driver, getEllipsisMenuRootElementGroups( groupName ) );
        SMUtils.waitForElement( driver, removeStuFromGrpGrandRoot );
        WebElement removeStuSubMenuParent = SMUtils.getWebElementDirect( driver, removeStuFromGrpGrandRoot, removeStudentFromGroupParent );
        WebElement removeStuSubSubMenu = SMUtils.getWebElementDirect( driver, removeStuSubMenuParent, removeStudentFromGroupChild );
        if ( removeStuSubSubMenu.getAttribute( "aria-label" ).trim().equals( Constants.Students.removeStudentText ) ) {
            status = true;
            Log.event( "Verified remove student from text for the student who is part of : " + groupName );
        }
        return status;
    }

    /**
     * To click remove student from Group option from ellipsis
     * 
     * @param studentID
     */
    public void clickRemoveStudentToGroupText( String groupName ) {
        SMUtils.clickJS( driver, getEllipsisMenuRootElementGroups( groupName ) );
        SMUtils.waitForElement( driver, removeStuFromGrpGrandRoot );
        WebElement removeStuSubSubMenu = SMUtils.getWebElementDirect( driver, removeStuFromGrpGrandRoot, removeStudentFromGroupParent, removeStudentFromGroupChild );
        SMUtils.clickJS( driver, removeStuSubSubMenu );
        Log.message( "Clicked on Remove student from Group in Ellipsis menu for the group: " + groupName );
    }

    /**
     * To verify remove student from group popup
     * 
     * @param studentName
     * @param groupName
     * @return
     */
    public boolean verifyRemoveStudentFromGroupPopup( String studentName, String groupName ) {
        ArrayList<Boolean> removepopup = new ArrayList<Boolean>();
        Log.event( "Verifying the screen elements present in Remove Student from Group popup" );
        //SMUtils.waitForElement( driver, removeStuFromGrpTextInPopUp );
        new WebDriverWait( driver, ( Duration.ofSeconds( 20 ) ) ).until( ExpectedConditions.visibilityOfAllElements( removeStuFromGrpTextInPopUp ) );
        // Verification of header text in Remove Student from Group Popup

        removepopup.add( SMUtils.verifyWebElementTextEquals( removeStuFromGrpTextInPopUp, Constants.Students.removeStudentText ) );

        // Verification of description text in Remove Student from Group Popup

        removepopup.add( SMUtils.verifyWebElementTextEquals( removeStuFromGrpMessagetInPopUp, String.format( Constants.Students.removeStudentMessage, studentName, groupName ) ) );

        // Verification of Close icon in Remove Student from Group popup
        removepopup.add( closeIconInPopup.isDisplayed() );

        // Verification of cancel button    
        removepopup.add( removeAndCancelButton( "Cancel" ).isDisplayed() );

        // Verification of Remove button
        removepopup.add( removeAndCancelButton( "Remove" ).isDisplayed() );

        return SMUtils.isAllValueTrue( removepopup );
    }

    /**
     * To Click Remove button in Remove Student from Group popup.
     */
    public void clickRemoveButtonInPopup() {
        WebElement removeButton = removeAndCancelButton( Constants.Students.removeText );
        SMUtils.waitForElement( driver, removeButton );
        Log.event( "Clicking on 'Remove' button in pop up modal" );
        SMUtils.clickJS( driver, removeButton );
        Log.message( "Clicked Remove button in Remove Student from Group popup" );
    }

    /**
     * To Click Cancel button in Remove Student from Group popup.
     */
    public void clickCancelButtonInPopup() {
        WebElement cancelButton = removeAndCancelButton( Constants.Students.cancelText );
        SMUtils.waitForElement( driver, cancelButton );
        Log.event( "Clicking on 'Cancel' button in pop up modal" );
        SMUtils.clickJS( driver, cancelButton );
        Log.message( "Clicked Cancel button in Remove Student from Group popup" );
    }

    /**
     * To Click Close icon in Remove Student from Group popup.
     */
    public void clickCloseIconInPopup() {
        SMUtils.waitForElement( driver, closeIconInPopup );
        Log.event( "Clicking on Close icon in pop up modal" );
        WebElement xIcon = SMUtils.getWebElement( driver, closeIconInPopup, xIconInPopup );
        SMUtils.clickJS( driver, xIcon );
        Log.message( "Clicked close icon in Remove Student from Group popup" );
    }

    /**
     * To get the ellipsis menu root element in Groups section
     * 
     * @param studentID
     * @return
     */

    private WebElement getEllipsisMenuRootElementGroups( String GroupName ) {
        SMUtils.nap( 2 );// wait for page to load
        WebElement ellipsisMenusParentRoot = null;
        for ( int i = 0; i < lblGroupName.size(); i++ ) {
            WebElement tdElement = lblGroupName.get( i );
            String elementText = tdElement.getText().trim();
            if ( elementText.equals( GroupName ) ) {
                WebElement parentElement = tdElement.findElement( By.xpath( "./.." ) );
                WebElement ellipsisGrandRoot = parentElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) );
                WebElement ellipsisParentRoot = SMUtils.getWebElementDirect( driver, ellipsisGrandRoot, elliipsisParentRootCSS );
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, ellipsisParentRoot, ellipsisDotCSS ) );
                SMUtils.nap( 1 );
                ellipsisMenusParentRoot = SMUtils.getWebElementDirect( driver, ellipsisGrandRoot, ellipsisMenuRootCSS );
            }
        }
        return ellipsisMenusParentRoot;
    }

    /**
     * To get remove and cancel button element in Remove Student from Group
     * popup
     * 
     * @return
     */
    public WebElement removeAndCancelButton( String buttonText ) {
        WebElement removeAndCancelRootElement = null;
        for ( WebElement removeCancelButton : removeAndCancelButtonPopup ) {
            if ( removeCancelButton.getText().trim().equals( buttonText ) ) {
                removeAndCancelRootElement = SMUtils.getWebElementDirect( driver, removeCancelButton, removeAndCancelButtonInPopup );
                break;
            }
        }
        return removeAndCancelRootElement;
    }

    /**
     * This will get the list of Group names in Popup
     * 
     * @return
     */
    public List<String> getListOfGroupName() {
        SMUtils.waitForElement( driver, getButtonsFromPopup( "Cancel" ) );
        ArrayList<String> groupNames = new ArrayList<String>();
        if ( groupNameList.size() > 0 ) {
            for ( WebElement groupName : groupNameList ) {
                groupNames.add( groupName.getText().trim() );
            }
        }
        return groupNames;
    }

    /**
     * To get the list of the assignment Names
     * 
     * @return
     */
    public List<String> getListOfAssignmentName() {
        ArrayList<String> groupNames = new ArrayList<String>();
        if ( assignmentNameList.size() > 0 ) {
            for ( WebElement assignmentName : assignmentNameList ) {
                groupNames.add( assignmentName.getText().trim() );
            }
        }
        return groupNames;
    }

    /**
     * This method will return true if the zero state present
     * 
     * @return
     */
    public boolean isZeroState() {
        return !SMUtils.verifyElementDoesNotExist( By.cssSelector( zeroStateCSS ), driver );
    }

    /**
     * To add a student to an assignment
     * 
     * @param assignmentName
     */

    public boolean addStudentstoAssignment( String assignmentName ) {
        clickAssignmentButton();
        SMUtils.nap( 2 );
        SMUtils.waitForElement( driver, formAssignmentPopup );
        Boolean flag = false;
        int assignmentCount = assignmentLists.size();
        Log.message( "The Assignment count is " + assignmentCount );
        if ( assignmentLists.size() > 0 ) {
            for ( int i = 0; i < assignmentLists.size(); i++ ) {
                WebElement tdElement = assignmentLists.get( i );
                String elementText = tdElement.getText().trim();
                if ( elementText.equals( assignmentName ) ) {
                    //  WebElement checkBoxRoot = parentElement.findElement(By.cssSelector("div.segment.ng-star-inserted div div cel-checkbox"));
                    WebElement grandParent = tdElement.findElement( By.xpath( "./../.." ) );
                    WebElement parentElement = grandParent.findElement( By.cssSelector( addStudenttoAssignmentparentCSS ) );
                    SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, parentElement, btnAddStudentstoAssignmentCSS ) );
                    btnAddtoAssignment.click();
                    SMUtils.waitForElement( driver, btnAddStudentRoot );
                    Log.message( "Added Student to the Assignment: " + assignmentName );
                    SMUtils.waitForElement( driver, tableStudentList, 5 );
                    flag = true;
                    break;
                } else {
                    Log.message( "The Assignment is not present in the Popup" );
                    flag = false;
                }
            }
        } else {
            Log.message( "The Popup has no assignment" );
            flag = false;
        }
        return flag;
    }

    /**
     * click go back button in Studnet container
     */
    public void clickBackBtninContaniner() {
        SMUtils.waitForElement( driver, btnBack );
        SMUtils.clickJS( driver, btnBack );
        Log.message( "Clicking back button in Student container" );
        SMUtils.waitForElement( driver, btnAddStudentRoot, 5 );

    }

    public String getGroupContainerHeader() {
        SMUtils.waitForElement( driver, groupHeaderContainer );
        return groupHeaderContainer.getText().trim();
    }

    /**
     * To get the all the options in ellipses
     * 
     * @param studentId
     * @return
     */
    public List<String> getTextOfEllipsesOptions( String studentId ) {
        return SMUtils.getAllTextFromWebElementList( getAllOptionsinEllipsis( studentId ) );
    }

    /**
     * To get all the WebElement in ellipses
     * 
     */
    public List<WebElement> getAllOptionsinEllipsis( String studentID ) {
        sortbyStudentUserName.click();
        List<WebElement> options;
        // SMUtils.nap(2);
        WebElement ellipsisMenusParentRoot = null;
        for ( int i = 0; i < listStudentUsernames.size(); i++ ) {
            WebElement tdElement = listStudentUsernames.get( i );
            String elementText = tdElement.getText().trim();
            if ( elementText.equals( studentID ) ) {
                WebElement parentElement = tdElement.findElement( By.xpath( "./.." ) );
                WebElement ellipsisGrandRoot = parentElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) );
                WebElement ellipsisParentRoot = SMUtils.getWebElementDirect( driver, ellipsisGrandRoot, elliipsisParentRootCSS );
                SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, ellipsisParentRoot, ellipsisDotCSS ) );
                SMUtils.nap( 1 );
                ellipsisMenusParentRoot = SMUtils.getWebElementDirect( driver, ellipsisGrandRoot, ellipsisMenuRootCSS );
            }
        }
        WebElement ellipsisRootMenu = ellipsisMenusParentRoot;
        options = SMUtils.getWebElementsDirect( driver, ellipsisRootMenu, ellipsesOptionsCSS );
        Log.message( "Clicked on the View student from the Ellipsis menu for the student: " + studentID );
        return options;
    }

    /**
     * To get the title of the Popup for the Group and Assignment
     */
    public String getTextofHeaderPopup() {
        return popupHeaderTitle.getText().trim();
    }

    /**
     * This will method will get the Text Add Student Text in popup
     */
    public String getAddStudentText() {
        return addStudentHeader.getText().trim();
    }

    /**
     * this method will check if the student is present or not
     * 
     * @param studentUsername
     * @return
     */
    public Boolean isStudentPresent( String studentUsername ) {
        return ( getAllStudentsUserNames().contains( studentUsername ) ) ? true : false;

    }

    /**
     * This method will create a add student link in zero state message
     */
    @Deprecated
    public void clickAddStudentinZeroState() {

        SMUtils.clickJS( driver, btnAddStudent );
        Log.message( "Clicked Add Student button in zero state message" );
        SMUtils.waitForElement( driver, formCreateStudentPopup );
    }

    /**
     * To click cancel button in popup
     */
    public void clickCancelStudentCreation() {

        SMUtils.clickJS( driver, btnCancelStudentCreation );
        Log.message( "Clicked cancel button" );
        SMUtils.waitForElement( driver, addStudentElement() );

    }

    /**
     * To click Add Student button in popup
     */
    public void clickAddStudent() {
        SMUtils.waitForElement( driver, btnAddStudentRoot );
        SMUtils.clickJS( driver, addStudentElement() );
        Log.message( "Clicked Add Student Button" );
        SMUtils.waitForElement( driver, formCreateStudentPopup );
    }

    /**
     * This method will verify the zero State message in student listing page
     */
    public void verifyZeroState() {
        String noDataYetText = Students.NO_DATA_YET;
        String btnAddStudentTxt = Students.ADD_STUDENT;

        if ( NO_DATA_YET.getText().trim().equals( noDataYetText ) ) {
            Log.pass( "The noDataYetText is matching!" );
        } else {
            Log.fail( "The zero State message is not matching Actual message is " + NO_DATA_YET.getText().trim() + "Expected[" + noDataYetText + "]" );
        }

        if ( zeroStateMessage.getText().trim().replaceAll( "[^a-zA-Z0-9]", " " ).equals( Students.ZERO_STATE_MESSAGE.replaceAll( "[^a-zA-Z0-9]", " " ) ) ) {
            Log.pass( "The MessageText is matching!" );
        } else {
            Log.fail( "The zero State message is not matching Actual message is " + zeroStateMessage.getText().trim() + "Expected[" + btnAddStudentTxt + "]" );
        }
        if ( btnAddStudent.getText().trim().equals( btnAddStudentTxt ) ) {
            Log.pass( "The btnAddStudentTxt is matching!" );
        } else {
            Log.fail( "The btnAddStudentTxt is not matching Actual message is " + btnAddStudent.getText().trim() + "Expected[" + btnAddStudentTxt + "]" );
        }
    }

    /**
     * To select a student by its ID
     * 
     * @param studentID
     */
    public void selectStudentByUsername( String studentUsername ) {

        SMUtils.waitForElement( driver, studentTable, 5 );
        ArrayList<String> allStudentUserNames = getAllStudentsUserNames();
        int index = allStudentUserNames.indexOf( studentUsername );
        SMUtils.nap( 5 );
        String queryToSelect = "return document.querySelector('table > tbody > tr:nth-child(" + ( index + 1 ) + ") > td.td-check > cel-checkbox').shadowRoot.querySelector('div > label.checkbox__container > span')";
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        WebElement checkBoxElement = (WebElement) javascriptExecutor.executeScript( queryToSelect );

        SMUtils.click( driver, checkBoxElement );
        Log.message( "Selected the Student: " + studentUsername );
    }

    /**
     * To get all the students from student listing page.
     * 
     * @return
     */
    public HashMap<String, List<String>> getColumnDetailsAsList() {
        HashMap<String, List<String>> studentDetails = new HashMap<>();
        studentDetails.put( Constants.FIRSTNAME, getAllStudentsFirsNames() );
        studentDetails.put( Constants.LASTNAME, getAllStudentsLastNames() );
        studentDetails.put( Constants.USER_NAME, getAllStudentsUserNames() );
        studentDetails.put( Constants.STUDENT_ID, getAllStudentsStudentIds() );
        studentDetails.put( Constants.GRADE, getAllStudentsGrades() );
        return studentDetails;
    }

    /**
     * To Convert Epoch Time in to Human Readble Date Format
     * 
     * @return
     * @param (epoch Dates)
     */

    public List<String> convertEpochDateToNormalDate( List<String> epochdates ) {
        List<String> apiDateOnXaxis = new ArrayList<>();
        SimpleDateFormat format = new SimpleDateFormat( "MM/dd" );
        for ( String epochDate : epochdates ) {
            long l = Long.parseLong( epochDate );
            Date dates = new Date( l * 1000 );
            TimeZone timeZone = TimeZone.getTimeZone( "US/Arizona" );
            format.setTimeZone( timeZone );
            String format2 = format.format( dates );
            apiDateOnXaxis.add( format2 );
        }
        return apiDateOnXaxis;
    }

    /**
     * To get XAxis Date on UI
     * 
     * @return
     */

    public List<String> getXAxisDatesinStudentProgressGraph() {
        SMUtils.nap( 1 );
        List<String> datesOnXAxisUI = new ArrayList<>();
        for ( int date = 0; date < dateValuesXAxis.size(); date++ ) {
            String uiDate = "";
            String result = dateValuesXAxis.get( date ).getText().trim();
            for ( int i = 0; i <= 4; i++ ) {
                char charAt = result.charAt( i );
                uiDate = uiDate + charAt;
            }
            // String uiDate = result.substring( 0, result. length()-3);
            datesOnXAxisUI.add( uiDate );
        }
        return datesOnXAxisUI;
    }

    /**
     * To check first and last values in the UI are Same with API Response
     * 
     * @return
     */

    public Boolean isYAxisFirstAndLastValueSame( List<String> ValuesOfYAxis ) {
        Boolean status = false;
        String firstValueUI = courseValuesYAxis.get( 0 ).getText().trim();
        String lastValueUI = courseValuesYAxis.get( 4 ).getText().trim();
        String firstValueFromApi = ValuesOfYAxis.get( 0 );
        String lastValueFromApi = ValuesOfYAxis.get( 3 );

        Log.message( "First Value UI" + firstValueUI );
        Log.message( "First Value API" + firstValueFromApi );

        Log.message( "Last Value UI" + lastValueUI );
        Log.message( "Last Value API" + lastValueFromApi );

        if ( firstValueUI.equals( firstValueFromApi ) && lastValueUI.equals( lastValueFromApi ) ) {
            status = true;
            Log.message( "First and Last Values Matched with UI" );
        }
        return status;
    }

    /**
     * To Click Add button for group name in Add Student to Group PopUp popup
     * 
     */
    public void clickAddButtonInAddStudentToGroup( String groupName ) {
        Log.event( "Clicking on Add button for group name" + groupName );
        SMUtils.waitForElement( driver, closeIconInPopup );
        WebElement addButton = getAddButtonForGroupinAddStudentToGroup( groupName );
        SMUtils.waitForElement( driver, addButton );
        SMUtils.click( driver, addButton );
        Log.event( "add button is clicked successfully for group name" + groupName );
    }

    /**
     * To Click Remove button for group name in Add Student to Group PopUp popup
     * 
     */

    public void clickRemovebuttonForGroup( String groupName ) {
        WebElement addButton = getAddButtonForGroupinAddStudentToGroup( groupName );
        SMUtils.waitForElement( driver, addButton );
        SMUtils.click( driver, addButton );
    }

    /**
     * To Verify Group Text and XIcon for selected group in Add Student to Group
     * is exist or not PopUp popup
     * 
     */

    public boolean isGroupExistInAddStuToGroup( String groupName ) {
        boolean status = false;
        WebElement xIcon = null;
        for ( WebElement labelGroupName : groupNameText ) {
            if ( labelGroupName.getText().trim().equals( groupName ) ) {
                WebElement parentElement = labelGroupName.findElement( By.xpath( "./.." ) );
                xIcon = parentElement.findElement( By.cssSelector( groupXIcon ) );
                if ( ( labelGroupName.isDisplayed() ) && ( xIcon.isDisplayed() ) )
                    status = true;
                break;

            }
        }
        Log.message( "Group Text verified" );
        return status;
    }

    /**
     * To Click on X Icon for Group name in Add Student to Group PopUp (This is
     * specific to Add Student to group, we are deselecting the selected student
     * by clicking the X icon in the Search box)
     */

    public void clickXinChipAreaForGroup( String groupName ) {
        Log.event( "Clicking on X icon for added group name" + groupName );
        WebElement xIcon = null;
        for ( WebElement labelGroupName : groupNameText ) {
            if ( labelGroupName.getText().trim().equals( groupName ) ) {
                WebElement parentElement = labelGroupName.findElement( By.xpath( "./.." ) );
                xIcon = parentElement.findElement( By.cssSelector( groupXIcon ) );
                break;
            }
        }
        SMUtils.click( driver, xIcon );
        Log.message( "Clicked X icon for added group name" + groupName );
    }

    /**
     * To Get Add button for group name in Add Student to Group PopUp
     * 
     */

    public WebElement getAddButtonForGroupinAddStudentToGroup( String groupName ) {
        WebElement addButton = null;
        for ( WebElement labelGroupName : groupListInPopup ) {
            if ( labelGroupName.getText().trim().equals( groupName ) ) {
                WebElement parentElement = labelGroupName.findElement( By.xpath( "./.." ) );
                addButton = parentElement.findElement( By.cssSelector( addButAddStuPopUp ) );
                break;
            }
        }
        return addButton;
    }

    /**
     * To Click Remove button for group name in Add Student to Group PopUp popup
     * 
     */

    public WebElement clickRemoveButtoninAddStudentToGroupPopup( String groupName ) {
        WebElement removeButton = null;
        for ( WebElement labelGroupName : groupListInPopup ) {
            if ( labelGroupName.getText().trim().equals( groupName ) ) {
                WebElement parentElement = labelGroupName.findElement( By.xpath( "./.." ) );
                removeButton = parentElement.findElement( By.cssSelector( removeButAddStuPopUp ) );
                break;
            }
        }
        return removeButton;
    }

    /**
     * To click save button in create Student popup
     */
    public void clickSaveButtonInAddStuPopup() {
        Log.event( "Clicking on  save Button in Add Student to Group popup" );
        SMUtils.waitForElement( driver, saveButtonInPopup );
        // WebElement addStrudent = SMUtils.getWebElementDirect(driver, btnAddStudentRoot, btnAddStrudent);
        if ( saveButtonInPopup.isEnabled() )
            SMUtils.click( driver, saveButtonInPopup );
        Log.message( "Clicked save Button in Add Student to Group popup" );
    }

    /**
     * To click cancel button in create Student popup
     */
    public void clickCancelButtonInAddStuPopup() {
        Log.event( "Clicking cancel button in Add Students to Group popup" );
        SMUtils.waitForElement( driver, cancelButtonInPopup );
        if ( cancelButtonInPopup.isEnabled() )
            SMUtils.click( driver, cancelButtonInPopup );
        Log.message( "Clicked cancel Button in Add Students to Group popup" );
    }

    /**
     * To verify help icon is displayed or not in Add Students to Group popup
     * 
     * @return
     */
    public boolean verifyHelpIcon() {
        Log.event( "Verifying help icon in displayed or not in Add Students to Group popup" );
        boolean status = false;
        SMUtils.waitForElement( driver, helpIcon );
        if ( helpIcon.isDisplayed() )
            status = true;
        Log.event( "Verified the help icon is displayed in Add Students to Group popup" );
        return status;
    }

    /**
     * To click Help icon in Add Student to Group popup
     */
    public void clickHelpIcon() {
        Log.event( "Clicking Help icon in Add Students to Group popup" );
        SMUtils.waitForElement( driver, helpIcon );
        SMUtils.click( driver, helpIcon );
        Log.message( "Help icon is clicked successfully" );
    }

    /**
     * To verify the zerostate message in Add Students to Group popup
     * 
     * @return
     */
    public boolean verifyZeroStateMsgInAddStuToGroup() {
        ArrayList<Boolean> zeroPopup = new ArrayList<Boolean>();
        Log.event( "Verifying the zero state message " );
        SMUtils.waitForElement( driver, zeroStateHeaderMsg );
        SMUtils.waitForElement( driver, zeroStateDescriptionMsg );

        //Verification of Zero State header message
        zeroPopup.add( SMUtils.verifyWebElementTextEqualsIgnoreCase( zeroStateHeaderMsg, Constants.Students.ZERO_STATE_HEADER ) );

        //Verification of Zero State description
        zeroPopup.add( SMUtils.verifyWebElementTextEqualsIgnoreCase( zeroStateDescriptionMsg, Constants.Students.ZERO_STATE_DESC ) );

        return SMUtils.isAllValueTrue( zeroPopup );
    }

    /**
     * To click Add Students to Group Button in zero state
     */
    public void clickAddStuToGrpButton() {
        Log.event( "Clicking Add students to Groups link in Add Students to Group popup" );
        SMUtils.waitForElement( driver, btnAddStudenttoGroups );
        SMUtils.click( driver, btnAddStudenttoGroups );
        Log.message( "Add students to Groups link is clicked successfully" );
    }

    // Mastery Sub-Navigation Methods

    public boolean isStaticDropDownPresent( Constants.Students.Mastery_DropDowns dropdown ) {
        switch ( dropdown ) {
            case SUBJECT:
                SMUtils.waitForElement( driver, subjectDropDown );
                return subjectDropDown.isDisplayed() ? true : false;
            case MASTERY_SKILL:
                SMUtils.waitForElement( driver, masterySkillsDropDown );
                return masterySkillsDropDown.isDisplayed() ? true : false;
            case ASSIGNMENTS:
                SMUtils.waitForElement( driver, assignmentsDropDownroot );
                WebElement elementAssignmentdropdown = SMUtils.getWebElement( driver, assignmentsDropDownroot, assignmentsDropdownchild );
                return elementAssignmentdropdown.isDisplayed() ? true : false;
            default:
                Log.message( "Invalid Drop down option." );
                return false;
        }
    }

    public List<String> getDropDownOptions( Constants.Students.Mastery_DropDowns dropdown ) {
        List<String> dropDownOptions = new ArrayList<String>();
        switch ( dropdown ) {
            case SUBJECT:
                SMUtils.waitForElement( driver, subjectDropDown );
                SMUtils.clickJS( driver, subjectDropDown );
                //SMUtils.waitForElement( driver, subjectDropDownValues.get( 0 ) );
                for ( WebElement eachOption : subjectDropDownValues )
                    dropDownOptions.add( eachOption.getText().trim().toLowerCase() );
                Log.message( "The values from Subject drop down is retrieved" );
                return dropDownOptions;
            case MASTERY_SKILL:
                SMUtils.waitForElement( driver, masterySkillsDropDown );
                SMUtils.clickJS( driver, masterySkillsDropDown );
                for ( WebElement eachOption : masterySkillsDropDownValues )
                    dropDownOptions.add( eachOption.getText().trim().toLowerCase() );
                Log.message( "The values from Mastery Skills drop down is retrieved" );
                return dropDownOptions;
            case ASSIGNMENTS:
                SMUtils.nap( 2 ); // For MAC it is taking some time for assignments list to load
                SMUtils.waitForElement( driver, assignmentsDropDownroot );
                WebElement dropDown = SMUtils.getWebElement( driver, assignmentsDropDownroot, assignmentsDropdownchild );
                SMUtils.clickJS( driver, dropDown );
                List<WebElement> allElements = SMUtils.getWebElements( driver, assignmentsDropDownroot, assignmentsDropdownvalueschild );
                for ( WebElement eachElement : allElements ) {
                    WebElement eachValue = SMUtils.getWebElement( driver, eachElement, assignmentsDropdownEachValueChild );
                    dropDownOptions.add( eachValue.getText().trim() );
                }
                return dropDownOptions;

            default:
                Log.message( "Drop down values are not available" );
                return null;
        }
    }

    public void selectDropDownValues( Constants.Students.Mastery_DropDowns dropdown, String value ) {
        switch ( dropdown ) {
            case SUBJECT:
                SMUtils.waitForElement( driver, subjectDropDown );
                SMUtils.clickJS( driver, subjectDropDown );
                for ( WebElement eachOption : subjectDropDownValues ) {
                    if ( eachOption.getText().trim().toLowerCase().equals( value.toLowerCase() ) ) {
                        SMUtils.clickJS( driver, eachOption );
                        Log.message( "The value " + value + " is selected in Subject Drop down" );
                        break;
                    }
                }
                SMUtils.nap( 1 );
                break;
            case MASTERY_SKILL:
                SMUtils.waitForElement( driver, masterySkillsDropDown );
                if ( masterySkillsDropDown.getAttribute( "aria-expanded" ).equals( "true" ) ) {
                    for ( WebElement eachOption : masterySkillsDropDownValues ) {
                        if ( eachOption.getText().toLowerCase().trim().equals( value.toLowerCase().trim() ) ) {
                            SMUtils.waitForElementToBeClickable( eachOption, driver );
                            SMUtils.clickJS( driver, eachOption );
                            Log.message( "The values from Mastery Skills drop down is clicked" );
                            break;
                        }
                    }
                }
                break;
            case ASSIGNMENTS:
                SMUtils.waitForElement( driver, assignmentsDropDownroot, 6 );
                WebElement dropDown = SMUtils.getWebElement( driver, assignmentsDropDownroot, assignmentsDropdownchild );
                SMUtils.clickJS( driver, dropDown );
                WebElement chbxSelectAll = SMUtils.getWebElementDirect( driver, assignmentsDropDownroot, assignmentsDropdownvalueschild, txtDropDownMSValue );
                SMUtils.clickJS( driver, chbxSelectAll );
                List<WebElement> allElements = SMUtils.getWebElements( driver, assignmentsDropDownroot, assignmentsDropdownvalueschild );
                for ( WebElement eachOption : allElements ) {
                    WebElement lblassignmentName = SMUtils.getWebElementDirect( driver, eachOption, assignmentsDropdownEachValueChild );
                    if ( lblassignmentName.getText().toLowerCase().trim().equals( value.toLowerCase().trim() ) ) {
                        WebElement chbxForAssignment = SMUtils.getWebElementDirect( driver, eachOption, txtDropDownMSValue );
                        SMUtils.clickJS( driver, chbxForAssignment );
                        Log.message( "The value " + value + " is selected in Assignment Drop down" );
                        break;
                    }

                }
                break;
            default:
                Log.message( "Drop down values are not available" );
                break;
        }
    }

    /**
     * To click Apply filter button
     */
    public void clickApplyFilter() {
        WebElement button = SMUtils.getWebElementDirect( driver, masteryApplyFilter, assignmentsDropdownchild );
        SMUtils.waitForElementToBeClickable( button, driver );
        SMUtils.clickJS( driver, button );
        Log.message( "Clicked Apply filter button" );
    }

    public String getSelectedValuesFromDropdown( Constants.Students.Mastery_DropDowns dropdown ) {
        switch ( dropdown ) {
            case SUBJECT:
                SMUtils.waitForElement( driver, subjectDropDownSelectedValue );
                return subjectDropDownSelectedValue.getText().trim();
            case MASTERY_SKILL:
                SMUtils.waitForElement( driver, masterySkillsDropDownSelectedValue );
                return masterySkillsDropDownSelectedValue.getText().trim();
            default:
                Log.message( "Select a valid drop down" );
                return null;
        }
    }

    // Assignments Sub-navigation methods
    public List<String> getAllAssignments() {
        SMUtils.waitForElement( driver, assignmentHeader );
        List<String> assignmentNames = new ArrayList<>();
        for ( WebElement eachElement : allAssignmentsList ) {
            assignmentNames.add( eachElement.getText().trim() );
        }
        return assignmentNames;
    }

    public boolean checkElementPresence( String element ) {
        if ( element.equals( Constants.Students.LEGENDS ) ) {
            SMUtils.waitForElement( driver, masteryLegendMastered );
            return SMUtils.isElementPresent( masteryLegendMastered ) && SMUtils.isElementPresent( masteryLegendAtRisk ) && SMUtils.isElementPresent( masteryLegendNotMastered ) && SMUtils.isElementPresent( masteryLegendUnaccessed ) ? true : false;
        } else if ( element.equals( Constants.Students.TOPLEVELHIERARCY ) ) {
            SMUtils.waitForElement( driver, masteryLegendMastered, 20 );
            if ( masteryTopLevelHierarcy.size() > 0 ) {
                SMUtils.waitForElement( driver, masteryTopLevelHierarcy.get( 0 ) );
                for ( int i = 0; i < masteryTopLevelHierarcy.size(); i++ ) {
                    Log.assertThat( SMUtils.waitForElement( driver, masteryTopLevelHierarcy.get( i ) ), "The Mastery Top Level Hierarcy " + i + " is displayed", "The Mastery Top Level Hierarcy " + i + " is not displayed" );
                }
                return true;
            } else {
                Log.message( "No Top Level Hierarcy to display" );
                return false;
            }
        } else if ( element.equals( Constants.Students.MIDDLELEVELHIERARCY ) ) {
            if ( masteryMiddleLevelHierarcy.size() > 0 ) {
                SMUtils.waitForElement( driver, masteryMiddleLevelHierarcy.get( 0 ) );
                for ( int i = 0; i < masteryMiddleLevelHierarcy.size(); i++ ) {
                    Log.assertThat( SMUtils.waitForElement( driver, masteryMiddleLevelHierarcy.get( i ) ), "The Mastery Middle Level Hierarcy " + i + " is displayed", "The Mastery Middle Level Hierarcy " + i + " is not displayed" );
                }
                return true;
            } else {
                Log.message( "No Middle Level Hierarcy to display" );
                return false;
            }
        } else if ( element.equals( Constants.Students.LEAFNODEHIERARCY ) ) {
            if ( masteryLeafNode.size() > 0 ) {
                SMUtils.waitForElement( driver, masteryLeafNode.get( 0 ) );
                for ( int i = 0; i < masteryLeafNode.size(); i++ ) {
                    Log.assertThat( SMUtils.waitForElement( driver, masteryLeafNode.get( i ) ), "The Mastery Leaf Node Hierarcy " + i + " is displayed", "The Mastery Leaf Node Hierarcy " + i + " is not displayed" );
                }
                return true;
            } else {
                Log.message( "No Leaf Node Hierarcy to display" );
                return false;
            }
        } else if ( element.equals( Constants.Students.LODESCRIPTION ) ) {
            if ( masteryLODescription.size() > 0 ) {
                SMUtils.waitForElement( driver, masteryLODescription.get( 0 ) );
                for ( int i = 0; i < masteryLODescription.size(); i++ ) {
                    Log.assertThat( SMUtils.waitForElement( driver, masteryLODescription.get( i ) ), "The Mastery LO Link and Description " + i + " is displayed", "The Mastery LO Link and Description " + i + " is not displayed" );
                }
                return true;
            } else {
                Log.message( "No LO Link and Description to display" );
                return false;
            }
        } else if ( element.equals( Constants.Students.PROGRESSBARS ) ) {
            if ( masteryProgressBarRoot.size() > 0 ) {
                for ( int i = 0; i < masteryProgressBarRoot.size(); i++ ) {
                    Log.assertThat( SMUtils.waitForElement( driver, masteryProgressBarRoot.get( i ) ), "The Mastery Progress Bar " + i + " is displayed", "The Mastery Progress Bar " + i + " is not displayed" );
                }
                return true;
            } else {
                Log.message( "No Progress Bar to display" );
                return false;
            }
        }
        return false;
    }

    public boolean verifyDropdownvalues( List<String> expected, List<String> actual ) {
        boolean result = false;
        Collections.sort( expected );
        Collections.sort( actual );
        Log.message( expected.size() + "" );
        Log.message( actual.size() + "" );
        for ( int i = 0; i < expected.size(); i++ ) {
            if ( expected.get( i ).equalsIgnoreCase( actual.get( i ) ) ) {
                result = true;
            } else {
                Log.message( expected.get( i ) + "->" + actual.get( i ) + " value mismatches" );
                result = false;
                break;
            }
        }
        return result;
    }

    public boolean isMasteryDisplayed() {
        SMUtils.waitForElement( driver, masteryLabel );
        return masteryLabel.isDisplayed() ? true : false;
    }
    
    public boolean isGradeDisplayed() {
        SMUtils.waitForElement( driver, masteryStudentGrade );
        return masteryStudentGrade.isDisplayed() ? true : false;
    }

    /**
     * To remove students from all the groups
     */
    public void removeStudentFromAllGroup() {
        try {
            SMUtils.waitForElementToBeClickable( headerText, driver );
            for ( WebElement element : removeStudentFromGroupGrandRoot ) {
                SMUtils.scrollWebElementToView( driver, element );
                WebElement ellipsesIcon = SMUtils.getWebElementDirect( driver, element, elipsisChild );
                SMUtils.clickJS( driver, ellipsesIcon );
                WebElement removeStudentfromGroupChild = SMUtils.getWebElement( driver, element, "cel-dropdown-menu-box[class='hydrated']" );
                WebElement removeStudentFromGroup = SMUtils.getWebElement( driver, removeStudentfromGroupChild, removeStudentFromGroupChild );
                SMUtils.clickJS( driver, removeStudentFromGroup );
                SMUtils.waitForElementToBeClickable( getButtonsFromPopup( "Remove" ), driver );
                SMUtils.clickJS( driver, getButtonsFromPopup( "Remove" ) );
                SMUtils.waitForElementToBeClickable( listSideNvaBar.get( 0 ), driver );

            }
            Log.pass( "Student Removed from all the groups" );
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.fail( "Issue in removing student from group" );
        }
    }

    /**
     * Alternate Method To Remove All the Students From Groups
     */

    public void removeStudentFromAllGroups() {
        try {
            SMUtils.waitForElementToBeClickable( headerText, driver );
            for ( WebElement element : removeStudentFromGroupGrandRoot ) {
                SMUtils.scrollWebElementToView( driver, element );
                WebElement ellipsesIcon = SMUtils.getWebElementDirect( driver, element, elipsisChild );
                SMUtils.clickJS( driver, ellipsesIcon );
                WebElement removeStudentfromGroupChild = SMUtils.getWebElement( driver, element, removeStudentFromGroupChilds );
                WebElement removeStudentFromGroup = SMUtils.getWebElement( driver, removeStudentfromGroupChild, removeStudentFromGroupChild );
                SMUtils.clickJS( driver, removeStudentFromGroup );
                SMUtils.waitForElementToBeClickable( getButtonsFromPopup( "Remove" ), driver );
                SMUtils.clickJS( driver, getButtonsFromPopup( "Remove" ) );
                SMUtils.waitForElementToBeClickable( listSideNvaBar.get( 0 ), driver );

            }
            Log.pass( "Student Removed from all the groups" );
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.fail( "Issue in removing student from group" );
        }
    }

    /**
     * Remove student from group
     * 
     * @param groupName
     */
    public void removeStudentFromGroup( String groupName ) {
        try {
            SMUtils.waitForElementToBeClickable( headerText, driver );

            WebElement groupNameElement = driver.findElement( By.cssSelector( String.format( groupNameFromViewStudent, groupName ) ) );
            WebElement parentElement = groupNameElement.findElement( By.xpath( "./../.." ) );
            WebElement rootElement = parentElement.findElement( By.cssSelector( "cel-button-menu[class='table-dropdown-menu th-action-dropdown hydrated']" ) );
            SMUtils.scrollWebElementToView( driver, rootElement );
            WebElement ellipsesIcon = SMUtils.getWebElementDirect( driver, rootElement, elipsisChild );
            SMUtils.clickJS( driver, ellipsesIcon );
            WebElement removeStudentfromGroupChild = SMUtils.getWebElement( driver, rootElement, "cel-dropdown-menu-box[class='hydrated']" );
            WebElement removeStudentFromGroup = SMUtils.getWebElement( driver, removeStudentfromGroupChild, removeStudentFromGroupChild );
            SMUtils.clickJS( driver, removeStudentFromGroup );
            SMUtils.waitForElementToBeClickable( getButtonsFromPopup( "Remove" ), driver );
            SMUtils.clickJS( driver, getButtonsFromPopup( "Remove" ) );
            SMUtils.waitForElementToBeClickable( listSideNvaBar.get( 0 ), driver );

            Log.pass( "Student Removed from all the groups" );
        } catch ( Exception e ) {
            e.printStackTrace();
            Log.fail( "Issue in removing student from group" );
        }
    }

    /**
     * To click on the Last session skill name
     */
    public void clickRecentSkillName() {
        SMUtils.waitForElement( driver, skillLinkClick );
        SMUtils.clickJS( driver, skillLinkClick );
        Log.message( "Last Session skill name clicked" );
    }

    /**
     * To get the Last session skill name
     * 
     * @return
     */
    public String getRecentSkillNameText() {
        SMUtils.waitForElement( driver, lastSessionFirstSkillName );
        return lastSessionFirstSkillName.getText().trim();
    }

    /**
     * To get the Last session skill name from popup
     * 
     * @return
     */
    public String getRecentSkillNameTextPopup() {
        SMUtils.waitForElement( driver, lastSessionNameInPopup );
        return lastSessionNameInPopup.getText().trim();
    }

    /**
     * To get the Last session skills popup header
     * 
     * @return
     */
    public String checkPopupTitle() {
        SMUtils.waitForElement( driver, lastSessionPopupHeader, 8 );
        Log.message( lastSessionPopupHeader.getText() );
        return lastSessionPopupHeader.getText().trim();
    }

    /**
     * To check Close button in the Last session Skills popup
     * 
     * @return
     */
    public boolean checkCloseButton() {
        SMUtils.waitForElement( driver, closeButton, 8 );
        return closeButton.isDisplayed();
    }

    /**
     * To click subject in drodpown present in Last Session Skills section
     * 
     * @param SubjectToCheck
     * @throws Exception
     */
    public void selectSubjectFromLastSessionDropDown( String SubjectToCheck ) throws Exception {

        SMUtils.waitForElement( driver, lastSessionDefaultSubject );
        try {
            lastSessionDropDownValues.stream().filter( element -> element.getText().equals( SubjectToCheck ) ).findFirst().ifPresent( element -> SMUtils.clickJS( driver, element ) );
        } catch ( Exception e ) {
            Log.message( "Subject Not Found" );
            Log.exception( e, driver );
        }
    }

    /**
     * To click Last session dropdown
     * 
     */
    public void clickDropDownForLastSession() {
        SMUtils.waitForElement( driver, lastSessionDropDown );
        SMUtils.clickJS( driver, lastSessionDropDown );
        Log.message( "Drop Down Button Clicked" );
    }

    /**
     * To get the Skill Tested Values
     * 
     * @return
     */
    public String getFirstSkillsTestedValues() {
        SMUtils.waitForElement( driver, lastSessionFirstSkill );
        Log.message( lastSessionFirstSkill.getText() );
        return lastSessionFirstSkill.getText().trim();
    }

    /**
     * To get the Skill Tested Value in Popup
     * 
     * @return
     */
    public String getSkillsTestedValuesFromPopup() {
        SMUtils.waitForElement( driver, lastSessionValueInPopup );
        Log.message( lastSessionValueInPopup.getText() );
        return lastSessionValueInPopup.getText().trim();
    }

    /**
     * To verify Add Students to Groups link is present or not in Students page
     * 
     * @return
     */
    public boolean verifyAddStudentLinkinZeroState() {
        boolean status = false;
        Log.event( "Verifying the display of Add Student to Groups link in Zero state" );
        SMUtils.waitForElement( driver, btnAddStudent );
        if ( btnAddStudent.isDisplayed() ) {
            status = true;
            Log.event( "Verified the display of Add Student to Groups link in Zero state" );
        }
        return status;
    }

    /**
     * To verify zero state for Last Session Skills
     *
     * @return
     */
    public boolean verifyZeroStateForLastSessionSkills() {
        try {
            SMUtils.waitForElement( driver, lastSessionHeader );
            for ( WebElement chartheader : lblstudentUsagechartForZeroState ) {
                if ( chartheader.getText().trim().equals( Constants.Students.STUDENT_LAST_SESSION_SKILLS_HEADER ) ) {
                    Log.pass( "Last Session Skills header " + "\"" + Constants.Students.STUDENT_LAST_SESSION_SKILLS_HEADER + "\"" + " displayed successfully!" );
                    String zeroStateFromUI = zeroStateLastSessionSkills.getText().trim();
                    if ( zeroStateFromUI.contains( Constants.Students.STUDENT_LAST_SESSION_SKILLS_ZERO_STATE_MESSAGE.get( 0 ) ) && zeroStateFromUI.contains( Constants.Students.STUDENT_LAST_SESSION_SKILLS_ZERO_STATE_MESSAGE.get( 1 ) )
                            && zeroStateFromUI.contains( Constants.Students.STUDENT_LAST_SESSION_SKILLS_ZERO_STATE_MESSAGE.get( 2 ) ) ) {
                        Log.pass( "Zero state message is displayed successfully! - " + zeroStateLastSessionSkills.getText().trim() );
                        return true;
                    } else {
                        Log.fail( "Zero state message is not displayed successfully! - " + zeroStateLastSessionSkills.getText().trim() );
                    }
                }
            }
            Log.fail( "Last Session Skills is not displayed properly! - Last Session Skills", driver );
            return false;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To get the Skill Tested Values
     * 
     * @return
     */
    public HashMap<String, HashMap<String, String>> getSkillsTestedValues() {
        SMUtils.waitForElement( driver, lastSessionGraph );
        HashMap<String, HashMap<String, String>> skillsTestedList = new HashMap<String, HashMap<String, String>>();
        List<String> skillsName = new ArrayList<String>();
        List<String> skillsCorrect = new ArrayList<String>();

        Log.message( "No of Skill Tested is " + lastSessionSkillTestedNames.size() );
        // Adding skill Names
        if ( !lastSessionSkillTestedNames.isEmpty() ) {
            lastSessionSkillTestedNames.stream().forEach( skillName -> {
                String name = skillName.getText().trim();
                skillsName.add( name );
            } );

            // Adding skillCorrect Text
            if ( !skillsCorrectList.isEmpty() ) {
                skillsCorrectList.stream().forEach( skillCorrect -> {
                    String name = skillCorrect.getText().trim();
                    skillsCorrect.add( name );
                    Log.message( "Number of attempts are displayed in Last Session Skills section" );
                } );
            }

            IntStream.range( 0, progressBarRoot.size() ).forEach( skillCount -> {
                WebElement parent = SMUtils.getWebElementDirect( driver, progressBarRoot.get( skillCount ), progressBarCSS );
                String barText = null;
                String barWidthArrtribute = null;
                HashMap<String, String> eachValues = new HashMap<>();
                try {
                    barText = parent.getText();
                    barWidthArrtribute = parent.getAttribute( "style" );
                } catch ( Exception NullPointerException ) {
                    parent = SMUtils.getWebElementDirect( driver, progressBarRoot.get( skillCount ), progressBarTextZeroCSS );
                    barWidthArrtribute = parent.getAttribute( "style" );
                    eachValues.put( SKILL_PERCENT_VALUE, parent.getText().trim() );
                    eachValues.put( BAR_WIDTH, barWidthArrtribute );
                }
                eachValues.put( SKILL_CORRECT, skillsCorrect.get( skillCount ) );
                eachValues.put( SKILL_PERCENT_VALUE, barText );
                eachValues.put( BAR_WIDTH, barWidthArrtribute );
                skillsTestedList.put( skillsName.get( skillCount ), eachValues );
            } );
        } else {
            Log.message( "The student has no skills tested" );
        }
        return skillsTestedList;
    }

    /**
     * To get the Skills Name from the hashMap getSkillsTestedValues() method
     * 
     * @param hashMap
     * @return Skill Name as ArrayList
     */
    public List<String> getSkillsListFromMap( HashMap<String, HashMap<String, String>> hashMap ) {
        List<String> KeyValues = new ArrayList<String>();
        Set<String> keys = hashMap.keySet();
        keys.stream().forEach( key -> {
            KeyValues.add( key );
        } );

        return KeyValues;
    }

    /**
     * To verify skills are present or not in Last Session Skills
     * 
     * @param skillName
     * @return
     */
    public boolean isSkillNameLinkDisplayed( String skillName ) {
        SMUtils.waitForElement( driver, lastSessionGraph );
        String linkText = skillLink.stream().filter( lbllegend -> lbllegend.getText().trim().equals( skillName ) ).map( WebElement::getText ).findAny().orElse( null );
        if ( Objects.nonNull( linkText ) ) {
            return true;
        }
        return false;
    }

    /**
     * To verify drpdown is displayed or not in Last Session Skills section
     * 
     * @return
     */
    public boolean verifyDropdownLastSession() {
        boolean status = false;
        Log.event( "Verifying the dropdown display in Last Session Skill section" );
        SMUtils.waitForElement( driver, lastSessionDropDown );
        if ( lastSessionDropDown.isDisplayed() )
            status = true;
        return status;
    }

    /**
     * To click skill Name in last session skill tested
     * 
     * @param skillName
     */
    public void clickSkillNameInSkillTested( String skillName ) {
        SMUtils.waitForElement( driver, skillTestedHeader );
        WebElement lblSkillName = skillNames.stream().filter( txtSkillName -> txtSkillName.getText().trim().equals( skillName ) ).findAny().orElse( null );
        if ( Objects.nonNull( lblSkillName ) ) {
            SMUtils.clickJS( driver, lblSkillName );
            Log.message( "Clicked skill name - " + lblSkillName.getText() );
        } else {
            Log.message( "Skill Name is not present under the respective student!" );
        }
    }

    /**
     * To click the skill name in last session in view student page.
     * 
     * @param skillName
     */
    public void clickSkillNameSkillTested( String skillName ) {
        SMUtils.waitForElement( driver, skillTestedHeader );
        for ( WebElement lblSkillName : skillNames ) {
            SMUtils.waitForElement( driver, lblSkillName );
            if ( lblSkillName.getText().equalsIgnoreCase( skillName ) ) {
                SMUtils.clickJS( driver, lblSkillName );
                Log.message( "Clicked skill name - " + lblSkillName.getText() );
            } else {
                Log.message( "Skill Name is not present under the respective student!" );
            }
        }
    }

    /**
     * To verify header and buttons in skill tested popup
     * 
     * @param assignmentType
     */
    public boolean verifySkillTestedPopupHeaderAndButtons( String assignmentType ) {
        SMUtils.waitForElement( driver, skillTestedPopupHeader );
        try {
            //Verifying Header
            if ( assignmentType.contains( Constants.MATH ) ) {
                if ( skillTestedPopupHeader.getText().trim().contains( Constants.LastSessionSkillTested.MATH_SKILL_TESTED_POPUP_HEADER ) ) {
                    Log.message( "Skill Tested popup header displayed properly - " + Constants.LastSessionSkillTested.MATH_SKILL_TESTED_POPUP_HEADER );
                } else {
                    Log.message( "Skill Tested popup header not displayed properly! \n Expected : " + Constants.LastSessionSkillTested.MATH_SKILL_TESTED_POPUP_HEADER + "\n Actual : " + skillTestedPopupHeader.getText().trim() );
                    return false;
                }
            } else {
                SMUtils.waitForElement( driver, skillTestedPopupHeader, 10 );
                if ( skillTestedPopupHeader.getText().trim().contains( Constants.LastSessionSkillTested.READING_SKILL_TESTED_POPUP_HEADER ) ) {
                    Log.message( "Skill Tested popup header displayed properly - " + Constants.LastSessionSkillTested.READING_SKILL_TESTED_POPUP_HEADER );
                } else {
                    Log.message( "Skill Tested popup header not displayed properly! \n Expected : " + Constants.LastSessionSkillTested.READING_SKILL_TESTED_POPUP_HEADER + "\n Actual : " + skillTestedPopupHeader.getText().trim() );
                    return false;
                }
            }

            //Verifying close icon
            if ( SMUtils.getWebElementDirect( driver, closeIconParentRoot, closeIconChild ).isDisplayed() ) {
                Log.message( "Close icon displayed in the skill tested popup!" );
            } else {
                Log.message( "Close icon is not displayed  properly in the skill tested popup" );
                return false;
            }

            //Verifying close button
            if ( SMUtils.getWebElementDirect( driver, closeBtnInSkillTestedPopup, closeButtonChild ).isDisplayed() ) {
                Log.message( "Close button displayed in the skill tested popup!" );
            } else {
                Log.message( "Close button is not displayed  properly in the skill tested popup" );
                return false;
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To verify values in skill tested popup
     * 
     * @param skillDetails
     */
    public boolean verifySkillTestedPopupValues( Map<String, String> skillDetails ) {
        SMUtils.waitForElement( driver, skillTestedPopupHeader );
        try {
            //Verifying skill name in popup
            if ( lblSkillNameInPopup.getText().trim().equals( skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) ) ) {
                Log.message( "Skill Name displayed properly in the skill tested popup! - " + skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) );
            } else {
                Log.message( "Skill Name not displayed properly in the skill tested popup! - \n Expected : " + skillDetails.get( Constants.LastSessionSkillTested.SKILL_NAME ) + "\n Actual : " + lblSkillNameInPopup.getText().trim() );
                return false;
            }

            //Verifying skill description in popup
            if ( txtSkillDescription.getText().replaceAll( "[^a-zA-Z0-9]", "" ).trim().equals( skillDetails.get( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ).replaceAll( "[^a-zA-Z0-9]", "" ) ) ) {
                Log.message( "Skill description displayed properly in the skill tested popup! - " + skillDetails.get( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) );
            } else {
                Log.message( "Skill description not displayed properly in the skill tested popup! - \n Expected : " + skillDetails.get( Constants.LastSessionSkillTested.OBJECT_DESCRIPTION ) + "\n Actual : " + txtSkillDescription.getText().trim() );
                return false;
            }

            //Verifying LO/SCO in popup
            if ( catalogNumber.getText().trim().equals( skillDetails.get( Constants.LastSessionSkillTested.CATALOG_NUMBER ) ) ) {
                Log.message( "LO/SCO displayed properly in the skill tested popup! - " + Constants.LastSessionSkillTested.CATALOG_NUMBER );
            } else {
                Log.message( " LO/SCO not displayed properly in the skill tested popup! - \n Expected : " + skillDetails.get( Constants.LastSessionSkillTested.CATALOG_NUMBER ) + "\n Actual : " + catalogNumber.getText().trim() );
                return false;
            }

            //Verifying no.of questions correct and attempted in popup
            if ( countOFCorrectAandAttemptedInPopup.getText().trim().equals( skillDetails.get( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) + " / " + skillDetails.get( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) + " correct" ) ) {
                Log.message( "Count of correct and attempted questions are displayed properly in the skill tested popup! - " + countOFCorrectAandAttemptedInPopup.getText().trim() );
            } else {
                Log.message( "Count of correct and attempted questions are not displayed properly in the skill tested popup! - \n Expected : " + skillDetails.get( Constants.LastSessionSkillTested.TOTAL_LO_CORRECT ) + " / "
                        + skillDetails.get( Constants.LastSessionSkillTested.TOTAL_LO_ATTEMPTS ) + " correct\n Actual : " + countOFCorrectAandAttemptedInPopup.getText().trim() );
                return false;
            }

            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To click LO/SCO
     * 
     */
    public void clickLOInSkillTestedPopup() {
        SMUtils.clickJS( driver, catalogNumber );
        Log.message( "Clicked LO/SCO From skill tested popup!" );
    }

    /**
     * To verify the Assignment SubNav header text in Students page
     * 
     * @return
     */
    public boolean verifyAssignmentSubNav() {
        boolean status = false;
        Log.event( "Verifying the Assignment sub nav header in Students Page" );
        SMUtils.waitForElement( driver, assignmentHeader );
        if ( assignmentHeader.getText().trim().equals( Constants.Students.SIDE_NAV_ASSIGNMENT_TAB ) )
            status = true;
        Log.event( "Verified the Assignment sub nav header in Students Page" );
        return status;
    }

    /**
     * To get the assigned assignments in student page
     * 
     * @throws InterruptedException
     * 
     */
    public List<String> getAssignedAssignmentNames() throws InterruptedException {
        List<String> assignmentNameFromUI = new ArrayList<>();
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        String assignmentNames = assignmentTable.getAttribute( "childElementCount" );
        IntStream.range( 0, Integer.parseInt( assignmentNames ) ).forEach( i -> {
            Log.message( driver.findElement( By.cssSelector( String.format( assingmentNameTable, i + 1 ) ) ).getText().trim() );
            String assignment = driver.findElement( By.cssSelector( String.format( assingmentNameTable, i + 1 ) ) ).getText().trim();
            assignmentNameFromUI.add( assignment );
        } );

        return assignmentNameFromUI;
    }

    /**
     * To get the zeroState header for assignments in student page
     * 
     * @return
     */
    public String getZeroStateHeaderForAssignments() {
        return zeroStateHeaderMsgForStudentAssignments.getText().trim();
    }

    /**
     * To get the zero state message description for assignments in student page
     * 
     * @return
     */
    public String getZeroStateMessageForAssignments() {
        return zeroStateDescriptionMsgForStudentAssignments.getText().trim();
    }

    // Find all assignments details mapped to the student in students page

    /**
     * Gets Title column name
     */
    public String getColumnTitle() {
        return columnTitle.getText();
    }

    /**
     * Gets LastSession column name
     */
    public String getColumnLastSession() {
        return columnLastSession.getText();
    }

    /**
     * Gets IPLevel column name
     */
    public String getColumnIPLevel() {
        return columnIPLevel.getText();
    }

    /**
     * Gets AssignedLevel column name
     */
    public String getColumnAssignedLevel() {
        return columnAssignedLevel.getText();
    }

    /**
     * Gets CurrentLevel column name
     */
    public String getColumnCurrentLevel() {
        return columnCurrentLevel.getText();
    }

    /**
     * Gets Gain column name
     */
    public String getColumnGain() {
        return columnGain.getText();
    }

    /**
     * Gets PercentageCorrect column name
     */
    public String getColumnPercentageCorrect() {
        return columnPercentageCorrect.getText();
    }

    /**
     * To click Three dot ellipsis from Assignments
     * 
     * @param assignmentName
     * @throws InterruptedException
     */
    public boolean clickingThreedotsEllipsisFromAssignments( String assignmentName ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        SMUtils.waitForElement( driver, assignmentNames );
        for ( WebElement trElement : assignmentListRoot ) {
            WebElement lblAssignmentName = trElement.findElement( By.cssSelector( lblAssignmentsName ) );
            Log.message( lblAssignmentName.getText().trim() );
            if ( lblAssignmentName.getText().trim().equals( assignmentName ) ) {
                SMUtils.scrollIntoView( driver, lblAssignmentName );
                WebElement elipsis = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), elliipsisParentRootCSS );
                SMUtils.clickJS( driver, elipsis );
                WebElement removeStudentFromAssignment = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), ellipsisMenuRootCSS, menuRemovestudentFromAssignment );
                return removeStudentFromAssignment.isDisplayed();
            }
        }
        Log.message( "Given Assignment is not present under the tab" );
        return false;
    }

    /**
     * To click Three dot ellipsis for First Assignments
     * 
     */
    public void clickingThreedotsEllipsisForFirstAssignments() {
        SMUtils.waitForElement( driver, assignmentNames );
        SMUtils.scrollIntoView( driver, assignmentNames );
        WebElement elipsis = SMUtils.getWebElementDirect( driver, AssignmentEllispeGrandRoot, elliipsisParentRootCSS );
        SMUtils.clickJS( driver, elipsis );
    }

    /**
     * To Get FluencyFiles Ellipsis option at assignment level
     * 
     * @return
     */
    public String fluencyFilesInEllipsis() {
        SMUtils.waitForElement( driver, assignmentNames );
        WebElement fluencyFiles = SMUtils.getWebElementDirect( driver, AssignmentEllispeGrandRoot, ellipsisMenuRootCSS, fluencyFileschild );
        Log.message( "Fluency Files option is displayed in Ellipsis" );
        return SMUtils.getTextOfWebElement( fluencyFiles, driver );
    }

    /**
     * To Get ViewAssignment Ellipsis option at assignment level
     * 
     * @return
     */
    public String viewAssignmentInEllipsis() {
        SMUtils.waitForElement( driver, assignmentNames );
        WebElement viewAssignment = SMUtils.getWebElementDirect( driver, AssignmentEllispeGrandRoot, ellipsisMenuRootCSS, viewAssignmentchild );
        Log.message( "View Assignment option is displayed in Ellipsis" );
        return SMUtils.getTextOfWebElement( viewAssignment, driver );
    }

    /**
     * To Get EditAssignment Ellipsis option at assignment level
     * 
     * @return
     */
    public String editAssignmentSettingsInEllipsis() {
        SMUtils.waitForElement( driver, assignmentNames );
        WebElement editAssignment = SMUtils.getWebElementDirect( driver, AssignmentEllispeGrandRoot, ellipsisMenuRootCSS, editAssignmentchild );
        Log.message( "Edit Assignment option is displayed in Ellipsis" );
        return SMUtils.getTextOfWebElement( editAssignment, driver );
    }

    /**
     * To Get PauseAssignmentForStudent Ellipsis option at assignment level
     * 
     * @return
     */
    public String pauseAssignmentForStudentInEllipsis() {
        SMUtils.waitForElement( driver, assignmentNames );
        WebElement pasueAssignment = SMUtils.getWebElementDirect( driver, AssignmentEllispeGrandRoot, ellipsisMenuRootCSS, pauseAssignmentForStudentchild );
        Log.message( "Pasue Assignment option is displayed in Ellipsis" );
        return SMUtils.getTextOfWebElement( pasueAssignment, driver );
    }

    /**
     * To Get RemoveStudent Ellipsis option at assignment level
     * 
     * @return
     */
    public String removeStudentFromAssignmentInEllipsis() {
        SMUtils.waitForElement( driver, assignmentNames );
        WebElement removeStudent = SMUtils.getWebElementDirect( driver, AssignmentEllispeGrandRoot, ellipsisMenuRootCSS, removeStudentFromAssignmentchild );
        Log.message( "Remove Student from Assignments option is displayed in Ellipsis" );
        return SMUtils.getTextOfWebElement( removeStudent, driver );
    }

    /**
     * To Click Remove button in the 'Remove Student' Popup
     */
    public void clickRemoveButtonInStudentRemovePopup() {
        WebElement removeButton = removeAndCancelButton( Constants.Students.removeText );
        SMUtils.waitForElement( driver, removeButton );
        Log.event( "Clicking on 'Remove' button in pop up modal" );
        SMUtils.clickJS( driver, removeButton );
        Log.message( "Clicked Remove button in Remove Student popup under the Assignments in the Students tab" );
    }

    /**
     * To View FluencyFiles popup from student page
     * 
     * @return
     */
    public void fluencyFilesFromAssignment( String assignmentName ) {
        SMUtils.waitForElement( driver, assignmentNames );
        for ( WebElement trElement : assignmentListRoot ) {
            WebElement lblAssignmentName = trElement.findElement( By.cssSelector( lblAssignmentsName ) );
            if ( lblAssignmentName.getText().trim().equals( assignmentName ) ) {
                SMUtils.scrollIntoView( driver, lblAssignmentName );
                WebElement elipsis = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), elliipsisParentRootCSS );
                SMUtils.clickJS( driver, elipsis );
                WebElement fluencyFilesFromAssignment = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), ellipsisMenuRootCSS, fluencyFileschild );
                SMUtils.clickJS( driver, fluencyFilesFromAssignment );
                Log.message( "Fluency Files popup is clicked !" );
                SMUtils.nap( 2 ); // required for page refresh
                break;
            }
        }
    }

    /**
     * To Verify Cancel button is displayed in Popup
     */
    public boolean isDisplayedCancelBtnInPopup() {
        SMUtils.waitForElement( driver, cancelBtnRootFluencyPopup );
        Log.event( "Clicking on Cancel btton in pop up modal" );
        WebElement cancelButton = SMUtils.getWebElement( driver, cancelBtnRootFluencyPopup, assignmentCancelBtn );
        return cancelButton.isDisplayed();
    }

    /**
     * Clicking cancel button in the Fluency Files Popup
     */
    public void clickCancelButtonInFluencyFilesPopup() {
        WebElement cancel = SMUtils.getWebElement( driver, cancelBtnRootFluencyPopup, assignmentCancelBtn );
        SMUtils.click( driver, cancel );
        Log.message( "Cancel button clicked" );
    }

    /**
     * To click 'View assignment' option in student page
     * 
     * @param AssignmentName
     * @return
     */
    public AssignmentDetailsPage viewAssignmnetFromStudent( String assignmentName ) {
        SMUtils.waitForElement( driver, assignmentNames );
        for ( WebElement trElement : assignmentListRoot ) {
            WebElement lblAssignmentName = trElement.findElement( By.cssSelector( lblAssignmentsName ) );
            if ( lblAssignmentName.getText().trim().equals( assignmentName ) ) {
                SMUtils.scrollIntoView( driver, lblAssignmentName );
                WebElement elipsis = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), elliipsisParentRootCSS );
                SMUtils.clickJS( driver, elipsis );
                WebElement viewAssignmentFromStudent = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), ellipsisMenuRootCSS, viewAssignmentchild );
                SMUtils.clickJS( driver, viewAssignmentFromStudent );
                Log.message( "View Assignment option is clicked !" );
                return new AssignmentDetailsPage( driver );
            }
        }
        Log.message( "Given Assignment is not present" );
        return null;
    }

    /**
     * To click 'Edit assignment settings' option in students page
     * 
     * @return
     */
    public void editAssignmentSettingsFromAssignment( String assignmentName ) {
        SMUtils.waitForElement( driver, assignmentNames );
        for ( WebElement trElement : assignmentListRoot ) {
            WebElement lblAssignmentName = trElement.findElement( By.cssSelector( lblAssignmentsName ) );
            if ( lblAssignmentName.getText().trim().equals( assignmentName ) ) {
                SMUtils.scrollIntoView( driver, lblAssignmentName );
                WebElement elipsis = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), elliipsisParentRootCSS );
                SMUtils.clickJS( driver, elipsis );
                WebElement editAssignmentSettingsFromAssignment = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), ellipsisMenuRootCSS, editAssignmentchild );
                SMUtils.clickJS( driver, editAssignmentSettingsFromAssignment );
                Log.message( "Edit Assignment Settings popup is clicked !" );
                SMUtils.nap( 2 ); // required for page refresh
                break;
            }
        }
    }

    /**
     * To Pause assignment from student page
     * 
     * @return
     */
    public void pasueStudentFromAssignment( String assignmentName ) {
        SMUtils.waitForElement( driver, assignmentNames );
        for ( WebElement trElement : assignmentListRoot ) {
            WebElement lblAssignmentName = trElement.findElement( By.cssSelector( lblAssignmentsName ) );
            if ( lblAssignmentName.getText().trim().equals( assignmentName ) ) {
                SMUtils.scrollIntoView( driver, lblAssignmentName );
                WebElement elipsis = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), elliipsisParentRootCSS );
                SMUtils.clickJS( driver, elipsis );
                WebElement pauseStudentFromAssignment = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), ellipsisMenuRootCSS, pauseAssignmentForStudentchild );
                SMUtils.clickJS( driver, pauseStudentFromAssignment );
                SMUtils.clickJS( driver, getButtonsFromPopup( "Pause" ) );
                Log.message( assignmentName + " assignment Paused to student sucesfully!" );
                SMUtils.nap( 2 ); // required for page refresh
                break;
            }
        }
    }

    /**
     * To Resume assignment from student page
     * 
     * @return
     */
    public void resumeStudentFromAssignment( String assignmentName ) {
        SMUtils.waitForElement( driver, assignmentNames );
        for ( WebElement trElement : assignmentListRoot ) {
            WebElement lblAssignmentName = trElement.findElement( By.cssSelector( lblAssignmentsName ) );
            if ( lblAssignmentName.getText().trim().equals( assignmentName ) ) {
                SMUtils.scrollIntoView( driver, lblAssignmentName );
                WebElement elipsis = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), elliipsisParentRootCSS );
                SMUtils.clickJS( driver, elipsis );
                WebElement resumeStudentFromAssignment = SMUtils.getWebElementDirect( driver, trElement.findElement( By.cssSelector( ellipsisGrandRootCSS ) ), ellipsisMenuRootCSS, resumeAssignmentForStudentchild );
                SMUtils.clickJS( driver, resumeStudentFromAssignment );
                SMUtils.clickJS( driver, getButtonsFromPopup( "Resume" ) );
                Log.message( assignmentName + " assignment resumed to student sucesfully!" );
                SMUtils.nap( 2 ); // required for page refresh
                break;
            }
        }
    }

    /**
     * Assignment Paused
     */
    public boolean isAssignmentPaused( String AssignmentName ) {
        SMUtils.waitForElement( driver, capturePaused );
        return capturePaused.isDisplayed();
    }

    /**
     * Assignment Completed
     */
    public boolean isAssignmentCompleted( String AssignmentName ) {
        SMUtils.waitForElement( driver, captureCompleted );
        return captureCompleted.isDisplayed();
    }

    /**
     * To Verify Close icon (x) is displayed in Popup
     */
    public boolean isDisplayedCloseIcon() {
        SMUtils.waitForElement( driver, closeIconInPopup );
        Log.event( "Clicking on Close icon in pop up modal" );
        WebElement xIcon = SMUtils.getWebElement( driver, closeIconInPopup, xIconInPopup );
        return xIcon.isDisplayed();
    }

    /**
     * To Click Close icon (x) in the FluencyFiles,
     * EditAssigmentSettings,PasueAssignment,ResumeAssignment,RemoveStudent
     * Popup's
     */
    public void clickCloseIconInAssignmentsPopup() {
        SMUtils.waitForElement( driver, closeIconInPopup );
        Log.event( "Clicking on Close icon in pop up modal" );
        WebElement xIcon = SMUtils.getWebElement( driver, closeIconInPopup, xIconInPopup );
        SMUtils.clickJS( driver, xIcon );
        Log.message( "Clicked close icon in the corresponding popup" );
    }

    /**
     * To verify View Details link is present or not in Last Session Skills
     * section
     * 
     * @return
     * @throws Exception
     */
    public boolean verifyViewDetailsOption_ColorCodeInLastSession() throws Exception {
        boolean status = false;
        Log.event( "Verifying the View Details link and View Details color code in Last Session Skills" );
        SMUtils.waitForElement( driver, lastSessionViewDetails );
        if ( lastSessionViewDetails.getText().trim().equals( "View Details" ) ) {
            SMUtils.checkBackgroundColor( lastSessionViewDetails, Constants.MasteryUI.LO_COLOR_CODE );
            status = true;
        }
        Log.event( "Verified the View Details link and View Details color code in Last Session Skills" );
        return status;
    }

    /**
     * To click the View Details link in Last Session Skills section
     */
    public void clickViewDetailsInLastSession() {
        SMUtils.waitForElement( driver, lastSessionViewDetails );
        Log.event( "Clicking View Details link in Last Session Skills" );
        SMUtils.click( driver, lastSessionViewDetails );
        Log.message( "Clicked View Details link in Last Session Skills" );
    }

    /**
     * To get the list of assignments in Last Session dropdown
     * 
     */

    public boolean verifySubjectTextInLastSession( String SubjectToCheck ) {
        boolean status = false;
        Log.event( "Verifying the " + SubjectToCheck + "assignment display in Last Session Skills dropdown" );
        SMUtils.waitForElement( driver, lastSessionDefaultSubject );
        if ( lastSessionDefaultSubject.getText().trim().equals( SubjectToCheck ) )
            status = true;
        Log.event( "Verified the " + SubjectToCheck + "assignment display in Last Session Skills dropdown" );
        return status;
    }

    /**
     * To verify subject in drodpown present in Last Session Skills section
     * 
     * @param SubjectToCheck
     * @throws Exception
     */
    public List<String> getAssignmentFromLastSessionDropDown() throws Exception {

        SMUtils.waitForElement( driver, lastSessionDefaultSubject );
        try {
            List<String> getAssignmemts = lastSessionDropDownValues.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
            return getAssignmemts;
        } catch ( Exception e ) {
            Log.message( "Subject Not Found" );
            Log.exception( e, driver );
            return null;
        }
    }

    /**
     * To get all the student Id
     * 
     * @return
     */
    public List<String> getStudentIds() {
        List<String> studentIds = new ArrayList<String>();
        studentIdColumnValues.stream().forEach( element -> {
            studentIds.add( element.getText().trim() );
        } );
        return studentIds;
    }

    /**
     * To click the column Name and select the sorting type
     * 
     * @param columnName
     * @param sortingType - Ascending(up) or Descending(down)
     */
    public void clickColumnnAndSort( String columnName, String sortingType ) {
        WebElement headingElement = columnNames.stream().filter( heading -> columnName.equals( heading.getText().trim() ) ).findFirst().get();
        SMUtils.click( driver, headingElement );
        Log.message( "Clicked Column " + columnName );
        String state = getArrowStateOfColumn();
        if ( state.equals( Constants.DESCENDING ) ) {
            Log.fail( "The default sorting is not in ASCENDING Order" );
        }
        if ( sortingType.equals( Constants.DESCENDING ) ) {
            SMUtils.click( driver, arrowIcon );
            Log.message( "Clicked Arrow for Down" );
        }
    }

    /**
     * To get the state of Arrow UP or Down
     * 
     * @return
     */
    public String getArrowStateOfColumn() {
        String status = arrowIcon.getAttribute( "name" );
        if ( status.equals( arrowUp ) ) {
            return Constants.ASCENDING;
        } else if ( status.equals( arrowDown ) ) {
            return Constants.DESCENDING;
        } else {
            Log.fail( "Arrow icon is not found" );
            return null;
        }
    }

    /**
     * To get all the values as List in Student Listing page
     * 
     * @param columnName - First Name to Grade.
     * @return
     */
    public List<String> getAllValuesAsListForColumn( String columnName ) {

        if ( !isZeroState() ) {
            if ( columnName.equals( Students.COLUMN_FIRST_NAME ) ) {
                return getAllStudentsFirsNames();
            } else if ( columnName.equals( Students.COLUMN_LAST_NAME ) ) {
                return getAllStudentsLastNames();
            } else if ( columnName.equals( Students.COLUMN_USER_NAME ) ) {
                return getAllStudentsUserNames();
            } else if ( columnName.equals( Students.COLUMN_STUDNET_ID ) ) {
                return getAllStudentsStudentIds();
            } else if ( columnName.equals( Students.COLUMN_GRADE ) ) {
                return getAllStudentsGrades();
            } else {
                Log.failsoft( "Error in ColumnName" );
                return null;
            }
        } else {
            Log.message( "There is no student!" );
            return null;
        }
    }

    /**
     * To get the column Name in which arrow icon present
     * 
     * @return
     */
    public String getColumnNameOfArrow() {
        WebElement parent = arrowIcon.findElement( By.xpath( "../../.." ) );
        WebElement columnText = parent.findElement( By.cssSelector( "span" ) );
        return columnText.getText().trim();
    }

    /**
     * Verify the column header in Student Listing Page
     */
    public void verifyHeaders() {
        if ( !isZeroState() ) {
            ColumnHeader.forEach( element -> {
                String columnName = SMUtils.getChildWebElementFromParent( element, "span" ).getText().trim();

                if ( columnName.equals( Students.COLUMN_FIRST_NAME ) ) {
                    Log.pass( "The First name header is Present" );
                } else if ( columnName.equals( Students.COLUMN_LAST_NAME ) ) {
                    Log.pass( "The Last name header is Present" );
                } else if ( columnName.equals( Students.COLUMN_USER_NAME ) ) {
                    Log.pass( "The User name header is Present" );
                } else if ( columnName.equals( Students.COLUMN_GRADE ) ) {
                    Log.pass( "The Grade header is Present" );
                } else if ( columnName.equals( Students.COLUMN_STUDNET_ID ) ) {
                    Log.pass( "STUDNET_ID header is Present" );
                } else if ( columnName.equals( Students.COLUMN_STUDNET_ID ) ) {
                    Log.pass( "STUDNET_ID header is Present" );
                } else {
                    Log.failsoft( "Header Text is not match for" + columnName );
                }

            } );
        } else {
            Log.message( "There is no student!" );
        }
    }

    /**
     * To find group name is present or not in Add Students to Group popup
     * 
     * @return
     */
    public Boolean isGroupnamePresentInAddStudentPopup( String groupName ) {
        SMUtils.nap( 2 ); //Waiting to disappear the loading icon
        Boolean status = false;
        for ( WebElement ele : groupListInPopup ) {
            SMUtils.scrollWebElementToView( driver, ele );
            if ( ele.getText().trim().equals( groupName ) )
                status = true;
            ;
        }

        return status;
    }

    /**
     * Return true if checkBox is checked for student Id
     * 
     * @param studentID
     * @return
     */
    public boolean isStudentChecked( String studentID ) {

        AtomicReference<String> flag = new AtomicReference<>();
        flag.set( "false" );

        listStudentID.stream().filter( tdElement -> tdElement.getText().trim().equals( studentID ) ).forEach( tdElement -> {
            WebElement btn = SMUtils.getWebElementDirect( driver, tdElement.findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( checkBoxCSS ) ), addBtnCSS );

            String color = SMUtils.convertColorFromRgbaToHex( btn.getCssValue( Constants.Students.BACKGROUND_COLOR ) );
            if ( color.equals( Constants.CHECKBOX_COLOR ) || color.equals( Constants.TOP_CHECKBOX_COLOR ) ) {
                flag.set( "true" );
            } else {
                flag.set( "false" );
            }
        } );
        return Boolean.parseBoolean( flag.get() );
    }

    /**
     * Return the student Id s of whose checkbox is checked
     * 
     * @return
     */
    public List<String> returnCheckedStudentIds() {
        List<String> studentIds = new ArrayList<String>();
        if ( !isZeroState() ) {
            listStudentUsernames.stream().forEach( tdElement -> {
                String elementText = tdElement.getText().trim();
                WebElement btn = SMUtils.getWebElementDirect( driver, tdElement.findElement( By.xpath( "./.." ) ).findElement( By.cssSelector( checkBoxCSS ) ), addBtnCSS );
                String color = SMUtils.convertColorFromRgbaToHex( btn.getCssValue( Constants.Students.BACKGROUND_COLOR ) );
                if ( color.equals( Constants.CHECKBOX_COLOR ) || color.equals( Constants.TOP_CHECKBOX_COLOR ) ) {
                    studentIds.add( elementText );
                }
            } );
        }
        return studentIds;
    }

    /**
     * Return true if Header check box is
     * 
     * @return
     */
    public boolean isTopCheckBoxisChecked() {
        String color = SMUtils.convertColorFromRgbaToHex( SMUtils.getWebElementDirect( driver, topCheckBox, topCheckBoxCSS ).getCssValue( Constants.Students.BACKGROUND_COLOR ) );
        if ( color.equals( Constants.TOP_CHECKBOX_COLOR ) ) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isCheckBoxSelected( String studentID ) {
        boolean status = false;
        SMUtils.waitForElement( driver, studentTable, 5 );
        for ( WebElement tdElement : listStudentUsernames ) {
            String elementText = tdElement.getText().trim();
            if ( elementText.equals( studentID ) ) {
                WebElement parentElement = tdElement.findElement( By.xpath( "./.." ) );
                WebElement checkBoxRoot = parentElement.findElement( By.cssSelector( checkBoxCSS ) );
                WebElement btn = SMUtils.getWebElementDirect( driver, checkBoxRoot, addBtnCSS );
                if ( btn.isSelected() )
                    status = true;
                Log.event( "Checkbox is selected/unselected for " + studentID );
                break;
            }
        }
        return status;
    }

    /**
     * To verify mastery zero state
     *
     * @return
     */
    public boolean verifyMasteryZeroState() {
        SMUtils.waitForElement( driver, masteryZeroStateMessage );
        String zeroStateHeaderFromUI = masteryZeroStateHeader.getText().trim();
        String zeroStateMessageFromUI = masteryZeroStateMessage.getText().trim();
        if ( zeroStateHeaderFromUI.equalsIgnoreCase( Constants.Students.MASTERY_ZERO_STATE_MESSAGE.get( 0 ) ) && zeroStateMessageFromUI.equalsIgnoreCase( Constants.Students.MASTERY_ZERO_STATE_MESSAGE.get( 1 ) ) ) {
            Log.pass( "Zero state message is displayed successfully!" );
            return true;
        } else {
            Log.fail( "Zero state message is not displayed successfully!" );
            return false;
        }
    }

    /**
     * To get the Last session skills popup header
     * 
     * @return
     */
    public String getSkillnameFontInPopup() {
        SMUtils.waitForElement( driver, skillnameInPopup, 8 );
        String colorRgb = skillnameInPopup.getCssValue( "color" ).trim();
        String hexColor = Color.fromString( colorRgb ).asHex();
        Log.message( "Skill name text color is : " + hexColor );
        return hexColor;
    }

    /**
     * To get progress bar background color in last session skills popup
     * 
     * @return
     */
    public String progressBarBGColorInPopup() {
        SMUtils.waitForElement( driver, progressBarPopup );
        WebElement popupProgressBar = SMUtils.getWebElementDirect( driver, progressBarPopup, progressBarSkillsPopup );
        String colorRgb = popupProgressBar.getCssValue( Constants.Students.BACKGROUND_COLOR ).trim();
        String hexColor = Color.fromString( colorRgb ).asHex();
        Log.message( "Progressbar background color is : " + hexColor );
        return hexColor;
    }

    /**
     * To get progress bar background color in last session skills popup
     * 
     * @return
     */
    public String progressBarBGColorReadingInPopup() {
        SMUtils.waitForElement( driver, progressBarPopup );
        WebElement popupProgressBar = SMUtils.getWebElementDirect( driver, progressBarPopupReading, progressBarSkillsPopup );
        String colorRgb = popupProgressBar.getCssValue( Constants.Students.BACKGROUND_COLOR ).trim();
        String hexColor = Color.fromString( colorRgb ).asHex();
        Log.message( "Progressbar background color is : " + hexColor );
        return hexColor;
    }

    /**
     * To get progress bar text color in last session skills popup
     * 
     * @return
     */
    public String progressBarTextColorInReadingPopup() {
        SMUtils.waitForElement( driver, progressBarPopup );
        WebElement popupProgressBar = SMUtils.getWebElementDirect( driver, progressBarPopupReading, progressBarSkillsPopup );
        String colorRgb = popupProgressBar.getCssValue( "color" ).trim();
        String hexColor = Color.fromString( colorRgb ).asHex();
        Log.message( "Progressbar text color is : " + hexColor );
        return hexColor;
    }

    /**
     * To check Close icon in the Last session Skills popup
     * 
     * @return
     */
    public boolean checkCloseIcon() {
        SMUtils.waitForElement( driver, lastSessionPopupCloseIcon );
        WebElement closeIcon = SMUtils.getWebElementDirect( driver, lastSessionPopupCloseIcon, lastSessionPopupIconClose );
        return closeIcon.isDisplayed();
    }

    /**
     * To get LO number from Skills tested popup
     * 
     * @return
     */
    public String getLONumberfromSkillsPopup() {
        SMUtils.waitForElement( driver, loNumberinSkillsPopup );
        return loNumberinSkillsPopup.getText().trim();
    }

    /**
     * To click LO number in Skills tested popup
     * 
     * @return
     */
    public String getLONumberfromUrl() {
        SMUtils.waitForElement( driver, loNumberinSkillsPopup );
        SMUtils.clickJS( driver, loNumberinSkillsPopup );
        Log.message( "LO number clicked Successfully" );
        String currentWindow = driver.getWindowHandle();
        Set<String> windowHandles = driver.getWindowHandles();
        List<String> windowList = new ArrayList<>( windowHandles );
        driver.switchTo().window( windowList.get( 1 ) );
        String lourl = driver.getCurrentUrl();
        Log.message( lourl );
        return lourl;
    }
    
    /**
     * To click first LO number in Skills tested popup
     * 
     * @return
     */
    public void clickFirstLO() {

    	WebElement firstLink = LOLinks.get(0);
    	firstLink.click();
        
    }
    
    /**
     * To click first LO number in Skills tested popup
     * 
     * @return
     */
    public void clickFirstArrow() {

    	WebElement firstArrow = SMUtils.getChildWebElementFromParent(arrowRoot,".icon-inner");
    	firstArrow.click();
        
    }

    /***
     * This method get the Mastery Subject Drop down default text from the
     * Subject drop down
     * 
     * @return - String
     */

    public String getMasterySubjectDropdownDefaultText() {
        SMUtils.waitForElement( driver, subjectDefaultText );
        String text = SMUtils.getTextOfWebElement( subjectDefaultText, driver ).trim();
        Log.message( "The subject drop down selected text is retrieved: " + text );
        return text;
    }

    /***
     * This method get the Mastery Subject Drop down default text from the
     * Subject drop down
     * 
     * @return - String
     */

    public void clickMasteryHelpIcon() {
        SMUtils.waitForElement( driver, masteryHelpIconroot );
        WebElement helpIcon = SMUtils.getWebElement( driver, masteryHelpIconroot, masteryHelpIconChild );
        SMUtils.clickJS( driver, helpIcon );
        Log.message( "Student Details - Mastery Sub-Navigation - i help icon clicked" );
        new WebDriverWait( driver, Duration.ofSeconds( 10 ) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
    }

    /***
     * Select the select all option in the mastery assignments drop down
     * 
     * @return boolean
     */
    public boolean selectMasteryAssignmentSelectAll() {
        expandMasteryAssignmentDropdown();
        WebElement chbxSelectAll = SMUtils.getWebElementDirect( driver, assignmentsDropDownroot, assignmentsDropdownvalueschild, txtDropDownMSValue );
        SMUtils.clickJS( driver, chbxSelectAll );
        Log.message( "Select All option is selected" );
        return chbxSelectAll.isSelected();
    }

    /***
     * This method help us to verify the check Select all is selected
     * 
     * @return - boolean
     */
    public boolean checkAllMasteryAssignmentsSelected() {
        boolean result = false;
        expandMasteryAssignmentDropdown();
        List<WebElement> allElements = SMUtils.getWebElements( driver, assignmentsDropDownroot, assignmentsDropdownvalueschild );
        for ( WebElement eachElement : allElements ) {
            WebElement chkbx = SMUtils.getWebElement( driver, eachElement, assignmentDropdownEachCheckbox );
            if ( chkbx.isSelected() ) {
                result = true;
            }
        }
        if ( result ) {
            Log.message( "The SELECT ALL option is selected in the Assignment drop down" );
            return true;
        } else {
            Log.message( "The SELECT ALL option is not selected in the Assignment drop down" );
            return false;
        }
    }

    /***
     * This method helps us get the selected values from the assignment drop
     * down
     * 
     * @return - List<String> The list of options selected in the Mastery
     *         Assignments drop down
     * 
     */

    public List<String> getAllMasteryAssignmentsSelectedValues() {
        collapseMasteryAssignmentDropdown();
        expandMasteryAssignmentDropdown();
        SMUtils.nap( 3 ); // This is required for MAC to wait and get the elements
        SMUtils.waitForElement( driver, assignmentsDropDownroot );
        List<WebElement> allElements = SMUtils.getWebElements( driver, assignmentsDropDownroot, assignmentsDropdownvalueschild );
        return allElements.stream().filter( element -> SMUtils.getWebElement( driver, element, assignmentDropdownEachCheckbox ).isSelected() ).map(
                element -> SMUtils.getWebElement( driver, element, assignmentsDropdownEachValueChild ).getText().trim() ).collect( Collectors.toList() );
    }

    /***
     * This method helps us to expand the assignment drop down
     * 
     * @return - void
     */

    public void expandMasteryAssignmentDropdown() {
        SMUtils.waitForElement( driver, assignmentsDropDownroot, 6 );
        WebElement dropDownIcon = SMUtils.getWebElement( driver, assignmentsDropDownroot, assignmentsDropdowniconchild );
        if ( dropDownIcon.getAttribute( "aria-pressed" ).equals( "false" ) ) {
            WebElement dropDown = SMUtils.getWebElement( driver, assignmentsDropDownroot, assignmentsDropdownchild );
            SMUtils.clickJS( driver, dropDown );
            Log.message( "The Assignment drop down is expanded successfully" );
        } else {
            Log.message( "The Assignment drop down is already expanded" );
        }
    }

    /***
     * This method helps us to collapse the assignment drop down
     * 
     * @return - void
     */

    public void collapseMasteryAssignmentDropdown() {
        SMUtils.waitForElement( driver, assignmentsDropDownroot, 6 );
        WebElement dropDownIcon = SMUtils.getWebElement( driver, assignmentsDropDownroot, assignmentsDropdowniconchild );
        if ( dropDownIcon.getAttribute( "aria-pressed" ).equals( "true" ) ) {
            WebElement dropDown = SMUtils.getWebElement( driver, assignmentsDropDownroot, assignmentsDropdownchild );
            SMUtils.clickJS( driver, dropDown );
            Log.message( "The Assignment drop down is collapsed successfully" );
        } else {
            Log.message( "The Assignment drop down is already Collapsed" );
        }

    }

    /***
     * This method helps us to get the options from the Mastery Assignments drop
     * down
     * 
     * @return - List<String> The list of options in the Mastery Assignments
     *         drop down
     */

    public List<String> getMasteryAssignments() {
        expandMasteryAssignmentDropdown();
        List<WebElement> allElements = SMUtils.getWebElements( driver, assignmentsDropDownroot, assignmentsDropdownvalueschild );
        List<String> values = allElements.stream().map( element -> SMUtils.getWebElement( driver, element, assignmentsDropdownEachValueChild ).getText().trim() ).collect( Collectors.toList() );
        Log.message( "The Assignment drop down values are collected" );
        return values;
    }

    /***
     * This method helps us to get the select one or more assignment values in
     * the drop down
     * 
     * @return - void
     */

    public void selectMasteryAssignments( String... value ) {
        expandMasteryAssignmentDropdown();
        selectMasteryAssignmentSelectAll();
        List<WebElement> allElements = SMUtils.getWebElements( driver, assignmentsDropDownroot, assignmentsDropdownvalueschild );
        allElements.stream().filter( element -> Arrays.stream( value ).anyMatch( assignmentName -> assignmentName.equalsIgnoreCase( SMUtils.getWebElement( driver, element, assignmentsDropdownEachValueChild ).getText().trim() ) ) ).forEach( element -> {
            WebElement chbxForAssignment = SMUtils.getWebElement( driver, element, txtDropDownMSValue );
            SMUtils.clickJS( driver, chbxForAssignment );
            Log.message( "The value is selected in Assignment Drop down" );
        } );

    }

    /***
     * This method helps us to verify the Apply filter is disabled or not
     * 
     * @return - boolean -> true if apply filter is disabled false if the apply
     *         filter is enabled
     */

    public boolean verifyApplyFilterisDisabled() {
        SMUtils.waitForElement( driver, masteryApplyFilter );
        WebElement element = SMUtils.getWebElement( driver, masteryApplyFilter, masteryApplyFilterchild );
        if ( element.isEnabled() ) {
            Log.message( "Apply filter button is enabled" );
            return false;
        } else {
            Log.message( "Apply filter button is disabled" );
            return true;
        }
    }

    /***
     * This method helps us to verify the Apply filter is displayed and
     * clickable
     * 
     * @return - boolean -> true if the Apply filter button is enabled and
     *         displayed false if the Apply filter button is disabled and not
     *         displayed
     */

    public boolean verifyApplyFilterButton() {
        SMUtils.waitForElement( driver, masteryApplyFilter );
        WebElement element = SMUtils.getWebElement( driver, masteryApplyFilter, masteryApplyFilterchild );
        if ( element.isDisplayed() && element.isEnabled() ) {
            Log.message( "The Apply Filter is displayed and enabled" );
            return true;
        } else {
            Log.message( "The Apply Filter is not displayed and disabled" );
            return false;
        }
    }

    /***
     * This method helps us to get the No data of Zero state for Mastery
     * assignments
     * 
     * @return - String - No Data text
     */

    public String getMasteryNoData() {
        SMUtils.waitForElement( driver, masteryNoData );
        String text = masteryNoData.getText().trim();
        Log.message( "Mastery No Data text is retrieved: " + text );
        return text;
    }

    /***
     * This method helps us to get the Zero state for Mastery assignments
     * 
     * @return - String - Zero State Message
     */

    public String getMasteryZeroState() {
        SMUtils.waitForElement( driver, masteryZeroState );
        String text = masteryZeroState.getText().trim();
        Log.message( "Mastery Zero State text is retrieved: " + text );
        return text;
    }

    /**
     * To click the column Name and select the sorting type
     * 
     * @param columnName
     * @param sortingType - Ascending(up) or Descending(down)
     */
    public void getAssignmentName( String assignmentName ) {
        WebElement headingElement = columnNames.stream().filter( heading -> assignmentName.equals( heading.getText().trim() ) ).findFirst().get();
        SMUtils.click( driver, headingElement );
        Log.message( "Assignment exist : " + assignmentName );
    }

    /**
     * To Verify Progress bar color and Percentage text
     * 
     * @return
     * @throws Exception
     */
    public boolean skillTestedProgressBarAndTextColor( String progressBarColor, String progressTextColor ) throws Exception {
        boolean status = false;
        SMUtils.waitForElement( driver, lastSessionGraph );
        WebElement parent = SMUtils.getWebElementDirect( driver, progressBarRoot.get( 0 ), progressBarCSS );
        status = SMUtils.checkBackgroundColor( parent, progressBarColor ) && SMUtils.checkColor( parent, progressTextColor );
        return status;
    }

    /**
     * To Verify number of attempt color in Last Session Skills
     * 
     * @return
     * @throws Exception
     */
    public boolean skillTestedAttemptColor( String color ) throws Exception {
        boolean status = false;
        SMUtils.waitForElement( driver, lastSessionGraph );
        WebElement parent = skillsCorrectList.get( 0 );
        status = SMUtils.checkColor( parent, Constants.ATTEMPT_COLOR_CODE );
        return status;
    }

    /**
     * To verify skills link color in Last Session Skills section
     * 
     * @param skillName
     * @return
     * @throws Exception
     */
    public boolean skillNameLinkColor( String color ) throws Exception {
        boolean status = false;
        SMUtils.waitForElement( driver, lastSessionGraph );
        WebElement parent = skillLink.get( 0 );
        status = SMUtils.checkColor( parent, Constants.MasteryUI.LO_ID_COLOR_CODE );
        return status;
    }

    /**
     * To get the progress percentage list from Last Session Skills
     */
    public List<String> getProgressPercentage() throws Exception {
        return progressBarRoot.stream().map( element -> SMUtils.getWebElementDirect( driver, element, progressBarCSS ) ).map( element -> element.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To check whether tooltip for Title is displayed or not.
     * 
     * @return
     */
    public boolean isToolTipDisplayedForTitle() {
        SMUtils.waitForElement( driver, titleTooltip, 5 );
        SMUtils.moveToElementSelenium( driver, titleTooltip );
        Log.message( titleTooltip.getText() );
        return titleTooltip.isDisplayed();
    }

    /**
     * To Check whether tooltip for Last session is displayed or not
     * 
     * @return
     */
    public boolean isTooltipDisplayedForLastSession() {
        SMUtils.waitForElement( driver, lastSessionTooltip, 5 );
        return lastSessionTooltip.isDisplayed();
    }

    /**
     * To Check whether tooltip for IP Level is displayed or not
     * 
     * @return
     */
    public boolean isTooltipDisplayedForIpLevel() {
        SMUtils.waitForElement( driver, ipLevelTooltip, 5 );
        return ipLevelTooltip.isDisplayed();
    }

    /**
     * To Check whether tooltip for Assigned Level is displayed or not
     * 
     * @return
     */
    public boolean isTooltipDisplayedForAssignedLevel() {
        SMUtils.waitForElement( driver, assignedLevelTooltip, 5 );
        return assignedLevelTooltip.isDisplayed();
    }

    /**
     * To Check whether tooltip for Current Level is displayed or not
     * 
     * @return
     */
    public boolean isTooltipDisplayedForCurrentLevel() {
        SMUtils.waitForElement( driver, currentLevelTooltip, 5 );
        return currentLevelTooltip.isDisplayed();
    }

    /**
     * To Check whether tooltip for Gain is displayed or not
     * 
     * @return
     */
    public boolean isTooltipDisplayedForGain() {
        SMUtils.waitForElement( driver, gainTooltip, 5 );
        return gainTooltip.isDisplayed();
    }

    /**
     * To Check whether tooltip for %Correct is displayed or not
     * 
     * @return
     */
    public boolean isTooltipDisplayedForPercentageCorrect() {
        SMUtils.waitForElement( driver, percentageCorrectTooltip, 5 );
        return percentageCorrectTooltip.isDisplayed();
    }

    /**
     * 
     * To get LastSession Details
     * 
     * @param assignmentName
     * @return
     */
    public String getLastSessionDetails( String assignmentName ) {
        SMUtils.waitForElement( driver, assignmentNames );
        String lastSessionValue = null;
        for ( WebElement tableRow : assignmentListRoot ) {
            WebElement lblAssignmentName = tableRow.findElement( By.cssSelector( lblAssignmentsName ) );
            if ( lblAssignmentName.getText().trim().equals( assignmentName ) ) {
                lastSessionValue = tableRow.findElements( By.cssSelector( tableColumn ) ).get( 1 ).findElement( By.cssSelector( labelLastSession ) ).getText();
                break;
            }
        }
        return lastSessionValue;
    }

    /**
     * To get IPLevel values
     * 
     * @return
     */
    public List<String> getLastSessionValues() {
        SMUtils.waitForElement( driver, assignmentNames );
        List<String> lastSessionValues = new ArrayList<String>();

        for ( WebElement tableRow : assignmentListRoot ) {
            lastSessionValues.add( tableRow.findElements( By.cssSelector( tableColumn ) ).get( 1 ).findElement( By.cssSelector( labelLastSession ) ).getText() );
        }
        return lastSessionValues;
    }

    /**
     * To get IPLevel values
     * 
     * @return
     */
    public List<String> getIpLevelValues() {
        SMUtils.waitForElement( driver, assignmentNames );
        List<String> ipLevelValues = new ArrayList<String>();
        for ( WebElement tableRow : assignmentListRoot ) {
            ipLevelValues.add( tableRow.findElements( By.cssSelector( tableColumn ) ).get( 2 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
        }
        return ipLevelValues;
    }

    /**
     * To get Assigned Level values
     * 
     * @return
     */
    public List<String> getAssignedLevelValues() {
        SMUtils.waitForElement( driver, assignmentNames );
        List<String> assignedLevelValues = new ArrayList<String>();
        for ( WebElement tableRow : assignmentListRoot ) {
            assignedLevelValues.add( tableRow.findElements( By.cssSelector( tableColumn ) ).get( 3 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
        }
        return assignedLevelValues;
    }

    /**
     * To get Current Level values
     * 
     * @return
     */
    public List<String> getCurrentLevelValues() {
        SMUtils.waitForElement( driver, assignmentNames );
        List<String> currentLevelValues = new ArrayList<String>();
        for ( WebElement tableRow : assignmentListRoot ) {
            currentLevelValues.add( tableRow.findElements( By.cssSelector( tableColumn ) ).get( 4 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
        }
        return currentLevelValues;
    }

    /**
     * To get Gain values
     * 
     * @return
     */
    public List<String> getGainValues() {
        SMUtils.waitForElement( driver, assignmentNames );
        List<String> gainValues = new ArrayList<String>();
        for ( WebElement tableRow : assignmentListRoot ) {
            gainValues.add( tableRow.findElements( By.cssSelector( tableColumn ) ).get( 5 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
        }
        return gainValues;
    }

    /**
     * To get Percentage Corret values
     * 
     * @return
     */
    public List<String> getPercentageCorrectValues() {
        SMUtils.waitForElement( driver, assignmentNames );
        List<String> percentageCorrectValues = new ArrayList<String>();
        for ( WebElement tableRow : assignmentListRoot ) {
            percentageCorrectValues.add( tableRow.findElements( By.cssSelector( tableColumn ) ).get( 6 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
        }
        return percentageCorrectValues;
    }

    /**
     * To get all the values from Assignment Details page in students Tab
     * 
     * @param assignmentName
     * @return
     * @throws InterruptedException
     */
    public Map<String, String> getStudentAssignmentDetailsPageIPLevelandGain( String assignmentName ) throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver, 60 );
        String tooltipText = null;
        SMUtils.waitForElement( driver, assignmentNames );
        Map<String, String> studentIPandGain = new HashMap<String, String>();
        for ( WebElement tableRow : assignmentListRoot ) {
            WebElement lblAssignmentName = tableRow.findElement( By.cssSelector( lblAssignmentsName ) );
            if ( lblAssignmentName.getText().trim().equals( assignmentName ) ) {
                SMUtils.scrollIntoView( driver, lblAssignmentName );
                studentIPandGain.put( "IP Level", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 2 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "Assigned Level", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 3 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "Current Level", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 4 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "Gain", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 5 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                studentIPandGain.put( "% Correct", tableRow.findElements( By.cssSelector( tableColumn ) ).get( 6 ).findElement( By.cssSelector( labelStudentIPandGain ) ).getText() );
                break;
            }
        }
        return studentIPandGain;
    }

    /**
     * To click the column Name and select the sorting type
     * 
     * @param columnName
     */
    public void sortingColumnnHeaders( String columnName ) {
        try {
            WebElement headingElement = columnNames.stream().filter( heading -> columnName.equals( heading.getText().trim() ) ).findFirst().get();
            SMUtils.click( driver, headingElement );
            Log.message( "Clicked Column " + columnName );
        } catch ( Exception e ) {
            WebElement aftersort = driver.findElement( By.cssSelector( String.format( afterSortingElement, columnName ) ) );
            SMUtils.click( driver, aftersort );
            Log.message( "Clicked Column " + columnName );
        }
    }

    /**
     * To check for completed tag.
     */
    public boolean checkCompletedTag() {

        SMUtils.waitForElement( driver, completedTag, 5 );
        return completedTag.isDisplayed();
    }

    /**
     * 
     * To check for completed tag color.
     */
    public String checkCompletedTagColor() {

        SMUtils.waitForElement( driver, completedTag, 5 );
        String color = completedTag.getCssValue( Constants.Students.BACKGROUND_COLOR );
        return Color.fromString( color ).asHex();
    }

    /**
     * 
     * To check for paused tag color.
     */
    public String checkPausedTagColor() {

        SMUtils.waitForElement( driver, pausedTag, 5 );
        String color = pausedTag.getCssValue( Constants.Students.BACKGROUND_COLOR );
        return Color.fromString( color ).asHex();
    }

    /**
     * To check for Paused tag.
     */
    public boolean checkPausedTag() {

        SMUtils.waitForElement( driver, pausedTag, 5 );
        return pausedTag.isDisplayed();
    }

    /***
     * 
     * This method helps the user to create a student with custom name and
     * custom grade for negative scenarios
     * 
     * @return
     * @throws Exception
     * @author balaji.chandra
     */
    public String createStudent( String firstName, String lastName, String grade ) throws Exception {
        SMUtils.nap( 1 ); //Waiting to disappear the loading icon
        clikAddStudentInStudentListingPage();
        SMUtils.waitForElement( driver, formCreateStudentPopup, 10 );

        if ( !formCreateStudentPopup.isDisplayed() ) {
            throw new Exception( "Create Student pop not visible" );
        }

        txtboxFirstName.sendKeys( firstName );
        txtboxLastName.sendKeys( lastName );
        SMUtils.waitForElement( driver, ddGradeSelection );
        SMUtils.clickJS( driver, ddGradeSelection );
        selectGrade( grade );
        txtboxDatOfBirth.sendKeys( "11/20/2010" );
        txtboxStudentID.sendKeys( firstName );
        txtboxUserName.sendKeys( firstName );
        txtboxPassWord.sendKeys( firstName );
        txtboxConfirmPassword.sendKeys( firstName );
        SMUtils.clickJS( driver, btnCreateStudent );
        ;
        Log.message( "Successfully Created the student: " + firstName );

        SMUtils.nap( 1.5 ); //Waiting to disappear the toast message

        return firstName;
    }

    /**
     * Verfiy the Popup Header and message for Limit 100 or less Student to your
     * group
     * 
     * @return
     */
    public boolean VerifyLimitStudentTo100Popup() {
        new SMUtils().waitForElement( driver, headerForStudentLimit );
        boolean headerTextCorrect = headerForStudentLimit.getText().trim().equals( TOO_MANY_STUDENTS_SELECTED );
        boolean erroeMessageCorrect = MessageForStudentLimit.getText().trim().equals( PLEAE_LIMIT_NUMBER_OF_STUDENT_TO_100_OR_LESS_MESSAGE );
        return ( headerTextCorrect && erroeMessageCorrect ) ? true : false;
    }

    /**
     * Click ok Button in popup
     */
    public void clickOkButton() {
        SMUtils.waitForElement( driver, okButtonRoot, 5 );
        WebElement okButton = new SMUtils().getWebElementDirect( driver, okButtonRoot, "button" );
        new SMUtils().click( driver, okButton );
    }

    /**
     * Click Close button for after created Student Popup Erron Message
     */
    public void clickCloseButton() {
        clickOkButton();
    }

    /**
     * To click the Save button in Add Student To Group Popup
     */
    public void clickSaveButtonOnAddStudentToGroupPopup() {
        SMUtils.click( driver, btnSaveGroup );
    }

    /**
     * Verify the tost message After Stdudent is addded into Groups
     * 
     * @return
     */
    public boolean VerifyToastMessageForAddStudentToGroup() {
        SMUtils.fluentWaitForElement( driver, ToastElement, 5 );
        return ( ToastElement.getText().trim().equals( STUDENTS_ADDED_TO_GROUP_SUCCESSFULLY ) ) ? true : false;
    }

    /**
     * Verify the tost message After Stdudent is addded into Groups
     * 
     * @return
     */
    public boolean VerifyToastMessageForRemoveStudentFromGroup() {
        SMUtils.fluentWaitForElement( driver, ToastElement, 5 );
        return ( ToastElement.getText().trim().equals( STUDENTS_REMOVED_FROM_GROUP_SUCCESSFULLY ) ) ? true : false;
    }

    ArrayList<String> passwordRequirementsText = new ArrayList<String>(
            Arrays.asList( "Password Requirements", "Must be at least eight characters long", "Must contain at least one letter", "Must contain at least one number", "Can not include your name or username" ) );

    /**
     * To Click First Student
     */
    public void clickFirstStudent() {
        SMUtils.waitForElement( driver, firstStudent );

        SMUtils.clickJS( driver, firstStudent );
        Log.message( "Clicked First Student" );
    }

    /**
     * To enter the first name of the student
     * 
     * @param editName
     */
    public void enterFirstName( String editName ) {
        SMUtils.waitForElement( driver, txtboxFirstName );
        txtboxFirstName.clear();
        txtboxFirstName.sendKeys( editName );
        Log.message( "Entered Student first name as: " + editName );
    }

    /**
     * To enter the Last name of the student
     * 
     * @param editLastName
     */
    public void enterLastName( String editLastName ) {
        SMUtils.waitForElement( driver, txtboxLastName );
        txtboxLastName.clear();
        txtboxLastName.sendKeys( editLastName );
        Log.message( "Entered Student first name as: " + editLastName );
    }

    /**
     * To enter the username of the student
     * 
     * @param editUserName
     */
    public void enterUserName( String editUserName ) {
        SMUtils.waitForElement( driver, txtboxUserName );
        txtboxUserName.clear();
        txtboxUserName.sendKeys( editUserName );
        Log.message( "Entered Username as: " + editUserName );
    }

    /**
     * To click change passsword link of the student
     * 
     */
    public void clickChangePassword() {
        SMUtils.scrollToBottomOfPage( driver );
        SMUtils.waitForElement( driver, changePassswordLink );
        SMUtils.clickJS( driver, changePassswordLink );
        Log.message( "Clicked Change Password link" );
    }

    /**
     * To sort the Student ID column
     */
    public void sortBasedOnStudentId() {
        try {
            SMUtils.clickJS( driver, sortBasedOnStudentID );
            Log.message( "clicked on student id" );
        } catch ( NoSuchElementException e ) {
            Log.message( "Page refreshed" );
        }
    }

    /**
     * Verify whether New Password and Confirm Password fields are displayed on
     * clicking Change Password link
     */
    public boolean VerifyNewPasswordandConfirmPasswordisPresent() {
        boolean isNewPasswordExists = new SMUtils().isElementPresent( txbNewPassword );
        boolean isConfirmNewPasswordExists = new SMUtils().isElementPresent( txbConfirmNewPassword );
        return ( isNewPasswordExists && isConfirmNewPasswordExists ) ? true : false;
    }

    /**
     * Click on information icon on New Password
     */
    public void clickInformationCircle() {
        new SMUtils().click( driver, new SMUtils().getWebElementDirect( driver, iIconRoot, "img" ) );
        Log.message( "Clicked (i) icon on the New Password Field" );
    }

    /**
     * Validate the Password requirement Text
     * 
     * @return
     */
    public boolean VerifyPasswordRequirementTexts() {
        ArrayList<String> actualText = new ArrayList<String>();
        actualText.add( new SMUtils().getChildWebElementFromParent( PasswordRequirementRoot, "label" ).getText().trim() );
        List<WebElement> passwordPolicies = SMUtils.getChildWebElementsFromParent( PasswordRequirementRoot, "ul li" );
        actualText.addAll( new SMUtils().getAllTextFromWebElementList( passwordPolicies ) );
        return new SMUtils().compareTwoList( passwordRequirementsText, actualText );
    }

    /**
     * To pass value in to new password field
     * 
     */

    public void modifyNewPassword( String newPassword ) {
        SMUtils.waitForElement( driver, txbNewPassword );
        txbNewPassword.clear();
        txbNewPassword.sendKeys( newPassword );
        Log.message( "newPassword passed in to field successfully" );
    }

    /**
     * To pass value in to confirm password field
     * 
     */

    public void modifyConfirmPassword( String newPassword ) {
        txbConfirmNewPassword.clear();
        txbConfirmNewPassword.sendKeys( newPassword );
        Log.message( "Confirm Password passed in to field successfully" );
    }

    /**
     * Click on Save Btn
     */
    public void saveChanges() {
        SMUtils.waitForElement( driver, saveBtnShadow );
        WebElement saveBtn = SMUtils.getWebElement( driver, saveBtnShadow, saveBtnCSS );
        SMUtils.clickJS( driver, saveBtn );
        Log.message( "Clicked Save Button" );
        SMUtils.nap( 0.5 );
    }

    /**
     * Click on Close Button for 'Student Added Successfully' Popup
     */
    public void clickCloseForPopup() {
        SMUtils.waitForElement( driver, closeBtnShadow );
        WebElement saveBtn = SMUtils.getWebElement( driver, closeBtnShadow, closeBtnCSS );
        SMUtils.clickJS( driver, saveBtn );
        Log.message( "Clicked Close Button" );
        SMUtils.nap( 0.5 );
    }

    /**
     * Click on Add Student Button
     */
    public void addStudent() {
        SMUtils.waitForElement( driver, btnCreateStudent );
        SMUtils.clickJS( driver, btnCreateStudent );
    }

    /**
     * Click on Cancel Btn
     */
    public void cancelChanges() {
        WebElement cancelBtn = SMUtils.getWebElement( driver, cancelBtnShadow, cancelBtnCSS );
        SMUtils.clickJS( driver, cancelBtn );
        Log.message( "Clicked Cancel Button" );
    }

    /**
     * To get all the Details in Student Listing page
     * 
     * @return
     */
    public ArrayList<String> getAllDetailsinStudentListingPage() {
        SMUtils.waitForElement( driver, btnAddStudentRoot, 10 );
        try {
            String query = "var names = []; var nodeList = document.querySelectorAll('tbody span.text-overflow-nowrap'); for ( let i=0 ; i<nodeList.length; i=i+1 ) { names.push(nodeList[i].getAttribute('title')); } {  return names; }";
            JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
            ArrayList<String> values = (ArrayList<String>) javascriptExecutor.executeScript( query );
            return values;

        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * To get the one Student Details in Student Listing Page
     * 
     * @param userName
     * @return
     */
    public HashMap<String, String> getStudentDetailsForUsername( String userName ) {
        ArrayList<String> allDetails = getAllDetailsinStudentListingPage();
        HashMap<String, HashMap<String, String>> studentDetails = new HashMap<String, HashMap<String, String>>();
        try {
            for ( int index = 0; index < allDetails.size(); index = index + 5 ) {
                HashMap<String, String> otherDetails = new HashMap<String, String>();
                otherDetails.put( Constants.Students.COLUMN_FIRST_NAME, allDetails.get( index ) );
                otherDetails.put( Constants.Students.COLUMN_LAST_NAME, allDetails.get( index + 1 ) );
                otherDetails.put( Constants.Students.COLUMN_STUDNET_ID, allDetails.get( index + 3 ) );
                otherDetails.put( Constants.Students.COLUMN_GRADE, allDetails.get( index + 4 ) );
                studentDetails.put( allDetails.get( index + 2 ), otherDetails );
            }
            return studentDetails.get( userName.toLowerCase() );

        } catch ( Exception e ) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * To get all the username in the student listing pages
     * 
     * @return
     */
    public ArrayList<String> getAllStudentsUserNames() {
        ArrayList<String> details = getAllDetailsinStudentListingPage();
        ArrayList<String> usernames = new ArrayList<>();
        for ( int index = 2; index < details.size(); index += 5 ) {
            usernames.add( details.get( index ) );
        }
        return usernames;

    }

    /**
     * To get all the FirsNames in the student listing pages
     * 
     * @return
     */
    public ArrayList<String> getAllStudentsFirsNames() {
        ArrayList<String> details = getAllDetailsinStudentListingPage();
        ArrayList<String> values = new ArrayList<>();
        for ( int index = 0; index < details.size(); index += 5 ) {
            values.add( details.get( index ) );
        }
        return values;

    }

    /**
     * To get all the LastName in the student listing pages
     * 
     * @return
     */
    public ArrayList<String> getAllStudentsLastNames() {
        ArrayList<String> details = getAllDetailsinStudentListingPage();
        ArrayList<String> values = new ArrayList<>();
        for ( int index = 1; index < details.size(); index += 5 ) {
            values.add( details.get( index ) );
        }
        return values;

    }

    /**
     * To get all the StudentIds in the student listing pages
     * 
     * @return
     */
    public ArrayList<String> getAllStudentsStudentIds() {
        ArrayList<String> details = getAllDetailsinStudentListingPage();
        ArrayList<String> values = new ArrayList<>();
        for ( int index = 3; index < details.size(); index += 5 ) {
            values.add( details.get( index ) );
        }
        return values;

    }

    /**
     * To get all the grade names in the student listing pages
     * 
     * @return
     */
    public ArrayList<String> getAllStudentsGrades() {
        ArrayList<String> details = getAllDetailsinStudentListingPage();
        ArrayList<String> values = new ArrayList<>();
        for ( int index = 4; index < details.size(); index += 5 ) {
            values.add( details.get( index ) );
        }
        return values;
    }

    /**
     * Get All the Group List in the Add Studetns to the groups Popup
     * 
     * @return list of Groups
     */
    public List<String> getAllGroupsinPoup() {
        if ( SMUtils.verifyElementDoesNotExist( By.cssSelector( ZERO_STATE_MESSAGE ), driver ) ) {
            return listOfGroupsForStudents.stream().map( element -> element.getAttribute( "title" ) ).collect( Collectors.toList() );
        } else {
            Log.message( "Zero State is Displayed for the Add Students to Groups Popup" );
            return null;
        }
    }

    /**
     * Get All the Assignments List in the Add Student to the Groups
     * 
     * @return list of assignments name
     */
    public List<String> getAllAssignmentsinPopup() {
        if ( SMUtils.verifyElementDoesNotExist( By.cssSelector( ZERO_STATE_MESSAGE ), driver ) ) {
            return listofAssignmentsForStudents.stream().map( element -> element.getAttribute( "title" ) ).collect( Collectors.toList() );
        } else {
            Log.message( "Zero State is Displayed for the Add Students to Assignments Popup" );
            return null;
        }
    }

    /**
     * To check if the Group is present on the Add Students to the Group Popup
     * 
     * @param groupName
     * @return true if present
     */
    public boolean isGroupPresentOnPopup( String groupName ) {
        return ( ( getAllGroupsinPoup() != null ) && getAllGroupsinPoup().contains( groupName ) ) ? true : false;
    }

    /**
     * To check if the Assignment is present on the Add Students to the
     * Assignment Popup
     * 
     * @param assignmentName
     * @return
     */
    public boolean isAssignmentPresentOnPopup( String assignmentName ) {
        return ( ( getAllAssignmentsinPopup() != null ) && getAllAssignmentsinPopup().contains( assignmentName ) ) ? true : false;
    }

    /**
     * To Close the Student Successfully Created Pop Up once student is created
     * 
     * @return
     */
    public Boolean closeStudentAddedToastPopUp() {
        Boolean status = false;
        SMUtils.waitForElement( driver, dialoguePopUpAfterStudentCreationRoot );
        if ( dialoguePopUpAfterStudentCreationRoot.isDisplayed() ) {
            SMUtils.clickJS( driver, SMUtils.getWebElement( driver, dialoguePopUpAfterStudentCreationRoot, saveBtnCSS ) );
            Log.message( "Student Successfully Created PopUp is closed successfully" );
            status = true;
        }
        return status;
    }

    /**
     * Clear the student Id field
     * 
     * @return
     */
    public boolean clearStudentIdField() {
        String id = getStudentId();
        Actions action = new Actions( driver );
        action.click( txtboxStudentID );
        action.doubleClick();
        action.build().perform();
        IntStream.range( 0, id.length() ).forEach( index -> {
            action.sendKeys( Keys.BACK_SPACE );
            action.build().perform();
        } );
        return getStudentId() == null ? true : false;
    }

    /**
     * To find whether Warning POP UP is get Displayed after creating a student
     * 
     * 
     * @return Status
     * @throws Exception
     */
    public Boolean isWarningPopupDisplayed() throws Exception {
        Boolean status = false;
        SMUtils.waitForElement( driver, warningMessageHeader );
        try {
            SMUtils.isElementPresent( warningMessageHeader );
            status = true;
            String warningMessageTitle = SMUtils.getTextOfWebElement( warningMessageHeader, driver );
            Log.message( warningMessageTitle );
            Log.assertThat( warningMessageTitle.equalsIgnoreCase( UserUIConstants.STUDENT_ADDED_TOAST_MESSAGE ), "Warning Message Header title is matched!", "Warning Message Header title is not matched!" );

        } catch ( Exception e ) {
            Log.message( "Warning Message Popup not Displayed" );
            status = false;
        }
        return status;
    }

    /**
     * To find whether content in Warning POP UP is get Displayed after creating
     * a student
     * 
     * 
     * @return status
     * @throws Exception
     */
    public boolean isWarningPopupContentDisplayed() throws Exception {
        Boolean status = false;
        SMUtils.waitForElement( driver, warningMessageContent );
        String actualWarningMsg = UserUIConstants.WARNING_MESSAGE_CONTENT;
        if ( SMUtils.verifyWebElementTextEqualsIgnoreCase( warningMessageContent, actualWarningMsg ) ) {
            Log.message( "Warning Message content is get displayed!!" );
            status = true;

        } else {
            Log.message( "Warning Message content is Not get displayed!!" );
        }
        return status;

    }

    /**
     * To click the X icon in Warning Pop-up after creating student
     * 
     * 
     * @return @throws
     */
    public void clickXiconWarningpPopup() {
        SMUtils.waitForElement( driver, warningpopupXBtn );
        SMUtils.click( driver, warningpopupXBtn );
        Log.message( "Clicked on X icon in Warning Popup" );
    }

    /**
     * To click the Close icon in Warning Pop-up after creating student
     * 
     * 
     * @return status
     * @throws Exception
     */
    public boolean clickCloseIconWarningPopup() throws Exception {
        Boolean status = false;
        SMUtils.waitForElement( driver, warningpopupCloseBtn );
        try {
            SMUtils.isElementPresent( warningpopupCloseBtn );
            Log.message( "Warning Message Popup Close button is Displayed!!" );
            SMUtils.clickJS( driver, warningpopupCloseBtn );
            Log.message( "Clicked on Close icon in Warning Popup" );
            status = true;

        } catch ( Exception e ) {
            Log.message( "Warning Message Popup Close button not Displayed" );
            Log.exception( e, driver );
        }
        return status;
    }
    
    public void createStudentPopupclose() {
               WebElement popUpclose = SMUtils.getWebElement(driver, createStudentPOPupCloseRoot, createStudentPOPupCloseChild);
               SMUtils.clickJS(driver, popUpclose);
	}
    
    /**
     * Get first student from the student list
     * 
     * @return
     */
    public String getFirstStudent() {
    	String firstUserName= listStudentUsernames.get(1).getText();
    	Log.message("The first user is "+firstUserName);
    	return firstUserName;
    }

}