package com.savvas.sm.teacher.ui.tests.HomeSuite;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.QualtricsSurveyPopup;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class QualtricsPopup extends BaseTest {

    private String smUrl;
    private String browser;
    private String username = null;
    private String password;
    private String newTeacherName;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    
    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = DataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "Verify whether script related to Qualtrics is loaded when the teacher is shown the popup requesting for the survey", priority = 1, groups = { "SMK-50702", "Qualtrics Survey Popup" } )
    public void qualtricsPopup_TC001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify whether script related to Qualtrics is loaded when the teacher is shown the popup requesting for the survey" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            TeacherHomePage teacher = new TeacherHomePage( driver );
            QualtricsSurveyPopup popup = new QualtricsSurveyPopup( driver );

            if ( smUrl.equals( Constants.NIGHTLY_SM_URL ) ) {
                LoginPage login = new LoginPage( driver, smUrl ).get();
                login.loginToSM( username, password, true );

                //Navigating to students Page
                teacher.topNavBar.navigateToStudentsTab();

                //Navigating to Home Page
                teacher.topNavBar.navigateToHomeTab();
            } else {
                LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, username, password );
            }

            //Verify if the qualtrics pop up displayed or not
            SMUtils.logDescriptionTC( "TC01 - Verify whether script related to Qualtrics is loaded when the teacher is shown the popup requesting for the survey" );
            Log.softAssertThat( popup.verifyQualtricsPopupAppeared(), "Qualtrics Survery Pop up appeared within a min", "Qualtrics Survery Pop up does not appeared within a min" );

            //Verify Savvas Logo is displayed
            SMUtils.logDescriptionTC( "TC03 - Verify the popup consists Savvas Logo" );
            Log.softAssertThat( popup.isSavvasLogoDisplayed(), "Savvas Logo is displayed", "Savvas Logo is not displayed" );

            //Verify Qualtrics Popup text matched
            SMUtils.logDescriptionTC( "TC04 - Verify the text present in the popup mathches to the UX" );
            Log.softAssertThat( popup.isQualtricasPopupTextIsAsExpected(), "Qualtrics Popup Text displayed is as per UX", "Qualtrics Popup Text is not displayed as per UX" );

            //Verify Qualtrics Popup Yes & No Text buttons
            SMUtils.logDescriptionTC( "TC05 - Verify the popup consist of two buttons which are named as 'YES!' and 'No thank you'" );
            Log.softAssertThat( popup.yesNoTextInPopup(), "Qualtrics Popup has 'YES!' and 'No thank you' button Text displayed is as per UX", "Qualtrics Popup 'YES!' and 'No thank you' button Text is not displayed as per UX" );

            //To Verify Survey Opened in new Window
            SMUtils.logDescriptionTC( "TC11 - Verify the teacher is lead to the survey in a new window when they click on the 'YES!' button of the popup" );
            String windowOld = popup.toOpenSurveyInNewWindow();
            Log.softAssertThat( !driver.getWindowHandle().equals( windowOld ), "Survey Opened in New window", "Survey is not opened" );

            //Verify if the Qualtrics pop up is disappeared after Yes has been clicked
            SMUtils.logDescriptionTC( "TC14 - Verify the popup fades away once the teacher starts attempting the survey." );
            String windowNew = driver.getWindowHandle();
            driver.switchTo().window( windowOld );
            Log.softAssertThat( popup.verifyQualtricsPopupDisappeared(), "Qualtrics Surver Pop up disappeared after clicking Yes button", "Qualtrics Surver Pop up does not disappear after clicking Yes button" );
            driver.switchTo().window( windowNew );

            //Answer the Survey and Check for Thank you Note
            SMUtils.logDescriptionTC( "TC13 - Verify the Teacher is able to successfully attempt the survey once the teacher is shown the survey upon clicking the 'YES!' button" );
            SMUtils.logDescriptionTC( "TC15 - Verify whether the teacher is shown the <Thank you message> once they completed attempting the survey." );
            popup.surveyQuestionAnswers();
            Log.softAssertThat( popup.isThankYouNoteDisplayed(), "Qualtrics Survery has been Completed and Thank you Note is displayed", "Qualtrics Survery has not been Completed and Thank you Note is not displayed" );

            //Verify if page navigated to Savvas.com after completion of survey
            Log.softAssertThat( popup.isSavvasHomePageDisplayed(), "Savvas Home page is Displayed", "Savvas Home page is not Displayed" );

            //Close the new window and navigate back to old window
            SMUtils.logDescriptionTC( "TC16 - Verify whether the Teacher is able to close the new window when they have completed attempting the survey." );
            SMUtils.closeCurrentWindowAndSwitchtoWindow( driver, windowOld );
            Log.softAssertThat( driver.getWindowHandle().equals( windowOld ), "Teacher has closed the Survey window", "Teacher has not closed the Survey window" );

            //Sign out
            teacher.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher is able to skip the survey in middle by clicking on close button and next time will continue with new survey.", priority = 1, groups = { "SMK-50702", "Qualtrics Survey Popup" } )
    public void qualtricsPopup_TC002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify the teacher is able to skip the survey in middle by clicking on close button and next time will continue with new survey." + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            TeacherHomePage teacher = new TeacherHomePage( driver );
            QualtricsSurveyPopup popup = new QualtricsSurveyPopup( driver );

            if ( smUrl.equals( Constants.NIGHTLY_SM_URL ) ) {
                LoginPage login = new LoginPage( driver, smUrl ).get();

                //Creating teacher 
                newTeacherName = "new_Teacher" + System.nanoTime();
                Integer newTeacherId = new UserSqlHelper().createTeacher( newTeacherName, newTeacherName, newTeacherName, Constants.PASSWORD_HASH, DataSetup.organizationId );
                login.loginToSM( newTeacherName, password, true );

                //Navigating to students Page
                teacher.topNavBar.navigateToStudentsTab();

                //Navigating to Home Page
                teacher.topNavBar.navigateToHomeTab();
            } else {
                // Creating school 1
                String schoolId1 = null;

                // Creating schoo1 Teacher
                String teacherdetails = new UserAPI().createTeacherAndResetPassword( schoolId1, "teacher1" );
                newTeacherName = SMUtils.getKeyValueFromResponse( teacherdetails, RBSDataSetupConstants.USERNAME );

                //Login as Teacher // login.loginToSM( newTeacherName, password, true );
                LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, newTeacherName, password );
            }

            //Verify if the qualtrics pop up displayed or not 
            Log.softAssertThat( popup.verifyQualtricsPopupAppeared(), "Qualtrics Survery Pop up appeared within a min", "Qualtrics Survery Pop up does not appeared within a min" );

            //To Verify Survey Opened in new Window 
            String windowOld = popup.toOpenSurveyInNewWindow();
            Log.softAssertThat( !driver.getWindowHandle().equals( windowOld ), "Survey Opened in New window", "Survey is not opened" );

            //To Verify Powered by Qualitrics button 
            SMUtils.logDescriptionTC( "TC20 - Verify 'Powered by Qualitrics' button is present at bottom right in survey window." );
            Log.softAssertThat( popup.isPoweredByQualtricsDisplayed(), "Powered by Qualitrics button is present", "Powered by Qualitrics button is not present" );

            //Answer the Survey and Check for Thank you Note
            SMUtils.logDescriptionTC( "TC19 - Verify the questions asked in previous survey are repeating in next survey." );
            popup.toSkipSurvey();

            //Close the new window and navigate back to old window
            SMUtils.logDescriptionTC( "TC18 - Verify the teacher is able to skip the survey in middle by clicking on close button and next time will continue with new survey." );
            SMUtils.closeCurrentWindowAndSwitchtoWindow( driver, windowOld );
            Log.softAssertThat( driver.getWindowHandle().equals( windowOld ), "Teacher has closed the Survey window", "Teacher has not closed the Survey window" );

            //Sign out 
            teacher.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            if ( smUrl.equals( Constants.NIGHTLY_SM_URL ) ) {
                BaseAPITest apiTest = new BaseAPITest();
                apiTest.invalidateSession( smUrl, apiTest.getJessionCookie( smUrl, newTeacherName, password ) );
            }
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the popup fades away under a minute if the Teacher doesn't take any action for the poup.", priority = 1, groups = { "SMK-50702", "Qualtrics Survey Popup" } )
    public void qualtricsPopup_TC003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify the popup fades away under a minute if the Teacher doesn't take any action for the poup." + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            TeacherHomePage teacher = new TeacherHomePage( driver );
            QualtricsSurveyPopup popup = new QualtricsSurveyPopup( driver );

            if ( smUrl.equals( Constants.NIGHTLY_SM_URL ) ) {
                LoginPage login = new LoginPage( driver, smUrl ).get();

                //Creating teacher 
                newTeacherName = "new_Teacher" + System.nanoTime();
                Integer newTeacherId = new UserSqlHelper().createTeacher( newTeacherName, newTeacherName, newTeacherName, Constants.PASSWORD_HASH, DataSetup.organizationId );
                login.loginToSM( newTeacherName, password, true );

                //Navigating to students Page
                teacher.topNavBar.navigateToStudentsTab();

                //Navigating to Home Page
                teacher.topNavBar.navigateToHomeTab();
            } else {
                // Creating school 1
                String schoolId1 = null;

                // Creating schoo1 Teacher
                String teacherdetails = new UserAPI().createTeacherAndResetPassword( schoolId1, "teacher1" );
                newTeacherName = SMUtils.getKeyValueFromResponse( teacherdetails, RBSDataSetupConstants.USERNAME );

                //Login as Teacher // login.loginToSM( newTeacherName, password, true );
                LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, newTeacherName, password );
            }

            //Verify if the qualtrics pop up displayed or not 
            Log.softAssertThat( popup.verifyQualtricsPopupAppeared(), "Qualtrics Survery Pop up appeared within a min", "Qualtrics Survery Pop up does not appeared within a min" );

            //Verify if the Qualtrics pop up is disappeared after a min or not
            SMUtils.logDescriptionTC( "TC17 - Verify the popup fades away under a minute if the Teacher doesn't take any action for the poup." );
            Log.softAssertThat( popup.verifyQualtricsPopupDisappearedAfterAMin(), "Qualtrics Surver Pop up disappeared within a min", "Qualtrics Surver Pop up does not disappear within a min" );

            //Sign out 
            teacher.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            if ( smUrl.equals( Constants.NIGHTLY_SM_URL ) ) {
                BaseAPITest apiTest = new BaseAPITest();
                apiTest.invalidateSession( smUrl, apiTest.getJessionCookie( smUrl, newTeacherName, password ) );
            }
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the popup goes away when the teacher clicks on the 'x' button at the top right corner", priority = 1, groups = { "SMK-50702", "Qualtrics Survey Popup" } )
    public void qualtricsPopup_TC004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify the popup goes away when the teacher clicks on the 'x' button at the top right corner" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            TeacherHomePage teacher = new TeacherHomePage( driver );
            QualtricsSurveyPopup popup = new QualtricsSurveyPopup( driver );

            if ( smUrl.equals( Constants.NIGHTLY_SM_URL ) ) {
                LoginPage login = new LoginPage( driver, smUrl ).get();

                //Creating teacher 
                newTeacherName = "new_Teacher" + System.nanoTime();
                Integer newTeacherId = new UserSqlHelper().createTeacher( newTeacherName, newTeacherName, newTeacherName, Constants.PASSWORD_HASH, DataSetup.organizationId );
                login.loginToSM( newTeacherName, password, true );

                //Navigating to students Page
                teacher.topNavBar.navigateToStudentsTab();

                //Navigating to Home Page
                teacher.topNavBar.navigateToHomeTab();
            } else {
                // Creating school 1
                String schoolId1 = null;

                // Creating schoo1 Teacher
                String teacherdetails = new UserAPI().createTeacherAndResetPassword( schoolId1, "teacher1" );
                newTeacherName = SMUtils.getKeyValueFromResponse( teacherdetails, RBSDataSetupConstants.USERNAME );

                //Login as Teacher // login.loginToSM( newTeacherName, password, true );
                LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, newTeacherName, password );
            }

            //Verify if the qualtrics pop up displayed or not 
            Log.softAssertThat( popup.verifyQualtricsPopupAppeared(), "Qualtrics Survery Pop up appeared within a min", "Qualtrics Survery Pop up does not appeared within a min" );

            //Verify if the Qualtrics pop up is disappeared after a min or not
            SMUtils.logDescriptionTC( "TC06 - Verify the popup goes away when the teacher clicks on the 'x' button at the top right corner" );
            Log.softAssertThat( popup.verifyPopupClosedOnClickingX(), "Qualtrics Surver Pop up Closed", "Qualtrics Surver Pop up is not Closed" );

            //Sign out 
            teacher.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            if ( smUrl.equals( Constants.NIGHTLY_SM_URL ) ) {
                BaseAPITest apiTest = new BaseAPITest();
                apiTest.invalidateSession( smUrl, apiTest.getJessionCookie( smUrl, newTeacherName, password ) );
            }
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the popup goes away when the teacher clicks on the 'No thank you' button", priority = 1, groups = { "SMK-50702", "Qualtrics Survey Popup" } )
    public void qualtricsPopup_TC005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify the popup goes away when the teacher clicks on the 'No thank you' button" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            TeacherHomePage teacher = new TeacherHomePage( driver );
            QualtricsSurveyPopup popup = new QualtricsSurveyPopup( driver );

            if ( smUrl.equals( Constants.NIGHTLY_SM_URL ) ) {
                LoginPage login = new LoginPage( driver, smUrl ).get();

                //Creating teacher 
                newTeacherName = "new_Teacher" + System.nanoTime();
                Integer newTeacherId = new UserSqlHelper().createTeacher( newTeacherName, newTeacherName, newTeacherName, Constants.PASSWORD_HASH, DataSetup.organizationId );
                login.loginToSM( newTeacherName, password, true );

                //Navigating to students Page
                teacher.topNavBar.navigateToStudentsTab();

                //Navigating to Home Page
                teacher.topNavBar.navigateToHomeTab();
            } else {
                // Creating school 1
                String schoolId1 = null;

                // Creating schoo1 Teacher
                String teacherdetails = new UserAPI().createTeacherAndResetPassword( schoolId1, "teacher1" );
                newTeacherName = SMUtils.getKeyValueFromResponse( teacherdetails, RBSDataSetupConstants.USERNAME );

                //Login as Teacher // login.loginToSM( newTeacherName, password, true );
                LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, LoginConstants.UserType.BASIC, null, newTeacherName, password );
            }

            //Verify if the qualtrics pop up displayed or not 
            Log.softAssertThat( popup.verifyQualtricsPopupAppeared(), "Qualtrics Survery Pop up appeared within a min", "Qualtrics Survery Pop up does not appeared within a min" );

            //Verify if the Qualtrics pop up is disappeared after a min or not
            SMUtils.logDescriptionTC( "TC07 - Verify the popup goes away when the teacher clicks on the 'No thank you' button" );
            Log.softAssertThat( popup.verifyPopupClosedOnClickingXBelowNoThankYou(), "Qualtrics Surver Pop up Closed", "Qualtrics Surver Pop up is not Closed" );

            //Sign out 
            teacher.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            if ( smUrl.equals( Constants.NIGHTLY_SM_URL ) ) {
                BaseAPITest apiTest = new BaseAPITest();
                apiTest.invalidateSession( smUrl, apiTest.getJessionCookie( smUrl, newTeacherName, password ) );
            }
            Log.endTestCase();
            driver.quit();
        }
    }

}
