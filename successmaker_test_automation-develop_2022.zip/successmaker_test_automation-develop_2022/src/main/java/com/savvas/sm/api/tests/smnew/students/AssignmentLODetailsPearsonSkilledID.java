package com.savvas.sm.api.tests.smnew.students;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

public class AssignmentLODetailsPearsonSkilledID extends EnvProperties {

    String smUrl;
    String browser;
    String teacherDetails;
    String orgId;
    String teacherUsername;
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String studentUsername;
    String studentPassword;
    String endPoint;
    String studentUserId;
    String studentUserName;
    String studentDetails;
    ArrayList<String> loDetails = new ArrayList<String>();

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        // Getting teacher details
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );

        // getting student details
        studentDetails = RBSDataSetup.getMyStudent( school, teacherUsername );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, "userId" );
        studentUserName = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );

    }

    @Test ( dataProvider = "PositiveFlowTestCases", groups = { "smoke_test_case", "LOSkill", "AssignmentLODetailsPearsonSkilledID", "API" } )
    private void AssignmentsLoDetails( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();

        endPoint = "";
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.STUDENT_ID, studentUserId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, "Bearer " + token );
        HashMap<String, String> response = getLODetails( smUrl, assignmentDetails, studentUserId, endPoint );
        switch ( scenario ) {

            case "TC01_Verify_pearsonSkillObjId":
                Log.message( response.toString() );
                Log.message( response.get( "body" ) );
                break;

            case "TC02_Verify_skillObjectiveName":
                Log.message( response.toString() );
                Log.message( response.get( "body" ) );
                break;
            case "TC03_Verify_skillObjectiveDescription":
                Log.message( response.toString() );
                Log.message( response.get( "body" ) );
                break;
            case "TC04_Verify_skillObjectiveId":
                Log.message( response.toString() );
                Log.message( response.get( "body" ) );
                break;

            default:

                Log.fail( "Case is invalid" );
                break;

        }

        Log.assertThat( response.get( "statusCode" ).equals( statusCode ), "Status code is matched", "Status code is mismatched" );
        String pearsonSkillId = "9";
        List<String> assignmentLODetails = getAssignmentLODetails( pearsonSkillId );
        Log.message( "LO: " + assignmentLODetails.toString() );

        String apiResponse = response.get( "body" ).toString();

        if ( scenario.contains( "TC04_Verify_skillObjectiveId" ) ) {

            Log.assertThat( apiResponse.contains( "\"skillObjectiveId\":" + assignmentLODetails.get( 0 ) + "" ), "skillObjectiveId are same as DB details", "skillObjectiveId are not same as DB details" );
        } else if ( scenario.contains( "TC02_Verify_skillObjectiveName" ) ) {

            Log.assertThat( apiResponse.contains( "\"skillObjectiveName\":\"" + assignmentLODetails.get( 1 ) + "\"" ), "skillObjectiveName are same as DB details", "skillObjectiveName are not same as DB details" );
        } else if ( scenario.contains( "TC01_Verify_pearsonSkillObjId" ) ) {

            Log.assertThat( apiResponse.contains( "\"pearsonSkillObjId\":\"" + assignmentLODetails.get( 2 ) + "\"" ), "pearsonSkillObjId are same as DB details", "pearsonSkillObjId are not same as DB details" );
        } else if ( scenario.contains( "TC03_Verify_skillObjectiveDescription" ) ) {

            Log.assertThat( apiResponse.contains( "\"skillObjDescription\":\"" + assignmentLODetails.get( 3 ) + "\"" ), "skillObjectiveDescription are same as DB details", "skillObjectiveDescription are not same as DB details" );
        }

        Log.testCaseResult();
        Log.endTestCase();

    }

    @DataProvider ( name = "PositiveFlowTestCases" )
    public Object[][] ProgressMonitoringGraphPositiveFlow() {

        Object[][] inputData = {

                { "TC01_Verify the status code is 200 when valid pearsonSkillId is given ", "TC01_Verify_pearsonSkillObjId", CommonAPIConstants.STATUS_CODE_OK },

                { "TC02_Verify the SkillObjectiveName when valid peasrsonSkillId is given", "TC02_Verify_skillObjectiveName", CommonAPIConstants.STATUS_CODE_OK },

                { "TC03_Verify the SkillObjectiveDescription  when valid peasrsonSkillId is given", "TC03_Verify_skillObjectiveDescription", CommonAPIConstants.STATUS_CODE_OK },

                { "TC04_Verify the SkilllObjectiveID when valid peasrsonSkillId is given", "TC04_Verify_skillObjectiveId", CommonAPIConstants.STATUS_CODE_OK },

        };
        return inputData;

    }

    private HashMap<String, String> getLODetails( String smUrl2, HashMap<String, String> header1, String studentUserId2, String endPoint2 ) throws Exception {

        String endPoint = "/lms/web/assignments/loDetails?idType=pearsonSkillId";

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        HashMap<String, String> header = new HashMap<>();
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        header.put( Constants.AUTHORIZATION, "Bearer " + token );
        header.put( Constants.USERID_SM_HEADER, studentUserId );
        header.put( Constants.ORGID_SM_HEADER, orgId );
        String payload = "[\"9\"]";
        Log.message( payload );
        return RestHttpClientUtil.POST( smUrl, header, new HashMap<>(), endPoint, payload );

    }

    public static List<String> getAssignmentLODetails( String pearsonSkillID ) {
        String queryString = "select * from skill_objectives where pearson_skill_obj_id = '" + pearsonSkillID + "'";
        List<Object[]> result = SQLUtil.executeQuery( queryString );
        List<String> details = new ArrayList<String>();
        for ( Object[] list : result ) {
            details.add( list[0].toString() );
            details.add( list[1].toString() );
            details.add( list[4].toString() );
            details.add( list[5].toString() );
        }
        return details;
    }
}
