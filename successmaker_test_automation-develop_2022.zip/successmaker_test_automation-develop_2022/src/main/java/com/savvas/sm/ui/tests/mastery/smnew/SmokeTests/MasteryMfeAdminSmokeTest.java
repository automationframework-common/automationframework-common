package com.savvas.sm.ui.tests.mastery.smnew.SmokeTests;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.teacher.ui.pages.MasteryReportOutputPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.MasteryDetailsPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.ui.pages.MasteryMfePage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class MasteryMfeAdminSmokeTest extends BaseTest {
    private String masteryAdminSingleMfeUrl;
    private String masteryAdminMultiMfeUrl;
    private String browser;
    private String password=RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String MASTERY_HEADER = "Mastery";
    List<String> MASTERYREPORT_ASSIGNMENTDETAILS_LABELS = new ArrayList<>( Arrays.asList( "Assigned course level:", "Current course level:", "IP level:", "Time spent:", "Total sessions:", "Average session time:" ) );
    @BeforeClass
    public void initTest( ITestContext context ) {
        masteryAdminSingleMfeUrl = configProperty.getProperty( "MasteryAdminSingleMfe" );
        masteryAdminMultiMfeUrl = configProperty.getProperty( "MasteryAdminMultiMfe" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
    }

    @Test (  description ="Verify Mastery Report for Math subject as a district admin",groups = { "smoke_te=st_case", "Districtadin Mastery", "Admin_155","P1" } )
    public void tcMasteryMfeDistrictadmin1( ITestContext context ) throws Exception {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        Log.testCaseInfo( "Verify Mastery Report for Math subject as a district admin" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            SMUtils.logDescriptionTC( "Verify the 'Mastery' title in the mastery filter component" );
            MasteryMfePage masteryMfePage = LoginWrapper.loginToMasteryMfe( driver, masteryAdminMultiMfeUrl, MasteryDataSetup.districtAdminUserName, password );

            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();
            masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);

            masteryFiltersComponent.applyFilter();
            
            MasterySummaryComponent masterySummaryComponent= new MasterySummaryComponent(driver);

            MasteryReportOutputPage masteryReport = masterySummaryComponent.clickMasteryRunReportBtn();
            
            SMUtils.logDescriptionTC("Tc:05 Verify the header of the  Mastery Run Report contains Mastery in bold letters in the top left of the page");
            Log.assertThat(masteryReport.getMasteryHeader().equals(MASTERY_HEADER),"The mastery header is displayed in bold letters","The mastery header is not displayed in bold letters");
            Log.testCaseResult();
           
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    @Test (  description ="Verify Mastery Report for Reading subject as a district admin",groups = { "smoke_te=st_case", "Districtadmin Mastery", "Admin_156","P1" } )
    public void tcMasteryMfeDistrictadmin2( ITestContext context ) throws Exception {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        Log.testCaseInfo( "Mastery Mfe Admin Test" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // TC_ 1
            SMUtils.logDescriptionTC( "Verify the 'Mastery' title in the mastery filter component" );
            MasteryMfePage masteryMfePage = LoginWrapper.loginToMasteryMfe( driver, masteryAdminMultiMfeUrl, MasteryDataSetup.districtAdminUserName, password );

            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();
            masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);

            masteryFiltersComponent.applyFilter();
            
            MasterySummaryComponent masterySummaryComponent= new MasterySummaryComponent(driver);

            MasteryReportOutputPage masteryReport = masterySummaryComponent.clickMasteryRunReportBtn();
            
            SMUtils.logDescriptionTC("Tc:05 Verify the header of the  Mastery Run Report contains Mastery in bold letters in the top left of the page");
            Log.assertThat(masteryReport.getMasteryHeader().equals(MASTERY_HEADER),"The mastery header is displayed in bold letters","The mastery header is not displayed in bold letters");
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC("Tc:06 Verify the Student Name , Grade Level and the Assignments name is present in the Mastery Run Report");
            Log.assertThat(!masteryReport.getStudentName().isEmpty(), "The student name is displayed", "The student name is not displayed");
            Log.assertThat(!masteryReport.getGradeName().isEmpty(), "The grade is displayed", "The grade is not displayed");
            Log.assertThat(!masteryReport.getAssignmentName().isEmpty(), "The grade is displayed", "The grade is not displayed");
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC("Tc:07 Verify the Date and time is getting displayed in the Mastery Run Report under Report Run ");
            SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
            String reportDate = dateFormat.format( new Date() );
            Log.assertThat(masteryReport.getReportRunTime().contains(reportDate), "The today date "+reportDate+" is displayed as expected", "The today date "+reportDate+" is not displayed as expected");
            Log.assertThat(masteryReport.getReportRunTime().contains("AM") || masteryReport.getReportRunTime().contains("PM"),"The time is "+masteryReport.getReportRunTime()+"displayed as expected","The time is "+masteryReport.getReportRunTime()+"not displayed as expected");
            Log.testCaseResult();
            
            SMUtils.logDescriptionTC("Tc:08 Verify the Assigned Course Level, Current Course Level, IP Level, Time Spent, Total Sessions(Minimum of 1 Assessments), Average Session Time, Skill/Standard, Mastery Status, # of Skills Completed/Judged, # of Attempts column fields are available in Mastery Run Report page");
            Log.assertThat(masteryReport.getAssignmentsDetailsKey().containsAll(MASTERYREPORT_ASSIGNMENTDETAILS_LABELS), "The Assignment Details Key are getting displayed as Expected", "The Assignment Details Key are getting displayed as Expected!");
            Log.testCaseResult();
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    @Test (  description ="Verify Mastery LO details page as a admin",groups = { "smoke_te=st_case", "Admin Mastery", "Admin_49","P1" } )
    public void tcMasteryMfeadmin1( ITestContext context ) throws Exception {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        Log.testCaseInfo( "Verify Mastery LO details page as a admin" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // TC_ 1
            SMUtils.logDescriptionTC( "Verify the 'Mastery' title in the mastery filter component" );
            MasteryMfePage masteryMfePage = LoginWrapper.loginToMasteryMfe( driver, masteryAdminSingleMfeUrl, MasteryDataSetup.schoolAdminUserName, password );

            Log.assertThat( masteryMfePage.getMasteryHeading().equals( MasteryConstants.Labels.MASTERY_HEADING ), "Mastery Heading is displayed", "Mastery Heading is not displayed" );

            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
    
             MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
             List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );
             MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masteredProgressBars.get( 0 ) );
             SMUtils.logDescriptionTC(  "Verify the student name(first name, last name), Mastery Status, Skills Evaluated, Attemps fields in the Mastery details page" );
             Log.assertThat( Constants.MasteryUI.masteryTableHeaders.equals( masteryDetailsPage.getStudentTableHeaders() ), "The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are available in the mastery header",
                "The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are not available in the mastery header" );
              Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
    @Test (  description ="Verify Mastery Run report as a admin",groups = { "smoke_te=st_case", "Admin Mastery", "Admin_50","P1" } )
    public void tcMasteryMfeadmin2( ITestContext context ) throws Exception {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        Log.testCaseInfo( "Verify Mastery Run report as a admin" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // TC_ 1
            SMUtils.logDescriptionTC( "Verify the 'Mastery' title in the mastery filter component" );
            MasteryMfePage masteryMfePage = LoginWrapper.loginToMasteryMfe( driver, masteryAdminSingleMfeUrl, MasteryDataSetup.schoolAdminUserName, password );

            Log.assertThat( masteryMfePage.getMasteryHeading().equals( MasteryConstants.Labels.MASTERY_HEADING ), "Mastery Heading is displayed", "Mastery Heading is not displayed" );

            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
    
             MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
             
             MasteryReportOutputPage masteryReport = masterySummaryComponent.clickMasteryRunReportBtn();
           
              SMUtils.logDescriptionTC("Verify the header of the  Mastery Run Report contains Mastery in bold letters in the top left of the page");
              Log.assertThat(masteryReport.getMasteryHeader().equals(MASTERY_HEADER),"The mastery header is displayed in bold letters","The mastery header is not displayed in bold letters");
              Log.testCaseResult();
              
              SMUtils.logDescriptionTC("Verify the Student Name , Grade Level and the Assignments name is present in the Mastery Run Report");
              Log.assertThat(!masteryReport.getStudentName().isEmpty(), "The student name is displayed", "The student name is not displayed");
              Log.assertThat(!masteryReport.getGradeName().isEmpty(), "The grade is displayed", "The grade is not displayed");
              Log.assertThat(!masteryReport.getAssignmentName().isEmpty(), "The grade is displayed", "The grade is not displayed");
              Log.testCaseResult();
              
              SMUtils.logDescriptionTC("Verify the Date and time is getting displayed in the Mastery Run Report under Report Run ");
              SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
              String reportDate = dateFormat.format( new Date() );
              Log.assertThat(masteryReport.getReportRunTime().contains(reportDate), "The today date "+reportDate+" is displayed as expected", "The today date "+reportDate+" is not displayed as expected");
              Log.assertThat(masteryReport.getReportRunTime().contains("AM") || masteryReport.getReportRunTime().contains("PM"),"The time is "+masteryReport.getReportRunTime()+"displayed as expected","The time is "+masteryReport.getReportRunTime()+"not displayed as expected");
              Log.testCaseResult();
              
              SMUtils.logDescriptionTC("Verify the Assigned Course Level, Current Course Level, IP Level, Time Spent, Total Sessions(Minimum of 1 Assessments), Average Session Time, Skill/Standard, Mastery Status, # of Skills Completed/Judged, # of Attempts column fields are available in Mastery Run Report page");
              Log.assertThat(masteryReport.getAssignmentsDetailsKey().containsAll(MASTERYREPORT_ASSIGNMENTDETAILS_LABELS), "The Assignment Details Key are getting displayed as Expected", "The Assignment Details Key are getting displayed as Expected!");
              Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}

