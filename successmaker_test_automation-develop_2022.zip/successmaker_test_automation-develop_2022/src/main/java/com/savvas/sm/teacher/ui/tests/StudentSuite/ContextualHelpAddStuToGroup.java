package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.HelpPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class ContextualHelpAddStuToGroup extends BaseTest {

    List<String> expectedCourseTypesInDropdown = Arrays.asList( "Focus Courses", "Default Courses", "Custom Courses", "All Courses" );

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    String studentDetails;

    private AtomicReference<String> schoolUsed = new AtomicReference<>();

    @BeforeClass
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        String teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentDetails = RBSDataSetup.getMyStudent( school, username );

    }

    @Test ( description = "Verify that clicking on 'i' icon on the Add students to the group popup, user is taken to the help documentation through student grid", groups = { "Students", "SMK-43269" }, priority = 1 )
    public void tcHelpAddStuToGroup001( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10029 : Verify that clicking on 'i' icon on the Add students to the group popup, user is taken to the help documentation through student grid <small><b><i>[" + browser + "]</b></i></small>" );
    	String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        Log.message( "studentID: " + studentID );
        String newGroupName = "Reg_Automation" + System.nanoTime();

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Groups tab
            GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupPage.createGroupWithoutStudent( newGroupName );
            // Navigate to Students tab
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickAddStudentToGroupByEllipsis( studentID );
            Log.assertThat( studentsPage.verifyHelpIcon(), "Help icon is present in Add students to Group popup", "Help icon is not present in Add students to Group popup" );
            studentsPage.clickHelpIcon();
            SMUtils.switchWindow( driver );
            HelpPage helpPage = new HelpPage( driver ).get();
            String currentURL = driver.getCurrentUrl();

            Log.assertThat( driver.getCurrentUrl().equals( Constants.Students.HELP_URL_FOR_ADD_STU_GRP_POPUP ), "Help Page loaded successfully -" + currentURL, "Issue with help Page. - " + driver.getCurrentUrl() );

            Log.assertThat( driver.getTitle().equals( Constants.Students.ADD_STU_GRP_TEXT ), "Help Page loaded successfully with title as " + driver.getTitle(), "Issue with help Page. - " + driver.getCurrentUrl() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that clicking on 'i' icon on the Add students to the group popup, user is taken to the help documentation on selecting all the students and grouping them", groups = { "Students", "SMK-43269" }, priority = 1 )
    public void tcHelpAddStuToGroup002( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10030 : Verify that clicking on 'i' icon on the Add students to the group popup, user is taken to the help documentation on selecting all the students and grouping them <small><b><i>[" + browser + "]</b></i></small>" );

        String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        Log.message( "studentID: " + studentID );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Students tab
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.selectAllStudents();
            studentsPage.clickAddStudentToGroupByEllipsis( studentID );
            Log.assertThat( studentsPage.verifyHelpIcon(), "Help icon is displayed in Add students to Group popup", "Help icon is not displayed in Add students to Group popup" );
            studentsPage.clickHelpIcon();
            SMUtils.switchWindow( driver );
            HelpPage helpPage = new HelpPage( driver ).get();
            String currentURL = driver.getCurrentUrl();

            Log.assertThat( driver.getCurrentUrl().equals( Constants.Students.HELP_URL_FOR_ADD_STU_GRP_POPUP ), "Help Page loaded successfully -" + currentURL, "Issue with help Page. - " + driver.getCurrentUrl() );

            Log.assertThat( driver.getTitle().equals( Constants.Students.ADD_STU_GRP_TEXT ), "Help Page loaded successfully with title as " + driver.getTitle(), "Issue with help Page. - " + driver.getCurrentUrl() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that clicking on 'i' icon on the Add students to the group popup, user is taken to the help documentation on zero state page Add students to group(s) link", groups = { "Students", "SMK-43269" }, priority = 1 )
    public void tcHelpAddStuToGroup003( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10031 : Verify that clicking on 'i' icon on the Add students to the group popup, user is taken to the help documentation on zero state page Add students to group(s) link <small><b><i>[" + browser + "]</b></i></small>" );
    	String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
    	Log.message( "studentID: " + studentID );

    	try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Groups tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.deleteAllGroup( groupsTab );

            groupsTab.createGroup( "SMReg" + System.nanoTime(), Arrays.asList( studentID ) );
            // Navigate to Students tab
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.selectStudentByUsername( studentID );
            studentsPage.clickGroupButtoninStudentLisitngPage();
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            Log.assertThat( studentsPage.verifyHelpIcon(), "Help icon is displayed in Add students to Group popup", "Help icon is not displayed in Add students to Group popup" );
            Log.assertThat( studentsPage.verifyZeroStateMsgInAddStuToGroup(), "Zero state message is verified successfully", "Zero state message is not displayed" );
            studentsPage.clickHelpIcon();
            SMUtils.switchWindow( driver );
            HelpPage helpPage = new HelpPage( driver ).get();
            String currentURL = driver.getCurrentUrl();
            Log.assertThat( driver.getCurrentUrl().equals( Constants.Students.HELP_URL_FOR_ADD_STU_GRP_POPUP ), "Help Page loaded successfully -" + currentURL, "Issue with help Page. - " + driver.getCurrentUrl() );
            Log.assertThat( driver.getTitle().equals( Constants.Students.ADD_STU_GRP_TEXT ), "Help Page loaded successfully with title as " + driver.getTitle(), "Issue with help Page. - " + driver.getCurrentUrl() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that clicking on 'i' icon on the Add students to the group popup, user is taken to the help documentation on zero state page Add students to group(s) button", groups = { "Students", "Help", "SMK-43269" }, priority = 1 )
    public void tcHelpAddStuToGroup004( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10032 : Verify that clicking on 'i' icon on the Add students to the group popup, user is taken to the help documentation on zero state page Add students to group(s) button <small><b><i>[" + browser + "]</b></i></small>" );
    	String studentID = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        Log.message( "studentID: " + studentID );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Groups tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.deleteAllGroup( groupsTab );
            // Navigate to Students tab
            groupsTab.createGroup( "SMReg" + System.nanoTime(), Arrays.asList( studentID ) );
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.selectStudentByUsername( studentID );
            studentsPage.clickGroupButtoninStudentLisitngPage();
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            studentsPage.clickAddStuToGrpButton();
            Log.assertThat( studentsPage.verifyHelpIcon(), "Help icon is displayed in Add students to Group popup", "Help icon is not displayed in Add students to Group popup" );
            Log.assertThat( studentsPage.verifyZeroStateMsgInAddStuToGroup(), "Zero state message is verified successfully", "Zero state message is not displayed" );
            studentsPage.clickHelpIcon();
            SMUtils.switchWindow( driver );
            HelpPage helpPage = new HelpPage( driver ).get();
            String currentURL = driver.getCurrentUrl();

            Log.assertThat( driver.getCurrentUrl().equals( Constants.Students.HELP_URL_FOR_ADD_STU_GRP_POPUP ), "Help Page loaded successfully -" + currentURL, "Issue with help Page. - " + driver.getCurrentUrl() );

            Log.assertThat( driver.getTitle().equals( Constants.Students.ADD_STU_GRP_TEXT ), "Help Page loaded successfully with title as " + driver.getTitle(), "Issue with help Page. - " + driver.getCurrentUrl() );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

}
