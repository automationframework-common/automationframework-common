package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
// import com.savvas.sm.teacher.ui.tests.DataSetup.DataSetup;

public class EditAssignmentLevelSettings extends BaseTest {
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = null;
    private String schoolID;
    private String teacherID;
    String studentDetails;
    String studentDetailsSecond;
    String studentDetailsThree;
    String studentSMDetails;
    String studentSMDetailsSecond;
    String studentSMDetailsThree;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    TeacherHomePage tHomePage;
    LoginPage smLoginPage;
    CoursesPage courses;
    private String orgId;
    List<String> studentListFromTheAssignmentPopup;
    StudentsPage studentsPage;
    AssignmentDetailsPage assignmentDetailsPage;
    private HashMap<String, String> groupDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private static HashMap<String, String> mathAssignmentDetails = new HashMap<>();
    AssignmentAPI assign = new AssignmentAPI();
    private String token = null;

    @BeforeClass (alwaysRun = true)
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentDetails = RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" );
        studentDetailsSecond = RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" );
        studentDetailsThree = RBSDataSetup.orgStudentDetails.get( school ).get( "Student3" );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsThree, "userId" ) );

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );
        
        // Assigning Math assignment
        mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherID );
        mathAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        HashMap<String, String> mathRssignmentResponse = assign.assignMultipleAssignments( smUrl, mathAssignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );
        Log.message( mathRssignmentResponse.toString() );
        
     //    executeSimulator( stuUserName, Constants.MATH, Constants.MATH );


    }

    @Test ( description = "Edit Assignment Level Settings - Math Assignment - Settings during creation should be displayed When Edited", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
    	
        Log.testCaseInfo( "tc_SMEditAssignments001:Edit Assignment Level Settings - Math Assignment - Settings during creation should be displayed When Edited <small><b><i>[" + browser + "]</b></i></small>" );

        try {
        	 LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
             TeacherHomePage tHomePage = new TeacherHomePage( driver );

             boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
             Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

             courses = new CoursesPage( driver );

             assignmentDetailsPage = new AssignmentDetailsPage( driver );
             studentListFromTheAssignmentPopup = new ArrayList<>();

             // Get Student Page
             StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

             //Get CourseLising Page
             CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

             //Select Custom Courses from the first drop down
             courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

             //Click on the course
             courses.clickFromCourseListingPage( Constants.MATH );
             courses.clickAssignBtn();
             SMUtils.nap(6);

             //Get the count of the student from the assignment pop up
             studentListFromTheAssignmentPopup = courses.getAllStudentNameFromAssignPopUp();

             //Assign the course to the student
             courses.addCourseToMultipleStudents();

             assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

             assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

             String idealTimeValue = assignmentDetailsPage.getIdealTime();
             String idealTimeValueBottomEllipsis = Constants.IDEAL_TIME_SELECTED;
             courses.clickAssignButton();

             tHomePage.topNavBar.getCourseListingPage();

             //Traverse to the assignment
             courses.clickAssignmentSubMenu();

             //Click on the View Assignment
             courses.clickOnTheHoveredAssignment( Constants.MATH );

             assignmentDetailsPage.assignmentLevelEllipsis();
             assignmentDetailsPage.allAssignmenttSettingTab();

             Log.assertThat( assignmentDetailsPage.getSessionLength().equalsIgnoreCase( Constants.SESSION_LENGHT_SELECTED ), "Session Length showed correct", "Session Length showed Incorrect" );
             Log.assertThat( idealTimeValue.equalsIgnoreCase( idealTimeValueBottomEllipsis ), "Idle Time Is Updated", "Idle Time Is Not Updated" );

             tHomePage.topNavBar.signOutfromSM();
             //Log message for test case
             Log.testCaseResult();


        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading Assignment - Settings during creation should be displayed When Edited", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments002() throws Exception {
		// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments002:Edit Assignment Level Settings - Reading Assignment - Settings during creation should be displayed When Edited <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            studentListFromTheAssignmentPopup = new ArrayList<>();

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course from courseListing page
            courses.clickFromCourseListingPage( Constants.READING );

            courses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = courses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            courses.addCourseToMultipleStudents();

            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            String idealTimeValue = assignmentDetailsPage.getIdealTime();
            String idealTimeValueBottomEllipsis = Constants.IDEAL_TIME_SELECTED;
            courses.clickAssignButton();

            tHomePage.topNavBar.getCourseListingPage();

            //Traverse to the assignment
            courses.clickAssignmentSubMenu();

            //Click on the View Assignment
            courses.clickOnTheHoveredAssignment( Constants.READING );

            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.softAssertThat( assignmentDetailsPage.getSessionLength().equalsIgnoreCase( Constants.SESSION_LENGHT_SELECTED ), "Session Length showed correct", "Session Length showed Incorrect" );
            Log.softAssertThat( idealTimeValue.equalsIgnoreCase( idealTimeValueBottomEllipsis ), "Idle Time Is Updated", "Idle Time Is Not Updated" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Focus Math Assignment - Settings during creation should be displayed When Edited", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments003:Edit Assignment Level Settings - Focus Math Assignment - Settings during creation should be displayed When Edited <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            studentListFromTheAssignmentPopup = new ArrayList<>();

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSE );

            //Click on the course
            courses.clickFromCourseListingPage( Constants.HomePage.FOCUS_MATH_COURSE );
            courses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = courses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            courses.addCourseToMultipleStudents();

            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            String idealTimeValue = assignmentDetailsPage.getIdealTime();
            String idealTimeValueBottomEllipsis = Constants.IDEAL_TIME_SELECTED;
            courses.clickAssignButton();

            tHomePage.topNavBar.getCourseListingPage();

            //Traverse to the assignment
            courses.clickAssignmentSubMenu();

            //Click on the View Assignment
            courses.clickOnTheHoveredAssignment( Constants.HomePage.FOCUS_MATH_COURSE );

            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( assignmentDetailsPage.getSessionLength().equalsIgnoreCase( Constants.SESSION_LENGHT_SELECTED ), "Session Length showed correct", "Session Length showed Incorrect" );
            Log.assertThat( idealTimeValue.equalsIgnoreCase( idealTimeValueBottomEllipsis ), "Idle Time Is Updated", "Idle Time Is Not Updated" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Focus Reading Assignment - Settings during creation should be displayed When Edited", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
    	

        Log.testCaseInfo( "tc_SMEditAssignments004:Edit Assignment Level Settings - Focus Reading Assignment - Settings during creation should be displayed When Edited <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            studentListFromTheAssignmentPopup = new ArrayList<String>();

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSE );

            //Click on the course
            courses.clickFromCourseListingPage( Constants.HomePage.FOCUS_READING_COURSE );

            courses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = courses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            courses.addCourseToMultipleStudents();

            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            String idealTimeValue = assignmentDetailsPage.getIdealTime();
            String idealTimeValueBottomEllipsis = Constants.IDEAL_TIME_SELECTED;
            courses.clickAssignButton();

            tHomePage.topNavBar.getCourseListingPage();

            //Traverse to the assignment
            courses.clickAssignmentSubMenu();

            //Click on the View Assignment
            courses.clickOnTheHoveredAssignment( Constants.HomePage.FOCUS_READING_COURSE );

            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( assignmentDetailsPage.getSessionLength().equalsIgnoreCase( Constants.SESSION_LENGHT_SELECTED ), "Session Length showed correct", "Session Length showed Incorrect" );
            Log.assertThat( idealTimeValue.equalsIgnoreCase( idealTimeValueBottomEllipsis ), "Idle Time Is Updated", "Idle Time Is Not Updated" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate sesssion length boundary values during edit settings should be from 1 to 180", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments005:Edit Assignment Level Settings - Math - Validate sesssion length boundary values during edit settings should be from 1 to 180<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();
            List<String> sessionList = assignmentDetailsPage.getListOfSessionLength( Constants.EditAssignments.SESSION_LENGTH_HEADER );

            Log.assertThat( sessionList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.SESSION_LENGTH_FIRST_ELEMENT ), "First value of session Length is displaying", "First value of session Length is not displaying" );
            Log.assertThat( sessionList.get( sessionList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.SESSION_LENGTH_LAST_ELEMENT ), "Last value of session Length is displaying", "Last value of session Length is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate Show Limit values during edit settings should be from 1 to 10", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments006:Edit Assignment Level Settings - Math - Validate Show Limit values during edit settings should be from 1 to 10<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password  );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();
            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            List<String> limitProgressList = assignmentDetailsPage.getListOfLimitProgress();

            Log.assertThat( limitProgressList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.PROGRESS_LIMIT_FIRST ), "First Value of progress limit is displaying", "First Value of progress limit is not displaying" );
            Log.assertThat( limitProgressList.get( limitProgressList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.PROGRESS_LIMIT_LAST ), "Last Value of progress limit is displaying", "Last Value of progress limit is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate Display Lo Information Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments007:Edit Assignment Level Settings - Math - Validate Display Lo Information Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( courses.getTheStatusOfTheDisplayLoInformation( Constants.ON_CAPS ).equalsIgnoreCase( Constants.ON_CAPS ), "LO information is showing as ON", "LO Information is not showing as ON " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate Display Lo Information Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments008() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments008:Edit Assignment Level Settings - Math - Validate Display Lo Information Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            SMUtils.logDescriptionTC( "SMK-39223 - Edit Assignment Level Settings - Math - Validate Speed Games Total Time Only When Speed Games is on" );

            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( assignmentDetailsPage.isElementDisplaOnEditPage( Constants.EditAssignments.SPEED_GAMES_QUESTION ).equalsIgnoreCase( Constants.EditAssignments.SPEED_GAMES_QUESTION ), "Speeed Game Question is displaying",
                    "Speed Game question is not displaying" );

            Log.assertThat( assignmentDetailsPage.isElementDisplaOnEditPage( Constants.EditAssignments.SPEED_GAMES_TOTAL_TIMES ).equalsIgnoreCase( Constants.EditAssignments.SPEED_GAMES_TOTAL_TIMES ), "Speeed Game times is displaying",
                    "Speed Game times is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate Speed Games Time per Question Boundary Values 1 to 6 Seconds", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments009:Edit Assignment Level Settings - Math - Validate Speed Games Time per Question Boundary Values 1 to 6 Seconds<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            SMUtils.logDescriptionTC( "SMK-39223 - Edit Assignment Level Settings - Math - Validate Share at District Level Toggle - ON/OFF" );
            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            List<String> speedGameList = assignmentDetailsPage.getListOfSpeedgame();

            Log.assertThat( speedGameList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.SPEED_GAME_FIRST_ELEMENT ), "First Value of Speed game is displaying", "First Value of Speed game is not displaying" );
            Log.assertThat( speedGameList.get( speedGameList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.SPEED_GAME_LAST_ELEMENT ), "Last Value of Speeed Game is displaying", "Last Value of Speeed Game is not displaying" );

            courses.changeStatusOfTheSharedAtDistrictLevel( Constants.OFF_CAPS );
            Log.assertThat( courses.getTheStatusOfTheSharedAtDistrictLevel( Constants.OFF_CAPS ).equals( Constants.OFF_CAPS ), "Share at District level is OFF now ", "Share at District level is not OFF" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate Speed Games Total Time Boundary Values 1 to 3 Minutes", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments010() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments010:Edit Assignment Level Settings - Math - Validate Speed Games Total Time Boundary Values 1 to 3 Minutes<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            List<String> speedGameTotalTimeList = assignmentDetailsPage.getListOfSpeedgameTotaltime();

            Log.assertThat( speedGameTotalTimeList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.SPEED_GAME_TOTAL_TIME_GAME_FIRST_ELEMENT ), "First Value of Speed game total time is displaying",
                    "First Value of Speed game total time is not displaying" );
            Log.assertThat( speedGameTotalTimeList.get( speedGameTotalTimeList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.SPEED_GAME_TOTAL_TIME_LAST_ELEMENT ), "Last Value of Speeed Game total time is displaying",
                    "Last Value of Speeed Game total time is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math Focus Assignment - Settings during creation should be displayed When Edited", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments011:Edit Student Level Assignment Settings - Math Focus Assignment - Settings during creation should be displayed When Edited<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            SMUtils.nap(5);
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            studentListFromTheAssignmentPopup = new ArrayList<>();

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSE );

            //Click on the course
            courses.clickFromCourseListingPage( Constants.HomePage.FOCUS_MATH_COURSE );

            courses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = courses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            courses.addCourseToMultipleStudents();

            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            String idealTimeValue = assignmentDetailsPage.getIdealTime();
            String idealTimeValueBottomEllipsis = Constants.IDEAL_TIME_SELECTED;
            courses.clickAssignButton();

            SMUtils.nap(3);
            //Traverse to the assignment
            courses.clickAssignmentSubMenu();

            //Click on the View Assignment
            courses.clickOnTheHoveredAssignment( Constants.HomePage.FOCUS_MATH_COURSE );

            assignmentDetailsPage.clickDotEllipsisButton();
            assignmentDetailsPage.clickAssignmentSetting();

            Log.assertThat( assignmentDetailsPage.getSessionLength().equalsIgnoreCase( Constants.SESSION_LENGHT_SELECTED ), "Session Length showed correct", "Session Length showed Incorrect" );
            Log.assertThat( idealTimeValue.equalsIgnoreCase( idealTimeValueBottomEllipsis ), "Idle Time Is Updated", "Idle Time Is Not Updated" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate Manually Set Couse Level - Should be Off and Disabled", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments012() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments012:Edit Assignment Level Settings - Math - Validate Manually Set Couse Level - Should be Off and Disabled<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            SMUtils.logDescriptionTC( "SMK-39223 -Edit Assignment Level Settings - Math - Validate Initial Placement - Should be On and Disabled " );
            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( assignmentDetailsPage.getValueOfIPSetCourseLevel( Constants.EditAssignments.SET_COURSE_LEVEL ).equalsIgnoreCase( Constants.EditAssignments.OFF ), "Set Course Level is off", "Set Course level is not Off" );
            Log.assertThat( assignmentDetailsPage.getValueOfIPSetCourseLevel( Constants.EditAssignments.INITIAL_PLACEMENT ).equalsIgnoreCase( Constants.EditAssignments.ON ), "Initial Placemet is showing as On", "Initical placement is not showing as On" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading - Validate sesssion length boundary values during edit settings should be from 1 to 180", groups = { "SMK-39223", "Assignment Page",
            "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments013() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments013:Edit Assignment Level Settings - Reading - Validate sesssion length boundary values during edit settings should be from 1 to 180<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.READING );
            SMUtils.nap(2);
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            List<String> sessionList = assignmentDetailsPage.getListOfSessionLength( Constants.EditAssignments.SESSION_LENGTH_HEADER );

            Log.assertThat( sessionList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.SESSION_LENGTH_FIRST_ELEMENT ), "First value of session Length is displaying", "First value of session Length is not displaying" );
            Log.assertThat( sessionList.get( sessionList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.SESSION_LENGTH_LAST_ELEMENT ), "Last value of session Length is displaying", "Last value of session Length is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading - Validate Show Limit values during edit settings should be from 1 to 10", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments014() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments014:Edit Assignment Level Settings - Reading - Validate Show Limit values during edit settings should be from 1 to 10<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.READING );
            SMUtils.nap(3);
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            List<String> limitProgressList = assignmentDetailsPage.getListOfLimitProgress();

            Log.assertThat( limitProgressList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.PROGRESS_LIMIT_FIRST ), "First Value of progress limit is displaying", "First Value of progress limit is not displaying" );
            Log.assertThat( limitProgressList.get( limitProgressList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.PROGRESS_LIMIT_LAST ), "Last Value of progress limit is displaying", "Last Value of progress limit is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading - Validate Idle Time boundary values during edit settings should be from 2 to 6", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments015() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo( "tc_SMEditAssignments015:Edit Assignment Level Settings - Reading - Validate Idle Time boundary values during edit settings should be from 2 to 6<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.READING );
           SMUtils.nap(2);
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();
            List<String> sessionList = assignmentDetailsPage.getListOfSessionLength( Constants.EditAssignments.IDEAL_TIME_HEADER );

            Log.assertThat( sessionList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.IDEAL_TIME_FIRST_ELEMENT ), "First value of Ideal time is displaying", "First value of Ideal time is not displaying" );
            Log.assertThat( sessionList.get( sessionList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.IDEAL_TIME_LAST_ELEMENT ), "Last value of Ideal time is displaying", "Last value of Ideal time is not displaying" );
            tHomePage.topNavBar.signOutfromSM();

            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading - Validate Show Limit values during edit settings should be from 1 to 10", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments016() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments016:Edit Assignment Level Settings - Reading - Validate Show Limit values during edit settings should be from 1 to 10<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.READING );
            SMUtils.nap(2);
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            List<String> limitProgressList = assignmentDetailsPage.getListOfLimitProgress();

            Log.assertThat( limitProgressList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.PROGRESS_LIMIT_FIRST ), "First Value of progress limit is displaying", "First Value of progress limit is not displaying" );
            Log.assertThat( limitProgressList.get( limitProgressList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.PROGRESS_LIMIT_LAST ), "Last Value of progress limit is displaying", "Last Value of progress limit is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading - Validate Initial Placement - Should be On and Disabled", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments017() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments017:Edit Assignment Level Settings - Reading - Validate Initial Placement - Should be On and Disabled<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.READING );
            SMUtils.nap(3);
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( assignmentDetailsPage.getValueOfIPSetCourseLevel( Constants.EditAssignments.INITIAL_PLACEMENT ).equalsIgnoreCase( Constants.EditAssignments.ON ), "Initial Placemet is showing as On", "Initical placement is not showing as On" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math Assignment - Settings during creation should be displayed When Edited", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments018() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments018:Edit Student Level Assignment Settings - Math Assignment - Settings during creation should be displayed When Edited <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            studentListFromTheAssignmentPopup = new ArrayList<>();

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            SMUtils.nap(3);
            courses.clickFromCourseListingPage( Constants.HomePage.MATH_COURSE );

            courses.clickAssignBtn();
            
            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = courses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            courses.addCourseToMultipleStudents();

            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            String idealTimeValue = assignmentDetailsPage.getIdealTime();
            String idealTimeValueBottomEllipsis = Constants.IDEAL_TIME_SELECTED;
            courses.clickAssignButton();

            //Traverse to the assignment
            courses.clickAssignmentSubMenu();

            //Click on the View Assignment
            courses.clickOnTheHoveredAssignment( Constants.HomePage.MATH_COURSE );

            assignmentDetailsPage.clickDotEllipsisButton();
            assignmentDetailsPage.clickAssignmentSetting();

            Log.assertThat( assignmentDetailsPage.getSessionLength().equalsIgnoreCase( Constants.SESSION_LENGHT_SELECTED ), "Session Length showed correct", "Session Length showed Incorrect" );
            Log.assertThat( idealTimeValue.equalsIgnoreCase( idealTimeValueBottomEllipsis ), "Idle Time Is Updated", "Idle Time Is Not Updated" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Reading Assignment - Settings during creation should be displayed When Edited", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments019() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments019:Edit Student Level Assignment Settings - Reading Assignment - Settings during creation should be displayed When Edited<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            studentListFromTheAssignmentPopup = new ArrayList<>();

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickFromCourseListingPage( Constants.HomePage.READING_COURSE );

            courses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = courses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            courses.addCourseToMultipleStudents();

            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            String idealTimeValue = assignmentDetailsPage.getIdealTime();
            String idealTimeValueBottomEllipsis = Constants.IDEAL_TIME_SELECTED;
            courses.clickAssignButton();

            //Traverse to the assignment
            courses.clickAssignmentSubMenu();

            //Click on the View Assignment
            courses.clickOnTheHoveredAssignment( Constants.HomePage.READING_COURSE );

            assignmentDetailsPage.clickDotEllipsisButton();
            assignmentDetailsPage.clickAssignmentSetting();

            Log.assertThat( assignmentDetailsPage.getSessionLength().equalsIgnoreCase( Constants.SESSION_LENGHT_SELECTED ), "Session Length showed correct", "Session Length showed Incorrect" );
            Log.assertThat( idealTimeValue.equalsIgnoreCase( idealTimeValueBottomEllipsis ), "Idle Time Is Updated", "Idle Time Is Not Updated" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Reading Focus Assignment - Settings during creation should be displayed When Edited", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments020() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments020:Edit Student Level Assignment Settings - Reading Focus Assignment - Settings during creation should be displayed When Edited<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            studentListFromTheAssignmentPopup = new ArrayList<>();

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSE );

            //Click on the course
            courses.clickFromCourseListingPage( Constants.HomePage.FOCUS_READING_COURSE );

            courses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = courses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            courses.addCourseToMultipleStudents();

            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            String idealTimeValue = assignmentDetailsPage.getIdealTime();
            String idealTimeValueBottomEllipsis = Constants.IDEAL_TIME_SELECTED;
            courses.clickAssignButton();

            //Traverse to the assignment
            courses.clickAssignmentSubMenu();

            //Click on the View Assignment
            courses.clickOnTheHoveredAssignment( Constants.HomePage.FOCUS_READING_COURSE );

            assignmentDetailsPage.clickDotEllipsisButton();
            assignmentDetailsPage.clickAssignmentSetting();

            Log.assertThat( assignmentDetailsPage.getSessionLength().equalsIgnoreCase( Constants.SESSION_LENGHT_SELECTED ), "Session Length showed correct", "Session Length showed Incorrect" );
            Log.assertThat( idealTimeValue.equalsIgnoreCase( idealTimeValueBottomEllipsis ), "Idle Time Is Updated", "Idle Time Is Not Updated" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Copy Course Standards - Settings during creation should be displayed When Edited", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments021() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments021:Edit Assignment Level Settings - Copy Course Standards - Settings during creation should be displayed When Edited <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            String staticCourseName;

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            studentListFromTheAssignmentPopup = new ArrayList<>();
            staticCourseName = courses.generateRandomCourseName();

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            courses.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.READING );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course
            courses.clickFromCourseListingPage( staticCourseName );
            courses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = courses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            courses.addCourseToMultipleStudents();

            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            String idealTimeValue = assignmentDetailsPage.getIdealTime();
            String idealTimeValueBottomEllipsis = Constants.IDEAL_TIME_SELECTED;
            courses.clickAssignButton();

            //Traverse to the assignment
            courses.clickAssignmentSubMenu();

            //Click on the View Assignment
            courses.clickOnTheHoveredAssignment( staticCourseName );

            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( assignmentDetailsPage.getSessionLength().equalsIgnoreCase( Constants.SESSION_LENGHT_SELECTED ), "Session Length showed correct", "Session Length showed Incorrect" );
            Log.assertThat( idealTimeValue.equalsIgnoreCase( idealTimeValueBottomEllipsis ), "Idle Time Is Updated", "Idle Time Is Not Updated" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Copy Course Skill - Settings during creation should be displayed When Edited", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments022() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments022:Edit Assignment Level Settings - Copy Course Skill - Settings during creation should be displayed When Edited<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            String staticCourseName;

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            studentListFromTheAssignmentPopup = new ArrayList<>();
            staticCourseName = courses.generateRandomCourseName();

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            courses.copyOfCourse( staticCourseName, Constants.SKILLS, Constants.READING );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course
            courses.clickFromCourseListingPage( staticCourseName );
            courses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = courses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            courses.addCourseToMultipleStudents();

            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            String idealTimeValue = assignmentDetailsPage.getIdealTime();
            String idealTimeValueBottomEllipsis = Constants.IDEAL_TIME_SELECTED;
            courses.clickAssignButton();

            //Traverse to the assignment
            courses.clickAssignmentSubMenu();

            //Click on the View Assignment
            courses.clickOnTheHoveredAssignment( staticCourseName );

            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( assignmentDetailsPage.getSessionLength().equalsIgnoreCase( Constants.SESSION_LENGHT_SELECTED ), "Session Length showed correct", "Session Length showed Incorrect" );
            Log.assertThat( idealTimeValue.equalsIgnoreCase( idealTimeValueBottomEllipsis ), "Idle Time Is Updated", "Idle Time Is Not Updated" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate Calculator Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments023() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments023:Edit Assignment Level Settings - Math - Validate Calculator Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( courses.getTheStatusOfTheCalculator( Constants.OFF_CAPS ).equalsIgnoreCase( Constants.OFF_CAPS ), "Calculator is showing as OFF", "Calculator is not showing as OFF " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate Translate Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments024() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments024:Edit Assignment Level Settings - Math - Validate Translate Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();
            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( courses.getTheStatusOfTheTranslate( Constants.OFF_CAPS ).equalsIgnoreCase( Constants.OFF_CAPS ), "Translate is showing as OFF", "Translate is not showing as OFF " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate Scratchpad Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments025() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments025:Edit Assignment Level Settings - Math - Validate Scratchpad Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();
            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( courses.getTheStatusOfTheScratchPad( Constants.ON_CAPS ).equalsIgnoreCase( Constants.ON_CAPS ), "Scrachpad is showing as ON", "Translate is not showing as ON " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate Show answer Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments026() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments026:Edit Assignment Level Settings - Math - Validate Show answer Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();
            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( courses.getTheStatusOfTheShowAnswer( Constants.ON_CAPS ).equalsIgnoreCase( Constants.ON_CAPS ), "Show Answer is showing as ON", "Show Answer is not showing as ON " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Math - Validate Exit Course Button Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments027() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments027:Edit Assignment Level Settings - Math - Validate Exit Course Button Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();
            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            Log.assertThat( courses.getTheStatusOfTheExitCourse( Constants.ON_CAPS ).equalsIgnoreCase( Constants.ON_CAPS ), "Exit Course Button is showing as ON", "Exit Course Button is not showing as ON " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading - Validate Spanish GlossaryToggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments028() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments028:Edit Assignment Level Settings - Reading - Validate Spanish GlossaryToggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.READING );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            SMUtils.nap( 5 );

            Log.assertThat( courses.getTheStatusOfTheSpanishGlossary( Constants.OFF_CAPS, Constants.READING ).equalsIgnoreCase( Constants.OFF_CAPS ), "Spanish Glossary is showing as OFF", "Spanish Glossary is not showing as OFF " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading - Validate Read To MeToggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments029() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments029:Edit Assignment Level Settings - Reading - Validate Read To MeToggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.READING );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            SMUtils.nap( 5 );

            Log.assertThat( courses.getTheStatusOfTheReadToMe( Constants.OFF_CAPS, Constants.READING ).equalsIgnoreCase( Constants.OFF_CAPS ), "Read To Me is showing as OFF", "Read To Me is not showing as OFF " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading - Validate TranslateToggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments030() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments030:Edit Assignment Level Settings - Reading - Validate TranslateToggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.READING );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            SMUtils.nap( 5 );

            Log.assertThat( courses.getTheStatusOfTheTranslate( Constants.OFF_CAPS, Constants.READING ).equalsIgnoreCase( Constants.OFF_CAPS ), "Translate is showing as OFF", "Translate is not showing as OFF " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading - Validate Share at District LevelToggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments031() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments031:Edit Assignment Level Settings - Reading - Validate Share at District LevelToggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, "seu_teacher", "password1" );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.READING );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            SMUtils.nap( 5 );

            Log.assertThat( courses.getTheStatusOfTheShareAtDistrictLevel( Constants.OFF_CAPS, Constants.READING ).equalsIgnoreCase( Constants.OFF_CAPS ), "Share At District Level is showing as OFF", "Share At District Level is not showing as OFF " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading - Validate FluencyToggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments032() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments032:Edit Assignment Level Settings - Reading - Validate FluencyToggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.READING );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            SMUtils.nap( 5 );

            Log.assertThat( courses.getTheStatusOfTheFluency( Constants.OFF_CAPS, Constants.READING ).equalsIgnoreCase( Constants.OFF_CAPS ), "Fluency is showing as OFF", "Fluency is not showing as OFF " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Assignment Level Settings - Reading - Validate Manually Set Couse Level - Should be Off and Disabled", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments033() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments033:Edit Assignment Level Settings - Reading - Validate Manually Set Couse Level - Should be Off and Disabled<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();
            // Click Delete Assignment
            AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( Constants.READING );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.allAssignmenttSettingTab();

            SMUtils.nap( 5 );

            Log.assertThat( assignmentDetailsPage.getValueOfIPSetCourseLevel( Constants.EditAssignments.SET_COURSE_LEVEL ).equalsIgnoreCase( Constants.EditAssignments.OFF ), "Set Course Level is off", "Set Course level is not Off" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate sesssion length boundary values during edit settings should be from 1 to 180", groups = { "SMK-39223", "Assignment Page",
            "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments034() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments034:Edit Student Level Assignment Settings - Math - Validate sesssion length boundary values during edit settings should be from 1 to 180<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );
            courses.clickAssignBtn();

            List<String> sessionList = assignmentDetailsPage.getListOfSessionLength( Constants.EditAssignments.SESSION_LENGTH_HEADER );
            Log.assertThat( sessionList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.SESSION_LENGTH_FIRST_ELEMENT ), "First value of session Length is displaying", "First value of session Length is not displaying" );
            Log.assertThat( sessionList.get( sessionList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.SESSION_LENGTH_LAST_ELEMENT ), "Last value of session Length is displaying", "Last value of session Length is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Idle Time boundary values during edit settings should be from 2 to 6", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments035() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments035:Edit Student Level Assignment Settings - Math - Validate Idle Time boundary values during edit settings should be from 2 to 6<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );
            courses.clickAssignBtn();

            List<String> idleTimeList = assignmentDetailsPage.getListOfSessionLength( Constants.EditAssignments.IDEAL_TIME_HEADER );
            Log.assertThat( idleTimeList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.IDEAL_TIME_FIRST_ELEMENT ), "First value of Ideal time is displaying", "First value of Ideal time is not displaying" );
            Log.assertThat( idleTimeList.get( idleTimeList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.IDEAL_TIME_LAST_ELEMENT ), "Last value of Ideal time is displaying", "Last value of Ideal time is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Show Limit values during edit settings should be from 1 to 10", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments036() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments036:Edit Student Level Assignment Settings - Math - Validate Show Limit values during edit settings should be from 1 to 10<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );
            courses.clickAssignBtn();

            List<String> limitProgressList = assignmentDetailsPage.getListOfLimitProgress();
            Log.assertThat( limitProgressList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.PROGRESS_LIMIT_FIRST ), "First Value of progress limit is displaying", "First Value of progress limit is not displaying" );
            Log.assertThat( limitProgressList.get( limitProgressList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.PROGRESS_LIMIT_LAST ), "Last Value of progress limit is displaying", "Last Value of progress limit is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Calculator Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments037() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments037:Edit Student Level Assignment Settings - Math - Validate Calculator Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );
            courses.clickAssignBtn();

            Log.assertThat( assignmentDetailsPage.getTheStatusOfTheToggle( Constants.CALCULATOR, Constants.OFF_CAPS ).equalsIgnoreCase( Constants.OFF_CAPS ), "Calculator is showing as OFF", "Calculator is not showing as OFF " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Translate Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments038() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments038:Edit Student Level Assignment Settings - Math - Validate Translate Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );
            courses.clickAssignBtn();

            Log.assertThat( assignmentDetailsPage.getTheStatusOfTheToggle( Constants.TRANSLATE, Constants.OFF_CAPS ).equalsIgnoreCase( Constants.OFF_CAPS ), "Translate is showing as OFF", "Translate is not showing as OFF " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Display Lo Information Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments039() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments039:Edit Student Level Assignment Settings - Math - Validate Display Lo Information Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );
            courses.clickAssignBtn();

            Log.assertThat( assignmentDetailsPage.getTheStatusOfTheToggle( Constants.DISPLAY_LO_INFORMATION, Constants.ON_CAPS ).equalsIgnoreCase( Constants.ON_CAPS ), "Display Lo Information is showing as ON",
                    "Display Lo Information is not showing as ON " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Scratchpad Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments040() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments040:Edit Student Level Assignment Settings - Math - Validate Scratchpad Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );
            courses.clickAssignBtn();

            Log.assertThat( assignmentDetailsPage.getTheStatusOfTheToggle( Constants.SCRATCHPAD, Constants.ON_CAPS ).equalsIgnoreCase( Constants.ON_CAPS ), "Scratchpad is showing as ON", "Scratchpad is not showing as ON " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Show answer Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments041() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments041:Edit Student Level Assignment Settings - Math - Validate Show answer Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );
            courses.clickAssignBtn();

            Log.assertThat( assignmentDetailsPage.getTheStatusOfTheToggle( Constants.SHOW_ANSWER, Constants.ON_CAPS ).equalsIgnoreCase( Constants.ON_CAPS ), "Show Answer is showing as ON", "Show Answer is not showing as ON " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Exit Course Button Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments042() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments042:Edit Student Level Assignment Settings - Math - Validate Exit Course Button Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );
            courses.clickAssignBtn();

            Log.assertThat( assignmentDetailsPage.getTheStatusOfTheToggle( Constants.EXIT_COURSE_BUTTON, Constants.ON_CAPS ).equalsIgnoreCase( Constants.ON_CAPS ), "Exit Course Button is showing as ON", "Exit Course Button is not showing as ON " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Share at District Level Toggle - ON/OFF", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments043() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments043:Edit Student Level Assignment Settings - Math - Validate Share at District Level Toggle - ON/OFF<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );
            courses.clickAssignBtn();

            Log.assertThat( assignmentDetailsPage.getTheStatusOfTheToggle( Constants.SHARE_AT_DISTRICT_LEVEL, Constants.OFF_CAPS ).equalsIgnoreCase( Constants.OFF_CAPS ), "Share at district level is showing as OFF",
                    "Share at district level is not showing as OFF " );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Speed Games Time per Question Only When Speed Games is on", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments044() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments044:Edit Student Level Assignment Settings - Math - Validate Speed Games Time per Question Only When Speed Games is on<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );
            courses.clickAssignBtn();

            Log.assertThat( assignmentDetailsPage.isElementDisplaOnEditPage( Constants.EditAssignments.SPEED_GAMES_QUESTION ).equalsIgnoreCase( Constants.EditAssignments.SPEED_GAMES_QUESTION ), "Speeed Game Question is displaying",
                    "Speed Game question is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Speed Games Time per Question Boundary Values 1 to 6 Seconds", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments045() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments045:Edit Student Level Assignment Settings - Math - Validate Speed Games Time per Question Boundary Values 1 to 6 Seconds<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );

            courses.clickAssignBtn();

            List<String> speedGameList = assignmentDetailsPage.getListOfSpeedgame();
            Log.assertThat( speedGameList.get( 0 ).equalsIgnoreCase( Constants.EditAssignments.SPEED_GAME_FIRST_ELEMENT ), "First Value of Speed game is displaying", "First Value of Speed game is not displaying" );
            Log.assertThat( speedGameList.get( speedGameList.size() - 1 ).equalsIgnoreCase( Constants.EditAssignments.SPEED_GAME_LAST_ELEMENT ), "Last Value of Speeed Game is displaying", "Last Value of Speeed Game is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Edit Student Level Assignment Settings - Math - Validate Speed Games Total Time Only When Speed Games is on", groups = { "SMK-39223", "Assignment Page", "Edit assignment at assignments Level" }, priority = 1 )
    public void tc_editAssignments046() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_SMEditAssignments046:Edit Student Level Assignment Settings - Math - Validate Speed Games Total Time Only When Speed Games is on<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );

            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( Boolean.TRUE.equals( courseWidgetDisplayed ), "Course widget is diplayed", "Course widget is not diplayed" );

            courses = new CoursesPage( driver );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the course
            courses.clickOnCourseNameFromList( Constants.MATH );

            courses.clickAssignBtn();

            Log.assertThat( assignmentDetailsPage.isElementDisplaOnEditPage( Constants.EditAssignments.SPEED_GAMES_TOTAL_TIMES ).equalsIgnoreCase( Constants.EditAssignments.SPEED_GAMES_TOTAL_TIMES ), "Speeed Game times is displaying",
                    "Speed Game times is not displaying" );

            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
}
