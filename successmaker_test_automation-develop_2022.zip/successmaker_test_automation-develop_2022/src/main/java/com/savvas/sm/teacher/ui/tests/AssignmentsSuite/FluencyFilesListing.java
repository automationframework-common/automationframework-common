package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class FluencyFilesListing extends BaseTest {

    private String smUrl;
    private String browser;
    private String username = null;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String studentDetails;
    private List<String> fluencyFileNames;
    private String courseName;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String completeStudentName;

    @BeforeClass (alwaysRun = true)
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentDetails = RBSDataSetup.getMyStudent( school, username );
    }

    @Test ( priority = 1, groups = { "SMK-39528", "Groups", "CreateGroup" } )
    public void tcFluencyFileList01() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "SMK-7468 : Verify the teacher is able to view the 'Fluency Files' popup" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            //To get all the student details for selecting assignment
            String studentFirstName = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" );
            String studentMiddleName = SMUtils.getKeyValueFromResponse( studentDetails, "middleName" );
            String studentLastName = SMUtils.getKeyValueFromResponse( studentDetails, "lastName" );
            String userId = SMUtils.getKeyValueFromResponse( studentDetails, "userId" );

            //Logging in as a teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Navigating to course page
            CoursesPage courseListingPage = tHomePage.navigateToCourseListingPage();
         //   courseName = courseListingPage.generateRandomCourseName();
            courseName = "fluncy course - "+System.nanoTime();
            CourseListingPage coursePage = tHomePage.topNavBar.getCourseListingPage();
            coursePage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            courseListingPage.copyOfCourse( courseName, Constants.SETTINGS, Constants.READING );
            tHomePage.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );
            Thread.sleep( 3000 );

            coursePage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.clickFromCourseListingPage( courseName );

            //Editing the course to enable fluency
            courseListingPage.clickEditBtn();
            courseListingPage.changeStatusOfTheFluency( Constants.ON_CAPS );
            courseListingPage.clickSaveBtn();

            //Assigning the assignment to students
            tHomePage.navigateToCourseListingPage();
            coursePage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.clickCourseFromTheListing( courseName );
            courseListingPage.clickAssignBtn();
            courseListingPage.addCourseToStudents();

            SMUtils.nap( 10 );
            //Generating the fluency files
            fluencyFileNames = new SqlHelperCourses().createFluencyFiles( 3, Integer.parseInt( new SqlHelperCourses().getAssignmentUserId( userId, new SqlHelperCourses().getAssignmentIDUsingName( courseName ) ) ) );

            //Navigating to assignment page
            AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            String assignmentLevelFilesCount = assignmentPage.getAssignmentFluencyFileCount( courseName );

            //Viewing the assignment
            AssignmentDetailsPage assignmentDetails = assignmentPage.viewAssignmentDetailsByAssignmentName( courseName );
            completeStudentName = assignmentDetails.completeStudentName( studentFirstName, studentMiddleName, studentLastName );

            //Navigating to fluency popup through student ellipses button
            String fluencyCount = assignmentDetails.fluencyFilesInEllipsisFromStudent( completeStudentName, false );
            assignmentDetails.fluencyFilesInEllipsisFromStudent( completeStudentName, true );

            //Validations
            SMUtils.logDescriptionTC( "SMK-7468 - Verify the teacher is able to view the 'Fluency Files' popup" );
            Log.assertThat( assignmentDetails.getFluencyFilePopupHeader().equalsIgnoreCase( completeStudentName + "'s Fluency Files" ), "Fluency file popup loaded", "Fluency file popup not loaded." );
            Log.assertThat( fluencyCount.contains( assignmentLevelFilesCount ), "Fluency file count matched with student level and assignment level for single student.",
                    "Fluency file count not matched with student level and assignment level for single student." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 2, groups = { "SMK-39528", "Groups", "CreateGroup" } )
    public void tcFluencyFileList02() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify the availability of buttons and options at bottom of the Fluency Files popup" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetails = assignmentPage.viewAssignmentDetailsByAssignmentName( courseName );

            //Verifying download button function
            assignmentDetails.fluencyFilesInEllipsisFromStudent( completeStudentName, true );
            assignmentDetails.selectFluencyFileByName( fluencyFileNames.get( 0 ) );
            assignmentDetails.clickDownloadFluency( browser );

            //Verifying Delete button functionality
            tHomePage.topNavBar.navigateToCourseListingPage();
            tHomePage.topNavBar.navigateToAssignmentsPage();
            assignmentPage.viewAssignmentDetailsByAssignmentName( courseName );
            assignmentDetails.fluencyFilesInEllipsisFromStudent( completeStudentName, true );

            //Navigating to fluency popup through student ellipses button
            assignmentDetails.selectFluencyFileByName( fluencyFileNames.get( 0 ) );
            assignmentDetails.clickDeleteFluency();
            SMUtils.logDescriptionTC( "SMK-10226 : Verify the Delete button color in Delete Fluency files for teacher user" );
            assignmentDetails.clickButtonsFromPopup( Constants.DELETE );

            //Verifying cancel button
            SMUtils.logDescriptionTC( "SMK-7471 : Verify user able to close the fluency files popup" );
            assignmentDetails.clickCancelButtonFluency();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 3, groups = { "SMK-39528", "Groups", "CreateGroup" } )
    public void tcFluencyFileDownload01() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "SMK-6449 : Verify the teacher able to download the single file." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetails = assignmentPage.viewAssignmentDetailsByAssignmentName( courseName );

            //Verifying download button function
            assignmentDetails.fluencyFilesInEllipsisFromStudent( completeStudentName, true );
            assignmentDetails.selectFluencyFileByName( fluencyFileNames.get( 1 ) );
            assignmentDetails.clickDownloadFluency( browser );
            Log.assertThat( SMUtils.isFileDownloaded( Constants.FLUENCY_FILE_DOWNLOAD_NAME, driver ), "File downloaded successfully", "File is not downloaded" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 4, groups = { "SMK-39528", "Groups", "CreateGroup" } )
    public void tcFluencyFileDownload02() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "SMK-6451 : User should be able to Download all the files." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetails = assignmentPage.viewAssignmentDetailsByAssignmentName( courseName );

            //Verifying download button function
            assignmentDetails.fluencyFilesInEllipsisFromStudent( completeStudentName, true );
            assignmentDetails.selectAllFluencyFiles();
            assignmentDetails.clickDownloadFluency( browser );
            Log.assertThat( SMUtils.isFileDownloaded( Constants.FLUENCY_FILE_DOWNLOAD_NAME, driver ), "All the downloaded successfully", "All the files is not downloaded" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 5, groups = { "SMK-39528", "Groups", "CreateGroup" } )
    public void tcFluencyFileDownload03() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "SMK-6448 : Single fluency assigned  to multiple students." + "<small><b><i>[" + browser + "]</b></i></small>" );
        String studentFirstName;
        String studentMiddleName;
        String studentLastName;
        String userId;
        List<String> fileNamesFromUI;
        try {
            //Verification for 1st student
            studentFirstName = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" );
            studentMiddleName = SMUtils.getKeyValueFromResponse( studentDetails, "middleName" );
            studentLastName = SMUtils.getKeyValueFromResponse( studentDetails, "lastName" );
            userId = SMUtils.getKeyValueFromResponse( studentDetails, "userId" );

            //Logging in as a teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            //Navigating to course page
            CoursesPage courseListingPage = tHomePage.navigateToCourseListingPage();
            courseName = courseListingPage.generateRandomCourseName();

            //Creating settings based reading course
            CourseListingPage coursePage = tHomePage.topNavBar.getCourseListingPage();
            coursePage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            courseListingPage.copyOfCourse( courseName, Constants.SETTINGS, Constants.READING );

            coursePage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            //Editing the course to enable fluency
            courseListingPage.clickCourseFromTheListing( courseName );
            courseListingPage.clickEditBtn();
            courseListingPage.changeStatusOfTheFluency( Constants.ON_CAPS );
            courseListingPage.clickSaveBtn();

            //Assigning the assignment to students
            tHomePage.navigateToCourseListingPage();
            coursePage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.clickCourseFromTheListing( courseName );
            courseListingPage.clickAssignBtn();
            courseListingPage.addCourseToStudents();

            SMUtils.nap( 10 );
            //Generating the fluency files
            fluencyFileNames = new SqlHelperCourses().createFluencyFiles( 3, Integer.parseInt( new SqlHelperCourses().getAssignmentUserId( userId, new SqlHelperCourses().getAssignmentIDUsingName( courseName ) ) ) );

            //Navigating to assignment page
            AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            //Viewing the assignment
            String assignmentLevelFilesCount = assignmentPage.getAssignmentFluencyFileCount( courseName );
            AssignmentDetailsPage assignmentDetails = assignmentPage.viewAssignmentDetailsByAssignmentName( courseName );

            //Navigating to fluency popup through student ellipses button
            completeStudentName = assignmentDetails.completeStudentName( studentFirstName, studentMiddleName, studentLastName );
            String fluencyCount = assignmentDetails.fluencyFilesInEllipsisFromStudent( completeStudentName, false );
            assignmentDetails.fluencyFilesInEllipsisFromStudent( completeStudentName, true );

            //Validations
            Log.assertThat( assignmentDetails.getFluencyFilePopupHeader().equalsIgnoreCase( completeStudentName + "'s Fluency Files" ), "Fluency file popup loaded", "Fluency file popup not loaded." );
            Log.assertThat( fluencyCount.contains( assignmentLevelFilesCount ), "Fluency file count matched with student level and assignment level for single student.",
                    "Fluency file count not matched with student level and assignment level for single student." );
            fileNamesFromUI = assignmentDetails.getAllFluencyFiles();
            fileNamesFromUI.remove( 0 ); //To remove the fetched header
            Log.assertThat( SMUtils.sortList( fluencyFileNames ).equals( SMUtils.sortList( fileNamesFromUI ) ), "All files displayed successfully!", "Issue in displaying files" );

            //Verification for 2nd Student
            studentDetails = RBSDataSetup.getMyStudent( school, username );
            studentFirstName = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" );
            studentMiddleName = SMUtils.getKeyValueFromResponse( studentDetails, "middleName" );
            studentLastName = SMUtils.getKeyValueFromResponse( studentDetails, "lastName" );

            userId = SMUtils.getKeyValueFromResponse( studentDetails, "userId" );

            fluencyFileNames = new SqlHelperCourses().createFluencyFiles( 3, Integer.parseInt( new SqlHelperCourses().getAssignmentUserId( userId, new SqlHelperCourses().getAssignmentIDUsingName( courseName ) ) ) );

            tHomePage.topNavBar.navigateToAssignmentsPage();
            assignmentPage.viewAssignmentDetailsByAssignmentName( courseName );
            completeStudentName = assignmentDetails.completeStudentName( studentFirstName, studentMiddleName, studentLastName );
            assignmentDetails.fluencyFilesInEllipsisFromStudent( completeStudentName, true );

            Log.assertThat( assignmentDetails.getFluencyFilePopupHeader().equalsIgnoreCase( completeStudentName + "'s Fluency Files" ), "Fluency file popup loaded", "Fluency file popup not loaded." );
            fileNamesFromUI = assignmentDetails.getAllFluencyFiles();
            fileNamesFromUI.remove( 0 ); //To remove the fetched header
            Log.assertThat( SMUtils.sortList( fluencyFileNames ).equals( SMUtils.sortList( fileNamesFromUI ) ), "All files displayed successfully!", "Issue in displaying files" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 6, groups = { "SMK-39528", "Groups", "CreateGroup" } )
    public void tcFluencyFileDelete01() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify the teacher is able to view the 'Fluency Files' popup" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            String studentFirstName = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" );
            String studentMiddleName = SMUtils.getKeyValueFromResponse( studentDetails, "middleName" );
            String studentLastName = SMUtils.getKeyValueFromResponse( studentDetails, "lastName" );

            String userId = SMUtils.getKeyValueFromResponse( studentDetails, "userId" );
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage courseListingPage = tHomePage.navigateToCourseListingPage();
            courseName = courseListingPage.generateRandomCourseName();

            CourseListingPage coursePage = tHomePage.topNavBar.getCourseListingPage();
            coursePage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            courseListingPage.copyOfCourse( courseName, Constants.SETTINGS, Constants.READING );

            coursePage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            courseListingPage.clickCourseFromTheListing( courseName );
            courseListingPage.clickEditBtn();
            courseListingPage.changeStatusOfTheFluency( Constants.ON_CAPS );
            courseListingPage.clickSaveBtn();
            tHomePage.navigateToCourseListingPage();
            coursePage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.clickCourseFromTheListing( courseName );
            courseListingPage.clickAssignBtn();
            courseListingPage.addCourseToStudents();

            SMUtils.nap( 10 );
            fluencyFileNames = new SqlHelperCourses().createFluencyFiles( 5, Integer.parseInt( new SqlHelperCourses().getAssignmentUserId( userId, new SqlHelperCourses().getAssignmentIDUsingName( courseName ) ) ) );

            AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetails = assignmentPage.viewAssignmentDetailsByAssignmentName( courseName );
            completeStudentName = assignmentDetails.completeStudentName( studentFirstName, studentMiddleName, studentLastName );
            assignmentDetails.fluencyFilesInEllipsisFromStudent( completeStudentName, true );

            //Verifying the delete popup and all buttons status
            SMUtils.logDescriptionTC( "SMK-6565 : Verify the delete button is disabled by default" );
            Log.assertThat( !assignmentDetails.checkDeleteBtnEnabled(), "Delete button is disabled by default", "Delete button enabled but it should be displaed by default" );

            SMUtils.logDescriptionTC( "SMK-6566 : Verify the delete button is enabled after selecting files" );
            assignmentDetails.selectAllFluencyFiles();
            Log.assertThat( assignmentDetails.checkDeleteBtnEnabled(), "Delete button is enabled after selcting files", "Delete button is not enabled after selcting files" );

            SMUtils.logDescriptionTC( "SMK-6567 : Verify the delete button is disabled when user removes all the selected files" );
            assignmentDetails.selectAllFluencyFiles();
            Log.assertThat( !assignmentDetails.checkDeleteBtnEnabled(), "Delete button is enabled after selcting files", "Delete button is not enabled after selcting files" );

            SMUtils.logDescriptionTC( "SMK-6569 : Verify the 'Delete File(s)' Confirmation popup displays when user tires to delete the files" );
            assignmentDetails.selectAllFluencyFiles();
            assignmentDetails.clickDeleteFluency();

            SMUtils.logDescriptionTC( "SMK-6570 : Verify the user able to Cancel in 'Delete File(s)' Confirmation popup" );
            assignmentDetails.clickButtonsFromPopup( Constants.CANCEL );

            SMUtils.logDescriptionTC( "SMK-6562 - Verify the teacher is able to delete by selecting the single file in 'Fluency Files' popup" );
            assignmentDetails.selectAllFluencyFiles();
            assignmentDetails.selectFluencyFileByName( fluencyFileNames.get( 0 ) );
            assignmentDetails.clickDeleteFluency();
            assignmentDetails.clickButtonsFromPopup( Constants.DELETE );
            Log.assertThat( !assignmentDetails.isFluencyFileExist( fluencyFileNames.get( 0 ) ), "File Deleted successfully- " + fluencyFileNames.get( 0 ), "Issue in deletion of file" );

            SMUtils.logDescriptionTC( "SMK-6563 : Verify the teacher is able to delete by selecting the multiple files in 'Fluency Files' popup" );

            IntStream.range( 1, 3 ).forEach( count -> assignmentDetails.selectFluencyFileByName( fluencyFileNames.get( count ) ) );

            assignmentDetails.clickDeleteFluency();
            assignmentDetails.clickButtonsFromPopup( Constants.DELETE );
            IntStream.range( 0, 2 ).forEach( count -> {
                Log.assertThat( !assignmentDetails.isFluencyFileExist( fluencyFileNames.get( count ) ), "File Deleted successfully- " + fluencyFileNames.get( count ), "Issue in deletion of file" );
            } );

            SMUtils.logDescriptionTC( "SMK-6564 : Verify the teacher is able to delete all the files by using the 'select all' options in 'Fluency Files' popup" );
            SMUtils.logDescriptionTC( "SMK-6578 : Verify the availability of No files text for which does not have any fluency files in the assignments" );
            assignmentDetails.selectAllFluencyFiles();
            assignmentDetails.clickDeleteFluency();
            assignmentDetails.clickButtonsFromPopup( Constants.DELETE );
            assignmentDetails.clickCancelButtonFluency();
            assignmentDetails.fluencyFilesInEllipsisFromStudent( completeStudentName, true );
            assignmentDetails.verifyZeroStateFluencyFile();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
