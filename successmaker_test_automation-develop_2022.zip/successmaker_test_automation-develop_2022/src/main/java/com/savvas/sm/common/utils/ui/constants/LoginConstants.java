package com.savvas.sm.common.utils.ui.constants;

public interface LoginConstants {
    interface UserType {
        public static String BASIC = "basic";
        public static String AUTO = "auto";
        public static String PLUS = "plus";
    }

    interface AUTO_DISTRICT_DETAILS {

        public static String DISTRICT_NAME_AUTO = "J_License_District";
        public static String USERNAME_AUTO = "teacher_jesko01";
        public static String USERNAME_WITH_DISTRICT_AUTO = "teacher_jesko01@smlicensing";
        public static String STUDENT_USERNAME_AUTO = "new_student_jesko_01";
        public static String STUDENT_USERNAME_WITH_DISTRICT_AUTO = "new_student_jesko_01@smlicensing";
    }

    interface PLUS_DISTRICT_DETAILS {

        public static String DISTRICT_NAME_PLUS = "Galactic Empire Nightly EB Plus";
        public static String USERNAME_PLUS = "realize.ebplus100";
        public static String USERNAME_WITH_DISTRICT_PLUS = "realize.ebplus100@nightlygalacticplus";
        public static String STUDENT_USERNAME_PLUS = "realize.plusstud101";
        public static String STUDENT_USERNAME_WITH_DISTRICT_PLUS = "gcstudent210@nightlygalacticplus";
    }

    interface DIFFERENT_DISTRICT_USERS {

        public static String TEACHER_USER_NAME_AUTO = "tchun_10000000000000000000@sm2022auto";
        public static String TEACHER_USERNAME_BASIC = "smautoteacherbasic410993049651900";
        public static String TEACHER_USERNAME_AUTOMSMN = "tchun_10000000010000000000@sm2022automsmn";
        public static String STUDENT_USERNAME_BASIC = "smuserrumba411243695440500";
        public static String STUDENT_USERNAME_AUTO = "stuun20001862@sm2022auto";
        public String UNAUTHORIZED = "Unauthorized";
        public String BODYCONTENT = "You do not have access to view this page with the credentials provided. Please try again.";
    }

    interface ADMIN_USER {
        public static String ADMIN_USER_NAME = "radmin";
        public static String ADMIN_PASSWORD = "abcd1234!";
        public static String ORG_ID = "8a7200f77de565ac017e2484aff10660";
        public static String BACKWARD_SLASH = "\\";
        public static String DOUBLE_QUOTATION = "\"";
    }

    interface DIFF_LICENSE_STATE_TEACHER_USERS {
        public static String NO_LICENSE_TEACHER = "as_jesko_teacher";
        public static String TEACHER_WITH_EXPIRED_LICENSE = "jesko_teacher_exp";
        public static String TEACHER_WITH_FUTURE_LICENSE = "jesko_teacher_futurelic";
        public static String TEACHER_WITH_ACTIVE_LICENSE = "as_flex_teacher";

    }
}
