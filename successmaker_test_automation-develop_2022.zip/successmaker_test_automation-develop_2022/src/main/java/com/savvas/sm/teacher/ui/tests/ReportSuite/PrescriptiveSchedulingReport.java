package com.savvas.sm.teacher.ui.tests.ReportSuite;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Reports;
import com.savvas.sm.common.utils.Constants.Students;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.PSRPage;
import com.savvas.sm.teacher.ui.pages.ReportComponent;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class PrescriptiveSchedulingReport extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher5" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( description = "Verify Prescriptive Scheduling option should present under the Reports top menu and header and description text should be displayed in the Prescriptive Scheduling Report Page.", groups = { "SMK-43784", "reports",
            "prescriptiveSchedulingReport" }, priority = 1 )
    public void tcSMPSR001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo(
                "tcSMSPR001: Verify Prescriptive Scheduling option should present under the Reports top menu and header and description text should be displayed in the Prescriptive Scheduling Report Page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            //initializing ReportComponent
            ReportComponent reportComponent = new ReportComponent( driver );

            SMUtils.logDescriptionTC( "SMK-12162 - Verify Prescriptive Scheduling option should present under the Reports top menu." );
            // Verify Prescriptive scheduling report Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.PSR_REPORT ), "Prescriptive sheduling Report sub menu is Present under report menu", "Prescriptive sheduling Report sub menu is not Present under report menu" );
            Log.testCaseResult();

            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12163 -Verify Prescriptive Scheduling Report Page should be Open after click the Prescriptive Scheduling option in sub menu." );
            //Verifying PSR Header
            Log.assertThat( reportPage.getReportPageHeader().equals( Constants.Reports.PSR_HEADER ), "PSR report header is \"" + Constants.Reports.PSR_HEADER + "\"", "PSR Header is not present." );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12164 - Verify header and description text should be displayed in the Prescriptive Scheduling Report Page" );
            //Verifying PSR Description
            Log.assertThat( reportComponent.getReportDescription().equals( Constants.Reports.PSR_DESCRIPTION ), "PSR Description text is \"" + Constants.Reports.PSR_DESCRIPTION + "\"", "PSR description text is not present." );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all fields are available in the Prescriptive Scheduling Report page.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMSPR002: Verify all fields are available in the Prescriptive Scheduling Report page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            //initializing ReportComponent
            ReportComponent reportComponent = new ReportComponent( driver );

            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12165 - Verify all fields are available in the Prescriptive Scheduling Report page." );

            // Verify PSR header
            Log.assertThat( reportComponent.getReportPageHeader().equals( Constants.Reports.PSR_HEADER ), "Cumulative Performance Report header is Present", "Cumulative Performance Report header is not Present" );

            // Verify Filters heading
            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.FILTERS ), "Filters heading is present in the PSR Page", "Filters heading is not present in the PSR Page" );

            // Verify Select Groups or Students heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.GROUP_OR_STUDENT_HEADER ), "Select Groups or Students heading is present in the PSR Page",
                    "Select Groups or Students heading is not present in the PSR Page" );

            // Verify group dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.GROUP_DROPDOWN ), "Group dropdown is present in the PSR Page", "Group dropdown is not present in the PSR Page" );

            // Verify student dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.STUDENTS_DROPDOWN ), "Student dropdown is present in the PSR Page", "Students dropdown is not present in the PSR Page" );

            // Verify Refine search heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.REFINE_SEARCH ), "Refine search heading is present in the PSR Page", "Refine search heading is present in the PSR Page" );

            // Verify subject dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject dropdown is present in the PSR Page", "Subjects dropdown is not present in the PSR Page" );

            // Verify assignment dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "Assignments dropdown is present in the PSR Page", "Assignments dropdown is not present in the PSR Page" );

            // Verify Report option heading
            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.REPORT_OPTION_HEADER ), "Report option heading is present in the PSR Page", "Report option heading is not present in the PSR Page" );

            // Verify Saved Option dropdown heading
            Log.assertThat( reportComponent.isSavedOptionDropdownHeadingPresent(), "Saved Option dropdown is present in the PSR Page", "Saved Option dropdown is not present in the PSR Page" );

            //Verify Holiday Info text
            Log.assertThat( reportPage.isHolidayInfoTextDisplayed(), "Holiday info Text is \"" + Constants.Reports.PSR_HOLIDAY_INFO + "\"", "Holiday info Text is not present in the PSR Page" );

            //Verify Target Date Field
            Log.assertThat( reportPage.isTargetDateFieldDisplayed(), "Target date is present in the PSR page", "Target date is not present in the PSR Page" );

            //Verify Set target level per grade Field
            Log.assertThat( reportPage.isSetTargetLevelPerGradeFieldDisplayed(), "\"Set target level per grade\" is present in the PSR page", "\"Set target level per grade\" is not present in the PSR Page" );

            // Verify additional grouping dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.ADDITIONAL_GROUPING ), "Additional grouping dropdown heading is present in the PSR Page", "Additional grouping dropdown is not present in the PSR Page" );

            // Verify Display dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.DISPLAY_DROPDOWN ), "Display dropdown heading is present in the PSR Page", "Display dropdown heading is not present in the PSR Page" );

            // Verify Display dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.SORT_DROPDOWN ), "Sort dropdown heading is present in the PSR Page", "Sort dropdown heading is not present in the PSR Page" );

            // Verify Remove page break field
            Log.assertThat( reportComponent.isMaskStudentDisplayAndRemovePageBreakFieldDisplayed( Constants.Reports.MASK_STUDENT_DISPLAY ), "Remove page break field is present in the PSR page", "Remove page break field is not present in the PSR page" );

            // Verify Mask student display field
            Log.assertThat( reportComponent.isMaskStudentDisplayAndRemovePageBreakFieldDisplayed( Constants.Reports.REMOVE_PAGE_BREAKS ), "Mask student display is present in the PSR page", "Mask student display field is not present in the PSR page" );

            // Verify Save Report Option button
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getSaveReportOptionButton() ), "Saved Report option button is present", "Saved Report option button is not present!" );

            // Verify Run Report
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getRunReportOption() ), "Run report button present!", "Run report not button present!" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher should be able to select one or more group in the Groups drop down.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR003() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR003: Verify teacher should be able to select one or more group in the Groups drop down. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupOptions = new ArrayList<>();

            SMUtils.logDescriptionTC( "SMK-12170 - Verify teacher should be able to select one or more group in the Groups drop down." );
            // Verify the Dropdown text after selecting one Group
            if ( groupsFromUI.size() > 1 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( groupsFromUI.get( 0 ).equals( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ) ), "Selected group name is Displayed", "Selected group name is not Displayed" );
            } else if ( groupsFromUI.size() == 1 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "1" ) ),
                        "All Groups text and count of the Groups is Display Properly", "All Groups text or count of the Groups is not Display Properly" );
            } else {
                Log.message( "Given teacher don't have goups" );
            }

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            //Selecting more than one group
            if ( groupsFromUI.size() > 2 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                groupOptions.add( groupsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Count of selected group is Displayed",
                        "count of selected group name is not Displayed" );
            } else if ( groupsFromUI.size() == 2 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                groupOptions.add( groupsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All Groups text and count of the Groups is Display Properly", "All Groups text or count of the Groups is not Display Properly" );
            } else {
                Log.message( "Given teacher has less than one goup" );
            }
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the group names and Student name listed in the Groups and Students drop down.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR004() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR004: Verify the group names and Student name listed in the Groups and Students drop down. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12171 - Verify the group names listed in the Groups drop down." );
            // getting the groups names from data setup
            List<String> groupsList = new ArrayList<>();
            String groupDetails = DataSetup.teacherGroupMap.get( username ).get( username );
            for ( int groupCount = 1; groupCount <= SMUtils.getWordCount( groupDetails, "groupName" ); groupCount++ ) {
                groupsList.add( SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", groupCount ) );
            }

            // Getting groups from UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            Log.assertThat( groupsList.equals( groupsFromUI ), "Groups displayed successfully!", "Groups not displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12175 - Verify the Student names listed in the Students drop down." );
            // getting the Student names from data setup
            List<String> studentList = new ArrayList<>();
            List<String> studentFirstNameAndLastNameList = new ArrayList<>();
            for ( int studentCount = 1; studentCount <= DataSetup.teacherStudentMap.get( username ).size(); studentCount++ ) {
                studentList.add( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ) );
                studentFirstNameAndLastNameList.add( SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,middleName" ) + ". "
                        + SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,lastName" ) );
            }

            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> allStudentsFromUI = reportComponent.getValuesFromDropDownMS();

            Log.assertThat( SMUtils.sortList( studentFirstNameAndLastNameList ).equals( SMUtils.sortList( allStudentsFromUI ) ), "All Students displayed properly in the student dropdown!", "Students not displayed properly in thes student dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Removed group should not display in the Groups drop down.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR005: Verify the Removed group should not display in the Groups drop down. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            // Getting groups from UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();

            SMUtils.logDescriptionTC( "SMK-12172 - Verify the Removed group should not display in the Groups drop down." );
            if ( groupsFromUI.size() > 0 ) {
                // getting Group Name
                String groupName = groupsFromUI.get( 0 );

                // Delete Group
                GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
                groupPage.viewGroup( groupName );
                SMUtils.nap( 2 ); //required for page loading
                groupPage.deleteGroup( groupName );

                // navigate to PSR Page
                teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

                // again Getting groups from UI
                reportComponent.setDropDownMS( "Groups" );
                groupsFromUI = reportComponent.getValuesFromDropDownMS();

                // validate delete group should not display under groups dropdown
                Log.assertThat( !( groupsFromUI.contains( groupName ) ), "Deleted Group is not present under Groups Dropdown", "Deleted Group is present under Groups Dropdown" );
            } else {
                Log.message( "Given teacher don't have goups" );
            }
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher should be able to select one or more Student in the Students drop down.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR006() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR006: Verify 'students' dropdown field display under Filters option when more than one students are selected. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12174 - Verify teacher should be able to select one or more Student in the Students drop down." );

            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> allStudentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();

            // Verify the Dropdown text after selecting multiple Students
            if ( allStudentsFromUI.size() > 2 ) {
                studentOptions.add( allStudentsFromUI.get( 0 ) );
                studentOptions.add( allStudentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_STUDENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Count of selected student is Displayed",
                        "count of selected student is not Displayed" );
            } else if ( allStudentsFromUI.size() == 2 ) {
                studentOptions.add( allStudentsFromUI.get( 0 ) );
                studentOptions.add( allStudentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_STUDENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All Students text and count of the students is displayed properly", "AllStudents text or count of the students is not displayed properly" );
            } else {
                Log.message( "Given teacher has less than one student" );
            }
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher can able to select one or more assignments in the Assignments drop down", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR007() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR007: Verify 'Assignments' dropdown field display under Filters option when more than one assignments are selected. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            SMUtils.logDescriptionTC( "SMK-12185 - Verify teacher can able to select one or more assignments in the Assignments drop down" );
            // navigate to PSR Page
            teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            // Verify the Dropdown text after selecting one assignment
            if ( assignmentsFromUI.size() > 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( assignmentsFromUI.get( 0 ).equals( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ) ), "Selected assignment name is Displayed", "Selected assignment name is not Displayed" );
            } else if ( assignmentsFromUI.size() == 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.ASSIGNMENTS_DROPDOWN, "1" ) ),
                        "All assignments text and count of the assignments is Display Properly", "All assignments text or count of the assignments is not Display Properly" );
            } else {
                Log.message( "Given teacher don't have assignments" );
            }

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );

            // Verify the Dropdown text after selecting multiple assignment
            if ( assignmentsFromUI.size() > 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "Count of selected assignment is Displayed", "count of selected assignment name is not Displayed" );
            } else if ( assignmentsFromUI.size() == 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All assignment text and count of the assignments is Display Properly", "All assignment text or count of the assignments is not Display Properly" );
            } else {
                Log.message( "Given teacher has less than one assignment" );
            }
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify removed assignments should not display under assignment dropdown.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR008() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR008: Verify removed assignments should not display under assignment dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to PSR Page
            teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12183 - Verify the assignments listed in the Assignments drop down." );
            List<String> assignmentsList = new ArrayList<>();
            String assignmentsDetails = DataSetup.teacherAssignmentMap.get( username ).get( username );
            for ( int assignmentsCount = 1; assignmentsCount <= SMUtils.getWordCount( assignmentsDetails, "name" ); assignmentsCount++ ) {
                assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignmentsDetails, "name", assignmentsCount ) );
            }
            // Getting Assignments from UI
            reportComponent.setDropDownMS( "Assignments" );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            Log.assertThat( assignmentsList.containsAll( assignmentsFromUI ), "All Assignments displayed successfully!", "Assignments not displayed properly" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "Verify the removed Assignments should not display in the Assignments drop down." );
            if ( assignmentsFromUI.size() > 0 ) {
                // getting Assignment Name
                String assignmentsName = assignmentsFromUI.get( 0 );
                // Navigate to Courseware tab
                AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

                // Click on Assignment SubMenu
                page.clickAssignmentSubMenu();

                // Click Delete Assignment
                AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( assignmentsName );
                assignmentDetailsPage.assignmentLevelEllipsis();
                assignmentDetailsPage.deleteAssignmenttab();
                SMUtils.nap( 2 ); //required for page loading
                assignmentDetailsPage.deleteAssignmentButton();
                Log.assertThat( assignmentDetailsPage.isAssignmentDisplayed(), "Assignment has deleted successfully", "Assignment has not deleted successfully" );

                //navigate to PSR Report page
                teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();
                reportComponent.setDropDownMS( "Assignments" );
                assignmentsFromUI = reportComponent.getValuesFromDropDownMS();

                // validate delete group should not display under groups
                // dropdown
                Log.assertThat( !( assignmentsFromUI.contains( assignmentsName ) ), "Deleted assignments is not present under Assignments Dropdown", "Deleted assignments is present under assignments Dropdown" );
                Log.testCaseResult();
                // SignOut from SM
                teacherHomePage.topNavBar.signOutfromSM();
            } else {
                Log.message( "Teacher don't have assignments" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Additional Grouping', 'Sort' and 'Display' options dropdown should display on PSR page.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR009() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR009: Verify 'Additional Grouping' dropdown should display on PSR page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to PSR Page
            teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            // Getting values for Additional grouping
            List<String> additionalGroupingFromUI = reportComponent.getValuesFromStaticDropDownMSWithLowerCase( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN );
            // Validation for Additional grouping
            Log.assertThat( ( additionalGroupingFromUI ).equals( ( Constants.Reports.PSR_ADDITION_GROUPING ) ), "Additional grouping information loaded successfully!", "Additional grouping information not loaded properly!" );

            // Getting values for Display
            List<String> displayFromUI = reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.DISPLAY_DROPDOWN );
            // Validation for Sort
            Log.assertThat( ( displayFromUI ).equals( Constants.Reports.DISPLAY ), "Display information loaded successfully!", "Display information not loaded properly!" );

            // Getting values for Sort
            List<String> sortFromUI = reportComponent.getValuesFromStaticDropDownMSWithLowerCase( Constants.Reports.SORT_DROPDOWN );
            // Validation for Sort
            Log.assertThat( sortFromUI.equals( Constants.Reports.PSR_SORT ), "Sort information loaded successfully!", "Sort information not loaded properly!" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selection of Current Date and Future Date in 'Target Date' field", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR010() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR010: Verify the selection of Current Date and Future Date in 'Target Date' field. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12189 - Verify the selection of Current Date and Future Date in 'Target Date' field" );
            // Enter target date
            SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
            String targetDate = dateFormat.format( new Date() );
            reportPage.setTargetDate( targetDate );

            //Verify the Run report button is enabled or not
            Log.assertThat( reportComponent.getRunReportOption().isEnabled(), "Run Report is enabled after enter the valid target date", "Run Report is not Enabled after enter the valid target date" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the selection of Past Date in 'Target Date' field ", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR011() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR011: Verify the selection of Past Date in 'TargetDate' field  <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12190 - Verify the selection of Past Date in 'TargetDate' field" );
            // Enter target date
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
            calendar.add( Calendar.DATE, -2 );
            reportPage.setTargetDate( dateFormat.format( calendar.getTime() ) );

            //Verify the error message
            Log.assertThat( reportPage.getErrorMessage().equals( Constants.Reports.PSR_ERROR_MESSAGE ), "Error Message (" + Constants.Reports.PSR_ERROR_MESSAGE + ") is displayed properly.",
                    "Error Message (" + Constants.Reports.PSR_ERROR_MESSAGE + ") is not displayed properly." );

            //Verify the Run report button is enabled or not
            Log.assertThat( !( reportComponent.getRunReportOption().isEnabled() ), "Run Report is disabled after enter the past date in target date", "Run Report is not disabled after enter the past date in target date" );

            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Set Target Level Per Grade' and  min and max range for slider if the single Student with particular Grade is selected and verify user can able to slect target level in slider bar. ", groups = { "SMK-43784", "reports",
            "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR012() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR012: Verify 'Set Target Level Per Grade' if the single Student with particular Grade is selected <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            SMUtils.logDescriptionTC( "SMK-12191 - Verify 'Set Target Level Per Grade' if the single Student with particular Grade is selected" );
            //get all Student Details
            HashMap<String, List<String>> studentDetails = studentPage.getColumnDetailsAsList();

            // Navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // get student from Students dropdown
            List<String> allStudentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();
            studentOptions.add( allStudentsFromUI.get( 0 ) );

            //get grades for students
            List<String> expectedGrades = reportPage.getStudentsGrade( studentDetails, studentOptions );
            reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );

            List<String> displayedGradesFromUI = reportPage.getDisplayedGradesFromUI();

            Log.assertThat( displayedGradesFromUI.containsAll( expectedGrades ), "Grade sliders displayed for selected student", "Grade sliders not displayed properly for selected student" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12195 - Verify the Lower level target and Higher level target in the Grade slide bar" );
            //Verify min and Max Range for slider
            HashMap<String, String> ranges = reportPage.getSliderRanges( displayedGradesFromUI.get( 0 ) );
            Log.assertThat( ranges.get( "lower Range" ).equals( Constants.Reports.PSR_LOWER_RANGE ), "Lowest range - " + Constants.Reports.PSR_LOWER_RANGE + " in slider displayed properly ",
                    "Lowest range - " + Constants.Reports.PSR_LOWER_RANGE + " in slider not displayed properly" );
            Log.assertThat( ranges.get( "highest Range" ).equals( Constants.Reports.PSR_HIGHER_RANGE ), "Highest Range -" + Constants.Reports.PSR_HIGHER_RANGE + " in slider displayed properly ",
                    "Highest Range - " + Constants.Reports.PSR_HIGHER_RANGE + " in slider not displayed properly" );

            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12196 - Verify teacher can modify student Target level in the Grade slide bar in Prescriptive Scheduling page" );
            //To drag the slider
            Log.assertThat( reportPage.moveSliderTo( displayedGradesFromUI.get( 0 ), "1" ), "Able to drag the target level slider", "Unable to drag the target level slider" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Set Target Level Per Grade' if the multiple Student is selected with different Grade", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR013() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR013: Verify 'Set Target Level Per Grade' if the multiple Student is selected with different Grade <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Student Page
            StudentsPage studentPage = teacherHomePage.topNavBar.navigateToStudentsTab();

            //get all Student Details
            HashMap<String, List<String>> studentDetails = studentPage.getColumnDetailsAsList();

            SMUtils.logDescriptionTC( "SMK-12192 - Verify 'Set Target Level Per Grade' if the multiple Student is selected with different Grade" );
            SMUtils.logDescriptionTC( "SMK-12193 - Verify the Grade slide bar displayed below the Grade name in Prescriptive Scheduling page" );
            // Navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // get student from Students dropdown
            List<String> allStudentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();
            studentOptions.add( allStudentsFromUI.get( 0 ) );
            studentOptions.add( allStudentsFromUI.get( 1 ) );
            studentOptions.add( allStudentsFromUI.get( 2 ) );

            //get grades for students
            List<String> expectedGrades = reportPage.getStudentsGrade( studentDetails, studentOptions );
            reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );

            List<String> displayedGradesFromUI = reportPage.getDisplayedGradesFromUI();
            Log.message( expectedGrades.toString() + " " + displayedGradesFromUI.toString() );
            Log.assertThat( displayedGradesFromUI.containsAll( expectedGrades ), "Grade sliders displayed for selected student", "Grade sliders not displayed properly for selected student" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Saved option' dropdown should have already Saved Reports nad user able to load the report filters.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR014() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR014: Verify 'Saved option' dropdown should have already Saved Reports. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            // Enter target date
            SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
            String targetDate = dateFormat.format( new Date() );
            reportPage.setTargetDate( targetDate );

            SMUtils.logDescriptionTC( "SMK-12187 - Verify 'Saved option' drop down should have already Saved Reports." );
            // Select values in static drop down
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, Constants.Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.SORT_DROPDOWN, Constants.Reports.PSR_CURRENT_COURSE_LEVEL );
            Log.message( "Values are selected in static dropdowns" );

            // Save the report filter
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( "Choose One" );
            Log.assertThat( reportComponent.isReportOptionSaved( reportFilterName ), "Saved report is displayed in Saved Options dropdown", "Saved report is not displayed in Saved Options dropdown" );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equals( Constants.Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Constants.Reports.PSR_CURRENT_COURSE_LEVEL ), "The selected option is displayed in Sort dropdown",
                    "The selected option is not displayed in Sort dropdown" );

            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all available fields in 'Save Report Option As' Popup.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR015() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR015: Verify all available fields in 'Save Report Option As' Popup. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12207 - Verify all available fields in 'Save Report Option As' Popup." );
            // Enter target date
            SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
            String targetDate = dateFormat.format( new Date() );
            reportPage.setTargetDate( targetDate );

            // Verifying the Save Report Option is displayed and clickable
            reportComponent.clickSaveReportOption();
            Log.assertThat( reportComponent.getSaveReportPopUpTextHeader().equals( Constants.Reports.SAVEREPORT_POUP_HEADER ), "Save Report Pop up is displayed and verified the header", "Save Report Pop up is not displayed and verified the header" );

            // Verifying all available fields in Save Report Option
            Log.assertThat( reportComponent.saveReportOptionPopupHeader( Constants.Reports.NEW_HEADER_SAVEREPORT ), "New Radio button is displayed in Save Report Popup", "New Radio button is displayed in Save Report Popup" );
            Log.assertThat( reportComponent.saveReportOptionPopupHeader( Constants.Reports.REPLACE_EXISTING_HEADER ), "Replace Existing Radio button is displayed in Save Report Popup", "Replace Existing Radio button is displayed in Save Report Popup" );
            Log.assertThat( reportComponent.saveBtnOnSaveReportPopUp().equals( Constants.Reports.SAVEBTN_SAVEREPORT_OPTION ), "Save button is displayed in Save Report Popup", "Save button is not displayed in Save Report Popup" );
            Log.assertThat( reportComponent.cancelBtnOnSaveReportPopUp().equals( Constants.Reports.CANCELBTN_SAVEREPORT_OPTION ), "Cancel button is displayed in Save Report Popup", "Cancel button is not displayed in Save Report Popup" );
            reportComponent.clickcancelButtoninSaveReportPopup();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to select the one option in 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR016() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR016: Verify user can able to select the one option in 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            SMUtils.logDescriptionTC( "SMK-12212 - Verify user can able to select the one option in 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup." );
            // navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            // Enter target date
            SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
            String targetDate = dateFormat.format( new Date() );
            reportPage.setTargetDate( targetDate );

            // Select values in static drop down
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, Constants.Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENT_USERNAME );

            SMUtils.logDescriptionTC( "Verify If click the 'Replace Existing Report Options' radio button in 'Save Report Options As' Popup." );
            SMUtils.logDescriptionTC( "Verify user can able to select the one option in 'Replace Existing Report Options' drop down in 'Save Report Option As' Popup." );
            // Save the report
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( "Choose One" );
            reportComponent.loadReportOption( reportFilterName );

            reportComponent.selectValueFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, Constants.Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENTID );

            // Click Save Report Option
            reportComponent.clickSaveReportOption();
            // Click Replace Existing Report radio button
            reportComponent.clickExistingReportValue( reportFilterName );

            //load report
            reportComponent.loadReportOption( "Choose One" );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equals( Constants.Reports.STUDENTID ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Save Report Option with empty name, new name and existing name.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 2 )
    public void tcSMPSR017() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR017: Verify Save Report Option with empty name, new name and existing name. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            // Enter target date
            SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
            String targetDate = dateFormat.format( new Date() );
            reportPage.setTargetDate( targetDate );

            SMUtils.logDescriptionTC( "SMK-12209 - Verify if click the save button with empty Name in 'Save Report Options As' Popup." );
            // Verify with empty name
            reportComponent.clickSaveReportOption();
            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "Save button is disabled when name textbox is empty", "Save button is enabled when name textbox is empty" );
            Log.testCaseResult();

            // Verify with new name
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            SMUtils.logDescriptionTC( "SMK-12213 - Verify User can able to save the report option with new name." );
            Log.assertThat( reportComponent.isReportOptionSaved( reportFilterName ), "Saved report is displyed in Saved Options dropdown", "Saved report is not displyed in Saved Options dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12210 - Verify if click the save button with already existing name in 'Save Report Options As' Popup." );
            // Verify with existing name
            reportComponent.loadReportOption( "Choose One" );
            reportPage.setTargetDate( targetDate );
            reportComponent.clickSaveReportOption();
            reportComponent.setFilterName( reportFilterName );
            Log.assertThat( reportComponent.getSaveReportOptionErrorMsg().equals( Constants.Reports.EXISTING_NAME_ERROR ), "Save Report Option popup throws the error message for existing name",
                    "Save Report Option popup is not throwing the error message for existing name" );
            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "Save button is disabled when existing name entered in the textbox", "Save button is enabled when existing name entered in the textbox" );
            reportComponent.clickcancelButtoninSaveReportPopup();
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Subject dropdown in report page.", groups = { "SMK-43900", "reports", "prescriptiveSchedulingReport" }, priority = 1 )
    public void tcSMPSR018() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMPSR018: Verify the Subject dropdown in report page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            // Verifying the availability of Subject dropdown
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject dropdown is present", "Subject dropdown is not present" );

            // Verifying the options of Subject dropdown
            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.SUBJECT_DROPDOWN ), "Select All option is present in Subject dropdown", "Select All option is not present in Subject dropdown" );
            reportComponent.setDropDownMS( Constants.Reports.SUBJECT_DROPDOWN );
            Log.assertThat( reportComponent.getValuesFromDropDownMS().containsAll( Constants.Reports.SUBJECTS ), "All options are available in Subject dropdown", "Some option is missing in Subject dropdown" );

            // Verifying default selection of Subject dropdown
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "All options are selected by default in Subject dropdown", "All options are not selected by default in Subject dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in PS Report Page", groups = { "SMK-43900", "reports",
            "prescriptiveSchedulingReport" }, priority = 1 )
    public void tcSMPSR019() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMPSR019: Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in PS Report Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> subjectOption = new ArrayList<>();

            // Select Math from subject dropdown
            subjectOption.add( Constants.Reports.SUBJECTS.get( 0 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            if ( !reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Enter target date
                SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
                String targetDate = dateFormat.format( new Date() );
                reportPage.setTargetDate( targetDate );

                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String mathReportFilter = "Math Subject " + System.nanoTime();
                reportComponent.saveReportOption( mathReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( mathReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SUBJECTS.get( 0 ) ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );
            } else {
                Log.message( "No assignments available for Math subject" );
            }

            // Select Reading from subject dropdown
            subjectOption.add( Constants.Reports.SUBJECTS.get( 1 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            if ( !reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Enter target date
                SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
                String targetDate = dateFormat.format( new Date() );
                reportPage.setTargetDate( targetDate );

                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String readingReportFilter = "Reading Subject " + System.nanoTime();
                reportComponent.saveReportOption( readingReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( readingReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SUBJECTS.get( 1 ) ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );
            } else {
                Log.message( "No assignments available for Reading subject" );
            }

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of check-box in subject dropdown", groups = { "SMK-43900", "reports", "prescriptiveSchedulingReport" }, priority = 3 )
    public void tcSM_SubjectDropdownPSR001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_SubjectDropdownPSR001: Verify the functionality of check-box in subject dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Prescriptive Scheduling Page
            teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-11157 - Verify unchecking all options in Subject drop down in Prescriptive Scheduling Reports Page" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.UNCHECKED_SUBJECTS ), "Subject dropdown is unchecked in Prescriptive Scheduling Reports Page",
                    "Subject dropdown is not unchecked in Prescriptive Scheduling Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11154 - Verify Math Option is selectable in Subject drop down in Prescriptive Scheduling Reports Page" );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.MATH ) );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.MATH ), "Math option is selected in Subject dropdown in Prescriptive Scheduling Reports Page",
                    "Math option is not selected in Subject dropdown in Prescriptive Scheduling Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-111155 - Verify Reading Option is selectable in Subject drop down in Prescriptive Scheduling Reports Page" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.READING ) );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.READING ), "Reading option is selected in Subject dropdown in Prescriptive Scheduling Reports Page",
                    "Reading option is not selected in Subject dropdown in Prescriptive Scheduling Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11156 - Verify SELECT ALL Option is selectable in Subject drop down in Prescriptive Scheduling Reports Page" );
            // Uncheck all subject
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            // Select all subjects
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "Select All option is selected in Subject dropdown in Prescriptive Scheduling Reports Page", "Select All option is not selected in Subject dropdown in Prescriptive Scheduling Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11151 - Verify that Subject drop down in Subject filter in Prescriptive Scheduling Reports Page is a multiselect drop down" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Constants.Reports.SUBJECTS );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "Subject dropdown is a multi-select dropdown in Prescriptive Scheduling Reports Page", "Subject dropdown is not a multi-select dropdown in Prescriptive Scheduling Reports Page" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify subjects are displayed in subject dropdown", groups = { "SMK-43900", "reports", "prescriptiveSchedulingReport" }, priority = 3 )
    public void tcSM_SubjectDropdownPSR002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SubjectDropdownPSR002: Verify subjects are displayed in subject dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Prescriptive Scheduling Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-11164 - Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Math and Reading subject alone in Prescriptive Scheduling report page" );
            String selectedAssignments = reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            // Enter target date
            SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
            String targetDate = dateFormat.format( new Date() );
            reportPage.setTargetDate( targetDate );
            if ( !selectedAssignments.equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String allSubjectReportFilter = "All Subject " + System.nanoTime();
                reportComponent.saveReportOption( allSubjectReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( allSubjectReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "Selected subject filters are loaded Successfully", "Selected subject filters are not loaded Successfully" );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( selectedAssignments ), "Selected assignment filters are loaded Successfully",
                        "Selected assignment filters are not loaded Successfully" );
            } else {
                Log.message( "No assignments available for Math subject" );
            }
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11165 - Verify the teacher able to see All Subjects (2) while colapsing the Filters if both subjects are selected in Subjects dropdown" );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "All Subjects (2) is displayed while colapsing the filters if both subjects are selected in Subjects dropdown", "All Subjects (2) is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11166 - Verify the teacher able to see Math while colapsing the Filters if Math subject is selected in Subjects dropdown" );
            // Expanding filters
            reportComponent.expandFilterButton();
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.MATH ) );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.MATH ), "Math is displayed while colapsing the filters if both subjects are selected in Subjects dropdown",
                    "Math is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11167 - Verify the teacher able to see Reading while colapsing the Filters if Reading subject is selected in Subjects dropdown" );
            // Expanding filters
            reportComponent.expandFilterButton();
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.READING ) );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.READING ), "Reading is displayed while colapsing the filters if both subjects are selected in Subjects dropdown",
                    "Reading is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify FILTERS field should be expandable and collapse.", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 3 )
    public void tcSMPSR020() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMPSR020: Verify FILTERS field should be expandable and collapse. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12166 - Verify FILTERS field should be expandable and collapse." );
            // Collapse and Expand the Filters
            reportComponent.collapseFilterButton();

            // Verify filter count
            Log.assertThat( java.util.Objects.nonNull( reportComponent.getCountOfSelectedFilter( Reports.GROUP_DROPDOWN ) ), "Filter collapsed Sucessfully", "Filters not collapsed properly." );

            SMUtils.logDescriptionTC( "SMK-12167 - Verify fields are available, After click the Filters option." );
            reportComponent.expandFilterButton();

            // Verify Select Groups or Students heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.GROUP_OR_STUDENT_HEADER ), "Select Groups or Students heading is present in the CPR Page",
                    "Select Groups or Students heading is not present in the CPR Page" );

            // Verify group dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.GROUP_DROPDOWN ), "Group dropdown is present in the CPR Page", "Group dropdown is not present in the CPR Page" );

            // Verify student dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.STUDENTS_DROPDOWN ), "Student dropdown is present in the CPR Page", "Students dropdown is not present in the CPR Page" );

            // Verify Refine search heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.REFINE_SEARCH ), "Refine search heading is present in the CPR Page", "Refine search heading is present in the CPR Page" );

            // Verify subject dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject dropdown is present in the CPR Page", "Subjects dropdown is not present in the CPR Page" );

            // Verify assignment dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "Assignments dropdown is present in the CPR Page", "Assignments dropdown is not present in the CPR Page" );

            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Groups and Students radio button Inside the FILTERS", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 3 )
    public void tcSMPSR021() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR021: Verify Groups and Students radio button Inside the FILTERS <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12168 - Verify Groups and Students radio button Inside the FILTERS" );
            Log.assertThat( reportComponent.isGroupAndStudentRadioButtonDisplayed(), "Group and student radio button are present", "Group and student radio button are not present" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12169 - Verify SELECT ALL option in Groups and Students drop down." );
            Log.assertThat( reportComponent.verifySelectALLCheckBox( Reports.GROUP_DROPDOWN ), "Select All option is present in Group dropdown", "Select All option is not present in Group dropdown" );
            Log.assertThat( reportComponent.verifySelectALLCheckBox( Reports.STUDENTS_DROPDOWN ), "Select All option is present in Student dropdown", "Select All option is not present in Student dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12182 - Verify SELECT ALL option in Assignments drop down." );
            Log.assertThat( reportComponent.verifySelectALLCheckBox( Reports.ASSIGNMENTS_DROPDOWN ), "Select all option displayed properly in Assignments Dropdown", "Select all option not displayed properly in Assignments Dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12188 - Verify 'Target Date' field in Prescriptive Scheduling Page" );
            //Verify Target Date Field
            Log.assertThat( reportPage.isTargetDateFieldDisplayed(), "Target date is present in the PSR page", "Target date is not present in the PSR Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12197 - Verify the Grade slide bar of multiple students with same Grade in Prescriptive Scheduling page" );

            List<String> grade1StudentList = new ArrayList<>();
            IntStream.rangeClosed( 1, DataSetupConstants.STUDENT_COUNT ).forEach( studentCount -> {
                String studentDetail = ( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ) );
                if ( SMUtils.getKeyValueFromResponse( studentDetail, "data,grade" ).equalsIgnoreCase( "FIRST" ) ) {
                    grade1StudentList.add(
                            SMUtils.getKeyValueFromResponse( studentDetail, "data,firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "data,middleName" ) + ". " + SMUtils.getKeyValueFromResponse( studentDetail, "data,lastName" ) );
                }
            } );

            reportComponent.clickSelectALLFromMSDropdown( Reports.STUDENTS_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Reports.STUDENTS_DROPDOWN, grade1StudentList );
            Log.assertThat( reportPage.getDisplayedGradesFromUI().equals( Arrays.asList( Students.GRADE1 ) ), "Grade slider bar displayed one time if selecting multiple students with same Grade",
                    "Grade slider bar is not  displayed one time if selecting multiple students with same Grade" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12199 - Verify user can able to select one option from 'Additional grouping' drop down on Prescriptive Scheduling page." );
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.PSR_ADDITION_GROUPING.get( 0 ) );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equalsIgnoreCase( Reports.PSR_ADDITION_GROUPING.get( 0 ) ), "user able to select one option from 'Additional grouping' drop down",
                    "user unable to select one option from 'Additional grouping' drop down" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12201 - Verify user can able to select one option from 'Display' drop down on Prescriptive Scheduling page." );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.DISPLAY.get( 0 ) );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equalsIgnoreCase( Reports.DISPLAY.get( 0 ) ), "user able to select one option from 'Display' drop down",
                    "user unable to select one option from 'Display' drop down" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12203 - Verify user can able to select one option from 'sort' drop down on Prescriptive Scheduling page." );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.PSR_SORT.get( 0 ) );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equalsIgnoreCase( Reports.PSR_SORT.get( 0 ) ), "user able to select one option from 'Sort' drop down",
                    "user unable to select one option from 'Sort' drop down" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12204 - Verify 'Remove Page Breaks' checkbox on Prescriptive Scheduling page." );
            // Verify Remove page break field
            Log.assertThat( reportComponent.isMaskStudentDisplayAndRemovePageBreakFieldDisplayed( Constants.Reports.MASK_STUDENT_DISPLAY ), "Remove page break field is present in the PSR page", "Remove page break field is not present in the PSR page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12205 - Verify 'Mask Student Display' checkbox on Prescriptive Scheduling page." );
            // Verify Mask student display field
            Log.assertThat( reportComponent.isMaskStudentDisplayAndRemovePageBreakFieldDisplayed( Constants.Reports.REMOVE_PAGE_BREAKS ), "Mask student display is present in the PSR page", "Mask student display field is not present in the PSR page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12206 - Verify 'Save Report Option' link on Prescriptive Scheduling page." );
            // Verify Save Report Option button
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getSaveReportOptionButton() ), "Saved Report option button is present", "Saved Report option button is not present!" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if teacher don't have any students, Group or Assignments, Verify zero State message", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 3 )
    public void tcSMPSR022() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR022: Verify if teacher don't have any students, Group or Assignments, Verify zero State message <small><b><i>[" + browser + "]</b></i></small>" );
        String teacherUsername = "AutomatedTeacher_ForZeroStateTest" + System.nanoTime();
        //Creating teacher for Zero state test.
        new UserSqlHelper().createTeacher( teacherUsername, teacherUsername, teacherUsername, Constants.PASSWORD_HASH, DataSetup.organizationId );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12178 - Verify if teacher don't have any students, Then what should be Prescriptive Scheduling Report Page." );
            Log.assertThat( reportComponent.isZeroStateMessageDisplayed(), "Zero state message is displaying", "Zero state message is not displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12169 - Verify SELECT ALL option in Groups and Students drop down." );
            // Navigate to Mastery Tab
            StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
            String studentID = studentsPage.createStudent();
            // Navigate to PSR Page
            reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            Log.assertThat( reportComponent.getZeroStateTextGroups().equalsIgnoreCase( Constants.Reports.ZERO_STATE_TEXT_GRP ), "Zero state message is displaying for group", "Zero state message is not displaying" );
            Log.assertThat( reportComponent.getZeroStateTextAssignments().equalsIgnoreCase( Constants.Reports.ZERO_STATE_TEXT_ASSIGNMENTS ), "Zero state message is displaying for assignments", "Zero state message is not displaying" );

            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Groups/Students name should display in Alphabetical order under Groups/Students drop down", groups = { "SMK-43784", "reports", "prescriptiveSchedulingReport" }, priority = 3 )
    public void tcSMPSR023() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMPSR023: Verify the Groups/Students name should display in Alphabetical order under Groups/Students drop down <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Getting the groups names from the UI
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsList = groupsTab.getGroupListNames();
            Collections.sort( groupsList );

            //getting assignemnts from assignments tab
            AssignmentsPage assignmentpage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> assignmentsList = assignmentpage.assignmentsList();
            Collections.sort( assignmentsList );

            // getting the Student names from data setup
            List<String> studentFirstNameAndLastNameList = new ArrayList<>();
            IntStream.rangeClosed( 1, DataSetupConstants.STUDENT_COUNT ).forEach( studentCount -> {
                String studentDetail = ( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ) );
                studentFirstNameAndLastNameList.add(
                        SMUtils.getKeyValueFromResponse( studentDetail, "data,firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetail, "data,middleName" ) + ". " + SMUtils.getKeyValueFromResponse( studentDetail, "data,lastName" ) );
            } );
            Collections.sort( studentFirstNameAndLastNameList, (Comparator<String>) ( String name1, String name2 ) -> name1.split( " " )[name1.split( " " ).length - 1].compareToIgnoreCase( name2.split( " " )[name1.split( " " ).length - 1] ) );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to PSR Page
            PSRPage reportPage = teacherHomePage.topNavBar.navigateToPrescriptiveSchedulingReportPage();

            SMUtils.logDescriptionTC( "SMK-12180 - Verify the Groups/Students name should display in Alphabetical order under Groups/Students drop down" );
            reportComponent.setDropDownMS( Reports.GROUP_DROPDOWN );
            Log.assertThat( reportComponent.getValuesFromDropDownMS().equals( groupsList ), "Group names displayed in alphabetical order", "Group names not displayed in alphabetical order" );
            reportComponent.setDropDownMS( Reports.STUDENTS_DROPDOWN );
            Log.assertThat( reportComponent.getValuesFromDropDownMS().equals( studentFirstNameAndLastNameList ), "Student names displayed in alphabetical order", "Students names not displayed in alphabetical order" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12181 - Verify the Assignments name should display in Alphabetical order under Assignments drop down" );
            reportComponent.setDropDownMS( Reports.ASSIGNMENTS_DROPDOWN );
            Log.assertThat( reportComponent.getValuesFromDropDownMS().equals( assignmentsList ), "Assignments displayed in alphabetical order", "Assignments not displayed in alphabetical order" );
            Log.testCaseResult();

            // Enter target date
            SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yy" );
            String targetDate = dateFormat.format( new Date() );
            reportPage.setTargetDate( targetDate );

            SMUtils.logDescriptionTC( "SMK-12214 - Verify the 'Run Report' button in Prescriptive Scheduling page" );
            // Verify Run Report
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getRunReportOption() ), "Run report button present!", "Run report not button present!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-12208 - Verify the help icon in 'Save Report Options As' Popup" );

            //Click save report button
            reportComponent.clickSaveReportOption();
            reportComponent.clickHelpInSaveReportOptionPopup();

            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();
            Log.assertThat( reportComponent.getHelpContentHeader().equalsIgnoreCase( Reports.SAVE_REPORT_OPTION ), "help icon is navigated to respective help page", "help icon is not navigated to respective help page" );
            Log.testCaseResult();

            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                teacherHomePage = new TeacherHomePage( driver );
                teacherHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

}