package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class SchoolMotionLog extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String districtId;
    private String teacherId;
    private String assignmentID;
    private String AssignmentUserId;
    private String CourseId;
    RBSUtils rbsutils = new RBSUtils();
    Map<String, String> assignmentResponse = new HashMap<>();
    private String studentDetail;
    private String studentUserID;
    String studentID = null;
    GroupAPI add = new GroupAPI();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        districtId = configProperty.getProperty( "district_ID" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( priority = 1, dataProvider = "SchoolMotionLogPositiveFlow", groups = { "SMK-57273", "smoke_test_case", "SchoolMotionLogAPI", "SchoolMotionLogAPI", "P1", "API" } )
    public void tcPostiveforSchoolMotion( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AssignmentAPIConstants.SCHOOL_ADMIN_ID, new RBSUtils().getUserIDByUserName( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ) ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );

        String endpoint = AssignmentAPIConstants.SCHOOL_MOTION + districtId;
        String reqParam = "null";

        switch ( scenario ) {

            case "Valid Org Id - Turn On":
                String MotionTurnOn = "Yes";
                assignmentDetails.put( AssignmentAPIConstants.CAPTURE_RESEARCH_DATA, MotionTurnOn );
                break;

            case "Valid Org Id - Turn Of":
                String MotionTurnOf = "No";
                assignmentDetails.put( AssignmentAPIConstants.CAPTURE_RESEARCH_DATA, MotionTurnOf );
                break;

            default:
                Log.message( "Case is invalid" );
                break;
        }

        HashMap<String, String> response = schoolMotion( smUrl, assignmentDetails, endpoint, reqParam );
        Log.message( "Response: " + response.get( "body" ) );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + response.get( "body" ) );

    }

    @Test ( priority = 2, dataProvider = "SchoolMotionLogNegativeFlow", groups = { "SMK-57273", "SchoolMotionLogAPI", "SchoolMotionLogAPI", "P1", "API" } )
    public void tcNegativeforSchoolMotion( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );
        HashMap<String, String> assignmentDetails = new HashMap<>();

        String endpoint = "null";
        String exception = null;
        boolean status = false;
        String message = null;
        String reqParam = "null";

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        assignmentDetails.put( AssignmentAPIConstants.SCHOOL_ADMIN_ID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, districtId );

        switch ( scenario ) {

            case "Invalid Authorization":
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                String MotionTurnOf = "No";
                assignmentDetails.put( AssignmentAPIConstants.CAPTURE_RESEARCH_DATA, MotionTurnOf );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "Invalid Authentication":
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( "hpteacher5", "testing123$" ) );
                MotionTurnOf = "No";
                assignmentDetails.put( AssignmentAPIConstants.CAPTURE_RESEARCH_DATA, MotionTurnOf );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "Invalid org-id":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, "ABC" );
                MotionTurnOf = "No";
                assignmentDetails.put( AssignmentAPIConstants.CAPTURE_RESEARCH_DATA, MotionTurnOf );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                break;

            case "Invalid UserId":
                assignmentDetails.put( AssignmentAPIConstants.SCHOOL_ADMIN_ID, "1234" );
                MotionTurnOf = "No";
                assignmentDetails.put( AssignmentAPIConstants.CAPTURE_RESEARCH_DATA, MotionTurnOf );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            case "Invalid Payload":
                MotionTurnOf = "abc";
                assignmentDetails.put( AssignmentAPIConstants.CAPTURE_RESEARCH_DATA, MotionTurnOf );
                break;

            case "Empty org id":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, " " );
                MotionTurnOf = "No";
                assignmentDetails.put( AssignmentAPIConstants.CAPTURE_RESEARCH_DATA, MotionTurnOf );
                status = true;
                break;
            case "Invalid Req org id":
                reqParam = "Abc";
                MotionTurnOf = "No";
                assignmentDetails.put( AssignmentAPIConstants.CAPTURE_RESEARCH_DATA, MotionTurnOf );
                status = true;
                break;

            default:
                Log.message( "Case is invalid" );
                break;
        }

        HashMap<String, String> response = schoolMotion( smUrl, assignmentDetails, endpoint, reqParam );
        Log.message( "Response: " + response.get( "body" ) );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        Log.message( "Response: " + response.get( "body" ) );

        if ( message != null ) {
            verifyException( response.get( "body" ), exception, status, message );
        }
        Log.testCaseResult();

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "SchoolMotionLogPositiveFlow" )
    public Object[][] schoolMotionLogPositiveFlow() {

        Object[][] inputData = { { "Validate 200 for Motion Turn On", "Valid Org Id - Turn On", CommonAPIConstants.STATUS_CODE_OK }, { "Validate 200 for Motion Turn Off", "Valid Org Id - Turn Of", CommonAPIConstants.STATUS_CODE_OK }, };
        return inputData;
    }

    /**
     * Data provider for negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "SchoolMotionLogNegativeFlow" )
    public Object[][] schoolMotionLogNegativeFlow() {

        Object[][] inputData = { { "Verify the status code is 401 -Invalid Authorization ", "Invalid Authorization", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code is 401 - Invalid Authentication ", "Invalid Authentication", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify the status code is 403 -Invalid org-id ", "Invalid org-id", CommonAPIConstants.STATUS_CODE_FORBIDDAN }, { "Verify the status code is 401 -Invalid UserId ", "Invalid UserId", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify that the status code is 500 -Invalid Payload", "Invalid Payload", CommonAPIConstants.STATUS_CODE_INTERNAL_ERROR }, { "Verify that the status code is 403 -Empty org id", "Empty org id", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify that the status code is 200 -Invalid Para org id", "Invalid Req org id", CommonAPIConstants.STATUS_CODE_OK },

        };
        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

}