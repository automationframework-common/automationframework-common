package com.savvas.sm.ui.tests.mastery.smnew.SmokeTests;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.ui.constants.LoginConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.teacher.ui.pages.MasteryReportOutputPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryDetailsPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.mastery.pages.MasteryMfePage;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperMastery;
import com.savvas.sm.utils.sql.helper.StandardVersionTable.StandardVersionMastery;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;


public class MasteryMfeTeacherSmokeTest extends BaseTest {

    private String masteryMFE;
    private String browser;
    private String username;
    private String smUrl;
    private String password=RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String MASTERY_HEADER = "Mastery";
    List<String> MASTERYREPORT_ASSIGNMENTDETAILS_LABELS = new ArrayList<>( Arrays.asList( "Assigned course level:", "Current course level:", "IP level:", "Time spent:", "Total sessions:", "Average session time:" ) );
     
    @BeforeClass
    public void beforeTest() {
         username = MasteryDataSetup.teacherUserName;
          masteryMFE = configProperty.getProperty( "MasteryTeacherMfe" );
         browser = configProperty.getProperty( "BrowserPlatformToRun" );
         smUrl = configProperty.getProperty( "SMAppUrl" );

    }

    @Test ( description ="Verify Mastery Report for Math subject as a Teacher",groups = { "smoke_te=st_case", "Teacher Mastery", "Teacher_157","P1" } )
    public void tcSMTeacherMasterySmoke001( ITestContext context ) throws Exception {
        // Get driver
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        Log.testCaseInfo( "tcSMTeacherMasterySmoke001: Verify Mastery Report for Math subject as a Teacher <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_MATH);

            MasterySummaryComponent masterySummaryComponent= masteryFiltersComponent.applyFilter();

            MasteryReportOutputPage masteryReport = masterySummaryComponent.clickMasteryRunReportBtn();
            
            Log.assertThat(masteryReport.isMasteryReportPageLoaded(), "Mastery Report Page is loaded Successfully", "Mastery Report Page is not loaded Successfully!!");
            Log.testCaseResult(); 
            
            SMUtils.logDescriptionTC("Tc:05 Verify the header of the  Mastery Run Report contains Mastery in bold letters in the top left of the page");
            Log.assertThat(masteryReport.getMasteryHeader().equals(MASTERY_HEADER),"The mastery header is displayed in bold letters","The mastery header is not displayed in bold letters");
            Log.testCaseResult();
            
              
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }
    @Test ( description ="Verify Mastery Report for Reading subject as a Teacher",groups = { "smoke_te=st_case", "Teacher Mastery", "Teacher_158","P1" } )
    public void tcSMTeacherMasterySmoke002( ITestContext context ) throws Exception {
        // Get driver
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        Log.testCaseInfo( "tcSMTeacherMasterySmoke002: Verify Mastery Report for Reading subject as a Teacher <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);

            MasterySummaryComponent masterySummaryComponent= masteryFiltersComponent.applyFilter();

            MasteryReportOutputPage masteryReport = masterySummaryComponent.clickMasteryRunReportBtn();
            
            Log.assertThat(masteryReport.isMasteryReportPageLoaded(), "Mastery Report Page is loaded Successfully", "Mastery Report Page is not loaded Successfully!!");
            Log.testCaseResult();
           
            SMUtils.logDescriptionTC("Tc:05 Verify the header of the  Mastery Run Report contains Mastery in bold letters in the top left of the page");
            Log.assertThat(masteryReport.getMasteryHeader().equals(MASTERY_HEADER),"The mastery header is displayed in bold letters","The mastery header is not displayed in bold letters");
            Log.testCaseResult();
            
              
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
           
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Mastery LO View Page",groups = { "smoke_te=st_case", "Teacher Mastery", "Teacher_83","P1" } )

public void tcSMTeacherMasterySmoke003( ITestContext context ) throws Exception {
    // Get driver
    WebDriverManager.chromedriver().setup();
    WebDriver driver = new ChromeDriver();
    Log.testCaseInfo( "tcSMTeacherMasterySmoke003:Verify Mastery Report Page <small><b><i>[" + browser + "]</b></i></small>" );
    try {
        LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
        TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
        // Navigate to Mastery Tab
        MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
        MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();

        masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);

         MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
         List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );
         MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masteredProgressBars.get( 0 ) );
         SMUtils.logDescriptionTC(  "Verify the student name(first name, last name), Mastery Status, Skills Evaluated, Attemps fields in the Mastery details page" );
         Log.assertThat( Constants.MasteryUI.masteryTableHeaders.equals( masteryDetailsPage.getStudentTableHeaders() ), "The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are available in the mastery header",
            "The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are not available in the mastery header" );
          Log.testCaseResult();
        
        
    } catch ( Exception e ) {
        Log.exception( e, driver );
    } finally {
        
        
        Log.endTestCase();
        driver.quit();
    }
}
    @Test ( description = "Mastery -->Run Mastery Report as a teacher",groups = { "smoke_te=st_case", "Teacher Mastery", "Teacher_47","P1" } )

    public void tcSMTeacherMasterySmoke004( ITestContext context ) throws Exception {
        // Get driver
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        Log.testCaseInfo( "tcSMTeacherMasterySmoke004:Mastery -->Run Mastery Report as a teacher\"<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.selectSubject(Constants.MasteryUI.SUBJECT_READING);
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.STANDARD_ALASKAENGLISH_READING );

            MasterySummaryComponent masterySummaryComponent= masteryFiltersComponent.applyFilter();

            MasteryReportOutputPage masteryReport = masterySummaryComponent.clickMasteryRunReportBtn();
            
            Log.assertThat(masteryReport.isMasteryReportPageLoaded(), "Mastery Report Page is loaded Successfully", "Mastery Report Page is not loaded Successfully!!");
            Log.testCaseResult();
            
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

}


