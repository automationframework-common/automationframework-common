package com.savvas.sm.teacher.ui.tests.MasterySuite;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryDetailsPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.MasterySummaryComponent;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class MasteryLOViewTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String studentUsername1 = null;
    private String studentUsername2 = null;
    private String studentUsername3 = null;
    private String studentUsername4 = null;
    private String studentUsername5 = null;
    private String studentUsername6 = null;
    private String Math_Assignment;
    String chromePlatform = "Windows_10_Chrome_latest";
    BaseAPITest baseApiObject = new BaseAPITest();
    UserSqlHelper userSqlHelper = new UserSqlHelper();
    String teacherId;
    String orgId;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher67" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        password = DataSetupConstants.DEFAULT_PASSWORD;
        studentUsername1 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,userName" );
        studentUsername2 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student2" ), "data,userName" );
        studentUsername3 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student3" ), "data,userName" );
        studentUsername4 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student4" ), "data,userName" );
        studentUsername5 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student5" ), "data,userName" );
        studentUsername6 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student6" ), "data,userName" );
        teacherId = userSqlHelper.getPersonID( username );
        orgId = userSqlHelper.getOrgId( teacherId );
    }

    @Test ( priority = 1, description = "DataSetup - Mastery LO View page" )
    public void tcMasteryDataSetup( ITestContext context ) throws Exception {
        String sessionCookie = baseApiObject.getJessionCookie( smUrl, username, password );
        Math_Assignment = "MathSingleLOCourse1__" + System.nanoTime();
        String Math_Assignment2 = "MathSingleLOCourse2__" + System.nanoTime();
        String Math_Assignment3 = "MathSingleLOCourse3__" + System.nanoTime();
        String Reading_Assignment1 = "ReadCourse__" + System.nanoTime();
        String course = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.ONE_LO, Math_Assignment );
        String course2 = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.ONE_LO, Math_Assignment2 );
        String course3 = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, Reading_Assignment1 );
        String course4 = baseApiObject.createCourse( smUrl, sessionCookie, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.ONE_LO, Math_Assignment3 );

        // Get driver
        //WebDriver driver = null;

        // Get driver
        EventFiringWebDriver chromeDriver = new EventFiringWebDriver( WebDriverFactory.get( chromePlatform ) );
        EventListener eventListner = new EventListener();
        chromeDriver.register( eventListner );
        Log.testCaseInfo( "Test Data generation for Mastery Details LO View Page." + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // login to the app
            LoginPage smLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            context.setAttribute( "Math_Assignment", Math_Assignment );
            context.setAttribute( "Math_Assignment2", Math_Assignment2 );
            context.setAttribute( "Math_Assignment3", Math_Assignment3 );

            // Assigning Math Courses to Students
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Math_Assignment );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Assigning Math second Courses to Students
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Math_Assignment2 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Assigning Math second Courses to Students
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Math_Assignment3 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // Assigning Reading Courses to Students
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Reading_Assignment1 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            chromeDriver.quit();

            Log.message( "Executing the courses using simulator" );

            //Login as student1 to the executeCourses
            Log.message( "Executing the courses using simulator for student1" );
            chromeDriver = new EventFiringWebDriver( WebDriverFactory.get( chromePlatform ) );
            eventListner = new EventListener();
            chromeDriver.register( eventListner );
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername1, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "100", "1", "20" );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment3, "100", "1", "20" );
            studentsPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Reading_Assignment1, "15", "1", "10" );
            studentsPage.logout();
            chromeDriver.quit();

            //Login as student2 to the executeCourses
            Log.message( "Executing the courses using simulator for student2" );
            chromeDriver = new EventFiringWebDriver( WebDriverFactory.get( chromePlatform ) );
            eventListner = new EventListener();
            chromeDriver.register( eventListner );
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername2, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment3, "60", "2", "20" );
            studentsPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Reading_Assignment1, "40", "1", "10" );
            studentsPage.logout();
            chromeDriver.quit();

            //Login as student3 to the executeCourses
            Log.message( "Executing the courses using simulator for student3" );
            chromeDriver = new EventFiringWebDriver( WebDriverFactory.get( chromePlatform ) );
            eventListner = new EventListener();
            chromeDriver.register( eventListner );
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername3, password, true );
            studentsPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Reading_Assignment1, "25", "1", "10" );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "95", "2", "20" );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment3, "10", "6", "20" );
            studentsPage.logout();
            chromeDriver.quit();

            //Login as student4 to the executeCourses
            Log.message( "Executing the courses using simulator for student4" );
            chromeDriver = new EventFiringWebDriver( WebDriverFactory.get( chromePlatform ) );
            eventListner = new EventListener();
            chromeDriver.register( eventListner );
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername4, password, true );
            studentsPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Reading_Assignment1, "15", "1", "10" );
            studentsPage.logout();
            chromeDriver.quit();

            //Login as student5 to the executeCourses
            Log.message( "Executing the courses using simulator for student5" );
            chromeDriver = new EventFiringWebDriver( WebDriverFactory.get( chromePlatform ) );
            eventListner = new EventListener();
            chromeDriver.register( eventListner );
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername5, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "100", "2", "20" );
            studentsPage.logout();
            chromeDriver.quit();

            //Login as student6 to the executeCourses
            Log.message( "Executing the courses using simulator for student6" );
            chromeDriver = new EventFiringWebDriver( WebDriverFactory.get( chromePlatform ) );
            eventListner = new EventListener();
            chromeDriver.register( eventListner );
            smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            studentsPage = smStudentLoginPage.loginToSMasStudent( studentUsername6, password, true );
            studentsPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), Math_Assignment, "100", "1", "20" );
            studentsPage.logout();
            chromeDriver.quit();

        } catch ( Exception e ) {
            Log.exception( e, chromeDriver );
        }

        finally {

            Log.endTestCase();
            chromeDriver.quit();
        }
    }

    @Test ( description = "Mastery - LO View - Integration - Verify LO Link for Math/Reading", priority = 2 )
    public void verifyLearningObjectName( ITestContext context ) throws Exception {
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-39465 - LO View Page - Verify LO Link for Math/Reading <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();

            SMUtils.logDescriptionTC( "SMK-5914 : Verify the teacher is able to see the LO as a blue link, when Math subject is chosen with skills" );
            Log.assertThat( masteryDetailsPage.getLOColor( browser ).contentEquals( Constants.MasteryUI.LO_ID_COLOR_CODE ), "Teacher is able to see the LO as a blue link",
                    "Teacher is not able to see the LO as a blue link, when Math subject is chosen with skills" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5915 & SMK-5916 : Verify the teacher can able to see the SCO content belongs to the LO, when Math subject is chosen with skills" );
            Log.assertThat( masteryDetailsPage.clickLearningObjectLink().equalsIgnoreCase( masteryDetailsPage.learningObjectID.getText() ), "The teacher can able to see the SCO content belongs to the LO, when Math subject is chosen with skills",
                    "The teacher is not able to see the SCO content belongs to the LO, when Math subject is chosen with skills" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5917 : Verify the teacher is not able to see the LO name, when Math subject is chosen with standards" );
            masteryDetailsPage.clickChevronIcon();
            masteryFiltersComponent.expandToggle();
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.STANDARD_AIMSWEBPLUS_MATH );
            MasterySummaryComponent masterySummaryComponent1 = masteryFiltersComponent.applyFilter();
            MasteryDetailsPage masteryDetailsPage1 = masterySummaryComponent1.clickLOLink();
            SMUtils.waitForElement( driver, masteryDetailsPage1.learningObjectID );
            Log.assertThat( masteryDetailsPage1.learningObjectID.getText().equals( "" ), "The LO Link is not visible when Math subject is chosen with standards", "The LO Link is visible when Math subject is chosen with standards" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5917 : Verify the teacher is not able to see the LO name, when Math subject is chosen with standards" );
            masteryDetailsPage.clickChevronIcon();
            masteryFiltersComponent.expandToggle();
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.STANDARD_AIMSWEBPLUS_MATH );
            MasterySummaryComponent masterySummaryComponent2 = masteryFiltersComponent.applyFilter();
            MasteryDetailsPage masteryDetailsPage2 = masterySummaryComponent2.clickLOLink();
            SMUtils.waitForElement( driver, masteryDetailsPage2.learningObjectID );
            Log.assertThat( masteryDetailsPage2.learningObjectID.getText().equals( "" ), "The LO Link is not visible when Math subject is chosen with standards", "The LO Link is visible when Math subject is chosen with standards" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5918 : Verify the teacher is not able to see the LO name, when Reading subject is chosen with skills" );
            masteryDetailsPage.clickChevronIcon();
            masteryFiltersComponent.expandToggle();
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );
            MasterySummaryComponent masterySummaryComponent3 = masteryFiltersComponent.applyFilter();
            MasteryDetailsPage masteryDetailsPage3 = masterySummaryComponent3.clickLOLink();
            Log.assertThat( !masteryDetailsPage3.verifyLearningObjectLinkIsDisplayed(), "The LO Link is not visible when Reading subject is chosen with skills", "The LO Link is visible when Reading subject is chosen with skills" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5918 : Verify the teacher is not able to see the LO name, when Reading subject is chosen with skills" );
            masteryDetailsPage.clickChevronIcon();
            masteryFiltersComponent.expandToggle();
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.STANDARD_ALASKAENGLISH_READING );
            MasterySummaryComponent masterySummaryComponent4 = masteryFiltersComponent.applyFilter();
            MasteryDetailsPage masteryDetailsPage4 = masterySummaryComponent4.clickLOLink();
            Log.assertThat( !masteryDetailsPage4.verifyLearningObjectLinkIsDisplayed(), "The LO Link is not visible when Reading subject is chosen with standards", "The LO Link is visible when Reading subject is chosen with standards" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Mastery - LO View - Integration - Verify mastery average", priority = 3 )
    public void verifyMasteryAverage( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-39465 - LO View Page - Verify Mastery Average <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.clickLOLink();
            SMUtils.logDescriptionTC( "SMK-5920 : Verify the teacher is able to see the mastery average for the skills, when math is selected" );
            Log.assertThat( Integer.parseInt( masteryDetailsPage.getStudentCounts().replaceAll( "[^\\d]", "" ) ) >= 1, "The teacher is able to see the mastery average for the skills, when math is selected",
                    "The teacher is not able to see the mastery average for the skills, when math is selected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5921 : Verify the teacher is able to see the mastery average for the standards, when math is selected" );
            masteryDetailsPage.clickChevronIcon();
            masteryFiltersComponent.expandToggle();
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.STANDARD_AIMSWEBPLUS_MATH );
            MasterySummaryComponent masterySummaryComponent1 = masteryFiltersComponent.applyFilter();
            MasteryDetailsPage masteryDetailsPage1 = masterySummaryComponent1.clickLOLink();
            Log.assertThat( Integer.parseInt( masteryDetailsPage1.getStudentCounts().replaceAll( "[^\\d]", "" ) ) >= 1, "The teacher is able to see the mastery average for the standards, when math  is selected",
                    "The teacher is not able to see the mastery average for the standards, when math is selected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5922 : Verify the teacher is able to see the mastery average for the skills, when reading is selected" );
            masteryDetailsPage.clickChevronIcon();
            masteryFiltersComponent.expandToggle();
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );
            MasterySummaryComponent masterySummaryComponent2 = masteryFiltersComponent.applyFilter();
            MasteryDetailsPage masteryDetailsPage2 = masterySummaryComponent2.clickLOLink();
            Log.assertThat( Integer.parseInt( masteryDetailsPage2.getStudentCounts().replaceAll( "[^\\d]", "" ) ) >= 1, "The teacher is able to see the mastery average for the skills, when reading is selected",
                    "The teacher is not able to see the mastery average for the skills, when reading is selected" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5923 : Verify the teacher is able to see the mastery average for the standards, when reading is selected" );
            masteryDetailsPage.clickChevronIcon();
            masteryFiltersComponent.expandToggle();
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_READING );
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.STANDARD_ALASKAENGLISH_READING );
            MasterySummaryComponent masterySummaryComponent3 = masteryFiltersComponent.applyFilter();
            MasteryDetailsPage masteryDetailsPage3 = masterySummaryComponent3.clickLOLink();
            Log.assertThat( Integer.parseInt( masteryDetailsPage3.getStudentCounts().replaceAll( "[^\\d]", "" ) ) >= 1, "The teacher is able to see the mastery average for the standards, when reading is selected",
                    "The teacher is not able to see the mastery average for the standards, when reading is selected" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Mastery - LO View Page - Verify Mastery Default Sorting", priority = 4 )
    public void verifyMasteryDefaultSorting( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-39465 - LO View Page - Verify Mastery Default Sorting <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
            List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masteredProgressBars.get( 0 ) );
            SMUtils.logDescriptionTC( "SMK-5929 : Verify the student name(first name, last name), Mastery Status, Skills Evaluated, Attemps fields in the Mastery details page" );
            Log.assertThat( Constants.MasteryUI.masteryTableHeaders.equals( masteryDetailsPage.getStudentTableHeaders() ), "The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are available in the mastery header",
                    "The 'Student', 'Mastery Status', 'Skills Evaluated', 'Attempts' are not available in the mastery header" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "SMK-5932 : Verify the student name fields are sorted in ascending by default in the Mastery details page" );
            masteryDetailsPage.clickBackBtn();
            masteryFiltersComponent.expandToggle();
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent1 = masteryFiltersComponent.applyFilter();
            List<WebElement> masteredProgressBars1 = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage1 = masterySummaryComponent.navigateToLoViewPage( masteredProgressBars1.get( 0 ) );
            SMUtils.waitForElement( driver, masteryDetailsPage1.getStatusBadge() );
            List<String> studentsName = masteryDetailsPage1.getStudentName( Math_Assignment );
            Log.assertThat( studentsName.equals( SMUtils.sortList( studentsName ) ), "The student name fields are sorted in ascending by default in the Mastery details page",
                    "The student name fields are not sorted in ascending by default in the Mastery details page" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "SMK-5933 : Verify the teacher is able to sort the 'student name' field in descending order in the Mastery details page" );
            SMUtils.clickJS( driver, masteryDetailsPage.getWebElementForDetailsPageHeaders( Constants.MasteryUI.STUDENT_FIELD ) );
            SMUtils.waitForElement( driver, masteryDetailsPage1.getStatusBadge() );
            List<String> studentDescending = masteryDetailsPage.getStudentName( Math_Assignment );
            Log.assertThat( studentDescending.equals( SMUtils.sortAndReverseList( studentsName ) ), "The student name fields are sorted in ascending by default in the Mastery details page",
                    "The student name fields are not sorted in ascending by default in the Mastery details page" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "SMK-5933 : Verify the teacher is able to sort the 'Attempts field' in ascending order in the Mastery details page" );
            SMUtils.clickJS( driver, masteryDetailsPage.getWebElementForDetailsPageHeaders( Constants.MasteryUI.ATTEMPTS_FIELD ) );
            SMUtils.waitForElement( driver, masteryDetailsPage1.getStatusBadge() );
            List<String> attemptsFieldAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.ATTEMPTS_FIELD );
            Log.assertThat( attemptsFieldAsc.equals( SMUtils.sortList( attemptsFieldAsc ) ), "The " + Constants.MasteryUI.ATTEMPTS_FIELD + " fields are sorted in ascending in the Mastery details page",
                    "The " + Constants.MasteryUI.ATTEMPTS_FIELD + " fields are not sorted in ascending in the Mastery details page" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "SMK-5942 : Verify the teacher is able to navigate back to the Mastery view page when they click on the breadcrumb icon in the top of the Mastery detail page" );
            masteryDetailsPage.clickBackBtn();
            MasteryPage masteryPage1 = new MasteryPage( driver );
            Log.assertThat( masteryPage1.lblMasteryHeading.isDisplayed(), "The teacher is able to navigate back to the Mastery view page when they click on the breadcrumb icon in the top of the Mastery detail page",
                    "The teacher is not able to navigate back to the Mastery view page when they click on the breadcrumb icon in the top of the Mastery detail page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Mastery - LO View Page - Verify Mastery Sorting", priority = 5 )
    public void verifyMasterySorting( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "SMK-39465 - LO View Page - Verify Mastery Sorting <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.STUDENTS );
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();
            List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );
            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            SMUtils.logDescriptionTC( "SMK-5936 : Verify the teacher is able to sort the 'Mastery Status' field in ascending order in the Mastery details page" );
            List<String> masteryStsBfrSortingAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.MASTERY_STATUS_FIELD );
            SMUtils.clickJS( driver, masteryDetailsPage.getWebElementForDetailsPageHeaders( Constants.MasteryUI.MASTERY_STATUS_FIELD ) );
            SMUtils.waitForElement( driver, masteryDetailsPage.getStatusBadge() );
            List<String> masteryStatusAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.MASTERY_STATUS_FIELD );
            Log.assertThat( masteryStatusAsc.equals( SMUtils.sortList( masteryStsBfrSortingAsc ) ), "The " + Constants.MasteryUI.MASTERY_STATUS_FIELD + " fields are sorted in ascending in the Mastery details page",
                    "The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD + " fields are not sorted in ascending in the Mastery details page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5935 : Verify the teacher is able to sort the 'Mastery Status' field in descending order in the Mastery details page" );
            List<String> masteryStsBfrSortingDsc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.MASTERY_STATUS_FIELD );
            SMUtils.clickJS( driver, masteryDetailsPage.getWebElementForDetailsPageHeaders( Constants.MasteryUI.MASTERY_STATUS_FIELD ) );
            SMUtils.waitForElement( driver, masteryDetailsPage.getStatusBadge() );
            List<String> masteryStatusDesc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.MASTERY_STATUS_FIELD );
            Log.assertThat( masteryStatusDesc.equals( SMUtils.sortAndReverseList( masteryStsBfrSortingDsc ) ), "The " + Constants.MasteryUI.MASTERY_STATUS_FIELD + " fields are sorted in descending in the Mastery details page",
                    "The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD + " fields are not sorted in descending order in the Mastery details page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5938 : Verify the teacher is able to sort the 'Skills Evaluated' field in ascending order in the Mastery details page" );
            List<String> skillEvalBeforeSortingAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.SKILLS_EVALUATED_FIELD );
            SMUtils.clickJS( driver, masteryDetailsPage.getWebElementForDetailsPageHeaders( Constants.MasteryUI.SKILLS_EVALUATED_FIELD ) );
            SMUtils.waitForElement( driver, masteryDetailsPage.getStatusBadge() );
            List<String> skillsEvaluatedAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.SKILLS_EVALUATED_FIELD );
            List<Integer> skillsEvaluatedAscExpectedInt = skillsEvaluatedAsc.stream().map( Integer::valueOf ).collect( Collectors.toList() );
            List<Integer> skillsEvaluatedAscInt = skillEvalBeforeSortingAsc.stream().map( Integer::valueOf ).collect( Collectors.toList() );
            Log.assertThat( skillsEvaluatedAscExpectedInt.equals( SMUtils.sortListInteger( skillsEvaluatedAscInt ) ), "The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD + " fields are sorted in ascending in the Mastery details page",
                    "The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD + " fields are not sorted in ascending in the Mastery details page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5937 : Verify the teacher is able to sort the 'Skills Evaluated' field in descending order in the Mastery details page" );
            List<String> skillEvalBeforeSortingDsc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.SKILLS_EVALUATED_FIELD );
            SMUtils.clickJS( driver, masteryDetailsPage.getWebElementForDetailsPageHeaders( Constants.MasteryUI.SKILLS_EVALUATED_FIELD ) );
            SMUtils.waitForElement( driver, masteryDetailsPage.getStatusBadge() );
            List<String> skillsEvaluatedDsc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.SKILLS_EVALUATED_FIELD );
            List<Integer> skillsEvaluatedDscExpectedInt = skillsEvaluatedDsc.stream().map( Integer::valueOf ).collect( Collectors.toList() );
            List<Integer> skillsEvaluatedDescInt = skillEvalBeforeSortingDsc.stream().map( Integer::valueOf ).collect( Collectors.toList() );
            Log.assertThat( skillsEvaluatedDscExpectedInt.equals( SMUtils.sortAndReverseListInteger( skillsEvaluatedDescInt ) ), "The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD + " fields are sorted in descending in the Mastery details page",
                    "The " + Constants.MasteryUI.SKILLS_EVALUATED_FIELD + " fields are not sorted in descending order in the Mastery details page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5940 : Verify the teacher is able to sort the 'Attempts field' in ascending order in the Mastery details page" );
            List<String> attemptsFieldBeforeSortingDsc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.ATTEMPTS_FIELD );
            SMUtils.clickJS( driver, masteryDetailsPage.getWebElementForDetailsPageHeaders( Constants.MasteryUI.ATTEMPTS_FIELD ) );
            SMUtils.waitForElement( driver, masteryDetailsPage.getStatusBadge() );
            List<String> attemptsFieldAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.ATTEMPTS_FIELD );
            List<Integer> attemptsFieldAscExpectedInt = attemptsFieldAsc.stream().map( Integer::valueOf ).collect( Collectors.toList() );
            List<Integer> attemptsFieldAscInt = attemptsFieldBeforeSortingDsc.stream().map( Integer::valueOf ).collect( Collectors.toList() );
            Log.assertThat( attemptsFieldAscExpectedInt.equals( SMUtils.sortListInteger( attemptsFieldAscInt ) ), "The " + Constants.MasteryUI.ATTEMPTS_FIELD + " fields are sorted in ascending order in the Mastery details page",
                    "The " + Constants.MasteryUI.ATTEMPTS_FIELD + " fields are not sorted in ascending order in the Mastery details page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5939 : Verify the teacher is able to sort the Attempts field in descending order in the Mastery details page" );
            List<String> attemptsFieldBeforeSortingAsc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.ATTEMPTS_FIELD );
            SMUtils.clickJS( driver, masteryDetailsPage.getWebElementForDetailsPageHeaders( Constants.MasteryUI.ATTEMPTS_FIELD ) );
            SMUtils.waitForElement( driver, masteryDetailsPage.getStatusBadge() );
            List<String> attemptsFieldDesc = masteryDetailsPage.getRowValuesBasedOnTheColumn( Math_Assignment, Constants.MasteryUI.ATTEMPTS_FIELD );
            List<Integer> attemptsFieldDescExpectedInt = attemptsFieldDesc.stream().map( Integer::valueOf ).collect( Collectors.toList() );
            List<Integer> attemptsFieldDescInt = attemptsFieldBeforeSortingAsc.stream().map( Integer::valueOf ).collect( Collectors.toList() );
            Log.assertThat( attemptsFieldDescExpectedInt.equals( SMUtils.sortAndReverseListInteger( attemptsFieldDescInt ) ), "The " + Constants.MasteryUI.ATTEMPTS_FIELD + " fields are sorted in descending order in the Mastery details page",
                    "The " + Constants.MasteryUI.ATTEMPTS_FIELD + " fields are not sorted in descending order in the Mastery details page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 6, groups = { "SMK-39465", "mastery", "masteryLOview" } )
    public void verifyMasteryLOViewStatus( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        String assignmentName = context.getAttribute( "Math_Assignment3" ).toString();
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.setDropDownMS( Constants.MasteryUI.ASSIGNMENTS );
            masteryFiltersComponent.selectAssignmentNameFromDropDownMS( assignmentName );
            MasterySummaryComponent masterySummaryComponent = masteryFiltersComponent.applyFilter();

            List<WebElement> masteredProgressBars = masterySummaryComponent.getProgressBarLink( Constants.MasteryUI.MASTERED );

            MasteryDetailsPage masteryDetailsPage = masterySummaryComponent.navigateToLoViewPage( masteredProgressBars.get( 0 ) );

            SMUtils.logDescriptionTC( "SMK-5924: Verify the Mastery status columnn values in red color for Not Mastered values for both Math/Reading courses skills or standards" );
            SMUtils.logDescriptionTC( "SMK-5926: Verify the Mastery status columnn values in yellow color for At Risk values for both Math/Reading courses skills or standards" );
            SMUtils.logDescriptionTC( "SMK-5925: Verify the Mastery status columnn values in green color for Mastered values for both Math/Reading courses skills or standards" );

            Log.assertThat( masteryDetailsPage.verifyMasteryValueBGColor( browser ), "All the mastery status values are displayed with respective color background", "All the mastery status values are not displayed with respective color background!" );

            Log.testCaseResult();
            Log.testCaseResult();
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-5927: Verify the Mastery status columnn values in Grey color for Not Assessed values for both Math/Reading courses skills or standards" );
            Map<String, Map<String, Integer>> student_Status = masteryDetailsPage.getCountAndColorInProgressBar( browser );
            Log.assertThat( student_Status.get( Constants.MasteryUI.UNASSESSED ).containsKey( Constants.MasteryUI.UNASSESSED_COLOR_CODE ), "The 'Unassessed' value in the Mastery Status columnn is displayed in Grey color",
                    "The 'Unassessed' value in the Mastery Status columnn is not displayed as grey color" );
            Log.testCaseResult();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {

            Log.endTestCase();
            driver.quit();
        }
    }

}