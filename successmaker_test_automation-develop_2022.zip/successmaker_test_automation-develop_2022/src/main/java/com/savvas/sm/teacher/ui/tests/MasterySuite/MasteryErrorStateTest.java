package com.savvas.sm.teacher.ui.tests.MasterySuite;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MasteryFiltersComponent;
import com.savvas.sm.teacher.ui.pages.MasteryPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class MasteryErrorStateTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher19" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        password = DataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "SMK-5964,SMK-5965,SMK-5966 - Verify mastery filters zero state", priority = 1 )
    public void tcMasteryFiltersVerifyZeroStateMsg( ITestContext context ) throws Exception {
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to Mastery Tab
            MasteryPage masteryPage = tHomePage.topNavBar.navigateToMasteryTab();
            MasteryFiltersComponent masteryFiltersComponent = masteryPage.getMasteryFilterComponent();
            masteryFiltersComponent.applyFilter();
            SMUtils.fluentWaitForElement( driver, masteryPage.zeroStateHeader, 30 );
            SMUtils.logDescriptionTC( "SMK-5964 NO RESULTS FOUND header message is displayed when no data is retrieved for the selection made" );
            Log.assertThat( masteryPage.zeroStateHeader.getText().equals( Constants.MasteryUI.NO_RESULTS_HEADER ), "The '" + Constants.MasteryUI.NO_RESULTS_HEADER + "' text is displayed when no data is retrieved",
                    "The '" + Constants.MasteryUI.NO_RESULTS_HEADER + "' text is not displayed when no data is retrieved" );
            SMUtils.logDescriptionTC( "SMK-5965 Verify the No matches for your search criteria. Please filter again message is displayed when no data is retrieved for the selection made" );
            Log.assertThat( masteryPage.zeroStateMsg.getText().equals( Constants.MasteryUI.NO_RESULTS_MSG ), "The '" + Constants.MasteryUI.NO_RESULTS_MSG + "' text is displayed when no data is retrieved",
                    "The '" + Constants.MasteryUI.NO_RESULTS_MSG + "' text is not displayed when no data is retrieved" );
            SMUtils.logDescriptionTC( "SMK-5966 Verify the null/zero state icon is displayed when no data is retrieved for the selection made" );
            Log.assertThat( masteryPage.zeroStateIcon.isDisplayed(), "The 'zero state icon' is displayed when no data is retrieved", "The 'zero state icon' is not displayed when no data is retrieved" );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

}