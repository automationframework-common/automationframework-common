package com.savvas.sm.common.utils.apiconstants;

public interface LMSAPIConstants {
    String LMS_POST_ENDPOINT = "/lms/web/api/autoassigncourse/organization/{orgId}/user/{userId}/scalescore/{scaleScore}/defaultCourse/assignment";
    String ORG_ID = "{orgId}";
    String USER_ID = "{userId}";
    String SCALE_SCORE = "{scaleScore}";
    String AUTHORISATION = "Authorization";
    String INVALID = "INVALID";
}
