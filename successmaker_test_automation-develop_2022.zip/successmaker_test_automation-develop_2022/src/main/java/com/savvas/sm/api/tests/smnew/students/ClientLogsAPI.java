package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class ClientLogsAPI extends AssignmentAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String assignmentID;
    private String assignmentUserId;
    RBSUtils rbsutils = new RBSUtils();
    private String studentDetail;
    private String studentUserID;
    private String studentUsername;
    private String stuFName;
    private String stuLName;
    private String readSessionId;
    private String CourseId;
    private String courseName;
    // Map<String, String> ReadingExitDataResponse = new HashMap<>();
    Map<String, String> updatewithPayload = new HashMap<>();
    Map<String, String> updatewithOutPayload = new HashMap<>();
    Map<String, String> assignmentResponse = new HashMap<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        stuFName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ).toString();
        stuLName = SMUtils.getKeyValueFromResponse( studentDetail, "lastName" ).toString();
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( priority = 1, groups = { "SMK-66838", "smoke_test_case", "P1", "API" } )
    public void tcPostiveClientLogsWithPayloadAPI() throws Exception {

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupdetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentUserID );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );

        assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( "assignmentResponse=" + assignmentResponse );
        assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
        Log.message( "assignmentUserId =" + assignmentUserId );

        String Accesstoken = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        HashMap<String, String> header = new HashMap<>();
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        header.put( Constants.AUTHORIZATION, "Bearer " + Accesstoken );
        header.put( Constants.USERID_SM_HEADER, studentUserID );
        header.put( Constants.ORGID_SM_HEADER, orgId );
        Log.message( "headers value: " + header.toString() );

        HashMap<String, String> pathpayLoad = new HashMap<>();
        pathpayLoad.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId );

        updatewithPayload = updatewithPayload( smUrl, header, pathpayLoad );
        Log.message( "updatewithPaylodResponse = " + updatewithPayload );
        Log.softAssertThat( updatewithPayload.get( Constants.STATUS_CODE ).equalsIgnoreCase( "200" ), "Status code is returned as expected and the same is " + updatewithPayload.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is 200 Actual - " + updatewithPayload.get( Constants.STATUS_CODE ) );

    }

    @Test ( priority = 2, groups = { "SMK-66838", "smoke_test_case", "P1", "API" } )
    public void tcPostiveClientLogsWithoutPayloadAPI() throws Exception {

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupdetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentUserID );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );

        assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( "assignmentResponse=" + assignmentResponse );
        assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
        Log.message( "assignmentUserId =" + assignmentUserId );

        String Accesstoken = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        HashMap<String, String> header = new HashMap<>();
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        header.put( Constants.AUTHORIZATION, "Bearer " + Accesstoken );
        header.put( Constants.USERID_SM_HEADER, studentUserID );
        header.put( Constants.ORGID_SM_HEADER, orgId );
        Log.message( "headers value: " + header.toString() );

        HashMap<String, String> pathpayLoad = new HashMap<>();
        pathpayLoad.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId );

        updatewithOutPayload = updatewithOutPayload( smUrl, header, pathpayLoad );
        Log.message( "updatewithOutPayloadResponse = " + updatewithOutPayload );
        Log.softAssertThat( updatewithOutPayload.get( Constants.STATUS_CODE ).equalsIgnoreCase( "200" ), "Status code is returned as expected and the same is " + updatewithOutPayload.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is 200 Actual - " + updatewithOutPayload.get( Constants.STATUS_CODE ) );

    }

    public Map<String, String> updatewithPayload( String url, HashMap<String, String> header, HashMap<String, String> withPayLoad ) throws Exception {
        String payload = null;
        String endPoint = StudentDetailsForGivenTeacherConstants.CLIENTLOGS_DATA;
        Log.message( "endpoint is : " + endPoint );
        payload = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "updateClientLogs.json" );
        payload = payload.replace( "assignmentUserId", withPayLoad.get( Constants.ASSIGNMENT_USER_ID ) );
        return RestHttpClientUtil.POST( url, header, new HashMap<>(), endPoint, payload );
        
    }

    public Map<String, String> updatewithOutPayload( String url, HashMap<String, String> header, HashMap<String, String> withPayLoad ) throws Exception {
        String payload = null;
        String endPoint = StudentDetailsForGivenTeacherConstants.CLIENTLOGS_DATA;
        Log.message( "endpoint is : " + endPoint );
        return RestHttpClientUtil.POST( url, header, new HashMap<>(), endPoint, payload );
    }

}