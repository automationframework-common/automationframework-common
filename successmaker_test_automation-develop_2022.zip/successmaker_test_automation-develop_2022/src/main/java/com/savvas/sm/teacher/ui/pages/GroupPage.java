package com.savvas.sm.teacher.ui.pages;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.GroupUIConstants;
import com.savvas.sm.common.utils.Constants.Groups;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.data.sme7.TestDataConstants;
import com.savvas.sm.utils.Constants.Students;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class GroupPage extends LoadableComponent<GroupPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    public WebDriver driver;
    boolean isPageLoaded;
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    // ********* SuccessMaker Groups Page Elements ***************

    @FindBy ( css = "div.users-table thead.table-head tr>th" )
    List<WebElement> userTableHeader;

    @IFindBy ( how = How.CSS, using = "div.confirm-modal-footer>cel-button:not([color*='secondary'])", AI = false )
    public WebElement confirmPopUpRoot;

    @IFindBy ( how = How.CSS, using = "div.group-details-content .users-container h1.header", AI = false )
    public WebElement userTabHeader;

    @IFindBy ( how = How.CSS, using = "div.assignments-container tbody tr td.th-action-button>cel-button.hydrated", AI = false )
    public WebElement viewAssignmentBtnStatic;

    @IFindBy ( how = How.CSS, using = "div.group-details-content .assignments-container span.header", AI = false )
    public WebElement assignmentsHeader;

    @IFindBy ( how = How.CSS, using = "div.group-details-content .header-title span", AI = false )
    public WebElement masteryHeader;

    @IFindBy ( how = How.CSS, using = "div.group-details-content .settings-container h1", AI = false )
    public WebElement settingsHeader;

    @FindBy ( css = "cel-icon.close-icon" )
    List<WebElement> addStudGroupCloseBtnX;

    @IFindBy ( how = How.CSS, using = "span.header-group-name", AI = false )
    public WebElement headerGroupName;

    @IFindBy ( how = How.CSS, using = "div.users-container cel-button[color='secondary']", AI = false )
    public WebElement addStudentRoot;

    @IFindBy ( how = How.CSS, using = "div.zero-state-content h3.header", AI = false )
    public WebElement noUserHeader;

    @IFindBy ( how = How.CSS, using = "div.zero-state-content div.projected .message", AI = false )
    public WebElement noUserMsg;

    @IFindBy ( how = How.CSS, using = "div.zero-state-content button.btn-link.link", AI = false )
    public WebElement noUserLink;

    @IFindBy ( how = How.CSS, using = "div.group-details-zero-state h3.header", AI = false )
    public WebElement assignmentHeaderNOData;

    @IFindBy ( how = How.CSS, using = "div.group-details-zero-state p.message", AI = false )
    public WebElement assignmentNoMsg;

    @IFindBy ( how = How.CSS, using = "div.assignments-container div grid-table div table tbody", AI = false ) // div.assignments-container
    // div:nth-child(2) div grid-table div
    // table tbody
    public WebElement assignmentList;

    @IFindBy ( how = How.CSS, using = "div .main-container-header cel-button", AI = false )
    public WebElement btnCreateGroupRoot;

    @IFindBy ( how = How.CSS, using = "cel-button.create-group-button.close-button.hydrated", AI = false )
    public WebElement btnCancelRoot;

    @IFindBy ( how = How.CSS, using = "cel-button.create-group-button.add-group-button.hydrated", AI = false )
    public WebElement btnCreateRoot;

    @IFindBy ( how = How.CSS, using = "#groupName", AI = false )
    public WebElement groupNameTextBox;

    @IFindBy ( how = How.CSS, using = "div.confirm-modal-footer cel-button[color='secondary']", AI = false )
    public WebElement btnCancelRootpopup;

    @IFindBy ( how = How.CSS, using = "input.filterText", AI = false )
    public WebElement addStudentTextBox;

    @IFindBy ( how = How.CSS, using = "div:nth-child(2) cel-button", AI = false )
    public WebElement btnAddStudentGroupRoot;

    @IFindBy ( how = How.CSS, using = "group-edit group-settings-container div div.actions cel-button", AI = false )
    public WebElement btneditGroupSettingsSaveRoot;

    @IFindBy ( how = How.CSS, using = "group-delete group-settings-container div div.actions cel-button", AI = false )
    public WebElement btndeleteGroupRoot;

//    @IFindBy ( how = How.CSS, using = "td:nth-child(6) > cel-button-menu", AI = false )
//    public WebElement ellipsesRoot;
    
    @FindBy(css="td:nth-child(6) > cel-button-menu")
    public WebElement ellipsesRoot;

    @IFindBy ( how = How.CSS, using = "div.container-fluid.card.main-container-body div.row div grid-table div table tbody", AI = false )
    public WebElement groupList;

    @IFindBy ( how = How.CSS, using = "div:nth-child(2) div grid-table div table tbody", AI = false )
    public WebElement groupStudentList;

    @IFindBy ( how = How.CSS, using = "div.main-container-heading span", AI = false )
    public WebElement groupPageHeader;

    @IFindBy ( how = How.CSS, using = "th:nth-child(1) span span:nth-child(1)", AI = false )
    public WebElement groupNameHeader;

    @IFindBy ( how = How.CSS, using = "th:nth-child(1) span span:nth-child(2)", AI = false )
    public WebElement groupNameSortIcon;

    @IFindBy ( how = How.CSS, using = "th:nth-child(2) span span:nth-child(1)", AI = false )
    public WebElement noOfStudentsHeader;

    @IFindBy ( how = How.CSS, using = "div.select-is-all-student cel-checkbox", AI = false )
    public WebElement chBoxAllStudentfromSchoolRoot;

    @IFindBy ( how = How.CSS, using = "cel-checkbox.search-checkbox.hydrated", AI = false )
    public WebElement chBoxSearchAllStudent;

    @IFindBy ( how = How.CSS, using = "span.dropdown-select-caret-outer.sc-cel-dropdown-select cel-icon", AI = false )
    public WebElement gradeDropDownRoot;

    @IFindBy ( how = How.CSS, using = "div.dropdown-select-options-wrapper.sc-cel-dropdown-select ul", AI = false )
    public WebElement allGrades;

    @IFindBy ( how = How.CSS, using = "cel-dropdown-select#grade  span span", AI = false )
    public WebElement gradeDropDown;

    @FindBy ( css = "cel-side-nav-bar div span.side-nav-item" )
    List<WebElement> settingsSideBar;

    @IFindBy ( how = How.CSS, using = "cel-side-nav-bar div:nth-child(2) span.side-nav-item", AI = false )
    public WebElement assignmentsSideBar;

    @IFindBy ( how = How.CSS, using = "group-edit group-settings-container div h2", AI = false )
    public WebElement lblEditGroup;

    @IFindBy ( how = How.CSS, using = "group-delete group-settings-container div h2", AI = false )
    public WebElement lblDeleteGroup;

    @IFindBy ( how = How.CSS, using = "group-delete group-settings-container div div.content p", AI = false )
    public WebElement lblDeleteGroupMsg;

    @IFindBy ( how = How.CSS, using = "ng-input div input", AI = false )
    public WebElement txtBoxEditGroup;

    @IFindBy ( how = How.CSS, using = "div.zero-state-content div:nth-child(2) p", AI = false )
    public WebElement lblZeroState;

    @IFindBy ( how = How.CSS, using = "div.group-container div span", AI = false )
    public WebElement lblGroupNameFromViewGroup;

    @IFindBy ( how = How.CSS, using = "cel-button:nth-child(2)", AI = false )
    public WebElement btnDeleteFromPopUpRoot;

    @IFindBy ( how = How.CSS, using = "th:nth-child(3)>span", AI = false )
    public WebElement iconUserNameSort;

    @IFindBy ( how = How.CSS, using = "form-error-message span span", AI = false )
    public WebElement errorMessageForGroupName;

    @IFindBy ( how = How.CSS, using = "text-chips input", AI = false )
    public WebElement addStudentTxtBox;

    @IFindBy ( how = How.CSS, using = "cel-dialog-header div div button", AI = false )
    public WebElement iconI;

    @IFindBy ( how = How.CSS, using = "h1.header", AI = false )
    public WebElement usersHeader;

    @IFindBy ( how = How.CSS, using = "div:nth-child(2) cel-button", AI = false )
    public WebElement addStudentToGroupParent;

    @IFindBy ( how = How.CSS, using = "div:nth-child(2) div grid-table div table tbody", AI = false )
    public WebElement assignmentsList;

    @IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
    public WebElement deleteAssignmentpopup;

    @IFindBy ( how = How.CSS, using = "div.confirm-modal p:nth-of-type(1)", AI = false )
    public WebElement deletepopupHeadsup;

    @IFindBy ( how = How.CSS, using = "div.confirm-modal p:nth-of-type(2)", AI = false )
    public WebElement deletepopupHeadsupMessage;

    @IFindBy ( how = How.CSS, using = ".confirm-modal-footer cel-button.hydrated:nth-of-type(2)", AI = false )
    public WebElement DeleteButtonparent;

    @IFindBy ( how = How.CSS, using = ".confirm-modal-footer cel-button.hydrated:nth-of-type(1)", AI = false )
    public WebElement cancelDeleteAssignmentButtonparent;

    @IFindBy ( how = How.CSS, using = "cel-icon.dialog-header__icon-close.hydrated", AI = false )
    public WebElement XDeleteAssignmentButtonparent;

    @IFindBy ( how = How.CSS, using = "div.add-button cel-button", AI = false )
    public WebElement addButtonRoot;

    @FindBy ( css = "div.dropdown-select-options-wrapper.sc-cel-dropdown-select ul li a span" )
    List<WebElement> listOfGradesDropDown;

    @IFindBy ( how = How.CSS, using = "input.chip-search-area", AI = false )
    public WebElement searchGroupTextField;

    @FindBy ( css = "div.add-btn cel-button" )
    List<WebElement> multipleAddBtnsInAssignPoPUp;

    @IFindBy ( how = How.CSS, using = "div.add-btn cel-button", AI = false )
    public WebElement addBtnInAssignPoPUpRoot;

    @FindBy ( css = "td div.assignment-text span" )
    List<WebElement> assignmentDetailsInGroupTab;

    @FindBy ( css = "td cel-checkbox" )
    List<WebElement> allCheckBoxRoot;

    @IFindBy ( how = How.CSS, using = "cel-button.group-button", AI = false )
    public WebElement groupButtonRoot;

    @FindBy ( css = "div.student-name div" )
    List<WebElement> grpNamesInAddStudentToGrpPoPUp;

    @FindBy ( css = "div.add-button cel-button" )
    List<WebElement> multipleAddButtonRoot;

    @IFindBy ( how = How.CSS, using = "cel-button.action-btn-wrapper", AI = false )
    public WebElement saveBtnAddStudentToGrpPopUpRoot;

    @FindBy ( css = "td span.text-overflow-nowrap" )
    List<WebElement> userDetailsInGrpPage;

    @IFindBy ( how = How.CSS, using = "cel-button.button.hydrated", AI = false )
    public WebElement addStuToGrpBtnRoot;

    @FindBy ( css = "div.student-name span.student-username" )
    List<WebElement> stuNamesInAddStudentToGrpPoPUp;

    @FindBy ( css = "div.student-name span.username" )
    List<WebElement> stuNamesInAssignPoPUp;

    // Root Child Elements

    @IFindBy ( how = How.CSS, using = " div.assignments-container th:nth-child(1)>span", AI = false )
    public WebElement iconTitleSort;

    @FindBy ( css = ".grp-table .table-container tr>td:nth-of-type(1)" )
    List<WebElement> listGroupName;

    @IFindBy ( how = How.CSS, using = "input[name='groupName']", AI = false )
    public WebElement groupNameSettings;

    @IFindBy ( how = How.CSS, using = "h3.header", AI = false )
    public WebElement noDataYet;

    @IFindBy ( how = How.CSS, using = "span.message", AI = false )
    public WebElement zeroStateMessge;

    @IFindBy ( how = How.CSS, using = "button.btn.btn-link.link", AI = false )
    public WebElement btnZeroStateAddGroup;

    @IFindBy ( how = How.CSS, using = "group-settings div h1", AI = false )
    public WebElement groupsettingsheader;

    @IFindBy ( how = How.CSS, using = "div.ng-input label", AI = false )
    public WebElement groupNameTitle;

    // Create a new Group button in Group page 
    @IFindBy ( how = How.CSS, using = "cel-button.main-container-header-button.hydrated", AI = false )
    public WebElement btnCreateNewGroup;

    // In Popup Create New Group header title element
    @IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
    public WebElement createaNewGroupHeaderinPopup;

    @IFindBy ( how = How.CSS, using = "cel-button.create-group-button.close-button.hydrated", AI = false )
    public WebElement btnCancelGroupinPopup;

    // Create a group button in popup
    @IFindBy ( how = How.CSS, using = "cel-button.create-group-button.add-group-button.hydrated", AI = false )
    public WebElement btnCreateGroupinPopup;

    // This element is Error messgae in GroupName Textbox in popup
    @IFindBy ( how = How.CSS, using = "span.ml-1", AI = false )
    public WebElement erroMessageinGroupName;

    // Group Name in at individual section
    @IFindBy ( how = How.CSS, using = "span.header-group-name", AI = false )
    public WebElement groupNameinContainer;

    @IFindBy ( how = How.CSS, using = "input[name='filterText']", AI = false )
    public WebElement txtBoxSearchinCreateGroupPopup;

    @IFindBy ( how = How.CSS, using = "div.list-data cel-button", AI = false )
    public WebElement addButtoninPopupRoot;

    public String addButtonCSS = "button.secondary_button";

    @IFindBy ( how = How.CSS, using = "tbody.table-body", AI = false )
    public WebElement groupTable;

    @IFindBy ( how = How.CSS, using = "cel-button.main-container-header-button.hydrated", AI = false )
    public WebElement createNewGroupbtn;

    @IFindBy ( how = How.CSS, using = "#cel-overlay-1 > div", AI = false )
    public WebElement createNewGroupDialogBox;

    @IFindBy ( how = How.CSS, using = "#cel-overlay-1 > div > cel-dialog-header > div > div > button", AI = false )
    public WebElement createNewGroupHelpInfoIcon;

    @IFindBy ( how = How.CSS, using = "#mc-main-content > h1", AI = false )
    public WebElement createNewGroupHelpPageHeader;

    @IFindBy ( how = How.CSS, using = ".analytics-container .header", AI = false )
    public WebElement groupUsageHeader;

    @IFindBy ( how = How.CSS, using = ".group-skills-tested .group-title", AI = false )
    public WebElement skillsAssessmentHeader;

    @IFindBy ( how = How.CSS, using = ".group-skills-tested .report-header", AI = false )
    public WebElement percentOfStudentsMasteredHeader;

    @IFindBy ( how = How.CSS, using = "#assignments button", AI = false )
    public WebElement assignmentsDropdown;

    @IFindBy ( how = How.CSS, using = "#assignments .dropdown-select-label", AI = false )
    public WebElement assignmentSelected;

    @FindBy ( css = "#assignments ul span" )
    List<WebElement> assignmentsName;

    @FindBy ( css = "#assignments a" )
    List<WebElement> assignmentsLink;

    @FindBy ( css = "cel-progress-bar.hydrated" )
    List<WebElement> progressBarRoot;

    @IFindBy ( how = How.CSS, using = ".group-skills-tested .top-panel a", AI = false )
    public WebElement viewDetailsBtn;

    @FindBy ( css = ".graph .description a" )
    List<WebElement> skillNames;

    @FindBy ( css = "cel-progress-bar.hydrated" )
    List<WebElement> progressPercentRoot;

    @IFindBy ( how = How.CSS, using = ".skills-desc .text-truncate", AI = false )
    public WebElement skillNameInSkillPopup;

    @IFindBy ( how = How.CSS, using = ".description a", AI = false )
    public WebElement loLink;

    @IFindBy ( how = How.CSS, using = ".skills-popup cel-button", AI = false )
    public WebElement closeBtnInSkillPopup;

    @IFindBy ( how = How.CSS, using = "div.dialog-wrapper", AI = false )
    public WebElement pauseOrResuMePopup;

    @IFindBy ( how = How.CSS, using = "div.create-group-container", AI = false )
    public WebElement formGroupPopup;

    @IFindBy ( how = How.CSS, using = "input[name=filterText]", AI = false )
    public WebElement txtboxGroupfilter;

    @IFindBy ( how = How.CSS, using = "div.add-button cel-button[role=button]", AI = false )
    public WebElement btnAddGroup;

    @IFindBy ( how = How.CSS, using = "skills-assessed .zero-state", AI = false )
    public WebElement skillsAssess;

    @IFindBy ( how = How.CSS, using = "skills-assessed .zero-state-content", AI = false )
    public WebElement skillsAssessZeroState;

    @FindBy ( css = "span[class='text-overflow-nowrap']" )
    List<WebElement> groupNameList;

    @FindBy ( css = ".user-grade .student-username" )
    List<WebElement> studentNamesFromCreateGroupPopup;

    @IFindBy ( how = How.CSS, using = "div.zero-state-content button", AI = false )
    public WebElement addStuToGrpLink;

    @FindBy ( css = "div.list-data div.student-info" )
    List<WebElement> parentElementAddAssignPopUp;

    @IFindBy ( how = How.CSS, using = "div[class='analytics-container col-sm-4'] div[class='header']", AI = false )
    public WebElement lblGroupUsageHeader;

    @IFindBy ( how = How.CSS, using = "div.zero-state-wrapper.px-3 zero-state div div.zero-state-content h3", AI = false )
    public WebElement lblZeroStateText;

    @FindBy ( css = "div[class='usage-chart'] p[class='text-grey']" )
    List<WebElement> lblText;

    @FindBy ( css = "div[class='usage-chart'] p[class='text-black']" )
    List<WebElement> lblvalues;

    @IFindBy ( how = How.CSS, using = "text[text-anchor='middle']", AI = false )
    public WebElement xAxisLable;

    // group usage chart
    @IFindBy ( how = How.CSS, using = "div.analytics-container  graphs-usage-chart", AI = false )
    public WebElement groupUsagechartRoot;

    @FindBy ( css = "graphs-usage-chart p.text-grey" )
    List<WebElement> lblUsageFields;

    @FindBy ( css = "graphs-usage-chart svg.legend-font g" )
    List<WebElement> lblgroupUsageLegends;

    @IFindBy ( how = How.CSS, using = "graphs-usage-chart svg g#yaxis text.axis-label", AI = false )
    public WebElement lblYaxis;

    @FindBy ( css = "graphs-usage-chart g#xaxis g.tick text" )
    List<WebElement> lblXaxisIntervals;

    @FindBy ( css = "graphs-usage-chart g#yaxis g.tick text" )
    List<WebElement> lblYaxisIntervals;

    @FindBy ( css = "graphs-usage-chart app-chart svg  g[fill ='#32325D'] rect" )
    List<WebElement> readingBars;

    @FindBy ( css = "graphs-usage-chart app-chart svg  g[fill ='#9ECA47'] rect" )
    List<WebElement> mathBars;

    @IFindBy ( how = How.CSS, using = "graphs-usage-chart app-chart svg  g#recttooltip_charts text", AI = false )
    public WebElement toolTipUsageChart;

    @IFindBy ( how = How.CSS, using = "div.analytics-container div.group-chart-title", AI = false )
    public WebElement groupUsgechartHeader;

    // assignments sub-nav
    @FindBy ( css = "table#report tr.accordion-table-row" )
    List<WebElement> assignmentListRoot;

    @IFindBy ( how = How.CSS, using = "table#report tr.accordion-table-row div.cell-tooltip span.align-right", AI = false )
    public WebElement assignmentNames;

    @IFindBy ( how = How.CSS, using = "div.group-assignment-header h5", AI = false )
    public WebElement assignmentSubNavHeader;

    @IFindBy ( how = How.CSS, using = "div.dialog-header h1", AI = false )
    public WebElement popupHeader;

    @FindBy ( css = "cel-button.hydrated" )
    List<WebElement> PopupButtonsRoot;

    @IFindBy ( how = How.CSS, using = "input[name='filterText']", AI = false )
    public WebElement studentNameFilter;

    @IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
    public WebElement pauseResumePopupHeader;

    @FindBy ( css = "div.confirm-modal p" )
    List<WebElement> pauseResumeAssignmentHeadsupMessage;

    @IFindBy ( how = How.CSS, using = "div.confirm-modal-footer cel-button:not([color])", AI = false )
    public WebElement pauseResumeButton;

    @IFindBy ( how = How.CSS, using = "div > cel-button[color='secondary'][role='button'][class='hydrated']", AI = false )
    public WebElement cancelPauseResumeAssignmentButton;

    @IFindBy ( how = How.CSS, using = "cel-icon.dialog-header__icon-close.hydrated ", AI = false )
    public WebElement xPauseResumeAssignmentButton;

    @IFindBy ( how = How.CSS, using = "div.assignments-container cel-badge.paused", AI = false )
    public WebElement pauseBadgeRoot;

    @IFindBy ( how = How.CSS, using = "table cel-icon", AI = false )
    public WebElement arrowIcon;

    @FindBy ( css = "tbody span" )
    List<WebElement> groupRowTextList;

    @FindBy ( css = "table span.sort-type-none" )
    List<WebElement> columnNames;

    // Add students to group button popup
    @IFindBy ( how = How.CSS, using = "h1.dialog-header__message", AI = false )
    public WebElement addStudentsToGroupPopupHeader;

    @FindBy ( css = "div.list-data" )
    List<WebElement> ListOfAddStudentsToGroupPopup;

    @IFindBy ( how = How.CSS, using = "span.display-message", AI = false )
    public WebElement gradeNotSelectedErrMsg;

    @IFindBy ( how = How.CSS, using = "input[name='filterText']", AI = false )
    public WebElement txtBoxSearchinAddGroupPopup;

    @IFindBy ( how = How.CSS, using = "cel-dropdown-select#grade  span span", AI = false )
    public WebElement gradeValue;

    // @IFindBy ( how = How.CSS, using = "a.dropdown-option-link" , AI=false)
    @IFindBy ( how = How.CSS, using = "span.dropdown-option-label", AI = false )
    List<WebElement> listofGrades;

    @FindBy ( css = "span.chip-text" )
    List<WebElement> listAddStudChipTxt;

    @IFindBy ( how = How.CSS, using = "button.dialog-btn-close", AI = false )
    public WebElement closePopupAddStudBtn;

    @IFindBy ( how = How.CSS, using = "span.student-username", AI = false )
    public WebElement studentlistingroup;

    @IFindBy ( how = How.CSS, using = "span.display-message", AI = false )
    public WebElement invalidSearchErrMsg;

    @IFindBy ( how = How.CSS, using = "span.cross-mark", AI = false )
    public WebElement chipTxtBtnX;

    @IFindBy ( how = How.CSS, using = "div.add-students-footer cel-button[color='primary']", AI = false )
    public WebElement btnAddStudents;

    @IFindBy ( how = How.CSS, using = "div.add-students-footer cel-button[color='secondary']", AI = false )
    public WebElement btnCancelAddStudPopup;

    @IFindBy ( how = How.CSS, using = ".mastery-container .zero-state-content .header", AI = false )
    public WebElement masteryZeroStateHeader;

    @IFindBy ( how = How.CSS, using = ".mastery-container .zero-state-content .message", AI = false )
    public WebElement masteryZeroStateMessage;

    @IFindBy ( how = How.CSS, using = "#assignments .dropdown-select-caret", AI = false )
    public WebElement downArrowInAssignmentDroddown;

    @IFindBy ( how = How.CSS, using = "a.header-backLink", AI = false )
    public WebElement backIcon;

    @IFindBy ( how = How.CSS, using = ".error-message span", AI = false )
    public WebElement groupNameErrorMesage;

    @IFindBy ( how = How.CSS, using = "div[class='form-group'] label[for='groupName']", AI = false )
    public WebElement groupNameHeaderCreateGroupPopup;

    @IFindBy ( how = How.CSS, using = "div[class='form-group'] label[for='addStudent']", AI = false )
    public WebElement addStudentHeaderCreateGroupPopup;

    @FindBy ( css = "div[class='student-firstName-lastName']" )
    List<WebElement> studentFirstNames;

    @FindBy ( css = "span.student-gradename" )
    List<WebElement> gradesOfListedStudent;

    @IFindBy ( how = How.CSS, using = "div[class='student-info']", AI = false )
    public WebElement studentInfoFrameInCreateGroupPopup;

    MasteryFiltersComponent masteryFilterComponent;

    // Adding more than 100 Student Error Element

    @IFindBy ( how = How.CSS, using = "div.error-message", AI = false )
    public WebElement errorMessageForLimit100Students;

    @IFindBy ( how = How.CSS, using = "span[class='sub-header']", AI = false )
    public WebElement messageForGoogleClass;

    @IFindBy ( how = How.CSS, using = "div[class='add-button'] cel-button", AI = false )
    public WebElement addButtonroot;

    @IFindBy ( how = How.CSS, using = "div[class='error-message']", AI = false )
    public WebElement studentFieldErrorMessage;

    @IFindBy ( how = How.CSS, using = "tbody.table-body tr.table-row.highlight-on-hover ", AI = false )
    public WebElement groupTableRows;

    @FindBy ( css = "td:nth-child(1) span" )
    List<WebElement> groupNames;

    // Solar serarch Element

    @FindBy ( css = "div.list-data span.student-username" )
    List<WebElement> listOfUserNamesSolarSearchResult;

    @FindBy ( css = "div.list-data div.student-firstName-lastName" )
    public List<WebElement> listOfStudentNamesSolarSearchResult;

    @FindBy ( css = "div.list-data span.student-gradename" )
    List<WebElement> listOfGradeValueSolarSearchResult;

    @IFindBy ( how = How.CSS, using = "cel-loading-spinner.hydrated", AI = false )
    public WebElement spinner;

    public static String PLEASE_LIMIT_THE_100_STUDENT_TO_YOUR_GROUP_ERROR = "Please limit the number of students in your group to 100 or less.";

    @IFindBy ( how = How.CSS, using = "div.table-container table.table tbody.table-body tr.table-row td:nth-child(6) > cel-button-menu.table-dropdown-menu.th-action-dropdown.hydrated", AI = false )
    public WebElement ellipsesIconShadowHost;

    public String ellipsesIconCSS = ".buttonmenu__dots.hydrated";

    public String dropDownMenuItemCSS = "div > cel-dropdown-menu-box.hydrated";
    public String editAssignmentSettingsCss = "div > ul.menu.menu--active.menu-position__right >li:first-of-type";

    @IFindBy ( how = How.CSS, using = "h1[title='Edit Assignment Settings']", AI = false )
    public WebElement editAssignmentSettingtitle;

    @FindBy ( how = How.CSS, using = "cel-button.action-btn-wrapper.d-flex.justify-content-end.hydrated" )
    public WebElement addStudentButton;
    
    @IFindBy ( how = How.CSS, using = "cel-side-nav-bar div:nth-child(3) span.side-nav-item", AI = false )
    public WebElement masterySideBar;

    // Root Child Elements
    private static String siedNavCommon = "cel-side-nav-bar div span.side-nav-item";
    private static String groupUserZeroState = "div.zero-state-content h3.header";
    private static String groupdropdownSelectAllCheckbox = "div.primary__checkbox.checkbox";
    private static String ellipsesAssignmentForgroupGrandRoot = "div.assignments-container tbody tr:nth-child(%s) cel-button-menu.table-dropdown-menu";
    private static String ellipsesAssignmentForGroupParent = "cel-dropdown-menu-box.hydrated";
    private static String editAssignmentForGroupChild = "span[aria-label='Edit Assignment Settings']";
    private static String deleteAssignmentForGroupChild = "span[aria-label='Delete Assignment']";
    private static String pauseAssignmentForGroupChild = "span[aria-label='Pause Assignment for All Students']";
    private static String usersTable = "div.users-container tbody tr";
    private static String assignmentTable = "div.assignments-container tbody tr";
    private static String assginmentTitle = "div.assignments-container tbody tr:nth-child(%s) td:nth-child(1) div.assignment-text span";
    private static String viewAssignmentBtn = "div.assignments-container tbody tr:nth-child(%s) td.th-action-button>cel-button.hydrated";
    private static String dateAssigned = "div.assignments-container tbody tr:nth-child(%s) td:nth-child(2) div.assignment-text span";
    private static String assginmentBadgeRoot = "div.assignments-container tbody tr:nth-child(%s) cel-badge.paused";
    private static String assginmentBadgeChild = "div[class='badge success']>span";
    private static String addStudentChild = ".secondary_button";
    private static String btnPrimary = ".primary_button";
    private static String btnSecondary = ".secondary_button";
    private static String removeBtnAddStudPopup = "div.remove-button";
    private static String addStudGroupcloseBtnchild = "img.icon-inner";
    private static String staticCourseName = null;

    private static String viewGroupRoot = "tr:nth-child(%s) td.th-action-button cel-button";
    private static String studentListForGroups = "div:nth-child(2) > div.list-data";
    private static String studentListForAddStudentGrpBtn = "div.list-data div.student-info";
    private static String studentListstudent = "div:nth-child(2) div.list-data div:nth-child(%s) div div.student-name div.user-grade span.student-username";

    private static String studentListFNLN = "div:nth-child(2) div.list-data div:nth-child(%s) div div.student-name div.student-firstName-lastName";

    private static String StudentListGrade = "div:nth-child(2) div.list-data div:nth-child(%s) div div.student-name div.user-grade span.student-gradename";

    private static String btnAdd = "div:nth-child(2) div.list-data div:nth-child(%s) div div.add-button cel-button";
    private static String btnRemove = "div:nth-child(2) div.list-data div:nth-child(%s) div div.remove-button cel-button";
    private static String groupName = "tr:nth-child(%s)>td:nth-child(1) span";
    private static String groupStudentCount = "tr:nth-child(%s) td:nth-child(2) span";

    private static String studentFN = "tr:nth-child(%s) td:nth-child(1) span";
    private static String studentLN = "tr:nth-child(%s) td:nth-child(2) span";
    private static String studentUN = "tr:nth-child(%s) td:nth-child(3) span";
    private static String studentID = "tr:nth-child(%s) td:nth-child(4) span";

    private static String studentGrade = "tr:nth-child(%s) td:nth-child(5) span";
    private static String studentTeacher = "tr:nth-child(%s) td:nth-child(6) span";
    private static String chBoxAllStudentfromSchool = "div.primary__checkbox input";
    private static String selectAllgradeDropDownChild = "img.icon-inner";
    private static String grade = "li:nth-child(%s) a span";

    private static String AssignemntTitle = "tr:nth-child(%s) td:nth-child(1) span";
    private static String AssignmentDateAssigned = "tr:nth-child(%s) td:nth-child(2) span";
    private static String assignmentName = "tr:nth-child(%s) td:nth-child(1) span";
    private static String threeDotEllipsesRoot = "tr:nth-child(%s) td:nth-child(6) > cel-button-menu";
    private static String DeleteAssignmentBtnParent = "cel-dropdown-menu-box.hydrated";
    private static String DeleteAssignmentchild = "span[aria-label='Delete Assignment']";
    private static String checkBoxchild = "div.primary__checkbox label>input";
    private static String userNameAddStuToGrpPopUp = "span.student-username";
    private String StuNameRootEleAddStuToGrpPopUp = "div.add-button cel-button";
    private static String grpNameAddAssignToGrpPopUp = ".student-name div.name";
    private static String addBtnRootAddassignToGrp = "div.add-btn cel-button";
    private static String lblCheckAllStudents = "label[class='checkbox__label']";
    private static String removeStudentFromSelection = "cel-icon[class='close-icon hydrated']";

    public static String groupTableCSS = "div.container-fluid.card.main-container-body div.row div grid-table div table tbody";
    private static String progressBar = ".progressBar";
    private static String progressPercent = ".progressBarText";
    public static String txterrorMessage = "span.ml-1";
    public static String addButtonFromCreateGroupRoot = "div[class='add-button'] cel-button";

    private static String lblZeroStateMessage = "div.zero-state-content";
    private static String txtindividualField = "p.text-black";
    private static String lblGroupsUsageHeader = "div.student-chart-title";
    private static String PauseAllStudentAssignmentBtnParent = "cel-dropdown-menu-box.hydrated";
    private static String PauseAllStudentAssignmentchild = "span[aria-label='Pause Assignment for All Students']";
    private static String ResumeAllStudentAssignmentBtnParent = "cel-dropdown-menu-box.hydrated";
    private static String ResumeAllStudentAssignmentchild = "span[aria-label='Resume Assignment for All Students']";
    public static String arrowUp = "icon_arrow_thin_up";
    public static String arrowDown = "icon_arrow_thin_down";
    public static String innerIcon = ".icon-inner";
    public static String PLEASE_TYPE_3_OR_MORE_LETTERS_TO_SEARCH = "Please type 3 or more letters to search";

    public GroupPage() {}

    public GroupPage( WebDriver driver ) {
        this.driver = driver;
        // Have Top bar here and init
        ElementLocatorFactory finder = new AjaxElementLocatorFactory( driver, Utils.maxElementWait );
        PageFactory.initElements( finder, this );
        elementLayer = new ElementLayer( driver );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, btnCreateGroupRoot );

    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, btnCreateGroupRoot ) ) {
            Log.message( "SM Groups page loaded successfully." );
        } else {
            Log.fail( "SM Groups page did not load." );
        }

    }

    /**
     * 
     * Groups Page - Users Side Nav - Get Table Headers
     *
     * @return - Table Headers
     */
    public List<String> getUsersTabTableHeader() throws Exception {
        clickGroupsSubNav( Constants.USERS );
        SMUtils.waitForElement( driver, noOfStudentsHeader, 30 );
        List<String> userHeader = new ArrayList<String>();
        for ( WebElement ele : userTableHeader ) {
            String headerText = ele.getText();
            userHeader.add( headerText );
        }
        return userHeader;
    }

    /**
     * Groups Page - Assignments SideNav - 'Delete assignments' for all the
     * students
     */
    public void deleteAllAssignmentsInGroupsSideNav() {
        try {
            SMUtils.waitForElement( driver, assignmentList, 30 );
            String assignmentCountFromUI = assignmentList.getAttribute( "childElementCount" );
            Log.message( "The assignment count is " + assignmentCountFromUI, driver );
            if ( !assignmentCountFromUI.isEmpty() ) {
                for ( int assignmentCount = 1; assignmentCount <= Integer.parseInt( assignmentCountFromUI ); assignmentCount++ ) {
                    String ellipsedots = String.format( ellipsesAssignmentForgroupGrandRoot, assignmentCount );
                    WebElement element = driver.findElement( By.cssSelector( ellipsedots ) );
                    SMUtils.waitForElement( driver, element );
                    element.click();
                    Log.message( "Clicked the ellipse dots in assignment table", driver );
                    WebElement deleteElement = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( ellipsedots ) ), ellipsesAssignmentForGroupParent, deleteAssignmentForGroupChild );
                    deleteElement.click();
                    SMUtils.waitForElement( driver, confirmPopUpRoot );
                    Log.message( "Clicked the Confirm Popup button for delete the assignment", driver );
                    confirmPopUpRoot.click();
                }

            }
        } catch ( Exception e ) {
            Log.fail( "Group Assignments are not displayed properly!" );
        }
    }

    /**
     * Groups Page - Assignments SideNav - 'Pause Assignments for All Students'
     * for all the available students in the table
     */
    public void pauseAllAssignmentsInGroupsSideNav() {
        try {
            SMUtils.waitForElement( driver, assignmentList, 30 );
            String assignmentCountFromUI = assignmentList.getAttribute( "childElementCount" );
            Log.message( "The assignment count is " + assignmentCountFromUI, driver );
            if ( !assignmentCountFromUI.isEmpty() ) {
                for ( int assignmentCount = 1; assignmentCount <= Integer.parseInt( assignmentCountFromUI ); assignmentCount++ ) {
                    String ellipsedots = String.format( ellipsesAssignmentForgroupGrandRoot, assignmentCount );
                    WebElement element = driver.findElement( By.cssSelector( ellipsedots ) );
                    SMUtils.waitForElement( driver, element );
                    element.click();
                    Log.message( "Clicked the ellipse dots in assignment table", driver );
                    WebElement pauseElement = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( ellipsedots ) ), ellipsesAssignmentForGroupParent, pauseAssignmentForGroupChild );
                    pauseElement.click();
                    SMUtils.waitForElement( driver, confirmPopUpRoot );
                    Log.message( "Clicked the Confirm Popup button for pause the assignment", driver );
                    confirmPopUpRoot.click();
                }

            }
        } catch ( Exception e ) {
            Log.fail( "Group Assignments are not displayed properly!" );
        }
    }

    /**
     * Groups Page - Assignments SideNav - Verify 'Paused' badge is displayed
     * for paused assignments
     *
     * @param ''one or more course name
     */
    public boolean verifyAssignmentIsPaused( String... course ) {
        boolean assignmentPaused = false;
        try {
            SMUtils.waitForElement( driver, assignmentList, 30 );

            String assignmentCountFromUI = assignmentList.getAttribute( "childElementCount" );
            Log.message( "The assignment count is " + assignmentCountFromUI, driver );
            for ( int courseCount = 0; courseCount < course.length; courseCount++ ) {
                for ( int rowNumber = 1; rowNumber <= Integer.parseInt( assignmentCountFromUI ); rowNumber++ ) {
                    String titleElement = String.format( assginmentTitle, rowNumber );
                    String title = driver.findElement( By.cssSelector( titleElement ) ).getText();
                    if ( title.equals( course[courseCount] ) ) {
                        String assignmentBadgeNo = String.format( assginmentBadgeRoot, rowNumber );
                        WebElement badgeElement = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( assignmentBadgeNo ) ), assginmentBadgeChild );
                        SMUtils.waitForElement( driver, badgeElement, 15 );
                        if ( badgeElement.getText().equals( "Paused" ) ) {
                            assignmentPaused = true;
                        } else {
                            Log.message( "The assignment is not paused" );
                        }
                        break;
                    }

                }
            }
        } catch ( Exception e ) {
            Log.fail( "Group Assignments are not displayed properly!" );
        }

        return assignmentPaused;
    }

    /**
     * Groups Page - Assignments SideNav - Get assignment details
     *
     * @return ''Assignment details(Title,Date Assigned)
     */
    public HashMap<String, HashMap<String, String>> getAssignmentDetailsBasedOnGroupSubNav() {

        HashMap<String, HashMap<String, String>> AssignmentDetails = new HashMap<>();
        try {
            SMUtils.waitForElement( driver, assignmentList, 30 );
            String assignmentCountFromUI = assignmentList.getAttribute( "childElementCount" );
            Log.message( "The assignment count is " + assignmentCountFromUI, driver );
            if ( !assignmentCountFromUI.isEmpty() ) {
                for ( int assignmentCount = 1; assignmentCount <= Integer.parseInt( assignmentCountFromUI ); assignmentCount++ ) {
                    HashMap<String, String> studentDetails = new HashMap<String, String>();
                    studentDetails.clear();
                    studentDetails.put( Constants.ASSIGNMENT_TITLE, driver.findElement( By.cssSelector( String.format( assginmentTitle, assignmentCount ) ) ).getText() );
                    studentDetails.put( Constants.DATE_ASSIGNED, driver.findElement( By.cssSelector( String.format( dateAssigned, assignmentCount ) ) ).getText() );
                    AssignmentDetails.put( "Assignment" + assignmentCount, studentDetails );
                }
            } else {
                Log.message( "No Assignments present in group! ", driver, true );
            }
        } catch ( Exception e ) {
            Log.fail( "Group Assignments are not displayed properly!" );
        }
        return AssignmentDetails;

    }

    /**
     * Groups Page - Assignments SideNav - Click the view assignment button
     *
     * @param ''Course Name
     */
    public void clickViewAssignmentButtonBasedOnCourse( String courseName ) {
        try {
            SMUtils.clickJS( driver, iconTitleSort );
            String assignmentCountFromUI = assignmentList.getAttribute( "childElementCount" );
            SMUtils.waitForElement( driver, assignmentList, 15 );
            if ( !assignmentCountFromUI.isEmpty() ) {
                for ( int assignmentCount = 1; assignmentCount <= Integer.parseInt( assignmentCountFromUI ); assignmentCount++ ) {
                    String titleElement = String.format( assginmentTitle, assignmentCount );
                    String title = driver.findElement( By.cssSelector( titleElement ) ).getText();
                    if ( title.equals( courseName ) ) {
                        driver.findElement( By.cssSelector( String.format( viewAssignmentBtn, assignmentCount ) ) ).click();
                    }
                }
            } else {
                Log.message( "No Assignments present in group! ", driver, true );
            }
        } catch ( Exception e ) {
            Log.fail( "Group Assignments are not displayed properly!" );
        }

    }

    /**
     * Groups Page - Users SideNav - Return the webelement of Add Button
     *
     * @return AddStudents Button WebElement
     */
    public WebElement getUsersSubnavAddStudentsToGroupBtn() {
        SMUtils.waitForElement( driver, addStudentRoot );
        Log.message( "Get webelement for 'Add Students' button'", driver, true );
        WebElement addStudents = SMUtils.getWebElementDirect( driver, addStudentRoot, addStudentChild );
        return addStudents;
    }

    public String getGroupHeaderName() {
        String groupName = SMUtils.getTextOfWebElement( headerGroupName, driver );
        return groupName;
    }

    public boolean verifyStudentDetailsDisplayingInUsersTab( HashMap<String, HashMap<String, String>> studentDetails, String studentDetailsExp ) {
        boolean sudentDetails = false;
        boolean ss = studentDetails.containsValue( studentDetailsExp );
        for ( Map.Entry<String, HashMap<String, String>> entry : studentDetails.entrySet() ) {
            if ( entry.getValue().containsValue( studentDetailsExp ) ) {
                sudentDetails = true;
                break;
            }
        }
        return sudentDetails;
    }

    /**
     * Groups Page - get no data values if the table have no data to display
     *
     * @return ''No data values text
     */
    public Map<String, String> getUsersSubNavNoDataValues() {
        Map<String, String> noDataValues = new HashMap<>();
        SMUtils.waitForLocator( driver, By.cssSelector( groupUserZeroState ), 30 );
        noDataValues.put( "header", noUserHeader.getText() );
        noDataValues.put( "msg", noUserMsg.getText() );
        noDataValues.put( "link", noUserLink.getText() );
        return noDataValues;
    }

    /**
     * Create group with Home room group students.
     *
     * @param groupName
     * @param studentUserNames
     */
    public void createGroupWithHomeRoomStudents( String groupName, String studentUserNames ) {
        try {
            SMUtils.nap( 2 );
            SMUtils.waitForElementToBeClickable( getCreateGroupButton(), driver );
            SMUtils.clickJS( driver, getCreateGroupButton() );
            boolean isStudentAdded = false;
            SMUtils.nap( 2 );
            Log.message( "Create group popup loaded" );
            groupNameTextBox.sendKeys( groupName );
            SMUtils.nap( 2 );
            String[] studenUserName = studentUserNames.split( "," );
            for ( String studentUN : studenUserName ) {
                SMUtils.enterValue( searchGroupTextField, studentUN );
                isStudentAdded = addSelectedStudent( studentUN );
            }
            if ( isStudentAdded ) {
                Log.pass( "Student added - " + studentUserNames );
            } else {
                Log.pass( "Student not found in teacher roster -" + studentUserNames );
            }
            SMUtils.nap( 2 );
            SMUtils.waitForElementToBeClickable( getCreateButton(), driver );
            SMUtils.clickJS( driver, getCreateButton() );
            SMUtils.nap( 2 );
            if ( isGroupExist( groupName ) ) {
                Log.pass( "Group Created Successfully-" + groupName, driver );
            } else {
                Log.fail( "Error while creating the group with student", driver );
            }
        } catch ( Exception e ) {
            Log.message( "Error while creating the group with student", driver, true );
        }
    }

    /**
     * To click the add student to group
     */
    public void clickAddStudentToGroup() {
        WebElement addStudentToGroup = SMUtils.getWebElement( driver, addStudentToGroupParent, btnSecondary );
        SMUtils.clickJS( driver, addStudentToGroup );
        SMUtils.nap( 1 );
        Log.message( "Clicked add student to group button" );
    }

    // 43184 -methods
    /**
     * To verify the add student to group header
     */
    public String addStudentToGroupTitle() {
        SMUtils.waitForElement( driver, addStudentsToGroupPopupHeader );
        Log.message( addStudentsToGroupPopupHeader.getText() );
        Log.message( "Add Students to group title displayed " );
        return addStudentsToGroupPopupHeader.getText().trim();

    }

    /**
     * To get error message grade not selected after checked search all students
     * from our school
     */
    public String getErrorMessageGradeNotSelect() {
        //This button will not be there in 2022 system
        //   SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chBoxAllStudentfromSchoolRoot, chBoxAllStudentfromSchool ) );
        SMUtils.waitForElement( driver, gradeNotSelectedErrMsg );
        Log.message( "Grade not selected error message displayed properly" );
        String grade_errmsg = gradeNotSelectedErrMsg.getText().trim();
        return grade_errmsg;
    }

    /**
     * To get checked search all students with grade filter from our school
     */
    public void getCheckedWithGradeFilter() {
        //  SMUtils.waitForElement( driver, chBoxSearchAllStudent );
        // SMUtils.clickJS( driver, chBoxAllStudentfromSchoolRoot );
        //Log.message( "Checked the search all students in your school checkbox" );
        SMUtils.waitForElement( driver, gradeDropDown );
        SMUtils.clickJS( driver, gradeDropDown );
        Log.message( "Grade drop down clicked" );
        return;
    }

    /**
     * This method get all the students present in student listing Page.
     * 
     * @author vikas.pandey
     *
     * @return
     */
    public HashMap<String, List<String>> getAllStudentListFromAddStudent() {
        HashMap<String, List<String>> studentDetails = new HashMap<>();
        List<String> studentFN = new ArrayList<>();
        List<String> studentLN = new ArrayList<>();
        List<String> studentUN = new ArrayList<>();
        List<String> studentGrade = new ArrayList<>();

        int studentListSize = driver.findElements( By.cssSelector( studentListForAddStudentGrpBtn ) ).size();
        IntStream.range( 0, studentListSize ).forEach( studentCount -> {
            String[] temp;
            String delimiter = " ";

            temp = driver.findElement( By.cssSelector( String.format( studentListFNLN, studentCount + 1 ) ) ).getText().trim().split( delimiter );
            String Fname = temp[0];
            String Lname = temp[1];
            studentFN.add( Fname.trim() );
            studentLN.add( Lname.trim() );
            studentUN.add( driver.findElement( By.cssSelector( String.format( studentListstudent, studentCount + 1 ) ) ).getText().trim() );
            studentGrade.add( driver.findElement( By.cssSelector( String.format( StudentListGrade, studentCount + 1 ) ) ).getText().trim().substring( 1 ) );
        } );

        studentDetails.put( Constants.FIRSTNAME, studentFN );
        studentDetails.put( Constants.LASTNAME, studentLN );
        studentDetails.put( Constants.USER_NAME, studentUN );
        studentDetails.put( Constants.GRADE, studentGrade );
        Log.message( "Got all the student details: " + studentDetails );
        return studentDetails;
    }

    /**
     * Create group with overall school students
     *
     * @param groupName
     * 
     * @param grade
     */
    public void createGroupWithSchoolStudents( String groupName, String studentUserName, String grade ) {
        try {
            SMUtils.nap( 2 );
            SMUtils.waitForElementToBeClickable( getCreateGroupButton(), driver );
            SMUtils.clickJS( driver, getCreateGroupButton() );
            boolean isStudentAdded = false;
            SMUtils.nap( 2 );
            Log.message( "Create group popup loaded" );
            groupNameTextBox.sendKeys( groupName );
            String[] studenUserName = studentUserName.split( "," );
            for ( String singleName : studenUserName ) {
                SMUtils.enterValue( searchGroupTextField, singleName );
                isStudentAdded = addSelectedStudent( singleName );
                Log.message( "Student added-" + singleName );
            }
            if ( isStudentAdded ) {
                Log.pass( "Student added - " + studentUserName );
            } else {
                Log.pass( "Student not found in teacher roster -" + studentUserName );
            }
            SMUtils.nap( 2 );
            SMUtils.waitForElementToBeClickable( getCreateButton(), driver );
            SMUtils.clickJS( driver, getCreateButton() );
            SMUtils.nap( 2 );
            if ( isGroupExist( groupName ) ) {
                Log.pass( "Group Created and listed Successfully -" + groupName, driver );
            } else {
                Log.fail( "Error while creating the group with student", driver );
            }
        } catch ( Exception e ) {
            Log.message( "Error while creating the group with student", driver, true );

        }
    }

    /**
     * Create the empty group
     * 
     *
     * @param groupName
     */
    public void createGroupWithoutStudent( String groupName ) {
        try {
            SMUtils.waitForElementToBeClickable( getCreateGroupButton(), driver );
            SMUtils.clickJS( driver, getCreateGroupButton() );
            Log.message( "Create group popup loaded" );
            SMUtils.nap( 2 );
            groupNameTextBox.sendKeys( groupName );
            SMUtils.waitForElementToBeClickable( getCreateButton(), driver );
            SMUtils.click( driver, getCreateButton() );
            SMUtils.nap( 5 );
            SMUtils.waitForToastMessageToDisapper( driver );
            driver.navigate().refresh();
            SMUtils.fluentWaitForElement( driver, groupTableRows, 5 );
            if ( isGroupExist( groupName ) ) {
                Log.pass( "Group Created Successfully-" + groupName, driver );
            } else {
                Log.fail( "Error while creating the group with student", driver );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * Verify the group headers
     *
     *
     * @return
     */
    public boolean verifyGroupHeaders() {
        try {
            if ( SMUtils.isElementPresent( groupPageHeader ) ) {
                Log.pass( "Groups header displayed successfully!" );
            } else {
                Log.fail( "Group header not displayed successfully! - " + groupPageHeader.getText(), driver );
            }
            if ( SMUtils.isElementPresent( groupNameHeader ) ) {
                Log.pass( "Group name header displayed successfully!" );
            } else {
                Log.fail( "Group name header not displayed successfully! - " + groupNameHeader.getText(), driver );
            }
            if ( SMUtils.isElementPresent( noOfStudentsHeader ) ) {
                Log.pass( "# of students header displayed successfully!" );
            } else {
                Log.fail( "# of students header not displayed successfully! - " + noOfStudentsHeader.getText(), driver );
            }
            if ( SMUtils.isElementPresent( getCreateGroupButton() ) ) {
                Log.pass( "Create group button displayed successfully!" );

            } else {
                Log.fail( "Create group button not displayed successfully! - " + getCreateGroupButton().getText(), driver );
            }
            if ( SMUtils.isElementPresent( getViewGroupButton( 1 ) ) ) {
                Log.pass( "View group button displayed successfully!" );

            } else {
                Log.fail( "View group button not displayed successfully! - " + getCreateGroupButton().getText(), driver );
            }
            if ( Integer.parseInt( groupList.getAttribute( "childElementCount" ) ) > 0 ) {
                Log.pass( groupList.getAttribute( "childElementCount" ) + " Groups displayed successfully!" );
            } else {
                Log.fail( "No groups present in groups tab!" );
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * Get the list of groups in group listing page.
     * 
     *
     * @return
     */
    public List<String> getGroupNames() {
        List<String> groupsFromUI = new ArrayList<String>();
        String groups = groupList.getAttribute( "childElementCount" );

        IntStream.range( 0, Integer.parseInt( groups ) ).forEach( element -> {
            String groupNameFromUI = driver.findElement( By.cssSelector( String.format( GroupPage.groupName, 1 ) ) ).getText().trim();
            groupsFromUI.add( groupNameFromUI );
        } );

        Log.message( "Listed Groups - " + groupsFromUI );
        return groupsFromUI;
    }

    /**
     * To get all the groups from UI
     * 
     * @return
     */
    public List<String> getGroupNamesFromGroupsTab() {
        List<String> groupnames = new ArrayList<>();
        for ( WebElement groupname : groupNames ) {
            groupnames.add( groupname.getText() );
        }
        return groupnames;
    }

    /**
     * Edit the group
     * 
     *
     * @param updatedGroupName
     */
    public boolean editGroup( String updatedGroupName ) {
        boolean isGroupEdited = false;
        try {
        	SMUtils.nap(2);
            clickSettingsSubNav();
            txtBoxEditGroup.clear();
            txtBoxEditGroup.sendKeys( updatedGroupName );
            SMUtils.clickJS( driver, getSaveButton() );
            SMUtils.nap( 3 );
            SMUtils.clickJS( driver, assignmentsSideBar );
            Log.message( "Navigated assignments sub menu" );
            SMUtils.nap( 3 );
            if ( lblGroupNameFromViewGroup.getText().equals( updatedGroupName ) ) {
            	isGroupEdited=true;
                Log.message( "Group name updated successfully! New group Name - " + updatedGroupName, driver, true );
            } else {
            	isGroupEdited=false;
                Log.fail( "Error in updating the group! or Group name must be between 3 and 75 characters!" );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        
        return isGroupEdited;
    }

    /**
     * Delete the group
     * 
     *
     * @param groupName
     */
    public boolean deleteGroup( String groupName ) {
        boolean isGroupDeleted = false;
        try {
            clickSettingsSubNav();
            SMUtils.nap( 1 );
            SMUtils.clickJS( driver, getDeleteButton() );
            SMUtils.nap( 4 );
            SMUtils.checkBackgroundColor( getDeleteButtonPopup(), Constants.BUTTON_COLOR_CODE );
            Log.message( "Delete button color code is displayed as " + Constants.BUTTON_COLOR_CODE );
            SMUtils.clickJS( driver, getDeleteButtonPopup() );
            SMUtils.nap( 2 );
            if ( !isGroupExist( groupName ) ) {
            	isGroupDeleted=true;
                Log.message( "Group deleted successfully!" );
            } else {
            	isGroupDeleted=false;
                Log.fail( "Error in deleting the group!" );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isGroupDeleted; 
    }

    /**
     * To get the error message of group name field
     * 
     *
     * @return
     */
    public String getErrorMessageForGroupName() {
        return errorMessageForGroupName.getText();
    }

    /**
     * To get the zero state page message.
     * 
     *
     * @return
     */

    public String getZeroStateAssignmentMessage() throws InterruptedException {
        SMUtils.waitForSpinnertoDisapper( driver );
        SMUtils.waitForElement( driver, lblZeroState );
        return lblZeroState.getText();
    }

    /**
     * To get the create group button
     * 
     *
     * @return
     */
    public WebElement getCreateGroupButton() {
        try {
            SMUtils.nap( 2 );
            WebElement createGroup = SMUtils.getWebElementDirect( driver, btnCreateGroupRoot, btnPrimary );
            return createGroup;
        } catch ( Exception e ) {
            WebElement createGroup = SMUtils.getWebElementDirect( driver, btnCreateGroupRoot, btnPrimary );
            return createGroup;
        }
    }

    /**
     * To get the create button from popup.
     * 
     *
     * @return
     */
    public WebElement getCreateButton() {
        WebElement createGroup = SMUtils.getWebElementDirect( driver, btnCreateRoot, btnPrimary );
        return createGroup;
    }

    /**
     * To add the students to group.
     *
     * @param studentUserName
     * @return
     */
    public boolean addSelectedStudent( String studentUserName ) {
        boolean isStudentAdded = false;
        try {
            int studentList = driver.findElements( By.cssSelector( studentListForAddStudentGrpBtn ) ).size();
            String userName = null;
            for ( int i = 0; i < ( studentList ); i++ ) {
                userName = driver.findElement( By.cssSelector( String.format( studentListstudent, i + 1 ) ) ).getText();
                if ( userName.trim().equals( studentUserName ) ) {
                    SMUtils.clickJS( driver, getAddButton( i + 1 ) );
                    isStudentAdded = true;
                    break;
                } else {
                    isStudentAdded = false;
                }
            }
            Log.message( "Added selected student - " + studentUserName );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isStudentAdded;
    }

    /**
     * Verify the group is exists.
     * 
     *
     * @param groupName
     * @return
     * @throws Exception
     */

    public boolean isGroupExist( String groupName ) throws Exception {
        SMUtils.waitForSpinnertoDisapper( driver, 20 );
        SMUtils.fluentWaitForElement( driver, groupTableRows, 10 );
        try {
            JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
            String scriptForGroupListNames = "var list = document.querySelectorAll('tbody.table-body tr.table-row.highlight-on-hover td span'); var grpNames = []; for ( let i=0 ; i <list.length; i=i+2 ) {grpNames.push(list[i].getAttribute('title') );}; { return grpNames;}";

            List<String> groupNameList = (List<String>) javascriptExecutor.executeScript( scriptForGroupListNames );
            int size = groupNameList.size();
            int index = groupNameList.indexOf( groupName );
            return ( groupNameList.contains( groupName ) ) ? true : false;
        } catch ( Exception e ) {
            Log.exception( e );
            return false;
        }
    }

    /**
     * To get the student count from group.
     *
     * @param groupName
     * @return student count
     */
    public String getStudentsCount( String groupName ) {
        String groups = groupList.getAttribute( "childElementCount" );
        String groupNameFromUI;
        String studentCount = null;
        for ( int groupCount = 0; groupCount < Integer.parseInt( groups ); groupCount++ ) {
            groupNameFromUI = driver.findElement( By.cssSelector( String.format( GroupPage.groupName, groupCount + 1 ) ) ).getText().trim();
            if ( groupNameFromUI.equals( groupName ) ) {
                studentCount = driver.findElement( By.cssSelector( String.format( groupStudentCount, groupCount + 1 ) ) ).getText().trim();
                break;
            }
        }
        Log.message( "Group count - " + studentCount );
        return studentCount;
    }

    /**
     * Select all students from school checkbox and selects grade.
     * 
     *
     * @param gradeName
     */
    public String clickAllStudentsAndSelectGrade( String gradeName ) {
        try {
            // SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chBoxAllStudentfromSchoolRoot, chBoxAllStudentfromSchool ) );
            // selectGrade( gradeName );
            SMUtils.waitForElement( driver, gradeDropDown );
            SMUtils.clickJS( driver, gradeDropDown );
            Log.message( "drop down clicked" );
            selectGradeFromAddStudPopup( gradeName );
            Log.message( "Clicked all students check box and selecting grade - " + gradeName );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return gradeName;
    }

    /**
     * Selects grade.
     * 
     *
     * @param gradeName
     */
    public void selectGrade( String gradeName ) {
        try {
            SMUtils.waitForElement( driver, gradeDropDown, 5 );
            SMUtils.clickJS( driver, gradeDropDown );
            SMUtils.waitForElement( driver, allGrades, 5 );
            String gradesCount = allGrades.getAttribute( "childElementCount" );
            if ( gradesCount.length() > 0 ) {
                Log.pass( "Grade dropdown displayed!", driver );
            } else {
                Log.fail( "Grade dropdown not displayed!", driver );
            }
            WebElement gradeElement = null;
            for ( int i = 1; i <= Integer.parseInt( gradesCount ); i++ ) {
                String gradeFromUI = driver.findElement( By.cssSelector( String.format( grade, i + 2 ) ) ).getText();
                gradeElement = driver.findElement( By.cssSelector( String.format( grade, i + 2 ) ) );
                if ( gradeName.contains( "Grade K" ) ) {
                    gradeFromUI = driver.findElement( By.cssSelector( String.format( grade, 2 ) ) ).getText();
                    gradeElement = driver.findElement( By.cssSelector( String.format( grade, 2 ) ) );
                } else if ( gradeName.contains( "All Grades" ) ) {
                    gradeFromUI = driver.findElement( By.cssSelector( String.format( grade, 1 ) ) ).getText();
                    gradeElement = driver.findElement( By.cssSelector( String.format( grade, 1 ) ) );
                } else if ( gradeName.contains( "Not Specified" ) ) {
                    gradeFromUI = driver.findElement( By.cssSelector( String.format( grade, 15 ) ) ).getText();
                    gradeElement = driver.findElement( By.cssSelector( String.format( grade, 15 ) ) );
                }

                if ( gradeName.equals( gradeFromUI ) ) {
                    SMUtils.clickJS( driver, gradeElement );
                    break;
                }
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * To Select grade
     * 
     * 
     */
    public void selectGradeFromAddStudPopup( String selectedGrade ) {
        for ( WebElement grade : listofGrades ) {
            String elementText = grade.getText();
            if ( elementText.equals( selectedGrade ) ) {
                SMUtils.scrollIntoView( driver, grade );
                SMUtils.clickJS( driver, grade );
                break;
            }
        }
        Log.message( "Selected the Grade: " + selectedGrade );
    }

    /**
     * Verify the Grade Dropdown in Create Group Popup
     * 
     * @return
     */
    public boolean verifyGradeDropdown() {
        SMUtils.fluentWaitForElement( driver, listofGrades.get( 0 ), 3 );
        List<String> gradeValues = listofGrades.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() );
        gradeValues.remove( "All Grades" );
        return new SMUtils().compareTwoList( gradeValues, Students.ALL_GRADES );
    }

    /**
     * View group based on group name
     * 
     *
     * @param groupName
     */
    public void viewGroup( String groupName ) {
        try {

            SMUtils.waitForElement( driver, groupList, 5 );
            String groups = groupList.getAttribute( "childElementCount" );
            String groupNameFromUI;
            Boolean groupExist = false;
            for ( int groupCount = 0; groupCount < Integer.parseInt( groups ); groupCount++ ) {
                groupNameFromUI = driver.findElement( By.cssSelector( String.format( GroupPage.groupName, groupCount + 1 ) ) ).getText();
                Log.message( "groupNameFromUI: " + groupNameFromUI );
                if ( groupNameFromUI.trim().equals( groupName ) ) {
                    WebElement viewGroupBtn = getViewGroupButton( groupCount + 1 );
                    SMUtils.waitForElementToBeClickable( viewGroupBtn, driver );
                    SMUtils.clickJS( driver, getViewGroupButton( groupCount + 1 ) );
                    Log.message( "Group " + groupName + " viewed successfully!" );
                    groupExist = true;
                    break;
                }
            }
            SMUtils.waitForElement( driver, usersHeader );
            if ( !groupExist ) {
                Log.message( "Group name not exists!  " + groupName );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * To get all the students from create group popup
     * 
     * @param groupName
     * @return
     * 
     */
    public HashMap<String, HashMap<String, String>> getStudentDetailsBasedOnGroup( String groupName ) {

        HashMap<String, HashMap<String, String>> AllStudentDetails = new HashMap<>();
        try {
            clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupStudentList, 30 );
            SMUtils.clickJS( driver, iconUserNameSort );
            SMUtils.waitForElementToBeClickable( groupStudentList, driver );
            String studentCountFromUI = groupStudentList.getAttribute( "childElementCount" );
            if ( !studentCountFromUI.isEmpty() ) {
                for ( int studentCount = 1; studentCount <= Integer.parseInt( studentCountFromUI ); studentCount++ ) {
                    HashMap<String, String> studentDetails = new HashMap<String, String>();
                    studentDetails.clear();
                    studentDetails.put( Constants.FIRSTNAME, driver.findElement( By.cssSelector( String.format( studentFN, studentCount ) ) ).getText() );
                    studentDetails.put( Constants.LASTNAME, driver.findElement( By.cssSelector( String.format( studentLN, studentCount ) ) ).getText() );
                    studentDetails.put( Constants.USER_NAME, driver.findElement( By.cssSelector( String.format( studentUN, studentCount ) ) ).getText() );
                    studentDetails.put( Constants.STUDENT_ID, driver.findElement( By.cssSelector( String.format( studentID, studentCount ) ) ).getText() );
                    studentDetails.put( Constants.GRADE, driver.findElement( By.cssSelector( String.format( studentGrade, studentCount ) ) ).getText() );
                    AllStudentDetails.put( "Student" + studentCount, studentDetails );
                }
            } else {
                Log.message( "No student present in group! ", driver, true );
            }
        } catch ( Exception e ) {
            Log.fail( "Group students are not dispalyed properly! - Actual: " + AllStudentDetails, driver );
        }
        return AllStudentDetails;

    }

    /**
     * To get all the students from add student to group popup
     *
     * @param groupName
     * @return
     * 
     */
    public HashMap<String, HashMap<String, String>> getStudentListBasedOnGroup( String groupName ) {

        HashMap<String, HashMap<String, String>> AllStudentDetails = new HashMap<>();
        try {
            SMUtils.waitForLocator( driver, By.cssSelector( usersTable ), 30 );
            SMUtils.clickJS( driver, iconUserNameSort );
            SMUtils.waitForElementToBeClickable( groupStudentList, driver );
            String studentCountFromUI = groupStudentList.getAttribute( "childElementCount" );
            if ( !studentCountFromUI.isEmpty() ) {
                for ( int studentCount = 1; studentCount <= Integer.parseInt( studentCountFromUI ); studentCount++ ) {
                    HashMap<String, String> studentDetails = new HashMap<String, String>();
                    studentDetails.clear();
                    studentDetails.put( Constants.FIRSTNAME, driver.findElement( By.cssSelector( String.format( studentFN, studentCount ) ) ).getText() );
                    studentDetails.put( Constants.LASTNAME, driver.findElement( By.cssSelector( String.format( studentLN, studentCount ) ) ).getText() );
                    studentDetails.put( Constants.USER_NAME, driver.findElement( By.cssSelector( String.format( studentUN, studentCount ) ) ).getText() );
                    studentDetails.put( Constants.STUDENT_ID, driver.findElement( By.cssSelector( String.format( studentID, studentCount ) ) ).getText() );
                    studentDetails.put( Constants.GRADE, driver.findElement( By.cssSelector( String.format( studentGrade, studentCount ) ) ).getText() );
                    AllStudentDetails.put( "Student" + studentCount, studentDetails );
                }
            } else {
                Log.message( "No student present in group! ", driver, true );
            }
        } catch ( Exception e ) {
            Log.fail( "Group students are not dispalyed properly! - Actual: " + AllStudentDetails, driver );
        }
        return AllStudentDetails;

    }

    /**
     * Common functions for clicking the Groups side nav
     */
    public void clickGroupsSubNav( String sideNavName ) {
        List<WebElement> sideNavEle = driver.findElements( By.cssSelector( siedNavCommon ) );
        for ( WebElement sideNav : sideNavEle ) {
            String sideNavBar = sideNav.getText().trim();
            if ( sideNavBar.equals( sideNavName ) ) {
                SMUtils.waitForElement( driver, sideNav );
                SMUtils.clickJS( driver, sideNav );
                Log.message( sideNavBar + " sub nav-bar is clicked" );
                break;
            }
        }
    }

    public void clickAssignmentSideSubNav() throws Exception {
        SMUtils.waitForElement( driver, assignmentsSideBar );
        SMUtils.clickJS( driver, assignmentsSideBar );
    }

    /**
     * To get the view group button
     *
     * @param groupCount
     * @return
     */
    private WebElement getViewGroupButton( int groupCount ) {
        WebElement viewButtonRoot = driver.findElement( By.cssSelector( String.format( viewGroupRoot, groupCount ) ) );
        WebElement viewGroup = SMUtils.getWebElementDirect( driver, viewButtonRoot, btnSecondary );
        return viewGroup;
    }

    /**
     * To click settings sub nav
     */
    public void clickSettingsSubNav() {
        for ( WebElement sideNav : settingsSideBar ) {
            String sideNavBar = sideNav.getText().trim();
            if ( sideNavBar.equals( Constants.SETTINGS ) ) {
                SMUtils.waitForElementToBeClickable( sideNav, driver );
                SMUtils.waitForElement( driver, sideNav );
                SMUtils.clickJS( driver, sideNav );
                Log.message( sideNavBar + " sub nav-bar is clicked" );
            }
        }
    }

    /**
     * To get all students check box
     * 
     *
     * @return
     */
    @Deprecated
    public WebElement getAllStudentsCheckBox() {
        WebElement viewGroup = SMUtils.getWebElementDirect( driver, chBoxAllStudentfromSchoolRoot, chBoxAllStudentfromSchool );
        return viewGroup;
    }

    /**
     * To get i icon
     * 
     *
     * @return
     */
    public WebElement getiIcon() {
        return iconI;
    }

    /**
     * Clicking i icon
     */
    public void clickiIcon() {
        SMUtils.clickJS( driver, getiIcon() );
        Log.message( "Clicked i icon" );
        SMUtils.nap( 5 ); // Waiting for help page switch and load
    }

    /**
     * To get cancel button
     * 
     *
     * @return
     */
    public WebElement getCancelButton() {
        return SMUtils.getWebElementDirect( driver, btnCancelRoot, btnSecondary );
    }

    /**
     * To click cancel button in Create Group Popup
     */
    public void clickCancelButtonInCreateGroup() {
        SMUtils.click( driver, getCancelButton() );
        Log.message( "Clicked Cancel Button in Create Group Popup" );
    }

    /**
     * To get cancel button in Delete Group PopUp
     * 
     *
     * @return
     */
    public WebElement getCancelButtonDeleteGroup() {
        return SMUtils.getWebElementDirect( driver, btnCancelRootpopup, btnSecondary );
    }

    /**
     * To get save button.
     * 
     *
     * @return
     */
    public WebElement getSaveButton() {
        return SMUtils.getWebElementDirect( driver, btneditGroupSettingsSaveRoot, btnPrimary );
    }

    /**
     * To get delete button.
     * 
     *
     * @return
     */
    public WebElement getDeleteButton() {
        return SMUtils.getWebElementDirect( driver, btndeleteGroupRoot, btnSecondary );
    }

    /**
     * To get group name text box
     * 
     *
     * @return
     */
    public WebElement getGroupNameTxtBox() {
        return groupNameTextBox;
    }

    /**
     * To get add student button
     * 
     *
     * @return
     */
    public WebElement getAddStudentTxtBox() {
        return addStudentTxtBox;
    }

    /**
     * To get delete group button
     *
     *
     * @return
     */
    private WebElement getDeleteButtonPopup() {
        WebElement saveButton = SMUtils.getWebElementDirect( driver, btnDeleteFromPopUpRoot, btnPrimary );
        return saveButton;
    }

    /**
     * To get add group button
     * 
     *
     * @param index
     * @return
     */
    private WebElement getAddButton( Integer index ) {
        WebElement addButton = driver.findElement( By.cssSelector( String.format( btnAdd, index.toString() ) ) );
        WebElement addButtonForStudent = SMUtils.getWebElementDirect( driver, addButton, btnSecondary );
        return addButtonForStudent;
    }

    /**
     * To get remove student to group button
     *
     * @param index
     * @return
     */
    private WebElement getOnRemoveBtn( Integer index ) {
        WebElement remove = driver.findElement( By.cssSelector( String.format( btnRemove, index.toString() ) ) );
        WebElement removebtn = SMUtils.getWebElementDirect( driver, remove, btnSecondary );
        return removebtn;
    }

    /**
     * To get remove student to group button
     *
     * 
     * @return
     * @return
     */
    public Boolean clickChipTxtCloseBtn() {
        Boolean status = false;
        try {
            for ( WebElement closeBtn : addStudGroupCloseBtnX ) {
                WebElement removebtn = SMUtils.getWebElementDirect( driver, closeBtn, addStudGroupcloseBtnchild );
                SMUtils.clickJS( driver, removebtn );

            }
            status = true;
            Log.message( "close button clicked successfully" );

        } catch ( Exception e ) {
            Log.message( "close button not clicked successfully" );

        }
        return status;
    }

    /**
     * To get all the All Assignments from Groups --> Assignments sub-nav
     * 
     *
     * 
     * 
     * @return
     */
    public HashMap<String, HashMap<String, String>> getAssignmentDetailsBasedOnGroup() {

        HashMap<String, HashMap<String, String>> AllAssignmentDetails = new HashMap<>();
        try {
            SMUtils.waitForElement( driver, assignmentsSideBar );
            SMUtils.clickJS( driver, assignmentsSideBar );
            SMUtils.waitForElement( driver, assignmentsList );
            int assignmentCount = 0;
            String assignmentCountFromUI = assignmentsList.getAttribute( "childElementCount" );
            if ( !assignmentCountFromUI.isEmpty() ) {
                for ( assignmentCount = 1; assignmentCount <= Integer.parseInt( assignmentCountFromUI ); assignmentCount++ ) {
                    HashMap<String, String> assignmentDetails = new HashMap<String, String>();
                    assignmentDetails.clear();
                    assignmentDetails.put( Constants.GroupsAssignments.TITLE, driver.findElement( By.cssSelector( String.format( AssignemntTitle, assignmentCount ) ) ).getText() );
                    assignmentDetails.put( Constants.GroupsAssignments.DATEASSIGNED, driver.findElement( By.cssSelector( String.format( AssignmentDateAssigned, assignmentCount ) ) ).getText() );
                    AllAssignmentDetails.put( "Assignments" + assignmentCount, assignmentDetails );
                }
                Log.message( "Groups Assignments are displayed properly!" );
            } else {
                Log.message( "No Assignment present in group! ", driver, true );
            }
        } catch ( Exception e ) {
            Log.fail( "Group Assignments are not dispalyed properly! - Actual: " + AllAssignmentDetails, driver );
        }
        return AllAssignmentDetails;
    }

    /**
     * Clicking Three-dot ellipses based on Assignment Name
     * 
     *
     * @param assignmentName
     */
    public void clickThreeDotEllipsesonAssignment( String assignmentName ) {
        Log.message( "Clicking on Three-dot Ellipses" );
        try {
            String Assignments = assignmentsList.getAttribute( "childElementCount" );
            String AssignmentNameFromUI;
            Boolean assignmentExist = false;
            for ( int assignmentCount = 0; assignmentCount <= Integer.parseInt( Assignments ); assignmentCount++ ) {
                AssignmentNameFromUI = driver.findElement( By.cssSelector( String.format( GroupPage.assignmentName, assignmentCount + 1 ) ) ).getText();
                if ( AssignmentNameFromUI.equals( assignmentName ) ) {
                    SMUtils.clickJS( driver, getthreeDotEllipses( assignmentCount + 1 ) );
                    Log.message( "Assignment " + assignmentName + "clicked three-dot Ellipses!" );
                    assignmentExist = true;
                    break;
                }
            }
            if ( !assignmentExist ) {
                Log.message( "Assignment name not exists!" );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * Web element for three-dot ellipses
     * 
     */
    private WebElement getthreeDotEllipses( int AssigmentCount ) {
        WebElement Ellipses = driver.findElement( By.cssSelector( String.format( threeDotEllipsesRoot, AssigmentCount ) ) );
        return Ellipses;
    }

    // Clicking on DeleteAssignment button in the three-dot ellipses method
    public void clickDeleteAssignmentonThreeDotEllipses() {
        Log.message( "Clicking on Delete Assignment button on three dot ellipses" );
        SMUtils.clickJS( driver, getThreeDotDeleteAssignmentButton() );
    }

    // Getting the locator for Delete Assignment button from three-dot ellipses
    private WebElement getThreeDotDeleteAssignmentButton() {
        WebElement DeleteAssign = SMUtils.getWebElementDirect( driver, ellipsesRoot, DeleteAssignmentBtnParent );
        WebElement ThreeDotDeleteAssignmentButton = SMUtils.getWebElementDirect( driver, DeleteAssign, DeleteAssignmentchild );
        return ThreeDotDeleteAssignmentButton;
    }

    /**
     * Verify the DeleteAssignment pop-up is loaded.
     * 
     *
     * @return
     */
    public boolean isDeleteAssignmentPopupLoaded() {
        try {
            SMUtils.nap( 2 );
            if ( SMUtils.isElementPresent( deleteAssignmentpopup ) ) {
                Log.message( "Groups Delete Assignments pop-up displayed successfully!" );
            } else {
                Log.fail( "Groups Delete Assignments pop-up displayed successfully!" );
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To get the Delete Assignment pop-up message.
     * 
     *
     * @return pop-up message
     */
    public String isDeleteAssignmentPopupMessageDisplayed() {
        String popupMessage = null;
        SMUtils.waitForElement( driver, deletepopupHeadsup );
        try {
            if ( SMUtils.isElementPresent( deletepopupHeadsup ) && SMUtils.isElementPresent( deletepopupHeadsupMessage ) ) {
                popupMessage = deletepopupHeadsup.getText() + deletepopupHeadsupMessage.getText();
                Log.message( "Delete Assignemnt pop-up Message: " + popupMessage );

            } else {
                Log.fail( "Delete Assignment pop-up message is not getting displayed" );
            }
        } catch ( Exception e ) {}
        return popupMessage;
    }

    /**
     * Deleting the GroupAssignment
     * 
     * <p>
     * return
     */
    public boolean deleteGroupAssignment() {

        WebElement deleteAssignmentBtn = SMUtils.getWebElement( driver, DeleteButtonparent, btnPrimary );
        SMUtils.waitForElement( driver, deleteAssignmentBtn );
        try {
            if ( SMUtils.isElementPresent( deleteAssignmentBtn ) ) {
                Log.message( "Delete Assignment button is displayed successfully!" );
                SMUtils.clickJS( driver, deleteAssignmentBtn );
                Log.message( "Clicked delete button!" );
            } else {
                Log.fail( "Delete Assignment button is not getting displayed!" );
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * Clicking cancel button on Delete Assignment pop-up
     * 
     * <p>
     * return
     */
    public boolean clickCancelButtononDeleteAssignmentPopup() {

        WebElement cancelDeleteAssignmentBtn = SMUtils.getWebElement( driver, cancelDeleteAssignmentButtonparent, btnSecondary );
        SMUtils.waitForElement( driver, cancelDeleteAssignmentBtn );
        try {
            if ( SMUtils.isElementPresent( cancelDeleteAssignmentBtn ) ) {
                Log.message( "Cancel button is getting displayed successfully!" );
                SMUtils.clickJS( driver, cancelDeleteAssignmentBtn );
                Log.message( "Clicked cancel button!" );
                if ( SMUtils.isElementPresent( ellipsesRoot ) )
                    Log.message( "The assignment is not getting deleted after clicking on cancel button" );
                else
                    Log.message( "The assignment is getting deleted even after clicking the cancel button" );
            } else {
                Log.fail( "Cancel button is not getting displayed!" );
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * Clicking X button on Delete Assignment pop-up
     * 
     * <p>
     * return
     */
    public boolean clickingXButtoninDeleteAssignmentPopup() {
        SMUtils.waitForElement( driver, XDeleteAssignmentButtonparent );
        try {
            if ( SMUtils.isElementPresent( XDeleteAssignmentButtonparent ) ) {
                Log.message( "X button is getting displayed successfully!" );
                SMUtils.clickJS( driver, XDeleteAssignmentButtonparent );
                Log.message( "Clicked 'X' button!" );
                if ( SMUtils.isElementPresent( ellipsesRoot ) )
                    Log.message( "The assignment is not getting deleted after clicking on X button" );
                else
                    Log.fail( "The assignment is getting deleted even after clicking the X button" );
            } else {
                Log.fail( "X button is not getting displayed!" );
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * Clicking create new group button
     * 
     * return
     */
    public void clickCreateNewGroupBtn() {
        SMUtils.waitForElement( driver, btnCreateGroupRoot );
        SMUtils.clickJS( driver, getCreateGroupButton() );
        Log.message( "Create Button clicked" );

    }

    /**
     * To click on the hovered add student chip text
     *
     * @param groupName
     * @return
     */
    public void clickonHoveredChipTxt( String groupName ) {
        // This nap is required for Safari
        SMUtils.nap( 5 );
        try {
            listAddStudChipTxt.stream().forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( groupNameDetail -> {
                if ( groupName.equals( groupNameDetail ) ) {
                    SMUtils.moveToElementSelenium( driver, element );
                    SMUtils.clickJS( driver, element );
                }
            } ) );
        } catch ( StaleElementReferenceException | NoSuchElementException e ) {
            Log.message( "Assignment selected is " + groupName );
        }
    }

    /**
     * To verify the Group name from the settings section of the group
     *
     * @param groupName
     * @return To Pass Group Name in the field
     * 
     * 
     * 
     */

    public void enterGroupNameinPopup( String groupName ) {
        SMUtils.waitForElement( driver, groupNameTextBox );
        groupNameTextBox.clear();
        groupNameTextBox.sendKeys( groupName );
        Log.message( "Group Name Passed in to text field Successfully " );
    }

    /**
     * To click create button
     * 
     * 
     */

    public void clickCreateButton() {
        SMUtils.waitForElement( driver, getCreateButton() );
        SMUtils.clickJS( driver, getCreateButton() );
        Log.message( "Create Button clicked successfully" );
        SMUtils.nap( 1 );
    }

    /**
     * To add text Name in the field
     * 
     * @throws InterruptedException
     * 
     * 
     */

    public void addNameInTextField( String studentUserName ) {
        SMUtils.waitForElement( driver, getAddStudentTxtBox() );
        SMUtils.enterValue( getAddStudentTxtBox(), studentUserName );
        Log.message( " " + studentUserName + " Added in the textfield " );

    }

    /**
     * To clear add student text field
     * 
     * 
     */

    public void clearAddStudentTextField() {
        SMUtils.waitForElement( driver, getAddStudentTxtBox() );
        getAddStudentTxtBox().clear();
        Log.message( "text Field cleared" );
    }

    /**
     * To add multiple students
     * 
     * 
     */
    @Deprecated
    public void addMultipleStudents( int noOfUsers ) {
        String teacherDetails1 = DataSetup.teacherDetailsMap.get( "Teacher60" );
        String username1 = SMUtils.getKeyValueFromResponse( teacherDetails1, "data,userId" );
        HashMap<String, String> stuDetails1 = new LinkedHashMap<>();
        for ( int username = 1; username < DataSetupConstants.STUDENT_COUNT; username++ ) {
            String studentDetails1 = DataSetup.teacherStudentMap.get( username1 ).get( "Student" + username + "" );
            String stuUserName2 = SMUtils.getKeyValueFromResponse( studentDetails1, "data,userName" );
            stuDetails1.put( "Student" + username + "", stuUserName2 );
        }
        for ( int username = 1; username <= noOfUsers; username++ ) {
            addSelectedStudent( stuDetails1.get( "Student" + username + "" ) );
            Log.message( "Selected student added" );
        }
    }

    /**
     * To add multiple students to group
     * 
     * @param studentUserNames
     */
    public void addMultipleStudents( List<String> studentUserNames, int count ) {

        IntStream.rangeClosed( 0, count ).forEach( studentCount -> {
            addSelectedStudent( studentUserNames.get( studentCount ) );
            Log.message( "Selected student added" );
        } );

    }

    /**
     * To Click Add Button
     * 
     * 
     */
    public void clickAddButton() {
        SMUtils.waitForElement( driver, addButtonRoot );
        WebElement addButton = SMUtils.getWebElementDirect( driver, addButtonRoot, btnSecondary );
        SMUtils.waitForElementToBeClickable( addButton, driver );
        SMUtils.clickJS( driver, addButton );
        Log.message( "Clicked Add Button" );
    }

    /**
     * To click Search All Student CheckBox
     * 
     * 
     */
    @Deprecated
    public void clickSearchAllStudentCheckBox() {
        SMUtils.waitForElement( driver, chBoxAllStudentfromSchoolRoot );
        WebElement checkBox = SMUtils.getWebElementDirect( driver, chBoxAllStudentfromSchoolRoot, chBoxAllStudentfromSchool );
        SMUtils.clickJS( driver, checkBox );
        Log.message( "Clicked Check box for Search All Students" );
    }

    /**
     * To Select AllGrades From DropDown
     * 
     * 
     */
    public void SelectAllGradesFromDropDown( String optionName ) {
        SMUtils.waitForElement( driver, gradeDropDownRoot );
        WebElement DropDown = SMUtils.getWebElementDirect( driver, gradeDropDownRoot, selectAllgradeDropDownChild );
        SMUtils.clickJS( driver, DropDown );
        Log.message( "Clicked the Select Grade Drop Down Button" );
        WebElement allGradesOption = listOfGradesDropDown.stream().filter( gradeDropDown -> gradeDropDown.getText().trim().equals( optionName ) ).findAny().orElse( null );
        if ( Objects.nonNull( allGradesOption ) ) {
            SMUtils.clickJS( driver, allGradesOption );
            Log.message( "All Grades Option selected from the dropdown" );
        } else {
            Log.message( "Option not present in the drop down" );
        }

    }

    /**
     * To Add Assignment to group
     * 
     * div.list-data div.student-info
     */

    public void addAssigmentToGrp( String groupName ) {
        SMUtils.nap( 2 );// Waiting for popup to load
        WebElement stuWebEle = parentElementAddAssignPopUp.stream().filter( element -> element.findElement( By.cssSelector( grpNameAddAssignToGrpPopUp ) ).getText().trim().equals( studentID ) ).findFirst().orElse( null );
        if ( Objects.nonNull( stuWebEle ) ) {
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, stuWebEle.findElement( By.cssSelector( addBtnRootAddassignToGrp ) ), btnSecondary ) );
            Log.message( "Student Added Successfully" );
        }

    }

    /**
     * To Add group name in search field
     * 
     * 
     */
    public void addGroupNameInSearchField( String gName ) {
        SMUtils.waitForElement( driver, searchGroupTextField );
        searchGroupTextField.sendKeys( gName );
        clickAddBtnOnAssignPoPUp();
        Log.message( "Group Name is passed in to field and selected" );
    }

    /**
     * To click Add Btn On AssignPoPUp
     * 
     * 
     */

    public void clickAddBtnOnAssignPoPUp() {
        SMUtils.waitForElement( driver, addBtnInAssignPoPUpRoot );
        WebElement addBtn = SMUtils.getWebElementDirect( driver, addBtnInAssignPoPUpRoot, btnSecondary );
        SMUtils.clickJS( driver, addBtn );
        Log.message( "Add Button Clicked" );
    }

    /**
     * To click Assignment side bar
     * 
     * 
     */

    public void clickAssignmentSideBar() {
        SMUtils.waitForElement( driver, assignmentsSideBar );
        SMUtils.clickJS( driver, assignmentsSideBar );
        Log.message( "Assignment side Bar is clicked" );
    }

    /**
     * To check is Assignment Available Fo Group
     * 
     * 
     */

    public Boolean isAssignmentAvailableForGroup( String assignmentName ) {
        SMUtils.nap( 1 ); // Wait for page to load
        Boolean status = false;
        WebElement assignment = assignmentDetailsInGroupTab.stream().filter( gradeDropDown -> gradeDropDown.getText().trim().equals( assignmentName ) ).findAny().orElse( null );
        if ( Objects.nonNull( assignment ) ) {
            status = true;
            Log.message( "Assignment Found in the Group" );
        } else {
            Log.message( "Option not present in the drop down" );
        }
        return status;
    }

    /**
     * To select CheckBox For Student
     * 
     * 
     */

    public void selectCheckBoxForStudent( String studentID ) {
        StudentsPage stuPage = new StudentsPage( driver );
        List<WebElement> studentIDs = stuPage.listStudentID;
        for ( int stuId = 0; stuId < studentIDs.size(); stuId++ ) {
            String stuID = studentIDs.get( stuId ).getText().trim();
            if ( stuID.equals( studentID ) ) {
                WebElement checkBox = SMUtils.getWebElementDirect( driver, allCheckBoxRoot.get( stuId ), checkBoxchild );
                SMUtils.clickJS( driver, checkBox );
                Log.message( "Check Box Clicked Successfully" );
                break;
            }
        }
    }

    /**
     * To Click Group Tab Button
     * 
     * 
     */

    public void clickGrouptabButton() {
        SMUtils.waitForElement( driver, groupButtonRoot );
        WebElement grpBtn = SMUtils.getWebElementDirect( driver, groupButtonRoot, btnSecondary );
        SMUtils.clickJS( driver, grpBtn );
        Log.message( "Group Button Clicked" );
    }

    /**
     * To add Group In AddStudent To Group PopUp
     * 
     * 
     */

    public void addGrpInAddStudentToGrpPopUp( String grpName ) {
        SMUtils.nap( 3 );
        for ( int grpname = 0; grpname < grpNamesInAddStudentToGrpPoPUp.size(); grpname++ ) {
            String name = grpNamesInAddStudentToGrpPoPUp.get( grpname ).getText().trim();
            if ( name.equals( grpName ) ) {
                WebElement addBtn = SMUtils.getWebElementDirect( driver, multipleAddButtonRoot.get( grpname ), btnSecondary );
                SMUtils.clickJS( driver, addBtn );
                Log.message( "Add Button clicked for selected Group" );
            }
        }
    }

    /**
     * To add GroupName In Search Field Add Student To Group PopUp
     * 
     * 
     */

    public void addGrpNameInSearFieldAddStuToGrpPopUp( String gName ) {
        SMUtils.waitForElement( driver, searchGroupTextField );
        searchGroupTextField.sendKeys( gName );
        SMUtils.waitForElement( driver, addButtonRoot );
        WebElement adbtn = SMUtils.getWebElementDirect( driver, addButtonRoot, btnSecondary );
        SMUtils.clickJS( driver, adbtn );
        Log.message( "Group Name is passed in to field and selected" );
    }

    /**
     * To click Save Btn in AddStudToGrpPopUp
     * 
     * 
     */

    public void clickSaveBtnAddStudToGrpPopUp() {
        SMUtils.waitForElement( driver, saveBtnAddStudentToGrpPopUpRoot );
        WebElement saveBtn = SMUtils.getWebElementDirect( driver, saveBtnAddStudentToGrpPopUpRoot, btnPrimary );
        SMUtils.clickJS( driver, saveBtn );
        Log.message( "Save Button Clicked" );
    }

    /**
     * To check is User present in group
     * 
     * 
     */

    public Boolean isUserPresentInGrp( String studentID ) {
        SMUtils.nap( 1 ); // wait for page to load
        Boolean status = false;
        for ( int user = 0; user < userDetailsInGrpPage.size(); user++ ) {
            String name = userDetailsInGrpPage.get( user ).getText().trim();
            if ( name.equals( studentID ) ) {
                status = true;
                Log.message( "User present in the Group" );
                break;
            }
        }
        return status;
    }

    /**
     * To click Add Student To Group Button Group Page
     * 
     * 
     */

    public void clickAddStudentToGrpBtnGrpPage() {
        SMUtils.waitForElement( driver, addStuToGrpBtnRoot );
        WebElement btn = SMUtils.getWebElementDirect( driver, addStuToGrpBtnRoot, btnSecondary );
        SMUtils.clickJS( driver, btn );
        Log.message( "Add Student to group Button Clicked" );
    }

    /**
     * To Add Students In Add Students To Group Popup
     * 
     * 
     */

    public void toAddStuInAddStudentsToGrpPopup( String studentID ) {
        SMUtils.nap( 2 );// Waiting for popup to load
        WebElement stuWebEle = parentElementAddAssignPopUp.stream().filter( element -> element.findElement( By.cssSelector( userNameAddStuToGrpPopUp ) ).getText().trim().equals( studentID ) ).findFirst().orElse( null );
        if ( Objects.nonNull( stuWebEle ) ) {
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, stuWebEle.findElement( By.cssSelector( StuNameRootEleAddStuToGrpPopUp ) ), btnSecondary ) );
            Log.message( "Student Added Successfully" );
        }

    }

    /**
     * To click Student Radio Button
     * 
     * 
     */

    public void clickStudentRadioBtn() {
        CoursesPage coursePage = new CoursesPage( driver );
        WebElement studentRadioBtn = coursePage.studentRadioBtn;
        SMUtils.waitForElement( driver, studentRadioBtn );
        SMUtils.clickJS( driver, studentRadioBtn );
        Log.message( "Student Radio Button clicked" );
    }

    /**
     * To add Student In AssignPopUp
     * 
     * 
     */

    public void addStuInAssignPopUp( String stuName ) {
        for ( int stuname = 0; stuname < stuNamesInAssignPoPUp.size(); stuname++ ) {
            String name = stuNamesInAssignPoPUp.get( stuname ).getText().trim();
            if ( name.equals( stuName ) ) {
                WebElement addBtn = SMUtils.getWebElementDirect( driver, multipleAddBtnsInAssignPoPUp.get( stuname ), btnSecondary );
                SMUtils.clickJS( driver, addBtn );
                Log.message( "Student Name is added" );
            }
        }

    }

    /**
     * To click on the hovered group
     *
     * @param groupName
     * @return
     */
    public void clickOnTheHoveredGroup( String groupName ) {
        // This nap is required for Safari
        SMUtils.nap( 5 );
        try {
            listGroupName.stream().forEach( element -> Optional.ofNullable( SMUtils.getTextOfWebElement( element, driver ) ).ifPresent( groupNameDetail -> {
                if ( groupName.equals( groupNameDetail ) ) {
                    SMUtils.moveToElementSelenium( driver, element );
                    SMUtils.clickJS( driver, element );
                }
            } ) );
        } catch ( StaleElementReferenceException | NoSuchElementException e ) {
            Log.message( "Assignment selected is " + groupName );
        }
    }

    /**
     * To verify the Clicking X button on Delete Assignment pop-up
     *
     * @param groupName
     * @return
     */
    public boolean verifyGroupNameInProfile( String groupName ) {
        for ( WebElement sideNav : settingsSideBar ) {
            String sideNavBar = sideNav.getText().trim();
            if ( sideNavBar.equals( Constants.SETTINGS ) ) {
                SMUtils.waitForElement( driver, sideNav );
                SMUtils.clickJS( driver, sideNav );
                Log.message( sideNavBar + " sub nav-bar is clicked" );
            }
        }
        SMUtils.waitForElement( driver, groupNameSettings, 5 );
        return groupName.equals( groupNameSettings.getAttribute( "value" ) );
    }

    /**
     * To Verify the zero State in GroupListing
     * 
     * @author suriya.kumar
     */
    public void verifyZeroState() {
        try {

            String noDataYetText = noDataYet.getText().trim();
            String zeroMessageText = zeroStateMessge.getText().trim();
            String btnAddGroupText = btnZeroStateAddGroup.getText().trim();

            if ( noDataYetText.equals( Constants.Groups.NO_DATA_YET ) ) {
                Log.pass( "noDataYetText  matching!" );
            } else {
                Log.fail( "noDataYetText is not matching expected[" + Constants.Groups.NO_DATA_YET + "] but actual is[" + noDataYetText + "]" );
            }
            if ( zeroMessageText.replaceAll( "[^a-zA-Z0-9]", " " ).equals( Groups.ZERO_STATE_MESSAGE.replaceAll( "[^a-zA-Z0-9]", " " ) ) ) {
                Log.pass( "ZeroMessageText  matching!" );
            } else {
                Log.fail( "zeroMessageText is not matching expected[" + Constants.Groups.ZERO_STATE_MESSAGE + "] but actual is[" + zeroMessageText + "]" );
            }
            if ( btnAddGroupText.equals( Constants.Groups.CREATE_NEW_GROUP ) ) {
                Log.pass( "btnAddGroupText matching!" );
            } else {
                Log.fail( "btnAddGroupText is not matching expected[" + Constants.Groups.CREATE_NEW_GROUP + "] but actual is[" + btnAddGroupText + "]" );
            }

        } catch ( Exception e ) {
            return;
        }
    }

    /**
     * To Verify the X button on Create Group PopUp
     * 
     * @author ajith.mohan
     */
    public void clickCancelButtonDeleteGroupPopUp() {
        clickSettingsSubNav();
        SMUtils.clickJS( driver, getDeleteButton() );
        SMUtils.clickJS( driver, getCancelButton() );

    }

    /**
     * To Verify the X button on Delete Group PopUp
     * 
     * @author ajith.mohan
     */
    public void clickCancelButtonGroupDeletePopUp() {
        clickSettingsSubNav();
        SMUtils.clickJS( driver, getDeleteButton() );
        SMUtils.clickJS( driver, getCancelButtonDeleteGroup() );

    }

    /**
     * To Verify the Group Name in Groups Settings tab
     * 
     * @author aravindan.sivanandan
     */
    public void enterGroupNameInGroupsTab( String newgroupName ) {
        clickSettingsSubNav();
        txtBoxEditGroup.clear();
        txtBoxEditGroup.sendKeys( newgroupName );
        SMUtils.clickJS( driver, getSaveButton() );
        if ( txtBoxEditGroup.getAttribute( "value" ).equals( newgroupName ) ) {
            Log.message( "Group name updated successfully! New group Name - " + newgroupName );
        } else {
            Log.fail( "Error in updating the group!" );
        }

    }

    /**
     * To Verify the InvalidGroup Name in Groups Settings tab
     * 
     * @author aravindan.sivanandan
     */
    public boolean enterInvalidGroupName( String updatedGroupName, String expectedErrorMessage ) {
        clickSettingsSubNav();
        txtBoxEditGroup.clear();
        txtBoxEditGroup.sendKeys( updatedGroupName );
        SMUtils.clickJS( driver, getSaveButton() );
        SMUtils.nap( 3 );
        String errormessage = driver.findElement( By.cssSelector( txterrorMessage ) ).getText();
        return errormessage.equalsIgnoreCase( expectedErrorMessage );
    }

    // Validating Groups settings header
    public boolean isGroupsSettingsDisplayed() throws InterruptedException {
        return groupsettingsheader.getText().trim().equals( Constants.GroupsSettings.GROUP_SETTINGS_HEADER );
    }

    // Validating Groups - Edit Settings Title
    public boolean isEditSettingsTitleDisplayed() throws InterruptedException {
        return lblEditGroup.getText().trim().equalsIgnoreCase( Constants.GroupsSettings.EDIT_SETTINGS );
    }

    // Validating Groups - Group Name Title
    public boolean isGroupNameTitleDisplayed() throws InterruptedException {
        return groupNameTitle.getText().trim().equalsIgnoreCase( Constants.GroupsSettings.GROUP_NAME );
    }

    // Validating Groups - Delete Group Title
    public boolean isDeleteGroupTitleDisplayed() throws InterruptedException {
        return lblDeleteGroup.getText().trim().equalsIgnoreCase( Constants.GroupsSettings.DELETE_GROUP );
    }

    // Validating Groups - Delete Group text
    public boolean isDeleteGrouptextTitleDisplayed() throws InterruptedException {
        return lblDeleteGroupMsg.getText().trim().equalsIgnoreCase( Constants.GroupsSettings.DELETE_GROUP_TEXT );
    }

    // Validating Groups - edit group text box
    public boolean isEditGroupTextboxDsiplayed() throws InterruptedException {
        return lblEditGroup.isDisplayed();
    }

    // Click create New group in Groups tab
    public void clickCreateGroup() {
        SMUtils.waitForElement( driver, btnCreateNewGroup, 5 );
        SMUtils.clickJS( driver, btnCreateNewGroup );
        Log.message( "Clicked Create Group button" );
        SMUtils.waitForElement( driver, createaNewGroupHeaderinPopup, 5 );
    }

    /**
     * To Click Cancel Button
     * 
     * 
     */
    public void clickCancelButtonOnCreateGroupPopup() {
        SMUtils.clickJS( driver, btnCancelRoot );
        Log.message( "Clicked Cancel Button" );
        SMUtils.waitForElement( driver, btnCreateNewGroup, 5 );
    }

    /**
     * To get No of students
     * 
     * @return
     */

    public String getNo_Of_Students( String groupName ) {
        WebElement grpName = driver.findElement( By.xpath( "//*[@title='" + groupName + "']//following :: span[1]" ) );
        SMUtils.scrollWebElementToView( driver, grpName );
        return grpName.getText().trim();
    }

    /**
     * To click Get View GroupBtn
     * 
     * 
     */

    public void clickGetViewGroupBtn( String groupName ) {
        WebElement viewGroupBtn = driver.findElement( By.xpath( "//*[@title='" + groupName + "']//following :: cel-button" ) );
        SMUtils.clickJS( driver, viewGroupBtn );
        Log.message( "Clicked View Group button for " + groupName );
    }

    /*
     * This Element is Group Header Name element after clicked "View Group"
     * Button at the Individual element
     */
    public String getGroupNameinContainer() {
        String groupName = groupNameinContainer.getText().trim();
        return groupName;
    }

    /*
     * This Element is Error Message for the Group Name Text Box in the
     * "Create a New Group" Modal popup
     */
    public String getErrorMessageInGroupNameTextBox() {
        SMUtils.waitForElement( driver, erroMessageinGroupName, 5 );
        String message = erroMessageinGroupName.getText().trim();
        return message;
    }

    /*
     * This Element is for click "Create group" button in Popup
     */
    public void clickCreateGroupButtoninPopup() {
        SMUtils.clickJS( driver, btnCreateGroupinPopup );
        Log.message( "Clicked created Group in Popup" );
        SMUtils.waitForElement( driver, btnCreateNewGroup, 5 );
    }

    /*
     * This Element is for click "close" button in Popup
     */
    public void clickCloseAddStudGroupButtoninPopup() {
        SMUtils.waitForElement( driver, closePopupAddStudBtn );
        SMUtils.clickJS( driver, closePopupAddStudBtn );
        Log.message( "Clicked created Group in Popup" );
    }

    /*
     * Get the Text in Create New Group in popup
     */
    public String getTextofCreateNewGroup() {
        return createaNewGroupHeaderinPopup.getText().trim();
    }

    /*
     * This Element is for "Enter name of a gorup" text box in ZeroState
     */
    public void clickCreateGroupinZeroState() {
        SMUtils.clickJS( driver, btnZeroStateAddGroup );
        Log.message( "Clicked create group in zero state" );
        SMUtils.waitForElement( driver, createaNewGroupHeaderinPopup, 5 );
    }

    /*
     * Add Student Text Box in Popup
     */
    public WebElement getAddStudentTextBox() {
        return txtBoxSearchinCreateGroupPopup;
    }

    /*
     * Group Name Text Box in Popup
     */
    public WebElement getGroupNameTextBoxInPopup() {
        return groupNameTextBox;
    }

    /**
     * This method will check if the Teacher user has Group or Not
     * 
     * @return true if teacher has group
     */
    public Boolean isTeacherhasGroup() {
        return !SMUtils.verifyElementDoesNotExist( By.cssSelector( groupTableCSS ), driver );
    }

    /**
     * To Create a Group Modified for sme -187
     *
     * @author suriya.kumar
     */
    public void createGroup( String groupName, List<String> studentUserNames ) {
        try {
            SMUtils.waitForElementToBeClickable( getCreateGroupButton(), driver );
            SMUtils.clickJS( driver, getCreateGroupButton() );
            SMUtils.waitForElement( driver, btnCancelRoot, 5 );
            Log.message( "Create group popup loaded" );
            groupNameTextBox.sendKeys( groupName );

            for ( String studentUN : studentUserNames ) {
                addSelectedStudents( studentUN.toLowerCase() );
            }
            SMUtils.waitForElementToBeClickable( getCreateButton(), driver );
            SMUtils.click( driver, getCreateButton() );
            if ( isGroupExist( groupName ) ) {
                Log.pass( "Group Created Successfully-" + groupName, driver );
            } else {
                Log.failsoft( "Error while creating the group with student", driver );
            }
        } catch ( Exception e ) {
            Log.message( "Error while creating the group with student: Group not exist", driver, true );
        }
    }

    /**
     * To delete all the group in UI
     * 
     * @param groupsTab object
     */
    public void deleteAllGroup( GroupPage groupsTab ) {
        Log.message( "Deleting all the groups in UI" );
        if ( isTeacherhasGroup() ) {
            List<String> groupsFromUI = groupsTab.getGroupListNames();
            for ( int i = 0; i < groupsFromUI.size(); i++ ) {
                clickGetViewGroupBtn( groupsFromUI.get( i ) );
                SMUtils.nap( 2 ); // waiting for settings button click in Groups page
                deleteGroup( groupsFromUI.get( i ) );
            }
        } else {
            Log.message( "All groups are already deleted" );
        }
    }

    /**
     * Return the Web Element of the Create New Group button of the Group Page
     *
     * @return Web Element
     */
    public WebElement getBtnCreateNewGroup() {
        return createNewGroupbtn;
    }

    /**
     * Return the Help Icon belonging to the Create New Group dialog box
     *
     * @return
     */

    public WebElement getBtnCreateNewGroupHelpInfoIcon() {
        return createNewGroupHelpInfoIcon;
    }

    /**
     * Returns the CreateNewGroup Dialog box as the Web Element
     *
     * @return Web Element
     */
    public WebElement getCreateNewGroupDialogBox() {
        return createNewGroupDialogBox;
    }

    /**
     * Returns the CreateNewGroup Help Page Header Element
     *
     * @return WebElement
     */
    public WebElement getCreateNewGroupHelpPageHeader() {
        return createNewGroupHelpPageHeader;
    }

    /**
     * To get header from group details page
     * 
     * @return
     */
    public String getGroupDetailsHeader( String headerName ) {
        String headerTxt = null;
        if ( headerName.equals( Constants.GroupUIConstants.GROUP_NAME ) ) {
            SMUtils.waitForElement( driver, lblGroupNameFromViewGroup );
            headerTxt = lblGroupNameFromViewGroup.getText().trim();
        } else if ( headerName.equals( Constants.GroupUIConstants.GROUP_USAGE ) ) {
            SMUtils.waitForElement( driver, groupUsageHeader );
            headerTxt = groupUsageHeader.getText().trim();
        } else if ( headerName.equals( Constants.GroupUIConstants.SKILLS_ASSESSMENT ) ) {
            SMUtils.waitForElement( driver, skillsAssessmentHeader );
            headerTxt = skillsAssessmentHeader.getText().trim();
        } else if ( headerName.equals( Constants.GroupUIConstants.PERCENT_OF_STUDENTS_MASTERED ) ) {
            SMUtils.waitForElement( driver, percentOfStudentsMasteredHeader );
            headerTxt = percentOfStudentsMasteredHeader.getText().trim();
        }
        Log.message( "Got " + headerName + " header from group details page" );
        return headerTxt;
    }

    /**
     * To verify assignment dropdown is present or not in skills assessment
     * 
     * @return
     */
    public boolean isAssignmentDropdownPresent() {
        Log.message( "Verifying assignment dropdown in Skills Assessment " );
        return ( SMUtils.isElementPresent( assignmentsDropdown ) ? true : false );
    }

    /**
     * To verify assignment dropdown is present or not in skills assessment
     * 
     * @return
     */
    public List<String> getValuesFromAssignmentsDropdown() {
        SMUtils.waitForElement( driver, assignmentsDropdown );
        SMUtils.clickJS( driver, assignmentsDropdown );
        List<String> assignmentsList = new ArrayList<>();
        for ( WebElement value : assignmentsName ) {
            assignmentsList.add( value.getText().trim() );
        }
        Log.message( "Got all assignments name from Assignments Dropdown in Skills Assessment" );
        return assignmentsList;
    }

    /**
     * To verify progress bar is displayed in each LO
     * 
     * @return
     */
    public boolean isProgressBarDisplayedForEachLO() {
        SMUtils.waitForElement( driver, percentOfStudentsMasteredHeader );
        Log.message( "Verifying progress bar is displayed for each LO in Skills Assessment" );
        for ( WebElement progressBarWebElement : progressBarRoot ) {
            WebElement progressBars = SMUtils.getWebElementDirect( driver, progressBarWebElement, progressBar );
            if ( SMUtils.isElementPresent( progressBars ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * To click view details button in skills assessment
     * 
     * @return
     */
    public void cickViewDetails() {
        SMUtils.waitForElement( driver, viewDetailsBtn );
        SMUtils.clickJS( driver, viewDetailsBtn );
        Log.message( "View Details button is clicked in Skills Assessment" );
    }

    /**
     * To get skills name in skills assessment
     * 
     * @return
     */
    public List<String> getSkillsName() {
        SMUtils.waitForElement( driver, percentOfStudentsMasteredHeader );
        List<String> skillsName = new ArrayList<>();
        for ( WebElement names : skillNames ) {
            skillsName.add( names.getText().trim() );
        }
        Log.message( "Got all skills name in Skills Assessment" );
        return skillsName;
    }

    /**
     * To get skills name in skills assessment
     * 
     * @return
     */
    public List<String> getProgressPrecent() {
        SMUtils.waitForElement( driver, percentOfStudentsMasteredHeader );
        List<String> progressPercentList = new ArrayList<>();
        for ( WebElement progressBarWebelement : progressPercentRoot ) {
            WebElement progressBar = SMUtils.getWebElementDirect( driver, progressBarWebelement, progressPercent );
            progressPercentList.add( progressBar.getText().trim() );
        }
        Log.message( "Got all progress percent in Skills Assessment" );
        return progressPercentList;
    }

    /**
     * To get skill name in skills popup
     * 
     * @return
     */
    public String getSkillNameInSkillPopup() {
        SMUtils.waitForElement( driver, skillNameInSkillPopup );
        String skillName = skillNameInSkillPopup.getText().trim();
        Log.message( "Got skill name in skills popup" );
        return skillName;
    }

    /**
     * To get skill name in skills popup
     * 
     * @return
     */
    public void clickLO() {
        SMUtils.waitForElement( driver, loLink );
        SMUtils.clickJS( driver, loLink );
        Log.message( "LO linked is clicked" );
    }

    /**
     * To click view details button in skills assessment
     * 
     * @return
     */
    public void cickCloseBtnInSkillPopup() {
        SMUtils.waitForElement( driver, closeBtnInSkillPopup );
        WebElement closeBtn = SMUtils.getWebElementDirect( driver, closeBtnInSkillPopup, btnPrimary );
        SMUtils.clickJS( driver, closeBtn );
        Log.message( "Close button is clicked in Skill Popup" );
    }

    /**
     * To add a student a group
     *
     */
    public void addStudentToGroup( String studentName ) {
        SMUtils.waitForElement( driver, formGroupPopup );
        txtboxGroupfilter.clear();
        txtboxGroupfilter.sendKeys( studentName );
        SMUtils.nap( 2 ); //Waiting to disappear the loading icon
        SMUtils.waitForElement( driver, btnAddGroup, 5 );
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, btnAddGroup, addButtonCSS ) );
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, btnAddStudents, btnPrimary ) );
        SMUtils.nap( 1 ); // Waiting to disappear the loading icon
        //   SMUtils.clickJS( driver, btnAddGroup );
        //SMUtils.clickJS( driver, btnAddStudents );
        Log.message( studentName + " student added to the group: " );
        SMUtils.nap( 2 ); //Waiting to disappear load icon
    }

    /**
     * To verify Skills Assessment zero state
     *
     * @return
     */
    public String getSkillsAssessmentZeroState() {
        SMUtils.waitForElement( driver, skillsAssess );
        return skillsAssessZeroState.getText().trim();
    }

    /**
     * Create group with overall school students
     *
     * @param groupName
     * @param studentUserNames
     * @param grade
     */
    public void createGroupWithSchoolStudents( String groupName, List<String> studentUserNames, String grade ) {
        try {

            SMUtils.waitForElementToBeClickable( getCreateGroupButton(), driver );
            SMUtils.clickJS( driver, getCreateGroupButton() );
            SMUtils.waitForElement( driver, btnCancelRoot, 5 );
            Log.message( "Create group popup loaded" );
            groupNameTextBox.sendKeys( groupName );

            for ( String studentUName : studentUserNames ) {
                SMUtils.enterValue( searchGroupTextField, studentUName );
                addSelectedStudents( studentUName );
            }

            SMUtils.waitForElementToBeClickable( getCreateButton(), driver );
            SMUtils.clickJS( driver, getCreateButton() );
            SMUtils.waitForElementToBeClickable( getCreateGroupButton(), driver );
            if ( isGroupExist( groupName ) ) {
                Log.pass( "Group Created and listed Successfully -" + groupName, driver );
            } else {
                Log.fail( "Group is not created.", driver );
            }
        } catch ( Exception e ) {
            Log.message( "Error while creating the group with student" + e, driver, true );

        }
    }

    public boolean addSelectedStudents( String studentUserName ) {
        try {

            txtBoxSearchinAddGroupPopup.clear();
            txtBoxSearchinAddGroupPopup.sendKeys( studentUserName );
            new SMUtils().waitForElement( driver, spinner );
            new SMUtils().waitForSpinnertoDisapper( driver, 600 );

            int MaxSeconds = 120;
            int starting = 0;
            while ( starting < MaxSeconds ) {
                if ( !new SMUtils().waitForElement( driver, addButtonroot ) ) {
                    Log.message( "Student Not Found: Searching Again..." + "of Total: " + starting + "/" + MaxSeconds + " second (s)" );
                    SMUtils.nap( 3 );
                    starting = starting + 3;
                    txtBoxSearchinAddGroupPopup.clear();
                    txtBoxSearchinAddGroupPopup.sendKeys( studentUserName );
                } else {
                    break;
                }
            }

            WebElement addButton = new SMUtils().getWebElementDirect( driver, addButtonroot, "button.secondary_button" );
            new SMUtils().click( driver, addButton );
            Log.message( "Added student: '" + studentUserName + "' into the chip Text Area" );
            return true;

        } catch ( Exception e ) {
            e.printStackTrace();
            return false;

        }
    }

    /**
     * To verify help icon is displayed or not in Add Students to Group popup
     * 
     * @return
     */
    public boolean verifyHelpIcon() {
        Log.event( "Verifying help icon in displayed or not in Add Students to Group popup" );
        boolean status = false;
        SMUtils.waitForElement( driver, iconI );
        if ( iconI.isDisplayed() )
            status = true;
        Log.event( "Verified the help icon is displayed in Add Students to Group popup" );
        return status;
    }

    /**
     * To click on Add Students to Group link in Groups page
     */
    public void clickAddStuToGrpLink() {
        Log.event( "Clicking Add students to Groups link in Add Students to Group popup" );
        SMUtils.waitForElement( driver, addStuToGrpLink );
        SMUtils.click( driver, addStuToGrpLink );
        Log.message( "Add students to Groups link is clicked successfully" );
    }

    /**
     * To get group usage bar data and verification
     * 
     * @param usageHours
     * @param isGroupCrossedHours
     * @param isMath
     * @return
     */
    public boolean verifyGroupUsageBarData( HashMap<String, HashMap<String, Integer>> usageHours, boolean isGroupCrossedHours, boolean isMath ) {
        try {
            List<String> weeks = getFourWeeksMonday();
            Collections.reverse( weeks );
            Iterator<String> weeksList = weeks.iterator();
            Iterator<WebElement> mathBar = mathBars.iterator();
            Iterator<WebElement> readingBar = readingBars.iterator();
            Iterator<WebElement> barDetails;
            WebElement bar;
            String week;
            String expectedHours = null;
            String subject;

            boolean isVerified = false;
            if ( isMath ) {
                barDetails = mathBar;
                subject = Constants.UsageChart.MATH;
            } else {
                barDetails = readingBar;
                subject = Constants.UsageChart.READING;
            }

            while ( weeksList.hasNext() && barDetails.hasNext() ) {
                bar = barDetails.next();
                week = weeksList.next();
                if ( bar.isDisplayed() ) {
                    SMUtils.moveToElementJS( driver, bar );
                    String actualHoursFromUI = toolTipUsageChart.getText().trim().replace( " Total", Constants.UsageChart.TOTAL );
                    if ( isMath ) {
                        expectedHours = subject + " : " + convertMinutesIntoHours( usageHours.get( week ).get( subject ), isGroupCrossedHours );
                        expectedHours = expectedHours.trim() + "Total : " + convertMinutesIntoHours( usageHours.get( week ).get( "Total" ), isGroupCrossedHours );
                    } else {
                        expectedHours = subject + " : " + convertMinutesIntoHours( usageHours.get( week ).get( subject ), isGroupCrossedHours );
                        expectedHours = expectedHours.trim() + "Total : " + convertMinutesIntoHours( usageHours.get( week ).get( "Total" ), isGroupCrossedHours );
                    }
                    if ( actualHoursFromUI.equals( expectedHours.trim() ) ) {
                        Log.pass( "Expected " + subject + " usage hours - " + actualHoursFromUI + " is displayed properly for " + week + " week!", driver );
                        isVerified = true;
                    } else {
                        Log.fail( "Expected " + subject + " usage hours - " + expectedHours + " is not displayed properly for " + week + " week!. Actual - " + actualHoursFromUI, driver );
                        isVerified = false;
                    }
                } else {
                    if ( usageHours.get( week ).get( subject ) != 0 ) {
                        Log.fail( subject + " usage hours is mismatched for " + week, driver );
                    } else {
                        Log.pass( week + " week don't have " + subject + " usage data! - Expected" );
                    }
                }
            }

            return isVerified;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * Getting Y axis Intervals for graph
     * 
     * @param usageHours
     * @param isGroupCrossedHours
     * @return
     */
    public List<Double> getYaxisIntervals( HashMap<String, HashMap<String, Integer>> usageHours, boolean isGroupCrossedHours ) {
        List<String> weeks = getFourWeeksMonday();
        List<Double> yaxisInterval = new ArrayList<Double>();
        if ( isGroupCrossedHours ) {
            int highestWeekMinFromAPI = 0;
            for ( String week : weeks ) {
                if ( highestWeekMinFromAPI < usageHours.get( week ).get( Constants.UsageChart.TOTAL ) ) {
                    highestWeekMinFromAPI = usageHours.get( week ).get( Constants.UsageChart.TOTAL );
                }
            }
            double highestWeekHourFromAPI = (double) highestWeekMinFromAPI / 60;
            DecimalFormat decimalFormat = new DecimalFormat( "#.#" );
            double interval = 0;
            while ( interval < highestWeekHourFromAPI ) {
                interval = interval + highestWeekHourFromAPI / 4;
                double formattedInterval = Double.valueOf( decimalFormat.format( interval ) );
                yaxisInterval.add( formattedInterval );
            }
        } else {
            yaxisInterval = Constants.UsageChart.YAXISINTERVAL_DEFAULT;
        }
        return yaxisInterval;
    }

    /**
     * getting zero state message for usage graph
     * 
     * @return
     */
    public String getZeroStateMessageForUsage() {
        SMUtils.waitForElement( driver, lblZeroStateText );
        String zeroState = lblZeroStateText.getText();
        return zeroState;
    }

    /**
     * Verifying the group usage chart field values
     * 
     * @param individualFieldsFromAPI
     * @param isGroupCrossedHours
     * @return
     */
    public boolean verifyGroupUsageChartFieldsData( HashMap<String, Integer> individualFieldsFromAPI, boolean isGroupCrossedHours ) {
        try {
            SMUtils.waitForElement( driver, groupUsagechartRoot, 15 );
            for ( String usageField : Constants.UsageChart.USAGE_FIELDS ) {
                boolean isLabelPresent = false;
                for ( WebElement lblUsageField : lblUsageFields ) {
                    if ( lblUsageField.getText().trim().equals( usageField ) ) {
                        WebElement ParentElement = lblUsageField.findElement( By.xpath( "./.." ) );
                        WebElement lblValue = ParentElement.findElement( By.cssSelector( txtindividualField ) );
                        String actualValueFromUI = lblValue.getText().trim().replace( "  ", " " );
                        int expectedMins = individualFieldsFromAPI.get( usageField );
                        String expectedValue;
                        if ( isGroupCrossedHours ) {
                            if ( expectedMins == 0 ) {
                                expectedValue = Constants.UsageChart.ZERO_HOURS;
                            } else if ( expectedMins < 60 ) {
                                expectedValue = Constants.UsageChart.LESS_THAN_ONE_HOUR;
                            } else if ( expectedMins / 60 == 1 && expectedMins % 60 < 30 ) {
                                expectedValue = Constants.UsageChart.ONE_HOUR;
                            } else {
                                if ( expectedMins % 60 < 30 ) {
                                    expectedValue = String.valueOf( expectedMins / 60 ) + " " + Constants.UsageChart.HOURS.toLowerCase();
                                } else {
                                    expectedValue = String.valueOf( ( expectedMins / 60 ) + 1 ) + " " + Constants.UsageChart.HOURS.toLowerCase();
                                }
                            }
                        } else {
                            if ( expectedMins == 0 ) {
                                expectedValue = Constants.UsageChart.ZERO_MINUTES;
                            }
                            if ( expectedMins == 1 ) {
                                expectedValue = Constants.UsageChart.ONE_MINUTE;
                            } else {
                                expectedValue = String.valueOf( expectedMins ) + " " + Constants.UsageChart.MINUTES.toLowerCase();
                            }
                        }
                        if ( actualValueFromUI.equals( expectedValue ) ) {
                            Log.pass( usageField + " - " + lblValue.getText().trim() + " value  is displayed successfully!" );
                            isLabelPresent = true;
                        } else {
                            Log.fail( usageField + " - " + expectedValue + " value  is not displayed properly!. Actual - " + lblValue.getText().trim(), driver );
                        }
                    }
                    if ( isLabelPresent ) {
                        break;
                    }
                }
                if ( !isLabelPresent ) {
                    Log.fail( usageField + " value is not displayed properly!", driver );
                }
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    // Getting the locator for Pause Assignment for All Students
    private WebElement getPauseAssignmentForAllStudents() {
        WebElement PauseAssignment = SMUtils.getWebElementDirect( driver, ellipsesRoot, PauseAllStudentAssignmentBtnParent );
        WebElement ThreeDotPauseAssignmentButton = SMUtils.getWebElementDirect( driver, PauseAssignment, PauseAllStudentAssignmentchild );
        return ThreeDotPauseAssignmentButton;
    }

    // Clicking Pause Assignment for All Students button in three-dot ellipses
    public void clickPauseAssignmentForAllStudents() {
        SMUtils.waitForElement( driver, getPauseAssignmentForAllStudents() );
        Log.message( "Clicking on Pause Assignment for All Students" );
        SMUtils.clickJS( driver, getPauseAssignmentForAllStudents() );
    }

    /**
     * To get the pause/Resume confirmation popup is having X, Cancel and
     * Pause/Resume button with message
     * 
     * @return pop-up message
     */
    public String isPauseResumeAssignmentPopupMessageDisplayed() {
        String popupMessage = "";
        WebDriverWait wait = new WebDriverWait( driver, Duration.ofSeconds( TestDataConstants.SIMULATOR_WAIT ) );
        wait.until( ExpectedConditions.visibilityOfAllElements( pauseResumeAssignmentHeadsupMessage ) );
        try {
            if ( SMUtils.isElementPresent( pauseResumePopupHeader ) ) {
                for ( WebElement element : pauseResumeAssignmentHeadsupMessage ) {
                    popupMessage += element.getText().toString();
                }
                Log.pass( "Assignment pop-up Message: " + popupMessage );
            } else {
                Log.fail( "Assignment pop-up is not getting displayed" );
            }

            if ( SMUtils.isElementPresent( xPauseResumeAssignmentButton ) )
                Log.pass( "X button is displayed successfully!" );
            else
                Log.fail( "X button is not getting displayed on the Pause/Resume Assignment pop-up!" );

            if ( SMUtils.isElementPresent( cancelPauseResumeAssignmentButton ) )
                Log.pass( "Cancel button is displayed successfully!" );
            else
                Log.fail( "Cancel button is not getting displayed on the Pause/Resume Assignment pop-up!" );

            if ( SMUtils.isElementPresent( pauseResumeButton ) ) {
                String buttonName = SMUtils.getTextOfWebElement( pauseResumeButton, driver );
                if ( buttonName.equals( "Pause" ) ) {
                    Log.pass( "Pause Button is getting displayed!" );
                } else if ( buttonName.equals( "Resume" ) ) {
                    Log.pass( "Resume Button is getting displayed!" );
                }
            } else {
                Log.fail( "Pause/Resume button is not getting displayed on the Pause/Resume Assignment pop-up!" );

            }
        }

        catch ( Exception e ) {}

        return popupMessage;

    }

    /**
     * Clicking X button on Pause/Resume Assignment pop-up
     * 
     * return
     */
    public boolean clickXButtononPauseResumeAssignmentpopup() {
        SMUtils.waitForElement( driver, xPauseResumeAssignmentButton );
        try {
            if ( SMUtils.isElementPresent( xPauseResumeAssignmentButton ) ) {
                Log.message( "X button is getting displayed successfully!" );
                SMUtils.clickJS( driver, xPauseResumeAssignmentButton );
                Log.pass( "Clicked 'X' button!" );
            } else {
                Log.fail( "X button is not getting displayed!" );
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * Clicking cancel button on Pause/Resume Assignment pop-up
     * 
     * return
     */
    public boolean clickCancelButtononPauseResumeAssignmentpopup() {
        SMUtils.waitForElement( driver, cancelPauseResumeAssignmentButton );
        WebElement cancelPauseResumeAssignmentBtn = SMUtils.getWebElement( driver, cancelPauseResumeAssignmentButton, btnSecondary );
        try {
            if ( SMUtils.isElementPresent( cancelPauseResumeAssignmentBtn ) ) {
                Log.message( "Cancel button is getting displayed successfully!" );
                SMUtils.clickJS( driver, cancelPauseResumeAssignmentBtn );
                Log.pass( "Clicked cancel button!" );
            } else {
                Log.fail( "Cancel button is not getting displayed!" );
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * Pausing/Resuming the GroupAssignment
     * 
     * return
     */
    public boolean clickPauseResumeButtononPauseAssignmentpopup() {
        SMUtils.waitForElement( driver, pauseResumeButton );
        WebElement pauseResumeAssignmentBtn = SMUtils.getWebElement( driver, pauseResumeButton, btnPrimary );
        try {
            if ( SMUtils.isElementPresent( pauseResumeAssignmentBtn ) ) {
                String buttonName = SMUtils.getTextOfWebElement( pauseResumeButton, driver ).toString().trim();
                if ( buttonName.equals( "Pause" ) ) {
                    Log.message( "Pause Assignment button is displayed successfully!" );
                    SMUtils.clickJS( driver, pauseResumeAssignmentBtn );
                    SMUtils.nap( 2 ); // Waiting to get assignment status after clicking on pause button
                    Log.message( "Clicked pause button!" );
                } else if ( buttonName.equals( "Resume" ) ) {
                    Log.message( "Resume Assignment button is displayed successfully!" );
                    SMUtils.clickJS( driver, pauseResumeAssignmentBtn );
                    SMUtils.nap( 2 ); // Waiting to get assignment status after clicking on resume button
                    Log.message( "Clicked Resume button!" );
                }
            } else {
                Log.fail( "Pause/Resume Assignment button is not getting displayed!" );
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * Verifying the usage chart legends
     * 
     * @return
     */
    public boolean verifyGroupUsageChart() {
        try {
            SMUtils.waitForElement( driver, groupUsagechartRoot, 20 );
            WebElement parentElement = groupUsagechartRoot.findElement( By.xpath( "./.." ) );
            WebElement lblheader = lblGroupUsageHeader;
            if ( lblheader.getText().trim().equals( Constants.UsageChart.GROUP_USAGE_HEADER ) ) {
                Log.pass( "Group usage header " + "\"" + Constants.UsageChart.GROUP_USAGE_HEADER + "\"" + " displayed successfully!" );
            } else {
                Log.fail( "Group usage header is not displayed properly! - " + lblheader.getText(), driver );
            }

            for ( String usageField : Constants.UsageChart.USAGE_FIELDS ) {
                boolean isLabelPresent = false;
                for ( WebElement lblUsageField : lblUsageFields ) {
                    if ( lblUsageField.getText().trim().equals( usageField ) ) {
                        Log.pass( usageField + "  is displayed successfully!" );
                        isLabelPresent = true;
                        break;
                    }
                }
                if ( !isLabelPresent ) {
                    Log.fail( usageField + "  is not displayed properly!", driver );
                }
            }

            for ( String legend : Constants.UsageChart.LEGENDS ) {
                boolean isLabelPresent = false;
                for ( WebElement lbllegend : lblgroupUsageLegends ) {
                    if ( lbllegend.getText().trim().equals( legend ) ) {
                        Log.pass( legend + "  is displayed successfully!" );
                        isLabelPresent = true;
                        break;
                    }
                }
                if ( !isLabelPresent ) {
                    Log.fail( legend + "  is not displayed properly! ", driver );
                }
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To Create a Group with Home Room Students
     *
     * @author nishanth.kamaraj
     */
    public void addStudGroupWithHomeRoomStudents( String groupName, List<String> studentUserNames ) {
        try {
            for ( String studentUN : studentUserNames ) {
                addSelectedStudents( studentUN );
            }
        } catch ( Exception e ) {
            Log.message( "Error while adding student to group with student: Group not exist", driver, true );
        }
    }

    /**
     * To delete all the group in UI Converting the minutes into hours as per
     * graph
     * 
     * @param minutes
     * @param isGroupCrossedHours
     * @return
     */
    public String convertMinutesIntoHours( int minutes, boolean isGroupCrossedHours ) {
        String result = "";
        if ( isGroupCrossedHours ) {
            if ( minutes == 60 || minutes / 60 == 1 ) {
                result = result + Constants.UsageChart.ONE_HOUR + " ";
            } else if ( minutes > 60 ) {
                result = result + String.valueOf( minutes / 60 ) + " " + Constants.UsageChart.HOURS.toLowerCase() + " ";
            }
            if ( minutes == 1 ) {
                result = result + Constants.UsageChart.ONE_MINUTE;
            } else if ( minutes % 60 != 0 ) {
                result = result + minutes % 60 + " " + Constants.UsageChart.MINUTES.toLowerCase();
            }
        } else {
            if ( minutes == 1 ) {
                result = Constants.UsageChart.ONE_MINUTE;
            } else {
                result = minutes + " " + Constants.UsageChart.MINUTES.toLowerCase();
            }
        }
        return result;
    }

    /**
     * Getting four monday dates
     * 
     * @return fourWeeksMonday
     */
    public static List<String> getFourWeeksMonday() {
        List<String> fourWeeksMonday = new ArrayList<String>();
        SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd" );
        Calendar weekStartDate = Calendar.getInstance();
        weekStartDate.setTime( new Date() );
        int iter = 0;
        while ( iter < 4 ) { // This is used to get the 4 week monday for usage graph
            if ( weekStartDate.get( Calendar.DAY_OF_WEEK ) == Calendar.SUNDAY ) {
                weekStartDate.add( Calendar.DATE, -1 );
                weekStartDate.set( Calendar.DAY_OF_WEEK, Calendar.MONDAY );
                fourWeeksMonday.add( dateFormat.format( weekStartDate.getTime() ) );
            } else {
                weekStartDate.set( Calendar.DAY_OF_WEEK, Calendar.MONDAY );
                fourWeeksMonday.add( dateFormat.format( weekStartDate.getTime() ) );
            }
            weekStartDate.add( Calendar.DATE, -7 );
            iter++;
        }
        return fourWeeksMonday;
    }

    /**
     * Verifying the group usage graph values
     * 
     * @param usageHours
     * @param isGroupCrossedHours
     * @return
     */
    public boolean verifyGroupUsageGraph( HashMap<String, HashMap<String, Integer>> usageHours, boolean isGroupCrossedHours ) {
        List<String> xAxisIntervals = getFourWeeksMonday();
        List<Double> yAxisIntervals = getYaxisIntervals( usageHours, isGroupCrossedHours );
        try {
            SMUtils.waitForElement( driver, groupUsagechartRoot, 10 );
            if ( isGroupCrossedHours ) {
                if ( lblYaxis.getText().trim().equals( "Hours" ) ) {
                    Log.pass( "Y axis label " + "\"" + Constants.UsageChart.HOURS + "\"" + " displayed successfully!" );
                } else {
                    Log.fail( "Y axis label is not displayed properly! - " + lblYaxis.getText().trim(), driver );
                }
            } else {
                if ( lblYaxis.getText().trim().equals( "Minutes" ) ) {
                    Log.pass( "Y axis label " + "\"" + Constants.UsageChart.MINUTES + "\"" + " displayed successfully!" );
                } else {
                    Log.fail( "Y axis label is not displayed properly! - " + lblYaxis.getText().trim(), driver );
                }
            }
            for ( String xAxisInterval : xAxisIntervals ) {
                boolean isLabelPresent = false;
                for ( WebElement lblXaxisInterval : lblXaxisIntervals ) {
                    if ( lblXaxisInterval.getText().trim().equals( xAxisInterval ) ) {
                        Log.pass( xAxisInterval + "  is present in the x axis intervals!" );
                        isLabelPresent = true;
                        break;
                    }
                }
                if ( !isLabelPresent ) {
                    Log.fail( xAxisInterval + "  is not present in the x axis intervals!" );
                }
            }
            for ( Double yAxisInterval : yAxisIntervals ) {
                boolean isLabelPresent = false;
                for ( WebElement lblYaxisInterval : lblYaxisIntervals ) {
                    if ( Double.valueOf( lblYaxisInterval.getText().trim() ) >= yAxisInterval - 0.1 && Double.valueOf( lblYaxisInterval.getText().trim() ) <= yAxisInterval + 0.1 ) {
                        Log.pass( lblYaxisInterval.getText().trim() + "  is present in the y axis intervals!" );
                        isLabelPresent = true;
                        break;
                    }
                }
                if ( !isLabelPresent ) {
                    Log.fail( yAxisInterval + "  is not present in the y axis intervals!" );
                }
            }
            if ( verifyGroupUsageBarData( usageHours, isGroupCrossedHours, true ) ) {
                Log.pass( "All math usage hours are displayed properly." );
            } else {
                Log.fail( "Math usage hours are not displayed properly!", driver );
            }

            if ( verifyGroupUsageBarData( usageHours, isGroupCrossedHours, false ) ) {
                Log.pass( "All reading usage hours are displayed properly." );
            } else {
                Log.fail( "Reading usage hours are not displayed properly!", driver );
            }
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * To get the usage hours
     * 
     * @return
     */
    public HashMap<String, String> getGraphValues() {
        HashMap<String, String> graphValues = new HashMap<>();
        for ( WebElement element : lblText ) {
            String lableTextValue = element.getText();
            if ( lableTextValue.trim().equals( Constants.GroupUIConstants.THIS_WEEK ) ) {
                String lableValue = lblvalues.get( 0 ).getText();
                Log.pass( "This Week value displayed successfully. - " + lableValue );
                graphValues.put( Constants.GroupUIConstants.THIS_WEEK, lableValue );
            } else if ( lableTextValue.trim().equals( Constants.GroupUIConstants.LAST_WEEK ) ) {
                String lableValue = lblvalues.get( 1 ).getText();
                Log.pass( "Last week value displayed successfully.- " + lableValue );
                graphValues.put( Constants.GroupUIConstants.LAST_WEEK, lableValue );
            } else if ( lableTextValue.trim().equals( Constants.GroupUIConstants.SCHOOL_YEAR ) ) {
                String lableValue = lblvalues.get( 2 ).getText();
                Log.pass( "School year value displayed successfully.- " + lableValue );
                graphValues.put( Constants.GroupUIConstants.SCHOOL_YEAR, lableValue );
            }
        }
        return graphValues;
    }

    /**
     * 
     * To get Assignment Pause/ Resume status**
     * 
     * @return
     */

    public boolean isGroupAssignmentPaused() {
        boolean assignmentPaused = false;
        try {
            if ( getBadgeElement().getText().equals( "Paused" ) ) {
                Log.pass( "Pause label is getting displayed" );
                assignmentPaused = true;
            } else {
                assignmentPaused = false;
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return assignmentPaused;
    }

    // To get webElement for PauseLabel
    private WebElement getBadgeElement() {
        SMUtils.waitForElement( driver, pauseBadgeRoot, 10 );
        WebElement badgeElement = SMUtils.getWebElement( driver, pauseBadgeRoot, assginmentBadgeChild );
        return badgeElement;
    }

    // Getting the locator for Resume Assignment for All Students
    private WebElement getResumeAssignmentForAllStudents() {
        SMUtils.waitForElement( driver, ellipsesRoot );
        WebElement ResumeAssignment = SMUtils.getWebElementDirect( driver, ellipsesRoot, ResumeAllStudentAssignmentBtnParent );
        WebElement ThreeDotResumeAssignmentButton = SMUtils.getWebElementDirect( driver, ResumeAssignment, ResumeAllStudentAssignmentchild );
        return ThreeDotResumeAssignmentButton;
    }

    // Clicking Resume Assignment for All Students button in three-dot ellipses
    public void clickResumeAssignmentForAllStudents() {
        SMUtils.waitForElement( driver, getResumeAssignmentForAllStudents() );
        Log.message( "Clicking on Resume Assignment for All Students" );
        SMUtils.clickJS( driver, getResumeAssignmentForAllStudents() );
    }

    /**
     * To get the state of Arrow UP or Down
     * 
     * @return
     */
    public String getArrowStateOfColumn() {
        String status = arrowIcon.getAttribute( "name" );
        if ( status.equals( arrowUp ) ) {
            return Constants.ASCENDING;
        } else if ( status.equals( arrowDown ) ) {
            return Constants.DESCENDING;
        } else {
            Log.fail( "Arrow icon is not found" );
            return null;
        }
    }

    /**
     * To click the column Name and select the sorting type
     * 
     * @param columnName
     * @param sortingType - Ascending(up) or Descending(down)
     */
    public void clickColumnnAndSort( String columnName, String sortingType ) {
        for ( WebElement heading : columnNames ) {
            if ( columnName.equals( heading.getText().trim() ) ) {
                SMUtils.click( driver, heading );
                Log.message( "Clicked Column " + columnName );
                break;
            }
        }
        String state = getArrowStateOfColumn();
        if ( state.equals( Constants.DESCENDING ) ) {
            Log.fail( "The default sorting is not in ASCENDING Order" );
        }
        if ( sortingType.equals( Constants.DESCENDING ) ) {
            SMUtils.click( driver, arrowIcon );
            Log.message( "Clicked Arrow for Down" );
        }
    }

    /**
     * To get the column Name in which arrow icon present
     * 
     * @return
     */
    public String getColumnNameOfArrow() {
        WebElement parent = arrowIcon.findElement( By.xpath( "../../.." ) );
        WebElement columnText = parent.findElement( By.cssSelector( "span" ) );
        return columnText.getText().trim();
    }

    /**
     * get the List of GroupNames
     * 
     * @return
     */
    public List<String> getListofGroupNames() {
        List<String> groupNameList = new ArrayList<String>();
        int size = groupRowTextList.size();
        if ( size > 0 ) {
            for ( int i = 0; i < size; i += 2 ) {
                String groupName = groupRowTextList.get( i ).getText().trim();
                groupNameList.add( groupName );
            }
        } else {
            Log.message( "The Teacher has no group" );
        }
        return groupNameList;
    }

    /**
     * get the No of Students column values
     * 
     * @return
     */
    public List<Integer> getListofNoOfStudnets() {
        List<Integer> studentsCountList = new ArrayList<Integer>();
        int size = groupRowTextList.size();
        if ( size > 0 ) {
            for ( int i = 1; i < size; i += 2 ) {
                String count = groupRowTextList.get( i ).getText().trim();
                studentsCountList.add( Integer.parseInt( count ) );
            }
        } else {
            Log.message( "The Teacher has no group" );
        }
        return studentsCountList;
    }

    /**
     * To get the modified Grade
     * 
     * @return
     */
    public String getGradeValue() {
        SMUtils.waitForElement( driver, gradeValue );
        String grade = gradeValue.getText().trim();
        Log.message( grade );
        return grade;
    }

    /**
     * To remove the students to group.
     *
     * @param studentUserName
     * @return
     */
    public boolean removeSelectedStudent( String studentUserName ) {
        boolean isStudentRemoved = false;
        try {
            int studentList = driver.findElements( By.cssSelector( studentListForAddStudentGrpBtn ) ).size();
            isStudentRemoved = IntStream.range( 0, ( studentList ) ).anyMatch( i -> {
                String userName = driver.findElement( By.cssSelector( String.format( studentListstudent, i + 1 ) ) ).getText();
                if ( userName.trim().equals( studentUserName ) ) {
                    SMUtils.clickJS( driver, getOnRemoveBtn( i + 1 ) );
                    return true;
                } else {
                    return false;
                }

            } );

            Log.message( "removed selected student - " + studentUserName );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isStudentRemoved;
    }

    /**
     * To remove the students to group.
     *
     * @param studentUserName
     * @return
     */
    public boolean isRemoveButtonDisplayed( String studentUserName ) {
        boolean isStudentRemoved = false;
        try {
            String studentList = driver.findElement( By.cssSelector( studentListForAddStudentGrpBtn ) ).getAttribute( "childElementCount" );
            isStudentRemoved = IntStream.range( 0, Integer.parseInt( studentList ) ).anyMatch( i -> {
                String userName = driver.findElement( By.cssSelector( String.format( studentListstudent, i + 1 ) ) ).getText();
                if ( userName.trim().equals( studentUserName ) ) {
                    return getOnRemoveBtn( i + 1 ).isDisplayed();
                } else {
                    return false;
                }

            } );

        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isStudentRemoved;
    }

    /**
     * To remove the students to group.
     *
     * @param studentUserName
     * @return
     */
    public boolean clickChipTxtCloseButton( String studentUserName ) {
        boolean isStudentRemoved = false;
        try {
            String studentList = driver.findElement( By.cssSelector( studentListForGroups ) ).getAttribute( "childElementCount" );
            String userName = null;
            for ( int i = 0; i < Integer.parseInt( studentList ); i++ ) {
                userName = driver.findElement( By.cssSelector( String.format( studentListFNLN, i + 1 ) ) ).getText();
                if ( userName.trim().equals( studentUserName ) ) {
                    clickChipTxtCloseBtn();
                    isStudentRemoved = true;
                    break;
                } else {
                    isStudentRemoved = false;
                }
            }
            Log.message( "remove selected student - " + studentUserName );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return isStudentRemoved;
    }

    /**
     * To get the modified Grade
     * 
     * @return
     */
    public String getValueAddStudTxtBox() {
        SMUtils.waitForElement( driver, addStudentTxtBox );
        String textValue = addStudentTxtBox.getText().trim();
        if ( textValue == " " ) {
            Log.message( "Add student text box value is null" );
        } else {
            Log.message( "Add student text box value is not null" );
        }
        return null;
    }

    /**
     * To click on the hovered group
     *
     * @return
     * @return
     * @throws Exception
     */
    public List<String> getAddStudChipTextValue() throws Exception {
        // This nap is required for Safari
        SMUtils.nap( 5 );
        try {
            List<String> textBoxValues = new ArrayList<String>();
            for ( WebElement listoftextvalue : listAddStudChipTxt ) {
                String textBoxValue = listoftextvalue.getText();
                textBoxValues.add( textBoxValue );
                Log.pass( "Student displayed in card format! - " + textBoxValue );
            }

            return textBoxValues;
        } catch ( StaleElementReferenceException | NoSuchElementException e ) {
            try {
                Log.message( "No values found in Textbox " );
                return null;

            } catch ( Exception e1 ) {
                Log.exception( e1, driver );
            }
        }
        return null;

    }

    /**
     * To click on the hovered group
     *
     * 
     * @return
     * @return
     * @throws Exception
     */
    public String verifyTextBoxValue() {
        // This nap is required for Safari
        SMUtils.nap( 5 );
        // List<String> textBoxValues = new ArrayList<String>();
        String textBoxValue = addStudentTxtBox.getText();
        return textBoxValue;
    }

    /**
     * click on the cancel button in add student popup
     * 
     * @return
     */
    public void clickOnCancelButtoninAddStudentPopup() {
        // WebElement cancelButton = SMUtils.getWebElementDirect( driver, btnCancelRoot,
        // btnSecondary );
        SMUtils.waitForElement( driver, btnCancelAddStudPopup );
        SMUtils.clickJS( driver, btnCancelAddStudPopup );
        Log.message( "Cancel button clicked" );
        return;
    }

    /**
     * click on the add students button in add student popup
     * 
     * @return
     */
    public void clickOnAddStudentsBtn() {
        SMUtils.waitForElement( driver, btnAddStudents );
        SMUtils.click( driver, SMUtils.getWebElementDirect( driver, btnAddStudents, btnPrimary ) );
        SMUtils.nap( 5 ); // Waiting to disappear the loading icon
        Log.message( "AddStudents button clicked" );
    }

    /**
     * click on the cancel button in add student popup
     * 
     * @return
     */
    public void addStudentsBtnIsEnable() {
        SMUtils.waitForElement( driver, btnAddStudents );
        if ( btnAddStudents.isEnabled() ) {
            Log.message( "AddStudents button is enabled " );
        } else {
            Log.message( "AddStudents button is disabled" );
        }
        return;
    }

    /**
     * To Click Mastery SubNav on Group Page
     * 
     * 
     */
    public void clickMasterySubNavOnGrpTab() {
        SMUtils.nap( 2 );
        settingsSideBar.stream().forEach( eachElement -> {
            if ( eachElement.getText().trim().equals( "Mastery" ) ) {
                SMUtils.clickJS( driver, eachElement );
            }
        } );
    }

    /**
     * To verify mastery zero state
     *
     * @return
     */
    public boolean verifyMasteryZeroState() {
    	SMUtils.clickJS( driver, masterySideBar );
        Log.message( "Navigated Mastery sub menu", driver, true );
        SMUtils.waitForElement( driver, masteryZeroStateMessage );
        String zeroStateHeaderFromUI = masteryZeroStateHeader.getText().trim();
        String zeroStateMessageFromUI = masteryZeroStateMessage.getText().trim();
        if ( zeroStateHeaderFromUI.equalsIgnoreCase( Constants.GroupUIConstants.MASTERY_ZERO_STATE_MESSAGE.get( 0 ) ) && zeroStateMessageFromUI.equalsIgnoreCase( Constants.GroupUIConstants.MASTERY_ZERO_STATE_MESSAGE.get( 1 ) ) ) {
            Log.pass( "Zero state message is displayed successfully!" );
            return true;
        } else {
            Log.fail( "Zero state message is not displayed successfully!" );
            return false;
        }
    }

    /**
     * To get list of group sub nav bar text
     * 
     * @return
     */
    public List<String> getGroupSubNav() {
        SMUtils.waitForElement( driver, userTabHeader );
        return driver.findElements( By.cssSelector( siedNavCommon ) ).stream().map( sideNav -> sideNav.getText().trim() ).collect( Collectors.toList() );
    }

    /**
     * To verify sub tab header
     * 
     * @param subNav
     */
    public boolean verifySubNavHeader( String subNav ) {

        if ( subNav.equalsIgnoreCase( Constants.USERS ) ) {
            userTabHeader.getText().trim().equals( subNav );
        } else if ( subNav.equalsIgnoreCase( Constants.ASSIGNMENTS ) ) {
            assignmentsHeader.getText().trim().equals( subNav );
        } else if ( subNav.equalsIgnoreCase( Constants.MASTERY ) ) {
            masteryHeader.getText().trim().equals( subNav );
        } else if ( subNav.equalsIgnoreCase( Constants.SETTINGS ) ) {
            settingsHeader.getText().trim().equals( subNav );
        } else {
            Log.message( subNav + " header is not displayed" );
            return false;
        }
        Log.message( subNav + " header is dsiplayed" );
        return true;
    }

    /**
     * To select assignment from assignments drop-down
     * 
     * @param assignmentName
     * @return
     */
    public boolean selectValuesFromAssignmentsDropdown( String assignmentName ) {
        List<String> valuesFromStaticDropDownMS = getValuesFromAssignmentsDropdown();
        List<String> valueList = Arrays.asList( valuesFromStaticDropDownMS.toString().replace( '[', '\u0000' ).replace( ']', '\u0000' ).trim().split( ", " ) );

        Map<String, Integer> mapValues = new LinkedHashMap<String, Integer>();
        IntStream.range( 0, valueList.size() ).forEach( i -> mapValues.put( valueList.get( i ).toLowerCase(), i ) );

        int txtDropdown = mapValues.get( assignmentName.toLowerCase() );
        SMUtils.clickJS( driver, assignmentsLink.get( txtDropdown ) );
        Log.message( assignmentName + " assignment is selected from Assingment dropdown" );
        return true;
    }

    /**
     * To get selected assignment from assignments drop-down
     * 
     * @return
     */
    public String getSelectedAssignment() {
        SMUtils.waitForElement( driver, assignmentSelected );
        return assignmentSelected.getText().trim();
    }

    /**
     * To verify down arrow is present in assignment drop down
     * 
     * @return
     */
    public boolean verifyDownArrowPresentInAssignmentDropdown() {
        SMUtils.waitForElement( driver, downArrowInAssignmentDroddown );
        Log.message( "Verifying down arrow button is present or not in assignment dropdown" );
        return downArrowInAssignmentDroddown.isDisplayed() ? true : false;
    }

    /**
     * To verifying skills name is present in skills assessment
     * 
     * @return
     */
    public boolean verifySkillsNameIsPresent() {
        SMUtils.waitForElement( driver, percentOfStudentsMasteredHeader );
        Log.message( "Verifying kills name are present in Skills Assessment" );
        return skillNames.stream().allMatch( skill -> skill.isDisplayed() ) ? true : false;
    }

    /**
     * To click back icon
     */
    public void clickBackIcon() {
        SMUtils.waitForElement( driver, backIcon );
        SMUtils.click( driver, backIcon );
        Log.message( "Back icon is clicked" );
        new SMUtils().waitForElement( driver, createNewGroupbtn );
    }

    /**
     * To get the validation message.
     * 
     * @return
     */
    public String getGroupNameErrorMessage() {
        SMUtils.click( driver, studentNameFilter );
        return SMUtils.getTextOfWebElement( groupNameErrorMesage, driver );
    }

    /**
     * To verify the error messages of groupName field
     * 
     * @param groupName
     * @param errorMesage
     * @throws Exception
     */
    public void groupNameErrorVerification( String groupName, String errorMesage ) throws Exception {
        try {

            SMUtils.waitForElementToBeClickable( getCreateGroupButton(), driver );
            SMUtils.clickJS( driver, getCreateGroupButton() );
            SMUtils.waitForElement( driver, btnCancelRoot, 5 );
            Log.message( "Create group popup loaded" );

            if ( errorMesage.equalsIgnoreCase( GroupUIConstants.NULL_GROUP_NAME_ERROR_MESSAGE ) ) {
                groupNameTextBox.click();
            } else {
                groupNameTextBox.sendKeys( groupName );
            }
            if ( getGroupNameErrorMessage().equalsIgnoreCase( errorMesage ) ) {
                Log.pass( "Valid error message displayed. - " + getGroupNameErrorMessage() );
            } else {
                Log.fail( "Invalid Error message displayed - " + getGroupNameErrorMessage(), driver );
            }
        } catch ( Exception e ) {
            SMUtils.click( driver, getCreateButton() );

            //This flow deprecated from 2022 system
            if ( getGroupNameErrorMessage().equalsIgnoreCase( errorMesage ) ) {
                Log.pass( "Duplicate groupname error message displayed. - " + getGroupNameErrorMessage() );
            } else {
                Log.fail( "Invalid Duplicate groupname error message displayed - " + getGroupNameErrorMessage(), driver );
            }
        }
    }

    /**
     * Verifying the search student field validation messages
     * 
     * @param errorMesage
     * @throws Exception
     */
    public void studentFieldErrorVerification( String errorMesage ) throws Exception {
        try {
            String text = studentFieldErrorMessage.getText();
            if ( text.trim().equalsIgnoreCase( errorMesage ) ) {
                Log.pass( "Error messsage verified." );
            } else {
                Log.fail( "Error message not as expected", driver );
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * Verify the create group popup headers
     */
    public void verifyCreateGroupPopupLables() {
        SMUtils.waitForElement( driver, groupNameHeaderCreateGroupPopup, 5 );
        if ( SMUtils.getTextOfWebElement( groupNameHeaderCreateGroupPopup, driver ).equalsIgnoreCase( GroupUIConstants.GROUP_NAME_LABEL ) ) {
            Log.pass( "Group name lable displayed successfully!" );
        } else {
            Log.fail( "Issue in displaying group name!", driver );
        }
        if ( SMUtils.getTextOfWebElement( addStudentHeaderCreateGroupPopup, driver ).equalsIgnoreCase( GroupUIConstants.ADD_STUDENT_LABEL ) ) {
            Log.pass( "Add student lable displayed successfully!" );
        } else {
            Log.fail( "Issue in displaying add student field!", driver );
        }
        if ( SMUtils.getTextOfWebElement( createaNewGroupHeaderinPopup, driver ).equalsIgnoreCase( GroupUIConstants.CREATE_GROUP_POPUP_HEADER ) ) {
            Log.pass( "Group popup header displayed successfully!" );
        } else {
            Log.fail( "Issue in displaying Group popup header!", driver );
        }
        if ( SMUtils.getAttributeOfWebElement( groupNameTextBox, driver, SMUtils.PLACEHOLDER ).equalsIgnoreCase( GroupUIConstants.GROUP_NAME_PLACEHOLDER ) ) {
            Log.pass( "Group name place holder displayed successfully!" );
        } else {
            Log.fail( "Issue in displaying Group name place holder!", driver );
        }
        if ( SMUtils.getAttributeOfWebElement( studentNameFilter, driver, SMUtils.PLACEHOLDER ).equalsIgnoreCase( GroupUIConstants.ADD_STUDENT_PLACEHOLDER ) ) {
            Log.pass( "Add student place holder displayed successfully!" );
        } else {
            Log.fail( "Issue in displaying Add student place holder!", driver );
        }
        //This popup is not there in 2022 system
        /*
         * if ( SMUtils.getTextOfWebElement( SMUtils.getWebElement( driver,
         * chBoxAllStudentfromSchoolRoot, lblCheckAllStudents ), driver
         * ).equalsIgnoreCase( GroupUIConstants.SELECT_ALL_STUDENTS_LABEL ) ) {
         * Log.pass( "Select school students label displayed successfully!" ); }
         * else { Log.fail( "Issue in displaying select students from school!",
         * driver ); }
         */

    }

    /**
     * To remove the student from selections
     * 
     * @param studentFNLN
     */
    public void removeStudentFromSelection( String studentFNLN ) {
        WebElement studentNameUI = listAddStudChipTxt.stream().filter( studentName -> studentName.getText().trim().equalsIgnoreCase( studentFNLN ) ).findAny().get();
        WebElement rootChip = studentNameUI.findElement( By.xpath( "./.." ) );
        SMUtils.click( driver, rootChip.findElement( By.cssSelector( removeStudentFromSelection ) ) );
        Log.message( "X icon displayed for student name from selection." );
    }

    /**
     * To verify the display message of reate group popup
     * 
     * @param isZeroState
     */
    public void verifyDisplayMessage( boolean isZeroState ) {
        SMUtils.waitForElement( driver, invalidSearchErrMsg, 5 );
        if ( isZeroState ) {
            if ( SMUtils.getTextOfWebElement( invalidSearchErrMsg, driver ).equalsIgnoreCase( GroupUIConstants.NO_STUDENT_FOUND_MESSAGE ) ) {
                Log.pass( "Zero state students displayed successfully" );
            } else {
                Log.fail( "Zero state message not displayed!", driver );
            }
        } else {
            //  SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chBoxAllStudentfromSchoolRoot, chBoxAllStudentfromSchool ) );
            //selectGrade( gradeName );
            SMUtils.waitForElement( driver, gradeDropDown );

            if ( SMUtils.getTextOfWebElement( invalidSearchErrMsg, driver ).equalsIgnoreCase( GroupUIConstants.SCHOOL_STUDENT_SELECTION_HINT ) ) {
                Log.pass( "School students selection hint displayed successfully" );
            } else {
                Log.fail( "School students selection hint not displayed!", driver );
            }
        }
    }

    /**
     * To get all the student list.
     * 
     * @return
     */
    public List<String> getAllStudentList() {
        SMUtils.waitForElement( driver, getPopupHeader(), 5 );
        SMUtils.waitForElement( driver, studentFirstNames.get( 0 ), 5 );
        List<String> studentNames = studentFirstNames.stream().map( studentName -> studentName.getText().trim() ).collect( Collectors.toList() );
        return studentNames;
    }

    /**
     * To close the create group popup using X icon
     */
    public void closeCreateGroupPopupUsingXIcon() {
        if ( SMUtils.isElementPresent( XDeleteAssignmentButtonparent ) ) {
            Log.message( "X button is getting displayed successfully!" );
            SMUtils.clickJS( driver, XDeleteAssignmentButtonparent );
            Log.message( "Clicked 'X' button!" );
        } else {
            Log.fail( "X button is not getting displayed!" );
        }
    }

    /**
     * To get the popup header
     * 
     * @return
     */
    public WebElement getPopupHeader() {
        return popupHeader;
    }

    /**
     * Verify the grade dropdown is displayed or not
     * 
     * @return
     */
    public boolean isGradeDropdownDisplayed() {
        boolean isDisplyed = false;
        try {
            if ( gradeDropDown.isDisplayed() ) {
                isDisplyed = true;
            } else {
                isDisplyed = false;
            }
        } catch ( Exception e ) {
            isDisplyed = false;
        }
        return isDisplyed;
    }

    /**
     * Clicking the select student from school check box
     */
    @Deprecated
    public void clickSelectStudentFromSchoolCheckBox() {
        try {
            SMUtils.clickJS( driver, SMUtils.getWebElementDirect( driver, chBoxAllStudentfromSchoolRoot, chBoxAllStudentfromSchool ) );
            SMUtils.waitForElement( driver, gradeNotSelectedErrMsg, 5 );
            Log.message( "Select school students check box!" );
        } catch ( Exception e ) {
            SMUtils.waitForElement( driver, studentFirstNames.get( 0 ), 5 );
        }
    }

    /**
     * To add the student in group
     * 
     * @param fieldName
     * @param value
     */
    public void addStudentInGroupPopup( String fieldName, String value ) {
        List<WebElement> addStudentElement = new ArrayList<>();
        AtomicReference<String> rootElement = new AtomicReference<>();
        SMUtils.enterValue( studentNameFilter, value );
        SMUtils.nap( 3 );
        if ( fieldName.contains( Constants.FIRSTNAME ) || fieldName.contains( Constants.LASTNAME ) ) {
            addStudentElement = studentFirstNames;

            //This line used to go back back 2 tree hierarchy for parent
            rootElement.set( "./../.." );
        } else if ( fieldName.contains( Constants.USER_NAME ) ) {
            addStudentElement = studentNamesFromCreateGroupPopup;

            //This line is used to go back 3 tree hierarchy for parent
            rootElement.set( "./../../.." );
        }

        if ( SMUtils.getFontFamily( studentFirstNames.get( 0 ) ).equalsIgnoreCase( "OpenSans-SemiBold, sans-serif" ) ) {
            Log.pass( "FirstName and LastName displayed in bold letters!", driver );
        }
        if ( SMUtils.getFontFamily( studentNamesFromCreateGroupPopup.get( 0 ) ).equalsIgnoreCase( "OpenSans, sans-serif" ) ) {
            Log.pass( "Grade and userName displayed in Normal letters!", driver );
        }

        addStudentElement.forEach( element -> {
            String studentFromUI = SMUtils.getTextOfWebElement( element, driver );
            if ( studentFromUI.contains( value ) ) {
                WebElement grandRoot = element.findElement( By.xpath( rootElement.get() ) );
                WebElement parentRoot = grandRoot.findElement( By.cssSelector( addButtonFromCreateGroupRoot ) );
                SMUtils.scrollWebElementToView( driver, parentRoot );
                WebElement addButton = SMUtils.getWebElement( driver, parentRoot, btnSecondary );
                if ( addButton.isDisplayed() ) {
                    Log.pass( "Add button displayed for the student - " + value );
                }

                SMUtils.click( driver, addButton );
                Log.pass( "Clicked add button for " + fieldName + " - " + value );

                WebElement removeButton = grandRoot.findElement( By.cssSelector( removeBtnAddStudPopup ) );
                if ( removeButton.isDisplayed() ) {
                    Log.pass( "Same student cannot be added multiple times!" );
                    Log.pass( "Remove button displayed for added student! - " + value );
                } else {
                    Log.fail( "Remove button is not displayed for student! - " + value, driver );
                }

            }
        } );
    }

    /**
     * To get all the grade details from students
     * 
     * @return
     */
    public List<String> getAllGradesFromStudentList() {
        SMUtils.nap( 2 ); //This nap is required for safari flow
        List<String> grades = gradesOfListedStudent.stream().map( gradeName -> gradeName.getText().trim() ).collect( Collectors.toList() );
        return grades;
    }

    /**
     * To enter the value in add student filter
     * 
     * @param value
     */
    public void enterValueInAddStudentFilter( String value ) {
        SMUtils.enterValue( studentNameFilter, value );
    }

    public WebElement getStudentInfoFrameInCreateGroupPopup() {
        return studentInfoFrameInCreateGroupPopup;
    }

    /**
     * Returns the Group List Web Element
     * 
     * @return WebElement
     */

    public WebElement getGroupList() {
        return groupList;
    }

    /**
     * Returns the Group Name in the form of String
     * 
     * @return String
     */

    public static String getGroupName() {
        return groupName;
    }

    public void courseCreation( TeacherHomePage tHomePage ) throws Exception {

        String courseCreatorName;
        CoursesPage customCourses = new CoursesPage( driver );
        staticCourseName = customCourses.generateRandomCourseName();

        // Get CourseLising Page
        CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

        // Select Custom Courses from the first drop down
        courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

        // Make a copy of the course
        customCourses.copyOfCourse( staticCourseName, Constants.STANDARDS, Constants.SM_FOCUS_READING_GRADE1 );

        // Get CourseLising Page
        tHomePage.topNavBar.getCourseListingPage();

        // Select Custom Courses from the first drop down
        courseListingPage.selectCourseTypeFromDropDown( Constants.CUSTOM_COURSES );

        // Sort by date descending
        courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

        // Click on the course
        customCourses.clickFromCourseListingPage( staticCourseName );

        // Click on the assignment
        customCourses.clickAssignBtn();
        // Get the count of the student from the assignment pop up
        customCourses.addCourseToGroups();
        customCourses.clickAssignmentSubMenu();
    }

    public void clickSingleAssignmentEditSettings() {
        boolean isAssignmentClicked = false;
        try {
            String assignmentCountFromUI = assignmentList.getAttribute( "childElementCount" );
            isAssignmentClicked = IntStream.range( 1, ( Integer.parseInt( assignmentCountFromUI ) + 1 ) ).anyMatch( assignmentCount -> {
                String ellipsedots = String.format( ellipsesAssignmentForgroupGrandRoot, assignmentCount );
                WebElement element = driver.findElement( By.cssSelector( ellipsedots ) );
                SMUtils.waitForElement( driver, element );
                element.click();
                Log.message( "Clicked the ellipse dots in assignment table", driver );
                WebElement editAssignmentSettingsElement = SMUtils.getWebElementDirect( driver, driver.findElement( By.cssSelector( ellipsedots ) ), ellipsesAssignmentForGroupParent, editAssignmentForGroupChild );
                editAssignmentSettingsElement.click();
                if ( assignmentCount == 1 ) {
                    return true;
                } else {
                    return false;
                }
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    public void obtainingMathSettings( TeacherHomePage tHomePage ) throws Exception {
        WebElement editAssignmentSettingElement = null;
        try {
            courseCreation( tHomePage );
            tHomePage.topNavBar.navigateToGroupsTab();

            getGroupNames();
            List<WebElement> groupsFromUI = new ArrayList<WebElement>();
            WebElement groupList = getGroupList();

            String groups = groupList.getAttribute( "childElementCount" );

            IntStream.range( 0, Integer.parseInt( groups ) ).forEach( element -> {
                WebElement groupFromUI = driver.findElement( By.cssSelector( String.format( GroupPage.getGroupName(), 1 ) ) );
                groupsFromUI.add( groupFromUI );
            } );

            groupsFromUI.get( 0 ).click();

            Log.message( "Navigated to Group Details Page Tab", driver, false );
            SMUtils.scrollWebElementToView( driver, assignmentsSideBar );
            SMUtils.waitForElement( driver, assignmentsSideBar );
            clickAssignmentSideSubNav();
            SMUtils.waitForElement( driver, assignmentList );
            clickSingleAssignmentEditSettings();
            SMUtils.waitForElement( driver, editAssignmentSettingtitle, 10 );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        }
    }

    /**
     * Get the list of groups in group listing page. Important- This Method is
     * required for Reports-groups filter validation
     * 
     * @author vikas.pandey
     * @return
     */
    public List<String> getGroupListNames() {
        List<String> groupsFromUI = new ArrayList<String>();
        String groups = groupList.getAttribute( "childElementCount" );
        IntStream.range( 0, Integer.parseInt( groups ) ).forEach( element -> {
            String groupNameFromUI = driver.findElement( By.cssSelector( String.format( GroupPage.groupName, element + 1 ) ) ).getText().trim();
            groupsFromUI.add( groupNameFromUI );
        } );
        Log.message( "Listed Groups - " + groupsFromUI );
        return groupsFromUI;
    }

    //Checking the DeleteAssignment button is present in the three-dot ellipses 
    public boolean isDeleteAssignmentBtnPresentonThreeDotEllipses() {
        boolean status = false;
        try {
            SMUtils.waitForElement( driver, getThreeDotDeleteAssignmentButton() );
            if ( SMUtils.isElementPresent( getThreeDotDeleteAssignmentButton() ) )
                status = true;
        } catch ( Exception e ) {
            e.printStackTrace();

        }
        return status;
    }

    /**
     * Clicking View Group Btn in the Groups page
     * 
     * @author madhan.nagarathinam
     * @param groupName
     */
    public void clickViewGroupUsingGroupName( String groupName ) {
        try {
            SMUtils.waitForElement( driver, groupList, 5 );
            String groups = groupList.getAttribute( "childElementCount" );
            IntStream.range( 0, Integer.parseInt( groups ) ).allMatch( i -> {
                String groupNameFromUI = driver.findElement( By.cssSelector( String.format( GroupPage.groupName, i + 1 ) ) ).getText();
                if ( groupNameFromUI.trim().equals( groupName ) ) {
                    WebElement viewGroupBtn = getViewGroupButton( i + 1 );
                    SMUtils.waitForElementToBeClickable( viewGroupBtn, driver );
                    SMUtils.clickJS( driver, viewGroupBtn );
                    Log.message( "Group " + groupName + " viewed successfully!" );
                }
                return true;
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    @IFindBy ( how = How.CSS, using = "cel-icon.dropdown-select-caret" )
    WebElement selectGradeRoot;

    public void clickGradeDropdowninCreateNewGroupPopup() {
        WebElement dropdown = SMUtils.getWebElementDirect( driver, selectGradeRoot, "img" );
        SMUtils.click( driver, dropdown );
        Log.message( "Clicked dropdown of 'Grade Select' " );
    }

    /**
     * This will filter by grade and add student to the to Chip area in the
     * Create Group popup
     * 
     * @param gradeName
     * @param studentUsernames
     */
    public void FilterGradeandAddStudents( String gradeName, List<String> studentUsernames ) {
        selectGradeFromAddStudPopup( gradeName );
        studentUsernames.forEach( username -> {
            addSelectedStudents( username );
        } );
    }

    /**
     * Click add Button in the popup given N times
     */
    public void clickAddButtonForNTimes( int count ) {
        try {
            String query = "const nodeList = document.querySelectorAll('div.add-button cel-button'); const count = " + count + " ;for ( let i=0 ; i <count; i++ ) { nodeList[i].shadowRoot.querySelector('button').click(); }";
            JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
            javascriptExecutor.executeScript( query );

        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }
    }

    /**
     * Click Remove Button in the popup given N times
     */
    public void clickRemoveButtonForNTimes( int count ) {
        try {
            String query = "const nodeList = document.querySelectorAll('div.remove-button cel-button'); const count = " + count + " ;for ( let i=0 ; i <count; i++ ) { nodeList[i].shadowRoot.querySelector('button').click(); }";
            JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
            javascriptExecutor.executeScript( query );

        } catch ( Exception e ) {
            Log.message( e.getMessage() );
        }

    }

    /**
     * To get the Student Details Result such as Username, First last Name and
     * Grade of the Student in Solar Search result
     * 
     * @return
     * @throws InterruptedException
     */
    public HashMap<String, HashMap<String, String>> getStudentDetailsResultinSolarSearch() throws InterruptedException {
        new SMUtils().waitForSpinnertoDisapper( driver, 120 );
        Log.message( "Getting Student Details.. in Solar Search" );
        ArrayList<String> usernames = new ArrayList<>( listOfUserNamesSolarSearchResult.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() ) );
        ArrayList<String> studentNames = new ArrayList<>( listOfStudentNamesSolarSearchResult.stream().map( element -> element.getText().trim() ).collect( Collectors.toList() ) );
        ArrayList<String> studentGrades = new ArrayList<>( listOfGradeValueSolarSearchResult.stream().map( element -> element.getText().trim().substring( 1 ) ).collect( Collectors.toList() ) );

        HashMap<String, HashMap<String, String>> studentDetails = new HashMap<String, HashMap<String, String>>();

        IntStream.range( 0, usernames.size() ).forEach( index -> {
            HashMap<String, String> otherDetails = new HashMap<String, String>();
            otherDetails.put( Constants.NAME, studentNames.get( index ) );
            otherDetails.put( Constants.GRADE, studentGrades.get( index ) );
            studentDetails.put( usernames.get( index ), otherDetails );
        } );

        return studentDetails;

    }

    /**
     * Return True if student is found on the Solar search
     * 
     * @param studentUserName
     * @return
     */
    public boolean isStudentFoundInSolarSearch( String studentUserName ) {
        txtBoxSearchinAddGroupPopup.clear();
        txtBoxSearchinAddGroupPopup.sendKeys( studentUserName );
        try {
            SMUtils.waitForLocator( driver, By.cssSelector( SMUtils.spinnerElement ), 3 );
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
        } catch ( InterruptedException e ) {}
        if ( !new SMUtils().waitForElement( driver, gradeNotSelectedErrMsg, 3 ) ) {
            try {
                return getStudentDetailsResultinSolarSearch().keySet().contains( studentUserName );
            } catch ( InterruptedException e ) {
                e.printStackTrace();
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * To Click on X Icon for student name create group (This is specific to
     * create group, we are deselecting the selected student by clicking the X
     * icon in the Search box)
     */

    public void clickXinChipAreaForStudent( String StudentFirstNameAndLastName ) {
        Log.event( "Clicking on X icon for added group name" + StudentFirstNameAndLastName );
        try {
            listOfChipRoot.stream().forEach( element -> {
                if ( element.findElement( By.cssSelector( "span.chip-text" ) ).getAttribute( "title" ).equals( StudentFirstNameAndLastName ) ) {
                    WebElement xElement = SMUtils.getWebElementDirect( driver, element.findElement( By.cssSelector( "cel-icon " ) ), "img" );
                    SMUtils.click( driver, xElement );
                    Log.message( "Clicked the X icon for the student: " + StudentFirstNameAndLastName );
                }
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    @FindBy ( css = "div.chip-area span.chips" )
    List<WebElement> listOfChipRoot;

    /**
     * To verify the Message in Create Group Popup To search for students in
     * your school, start typing their username or given name.
     * 
     * @return
     */
    public boolean verifySolarSearchMessage() {
        return gradeNotSelectedErrMsg.getText().trim().equals( Constants.GroupUIConstants.SOLAR_SEARCH_MESSAGE ) ? true : false;
    }

    /**
     * Verify Error message For Please type 3 or more letters to search in
     * Create Group
     * 
     * @return
     */
    public boolean verifyErrorForStudentSearchLessThan3() {
        addStudentTxtBox.clear();
        addStudentTxtBox.sendKeys( "st" );
        return errorMessageForLimit100Students.getText().trim().equals( Constants.Groups.PLEASE_TYPE_3_OR_MORE_ERROR ) ? true : false;
    }

    /**
     * Click cancel button in Add Stud to Group popup
     */
    public void clickCancelButtoninAddStudentToGroupPopup() {
        WebElement rootCancel = driver.findElement( By.cssSelector( "cel-button.cancel-btn-wrapper.hydrated" ) );
        SMUtils.click( driver, SMUtils.getWebElement( driver, rootCancel, "button" ) );
    }

    /**
     * Verify Google class message is displaying correctly
     * 
     * @return
     */
    public boolean verifyMessageForGoogleClass() {
        SMUtils.waitForElement( driver, messageForGoogleClass );
        return messageForGoogleClass.getText().trim().equals( Constants.GOOGLE_CLASS_TEXT ) ? true : false;
    }

    /***
     * return the masteryFilterComponent Object
     *
     * @return
     */
    public MasteryFiltersComponent getMasteryFilterComponent() {
        return masteryFilterComponent;
    }

    /**
     * Click add student to group button
     */
    public void clickAddStudentButton() {
        SMUtils.waitForElement( driver, addStudentButton );
        SMUtils.click( driver, addStudentButton );
        Log.message( "clicked add student button" );
    }

    /**
     * Enter Key in search bar
     * 
     * @param keyWord
     */
    public void enterKeywordInSearch( String keyWord ) {
        SMUtils.enterValue( searchGroupTextField, keyWord );
    }

}
