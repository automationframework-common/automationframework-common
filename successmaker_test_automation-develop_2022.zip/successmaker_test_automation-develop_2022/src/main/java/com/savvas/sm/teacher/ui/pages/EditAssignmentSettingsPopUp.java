package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.List;

import java.util.concurrent.atomic.AtomicBoolean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class EditAssignmentSettingsPopUp extends LoadableComponent<EditAssignmentSettingsPopUp> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    private WebDriver driver;
    boolean isPageLoaded;
    

    
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    
//    @IFindBy (how = How.CSS, using = "section.page-title div h1" , AI = false)
//    public WebElement lblCPRHeader;

    @IFindBy (how = How.CSS, using = ".tile__title", AI = false ) 
    public WebElement editassignmentSettingsTitle;

    @IFindBy (how = How.CSS, using = "div.dialog-wrapper.sc-cel-dialog.dialog-wrapper--visible", AI = false ) 
    public WebElement editAssigmentSettingPopup;

    @IFindBy (how = How.CSS, using = "cel-button:not([class=cancel-button])[class=hydrated]", AI = false ) 
    public WebElement saveButton;

    @IFindBy (how = How.CSS, using = ".cancel-button", AI = false ) 
    public WebElement cancelButton;

    @IFindBy (how = How.CSS, using = "div.setting-label", AI = false ) 
    public WebElement sessionLength;

    public @FindBy ( css = "div.first.column > div > setting-control > div.setting-label" ) 
    List<WebElement> editAssignmentFirstSettingsLabel;

    public @FindBy ( css = "div.second.column > div > setting-control > div.setting-label" ) 
    List<WebElement> editAssignmentSecondSettingsLabel;

    public String sessionLengthButton = "button";

    public @FindBy ( css = "div.setting-label" ) 
    List<WebElement> headerList;
    
    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[1]/span/span", AI = false )
    public WebElement sessionLengthValue;

    //TODO: Replace the xpath with css locator
    @IFindBy ( how = How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[2]/span/span", AI = false )
    public WebElement idealTime;

    public EditAssignmentSettingsPopUp() {}
    /**
     * Constructor to invoke the edit Assignment Settings
     *
     * @param driver
     */

    public EditAssignmentSettingsPopUp( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
        PageFactory.initElements(finder, this);
        elementLayer = new ElementLayer(driver);
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, editassignmentSettingsTitle );

    }

    @Override
    protected void isLoaded() throws Error {
        // TODO Auto-generated method stub

    }

    /**
     * To verify the Settings Label is Present on the first Column
     *
     *
     * @return Boolean
     *
     *
     */

    public boolean verifyAssignmentSettingsLabelForFirstColumn( String setting_label ) throws Exception {
        Log.message( "Verifying the Edit Assignment Settings First Label Present in Sub Navigation Assignments Bar of Groups Page" );
        AtomicBoolean set_flag = new AtomicBoolean( false );
        SMUtils.waitForElement( driver, sessionLength );
        editAssignmentFirstSettingsLabel.forEach( element -> {
            String headerText = element.getText();
            if ( headerText.trim().equalsIgnoreCase( setting_label.trim() ) ) {
                set_flag.set( true );
                return;
            }
        } );
        return set_flag.get();
    }

    /**
     * To verify the Settings Label is Present on the Second Column
     *
     *
     * @return Boolean
     *
     *
     */
    public boolean verifyAssignmentSettingsLabelForSecondColumn( String setting_label ) throws Exception {
        Log.message( "Verifying the Edit Assignment Settings Second Label Present in Sub Navigation Assignments Bar of Groups Page" );
        AtomicBoolean set_flag = new AtomicBoolean( false );
        SMUtils.waitForElement( driver, sessionLength );

        editAssignmentSecondSettingsLabel.forEach( element -> {
            String headerText = element.getText();
            if ( headerText.trim().equalsIgnoreCase( setting_label.trim() ) ) {
                set_flag.set( true );
                return;
            }
        } );
        return set_flag.get();
    }
    
    /**
     * To Get Session Length
     *
     * @return
     */
    public String getSessionLength() {
        SMUtils.waitForElement( driver, sessionLengthValue );
        String valueOfSessionLength = sessionLengthValue.getText().trim();
        Log.message( valueOfSessionLength );
        return valueOfSessionLength;
    }
}
