package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class HelpPage extends LoadableComponent<HelpPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    public  WebDriver driver;
    boolean isPageLoaded;
    public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();   

    // ********* SuccessMaker Help Page Elements ***************

    @IFindBy ( how=How.CSS,using = "div.logo-wrapper a" ,AI = false)
    public WebElement logoSM;

    public HelpPage() {}
    /**
     *
     * Constructor class for Help contextual page and initializing the driver
     * for page factory objects.
     *
     * @param driver
     * @param url
     */
    public HelpPage( WebDriver driver ) {
        this.driver = driver;
        // Have Topbar here and init
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
    	PageFactory.initElements(finder, this);
    	elementLayer = new ElementLayer(driver);
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, logoSM );

    }

    @Override
    protected void isLoaded() throws Error {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( SMUtils.waitForElement( driver, logoSM ) ) {
            Log.message( "SM Help page loaded successfully." );
        } else {
            Log.fail( "SM Help page did not load." );
        }

    }

}
