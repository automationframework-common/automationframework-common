package com.savvas.sm.admin.api.tests;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants.AdminAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.settings.HolidayScheduler;

public class EditHolidaySchedulerTest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    public RBSUtils rbsUtils = new RBSUtils();
    private String username;
    private String password;
    private String orgId;
    private String userId;
    private String accessToken;
    private Map<String, String> response;
    HashMap<String, String> params = new HashMap<String, String>();
    HolidayScheduler holidayScheduler = new HolidayScheduler();
    private String flexSchool;
    private String mathSchool;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {

        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty( "SMAppUrl" );
        orgId = configProperty.getProperty( "district_ID" );

        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );

        // Creating Admin user data to login
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        accessToken = rbsUtils.getAccessToken( username, password );

    }

    @Test ( dataProvider = "getData_Positive", groups = { "smoke_test_case", "SMK-50747", "Edit Holiday Scheduler", "API" }, priority = 1 )
    public void editHolidayScheduler_Positive( String testcaseNumber, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseNumber + ": " + testDescription );
        HashMap<String, String> headers = new HashMap<String, String>();
        String keyValueFromResponse;

        switch ( scenario ) {
            case "Valid Holiday which does not exit":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

                HashMap<String, String> keyValue = new HashMap<String, String>();
                LocalDate now = LocalDate.now();
                LocalDate firstMonday = now.with( TemporalAdjusters.next( DayOfWeek.MONDAY ) );
                LocalDate plusDays = firstMonday.plusDays( 3 );
                String endDate = plusDays.toString();
                String startDate = firstMonday.toString();

                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, endDate, "Local Holiday", orgId );
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                deleteAllHolidays( response );
                Log.message( response.toString() );
                // Get call to verify the unused Date

                Log.message( "Holiday Creation for the date " + startDate + " as Local Holiday" );

                // Creating new Holiday
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, startDate, "Local Holiday", orgId );

                Log.message( response.toString() );
                // Data Validation
                Map<String, String> getResponse = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                String keyValueFromGetResponse = SMUtils.getKeyValueFromResponse( getResponse.get( "body" ), "data" );
                keyValue.clear();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromGetResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromGetResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );

                Log.assertThat( keyValue.containsKey( startDate ) && keyValue.get( startDate ).equals( "Local Holiday" ), "The New Holiday is added", "The New Holiday is not added" );
                break;
            case "Valid for Updating the existing holiday":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.next( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, startDate, "Local Holiday", orgId );
                // Get call to verify the unused Date
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );
                keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data" );
                keyValue = new HashMap<String, String>();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );

                String existingDate = new ArrayList<>( keyValue.keySet() ).get( 0 );
                String existingDescription = keyValue.get( existingDate );

                Log.message( "The existing date choosen to update is " + existingDate + "and the description is " + existingDescription );

                // Creating new Holiday
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, existingDate, existingDate, "Updated Existing Holiday", orgId );
                Log.message( response.toString() );
                // Data Validation
                getResponse = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                keyValueFromGetResponse = SMUtils.getKeyValueFromResponse( getResponse.get( "body" ), "data" );
                keyValue.clear();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromGetResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromGetResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );

                Log.assertThat( keyValue.containsKey( existingDate ) && keyValue.get( existingDate ).equals( "Updated Existing Holiday" ), "The existing holiday is updated with description", "The existing holiday is not updated with description" );
                break;

            case "Valid with more than one day":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                // Get call to verify the unused Date
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );
                keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data" );
                keyValue = new HashMap<String, String>();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );

                // Getting first monday to add the holidays
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.firstInMonth( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();
                endDate = firstMonday.plusDays( 1 ).toString();
                List<String> listOfHolidays = Arrays.asList( startDate, endDate );
                // Creating new Holiday
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, endDate, "Newly Added Multiple Holidays", orgId );

                // Data Validation
                getResponse = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                keyValueFromGetResponse = SMUtils.getKeyValueFromResponse( getResponse.get( "body" ), "data" );
                keyValue.clear();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromGetResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromGetResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );
                Log.assertThat( new ArrayList<>( keyValue.keySet() ).containsAll( listOfHolidays ), "The Multiple Holidays are created", "The Multiple Holidays are not created" );
                break;
            case "Valid for Updating the existing holidays":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                // Get call to verify the unused Date
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );
                keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data" );
                keyValue = new HashMap<String, String>();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );

                // Getting first monday to add the holidays
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.firstInMonth( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();
                endDate = firstMonday.plusDays( 1 ).toString();
                listOfHolidays = Arrays.asList( startDate, endDate );
                // Creating new Holiday
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, endDate, "Update Multiple Holidays", orgId );

                // Data Validation
                getResponse = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                keyValueFromGetResponse = SMUtils.getKeyValueFromResponse( getResponse.get( "body" ), "data" );
                keyValue.clear();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromGetResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromGetResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );
                Log.assertThat( new ArrayList<>( keyValue.keySet() ).containsAll( listOfHolidays ), "The Multiple Holidays are Updated", "The Multiple Holidays are not Updated" );
                Log.assertThat( keyValue.get( startDate ).equals( "Update Multiple Holidays" ) && keyValue.get( endDate ).equals( "Update Multiple Holidays" ), "The multiple holidays description is updated",
                        "The multiple holidays description is not updated" );
                break;
            case "Valid for weekends":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                // Get call to verify the unused Date
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );
                keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data" );
                keyValue = new HashMap<String, String>();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );

                // Getting first Saturday and sunday to add the holidays
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.firstInMonth( DayOfWeek.SATURDAY ) );
                startDate = firstMonday.toString();
                endDate = firstMonday.plusDays( 1 ).toString();
                listOfHolidays = Arrays.asList( startDate, endDate );
                // Creating new Holiday
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, endDate, "Update Multiple Holidays", orgId );

                // Data Validation
                getResponse = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                keyValueFromGetResponse = SMUtils.getKeyValueFromResponse( getResponse.get( "body" ), "data" );
                keyValue.clear();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromGetResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromGetResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );
                Log.assertThat( !new ArrayList<>( keyValue.keySet() ).containsAll( listOfHolidays ), "The Multiple Holidays for Saturday and sunday are not created", "The Multiple Holidays for saturday and sunday are created" );
                break;
            case "Valid for empty description":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                // Get call to verify the unused Date
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );
                keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data" );
                keyValue = new HashMap<String, String>();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );

                // Getting first Saturday and sunday to add the holidays
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.firstInMonth( DayOfWeek.FRIDAY ) );
                startDate = firstMonday.toString();
                // Creating new Holiday
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, startDate, "", orgId );

                // Data Validation
                getResponse = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                keyValueFromGetResponse = SMUtils.getKeyValueFromResponse( getResponse.get( "body" ), "data" );
                keyValue.clear();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromGetResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromGetResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );
                Log.assertThat( keyValue.get( startDate ).equals( "" ), "The holiday updated with empty description", "The holiday is not updated with empty description" );
                break;
            case "Valid with more than two days":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                // Get call to verify the unused Date
                response = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                Log.message( response.toString() );
                keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.get( "body" ), "data" );
                keyValue = new HashMap<String, String>();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );

                // Getting first monday to add the holidays
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.lastInMonth( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();
                endDate = firstMonday.plusDays( 1 ).toString();
                listOfHolidays = Arrays.asList( startDate, endDate );
                // Creating new Holiday
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, endDate, "Newly Added Multiple Holidays", orgId );

                // Data Validation
                getResponse = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );
                keyValueFromGetResponse = SMUtils.getKeyValueFromResponse( getResponse.get( "body" ), "data" );
                keyValue.clear();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromGetResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromGetResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );
                Log.assertThat( new ArrayList<>( keyValue.keySet() ).containsAll( listOfHolidays ), "The Multiple Holidays are created", "The Multiple Holidays are not created" );
                Log.assertThat( keyValue.get( startDate ).equals( "Newly Added Multiple Holidays" ) && keyValue.get( endDate ).equals( "Newly Added Multiple Holidays" ), "The multiple holidays updated with same description",
                        "The multiple holidays is not updated with same description" );
                break;
        }

        // Validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "editHolidayScheduler", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );

        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData_Positive() {
        Object[][] data = { { "tcEditHoliday001", "Verify a new holiday is added when the request is made with a date which doesnt exist in the holiday list", "200", "Valid Holiday which does not exit" },
                { "tcEditHoliday002", "Verify if requested date is already present in the holiday list, the holiday list is updated with the new data provided", "200", "Valid for Updating the existing holiday" },
                { "tcEditHoliday003", "Verify if the holiday is more than a day, all those dates are added to the list", "200", "Valid with more than one day" },
                { "tcEditHoliday004", "Verify all the requested dates are updated in the holiday list if those dates are already present in the holiday list", "200", "Valid for Updating the existing holidays" },
                { "tcEditHoliday005", "Verify we should not create holiday for saturday and sunday", "200", "Valid for weekends" },
                { "tcEditHoliday006", "Verify the data sholud be added/updated in holiday list when description is not given", "200", "Valid for empty description" },
                { "tcEditHoliday007", "Verify two or more data are added/edited when same description is given", "200", "Valid with more than two days" } };
        return data;
    }

    @Test ( dataProvider = "getData_Negative", groups = { "SMK-50747", "Edit Holiday Scheduler", "API" }, priority = 1 )
    public void editHolidayScheduler_Negative( String testcaseNumber, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseNumber + ": " + testDescription );
        HashMap<String, String> headers = new HashMap<String, String>();
        List<String> selectedOrganizationId = new ArrayList<>();
        switch ( scenario ) {
            case "Invalid with invalid dates":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, "2022-15-13", "2022-15-13", "Local Holiday", orgId );
                Map<String, String> getResponse = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );

                String keyValueFromResponse = SMUtils.getKeyValueFromResponse( getResponse.get( "body" ), "data" );
                HashMap<String, String> keyValue = new HashMap<String, String>();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );

                Log.assertThat( !keyValue.containsKey( "2022-15-13" ), "The invalid date is not created as holiday", "The invalid date is created as holiday" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "500_Schema", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                break;
            case "Invalid with invalid description":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

                LocalDate now = LocalDate.now();
                LocalDate firstMonday = now.with( TemporalAdjusters.previous( DayOfWeek.MONDAY ) );
                String startDate = firstMonday.toString();

                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, startDate, "The longest holiday description for invalid scenario", orgId );
                getResponse = holidayScheduler.getHolidayScheduler( smUrl, headers, orgId );

                keyValueFromResponse = SMUtils.getKeyValueFromResponse( getResponse.get( "body" ), "data" );
                keyValue = new HashMap<String, String>();
                IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
                    JSONArray ja = new JSONArray( keyValueFromResponse );
                    JSONObject jObj = ja.getJSONObject( itr );
                    keyValue.put( jObj.get( "date" ).toString().substring( 0, 10 ), jObj.get( "description" ).toString() );
                } );

                Log.assertThat( !keyValue.containsKey( startDate ), "The date with invalid description is not created as holiday", "The date with invalid description is created as holiday" );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "500_Schema", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                break;
            case "Invalid with teacher/student users":
                // Getting Teacher Details
                String teacherDetails = RBSDataSetup.orgTeacherDetails.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ).get( "Teacher1" );
                // Headers
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( AdminAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
                headers.put( AdminAPIConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_SCHOOL_ADMIN );
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.next( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, startDate, "Local Holiday", orgId );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "403_Schema", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                break;
            case "Invalid with wrong bearer token":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken + "invalid" );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.next( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, startDate, "Local Holiday", orgId );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "401_Schema", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                break;
            case "Invalid with wrong/empty user-id/org-id":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId + "invalid" );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.next( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, startDate, "Local Holiday", orgId );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "403_Schema", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                break;
            case "Invalid with end date lesser than the start date":
                // Headers
                headers.put( AdminAPIConstants.ORGID, orgId );
                headers.put( AdminAPIConstants.USERID, userId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + accessToken );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.next( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();
                LocalDate plusDays = firstMonday.plusDays( -3 );
                String endDate = plusDays.toString();
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, endDate, "Local Holiday", orgId );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "400_Schema", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                break;
            case "Invalid with subdistrict admin details":
                // Getting Subdistrict admin details
                String subdistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
                String subdistrictUserID = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERID );
                String subdistrictUsername = SMUtils.getKeyValueFromResponse( subdistrictAdminDetails, RBSDataSetupConstants.USERNAME );
                String subDistrictwithSchoolId = RBSDataSetup.subDistrictwithSchoolId;
                // Setting Headers
                headers.put( AdminAPIConstants.ORGID, subDistrictwithSchoolId );
                headers.put( AdminAPIConstants.USERID, subdistrictUserID );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( subdistrictUsername, password ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_SUBDISTRICT_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.next( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, startDate, "Local Holiday", orgId );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "403_Schema", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                break;
            case "Invalid with school admin details":
                // Getting School admin details
                String schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
                String schoolAdminUserID = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID );
                String schoolAdminUsername = SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERNAME );
                // Setting Headers
                headers.put( AdminAPIConstants.ORGID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
                headers.put( AdminAPIConstants.USERID, schoolAdminUserID );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( schoolAdminUsername, password ) );
                headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_SCHOOL_ADMIN );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                now = LocalDate.now();
                firstMonday = now.with( TemporalAdjusters.next( DayOfWeek.MONDAY ) );
                startDate = firstMonday.toString();
                response = holidayScheduler.putHolidayScheduler( smUrl, headers, startDate, startDate, "Local Holiday", orgId );
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "403_Schema", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );
                break;
        }
        Log.message( response.toString() );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData_Negative() {
        Object[][] data = { { "tcEditHoliday008", "Verify the data should not be added/updated in holiday list when invalid/empty date format is given", "500", "Invalid with invalid dates" },
                { "tcEditHoliday009", "Verify holiday description with more than 50 character", "500", "Invalid with invalid description" },
                { "tcEditHoliday0010", "Verify teacher/student cannot add/update holidays", "403", "Invalid with teacher/student users" }, { "tcEditHoliday0011", "Verify when wrong bearer token given", "401", "Invalid with wrong bearer token" },
                { "tcEditHoliday0011", "Verify holiday is not created if user-id/org-id is wrong or empty", "403", "Invalid with wrong/empty user-id/org-id" },
                { "tcEditHoliday0012", "Verify holiday should not be added/updated when endDate is given lesser than startDate", "400", "Invalid with end date lesser than the start date" },
                { "tcEditHoliday0013", "Verify subdistrict admin cannot add/update holidays", "403", "Invalid with subdistrict admin details" },
                { "tcEditHoliday0014", "Verify school admin cannot add/update holidays", "403", "Invalid with school admin details" }, { "tcEditHoliday0015", "Verify when wrong bearer token given", "401", "Invalid with wrong bearer token" } };
        return data;
    }

    public void deleteAllHolidays( Map<String, String> response ) throws Exception {
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( response.get( Constants.RESPONSE_BODY ), "data" );
        List<String> dateFromResponse = new ArrayList<String>();
        IntStream.range( 0, SMUtils.getWordCount( keyValueFromResponse, "description" ) ).forEach( itr -> {
            JSONArray ja = new JSONArray( keyValueFromResponse );
            JSONObject jObj = ja.getJSONObject( itr );
            dateFromResponse.add( jObj.get( "date" ).toString().substring( 0, 10 ) );
        } );
        Collections.sort( dateFromResponse );
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( AdminAPIConstants.ORGID, orgId );
        headers.put( AdminAPIConstants.USERID, userId );
        headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( username, password ) );
        headers.put( AdminAPIConstants.SUBROLETYPE, AdminAPIConstants.SUBROLETYPE_DISTRICT_ADMIN );
        holidayScheduler.deleteHolidayScheduler( smUrl, headers, dateFromResponse.get( 0 ), dateFromResponse.get( dateFromResponse.size() - 1 ), "", orgId );
    }

}