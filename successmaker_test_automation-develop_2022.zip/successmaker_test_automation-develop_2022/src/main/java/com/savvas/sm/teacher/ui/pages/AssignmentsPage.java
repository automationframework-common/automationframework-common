package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Assignments;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class AssignmentsPage extends LoadableComponent<AssignmentsPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    private WebDriver driver;
    boolean isPageLoaded;
    
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();
    
    @IFindBy (how = How.CSS,using = "h4.col-10.assignment-heading.pl-0",AI=false )
    public WebElement assignmentTxt;
    
    @IFindBy (how = How.CSS, using = "cel-platform-navbar.hydrated", AI = false )
    public WebElement cousewareBtnRoot;

    @IFindBy (how = How.CSS, using = "cel-platform-navbar.hydrated", AI = false )
    public WebElement assignmentsubMenuGrandRoot;

    @IFindBy (how = How.CSS, using = "td.th-action-button > cel-button:not([color='primary'])", AI = false )
    public WebElement viewAssignmentbtnRoot;

    @IFindBy (how = How.CSS, using = "div.tile__body>span:nth-child(1)", AI = false )
    public WebElement titleOfAssignmentDetailsPage;

    @IFindBy (how = How.CSS, using = "div.tile__body>span:nth-child(2)", AI = false )
    public WebElement subTitleOfAssignmentDetailsPage;

    @IFindBy (how = How.CSS, using = "tbody.table-body > tr:nth-child(1)> td.action-menu-cell > cel-button-menu", AI = false )
    public WebElement dotEllipsisOptionRoot;

    // ********Assignments setting elements******

    // **** Edit Assignment setting
    @FindBy ( xpath = "//div[@class='dropdown-select-options-wrapper sc-cel-dropdown-select']/ul/li" )
    List<WebElement> dropdownGeneric;

    @IFindBy (how=How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[1]", AI = false )
    public WebElement sessionLength;

    @IFindBy (how=How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[1]/span/span", AI = false )
    public WebElement sessionLengthValue;

    @IFindBy (how=How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[2]", AI = false )
    public WebElement idealTime;

    @IFindBy (how=How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[2]/span/span", AI = false )
    public WebElement idealTimeValue;

    @IFindBy (how=How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[3]", AI = false )
    public WebElement showProgressReport;

    @IFindBy (how=How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[4]", AI = false )
    public WebElement speedGamesTimePerQuestion;

    @IFindBy (how=How.XPATH, using = "(//button[@class='dropdown-select-trigger sc-cel-dropdown-select'])[5]", AI = false )
    public WebElement speedGameTotalTime;

    @FindBy ( css = "filter-group-student >div >div.list-data > div" )
    List<WebElement> studentListAssignmentPopUp;

    @FindBy ( css = "div.table-container>table>tbody>tr" )
    List<WebElement> studentListAssignmentTable;

    // *******Pause All Student

    @IFindBy (how = How.CSS, using = "cel-button-menu.tile-ellipsis-btn", AI = false )
    public WebElement pauseAllStudentsGrandRoot;

    @IFindBy (how = How.CSS, using = "div .confirm-modal-footer > cel-button:nth-of-type(1)", AI = false )
    public WebElement cancelbtnPauseStudentParent;

    // ********Delete Assignments
    // ********Delete all Assignments

    @IFindBy (how = How.CSS, using = "cel-button-menu.tile-ellipsis-btn", AI = false )
    public WebElement deleteAssignmentGrandRoot;

    @IFindBy (how = How.CSS, using = "div .confirm-modal-footer > cel-button:nth-of-type(2)", AI = false )
    public WebElement deleteAssignmentsDeleteBtn;

    @IFindBy (how = How.CSS, using = "cel-button-menu.tile-ellipsis-btn", AI = false )
    public WebElement deleteAssignment;

    @IFindBy (how = How.CSS, using = "div .confirm-modal-footer > cel-button:nth-of-type(2)", AI = false )
    public WebElement deleteAssignmentsCancelBtn;

    @IFindBy (how = How.CSS, using = "tr:nth-of-type(1) > td.th-action-button > cel-button", AI = false )
    public WebElement viewAssignmentFirstRoot;

    @IFindBy (how = How.CSS, using = "span.message", AI = false )
    public WebElement deleteMessage;

    // ********Column name

    @IFindBy (how = How.CSS, using = "assignment-list > div > div.container.list-assignment > grid-table > div > table > thead > tr >th:nth-child(1)", AI = false )
    public WebElement columnAssignmnetTitle;

    @IFindBy (how = How.CSS, using = "assignment-list > div > div.container.list-assignment > grid-table > div > table > thead > tr >th:nth-child(2)", AI = false )
    public WebElement columnDateAssigned;

    @IFindBy (how = How.CSS, using = "assignment-list > div > div.container.list-assignment > grid-table > div > table > thead > tr >th:nth-child(3)", AI = false )
    public WebElement columnActiveStudents;

    @IFindBy (how = How.CSS, using = "assignment-list > div > div.container.list-assignment > grid-table > div > table > thead > tr >th:nth-child(4)", AI = false )
    public WebElement columnPausedStudents;

    @IFindBy (how = How.CSS, using = "assignment-list > div > div.container.list-assignment > grid-table > div > table > thead > tr >th:nth-child(5)", AI = false )
    public WebElement columnFluencyFiles;

    @FindBy ( css = "tbody.table-body .table-row td .font-weight-bold" )
    List<WebElement> assignmentNameList;

    @FindBy ( css = "tbody.table-body .img-tile" )
    List<WebElement> assignmentImagesList;

    //@FindBy ( css = "text-overflow-nowrap font-weight-bold" )
    @FindBy ( css = "span.text-overflow-nowrap.font-weight-bold" )
    List<WebElement> assignmentTitle;

    @IFindBy (how = How.CSS, using = "tbody.table-body", AI = false )
    public WebElement studentList;

    @IFindBy (how = How.CSS, using = "table cel-icon", AI = false )
    public WebElement arrowIcon;

    @FindBy ( css = "tbody span.text-overflow-nowrap" )
    List<WebElement> assignementRowTextList;

    @FindBy ( css = "table span.sort-type-none" )
    List<WebElement> columnNames;

    @IFindBy (how = How.CSS, using = ".site-layout h4", AI = false )
    public WebElement assignmentHeading;

    @FindBy ( css = "tr.table-row.highlight-on-hover" )
    List<WebElement> assignmentRows;

//    @IFindBy (how = How.CSS, using = "tr.table-row.highlight-on-hover", AI = false )
//    public WebElement assignmentRow;
    @FindBy (css="tr.table-row.highlight-on-hover")
    public WebElement assignmentRow;

    /** zero State Assignment **/

    @IFindBy (how = How.CSS, using = "div.zero-state-content h3", AI = false )
    public WebElement zeroStateHeader;

    @IFindBy (how = How.CSS, using = "div.zero-state-content span", AI = false )
    public WebElement zeroStateMessage;

    public static String arrowUp = "icon_arrow_thin_up";
    public static String arrowDown = "icon_arrow_thin_down";
    public static String dateAssignedCSS = ":nth-child(2) span";
    public static String activeStudentsCSS = ":nth-child(3) span";
    public static String pausedStudentsCSS = ":nth-child(4) span";
    public static String fluencyFilesCSS = ":nth-child(5) span";
    public static String assignmentNameCSS = "span.text-overflow-nowrap.font-weight-bold";

    // Root Child Elements

    // *****Assignments Sub menu
    private static String assignmentssubMenuParent = "cel-dropdown-menu-box.box";
    private static String assignmentsubMenuChild = "span[aria-label='Assignments']";

    private static String viewAssignmentbtnChild = ".secondary_button";

    // *********Assignment Page Table******
    @FindBy ( css = ".table-body>tr" )
    List<WebElement> availableAssignments;

    String assignmentTitleCSS = "td:nth-of-type(1)>span:nth-of-type(2)";
    String assignmentDateCSS = "td:nth-of-type(2)>span";
    String assignmentActiveStudentsCountCSS = "td:nth-of-type(3)>span";
    String assignmentPausedStudentsCountCSS = "td:nth-of-type(4)>span";
    String assignmentFluencyFilesCountCSS = "td:nth-of-type(5)>span";
    String viewAssignmentBtnRootCSS = "td:nth-of-type(6)>cel-button";
    String viewAssignmentBtnCSS = ".secondary_button";
    String fluencyFilesCount = "td:nth-child(5) span";
    String assignmentListImage = "span[class='text-overflow-nowrap font-weight-bold']";

    // *********Common Methods*************

    
    public AssignmentsPage() {}
    /**
     *
     * Constructor class for Assignment page and initializing the driver for
     * page factory objects.
     *
     * @param driver
     * @param url
     */

    public AssignmentsPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
        PageFactory.initElements(finder, this);
        elementLayer = new ElementLayer(driver);
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, assignmentTxt );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }

    }

    /**
     * To refresh Assignment Page
     *
     * @return
     * @return
     */
    public void refreshPage() {
        SMUtils.sendF5Key( driver );
        SMUtils.waitForElement( driver, cousewareBtnRoot );
    }

    /**
     * Clicks the View Assignment for the given assignment name
     *
     * @param assignmentName
     */
    public AssignmentDetailsPage viewAssignmentDetailsByAssignmentName( String assignmentName ) {
        SMUtils.waitForElement( driver, assignmentRow, 5 );
        for ( WebElement assignment : availableAssignments ) {
            WebElement assignmentTitleElement = SMUtils.getChildWebElementFromParent( assignment, assignmentTitleCSS );
            if ( assignmentTitleElement.getText().trim().equals( assignmentName ) ) {
                WebElement viewAssignmentBtnRootElement = SMUtils.getChildWebElementFromParent( assignment, viewAssignmentBtnRootCSS );
                WebElement viewAssignmentBtnElement = SMUtils.getWebElement( driver, viewAssignmentBtnRootElement, viewAssignmentBtnCSS );
                SMUtils.scrollIntoView( driver, viewAssignmentBtnElement );
                SMUtils.clickJS( driver, viewAssignmentBtnElement );
                SMUtils.waitForElement( driver, studentList, 5 );
                Log.message( assignmentName + " assignment is viewed", driver, true );
                break;
            }
        }
        return new AssignmentDetailsPage( driver );
    }

    /**
     * To get viewAssignment button element
     *
     * @return
     * @return
     */
    public WebElement viewAssignmentElement() {
        SMUtils.waitForElement( driver, viewAssignmentbtnRoot );
        WebElement viewAssignment = SMUtils.getWebElement( driver, viewAssignmentbtnRoot, viewAssignmentbtnChild );
        return viewAssignment;

    }

    /**
     * Gets AssignmnetTitle column name
     */
    public String getColumnAssignmnetTitle() {
        return columnAssignmnetTitle.getText();
    }

    /**
     * Gets DateAssigned column name
     */
    public String getColumnDateAssigned() {
        return columnDateAssigned.getText();
    }

    /**
     * Gets ActiveStudents column name
     */
    public String getColumnActiveStudents() {
        return columnActiveStudents.getText();
    }

    /**
     * Gets PausedStudents column name
     */
    public String getColumnPausedStudents() {
        return columnPausedStudents.getText();
    }

    /**
     * Gets FluencyFiles column name
     */
    public String getColumnFluencyFiles() {
        return columnFluencyFiles.getText();
    }

    /**
     * To click Assignments Sub Menu
     */

    public void clickAssignmentSubMenu() {
        SMUtils.waitForElement( driver, assignmentsubMenuGrandRoot );
        WebElement assignmentSubMenuParent = SMUtils.getWebElement( driver, assignmentsubMenuGrandRoot, assignmentssubMenuParent );
        WebElement assignmentSubMenu = SMUtils.getWebElement( driver, assignmentSubMenuParent, assignmentsubMenuChild );
        SMUtils.clickJS( driver, assignmentSubMenu );
        Log.message( "Clicked Assignments sub menu" );

    }

    /**
     * To Click View Assignment Math Button
     */
    public AssignmentDetailsPage clickViewAssignment() {
        SMUtils.waitForElement( driver, viewAssignmentbtnRoot );
        WebElement viewAssignment = SMUtils.getWebElement( driver, viewAssignmentbtnRoot, viewAssignmentbtnChild );
        SMUtils.clickJS( driver, viewAssignment );
        Log.message( "Clicked View Assignment  Button", driver, true );
        return new AssignmentDetailsPage( driver );
    }

    /**
     * Getting all assignment list
     *
     * @return
     */
    public List<String> getAllAssignmentNames() {
        List<String> assignmentnames = new ArrayList<>();
        for ( WebElement assignment : availableAssignments ) {
            WebElement assignmentTitleElement = SMUtils.getChildWebElementFromParent( assignment, assignmentTitleCSS );
            assignmentnames.add( assignmentTitleElement.getText().trim() );
        }
        return assignmentnames;
    }

    /*
     * To get list of assignments
     *
     * @param assignmentName
     *
     * @return
     */
    public List<String> assignmentsList() {
        List<String> listOfAssignments = new ArrayList<>();
        List<WebElement> assignmentList = assignmentNameList;
        for ( WebElement value : assignmentList ) {
            listOfAssignments.add( value.getText().trim() );
        }
        Log.message( "Got all assignment names" );
        return listOfAssignments;

    }

    /**
     * Return all the subject Names based on the subject
     *
     * @param subject
     * @return
     */
    public List<String> getAssignmentListBasedOnSubject( String subject ) {
        List<String> listOfAssignments = new ArrayList<>();
        for ( WebElement value : assignmentImagesList ) {
            if ( value.getAttribute( "src" ).contains( subject ) ) {
                WebElement element = value.findElement( By.xpath( "./../.." ) );
                WebElement title = element.findElement( By.cssSelector( assignmentListImage ) );
                listOfAssignments.add( title.getText().trim() );
            }
        }
        Log.message( "Got all assignment names from" + subject + " Subject" );
        return listOfAssignments;
    }

    /**
     * Is Assignment Present
     *
     * @param assignmentName
     * @return true if present
     */
    public boolean isAssignmentPresent( String assignmentName ) {
        boolean flag = false;
        List<String> assignmentNames = new ArrayList<>();
        if ( assignmentTitle.size() > 0 ) {
            for ( WebElement assignmentNameElement : assignmentTitle ) {
                assignmentNames.add( assignmentNameElement.getText().trim() );
            }
        }
        if ( assignmentNames.contains( assignmentName ) ) {
            return true;
        }
        return flag;
    }

    /**
     * To get available assignments
     */
    public void getAssignments() {
        for ( WebElement assignments : availableAssignments ) {
            WebElement assignmentTitleElement = SMUtils.getChildWebElementFromParent( assignments, assignmentTitleCSS );
            SMUtils.waitForElement( driver, assignmentTitleElement );
            Log.message( "Assignments displayed are:" + assignmentTitleElement.getText() );
        }

    }

    /**
     * To delete All Assignments in the assignment details page
     */
    public void deleteAllAssignments() {

        for ( WebElement assignment : availableAssignments ) {
            SMUtils.waitForElement( driver, viewAssignmentFirstRoot, 10 );
            WebElement viewAssignmentButton = SMUtils.getWebElement( driver, viewAssignmentFirstRoot, viewAssignmentbtnChild );
            SMUtils.waitForElement( driver, viewAssignmentButton, 10 );
            SMUtils.scrollWebElementToView( driver, viewAssignmentButton );
            SMUtils.clickJS( driver, viewAssignmentButton );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            assignmentDetailsPage.assignmentLevelEllipsis();
            assignmentDetailsPage.deleteAssignmenttab();
            assignmentDetailsPage.deleteAssignmentButton();
            SMUtils.nap( 5 );
            clickAssignmentSubMenu();
        }
    }

    /**
     * To delete All Assignments
     */
    public String assignmentListingZeroState() {

        if ( availableAssignments.isEmpty() ) {
            deleteMessage.getText().trim();
            Log.message( deleteMessage.getText().trim() );

        } else {
            deleteAllAssignments();
            SMUtils.waitForElement( driver, deleteMessage, 10 );
            Log.message( deleteMessage.getText().trim() );
        }
        return deleteMessage.getText().trim();
    }

    public String getAssignmentFluencyFileCount( String assignmentName ) {
        AtomicReference<String> fileCount = new AtomicReference<>();
        try {
            availableAssignments.stream().filter( assignmentNameUI -> assignmentNameUI.findElement( By.cssSelector( assignmentTitleCSS ) ).getText().trim().equalsIgnoreCase( assignmentName ) ).findAny().ifPresent( assignmentNameUIFinal -> {
                fileCount.set( assignmentNameUIFinal.findElement( By.cssSelector( fluencyFilesCount ) ).getText().trim() );
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return fileCount.get();
    }

    /**
     * To get the state of Arrow UP or Down
     *
     * @return
     */
    public String getArrowStateOfColumn() {
        String status = arrowIcon.getAttribute( "name" );
        if ( status.equals( arrowUp ) ) {
            return Constants.ASCENDING;
        } else if ( status.equals( arrowDown ) ) {
            return Constants.DESCENDING;
        } else {
            Log.fail( "Arrow icon is not found" );
            return null;
        }
    }

    /**
     * To click the column Name and select the sorting type
     *
     * @param columnName
     * @param sortingType - Ascending(up) or Descending(down)
     */
    public void clickColumnnAndSort( String columnName, String sortingType ) {
        columnNames.stream().filter( element -> element.getText().trim().equals( columnName ) ).forEach( element -> {
            SMUtils.click( driver, element );
            Log.message( "Clicked Column " + columnName );
        } );
        String state = getArrowStateOfColumn();
        if ( state.equals( Constants.DESCENDING ) ) {
            Log.fail( "The default sorting is not in ASCENDING Order" );
        }
        if ( sortingType.equals( Constants.DESCENDING ) ) {
            SMUtils.click( driver, arrowIcon );
            Log.message( "Clicked Arrow for Down" );
        }

    }

    /**
     * To get the column Name in which arrow icon present
     *
     * @return
     */
    public String getColumnNameOfArrow() {
        WebElement parent = arrowIcon.findElement( By.xpath( "../../.." ) );
        WebElement columnText = parent.findElement( By.cssSelector( "span" ) );
        return columnText.getText().trim();
    }

    /**
     * get the List of Assignment Names
     *
     * @return
     */
    public List<String> getColumnAssignmentValues() {
        List<String> assignementNameList = new ArrayList<>();
        int size = assignementRowTextList.size();
        if ( size > 0 ) {
            for ( int i = 0; i < size; i += 5 ) {
                String assignementName = assignementRowTextList.get( i ).getText().trim();
                assignementNameList.add( assignementName );
            }
        } else {
            Log.message( "The Teacher has no assignment" );
        }
        return assignementNameList;
    }

    /**
     * To get the column Date Assigned values
     *
     * @return
     */
    public List<String> getColumnDateAssignedValues() {
        List<String> dateAssignedNameList = new ArrayList<>();
        int size = assignementRowTextList.size();
        if ( size > 0 ) {
            for ( int i = 1; i < size; i += 5 ) {
                String dateAssignedName = assignementRowTextList.get( i ).getText().trim();
                dateAssignedNameList.add( dateAssignedName );
            }
        } else {
            Log.message( "The Teacher has no assignment" );
        }
        return dateAssignedNameList;
    }

    /**
     * To get the Active students values
     *
     * @return
     */
    public List<Integer> getColumnActiveStudentsValues() {
        List<Integer> activeStudentsNameList = new ArrayList<>();
        int size = assignementRowTextList.size();
        if ( size > 0 ) {
            for ( int i = 2; i < size; i += 5 ) {
                String activeStudentsName = assignementRowTextList.get( i ).getText().trim();
                activeStudentsNameList.add( Integer.parseInt( activeStudentsName ) );
            }
        } else {
            Log.message( "The Teacher has no assignment" );
        }
        return activeStudentsNameList;
    }

    /**
     * To get the Paused Students values
     *
     * @return
     */
    public List<Integer> getColumnPausedStudentsValues() {
        List<Integer> pausedStudentsNameList = new ArrayList<>();
        int size = assignementRowTextList.size();
        if ( size > 0 ) {
            for ( int i = 3; i < size; i += 5 ) {
                String pausedStudentsName = assignementRowTextList.get( i ).getText().trim();
                pausedStudentsNameList.add( Integer.parseInt( pausedStudentsName ) );
            }
        } else {
            Log.message( "The Teacher has no assignment" );
        }
        return pausedStudentsNameList;
    }

    /**
     * To get the Fluency files Column values
     *
     * @return
     */
    public List<Integer> getColumnFluencyFilesValues() {
        List<Integer> fluencyFilesNameList = new ArrayList<>();
        int size = assignementRowTextList.size();
        if ( size > 0 ) {
            for ( int i = 4; i < size; i += 5 ) {
                String fluencyFilesName = assignementRowTextList.get( i ).getText().trim();
                fluencyFilesNameList.add( Integer.parseInt( fluencyFilesName ) );
            }
        } else {
            Log.message( "The Teacher has no assignment" );
        }
        return fluencyFilesNameList;
    }

    /**
     * Verify the Assignments lisitng page headers , title and URL
     */
    public void VerifyAssignmentsPageHeaders() {
        if ( driver.getCurrentUrl().equals( configProperty.getProperty( "SMAppUrl" ) + Assignments.ASSIGNMENT_PAGE_URL ) ) {
            Log.pass( "The assignment URL matches!" );
        } else {
            Log.fail( "The assignment URL is not matching actual is " + driver.getCurrentUrl() + " expected: " + configProperty.getProperty( "SMAppUrl" ) + Assignments.ASSIGNMENT_PAGE_URL );
        }
        if ( assignmentHeading.getText().trim().equals( "Assignments" ) ) {
            Log.pass( "The Assignment Header text mathces!" );
        } else {
            Log.fail( "The Assignment Header text is not mathching" );
        }
        if ( getColumnAssignmnetTitle().equals( Constants.ASSIGNMENT_TITLE ) ) {
            Log.pass( "Assignment Title column is displayed" );
        } else {
            Log.fail( "Assignment Title column is not displayed" );
        }
        if ( getColumnDateAssigned().equals( Constants.DATE_ASSIGNED ) ) {
            Log.pass( "Date Assigned column is displayed" );
        } else {
            Log.fail( "Date Assigned column is not displayed" );
        }
        if ( getColumnActiveStudents().equals( Constants.ACTIVE_STUDENTS ) ) {
            Log.pass( "Active Students column is displayed" );
        } else {
            Log.fail( "Active Students column is not displayed" );
        }
        if ( getColumnPausedStudents().equals( Constants.PAUSED_STUDENTS ) ) {
            Log.pass( "Paused Students column is displayed" );
        } else {
            Log.fail( "Paused Students column is not displayed" );
        }
        if ( getColumnFluencyFiles().equals( Constants.FLUENCY_FILES ) ) {
            Log.pass( "Fluency Files column is displayed" );
        } else {
            Log.fail( "Fluency Files column is not displayed" );
        }
    }

    /**
     * To get the zeroState text
     *
     * @return
     */
    public String getZeroStateText() {
        return zeroStateHeader.getText().trim();
    }

    /**
     * To get the zero state message text
     *
     * @return
     */
    public String getZeroStateMessage() {
        return zeroStateMessage.getText().trim();
    }

    /**
     * To get the values for the Assignents in Assignment Listing page
     *
     * @param assignmentName
     * @param ColumnName
     * @return
     */
    public String getValueForAssignment( String assignmentName, String ColumnName ) {
        if ( assignmentRows.size() > 0 ) {
            for ( WebElement eachRow : assignmentRows ) {
                String assignment = SMUtils.getChildWebElementFromParent( eachRow, assignmentNameCSS ).getText().trim();
                if ( assignment.equals( assignmentName ) ) {
                    if ( ColumnName.equals( Assignments.COLUMN_DATE_ASSIGNED ) ) {
                        return SMUtils.getChildWebElementFromParent( eachRow, dateAssignedCSS ).getText().trim();
                    } else if ( ColumnName.equals( Assignments.COLUMN_ACTIVE_STUDENTS ) ) {
                        return SMUtils.getChildWebElementFromParent( eachRow, activeStudentsCSS ).getText().trim();
                    } else if ( ColumnName.equals( Assignments.COLUMN_PAUSED_STUDENTS ) ) {
                        return SMUtils.getChildWebElementFromParent( eachRow, pausedStudentsCSS ).getText().trim();
                    } else if ( ColumnName.equals( Assignments.COLUMN_FLUENCY_FILES ) ) {
                        return SMUtils.getChildWebElementFromParent( eachRow, fluencyFilesCSS ).getText().trim();
                    } else {
                        Log.message( "Error in getting values" );
                    }
                }
            }
        } else {
            Log.message( "The students has no assignments" );
        }
        return null;
    }

    // get All Math courses
    public List<String> getMathCourses() {
        List<String> mathAssignmentsList = new ArrayList<>();
        availableAssignments.stream().forEach( element -> {
            WebElement assignmentIcon = element.findElement( By.cssSelector( "img" ) );
            if ( assignmentIcon.getAttribute( "src" ).contains( "Math" ) ) {
                String name = element.findElement( By.cssSelector( "span.text-overflow-nowrap.font-weight-bold" ) ).getText().trim();
                mathAssignmentsList.add( name );
            }
        } );
        return mathAssignmentsList;
    }

    // get all Reading courses
    public List<String> getReadingCourses() {
        List<String> mathAssignmentsList = new ArrayList<>();
        availableAssignments.stream().forEach( element -> {
            WebElement assignmentIcon = element.findElement( By.cssSelector( "img" ) );
            if ( assignmentIcon.getAttribute( "src" ).contains( "Read" ) ) {
                String name = element.findElement( By.cssSelector( "span.text-overflow-nowrap.font-weight-bold" ) ).getText().trim();
                mathAssignmentsList.add( name );
            }
        } );
        return mathAssignmentsList;
    }
    
    /**
     * Checks and returns the visibility state of Mastery Widget
     *
     * @return
     */
    public boolean isAssignmentTitleDisplayed() {
        SMUtils.waitForElement( driver, assignmentHeading, 10 );
        return assignmentHeading.isDisplayed();
    }
    
    /**
     * Return number of assignments
     *
     * @return
     */
    public int countOfAssignments() {
        SMUtils.waitForElement( driver, assignmentImagesList.get(0), 10 );
        return assignmentImagesList.size();
    }
    

}
