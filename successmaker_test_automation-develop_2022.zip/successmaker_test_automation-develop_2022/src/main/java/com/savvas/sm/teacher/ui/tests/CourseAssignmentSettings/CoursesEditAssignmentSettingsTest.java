package com.savvas.sm.teacher.ui.tests.CourseAssignmentSettings;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.EditAssignments;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesEditAssignmentSettingsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EditCourseSettingPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class CoursesEditAssignmentSettingsTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;

    @BeforeTest
    public void initTest( ITestContext context ) {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher42" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( description = "Verify Course Details page ", priority = 1, groups = { "SMK-40138", "Courses", "EditAssignmentSettings" } )
    public void verifyCourseDetailsPage() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "verifyCourseDetailsPage: Verify Course Details Page . <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            SMUtils.logDescriptionTC( "SMK-10285:Verify that clicking on courses undercourseware tab, you are redirected to the CourseDetails page" );

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

            coursePage.clickMathCourse();

            coursesEditAssignmentSettingsPage.isLoaded();
            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify edit button enable at settings panel ", priority = 2, groups = { "SMK-40138", "Courses", "EditAssignmentSettings" } )
    public void verifyEditButtonEnableAtSettingsPanel() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "verifyEditButtonEnableAtSettingsPanel: verifyEditButtonEnableAtSettingsPanel .<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            SMUtils.logDescriptionTC( "SMK-10286: Verify that on course details page, setting panel displays with the edit button enabled on the screen" );

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = new CoursesPage( driver );

            CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

            String courseName = coursesEditAssignmentSettingsPage.generateCourseName();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending 
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course 
            coursePage.clickFromCourseListingPage( courseName );

            Log.softAssertThat( coursesEditAssignmentSettingsPage.isEditButtonEnabled(), "Edit button is in enable state", "Edit button is in disable state" );
            //Signout 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify course edit setting popup displayed ", priority = 3, groups = { "SMK-40138", "Courses", "EditAssignmentSettings" } )
    public void verifyCourseEditSettinsPopUpDisplayded() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "verifyCourseEditSettinsPopUpDisplayded: Verify Course edit setting pop up displayed . <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            SMUtils.logDescriptionTC( "SMK-10287: Verify that on course edit settings screen pop up displays after clicking on the edit button enabled on the screen" );

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = new CoursesPage( driver );

            CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

            String courseName = coursesEditAssignmentSettingsPage.generateCourseName();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending 
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course 
            coursePage.clickFromCourseListingPage( courseName );

            coursesEditAssignmentSettingsPage.clickOnEditButton();

            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedEditSettingsPopUp(), "Navigated to Courses edit settings popup", "test fail" );

            coursePage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all the text boxes and sections displayed", priority = 4, groups = { "SMK-40138", "Courses", "EditAssignmentSettings" } )
    public void verifyAllSectionsDisplayed() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "verifyAllSectionsDisplayed: Verify all the text boxes and sections displayed . <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            SMUtils.logDescriptionTC( "SMK-10288: Verify all the Text boxs and sections are displyed sucessfully" );

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = new CoursesPage( driver );

            CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

            String courseName = coursesEditAssignmentSettingsPage.generateCourseName();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending 
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course 
            coursePage.clickFromCourseListingPage( courseName );

            coursesEditAssignmentSettingsPage.clickOnEditButton();

            //verify SessionLength section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, "Session Length" ), "Session length section displayed", "Not displayed Session length section" );
            //verify IdleLength section is displayed or not 
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, "Idle Time" ), "Idle Time section is displayed", "Not displayed Idle time section" );
            //verify show/limt progreass report section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.DROPDOWN, "Show / limit progress Report" ), "Show Limit Progress report is displayd", "Not diplayed Show limit  progress report" );
            //verify InitialPlacement section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );
            //verify Calculater section 
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, "Calculator" ), "Calculater section is displayed", "Calculater section is not displayed" );
            //verify Translate section 
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, "Translate" ), "Translate section is displayed", "Translate section is not displayed" );
            //verify Scratchpad section
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, "Scratchpad" ), "Scratchpad section is displayed", "Scratchpad section is not displayed" );
            //verify ShowAnswer section 
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, "Show answer" ), "ShowAnswer section is displayd", "ShowAnswer section is not displayed" );
            //verify ExitCourseButton section 
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, "Exit Course Button" ), "ExitCourseButton section is displayed", "ExitCourseButton section is not displayed" );
            //verify SpeedGames section 
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isCourseAssignmentSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, "Speed Games" ), "SpeedGames section is displayed", "SpeedGames section is not displayed" );
            //verify ManualSetCourseLevel section 
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedManuallySetCourseLevelSection( Constants.MANUALLY_SET_COURSE_LEVEL ), "ManuallySetCourseLevel section is displayed", "ManuallySetCourseLevel section is not displayed" );

            coursePage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Select language section is displayed", priority = 5, groups = { "SMK-40138", "Courses", "EditAssignmentSettings" } )

    public void verifySelectLanguageSectionDisplayed() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "verifySelectLanguageSectionDisplayed: Verify Select language section is displayed . <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            SMUtils.logDescriptionTC( "SMK-10289: Verify select languages text box is displayed with teh drop down options" );

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = new CoursesPage( driver );

            CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

            String courseName = coursesEditAssignmentSettingsPage.generateCourseName();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending 
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course 
            coursePage.clickFromCourseListingPage( courseName );

            coursesEditAssignmentSettingsPage.clickOnEditButton();

            coursesEditAssignmentSettingsPage.clickOnTranslate( Constants.TRANSLATE );

            //verify Select language drop down section is displayed or not
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedLanguagesDropDown(), "Available languages section is displayed", "Available languages section is not displayed" );

            coursePage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Save button is displayed", priority = 6, groups = { "SMK-40138", "Courses", "EditAssignmentSettings" } )
    public void verifySaveButtonDisplayed() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "verifySaveButtonDisplayed: Verify Save button is displayed . <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            SMUtils.logDescriptionTC( "SMK-10292: verify that the save button display sucessfully on edit setting screens" );

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = new CoursesPage( driver );

            CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

            String courseName = coursesEditAssignmentSettingsPage.generateCourseName();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending 
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course 
            coursePage.clickFromCourseListingPage( courseName );

            coursesEditAssignmentSettingsPage.clickOnEditButton();

            coursePage.changeStatusOfTheSharedAtDistrictLevel( Constants.OFF_CAPS );

            //verify save button is displayed 
            Log.softAssertThat( coursesEditAssignmentSettingsPage.isDisplayedSaveButton(), "Save button is displayed", "Save button is not displayed" );

            coursePage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify MaxLimit of idletime", priority = 7, groups = { "SMK-40138", "Courses", "EditAssignmentSettings" } )
    public void veirifyMaxLimitOfIdelTime() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "veirifyMaxLimitOfIdelTime: Verify MaxLimit of idletime . <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            SMUtils.logDescriptionTC( "SMK-10295: Verify the boundary value of idle time" );

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = new CoursesPage( driver );

            CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

            String courseName = coursesEditAssignmentSettingsPage.generateCourseName();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending 
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course 
            coursePage.clickFromCourseListingPage( courseName );

            coursesEditAssignmentSettingsPage.clickOnEditButton();

            Log.softAssertThat( coursesEditAssignmentSettingsPage.verifyMaxLimitOfIdleTime( "Idle Time" ), "Max idel limit time is 6 min", "test fail" );

            coursePage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Max Show limit is 10 per session", priority = 8, groups = { "SMK-40138", "Courses", "EditAssignmentSettings" } )
    public void verifyMaxShowLimit() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "verifyMaxShowLimit: Verify Max Show limit is 10 per session. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            SMUtils.logDescriptionTC( "SMK-10296: Verify the boundary value for show/limit progress report" );

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = new CoursesPage( driver );

            CoursesEditAssignmentSettingsPage coursesEditAssignmentSettingsPage = new CoursesEditAssignmentSettingsPage( driver );

            String courseName = coursesEditAssignmentSettingsPage.generateCourseName();

            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.STANDARDS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course
            coursePage.clickFromCourseListingPage( courseName );

            coursesEditAssignmentSettingsPage.clickOnEditButton();

            Log.softAssertThat( coursesEditAssignmentSettingsPage.verifyMaxLimitOfShowLimitProgress( "Show / limit progress Report" ), "Max show/limit is 10 per sission", "test fail" );

            coursePage.clickSaveBtn();

            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify that toggle button display sucessfully on edit setting screens", priority = 9, groups = { "SMK-40138", "assignments", "assignmentDetailsPage" } )
    public void verifyToggleButtonDisplayOnEditSettingScreen() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "verifyToggleButtonDisplayOnEditSettingScreen:SMK-40138- verify that toggle button display sucessfully on edit setting screens" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = new CoursesPage( driver );

            String courseName = "Math_XM" + System.nanoTime();
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending 
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course 
            coursePage.clickOnCourseNameFromList( courseName );

            // Click on Edit button on CoursesEditAssignmentSettingsPage
            CoursesEditAssignmentSettingsPage courseeditassignmentsettingpage = new CoursesEditAssignmentSettingsPage( driver );
            courseeditassignmentsettingpage.clickOnEditButton();

            // Verify All Toggle buttons on EditCourseSettingPage
            EditCourseSettingPage editcoursesettingpage = new EditCourseSettingPage( driver );

            Log.softAssertThat( editcoursesettingpage.isDisplayedFirstColumnToggleButtons( Constants.INITIAL_PLACEMENT ), "Toggle button for InitialPlacement displayed", "Toggle button for InitialPlacement not displayed" );
            Log.softAssertThat( editcoursesettingpage.isDisplayedFirstColumnToggleButtons( Constants.CALCULATOR ), "Toggle button for Calculator displayed", "Toggle button for Calculator not displayed" );
            Log.softAssertThat( editcoursesettingpage.isDisplayedFirstColumnToggleButtons( Constants.TRANSLATE ), "Toggle button for Translate displayed", "Toggle button for Translate not displayed" );
            Log.softAssertThat( editcoursesettingpage.isDisplayedFirstColumnToggleButtons( Constants.DISPLAY_LO_INFORMATION ), "Toggle button for LO Information displayed", "Toggle button for LO Information not displayed" );
            Log.softAssertThat( editcoursesettingpage.isDisplayedSecondColumnToggleButtons( Constants.SCRATCHPAD ), "Toggle button for Scratchpad displayed", "Toggle button for Scratchpad not displayed" );
            Log.softAssertThat( editcoursesettingpage.isDisplayedSecondColumnToggleButtons( Constants.SHOW_ANSWER ), "Toggle button for Show-Answer displayed", "Toggle button for Show-Answer not displayed" );
            Log.softAssertThat( editcoursesettingpage.isDisplayedSecondColumnToggleButtons( Constants.EXIT_COURSE_BUTTON ), "Toggle button for ExitCourse displayed", "Toggle button for ExitCourse not displayed" );
            Log.softAssertThat( editcoursesettingpage.isDisplayedSecondColumnToggleButtons( Constants.SHARE_AT_DISTRICT_LEVEL ), "Toggle button for SpeedGames displayed", "Toggle button for SpeedGames not displayed" );
            Log.softAssertThat( editcoursesettingpage.isDisplayedSecondColumnToggleButtons( Constants.SPEED_GAMES ), "Toggle button for SpeedGames displayed", "Toggle button for SpeedGames not displayed" );
            Log.softAssertThat( editcoursesettingpage.isDisplayedSecondColumnToggleButtons( Constants.MANUALLY_SET_COURSE_LEVEL ), "Toggle button for ManuallySetCourseLevel displayed", "Toggle button for ManuallySetCourseLevel not displayed" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "verify that cancel button display sucessfully on edit setting screens", priority = 10, groups = { "SMK-40138", "assignments", "assignmentDetailsPage" } )
    public void verifyCancelButtonDisplayOnEditSettingScreen() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "verifyCancelButtonDisplayOnEditSettingScreen:SMK-40138- verify that cancel button display sucessfully on edit setting screens" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            CoursesPage coursePage = new CoursesPage( driver );

            String courseName = "Math_XM" + System.nanoTime();
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending 
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course 
            coursePage.clickOnCourseNameFromList( courseName );

            // Click on Edit button on CoursesEditAssignmentSettingsPage
            CoursesEditAssignmentSettingsPage courseeditassignmentsettingpage = new CoursesEditAssignmentSettingsPage( driver );
            courseeditassignmentsettingpage.clickOnEditButton();

            // check Cancle Button display or not
            EditCourseSettingPage editcoursesettingpage = new EditCourseSettingPage( driver );

            //verify Manually Set Course Level Toggle Button displayed or not
            Log.assertThat( editcoursesettingpage.isDisplayedCancelButton(), "Cancel Button is displayed successfully", " Cancel Button is not displayed" );
            Log.assertThat( editcoursesettingpage.isCancelButtonEnabled(), "Cancel Button is in enabled state", " Cancel Button is not in enabled state" );
            editcoursesettingpage.clickCancelBtn();

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the boundary value of session length", priority = 11, groups = { "SMK-40138", "assignments", "assignmentDetailsPage" } )
    public void verifyBoundaryValueOfSessionLength() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "verifyBoundaryValueOfSessionLength:SMK-40138- Verify the boundary value of session length" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            CoursesPage coursePage = new CoursesPage( driver );

            String courseName = "Math_XM" + System.nanoTime();
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending 
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course 
            coursePage.clickOnCourseNameFromList( courseName );

            // Click on Edit button on CoursesEditAssignmentSettingsPage
            CoursesEditAssignmentSettingsPage courseeditassignmentsettingpage = new CoursesEditAssignmentSettingsPage( driver );
            courseeditassignmentsettingpage.clickOnEditButton();

            EditCourseSettingPage editcoursesettingpage = new EditCourseSettingPage( driver );

            // Verify the boundary value of session length            

            Log.softAssertThat( editcoursesettingpage.SessionLengthBoundaryValue( Constants.SESSION_LENGHT, EditAssignments.SESSION_LENGTH_LAST_ELEMENT ), "Boundry value of session length verified", "Boundry value of session length is incorrect" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify that the user is able to select multiple toggle as enabled at a time and can save it", priority = 12, groups = { "SMK-40138", "assignments", "assignmentDetailsPage" } )
    public void verifyUserAbleToSelectMultipleToggleButtons() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo(
                "verifyUserAbleToSelectMultipleToggleButtons-40138- verify that the user is able to select multiple toggle as enabled at a time and can save it" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            CoursesPage coursePage = new CoursesPage( driver );

            String courseName = "Math_XM" + System.nanoTime();
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            coursePage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.ALL_COURSES );

            //Sort by date descending 
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course 
            coursePage.clickOnCourseNameFromList( courseName );

            // Click on Edit button on CoursesEditAssignmentSettingsPage
            CoursesEditAssignmentSettingsPage courseeditassignmentsettingpage = new CoursesEditAssignmentSettingsPage( driver );
            courseeditassignmentsettingpage.clickOnEditButton();

            EditCourseSettingPage editcoursesettingpage = new EditCourseSettingPage( driver );

            // verify User Can Select Multiple Toggle Buttons           

            Log.softAssertThat( editcoursesettingpage.verifyFirstColumnToggleButtonSelected( Constants.INITIAL_PLACEMENT ), "Initial Placement Toggle Button is selected", "Initial Placement Toggle Button is Not Selected" );

            Log.softAssertThat( editcoursesettingpage.verifyFirstColumnToggleButtonSelected( Constants.DISPLAY_LO_INFORMATION ), "Display LO Information Toggle Button is selected", "Display LO Information Toggle Button is Not Selected" );

            Log.softAssertThat( editcoursesettingpage.verifyFirstColumnToggleButtonSelected( Constants.TRANSLATE ), "Translate Toggle Button is selected", "Translate Toggle Button is Not Selected" );

            Log.softAssertThat( editcoursesettingpage.verifySecondColumnToggleButtonSelected( Constants.SCRATCHPAD ), "Scratchpad Toggle Button is selected", "Scratchpad Toggle Button is Not Selected" );

            Log.softAssertThat( editcoursesettingpage.verifySecondColumnToggleButtonSelected( Constants.SHOW_ANSWER ), "Show Answer Toggle Button is selected", "Show Answer Toggle Button is Not Selected" );

            Log.softAssertThat( editcoursesettingpage.verifySecondColumnToggleButtonSelected( Constants.EXIT_COURSE_BUTTON ), "Exit Course Toggle Button is selected", "Exit Course Toggle Button is Not Selected" );

            Log.softAssertThat( editcoursesettingpage.verifySecondColumnToggleButtonSelected( Constants.SPEED_GAMES ), "Speed Games Toggle Button is selected", "Speed Games Toggle Button is Not Selected" );

            Log.softAssertThat( editcoursesettingpage.verifySecondColumnToggleButtonSelected( Constants.MANUALLY_SET_COURSE_LEVEL ), "Manually Set Course Level Toggle Button is selected", "Manually Set Course Level Toggle Button is Not Selected" );

            editcoursesettingpage.clickOnSaveButton();

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
