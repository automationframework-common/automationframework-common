package com.savvas.sm.api.tests.smnew.groups;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.CourseExecution;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.GetGroupMostAssessedSkill;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SQLConstants.Course;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * This class created to test the Most assessed skill for group
 * 
 * @author ajith.mohan
 *
 */
public class GroupMostAssessedSkill extends GroupAPI {

	private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	private static List<String> studentRumbaIds = new ArrayList<>();
	private String smUrl;
	private String browser;
	private String teacherDetails = null;
	private String teacherUsername = null;
	private String coTeacherDetails = null;
	private String orgId = null;
	private String teacherId = null;
	private String standardCourseName;
	private String standardCourseId;
	private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
	private static HashMap<String, String> assignmentDetails = new HashMap<>();
	private static HashMap<String, String> contentBase = new HashMap<>();
	private static HashMap<String, String> contentBaseName = new HashMap<>();

	private List<String> courseIDs = new ArrayList<>();
	private List<String> schools = new ArrayList<>();
	private HashMap<String, String> response = new HashMap<>();
	private HashMap<String, String> groupDetails = new HashMap<>();
	private HashMap<String, String> userDetails = new HashMap<>();
	private String exception = null;
	private boolean status = false;
	private String message = null;
	CourseAPI coursesMethod = new CourseAPI();
	String student1Id;
    String student2Id;
    String student3Id;
    String student4Id;
    private String student1Detail = null;
    private String student2Detail = null;
    private String student3Detail = null;
    private String student4Detail = null;
    private static List<String> studentUserName = new ArrayList<>();

	@BeforeClass(alwaysRun = true)
	public void BeforeTest() throws Exception {
		smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
		browser = configProperty.getProperty( "BrowserPlatformToRun" );
		teacherDetails = RBSDataSetup.getMyTeacher( school );
		teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
		coTeacherDetails = RBSDataSetup.getMyTeacher( school );
		orgId = RBSDataSetup.organizationIDs.get( school );
		teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
		standardCourseName = "R-StandardCourse" + System.nanoTime();

		String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
		student1Detail=RBSDataSetup.getMyStudent( school, teacherUsername );
        student2Detail=RBSDataSetup.getMyStudent( school, teacherUsername );
        student3Detail=RBSDataSetup.getMyStudent( school, teacherUsername );
        student4Detail=RBSDataSetup.getMyStudent( school, teacherUsername );
        student1Id= SMUtils.getKeyValueFromResponse( student1Detail, Constants.USERID_HEADER );
        student2Id= SMUtils.getKeyValueFromResponse( student2Detail, Constants.USERID_HEADER );
        student3Id= SMUtils.getKeyValueFromResponse( student3Detail, Constants.USERID_HEADER );
        student4Id= SMUtils.getKeyValueFromResponse( student4Detail, Constants.USERID_HEADER );
		studentRumbaIds.add( student1Id );
		studentRumbaIds.add( student2Id );
		studentRumbaIds.add( student3Id );
		studentRumbaIds.add( student4Id );
	    studentUserName.add( SMUtils.getKeyValueFromResponse( student1Detail, RBSDataSetupConstants.USERNAME ) );
	    studentUserName.add( SMUtils.getKeyValueFromResponse( student2Detail, RBSDataSetupConstants.USERNAME ) );
	    studentUserName.add( SMUtils.getKeyValueFromResponse( student3Detail, RBSDataSetupConstants.USERNAME ) );
	    studentUserName.add( SMUtils.getKeyValueFromResponse( student4Detail, RBSDataSetupConstants.USERNAME ) );

		groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
		groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
		groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );

		assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
		assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
		assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

		Log.message( "Created group " + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

		createReadingAllStandardCourse(teacherUsername, standardCourseName);
		standardCourseId = new SqlHelperCourses().getContenBaseIdByName(standardCourseName);
		Log.message("StandardCourseID is --> " +standardCourseId );
		Log.message("StandardCourseName is --> " +standardCourseName );
		
		contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
		contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
		contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
		contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
		contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

		contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
		contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
		contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
		contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
		contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

		contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
		contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
		contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
				coursesMethod.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
		contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE,
				coursesMethod.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.STANDARD, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );
		contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
				coursesMethod.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

		contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
		contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING );
		contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE,
				coursesMethod.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
		contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, coursesMethod.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.STANDARD,
				contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );
		contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, coursesMethod.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), orgId.toString(), DataSetupConstants.SETTINGS,
				contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

		courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );
		courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

		Log.message( "Assigning assignment..." );
		Log.message( "Assignment Details - " + new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs ) );

		IntStream.rangeClosed( 0, studentRumbaIds.size() - 3 ).forEach( studentNumber -> {
		    
			String username = studentUserName.get( studentNumber );
			Log.message("Student taking asssignemnt is ==> " + username);
			try {
//				executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
//				executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ), true );
//				executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ), true );
//				executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true );
//				executeCourse( username, "SM Focus Math: Grade 1", true );
			    new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true, "100", "1", "10" );
			    new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ), true, "100", "1", "10" );
			    new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ), true, "100", "1", "10" );
			    new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true, "100", "1", "10" );
			    new CourseExecution().executeCourse( username, "SM Focus Math: Grade 1", true, "100", "1", "10" );
			    new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false, "100", "2", "20" );
			    new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ), false, "100", "2", "20" );
			    new CourseExecution().executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ), false, "100", "2", "20" );
			    new CourseExecution().executeCourse( username,contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false, "100", "2", "20" );
			    new CourseExecution().executeCourse( username, "SM Focus Reading: Grade 1", false, "100", "2", "20" );
//				executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
//				executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ), false );
//				executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE ), false );
//				executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false );
//				executeCourse( username, "SM Focus Reading: Grade 1", false );
			} catch ( IOException e ) {
				e.printStackTrace();
			}
		} );
	}

	@Test ( priority = 1, dataProvider = "groupMostAssessedSkillPositive", groups = { "smoke_test_case", "Smoke ", "Most assessed skill group", "SMK-51987", "Group", "Most assessed skill", "P1", "API" } )
	public void tcPositiveTestcases( String description, String scenario, String statusCode ) throws Exception {

		String groupName = "MostSkillAssessedGroup_" + System.nanoTime();
		Log.testCaseInfo( description );

		switch ( scenario ) {
		case "HAPPY_PATH":
			SMUtils.logDescriptionTC( "Verify the 'percentageMastered' is showing percentage values(0-100)" );
			SMUtils.logDescriptionTC("Verify Status code is 200 if we give contentBaseId of default Math Assignment");
			SMUtils.logDescriptionTC( "Verify the response body is displaying catalogNum" );
			SMUtils.logDescriptionTC( "Verify the API Get Groups Skills Assessment Graph will get the 200 response code and message  for all the variable is correct" );
			SMUtils.logDescriptionTC( "Verify  API Get Groups Skills Assessment Graph when the student assessed the skill in last session." );
			SMUtils.logDescriptionTC( "Verify  API Get Groups Skills Assessment Graph when the student assessed the skill in last session." );
			HashMap<String, String> groupDetail = new HashMap<>();
			groupDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetail.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetail.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetail.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			groupDetail.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetail, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetail.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			groupDetail.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

			HashMap<String, String> response = new HashMap<>();
			response = getMostSkillAssessedForGroup( smUrl, groupDetail );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			verifyResponse( response.get( Constants.REPORT_BODY ), true );

			break;

		case "DEFAULT_MATH_ASSIGNMENT":

			HashMap<String, String> groupDetails1 = new HashMap<>();
			groupDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails1.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			groupDetails1.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails1, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails1.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			groupDetails1.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

			HashMap<String, String> response1 = new HashMap<>();
			response1 = getMostSkillAssessedForGroup( smUrl, groupDetails1 );
			Log.message( "Group Skill details - " + response1 );
			Log.assertThat( response1.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response1.get( Constants.STATUS_CODE ) );
			verifyResponse( response1.get( Constants.REPORT_BODY ), true );
			break;

		case "MATH_CUSTOM_BY_STANDARD":
			HashMap<String, String> groupDetails2 = new HashMap<>();
			groupDetails2.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails2.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			groupDetails2.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails2, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails2.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			groupDetails2.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );

			HashMap<String, String> response2 = new HashMap<>();
			response2 = getMostSkillAssessedForGroup( smUrl, groupDetails2 );
			Log.message( "Group Skill details - " + response2 );
			Log.assertThat( response2.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response2.get( Constants.STATUS_CODE ) );
			verifyResponse( response2.get( Constants.REPORT_BODY ), true );
			break;

		case "MATH_CUSTOM_BY_SKILL":
			SMUtils.logDescriptionTC( " Verify  API Get Groups Skills Assessment Graph when the students partially completes the assignment(like 1 student assessed 4 skills and another student not assessed any skills)." );
			SMUtils.logDescriptionTC("erify  API Get Groups Skills Assessment Graph when the assignment has only one skill mapped.");
			
			HashMap<String, String> mathSkillGroupDetails = new HashMap<>();
			HashMap<String, String> response3 = new HashMap<>();
			
			mathSkillGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			mathSkillGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			mathSkillGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			mathSkillGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			mathSkillGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, mathSkillGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			mathSkillGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			mathSkillGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );

			response3 = getMostSkillAssessedForGroup( smUrl, mathSkillGroupDetails );
			Log.message( "Group Skill details - " + response3 );
			Log.assertThat( response3.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response3.get( Constants.STATUS_CODE ) );
			verifyResponse( response3.get( Constants.REPORT_BODY ), true );
			Log.testCaseResult();
			break;

		case "MATH_CUSTOM_BY_SETTINGS":
			
			HashMap<String, String> mathSetGroupDetails = new HashMap<>();
			HashMap<String, String> response4 = new HashMap<>();
			
			SMUtils.logDescriptionTC("Verify  API Get Groups Skills Assessment Graph the assignment has mapped with multiple skills.");
			mathSetGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			mathSetGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			mathSetGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			mathSetGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			mathSetGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, mathSetGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			mathSetGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			mathSetGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

			response4 = getMostSkillAssessedForGroup( smUrl, mathSetGroupDetails );
			Log.message( "Group Skill details - " + response4 );
			Log.assertThat( response4.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response4.get( Constants.STATUS_CODE ) );
			verifyResponse( response4.get( Constants.REPORT_BODY ), true );
			Log.testCaseResult();
			break;

		case "DEFAULT_READING_ASSIGNMENT":

			HashMap<String, String> readGroupDetails = new HashMap<>();
			HashMap<String, String> readResponse = new HashMap<>();
			
			readGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			readGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			readGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			readGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			readGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, readGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			readGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.READING );
			readGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.READING_COURSE ) );

			readResponse = getMostSkillAssessedForGroup( smUrl, readGroupDetails );
			Log.message( "Group Skill details - " + readResponse );
			Log.assertThat( readResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + readResponse.get( Constants.STATUS_CODE ) );
			verifyResponse( readResponse.get( Constants.REPORT_BODY ), false );
			break;

		case "READING_CUSTOM_BY_STANDARD":
			
			List<String> studentRumbaIdReadingStandard = new ArrayList<>();
			String standardGroupName = "Reading Custom By Standard Group";
			String readingStandardStudent = "ReadingStandardStudent" + System.nanoTime();
			
			//Student User Creation
			HashMap<String, String> userDetails1 = new HashMap<>();
			userDetails1.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
			userDetails1.put( RBSDataSetupConstants.USERNAME, readingStandardStudent );
			userDetails1.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
			userDetails1.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
			String readingStandardStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails1 ), RBSDataSetupConstants.USERID );
			studentRumbaIdReadingStandard.add( readingStandardStudentID );
			
			HashMap<String, String> readStandardGroupDetails = new HashMap<>();
			HashMap<String, String> readResponse1 = new HashMap<>();

			//Updating Student Details
			HashMap<String, String> readingStudentInfo = new HashMap<>();
			readingStudentInfo = generateRequestValues( new RBSUtils().getUser( readingStandardStudentID ), readingStudentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			readingStudentInfo = SMUtils.updateRequestBodyValues( readingStudentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			readingStudentInfo = SMUtils.updateRequestBodyValues( readingStudentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			readingStudentInfo = SMUtils.updateRequestBodyValues( readingStudentInfo, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), readingStudentInfo );
			new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( school ), RBSDataSetupConstants.DEFAULT_PASSWORD, readingStandardStudentID );

			//R-Standard Group Details
			HashMap<String, String> createStandardGroupDetails = new HashMap<>();
			createStandardGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			createStandardGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			createStandardGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			createStandardGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, standardGroupName );
			
			//Creating Group
			String standardGroupID = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, createStandardGroupDetails, studentRumbaIdReadingStandard ).get( Constants.REPORT_BODY ), "data,groupId" );
			Log.message("The Group ID is --->  " + standardGroupID);
			
			//Assigning Assignment
			HashMap<String, String> assignmentDetail = new HashMap<>();
			assignmentDetail.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			assignmentDetail.put( AssignmentAPIConstants.COURSE_ID, standardCourseId );
			
			new AssignmentAPI().assignAssignment(smUrl, assignmentDetail, Arrays.asList(standardGroupID),  AssignmentAPIConstants.GROUPS_TYPE);
			
			//Executing Course
//			executeCourse( readingStandardStudent, standardCourseName, false );
	        new CourseExecution().executeCourse( readingStandardStudent, standardCourseName, false, "100", "2", "20" );
			
			readStandardGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			readStandardGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			readStandardGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			readStandardGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, standardGroupName );
			readStandardGroupDetails.put( CreateGroupAPIConstants.GROUP_ID,standardGroupID );
			readStandardGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.READING );
			readStandardGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, standardCourseId );
			

			readResponse1 = getMostSkillAssessedForGroup( smUrl, readStandardGroupDetails );
			Log.message( "Group Skill details - " + readResponse1 );
			Log.assertThat( readResponse1.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + readResponse1.get( Constants.STATUS_CODE ) );
			verifyResponse( readResponse1.get( Constants.REPORT_BODY ), false );
			break;
			

			
		case "READING_CUSTOM_BY_SKILL":

			
			HashMap<String, String> readSkillGroupDetails = new HashMap<>();
			HashMap<String, String> readResponse2 = new HashMap<>();
			readSkillGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			readSkillGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			readSkillGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			readSkillGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			readSkillGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, readSkillGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			readSkillGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.READING );
			readSkillGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );

			readResponse2 = getMostSkillAssessedForGroup( smUrl, readSkillGroupDetails );
			Log.message( "Group Skill details - " + readResponse2 );
			Log.assertThat( readResponse2.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + readResponse2.get( Constants.STATUS_CODE ) );
			verifyResponse( readResponse2.get( Constants.REPORT_BODY ), false );
			break;

		case "READING_CUSTOM_BY_SETTINGS":

			HashMap<String, String> readSettingsGroupDetails = new HashMap<>();
			HashMap<String, String> readResponse3 = new HashMap<>();
			
			readSettingsGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			readSettingsGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			readSettingsGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			readSettingsGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			readSettingsGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, readSettingsGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			readSettingsGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.READING );
			readSettingsGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

			readResponse3 = getMostSkillAssessedForGroup( smUrl, readSettingsGroupDetails );
			Log.message( "Group Skill details - " + readResponse3 );
			Log.assertThat( readResponse3.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + readResponse3.get( Constants.STATUS_CODE ) );
			verifyResponse( readResponse3.get( Constants.REPORT_BODY ), false );
			break;

		case "FOCUS_MATH":
			HashMap<String, String> focusGroupDetails = new HashMap<>();
			HashMap<String, String> focusResponse = new HashMap<>();
			focusGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			focusGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			focusGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			focusGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			focusGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, focusGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			focusGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			focusGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) );

			focusResponse = getMostSkillAssessedForGroup( smUrl, focusGroupDetails );
			Log.message( "Group Skill details - " + focusResponse );
			Log.assertThat( focusResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + focusResponse.get( Constants.STATUS_CODE ) );
			verifyResponse( focusResponse.get( Constants.REPORT_BODY ), true );
			break;

		case "FOCUS_READING":

			HashMap<String, String> focusGroupDetails1 = new HashMap<>();
			HashMap<String, String> focusResponse1 = new HashMap<>();
			focusGroupDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			focusGroupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			focusGroupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			focusGroupDetails1.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			focusGroupDetails1.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, focusGroupDetails1, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			focusGroupDetails1.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.READING );
			focusGroupDetails1.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) );

			focusResponse1 = getMostSkillAssessedForGroup( smUrl, focusGroupDetails1 );
			Log.message( "Group Skill details - " + focusResponse1 );
			Log.assertThat( focusResponse1.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + focusResponse1.get( Constants.STATUS_CODE ) );
			verifyResponse( focusResponse1.get( Constants.REPORT_BODY ), false );
			break;

		case "STUDENT_REMOVED_FROM_GROUP":

			HashMap<String, String> removedGroupDetails = new HashMap<>();
			HashMap<String, String> removedResponse = new HashMap<>();
			studentRumbaIds.clear();
			studentRumbaIds.add( student1Id );
			studentRumbaIds.add( student2Id);

			removedGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			removedGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			removedGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			removedGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			removedGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, removedGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			removedGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			removedGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );

			removedResponse = getMostSkillAssessedForGroup( smUrl, removedGroupDetails );
			Log.message( "Group Skill details  before remove student- " + removedResponse );
			Log.assertThat( removedResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + removedResponse.get( Constants.STATUS_CODE ) );
			verifyResponse( removedResponse.get( Constants.REPORT_BODY ), true );

			Log.message( "Removing student from Group." );

			removeStudentFromGroup( smUrl, studentRumbaIds.get( 0 ), removedGroupDetails.get( CreateGroupAPIConstants.GROUP_ID ), SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ), RBSDataSetup.organizationIDs.get( school ),
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

			removedResponse = getMostSkillAssessedForGroup( smUrl, removedGroupDetails );
			Log.message( "Group Skill details after removing student - " + removedResponse );
			Log.assertThat( removedResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + removedResponse.get( Constants.STATUS_CODE ) );
			Log.message( "Group Skill details  before remove student- " + removedResponse );
			Log.assertThat( removedResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + removedResponse.get( Constants.STATUS_CODE ) );
			verifyResponse( removedResponse.get( Constants.REPORT_BODY ), true );

			break;

		case "PAUSED_ASSIGNMENT":
			
			HashMap<String, String> pausedGroupDetails = new HashMap<>();
			HashMap<String, String> pausedResponse = new HashMap<>();
			
			groupName = "Paused Assignment Group";
			String assignPausedStudent = "AssignPausedStudent" + System.nanoTime();
			studentRumbaIds.clear();
			studentRumbaIds.add( student1Id );

			HashMap<String, String> userDetailsPaused = new HashMap<>();
			userDetailsPaused.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
			userDetailsPaused.put( RBSDataSetupConstants.USERNAME, assignPausedStudent );
			userDetailsPaused.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
			userDetailsPaused.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
			String assignPausedStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetailsPaused ), RBSDataSetupConstants.USERID );
			studentRumbaIds.add( assignPausedStudentID );

			HashMap<String, String> pausedStudentInfo = new HashMap<>();
			pausedStudentInfo = generateRequestValues( new RBSUtils().getUser( assignPausedStudentID ), pausedStudentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			pausedStudentInfo = SMUtils.updateRequestBodyValues( pausedStudentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			pausedStudentInfo = SMUtils.updateRequestBodyValues( pausedStudentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			pausedStudentInfo = SMUtils.updateRequestBodyValues( pausedStudentInfo, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), pausedStudentInfo );
			new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( school ), RBSDataSetupConstants.DEFAULT_PASSWORD, assignPausedStudentID );

			pausedGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			pausedGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			pausedGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			pausedGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			pausedGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, pausedGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			pausedGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.READING );
			pausedGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );

			HashMap<String, String> assignmentDetails1 = new HashMap<>();
			assignmentDetails1.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails1.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			assignmentDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

			String assignmentResponseDetails = SMUtils.getKeyValueFromResponse( new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails1,
					Arrays.asList( assignPausedStudentID ),Arrays.asList( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) )  ).get(Constants.REPORT_BODY), "data,assignmentId");

			Log.message("assignmentAssignedresponseDetails: " +  assignmentResponseDetails);
			String assignmentUserIDs = new SqlHelperAssignment().getAssignmentUserId(assignmentResponseDetails);
			Log.message("Assignment User ID: " + assignmentUserIDs );
			
//			executeCourse( assignPausedStudent, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ), false );
	        new CourseExecution().executeCourse( assignPausedStudent, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ), false , "100", "2", "20" );
			assignmentDetails1.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails1.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			assignmentDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			assignmentDetails1.put(  AssignmentAPIConstants.ASSIGNMENT_USER_ID, assignmentUserIDs);
			new AssignmentAPI().changeAssignmentStatus(smUrl, assignmentDetails1,  AssignmentAPIConstants.STATUS_INACTIVE, CourseAPIConstants.NULL);

			pausedGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

			pausedResponse = getMostSkillAssessedForGroup( smUrl, pausedGroupDetails );
			Log.message( "Group Skill details - " + pausedResponse );
			Log.assertThat( pausedResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + pausedResponse.get( Constants.STATUS_CODE ) );
			verifyResponse( pausedResponse.get( Constants.REPORT_BODY ), false );
			break;


		case "SHARED_STUDENT_GROUP":

			HashMap<String, String> sharedGroupDetails = new HashMap<>();
			HashMap<String, String> sharedResponse = new HashMap<>();
			
			String sharedTeacher = "SharedTeacher" + System.nanoTime();

			HashMap<String, String> userDetailsSharedStudent = new HashMap<>();
			userDetailsSharedStudent.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
			userDetailsSharedStudent.put( RBSDataSetupConstants.USERNAME, sharedTeacher );
			userDetailsSharedStudent.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
			userDetailsSharedStudent.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );

			String sharedTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetailsSharedStudent ), RBSDataSetupConstants.USERID );
			new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( school ), RBSDataSetupConstants.DEFAULT_PASSWORD, sharedTeacherID );

			groupName = "SharedStudentGroup" + System.nanoTime();
			sharedGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( sharedTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			sharedGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, sharedTeacherID );
			sharedGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			sharedGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			new GroupAPI().createGroup( smUrl, sharedGroupDetails, studentRumbaIds );

			sharedGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( sharedTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			sharedGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, sharedTeacherID );
			sharedGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			sharedGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, sharedGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			sharedGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			sharedGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

			sharedResponse = getMostSkillAssessedForGroup( smUrl, sharedGroupDetails );
			Log.message( "Group Skill details - " + sharedResponse );
			Log.assertThat( sharedResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + sharedResponse.get( Constants.STATUS_CODE ) );
			verifyResponse( sharedResponse.get( Constants.REPORT_BODY ), true );
			break;

		case "MULTI_TEACHER_GROUP":
			groupName = "Multi teacher Group";
			

			HashMap<String, String> multiGroupDetails = new HashMap<>();
			HashMap<String, String> multiResponse = new HashMap<>();

			List<String> teacherIds = new ArrayList<>();

			teacherIds.add( SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			teacherIds.add( SMUtils.getKeyValueFromResponse( coTeacherDetails, "userId" ) );

			multiGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			multiGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			multiGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			multiGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );

			multiGroupDetails.put( RBSDataSetupConstants.SECTION_NAME, groupName );
			multiGroupDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( school ) );

			new RBSUtils().createClassWithMultipleTeacher( multiGroupDetails, teacherIds, studentRumbaIds );

			multiGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			multiGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			multiGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			multiGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			multiGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, multiGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			multiGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			multiGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

			multiResponse = getMostSkillAssessedForGroup( smUrl, multiGroupDetails );
			Log.message( "Group Skill details for teacher 1 - " + multiResponse );
			Log.assertThat( multiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + multiResponse.get( Constants.STATUS_CODE ) );
			verifyResponse( multiResponse.get( Constants.REPORT_BODY ), true );

			multiGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( coTeacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			multiGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherIds.get( 1 ) );
			multiGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			multiGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, multiGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			multiGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			multiGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

			Log.message( "Group Skill details for teacher 2 - " + multiResponse );

			break;

		case "MULTI_SCHOOL_STUDENT":
			
			HashMap<String, String> multiGroupDetails1 = new HashMap<>();
			HashMap<String, String> multiResponse1 = new HashMap<>();
			groupName = "Multi School Student Group";

			String multiSchoolStudent = "MultiSchStudent" + System.nanoTime();
			studentRumbaIds.clear();
			studentRumbaIds.add( student1Id );

			HashMap<String, String> userDetailsMultiSchS = new HashMap<>();
			userDetailsMultiSchS.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
			userDetailsMultiSchS.put( RBSDataSetupConstants.USERNAME, multiSchoolStudent );
			userDetailsMultiSchS.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

			schools.add( RBSDataSetup.organizationIDs.get( school ) );
			schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
			String finalSchool = "";
			for ( String school : schools ) {
				finalSchool += school.concat( "\",\"" );
			}
			finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
			userDetailsMultiSchS.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
			String multiSchoolStudentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetailsMultiSchS ), RBSDataSetupConstants.USERID );
			studentRumbaIds.add( multiSchoolStudentID );

			HashMap<String, String> studentInfo = new HashMap<>();
			studentInfo = generateRequestValues( new RBSUtils().getUser( multiSchoolStudentID ), studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
			new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( school ), RBSDataSetupConstants.DEFAULT_PASSWORD, multiSchoolStudentID );

			multiGroupDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			multiGroupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			multiGroupDetails1.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			multiGroupDetails1.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			multiGroupDetails1.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, multiGroupDetails1, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			multiGroupDetails1.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			multiGroupDetails1.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );

			HashMap<String, String> assignmentDetails2 = new HashMap<>();
			assignmentDetails2.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails2.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			assignmentDetails2.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

			new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails2, Arrays.asList( multiSchoolStudentID ), Arrays.asList( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );

			executeCourse( multiSchoolStudent, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ), true );

			multiGroupDetails1.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

			multiResponse1 = getMostSkillAssessedForGroup( smUrl, multiGroupDetails1 );
			Log.message( "Group Skill details - " + multiResponse1 );
			Log.assertThat( multiResponse1.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + multiResponse1.get( Constants.STATUS_CODE ) );
			verifyResponse( multiResponse1.get( Constants.REPORT_BODY ), true );
			break;

		case "MULTI_SCHOOL_TEACHER":

			HashMap<String, String> multiGroupDetails2 = new HashMap<>();
			HashMap<String, String> multiResponse2 = new HashMap<>();
			HashMap<String, String> multiUserDetails = new HashMap<>();
			
			String multiSchoolTeacher = "MultiSchTeacher" + System.nanoTime();
			String studentUserName = "StudentuserName" + System.nanoTime();
			multiUserDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
			multiUserDetails.put( RBSDataSetupConstants.USERNAME, multiSchoolTeacher );
			multiUserDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );

			schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
			schools.add( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) );
			String listString = "";
			for ( String school : schools ) {
				listString += school.concat( "\",\"" );
			}
			listString = listString.substring( 0, listString.length() - 3 );
			multiUserDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, listString );
			String multipleSchoolTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( multiUserDetails ), RBSDataSetupConstants.USERID );
			new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ), RBSDataSetupConstants.DEFAULT_PASSWORD, multipleSchoolTeacherID );

			multiUserDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
			multiUserDetails.put( RBSDataSetupConstants.USERNAME, studentUserName );
			multiUserDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
			multiUserDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
			String studentId = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( multiUserDetails ), RBSDataSetupConstants.USERID );
			studentRumbaIds.add( studentId );

			HashMap<String, String> multiSchTeacherStudent = new HashMap<>();
			multiSchTeacherStudent = generateRequestValues( new RBSUtils().getUser( studentId ), multiSchTeacherStudent, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			multiSchTeacherStudent = SMUtils.updateRequestBodyValues( multiSchTeacherStudent, UserConstants.SCHOOLID, RBSDataSetup.organizationIDs.get( school ) );
			multiSchTeacherStudent = SMUtils.updateRequestBodyValues( multiSchTeacherStudent, UserConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
			multiSchTeacherStudent = SMUtils.updateRequestBodyValues( multiSchTeacherStudent, RBSDataSetupConstants.BEARER_TOKEN,
					new RBSUtils().getAccessToken( multiSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), multiSchTeacherStudent );
			new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( school ), RBSDataSetupConstants.DEFAULT_PASSWORD, studentId );

			multiGroupDetails2.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			multiGroupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
			multiGroupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			multiGroupDetails2.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			multiGroupDetails2.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, multiGroupDetails2, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			multiGroupDetails2.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			multiGroupDetails2.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

			HashMap<String, String> assignmentDetails3 = new HashMap<>();
			assignmentDetails3.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails3.put( AssignmentAPIConstants.TEACHER_ID, multipleSchoolTeacherID );
			assignmentDetails3.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

			new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails3, Arrays.asList( studentId ), Arrays.asList( "1" ) );

//			executeCourse( studentUserName, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
	        new CourseExecution().executeCourse( studentUserName, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true , "100", "1", "10" );

			multiGroupDetails2.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			multiGroupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ID, multipleSchoolTeacherID );
			multiGroupDetails2.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			multiGroupDetails2.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, multiGroupDetails2, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			multiGroupDetails2.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			multiGroupDetails2.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

			multiResponse2 = getMostSkillAssessedForGroup( smUrl, multiGroupDetails2 );
			Log.message( "Group Skill details - " + multiResponse2 );
			Log.assertThat( multiResponse2.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + multiResponse2.get( Constants.STATUS_CODE ) );
			verifyResponse( multiResponse2.get( Constants.REPORT_BODY ), true );
			break;

		case "DELETE_ASSIGNMENT":
			
			HashMap<String, String> deleteGroupDetails = new HashMap<>();
			HashMap<String, String> deleteResponse = new HashMap<>();
			
			
			deleteGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			deleteGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			deleteGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			deleteGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			deleteGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, deleteGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			deleteGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			deleteGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );

			deleteResponse = getMostSkillAssessedForGroup( smUrl, deleteGroupDetails );
			Log.message( "Group Skill details before delete - " + deleteResponse );
			Log.assertThat( deleteResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + deleteResponse.get( Constants.STATUS_CODE ) );
			verifyResponse( deleteResponse.get( Constants.REPORT_BODY ), true );

			Log.message( "Deleting assignment." );

			HashMap<String, String> assignmentDetailsDelete = new HashMap<>();
			assignmentDetailsDelete.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetailsDelete.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			assignmentDetailsDelete.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			assignmentDetailsDelete.put( AssignmentAPIConstants.COURSE_ID, deleteGroupDetails.get( GetGroupMostAssessedSkill.CONTENT_BASE ) );

			new AssignmentAPI().deleteAssignment( smUrl, assignmentDetailsDelete, CourseAPIConstants.NULL );

			deleteGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			deleteResponse = getMostSkillAssessedForGroup( smUrl, deleteGroupDetails );
			Log.message( "Group Skill details after delete - " + deleteResponse );
			Log.assertThat( deleteResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + deleteResponse.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
			exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
			verifyException( deleteResponse.get( Constants.REPORT_BODY ), exception, true, message );
////			break;
////
////		case "REASSIGNING_DELETED_ASSIGNMENT":
			Log.testCaseInfo("REASSIGNING_DELETED_ASSIGNMENT");
			HashMap<String, String> reassignGroupDetails = new HashMap<>();
			HashMap<String, String> reassignResponse = new HashMap<>();
			
			reassignGroupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			reassignGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			reassignGroupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			reassignGroupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
			reassignGroupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, reassignGroupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			reassignGroupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			reassignGroupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );

			reassignResponse = getMostSkillAssessedForGroup( smUrl, reassignGroupDetails );
			Log.message( "Group Skill details - " + reassignResponse );
			Log.assertThat( reassignResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + reassignResponse.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
			exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
			verifyException( reassignResponse.get( Constants.REPORT_BODY ), exception, true, message );

			HashMap<String, String> assignmentDetailsReassign = new HashMap<>();
			assignmentDetailsReassign.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetailsReassign.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			assignmentDetailsReassign.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

			new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetailsReassign, studentRumbaIds, Arrays.asList( reassignGroupDetails.get( GetGroupMostAssessedSkill.CONTENT_BASE ) ) );
			Log.message( "Again the same assignment assigned - " );

			reassignResponse = getMostSkillAssessedForGroup( smUrl, reassignGroupDetails );
			Log.message( "Group Skill details - " + reassignResponse );
			Log.assertThat( reassignResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + reassignResponse.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
			exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
			verifyException( reassignResponse.get( Constants.REPORT_BODY ), exception, true, message );
			break;
		}
		Log.testCaseResult();
	}

	/**
	 * Data provider for positive scenarios
	 * 
	 * @return
	 */
	@DataProvider ( name = "groupMostAssessedSkillPositive" )
	public Object[][] groupMostAssessedSkillPositive() {

		Object[][] inputData = { { "Verify the status code is 200 for the valid data.", "HAPPY_PATH", CommonAPIConstants.STATUS_CODE_OK },
				// Already Covered in HappyPath  { "Verify Status code is 200 if we give contentBaseId of default Math Assignment ", "DEFAULT_MATH_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify Status code is 200 if we give contentBaseId  for Math Custom By Standard. ", "MATH_CUSTOM_BY_STANDARD", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify Status code is 200 if we give contentBaseId  for Math Custom By Skill.", "MATH_CUSTOM_BY_SKILL", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify Status code is 200 if we give contentBaseId  for Math Custom By Settings.", "MATH_CUSTOM_BY_SETTINGS", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify Status code is 200 if we give contentBaseId  for default Reading.", "DEFAULT_READING_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify Status code is 200 if we give contentBaseId  for Reading Custom By Standard.", "READING_CUSTOM_BY_STANDARD", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify Status code is 200 if we give contentBaseId  for Reading Custom By Skill", "READING_CUSTOM_BY_SKILL", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify Status code is 200 if we give contentBaseId  for Reading Custom By Settings.", "READING_CUSTOM_BY_SETTINGS", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify Status code is 200 if we give contentBaseId  for Focus Math Course", "FOCUS_MATH", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify Status code is 200 if we give contentBaseId  for Focus Reading Course", "FOCUS_READING", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify  API Get Groups Skills Assessment Graph when the student removed from group.", "STUDENT_REMOVED_FROM_GROUP", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify  API Get Groups Skills Assessment Graph when the assignment is paused.", "PAUSED_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify  API Get Groups Skills Assessment Graph when the student is shared student.", "SHARED_STUDENT_GROUP", CommonAPIConstants.STATUS_CODE_OK },
				// Already Covered  { "Verify  API Get Groups Skills Assessment Graph when the assignment has only one skill mapped.", "MATH_CUSTOM_BY_SKILL", CommonAPIConstants.STATUS_CODE_OK },
				// Already Covered  { "Verify  API Get Groups Skills Assessment Graph the assignment has mapped with multiple skills.", "MATH_CUSTOM_BY_SETTINGS", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify the teacher can able to see the Groups skills assessment from all the teachers when the group has more then one teacher.", "MULTI_TEACHER_GROUP", CommonAPIConstants.STATUS_CODE_OK },
				// { "Verify when the student is part of multiple school.", "MULTI_SCHOOL_STUDENT", CommonAPIConstants.STATUS_CODE_OK },
				// { "Verify when the student is part of multiple school and both the school has progress.", "MULTI_SCHOOL_STUDENT", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify when the teacher is part of multiple school.", "MULTI_SCHOOL_TEACHER", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify  API Get Groups Skills Assessment Graph when the assignment is deleted.", "DELETE_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
//				{ "Verify Status code is 200 after the assignment is reassigned to the group.", "REASSIGNING_DELETED_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },

		};
		return inputData;
	}

	@Test ( priority = 2, dataProvider = "groupMostassessedNegativeData", groups = { "SMK-51958", "Group", "Adding Students to Group", "P2", "API" } )
	public void tcNegativeTestCases01( String description, String scenario, String statusCode ) throws Exception {

		Log.testCaseInfo( description );

		HashMap<String, String> groupDetails = new HashMap<>();
		List<String> studentRumbaIds = new ArrayList<>();
		String exception = null;
		boolean status = false;
		String message = null;

		switch ( scenario ) {

		case "EMPTY_GROUP":
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group Test" + System.nanoTime() );
			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
			response = getMostSkillAssessedForGroup( smUrl, groupDetails );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
			exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
			verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
			break;

		case "STUDENT_NOT_ATTENDED_ANY_ASSIGNMENT":
		    studentRumbaIds.clear();
			studentRumbaIds.add( student2Id );
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group Test" + System.nanoTime() );

			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
			response = getMostSkillAssessedForGroup( smUrl, groupDetails );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
			exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
			verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
			break;

		case "DELETED_GROUP":
		    studentRumbaIds.clear();
			studentRumbaIds.add( student2Id );
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group Test" + System.nanoTime() );
			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

			new RBSUtils().deleteClass( groupDetails.get( CreateGroupAPIConstants.GROUP_ID ), "", groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ID ) );

			response = getMostSkillAssessedForGroup( smUrl, groupDetails );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
			exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
			verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
			break;

		case "DELETED_ASSIGNMENT":
		    studentRumbaIds.clear();
			studentRumbaIds.add( student2Id );
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group Test" + System.nanoTime() );
			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );

			assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );

			new AssignmentAPI().deleteAssignment( smUrl, assignmentDetails, CourseAPIConstants.NULL );

			response = getMostSkillAssessedForGroup( smUrl, groupDetails );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
			exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
			verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
			break;

		case "DIFFERENT_SUBJECT_TYPE_ID":
		    studentRumbaIds.clear();
			studentRumbaIds.add( student1Id );
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group Test" + System.nanoTime() );
			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.READING );
			groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

			assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

			response = getMostSkillAssessedForGroup( smUrl, groupDetails );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
			exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
			verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
			break;

		case "INVALID_ORG":
		    studentRumbaIds.clear();
			studentRumbaIds.add( student1Id );
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group Test" + System.nanoTime() );
			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
			groupDetails.put( CreateGroupAPIConstants.INVALID_ORG, "ABCD" );

			response = getMostSkillAssessedForGroup( smUrl, groupDetails );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			message = String.format( CommonAPIConstants.MISMATCH_ORG_MESSAGE, groupDetails.get( CreateGroupAPIConstants.INVALID_ORG ), groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );
			exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
			verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
			break;

		case "INVALID_GROUP":
		    studentRumbaIds.clear();
			studentRumbaIds.add( student2Id );
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group Test" + System.nanoTime() );
			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
			groupDetails.put( CreateGroupAPIConstants.INVALID_GROUP_ID, "ABCD" );

			response = getMostSkillAssessedForGroup( smUrl, groupDetails );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.MOST_SKILL_ASSESSED_ZERO_STATE_MESSAGE;
			exception = CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION;
			verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
			break;

		case "INVALID_CONTENT_BASE":

		    studentRumbaIds.clear();
			studentRumbaIds.add( student1Id );
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group Test" + System.nanoTime() );
			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
			groupDetails.put( GetGroupMostAssessedSkill.INVALID_CONTENT_BASE, "ABCD" );

			response = getMostSkillAssessedForGroup( smUrl, groupDetails );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
			message = CommonAPIConstants.NUMBER_FORMAT_EXCEPTION;
			verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
			break;

		case "INVALID_SUBJECT_TYPE":

		    studentRumbaIds.clear();
			studentRumbaIds.add( student1Id );
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group Test" + System.nanoTime() );
			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
			groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
			groupDetails.put( GetGroupMostAssessedSkill.INVALID_SUBJECT_TYPE, "ABCD" );

			response = getMostSkillAssessedForGroup( smUrl, groupDetails );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.NUMBER_FORMAT_EXCEPTION;
			exception = CommonAPIConstants.METHOD_ARGUMENT_TYPE_MISMATCH;
			verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
			break;

		case "WITHOUT_SUBJECT_TYPE":

		    studentRumbaIds.clear();
			studentRumbaIds.add( student1Id );
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group Test" + System.nanoTime() );
			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );

			response = getMostSkillAssessedForGroup( smUrl, groupDetails );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.EMPTY_SUBJECT_ID_MESSAGE;
			exception = CommonAPIConstants.MISMATCH_SERVLET_EXCEPTION;
			verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
			break;

		case "INVALID_TEACHER":

		    studentRumbaIds.clear();
			studentRumbaIds.add( student1Id );
			groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
			groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group Test" + System.nanoTime() );
			groupDetails.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" ) );
			groupDetails.put( GetGroupMostAssessedSkill.CONTENT_BASE, contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
			groupDetails.put( CreateGroupAPIConstants.INVALID_GROUP_OWNER_ID, "ABCD" );
			groupDetails.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );

			response = getMostSkillAssessedForGroup( smUrl, groupDetails );
			Log.message( "Group Skill details - " + response );
			Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
			message = CommonAPIConstants.MISMATCH_TEACHER_MESSAGE;
			exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
			verifyException( response.get( Constants.REPORT_BODY ), exception, true, message );
			break;

		}

	}

	/**
	 * Data provider for negative data
	 * 
	 * @return
	 */
	@DataProvider ( name = "groupMostassessedNegativeData" )
	public Object[][] groupMostAssessedSkillNegative() {

		Object[][] inputData = { { "Verify the response is 200 if the Group has No student", "EMPTY_GROUP", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify the status code is 200 and Student from the group should not attend any assignment.", "STUDENT_NOT_ATTENDED_ANY_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify that Data not found exception is returned for a deleted group", "DELETED_GROUP", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify response code is 200 data not found exception after assignment is deleted for the group", "DELETED_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify Status code is 200 data not found exception if we give subjectTypeId as 1 for reading assignment", "DIFFERENT_SUBJECT_TYPE_ID", CommonAPIConstants.STATUS_CODE_OK },
				{ "verify  API Get Groups Skills Assessment Graph when the student don't have any skill assessed.", "STUDENT_NOT_ATTENDED_ANY_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify the response code is 400 if invalid Org ID is given", "INVALID_ORG", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify the response code is 400 if invalid Staff ID is given", "INVALID_TEACHER", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify the response code is 400 if invalid Group ID is given", "INVALID_GROUP", CommonAPIConstants.STATUS_CODE_OK },
				{ "Verify the response code is 400 if invalid contentBaseId is given", "INVALID_CONTENT_BASE", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify that the response code is 400 for invalid subjectTypeId.", "INVALID_SUBJECT_TYPE", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
				{ "Verify that the response code is 400 without passing subjectTypeId.", "WITHOUT_SUBJECT_TYPE", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },

		};
		return inputData;
	}

	/**
	 * Verifying the actual response
	 * 
	 * @param actualBody
	 * @param isMath
	 * @return
	 */
	public boolean verifyResponse( String actualBody, boolean isMath ) {
		boolean isVerified = false;
		JSONObject actualBodyJsonObj = new JSONObject( actualBody );
		JSONArray actualBodyJsonArray = new JSONArray( actualBodyJsonObj.get( Constants.DATA ).toString() );
		for ( Object skill : actualBodyJsonArray ) {
			JSONObject skillDetails = new JSONObject( skill.toString() );
			String skillId = skillDetails.get( "skillId" ).toString();
			String skillDetailsFromDB = new SqlHelperCourses().getSkillDetails( skillId, isMath );
			if ( skillDetailsFromDB.equalsIgnoreCase( skillDetails.get( "skillName" ).toString() ) ) {
				isVerified = true;
				Log.pass( "Skill name verified successfully!" );
			} else {
				Log.fail( "Skill name is not matched - Expected -  " + skillDetailsFromDB + " Actual - " + skillDetails.get( "skillName" ).toString() );
			}
			JSONArray loDetails = skillDetails.getJSONArray( "loDetails" );
			for ( Object lo : loDetails ) {
				JSONObject loInfo = new JSONObject( lo.toString() );
				String loId = loInfo.get( "objectId" ).toString();
				HashMap<String, String> catalogDetails = new SqlHelperCourses().getCatalogDetails( loId );
				if ( catalogDetails.get( Course.LO_OBJECT_DESCRIPTION ).equalsIgnoreCase( loInfo.get( Course.LO_OBJECT_DESCRIPTION ).toString() ) ) {
					isVerified = true;
					Log.pass( "LO name verified successfully! - " + loInfo.get( Course.LO_OBJECT_DESCRIPTION ).toString() );
				} else {
					Log.pass( "LO name not Matched with actual response. Expected - " + catalogDetails.get( Course.LO_OBJECT_DESCRIPTION ) + "Actual - " + loInfo.get( Course.LO_OBJECT_DESCRIPTION ).toString() );
				}

				if ( catalogDetails.get( Course.CATALOG_NUMBER ).equalsIgnoreCase( loInfo.getString( Course.CATALOG_NUMBER ).toString() ) ) {
					isVerified = true;
					Log.pass( "Catalog number verified successfully! - " + loInfo.get( Course.CATALOG_NUMBER ).toString() );
				} else {
					Log.pass( "LO name not Matched with actual response. Expected - " + catalogDetails.get( Course.CATALOG_NUMBER ) + "Actual - " + loInfo.getString( Course.CATALOG_NUMBER ).toString() );
				}
			}

			String percentage = skillDetails.get( "percentMastered" ).toString();
			if ( Integer.parseInt( percentage ) <= 100 ) {
				Log.pass( "Percentage mastered returned as expected!" );
			} else {
				Log.fail( "Issue in displaying Percentage mastered. " );
			}

		}
		return isVerified;

	}

	/**
	 * To execute the course
	 * 
	 * @param studentUserName
	 * @param courseName
	 * @throws IOException
	 */
	public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
	    WebDriver chromeDriver = null;
        StudentDashboardPage studentsPage = null;
        boolean flagIsExecutionSuccessfull = false;
        try {
            for ( int i = 0; i < 3; i++ ) {
                try {
                    // Get driver
                    chromeDriver = WebDriverFactory.get( browser );
                    LoginWrapper.loginToSuccessMakerAsStudent( chromeDriver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
                    studentsPage = new StudentDashboardPage( chromeDriver );
                    Log.message( "Student username " + studentUserName );
                } catch ( Exception e ) {
                    Log.message( "Issue occurrred at driver creation and Login , reattempting : " + i );
                    continue;
                }
                if ( isMath ) {
                    try {
                        studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "10" );
                        studentsPage.logout();
                        flagIsExecutionSuccessfull = true;
                        break;
                    } catch ( Exception e ) {
                        Log.message( "Issue in course execution!!!" );
                        Log.message( "Issue in executing this course:" + courseName + " , for this Student Username : " + studentUserName );
                    }
                } else {
                    try {
                        studentsPage.executeReadingCourse( studentUserName, courseName, "100", "2", "20" );
                        studentsPage.logout();
                        flagIsExecutionSuccessfull = true;
                        break;
                    } catch ( Exception e ) {
                        Log.message( "Issue in course execution!!!" );
                        Log.message( "Issue in executing this course:" + courseName + " , for this Student Username : " + studentUserName );
                    }
                }
            }
        } finally {
            if ( flagIsExecutionSuccessfull ) {
                Log.message( "Course executed successfully" );
            } else {
                Log.message( "Course execution failed after reattempting : 3" );
            }
            chromeDriver.quit();

        }

    }

	/**
	 * This method is used to create a Reading Standard Course with All LO 
	 * 
	 */
	public void createReadingAllStandardCourse(String teacherUsername, String standardCourseName ) throws Exception {

		// Get driver
		final WebDriver driver = WebDriverFactory.get( browser );
		LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
		TeacherHomePage tHomePage = smLoginPage.loginToSM( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD, true );
		Log.message("Logged into SM as Teacher: " + teacherUsername);
		// Navigate to Courses Tab
		tHomePage.topNavBar.navigateToCourseListingPage();
		CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
		courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

		CoursesPage coursePage = new CoursesPage( driver );
		try {
			coursePage.createReadingCustomCourseWithAllStandards(standardCourseName, teacherUsername, smUrl);

			// Sign out
			tHomePage.topNavBar.signOutfromSM();
		} catch (Exception e) {
			driver.close();
		}

	}
	
	/**
	 * Generating request values
	 * 
	 * @param studentExistingData
	 * @param newDetails
	 * @param key
	 * @param value
	 * @return
	 */
	public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

		HashMap<String, String> generatedStudentDetails = newDetails;
		generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
		generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
		generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
		generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
		generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
		generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
		generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
		generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
		generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
		generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
		generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
		generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
		generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
		generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
		generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
		generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
		generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

		return generatedStudentDetails;
	}

}