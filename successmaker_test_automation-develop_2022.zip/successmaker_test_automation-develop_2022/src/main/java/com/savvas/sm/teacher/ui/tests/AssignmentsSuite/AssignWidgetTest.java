package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

@Listeners ( EmailReport.class )
public class AssignWidgetTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String teacherID;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String studentDetails;
    String studentDetailsSecond;
    String studentSMDetails;
    String studentSMDetailsSecond;
    private HashMap<String, String> groupDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String stuUserName;
    private String stuFName;
    private String token = null;
    String groupName;
    
    @BeforeClass (alwaysRun = true)
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        UserAPI userAPIMethod = new UserAPI();
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );  
        
        studentDetails = RBSDataSetup.getMyStudent(school, username);
        studentDetailsSecond = RBSDataSetup.getMyStudent(school, username);

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ) );
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        stuFName = SMUtils.getKeyValueFromResponse(studentDetails, "firstName");
        // Group
        groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );
        
    }

    @Test ( description = "Verify the title of Assign course window", priority = 1 )
    public void tcSMBVT001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT001: Verify the title of Assign course window. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );
     
            Log.softAssertThat( popup.getAssignmentTitle().equals( Constants.MATH_ASSIGMENT_TITLE ), Constants.MATH_COURSE_TITLE_DISPLAYED, Constants.MATH_COURSE_TITLE_NOT_DISPLAYED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

           // Click on Assign Button for Reading course
            popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 1 ) );

            Log.softAssertThat( Boolean.TRUE.equals( popup.getAssignmentTitle().equals( Constants.READING_ASSIGMENT_TITLE ) ), Constants.READ_COURSE_TITLE_DISPLAYED, Constants.READ_COURSE_TITLE_NOT_DISPLAYED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that clicking on Assign button user navigated to Assign course window", priority = 2 )
    public void tcSMBVT002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT002: Verify that clicking on Assign button user navigated to Assign course window. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            Log.softAssertThat( popup.elementsDisplayedOnCourseAssignWidget(), Constants.MATH_COURSE_ASSIGN_DISPLAYED, Constants.MATH_COURSE_ASSIGN_NOT_DISPLAYED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Click on Assign Button for Reading course
            popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 1 ) );

            Log.softAssertThat( popup.elementsDisplayedOnCourseAssignWidget(), Constants.READ_COURSE_ASSIGN_DISPLAYED, Constants.READ_COURSE_ASSIGN_NOT_DISPLAYED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that Groups is the default selection", priority = 3 )
    public void tcSMBVT003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT003: Verify that Groups is the default selection. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            Log.softAssertThat( Boolean.TRUE.equals( popup.radioButtonsDefaultSelection() ), Constants.GROUP_RADIO_ENABLED, Constants.GROUP_RADIO_DISABLED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that teacher is able to add a course to a group", priority = 4 )
    public void tcSMBVT004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT004: Verify that teacher is able to add a course to a group. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Add Multiple Groups
            popup.clickMultipleAddButton();

            Log.softAssertThat( Boolean.TRUE.equals( popup.groupsOrStudentsInSearchTxtBx() != 0 ), Constants.GROUP_ADDED, Constants.GROUP_NOT_ADDED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that teacher is able to add a course to a student", priority = 5 )
    public void tcSMBVT005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT005: Verify that teacher is able to add a course to a student. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Click on Students Radio button
            popup.radioButtonSelectAssignWidget( Constants.STUDENTS );

            // Add Multiple Students
            popup.clickMultipleAddButton();

            Log.softAssertThat( Boolean.TRUE.equals( popup.groupsOrStudentsInSearchTxtBx() != 0 ), Constants.STUDENTS_ADDED, Constants.STUDENTS_NOT_ADDED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that user is able to remove a group from the list", priority = 6 )
    public void tcSMBVT006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT006: Verify that user is able to remove a group from the list. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Add a Group
            popup.clickAddButton();

            // Click on close button for added Group or Student
            popup.clickCloseBtnForGroupOrStudent();

            Log.softAssertThat( Boolean.TRUE.equals( popup.groupsOrStudentsInSearchTxtBx() == 0 ), Constants.GROUP_REMOVED, Constants.GROUP_NOT_REMOVED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that user is able to remove a student from the list", priority = 7 )
    public void tcSMBVT007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT007: Verify that user is able to remove a student from the list. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Click on Students Radio button
            popup.radioButtonSelectAssignWidget( Constants.STUDENTS );

            // Add a Student
            popup.clickAddButton();

            // Click on close button for added Group or Student
            popup.clickCloseBtnForGroupOrStudent();

            Log.softAssertThat( Boolean.TRUE.equals( popup.groupsOrStudentsInSearchTxtBx() == 0 ), Constants.STUDENTS_REMOVED, Constants.STUDENTS_NOT_REMOVED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that teacher is not able to add a duplicate group to the course", priority = 8 )
    public void tcSMBVT008() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT008: Verify that teacher is not able to add a duplicate group to the course. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Add a Group
            popup.clickAddButton();

            Log.softAssertThat( popup.getRemoveButtonText(), Constants.REMOVE_DISPLAYED, Constants.REMOVE_NOT_DISPLAYED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that teacher is not able to add a duplicate student to the course", priority = 9 )
    public void tcSMBVT009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT009: Verify that teacher is not able to add a duplicate student to the course. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Click on Students Radio button
            popup.radioButtonSelectAssignWidget( Constants.STUDENTS );

            // Add a Student
            popup.clickAddButton();

            Log.softAssertThat( popup.getRemoveButtonText(), Constants.REMOVE_DISPLAYED, Constants.REMOVE_NOT_DISPLAYED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that teacher is able to add an existing student to the course", priority = 10 )
    public void tcSMBVT010() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT010: Verify that teacher is able to add an existing student to the course. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
            
			CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Click on Students Radio button
            popup.radioButtonSelectAssignWidget( Constants.STUDENTS );

            // Click on Assign Button
            String firstStudentName = popup.addStudentsToAssignment();

            // Click on Assign Button for Math course
            popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Click on Students Radio button
            popup.radioButtonSelectAssignWidget( Constants.STUDENTS );

            Log.softAssertThat( Boolean.FALSE.equals( popup.getStudentOrGroupFromPopUp( firstStudentName ) ), Constants.PREVIOUSLY_ADDED_STUDENT_NOT_DISPLAYED, Constants.PREVIOUSLY_ADDED_STUDENT_DISPLAYED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that teacher is able to add an existing group to the course", priority = 11 )
    public void tcSMBVT011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT011: Verify that teacher is able to add an existing group to the course. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Click on Assign Button
            String firstGroupName = popup.addgroupsToAssignment();

            // Click on Assign Button for Math course
            popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            Log.softAssertThat( Boolean.FALSE.equals( popup.getStudentOrGroupFromPopUp( firstGroupName ) ), Constants.PREVIOUSLY_ADDED_GROUP_NOT_DISPLAYED, Constants.PREVIOUSLY_ADDED_GROUP_DISPLAYED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that no action takes place when user click on assign button with out selecting any group", priority = 12 )
    public void tcSMBVT012() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT012: Verify that no action takes place when user click on assign button with out selecting any group. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Click on Assign Button which is disabled
            popup.assignBtn();

            Log.softAssertThat( popup.getAssignmentTitle().equals( Constants.MATH_ASSIGMENT_TITLE ), Constants.USER_ON_ASSIGN, Constants.USER_NOT_ON_ASSIGN );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that no action takes place when user click on assign button with out selecting any Student", priority = 13 )
    public void tcSMBVT013() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT013: Verify that no action takes place when user click on assign button with out selecting any Student. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Click on Students Radio button
            popup.radioButtonSelectAssignWidget( Constants.STUDENTS );

            SMUtils.logDescriptionTC( "SMK-7307 : Verify that the list of students displayed should belongs to the specific teacher" );

            // Click on Assign Button which is disabled
            popup.assignBtn();

            Log.softAssertThat( popup.getAssignmentTitle().equals( Constants.MATH_ASSIGMENT_TITLE ), Constants.USER_ON_ASSIGN, Constants.USER_NOT_ON_ASSIGN );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that course settings are dispalyed on Assign course window", priority = 14 )
    public void tcSMBVT014() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT014: Verify that course settings are dispalyed on Assign course window. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            Log.softAssertThat( popup.courseAssignSettingLabels(), Constants.MATH_SETTINGS_DISPLAYED, Constants.MATH_SETTINGS_NOT_DISPLAYED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Click on Assign Button for Reading course
            popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 1 ) );

            Log.softAssertThat( popup.courseAssignSettingLabels(), Constants.READ_SETTINGS_DISPLAYED, Constants.READ_SETTINGS_NOT_DISPLAYED );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that clicking on close button is closing the Assign course window", priority = 15 )
    public void tcSMBVT015() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT015: Verify that clicking on close button is closing the Assign course window. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            Log.softAssertThat( Boolean.TRUE.equals( tCoursesPage.getCourseNameList().size() > 0 ), Constants.MATH_ASSIGN_WIDGET_CLOSED, Constants.MATH_ASSIGN_WIDGET_NOT_CLOSED );

            // Click on Assign Button for Reading course
            popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 1 ) );

            // Click on Close Button of Course-Assign widget
            tCoursesPage.clickCloseBtn();

            Log.softAssertThat( tCoursesPage.getCourseNameList().size() > 0, Constants.READ_ASSIGN_WIDGET_CLOSED, Constants.READ_ASSIGN_WIDGET_NOT_CLOSED );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that clicking on cancel button is closing the Assign course window", priority = 16 )
    public void tcSMBVT016() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT016: Verify that clicking on cancel button is closing the Assign course window. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();

            // Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Click on Cancel Button of Course-Assign widget
            popup.cancelChangesBtn();

            Log.softAssertThat( Boolean.TRUE.equals( tCoursesPage.getCourseNameList().size() > 0 ), Constants.MATH_ASSIGN_WIDGET_CLOSED, Constants.MATH_ASSIGN_WIDGET_NOT_CLOSED );

            // Click on Assign Button for Reading course
            popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 1 ) );

            // Click on Cancel Button of Course-Assign widget
            popup.cancelChangesBtn();

            Log.softAssertThat( Boolean.TRUE.equals( tCoursesPage.getCourseNameList().size() > 0 ), Constants.READ_ASSIGN_WIDGET_CLOSED, Constants.READ_ASSIGN_WIDGET_NOT_CLOSED );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that the list of students displayed should belongs to the specific teacher", priority = 17 )
    public void tcSMBVT017() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT017:Verify that the list of students displayed should belongs to the specific teacher." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );

            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.createStudent();
            studentsPage.createStudent();

            // Get Assignments Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );
            courseListingPage.selectCourseTypeFromDropDown( "Default Courses" );
            CoursesPage coursepage = new CoursesPage( driver );

            // Assigned Cousres to Students
            coursepage.clickCourseName( Constants.READING );
            coursepage.clickAssignBtn();

            SMUtils.logDescriptionTC( "SMK-7309 : Verify that the list of groups displayed should belongs to the specific teacher   " + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

            int sizeGroup = assignAssignmentPopup.verifyStudents();
            Log.assertThat( sizeGroup != 0, "List of" + Constants.Reports.GROUP_DROPDOWN + " are displayed Sucessfuly", "List of " + Constants.Reports.GROUP_DROPDOWN + " are not displayed" );
            assignAssignmentPopup.checkStudents();

            SMUtils.logDescriptionTC( "SMK-7307  and SMK-7320: Verify that the list of students displayed should belongs to the specific teacher   " + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

            int sizeStud = assignAssignmentPopup.verifyStudents();
            Log.assertThat( sizeStud != 0, "List of" + Constants.Reports.STUDENTS_DROPDOWN + " are displayed Sucessfuly", "List of " + Constants.Reports.STUDENTS_DROPDOWN + " are not displayed" );
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify that teacher is able to assign a course", priority = 18 )
    public void tcSMBVT018() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT018:Verify that teacher is able to assign a course." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );
            String customSettingCourseMath = Constants.CUSTOM_SETTINGS_MATH_ASSIGMENT_TITLE + System.nanoTime();
            // Create Math custom setting course with IP Off
            coursePage.clickMathCourse();
            coursePage.clickMakeCopyBtn();
            coursePage.enterCourseName( customSettingCourseMath );
            coursePage.clickSettingsRadioBtn();
            coursePage.clickNextBtn();
            coursePage.turnOffInitialPlacement();
            coursePage.clickCreateBtn();

            // Verify that the new course showed in course listing page
            coursePage.verifyCourseRemovedSuccessfully( customSettingCourseMath );
            coursePage.clickCourseName( customSettingCourseMath );
            coursePage.clickAssignBtn();

            SMUtils.logDescriptionTC( "SMK-7316 and SMK-7321: Verify that teacher is able to assign a course to the multiple groups" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );
            coursePage.addCourseToGroup();

            SMUtils.logDescriptionTC( "SMK-7317 AND SMK-7322: Verify that teacher is able to assign a course to the multiple students" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

            tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.nap(3);
            coursePage.clickCourseName( customSettingCourseMath );
            coursePage.clickAssignBtn();
            assignAssignmentPopup.checkStudents();
            coursePage.addCourseToStudents();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify that the list of students displayed should belongs to the specific teacher", priority = 19 )
    public void tcSMBVT019() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
    	
        Log.testCaseInfo( "tcSMBVT019:Verify that teacher can search." + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");
			
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            AssignAssignmentPopup assignAssignmentPopup = new AssignAssignmentPopup( driver );
            AssignmentDetailsPage assignmentdetailspage = new AssignmentDetailsPage( driver );
            String customSettingCourseMath = Constants.CUSTOM_READING_ASSIGMENT_TITLE + System.nanoTime();
            // Create Math custom setting course with IP Off
            coursePage.clickMathCourse();
            coursePage.clickMakeCopyBtn();
            coursePage.enterCourseName( customSettingCourseMath );
            coursePage.clickSettingsRadioBtn();
            coursePage.clickNextBtn();
            coursePage.turnOffInitialPlacement();
            SMUtils.nap(5);
            coursePage.clickCreateBtn();

            // Verify that the new course showed in course listing page
            coursePage.verifyCourseRemovedSuccessfully( customSettingCourseMath );
            coursePage.clickCourseName( customSettingCourseMath );
            SMUtils.nap(3);
            coursePage.clickAssignBtn();

            SMUtils.logDescriptionTC( "SMK-7323 : Verify that teacher can search for groups to add by choosing Groups and entering search criteria" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );
            assignAssignmentPopup.enterSearchTextboxAssignment( groupName );

            int sizeGroup = assignAssignmentPopup.verifyStudents();
            Log.assertThat( sizeGroup != 0, "List of" + Constants.Reports.GROUP_DROPDOWN + " are displayed Sucessfuly", "List of " + Constants.Reports.GROUP_DROPDOWN + " are not displayed" );

            SMUtils.logDescriptionTC( "SMK-7324 : Verify that teacher can search for students to add by choosing Students and entering search" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

            assignAssignmentPopup.checkStudents();

            assignAssignmentPopup.enterSearchTextboxAssignment( stuFName );

            int sizeStud = assignAssignmentPopup.verifyStudents();
            Log.assertThat( sizeStud != 0, "List of" + Constants.Reports.STUDENTS_DROPDOWN + " are displayed Sucessfuly", "List of " + Constants.Reports.STUDENTS_DROPDOWN + " are not displayed" );

            assignAssignmentPopup.clickCancelButtonOnPopup();

            SMUtils.logDescriptionTC( "SMK-7325 : Verify that group search results are displaying after entering 3 characters or 250ms of input delay" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );
            SMUtils.nap(5);
            coursePage.clickAssignBtn();
            String gorupThreeletter= groupName.substring(0, 3);
            assignAssignmentPopup.enterSearchTextboxAssignment( gorupThreeletter);
            int sizeGroupa = assignAssignmentPopup.verifyStudents();
            Log.assertThat( sizeGroupa != 0, "List of" + Constants.Reports.GROUP_DROPDOWN + " are displayed Sucessfuly", "List of " + Constants.Reports.GROUP_DROPDOWN + " are not displayed" );

            SMUtils.logDescriptionTC( "SMK-7326 : Verify that student search results are displaying after entering 3 characters or 250ms of input delay" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );
            assignAssignmentPopup.checkStudents();
            String studentThree=stuFName.substring(0, 3);
            assignAssignmentPopup.enterSearchTextboxAssignment(studentThree);
            int sizeStuda = assignAssignmentPopup.verifyStudents();
            Log.assertThat( sizeStuda != 0, "List of" + Constants.Reports.STUDENTS_DROPDOWN + " are displayed Sucessfuly", "List of " + Constants.Reports.STUDENTS_DROPDOWN + " are not displayed" );

            SMUtils.logDescriptionTC( "SMK-7327 : Verify that No reults message is displayed while passing invalid group name in the search field" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

            assignAssignmentPopup.clickCancelButtonOnPopup();
            SMUtils.nap(5);
            coursePage.clickAssignBtn();
            assignAssignmentPopup.enterSearchTextboxAssignment( "aaa" );
            String errorMessagegroup = assignAssignmentPopup.verifyErrorMessage( browser );
            String expectedErromessagegroup = Constants.SEARCH_MESSAGE + " " + Constants.SEARCH_ERROR_MESSAGE;

            Log.assertThat( errorMessagegroup.matches( expectedErromessagegroup ), Constants.Reports.GROUP_DROPDOWN + " Error Message  Matched", Constants.Reports.GROUP_DROPDOWN + "Error Message not Matched" );

            SMUtils.logDescriptionTC( "SMK-7328 : Verify that error message is displayed while passing invalid student name in the search field" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

            assignAssignmentPopup.checkStudents();
            assignAssignmentPopup.enterSearchTextboxAssignment( "bbb" );

            String errorMessagestud = assignAssignmentPopup.verifyErrorMessage( browser );
            String expectedErromessagestud = Constants.SEARCH_MESSAGE + " " + Constants.SEARCH_ERROR_MESSAGE;

            Log.assertThat( errorMessagestud.matches( expectedErromessagestud ), Constants.Reports.STUDENTS_DROPDOWN + " Error Message  Matched", Constants.Reports.STUDENTS_DROPDOWN + "Error Message not Matched" );

            SMUtils.logDescriptionTC( "SMK-7329 and SMK-7331 : Verify that remove button is displayed when the group is already added to the list" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );
            assignAssignmentPopup.clickCancelButtonOnPopup();
            SMUtils.nap(5);
            coursePage.clickAssignBtn();
            assignAssignmentPopup.enterSearchTextboxAssignment( groupName );
            assignAssignmentPopup.clickAddButton();
            Log.message( "Group Button Text" );
            Log.softAssertThat( assignAssignmentPopup.getRemoveButtonText(), Constants.REMOVE_DISPLAYED, Constants.REMOVE_NOT_DISPLAYED );
            assignAssignmentPopup.checkStudents();

            SMUtils.logDescriptionTC( "SMK-7330 : Verify that remove button is displayed when the student is already added to the list" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );
            assignAssignmentPopup.enterSearchTextboxAssignment( stuFName );
            assignAssignmentPopup.clickAddButton();
            Log.message( "Student Button Text" );
            Log.softAssertThat( assignAssignmentPopup.getRemoveButtonText(), Constants.REMOVE_DISPLAYED, Constants.REMOVE_NOT_DISPLAYED );

            SMUtils.logDescriptionTC( "SMK-7335 : Verify that teacher is able to assign a course to a group by modifying existing course settings" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );
            assignAssignmentPopup.clickCancelButtonOnPopup();
            SMUtils.nap(5);
            coursePage.clickAssignBtn();
            assignAssignmentPopup.enterSearchTextboxAssignment( groupName );
            assignAssignmentPopup.clickAddButton();
            assignmentdetailspage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            assignmentdetailspage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );
            assignAssignmentPopup.clickAssignButtonOnPopup();

            SMUtils.logDescriptionTC( "SMK-7336 : Verify that teacher is able to assign a course to a student by modifying existing course settings" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );
            tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( customSettingCourseMath );
            SMUtils.nap(5);
            coursePage.clickAssignBtn();
            assignAssignmentPopup.checkStudents();

            assignmentdetailspage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            assignmentdetailspage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            coursePage.addCourseToStudents();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
