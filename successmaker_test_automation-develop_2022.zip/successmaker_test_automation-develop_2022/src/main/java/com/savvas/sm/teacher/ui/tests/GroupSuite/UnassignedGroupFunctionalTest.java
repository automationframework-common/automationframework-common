package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperOrganization;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This class test the unassigned group UI testing.
 *
 * @author ajith.mohan
 *
 */
@Listeners ( EmailReport.class )
public class UnassignedGroupFunctionalTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String sessionCookie;
    private String username = null;
    private String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String teacher = "Teacher47";

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = DataSetup.teacherDetailsMap.get( teacher );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );

    }

    @Test ( priority = 1, groups = { "SMK-43459", "Groups", "UnassignedGroupTest" } )
    public void tcUnassignedGroupTest01( ITestContext context ) throws Exception {

        Log.testCaseInfo( "Verify the unassigned groups are displaying in Student Groups Section" + "<small><b><i>[" + browser + "]</b></i></small>" );

        SMUtils.logDescriptionTC( "SMK-10840 : Verify the unassigned groups are displaying in Student Groups Section" );
        //Creating unassignedStudent
        String unassignedStudentDetails = createUnassignedStudent();
        String groupName = "UnassignedGroupAuto" + System.nanoTime();
        String unassignedStuddentName = SMUtils.getKeyValueFromResponse( unassignedStudentDetails, "data,userName" );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            List<String> studentNamesToCreateGroup = new ArrayList<>();
            studentNamesToCreateGroup.add( unassignedStuddentName );

            //Creating group with school students
            groupsTab.createGroupWithSchoolStudents( groupName, studentNamesToCreateGroup, Constants.GroupUIConstants.GROUP_ALLGRADES );

            //Navigating to student and verifying unassigned group present or not.
            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();
            studentTab.clickviewStudentByEllipsis( unassignedStuddentName );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Newly created group present in student associated group", "Newly created group is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            SMUtils.logDescriptionTC( "SMK-10841 : Verify the groups listing page, when the unassigned student reflecting in Student Listing page" );
            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsTab.isGroupExist( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in group listing page." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 2, groups = { "SMK-43459", "Groups", "UnassignedGroupTest" } )
    public void tcUnassignedGroupTest02( ITestContext context ) throws Exception {

        Log.testCaseInfo( "SMK-10842 : Verify the groups listing page, when the custom group has both unassigned student and active student" + "<small><b><i>[" + browser + "]</b></i></small>" );

        //Creating unassignedStudent
        String unassignedStudentDetails = createUnassignedStudent();
        String groupName = "UnassignedGroupAuto" + System.nanoTime();
        String unassignedStuddentName = SMUtils.getKeyValueFromResponse( unassignedStudentDetails, "data,userName" );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            List<String> studentNamesToCreateGroup = new ArrayList<>();

            studentNamesToCreateGroup.add( unassignedStuddentName );

            for ( int studentCount = 1; studentCount <= 2; studentCount++ ) {
                studentNamesToCreateGroup.add( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,userName" ) );
            }

            groupsTab.createGroupWithSchoolStudents( groupName, studentNamesToCreateGroup, Constants.GroupUIConstants.GROUP_ALLGRADES );

            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();

            //Navigating to student and verifying unassigned group present or not.
            studentTab.clickviewStudentByEllipsis( unassignedStuddentName );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Newly created group present in student associated group", "Newly created group is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsTab.isGroupExist( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in group listing page." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 3, dataProvider = "sharedStudentData", groups = { "SMK-43459", "Groups", "UnassignedGroupTest" } )
    public void tcUnassignedGroupTest03( ITestContext context, String sharedStudentName ) throws Exception {

        Log.testCaseInfo( "SMK-10843 : Verify the groups listing page, when the custom group has both shared student and unassigned student " + "<small><b><i>[" + browser + "]</b></i></small>" );

        //Creating unassignedStudent
        String unassignedStudentDetails = createUnassignedStudent();
        String groupName = "UnassignedGroupAuto" + System.nanoTime();
        String unassignedStuddentName = SMUtils.getKeyValueFromResponse( unassignedStudentDetails, "data,userName" );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
        	teacherDetails = DataSetup.teacherDetailsMap.get( teacher );
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> studentNamesToCreateGroup = new ArrayList<>();
            studentNamesToCreateGroup.add( sharedStudentName );
            studentNamesToCreateGroup.add( unassignedStuddentName );

            groupsTab.createGroupWithSchoolStudents( groupName, studentNamesToCreateGroup, Constants.GroupUIConstants.GROUP_ALLGRADES );

            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();

            //Navigating to student and verifying unassigned group present or not.
            studentTab.clickviewStudentByEllipsis( unassignedStuddentName );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Newly created group present in student associated group", "Newly created group is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsTab.isGroupExist( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in group listing page." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 4, dataProvider = "sharedStudentData", groups = { "SMK-43459", "Groups", "UnassignedGroupTest" } )
    public void tcUnassignedGroupTest04( ITestContext context, String sharedStudentName ) throws Exception {

        Log.testCaseInfo( "SMK-10844 : Verify the groups listing page, when the custom group has shared student, active student and unassigned student." + "<small><b><i>[" + browser + "]</b></i></small>" );

        //Creating unassignedStudent
        String unassignedStudentDetails = createUnassignedStudent();
        String groupName = "UnassignedGroupAuto" + System.nanoTime();
        String unassignedStuddentName = SMUtils.getKeyValueFromResponse( unassignedStudentDetails, "data,userName" );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> studentNamesToCreateGroup = new ArrayList<>();
            studentNamesToCreateGroup.add( sharedStudentName );
            studentNamesToCreateGroup.add( unassignedStuddentName );

            for ( int studentCount = 1; studentCount <= 2; studentCount++ ) {
                studentNamesToCreateGroup.add( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ), "data,userName" ) );
            }
            groupsTab.createGroupWithSchoolStudents( groupName, studentNamesToCreateGroup, Constants.GroupUIConstants.GROUP_ALLGRADES );

            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();

            //Navigating to student and verifying unassigned group present or not.
            studentTab.clickviewStudentByEllipsis( unassignedStuddentName );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Newly created group present in student associated group", "Newly created group is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsTab.isGroupExist( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in group listing page." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 5, groups = { "SMK-43459", "Groups", "UnassignedGroupTest" } )
    public void tcUnassignedGroupTest05( ITestContext context ) throws Exception {

        Log.testCaseInfo( "SMK-10845 : Verify the groups listing page, when the active student teacher transferred to another organization." + "<small><b><i>[" + browser + "]</b></i></small>" );

        String groupName = "UnassignedGroupAuto" + System.nanoTime();
        String newTeacherName = "Transferd_School_Teacher" + System.nanoTime();
        String newStudentName = "Transferd_School_Student" + System.nanoTime();
        String newOrgName = "Automation_Transfer_Org";

        new SqlHelperOrganization().deleteOrganization( newOrgName );
        Integer newOrgId = new SqlHelperOrganization().createOrganization( newOrgName, newOrgName );
        Integer newTeacherID = new UserSqlHelper().createTeacher( newTeacherName, newTeacherName, newTeacherName, Constants.PASSWORD_HASH, DataSetup.organizationId );
        sessionCookie = new BaseAPITest().getJessionCookie( smUrl, newTeacherName, password );
        new BaseAPITest().createStudent( smUrl, sessionCookie, newStudentName, newStudentName, newStudentName, newStudentName, newTeacherID.toString(), DataSetup.organizationId.toString(), "5" );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( newTeacherName, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> studentNamesToCreateGroup = new ArrayList<>();
            studentNamesToCreateGroup.add( newStudentName );

            groupsTab.createGroup( groupName, studentNamesToCreateGroup );

            Log.assertThat( groupsTab.isGroupExist( groupName ), groupName + " Group name present in Group listing page.", groupName + " Group name not present in Group listing page." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Transferring teacher
            sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
            new BaseAPITest().transferUser( smUrl, sessionCookie, DataSetup.organizationId.toString(), newOrgId.toString(), "teacher", newTeacherID.toString() );
            new BaseAPITest().invalidateSession( smUrl, sessionCookie );

            smLoginPage.enterCredentialsAndLogIn( username, password );
            tHomePage.topNavBar.navigateToStudentsTab();
            groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( groupName, studentNamesToCreateGroup, Constants.GroupUIConstants.GROUP_ALLGRADES );

            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();

            //Navigating to student and verifying unassigned group present or not.
            studentTab.clickviewStudentByEllipsis( newStudentName );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Transferred teacher student group exist in group listing page. ", "Newly created group with unassigned student is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsTab.isGroupExist( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in group listing page." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            new SqlHelperOrganization().deleteOrganization( newOrgName );
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 6, groups = { "SMK-43459", "Groups", "UnassignedGroupTest" } )
    public void tcUnassignedGroupTest06( ITestContext context ) throws Exception {

        Log.testCaseInfo( "SMK-10846 : Verify the groups listing page, when the active student teacher deleted" + "<small><b><i>[" + browser + "]</b></i></small>" );

        String groupName = "UnassignedGroupAuto" + System.nanoTime();
        String newTeacherName = "Deleted_Teacher" + System.nanoTime();
        String newStudentName = "Deleted_Teacher_Student" + System.nanoTime();

        Integer newTeacherID = new UserSqlHelper().createTeacher( newTeacherName, newTeacherName, newTeacherName, Constants.PASSWORD_HASH, DataSetup.organizationId );
        sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
        new BaseAPITest().createStudent( smUrl, sessionCookie, newStudentName, newStudentName, newStudentName, newStudentName, newTeacherID.toString(), DataSetup.organizationId.toString(), "5" );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( newTeacherName, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> studentNamesToCreateGroup = new ArrayList<>();
            studentNamesToCreateGroup.add( newStudentName );

            groupsTab.createGroup( groupName, studentNamesToCreateGroup );

            Log.assertThat( groupsTab.isGroupExist( groupName ), groupName + " Group name present in Group listing page.", groupName + " Group name not present in Group listing page." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            SMUtils.logDescriptionTC( "SMK-10848 : Verify the groups listing page, when the shared student teacher has been deleted." );
            //Deleting teacher
            new UserSqlHelper().deleteTeacher( newTeacherName );

            smLoginPage.enterCredentialsAndLogIn( username, password );

            tHomePage.topNavBar.navigateToStudentsTab();
            groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithSchoolStudents( groupName, studentNamesToCreateGroup, Constants.GroupUIConstants.GROUP_ALLGRADES );

            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();

            //Navigating to student and verifying unassigned group present or not.
            studentTab.clickviewStudentByEllipsis( newStudentName );
            SMUtils.logDescriptionTC( "Verify the groups listing page, when the shared student teacher has been deleted" );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Deleted teacher student group exist in group listing page. ", "Newly created group with unassigned student is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsTab.isGroupExist( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in group listing page." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 7, groups = { "SMK-43459", "Groups", "UnassignedGroupTest" } )
    public void tcUnassignedGroupTest07( ITestContext context ) throws Exception {

        Log.testCaseInfo( "SMK-10850 : Verify the unassigned group not listed groups listing page in courses section" + "<small><b><i>[" + browser + "]</b></i></small>" );

        //Creating unassignedStudent
        String unassignedStudentDetails = createUnassignedStudent();
        String groupName = "UnassignedGroupAuto" + System.nanoTime();
        String unassignedStuddentName = SMUtils.getKeyValueFromResponse( unassignedStudentDetails, "data,userName" );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            List<String> studentNamesToCreateGroup = new ArrayList<>();
            studentNamesToCreateGroup.add( unassignedStuddentName );

            groupsTab.createGroupWithSchoolStudents( groupName, studentNamesToCreateGroup, Constants.GroupUIConstants.GROUP_ALLGRADES );

            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();

            studentTab.sortByUserID();
            studentTab.clickviewStudentByEllipsis( unassignedStuddentName );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Newly created group present in student associated group", "Newly created group is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsTab.isGroupExist( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in group listing page." );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            List<String> groupListFromAssignPopup = coursePage.getGroupListfromAssignementDetailsTable();
            coursePage.addCourseToGroups();

            String txtlegend = groupListFromAssignPopup.stream().filter( lbllegend -> lbllegend.trim().equals( Constants.GroupUIConstants.UNASSIGNED_GROUP ) ).findAny().orElse( null );
            if ( Objects.isNull( txtlegend ) ) {
                Log.pass( "Unassigned group is not displayed in assignment popup." );
            } else {
                Log.fail( "Unassigned group is displayed in assignment popup." );
            }
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 8, groups = { "SMK-43459", "Groups", "UnassignedGroupTest" } )
    public void tcUnassignedGroupTest08( ITestContext context ) throws Exception {

        Log.testCaseInfo( "SMK-10849 : Verify the unassigned group not listed groups listing page in assignment section" + "<small><b><i>[" + browser + "]</b></i></small>" );

        //Creating unassignedStudent
        String unassignedStudentDetails = createUnassignedStudent();
        String groupName = "UnassignedGroupAuto" + System.nanoTime();
        String unassignedStuddentName = SMUtils.getKeyValueFromResponse( unassignedStudentDetails, "data,userName" );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            List<String> studentNamesToCreateGroup = new ArrayList<>();
            studentNamesToCreateGroup.add( unassignedStuddentName );

            groupsTab.createGroupWithSchoolStudents( groupName, studentNamesToCreateGroup, Constants.GroupUIConstants.GROUP_ALLGRADES );

            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();

            studentTab.sortByUserID();
            studentTab.clickviewStudentByEllipsis( unassignedStuddentName );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Newly created group present in student associated group", "Newly created group is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsTab.isGroupExist( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in group listing page." );

            AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetilsPage = assignmentPage.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            assignmentDetilsPage.clickAssignButton();
            List<String> groupListFromAssignPopup = assignmentDetilsPage.getStudentListfromAssignementDetailsTable();

            String txtlegend = groupListFromAssignPopup.stream().filter( lbllegend -> lbllegend.trim().equals( Constants.GroupUIConstants.UNASSIGNED_GROUP ) ).findAny().orElse( null );
            if ( Objects.isNull( txtlegend ) ) {
                Log.pass( "Unassigned group is not displayed in assignment popup." );
            } else {
                Log.fail( "Unassigned group is displayed in assignment popup." );
            }

            Log.message( groupListFromAssignPopup.toString() );
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 9, groups = { "SMK-43459", "Groups", "UnassignedGroupTest" } )
    public void tcUnassignedGroupTest09( ITestContext context ) throws Exception {

        Log.testCaseInfo( "SMK-10852 : Verify the unassigned group not listed groups listing page in Students Listing ( Add Students to Group ) section" + "<small><b><i>[" + browser + "]</b></i></small>" );

        //Creating unassignedStudent
        String unassignedStudentDetails = createUnassignedStudent();
        String groupName = "UnassignedGroupAuto" + System.nanoTime();
        String unassignedStuddentName = SMUtils.getKeyValueFromResponse( unassignedStudentDetails, "data,userName" );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            List<String> studentNamesToCreateGroup = new ArrayList<>();
            studentNamesToCreateGroup.add( unassignedStuddentName );

            groupsTab.createGroupWithSchoolStudents( groupName, studentNamesToCreateGroup, Constants.GroupUIConstants.GROUP_ALLGRADES );

            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();

            studentTab.sortByUserID();
            studentTab.clickviewStudentByEllipsis( unassignedStuddentName );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Newly created group present in student associated group", "Newly created group is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsTab.isGroupExist( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in group listing page." );

            tHomePage.topNavBar.navigateToStudentsTab();
            studentTab.selectAllStudents();
            studentTab.clickGroupButtoninStudentLisitngPage();
            List<String> groupsListFromPopup = studentTab.getListOfGroupName();
            String txtlegend = groupsListFromPopup.stream().filter( lbllegend -> lbllegend.trim().equals( Constants.GroupUIConstants.UNASSIGNED_GROUP ) ).findAny().orElse( null );
            if ( Objects.isNull( txtlegend ) ) {
                Log.pass( "Unassigned group is not displayed in assignment popup." );
            } else {
                Log.fail( "Unassigned group is displayed in assignment popup." );
            }

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 10, groups = { "SMK-43459", "Groups", "UnassignedGroupTest" } )
    public void tcUnassignedGroupTest10( ITestContext context ) throws Exception {

        Log.testCaseInfo( "SMK-10847 : Verify the groups listing page, when the unassigned student mapped with teacher" + "<small><b><i>[" + browser + "]</b></i></small>" );

        //Creating unassignedStudent
        String unassignedStudentDetails = createUnassignedStudent();
        String groupName = "UnassignedGroupAuto" + System.nanoTime();
        String unassignedStuddentName = SMUtils.getKeyValueFromResponse( unassignedStudentDetails, "data,userName" );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
        	LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            List<String> studentNamesToCreateGroup = new ArrayList<>();
            studentNamesToCreateGroup.add( unassignedStuddentName );

            groupsTab.createGroupWithSchoolStudents( groupName, studentNamesToCreateGroup, Constants.GroupUIConstants.GROUP_ALLGRADES );

            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();

            studentTab.sortByUserID();
            studentTab.clickviewStudentByEllipsis( unassignedStuddentName );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Newly created group present in student associated group", "Newly created group is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsTab.isGroupExist( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in group listing page." );

            //Mapping unassigned student to teacher
            new BaseAPITest().updateStudent( smUrl, sessionCookie, unassignedStuddentName, unassignedStuddentName, unassignedStuddentName, unassignedStuddentName, SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ),
                    DataSetup.organizationId.toString(), "5", SMUtils.getKeyValueFromResponse( unassignedStudentDetails, "data,personId" ) );

            tHomePage.topNavBar.navigateToStudentsTab();
            studentTab.sortByUserID();
            studentTab.clickviewStudentByEllipsis( unassignedStuddentName );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Newly created group present in student associated group", "Newly created group is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * Data provider to give the shared student data
     *
     * @return
     * @throws Exception
     */
    @DataProvider ( name = "sharedStudentData" )
    public Object[][] sharedStudentData() throws Exception {

        String teacher2Details = DataSetup.teacherDetailsMap.get( "Teacher49" );
        String teacher2Id = SMUtils.getKeyValueFromResponse( teacher2Details, "data,personId" );

        String studentName = "Student_Shared_" + System.nanoTime();
        sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
        new BaseAPITest().createStudent( smUrl, sessionCookie, studentName, studentName, studentName, studentName, teacher2Id, DataSetup.organizationId.toString(), "5" );

        Object[][] inputData = { { studentName } };
        return inputData;

    }

    private String createUnassignedStudent() throws Exception {

        String studentName = "Student_Unassigned_" + System.nanoTime();
        String unassignedStudentDetails = null;
        try {
            sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
            String newStudentID = new BaseAPITest().createStudent( smUrl, sessionCookie, studentName, studentName, studentName, studentName, "1", DataSetup.organizationId.toString(), "5" );
            unassignedStudentDetails = new BaseAPITest().getUserDetails( smUrl, sessionCookie, "student", newStudentID );
            new BaseAPITest().invalidateSession( smUrl, sessionCookie );
        } catch ( Exception e ) {
            Log.exception( e );
        }
        return unassignedStudentDetails;
    }

}
