package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForGivenTeacherConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;
import LSTFAI.customfactories.EventFiringWebDriver;

public class UpdateMathExitDataAPI  {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String assignmentID;
    private String assignmentUserId;
    RBSUtils rbsutils = new RBSUtils();
    private String studentDetail;
    private String studentUserID;
    private String studentUsername;
    private String stuFName;
    private String stuLName;
    private String mathSessionId;
    private String courseName;
    Map<String, String> MathExitDataResponse = new HashMap<>();
    Map<String, String> assignmentResponse = new HashMap<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID_HEADER );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        stuFName = SMUtils.getKeyValueFromResponse( studentDetail, "firstName" ).toString();
        stuLName = SMUtils.getKeyValueFromResponse( studentDetail, "lastName" ).toString();
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( priority = 1, dataProvider = "tcPostiveforMathExitDataAPI", groups = { "SMK-52003", "smoke_test_case", "P1", "API" } )
    public void tcPostiveforMathExitDataAPI( String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( description );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        try {

            HashMap<String, String> assignmentDetails = new HashMap<>();
            HashMap<String, String> groupdetails = new HashMap<>();
            List<String> studentRumbaIds = new ArrayList<>();
            studentRumbaIds.add( studentUserID );
            String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

            groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
            groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
            new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );

            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
            assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );

            switch ( scenario ) {

                case "Default Math":
                    courseName = Constants.MATH;
                    assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                    break;
                default:
                    Log.message( "Case is invalid" );
                    break;
            }

            assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
            Log.message( "assignmentResponse=" + assignmentResponse );
            assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
            assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
            Log.message( "assignmentUserId =" + assignmentUserId );

            selectCourse( driver, studentUsername, courseName );
            SMUtils.nap( 10 );

            String SessionId = SqlHelperAssignment.getSessionId( assignmentUserId );
            Log.message( "SessionId : " + SessionId );

            String Accesstoken = new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            HashMap<String, String> header = new HashMap<>();
            header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            header.put( Constants.AUTHORIZATION, "Bearer " + Accesstoken );
            header.put( Constants.USERID_SM_HEADER, studentUserID );
            header.put( Constants.ORGID_SM_HEADER, orgId );
            header.put( Constants.SESSIONID_HEADER, SessionId );

            HashMap<String, String> studentDetails = new HashMap<>();
            studentDetails.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId );

            Map<String, String> SessionData = sessionStartTime( smUrl, header, studentDetails );
            Log.message( "Session Data :" + SessionData );

            mathSessionId = getMathSessionHistoryId( assignmentUserId );
            Log.message( "MathSessionId :" + mathSessionId );

            studentDetails.put( Constants.FIRSTNAME, stuFName );
            studentDetails.put( Constants.LASTNAME, stuLName );
            studentDetails.put( AssignmentAPIConstants.SESSION_ID, mathSessionId );
            
            MathExitDataResponse = new AssignmentAPI().UpdateMathExitData( smUrl, header, studentDetails );
            Log.message( "Status code: " + MathExitDataResponse.get( Constants.STATUS_CODE ) );
            Log.message( "MathExitDataResponse = " + MathExitDataResponse );
            Log.softAssertThat( MathExitDataResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + MathExitDataResponse.get( Constants.STATUS_CODE ),
                    "Status code is not returned as expected and the same is " + statusCode + " Actual - " + MathExitDataResponse.get( Constants.STATUS_CODE ) );
            Log.assertThat( getDataFromDB( assignmentUserId, "1", "1" ), "DB validation is successfull!!!", "DB validation is not successfull" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public Map<String, String> sessionStartTime( String url, HashMap<String, String> header, HashMap<String, String> path ) throws Exception {
        String endPoint = StudentDetailsForGivenTeacherConstants.SESSION_START_TIME;
        endPoint = endPoint.replace( Constants.ASSIGNMENT_USER_ID_VALUE, path.get( Constants.ASSIGNMENT_USER_ID ) );
        endPoint = endPoint + "?courseStartTime=" + System.nanoTime();
        Log.message( "endpoint is : " + endPoint );
        String payload = null;
        return RestHttpClientUtil.PUT( url, header, new HashMap<>(), endPoint, payload );
    }

    /**
     * Data provider to give the positive data
     *
     * @return
     */
    @DataProvider ( name = "tcPostiveforMathExitDataAPI" )
    public Object[][] tcPostiveforMathExitDataAPI() {
        Object[][] inputData = { { "Verify the valid response to Default Math", "Default Math", CommonAPIConstants.STATUS_CODE_OK }, };
        return inputData;
    }

    /**
     * This method is used to select the course based on courseName.
     * 
     * @param studentUserName
     * @param courseName
     */
    private void selectCourse( WebDriver driver, String studentUserName, String courseName ) throws IOException {
        Log.message( "Student username :" + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        SMUtils.nap( 30 );
        StudentDashboardPage studentPage = new StudentDashboardPage( driver );
        studentPage.selectAssignmentByName( courseName );
    }

    /**
     * This method is used to get math-session-history-id of a student.
     * 
     * @param assignmentUserID
     */
    private String getMathSessionHistoryId( String assignmentUserID ) {
        String mathSessioID = null;
        String queryString = "select math_session_history_id from school.math_session_history where assignment_user_id=" + assignmentUserID + "";
        List<Object[]> listItems = SQLUtil.executeQuery( queryString );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            if ( list.length > 0 ) {
                arrList.add( list[0].toString() );
            }
        }
        mathSessioID = arrList.get( 0 );
        return mathSessioID;
    }

    private boolean getDataFromDB( String assignemntUseId, String totalAttempt, String totalCorrect ) {
        String path = "select total_correct, total_attempts from math_assignment_history where assignment_user_id = " + assignemntUseId;
        List<Object[]> listItems = SQLUtil.executeQuery( path );
        List<String> arrList = new ArrayList<String>();
        for ( Object[] list : listItems ) {
            arrList.add( list[0].toString() );
            arrList.add( list[1].toString() );
        }
        Log.message( arrList + "" );
        return arrList.equals( Arrays.asList( totalCorrect, totalAttempt ) );
    }
}