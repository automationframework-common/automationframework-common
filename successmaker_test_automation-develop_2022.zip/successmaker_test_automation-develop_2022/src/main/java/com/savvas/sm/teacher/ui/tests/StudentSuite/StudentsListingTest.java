package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.StopWatch;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Groups;
import com.savvas.sm.common.utils.Constants.Students;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.GetGroupListAPI;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.ReturnStudentListAPI;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

public class StudentsListingTest extends BaseTest {

    // Initializing the object
    StudentsPage StudentsPageObject;
    SMUtils SMUtilsObject = new SMUtils();

    private String teacherId;
    private String orgId;
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    List<String> studentIdList = null;
    List<String> studentUserNames = null;
    List<String> teacherGroupNames = new ArrayList<>();
    List<String> teacherGroupId = new ArrayList<>();
    private long startTime;

    GroupAPI groupApi = new GroupAPI();
    private AtomicReference<String> schoolUsed = new AtomicReference<>();

    @BeforeClass
    public void initTest( ITestContext context ) {
        startTime = StopWatch.startTime();
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        orgId = RBSDataSetup.organizationIDs.get( schoolUsed.get() );
        String teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        ArrayList<String> studentDetails = new ArrayList<>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );

        studentIdList = new ArrayList<>();
        studentUserNames = new ArrayList<>();

        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUserNames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

        // Getting GroupId of the Teacher
        HashMap<String, String> response = new HashMap<>();
        HashMap<String, String> apiDetails = new HashMap<>();
        try {
            String accessToken = new RBSUtils().getAccessToken( username, password );
            apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
            apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            apiDetails.put( GroupConstants.STAFF_ID, teacherId );
            response = groupApi.getGroupListingForTeacherID( smUrl, apiDetails );
            Log.message( "GroupListing respone: " + response.toString() );

            JSONObject jsonObject = new JSONObject( response.get( Constants.REPORT_BODY ) );
            JSONArray array = jsonObject.getJSONArray( CreateGroupAPIConstants.DATA );

            IntStream.range( 0, array.length() ).forEach( iter -> {
                String eachObject = array.getJSONObject( iter ).toString();
                teacherGroupNames.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_NAME ) );
                teacherGroupId.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_ID ) );
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    @AfterClass
    public void enofExecution() {
        long totalTime = StopWatch.elapsedTime( startTime );
        long sec = totalTime % 60;
        long min = ( totalTime / 60 );
        Log.message( " Student Listing class ran for: " + min + ":" + sec );
    }

    @Test ( description = "Verify student details are corectly or not ", priority = 8, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_001() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        try {

            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, false );
            StudentsPage StudentsPageObject = tHomePage.topNavBar.navigateToStudentsTab();
            GroupPage groupPage = new GroupPage( driver );
            // Verifying column header
            SMUtils.logDescriptionTC( "SMK-10126:Verify the header details are displayed correctly in application" );
            StudentsPageObject.verifyHeaders();

            String FirstName = "StudentFirstName" + System.nanoTime();
            String LastName = "StudentLastName" + System.nanoTime();
            String userName = "StudentUserName" + System.nanoTime();
            String Grade = "Grade 5";
            String studentId = "StudentId223" + System.nanoTime();

            userName = userName.toLowerCase();

            HashMap<String, String> studentDetails = new HashMap<>();
            studentDetails.put( Students.COLUMN_FIRST_NAME, FirstName );
            studentDetails.put( Students.COLUMN_LAST_NAME, LastName );
            studentDetails.put( Students.COLUMN_USER_NAME, userName );
            studentDetails.put( Students.COLUMN_GRADE, Grade );
            studentDetails.put( Students.COLUMN_STUDNET_ID, studentId );
            studentDetails.put( Constants.PASSWORD_TEXT, RBSDataSetupConstants.DEFAULT_PASSWORD );

            StudentsPageObject.createStudentWithMandatoryField( studentDetails );

            addStudentToGroup( userName );
            tHomePage.topNavBar.navigateToGroupsTab();
            tHomePage.topNavBar.navigateToStudentsTab();

            HashMap<String, String> studentDetailsForUsername = StudentsPageObject.getStudentDetailsForUsername( userName );

            SMUtils.logDescriptionTC( "SMK-10123:Verify the student details are displyed correctly" );
            SMUtils.logDescriptionTC( "Verify the teacher can see only the students in student listing page." );

            Log.assertThat( StudentsPageObject.getStudentDetailsForUsername( userName ).get( Students.COLUMN_FIRST_NAME ).equals( FirstName ), "First Name matches", "First Name doesnot matches" );
            Log.assertThat( StudentsPageObject.getStudentDetailsForUsername( userName ).get( Students.COLUMN_LAST_NAME ).equals( LastName ), "Last Name matches", "Last Name doesnot matches" );
            Log.assertThat( StudentsPageObject.getStudentDetailsForUsername( userName ).get( Students.COLUMN_STUDNET_ID ).equals( studentId ), "StudentID with special characters matches", "StudentID with special characters doesnot matches" );
            Log.assertThat( StudentsPageObject.getStudentDetailsForUsername( userName ).get( Students.COLUMN_GRADE ).equals( Grade ), "Grade matches", "Grade matches doesnot matches" );

            studentDetails.clear();

            SMUtils.logDescriptionTC( "SMK-10162:Verify the color code of Add New Student button" );
            Log.assertThat( SMUtils.checkBackgroundColor( StudentsPageObject.addStudentElement(), Groups.CREATE_A_GROUP_COLOR ), "Add New Student button color matches", "Add New Student button color doesnot matches" );

            // Adding FistName and Last name with apostrophe
            SMUtils.logDescriptionTC( "SMK-10155:Verify the firstname with apostrophes should be displayed properly" );
            SMUtils.logDescriptionTC( "SMK-10156:Verify the lastname with apostrophes should be displayed properly" );
            FirstName = "Student'Name" + System.nanoTime();
            LastName = "Student'Name" + System.nanoTime();
            userName = "StudentUserName" + System.nanoTime();
            userName = userName.toLowerCase();
            Grade = "Grade 1";
            studentId = "StudentId223" + System.nanoTime();
            userName = userName.toLowerCase();
            studentDetails.put( Students.COLUMN_FIRST_NAME, FirstName );
            studentDetails.put( Students.COLUMN_LAST_NAME, LastName );
            studentDetails.put( Students.COLUMN_USER_NAME, userName );
            studentDetails.put( Students.COLUMN_GRADE, Grade );
            studentDetails.put( Students.COLUMN_STUDNET_ID, studentId );
            studentDetails.put( Constants.PASSWORD_TEXT, RBSDataSetupConstants.DEFAULT_PASSWORD );

            StudentsPageObject.createStudentWithMandatoryField( studentDetails );
            addStudentToGroup( userName );
            tHomePage.topNavBar.navigateToGroupsTab();
            tHomePage.topNavBar.navigateToStudentsTab();

            Log.assertThat( StudentsPageObject.getStudentDetailsForUsername( userName ).get( Students.COLUMN_FIRST_NAME ).equals( FirstName ), "First Name with Aspotrophe matches", "First Name with Aspotrophe doesnot matches" );
            Log.assertThat( StudentsPageObject.getStudentDetailsForUsername( userName ).get( Students.COLUMN_LAST_NAME ).equals( LastName ), "Last Name with Aspotrophe matches", "Last Name with Aspotrophe doesnot matches" );

            // Verifying with Special characters
            SMUtils.logDescriptionTC( "SMK-10166:Verify whether the firstname / lastname / username fields are displaying special characters properly" );
            FirstName = "Student$" + System.nanoTime();
            LastName = "Student$%" + System.nanoTime();
            userName = "Student$" + System.nanoTime();
            userName = userName.toLowerCase();
            Grade = "Grade 5";
            studentId = "StudentId22$" + System.nanoTime();

            userName = userName.toLowerCase();
            studentDetails.put( Students.COLUMN_FIRST_NAME, FirstName );
            studentDetails.put( Students.COLUMN_LAST_NAME, LastName );
            studentDetails.put( Students.COLUMN_USER_NAME, userName );
            studentDetails.put( Students.COLUMN_GRADE, Grade );
            studentDetails.put( Students.COLUMN_STUDNET_ID, studentId );
            studentDetails.put( Constants.PASSWORD_TEXT, RBSDataSetupConstants.DEFAULT_PASSWORD );

            StudentsPageObject.createStudentWithMandatoryField( studentDetails );
            addStudentToGroup( userName );
            tHomePage.topNavBar.navigateToGroupsTab();
            tHomePage.topNavBar.navigateToStudentsTab();

            Log.assertThat( StudentsPageObject.getStudentDetailsForUsername( userName ).get( Students.COLUMN_FIRST_NAME ).equals( FirstName ), "UserName with special characters Name matches", "UserName with special characters doesnot matches" );
            Log.assertThat( StudentsPageObject.getStudentDetailsForUsername( userName ).get( Students.COLUMN_LAST_NAME ).equals( LastName ), "Last Name with special characters matches", "Last Name with special characters doesnot matches" );
            Log.assertThat( StudentsPageObject.getStudentDetailsForUsername( userName ).get( Students.COLUMN_STUDNET_ID ).equals( studentId ), "StudentID with special characters matches", "StudentID with special characters doesnot matches" );

            // SignOut from SM   c
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student Listing Check Box", priority = 2, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_002() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {
            StudentsPageObject = new StudentsPage( driver );

            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, false );
            StudentsPage StudentsTab = tHomePage.topNavBar.navigateToStudentsTab();

            // Group and assignment button disabled state
            SMUtils.logDescriptionTC( "SMK-10129:Verify the Group button when the students not selected in a page" );
            SMUtils.logDescriptionTC( "SMK-10130:Verify the Assignment button when the students not selected in a page" );

            Log.assertThat( SMUtils.getOuterHTML( StudentsTab.getGroupButton() ).contains( "disabled" ), "The group button is in disabled state!", "The group button is not in disabled state" );
            Log.assertThat( SMUtils.getOuterHTML( StudentsTab.getAssignmentButton() ).contains( "disabled" ), "The Assignment button is in disabled state!", "The Assignment button is not in disabled state" );

            //Select all option
            SMUtils.logDescriptionTC( "SMK-10133:Verify the Select All option in application" );
            StudentsTab.selectAllStudents();
            Log.assertThat( StudentsTab.returnCheckedStudentIds().size() == StudentsTab.getStudentIds().size(), "All the student has been checked!", "All the student not  checked" );

            // Deselect all options
            SMUtils.logDescriptionTC( "SMK-10134:Verify the Deselect All Option in application" );
            StudentsTab.selectAllStudents();
            Log.assertThat( StudentsTab.returnCheckedStudentIds().isEmpty(), "All the student has been deselected!", "All the student has not been deselected" );

            // top check box
            SMUtils.logDescriptionTC( "SMK-10174:Verify the select all option, when the studets selected partially" );
            studentUserNames.subList( 0, studentUserNames.size() / 2 ).forEach( studentId -> {
                StudentsTab.selectStudentByUsername( studentId.toLowerCase() );
            } );
            StudentsTab.selectAllStudents();
            Log.assertThat( StudentsTab.returnCheckedStudentIds().isEmpty(), "All the student has been deselected!", "All the student has not been deselected" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify ZeroState message and link buttons in Student listing page ", priority = 3, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_003() throws Exception {

        //teacher create
        String teacherUsernameCreate = "teacher1654490575327" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        String teacherdetailsCreate = null;
        String teacherIdCreate = null;
        try {
            if ( !new RBSUtils().isUserExits( teacherUsernameCreate, orgId ) ) {
                teacherdetailsCreate = new UserAPI().createUserWithCustomization( teacherUsernameCreate, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
            }
            teacherIdCreate = new RBSUtils().getUserIDByUserName( teacherUsernameCreate );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            StudentsPageObject = new StudentsPage( driver );

            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( teacherUsernameCreate, password, false );
            StudentsPage StudentsTab = tHomePage.topNavBar.navigateToStudentsTab();

            SMUtils.logDescriptionTC( "SMK-10124: Verify the Zero State Page are displyed correctly when none of the students get assigned under Teacher" );
            SMUtils.logDescriptionTC( "SMK-10125:Verify the Zero State page is displaying the message properly" );

            StudentsPageObject.verifyZeroState();

            SMUtils.logDescriptionTC( "SMK-10159: Verify the Add Student in zero state message" );
            StudentsPageObject.clickAddStudentinZeroState();
            String expectedMessage = StudentsPageObject.getAddStudentText();
            Log.assertThat( expectedMessage.equals( "Add Student" ), "Popup is loaded!", "Popup is not loaded getting message as " + expectedMessage );
            StudentsPageObject.clickCancelStudentCreation();

            SMUtils.logDescriptionTC( "SMK-10128:: Verify the Add Student feature in Button" );
            StudentsPageObject.clickAddStudent();
            String expectedMessage1 = StudentsPageObject.getAddStudentText();
            Log.assertThat( expectedMessage1.equals( "Add Student" ), "Popup is loaded!", "Popup is not loaded getting message as " + expectedMessage1 );
            StudentsPageObject.clickCancelStudentCreation();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verification buttons and functionality in Student List grid", priority = 4, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_004() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        try {
            StudentsPageObject = new StudentsPage( driver );

            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, false );
            StudentsPage StudentsTab = tHomePage.topNavBar.navigateToStudentsTab();

            //Create one Student and verify on the UI
            SMUtils.logDescriptionTC( "SMK-10128: Verify the Add Student feature in application" );
            String studentID = StudentsPageObject.createStudent();
            StudentsPageObject.clickCloseButton();

            addStudentToGroup( studentID );
            tHomePage.topNavBar.navigateToGroupsTab();
            tHomePage.topNavBar.navigateToStudentsTab();
            Log.assertThat( StudentsPageObject.isStudentPresent( studentID ), "Created student is present on the UI!", "The Student creates is not present on the UI Received Studnet Id is " + studentID );

            SMUtils.logDescriptionTC( "SMK-10131: Verify the Group button when the students are selected in a page" );
            StudentsPageObject.selectAllStudents();
            StudentsPageObject.clickGroupButtoninStudentLisitngPage();
            Log.assertThat( Constants.Students.POPUP_HEADER_GROUP.equals( StudentsPageObject.getTextofHeaderPopup() ), "Groups Popup opens successfully!",
                    "Popup title is not machting expected[" + Constants.Students.POPUP_HEADER_GROUP + "] actual[" + StudentsPageObject.getTextofHeaderPopup() + "]" );
            StudentsPageObject.closePopup();

            SMUtils.logDescriptionTC( "SMK-10130: Verify the Assignment button when the students are selected in a page" );
            StudentsPageObject.clickAssignmentButton();
            Log.assertThat( Constants.Students.POPUP_HEADER_ASSIGNMENT.equals( StudentsPageObject.getTextofHeaderPopup() ), "Assignments Popup opens successfully!",
                    "Popup title is not machting expected[" + Constants.Students.POPUP_HEADER_ASSIGNMENT + "] actual[" + StudentsPageObject.getTextofHeaderPopup() + "]" );
            StudentsPageObject.closePopup();

            SMUtils.logDescriptionTC( "SMK-10150:: Verify the elipses menu and validate the options" );
            HashMap<String, List<String>> studentsList = StudentsPageObject.getColumnDetailsAsList();
            String studentId = studentsList.get( Constants.USER_NAME ).get( 0 );
            List<String> expEllipsesOptions = new ArrayList<>();
            expEllipsesOptions.add( Constants.Students.VIEW_STUDENTS );
            expEllipsesOptions.add( Constants.Students.ADD_STUDENTS_TO_GROUPS );
            expEllipsesOptions.add( Constants.Students.ADD_STUDENTS_TO_ASSIGNMENTS );

            List<String> actualEllipsesOptions = new ArrayList<>();
            actualEllipsesOptions = StudentsPageObject.getTextOfEllipsesOptions( studentId );

            Collections.sort( actualEllipsesOptions );
            Collections.sort( expEllipsesOptions );
            Log.assertThat( expEllipsesOptions.equals( actualEllipsesOptions ), "Ellipses options are Matching!", "Ellipses values are not matching Expected" + expEllipsesOptions + " but Actual" + actualEllipsesOptions );

            StudentsPageObject.clickviewStudentByEllipsis( studentId );
            Log.assertThat( StudentsPageObject.getGroupContainerHeader().equals( "Groups" ), "Clicking view students works correclty", "Clicking view students Not works correclty" );
            Log.endTestCase();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Same Student cannot be added into Assignment and Groups", priority = 5, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_005() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        try {

            StudentsPageObject = new StudentsPage( driver );

            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, false );
            StudentsPage StudentsTab = tHomePage.topNavBar.navigateToStudentsTab();

            // student for assignemetn
            String StudentToTest = StudentsTab.createStudent();
            StudentsTab.clickCloseButton();

            SMUtils.logDescriptionTC( "SMK-10153 : Verify the Add Student to Group functionality in application" );
            String groupName = "Group " + System.nanoTime();
            addStudentToGroup( StudentToTest );

            CoursesPage tCoursesPage = tHomePage.navigateToCourseListingPage();
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            List<String> DefaultCourseNames = tCoursesPage.getDefaultCoursesNameFromCoursesWidget();

            // Click on Assign Button for Math course
            AssignAssignmentPopup popup = tCoursesPage.assignDefaultCourseFromCoursesWidget( DefaultCourseNames.get( 0 ) );

            // Click on Students Radio button
            popup.radioButtonSelectAssignWidget( Constants.STUDENTS );

            // Add a Student
            popup.addStudentsToChipBox( Arrays.asList( StudentToTest ) );
            popup.assign();

            tHomePage.navigateToStudentTab();

            SMUtils.logDescriptionTC( "SMK-10152 : Verify the clicking view Student button will opens the Student Container" );
            StudentsPageObject.clickviewStudentByEllipsis( StudentToTest );
            StudentsPageObject.clickBackBtninContaniner();

            SMUtils.logDescriptionTC( "SMK-10168 : Verify whether the same student will be added in same group" );
            StudentsPageObject.selectStudentByUsername( StudentToTest.toLowerCase() );
            StudentsPageObject.clickGroupButtoninStudentLisitngPage();

            Log.assertThat( !StudentsPageObject.isGroupPresentOnPopup( groupName ), "Same Group  is not listed on the Popup after assigned into same Student!", "Failed! The Group names is listed on the Popup" );
            StudentsPageObject.closePopup();

            SMUtils.logDescriptionTC( "SMK-10154 : Verify the Add Student to Assignment functionality in application" );

            SMUtils.logDescriptionTC( "SMK-10169 : Verify whether the same student will be assigned to the existing assignment" );
            StudentsPageObject.clickAssignmentButton();
            boolean isAvailable = StudentsPageObject.isAssignmentPresentOnPopup( DefaultCourseNames.get( 0 ) );
            Log.assertThat( !isAvailable, "Same Assignment  is not listed on the Popup after assigned into same Student!", "The Assignment is listed on the Popup" );
            StudentsPageObject.closePopup();
            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verification of student Listing Grid soriting - ASCENDING ", priority = 6, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_006() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        try {
            StudentsPageObject = new StudentsPage( driver );

            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, false );
            StudentsPage StudentsTab = tHomePage.topNavBar.navigateToStudentsTab();

            SMUtils.logDescriptionTC( "SMK-10135:Verify the default order in student listing page" );
            Log.assertThat( StudentsPageObject.getColumnNameOfArrow().equals( Students.COLUMN_FIRST_NAME ), "The default column sorting is Matching", "The Default column sorting is not in Fist Name column" );
            Log.assertThat( StudentsPageObject.getArrowStateOfColumn().equals( Constants.ASCENDING ), "Default Sorting is in Ascending order", "Default Sorting is not in Ascending order" );

            // Adding one student
            SMUtils.logDescriptionTC( "SMK-10127:Verify the order sequence, when the New Student has been added under the teacher" );
            String studentName = StudentsTab.createStudent();
            addStudentToGroup( studentName );

            //Last Name Column
            SMUtils.logDescriptionTC( "SMK-10138:Verify the ascending order functionality in last name" );
            List<String> columnValues = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_LAST_NAME );
            StudentsPageObject.clickColumnnAndSort( Students.COLUMN_LAST_NAME, Constants.ASCENDING );
            List<String> actualList = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_LAST_NAME );
            Log.assertThat( SMUtils.sortAndCompareList( actualList, columnValues, Constants.ASCENDING ), "Last Name Ascending order is matching",
                    "ASCENDING Ascending order is not matching \n Actual: " + actualList.toString() + "\n Expected: " + columnValues.toString() );

            //First Name Column
            SMUtils.logDescriptionTC( "SMK-10136:Verify the ascending order functionality in first name" );
            columnValues = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_FIRST_NAME );
            StudentsPageObject.clickColumnnAndSort( Students.COLUMN_FIRST_NAME, Constants.ASCENDING );
            actualList = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_FIRST_NAME );
            Log.assertThat( SMUtils.sortAndCompareList( actualList, columnValues, Constants.ASCENDING ), "First Name Ascending order is matching",
                    "ASCENDING Ascending order is not matching \n Actual: " + actualList.toString() + "\n Expected: " + columnValues.toString() );

            //User Name Column
            SMUtils.logDescriptionTC( "SMK-10140:Verify the ascending order functionality in user name" );
            columnValues = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_USER_NAME );
            StudentsPageObject.clickColumnnAndSort( Students.COLUMN_USER_NAME, Constants.ASCENDING );
            actualList = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_USER_NAME );
            Log.assertThat( SMUtils.sortAndCompareList( actualList, columnValues, Constants.ASCENDING ), "USER_NAME Ascending order is matching",
                    "ASCENDING Ascending order is not matching \n Actual: " + actualList.toString() + "\n Expected: " + columnValues.toString() );

            //Student ID Column
            SMUtils.logDescriptionTC( "SMK-10142:Verify the ascending order for student ID in application" );
            columnValues = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_STUDNET_ID );
            columnValues = columnValues.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            StudentsPageObject.clickColumnnAndSort( Students.COLUMN_STUDNET_ID, Constants.ASCENDING );
            actualList = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_STUDNET_ID );
            actualList = actualList.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            Log.assertThat( SMUtils.sortAndCompareList( actualList, columnValues, Constants.ASCENDING ), "ASCENDING Ascending order is matching",
                    "ASCENDING Ascending order is not matching \n Actual: " + actualList.toString() + "\n Expected: " + columnValues.toString() );

            //Grade Column
            SMUtils.logDescriptionTC( "SMK-10144:Verify the Ascending order for Grade in application" );
            columnValues = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_GRADE );
            columnValues = columnValues.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            StudentsPageObject.clickColumnnAndSort( Students.COLUMN_GRADE, Constants.ASCENDING );
            actualList = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_GRADE );
            actualList = actualList.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            Log.assertThat( gradeSortingMatches( actualList, columnValues, Constants.DESCENDING ), "COLUMN_GRADE Ascending order is matching",
                    "ASCENDING Ascending order is not matching \n Actual: " + actualList.toString() + "\n Expected: " + columnValues.toString() );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verification of student Listing Grid soriting - DESCENDING ", priority = 7, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_007() throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {
    		StudentsPageObject = new StudentsPage( driver );

            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, false );
            StudentsPage StudentsTab = tHomePage.topNavBar.navigateToStudentsTab();

            //Last Name Column
            SMUtils.logDescriptionTC( "SMK-10139:Verify the descending order functionality in last name" );
            List<String> columnValues = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_LAST_NAME );
            StudentsPageObject.clickColumnnAndSort( Students.COLUMN_LAST_NAME, Constants.DESCENDING );
            List<String> actualList = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_LAST_NAME );
            Log.assertThat( SMUtils.sortAndCompareList( actualList, columnValues, Constants.DESCENDING ), "Last Name DESCENDING order is matching",
                    "Last Name DESCENDING  is not matching \n Actual: " + actualList.toString() + "\n Expected: " + columnValues.toString() );

            //First Name Column
            SMUtils.logDescriptionTC( "SMK-10137:Verify the descending order functionality in first name" );
            columnValues = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_FIRST_NAME );
            StudentsPageObject.clickColumnnAndSort( Students.COLUMN_FIRST_NAME, Constants.DESCENDING );
            actualList = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_FIRST_NAME );
            Log.assertThat( SMUtils.sortAndCompareList( actualList, columnValues, Constants.DESCENDING ), "First Name DESCENDING order is matching",
                    "First Name DESCENDING  is not matching \n Actual: " + actualList.toString() + "\n Expected: " + columnValues.toString() );

            //User Name Column
            SMUtils.logDescriptionTC( "SMK-10141:Verify the descending order functionality in user name" );
            columnValues = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_USER_NAME );
            StudentsPageObject.clickColumnnAndSort( Students.COLUMN_USER_NAME, Constants.DESCENDING );
            actualList = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_USER_NAME );
            Log.assertThat( SMUtils.sortAndCompareList( actualList, columnValues, Constants.DESCENDING ), "DESCENDING Ascending order is matching",
                    "DESCENDING  is not matching \n Actual: " + actualList.toString() + "\n Expected: " + columnValues.toString() );

            //Student ID Column
            SMUtils.logDescriptionTC( "SMK-10143:Verify the descending order for student ID in application" );
            columnValues = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_STUDNET_ID );
            columnValues = columnValues.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            StudentsPageObject.clickColumnnAndSort( Students.COLUMN_STUDNET_ID, Constants.DESCENDING );
            actualList = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_STUDNET_ID );
            actualList = actualList.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            Log.assertThat( SMUtils.sortAndCompareList( actualList, columnValues, Constants.DESCENDING ), "DESCENDING Ascending order is matching",
                    "DESCENDING  is not matching \n Actual: " + actualList.toString() + "\n Expected: " + columnValues.toString() );

            //Grade Column
            SMUtils.logDescriptionTC( "SMK-10145:Verify the Descending order for Grade in application" );
            columnValues = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_GRADE );
            columnValues = columnValues.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            StudentsPageObject.clickColumnnAndSort( Students.COLUMN_GRADE, Constants.DESCENDING );
            actualList = StudentsPageObject.getAllValuesAsListForColumn( Students.COLUMN_GRADE );
            actualList = actualList.stream().map( String::toLowerCase ).collect( Collectors.toList() );
            Log.assertThat( gradeSortingMatches( actualList, columnValues, Constants.DESCENDING ), "DESCENDING Ascending order is matching", "DESCENDING  is not matching \n Actual: " + actualList.toString() + "\n Expected: " + columnValues.toString() );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verification of Google class room student listing ", priority = 7, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_008() throws Exception {
        Log.testCaseInfo( "Verify the teacher can able to see the google class students." );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            StudentsPageObject = new StudentsPage( driver );

            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            String googleClassTeacher = configProperty.getProperty( ConfigConstants.GC_BASIC_USER );
            TeacherHomePage tHomePage = smLoginPage.loginToSM( googleClassTeacher, password, false );
            StudentsPage StudentsTab = tHomePage.topNavBar.navigateToStudentsTab();
            StudentsTab.selectAllStudents();
            StudentsTab.clickGroupButtoninStudentLisitngPage();
            List<String> allGroupsinPoup = StudentsTab.getAllGroupsinPoup();
            Log.assertThat( !allGroupsinPoup.contains( "Google Class Test Group" ), "Google class is not displayed in add student to group", "Google class is displayed in add student to group" );
            StudentsTab = tHomePage.topNavBar.navigateToStudentsTab();
            String googleClassStudent = SMUtils.getKeyValueFromResponse( new RBSUtils().getUser( configProperty.getProperty( ConfigConstants.GC_BASIC_STUDENT_ID ) ), RBSDataSetupConstants.USERNAME );
            Log.assertThat( StudentsTab.isStrudentPresent( googleClassStudent ), "Google class student displayed in student listing!", "Google class student is not displayed!", driver );
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 7, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_009() throws Exception {
        Log.testCaseInfo( "Verify the teacher can not able to see the student when the student is not part of group." );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
        	StudentsPageObject = new StudentsPage( driver );

            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, false );
            StudentsPage studentsTab = tHomePage.topNavBar.navigateToStudentsTab();
            String newStudentName = "auto_student_" + System.nanoTime();
            String createdStudent = studentsTab.createStudent( newStudentName, newStudentName, "Grade 2" );
            Log.assertThat( studentsTab.isStudentNotPresent( createdStudent ), "Newly created student is not displayed without group!", "Newly created student is displayed without group!" );
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 7, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_011() throws Exception {
        Log.testCaseInfo( "Verify the teacher can able to see the students when the student is part of multiple teachers group." );

        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentIdList.get( 0 ) );
        studentRumbaIds.add( studentIdList.get( 1 ) );

        String sharedTeacher = "successmakerTeachershared";
        HashMap<String, String> userDetails = new HashMap<>();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, sharedTeacher );
        if ( new RBSUtils().isUserExits( sharedTeacher, userDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ) ) ) {
            String teacherId = new RBSUtils().getUserIDByUserName( sharedTeacher );
            new RBSUtils().deleteUser( Arrays.asList( teacherId ) );
        }
        String sharedTeacherId = new RBSUtils().createUser( userDetails );
        new RBSUtils().resetPassword( RBSDataSetup.organizationIDs.get( schoolUsed.get() ), password, sharedTeacherId );
        String groupName = "SharedTeacherGroup" + System.nanoTime();
        HashMap<String, String> groupDetails = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.USERNAME, sharedTeacher );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
        groupDetails.put( RBSDataSetupConstants.SECTION_NAME, groupName );
        groupDetails.put( RBSDataSetupConstants.ORGANIZATION_ID, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
        String createGroupResp = new RBSUtils().createClassWithMultipleTeacher( groupDetails, Arrays.asList( sharedTeacherId, teacherId ), studentRumbaIds );
        Log.message( createGroupResp );

        JSONObject jsonnObject2 = new JSONObject( createGroupResp );
        String classId = jsonnObject2.getJSONObject( Constants.DATA ).getJSONObject( ReturnStudentListAPI.SECTION ).get( ReturnStudentListAPI.ID ).toString();
        String adminToken = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        String addProductToClassGraphQL = new RBSUtils().addProductToClassGraphQL( groupDetails.get( RBSDataSetupConstants.ORGANIZATION_ID ), classId, configProperty.getProperty( ConfigConstants.FLEXPRODUCT ), adminToken, teacherId );
        Log.message( addProductToClassGraphQL );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            StudentsPageObject = new StudentsPage( driver );
            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( sharedTeacher, password, false );
            StudentsPage studentsTab = tHomePage.topNavBar.navigateToStudentsTab();

            SMUtils.logDescriptionTC( "Verify the teacher can able to see the student single time when the student part of multiple group in teacher." );
            SMUtils.logDescriptionTC( "Verify the teacher can able to see the students when the student is part of multiple teachers group." );
            Log.assertThat( studentsTab.isStudentPresent( studentUserNames.get( 0 ) ), "Student is listing from multiple teachers group.", "Student is not listing from multiple teachers group." );

            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );
            groupsPage.clickSettingsSubNav();
            groupsPage.editGroup( groupName + "updated" );
            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsPage.isGroupExist( groupName + "updated" ), "Shared teacher group name updated!", "Shared teacher group name updated!" );

            SMUtils.logDescriptionTC( "Verify the student can be remove from the shared group" );
            StudentsPage navigateToStudentsTab = tHomePage.topNavBar.navigateToStudentsTab();
            navigateToStudentsTab.clickviewStudentByEllipsis( studentUserNames.get( 0 ) );
            navigateToStudentsTab.removeStudentFromAllGroup();

            SMUtils.logDescriptionTC( "Verify the Toast Message after removing the student from the Group" );
            Log.assertThat( navigateToStudentsTab.VerifyToastMessageForRemoveStudentFromGroup(), "Toast message verified successfully!", "Error in toast message", driver );

            tHomePage.topNavBar.navigateToGroupsTab();
            SMUtils.logDescriptionTC( "Verify the teacher can able to delete the group when the group is shared with multiple teachers" );
            SMUtils.logDescriptionTC( "Verify the teacher can able to delete the group with shared students." );
            groupsPage.viewGroup( groupName + "updated" );
            groupsPage.deleteGroup( groupName );

            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsPage.isGroupExist( groupName ), "Shared teacher group is deleted!", "Shared teacher group is not deleted!" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 7, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_010() throws Exception {
        Log.testCaseInfo( "Verify the teacher can not able to see the student when the student is removed from all the groups." );

        String maxnumberStudentName = "successmakertestsudentwithmaximumnumberofcharacterfortestingpurp";
        HashMap<String, String> userDetails = new HashMap<>();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, maxnumberStudentName );
        userDetails.put( RBSDataSetupConstants.FIRSTNAME, maxnumberStudentName );
        if ( new RBSUtils().isUserExits( maxnumberStudentName, userDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ) ) ) {
            String studentId = new RBSUtils().getUserIDByUserName( maxnumberStudentName );
            new RBSUtils().deleteUser( Arrays.asList( studentId ) );
        }
        String maxnumberStudentNameResp = new RBSUtils().createUser( userDetails );
        String minnumberStudentName = "suc";
        userDetails.put( RBSDataSetupConstants.FIRSTNAME, minnumberStudentName );
        userDetails.put( RBSDataSetupConstants.USERNAME, minnumberStudentName );
        if ( new RBSUtils().isUserExits( minnumberStudentName, userDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ) ) ) {
            String studentId = new RBSUtils().getUserIDByUserName( minnumberStudentName );
            new RBSUtils().deleteUser( Arrays.asList( studentId ) );
        }
        String minnumberStudentNameResp = new RBSUtils().createUser( userDetails );

        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( maxnumberStudentNameResp, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( minnumberStudentNameResp, RBSDataSetupConstants.USERID ) );
        HashMap<String, String> groupDetails = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Group sm Test" + System.nanoTime() );
        HashMap<String, String> response = new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {

            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, false );
            StudentsPage studentsTab = tHomePage.topNavBar.navigateToStudentsTab();
            studentsTab.clickViewStudentByEllipseForStudent( studentUserNames.get( 0 ) );

            studentsTab.removeStudentFromAllGroup();
            tHomePage.topNavBar.navigateToStudentsTab();
            Log.assertThat( studentsTab.isStudentNotPresent( studentUserNames.get( 0 ) ), "Student not present in student listing after removing from all groups.", "Student present in student listing after removing from all groups." );

            studentsTab = tHomePage.topNavBar.navigateToStudentsTab();

            SMUtils.logDescriptionTC( "Verify the student firstname, when the character length is more than 64 characters" );
            SMUtils.logDescriptionTC( "Verify the student firstname, when the character length is minimum no of acceptable characters" );
            Log.assertThat( studentsTab.isStudentPresent( maxnumberStudentName ), "Maximum count student is present in student listing", "Maximum count student is not present in student listing" );
            Log.assertThat( studentsTab.isStudentPresent( minnumberStudentName ), "Minimum count student is present in student listing", "Minimum count student is not present in student listing" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 7, groups = { "SMK-39581", "Students Listing", "Students" } )
    public void tcSMStudentListing_012() throws Exception {
        Log.testCaseInfo( "Verify the teacher can able to see more then 100 students" );
        SMUtils.logDescriptionTC( "Verify the teacher can able to select more then 100 students and see the groups are listed." );

        HashMap<String, String> userDetails = new HashMap<>();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( schoolUsed.get() ) );
        String bulkuserGroupname = "BulkuserGroupTest%s";
        String bulkusername = "smautobulkusertest%s";
        List<String> bulkuserids = new ArrayList<>();
        IntStream.rangeClosed( 1, 100 ).forEach( count -> {
            String studentId = null;
            try {
                userDetails.put( RBSDataSetupConstants.USERNAME, String.format( bulkusername, count ) );
                String bulkuserResp = new RBSUtils().createUser( userDetails );
                JSONObject createdUser = new JSONObject( bulkuserResp );
                bulkuserids.add( createdUser.get( RBSDataSetupConstants.USERID ).toString() );
            } catch ( Exception e ) {

                try {
                    new RBSUtils().deleteUser( Arrays.asList( new RBSUtils().getUserIDByUserName( String.format( bulkusername, count ) ) ) );
                    userDetails.put( RBSDataSetupConstants.USERNAME, String.format( bulkusername, count ) );
                    String bulkuserResp = new RBSUtils().createUser( userDetails );
                    JSONObject createdUser = new JSONObject( bulkuserResp );
                    bulkuserids.add( createdUser.get( RBSDataSetupConstants.USERID ).toString() );
                } catch ( Exception e1 ) {
                    e.printStackTrace();
                }
            }
            System.out.println( "Created Student = " + count );
        } );

        HashMap<String, String> groupDetails = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );

        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, String.format( bulkuserGroupname, "bulk" ) );
        new GroupAPI().createGroup( smUrl, groupDetails, bulkuserids );
        bulkuserids.clear();
        IntStream.rangeClosed( 1, 100 ).forEach( count -> {
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, String.format( bulkuserGroupname, count ) );
            try {
                new GroupAPI().createGroup( smUrl, groupDetails, bulkuserids );
            } catch ( Exception e ) {
                e.printStackTrace();
            }
        } );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);

        try {

            // Logging in and goes to Students tab
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, false );
            StudentsPage studentsTab = tHomePage.topNavBar.navigateToStudentsTab();
            List<String> allValuesAsListForColumn = studentsTab.getAllValuesAsListForColumn( Students.COLUMN_USER_NAME );
            Log.assertThat( allValuesAsListForColumn.size() > 100, "Student listing displaying morethen 100 students1", "Issue in displaying more then 100 students. " );

            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();

            List<String> groupListNames = groupsPage.getGroupListNames();
            SMUtils.logDescriptionTC( "Verify the group listing for 100 groups" );
            SMUtils.logDescriptionTC( "Verify the teacher can able to see more then 100 group when the students are not part of those grouups." );

            Log.assertThat( groupListNames.size() > 100, "More then 100 groups are displayed!", "Issue in displaying more then 100 students!" );
            SMUtils.logDescriptionTC( "Verify the group is created with more than 100+ Users" );
            SMUtils.logDescriptionTC( "Verify the group listing group with 100 students" );
            String studentsCount = groupsPage.getStudentsCount( String.format( bulkuserGroupname, "bulk" ) );
            Log.assertThat( studentsCount.equals( "100" ), "Student count displayed 100", "Student count is not displayed as 100" );

            SMUtils.logDescriptionTC( "Verify the student can be removed from a group contains more than 100 students" );
            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();
            studentTab.clickviewStudentByEllipsis( String.format( bulkusername, 1 ) );
            studentTab.removeStudentFromAllGroup();

            SMUtils.logDescriptionTC( "Verify that all the groups are listed, when there are more than 100 groups and student is not part of any group" );
            studentTab = tHomePage.topNavBar.navigateToStudentsTab();
            studentTab.selectAllStudents();
            studentTab.clickGroupButtoninStudentLisitngPage();
            List<String> allGroupsinPoup = studentTab.getAllGroupsinPoup();
            Log.assertThat( allGroupsinPoup.size() > 100, "More then 100 groups are displayed for the students", "Issue in displaying morethen 100 students." );

            SMUtils.logDescriptionTC( "Verify the group contains more than 100 students and try to update the group" );
            groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( String.format( bulkuserGroupname, "bulk" ) );
            groupsPage.clickSettingsSubNav();
            groupsPage.editGroup( String.format( bulkuserGroupname, "updated" ) );
            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsPage.isGroupExist( String.format( bulkuserGroupname, "updated" ) ), "Group name is updated when the group has 100 students", "Group name is not updated when the group has 100 students" );

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public void addStudentToGroup( String studentUsername ) {
        HashMap<String, String> groupDetails = new HashMap<>();
        try {
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
            HashMap<String, String> response = groupApi.addStudentToGroup( smUrl, groupDetails, Arrays.asList( new RBSUtils().getUserIDByUserName( studentUsername.toLowerCase() ) ), Arrays.asList( teacherGroupId.get( 0 ) ) );
            Log.message( response.toString() );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

    }

    public boolean gradeSortingMatches( List<String> actual, List<String> expected, String SortingType ) {

        for ( String grade : actual ) {
            if ( grade.contains( "not" ) ) {
                actual.set( actual.indexOf( grade ), "-1" );
            } else if ( grade.contains( "k" ) ) {
                actual.set( actual.indexOf( grade ), "0" );
            } else {
                actual.set( actual.indexOf( grade ), grade.substring( 6 ) );
            }
        }
        for ( String grade : expected ) {
            if ( grade.contains( "not" ) ) {
                expected.set( expected.indexOf( grade ), "-1" );
            } else if ( grade.contains( "k" ) ) {
                expected.set( expected.indexOf( grade ), "0" );
            } else {
                expected.set( expected.indexOf( grade ), grade.substring( 6 ) );
            }
        }
        List<Integer> newActual = actual.stream().map( Integer::parseInt ).collect( Collectors.toList() );
        List<Integer> newExpected = expected.stream().map( Integer::parseInt ).collect( Collectors.toList() );

        if ( SortingType.equals( Constants.DESCENDING ) ) {
            Collections.sort( newActual, Collections.reverseOrder() );
            Collections.sort( newExpected, Collections.reverseOrder() );
        } else {
            Collections.sort( newActual );
            Collections.sort( newExpected );
        }

        return ( newExpected.equals( newExpected ) ) ? true : false;
    }
}
