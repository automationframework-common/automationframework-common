package com.savvas.sm.api.tests.smnew.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.StudentUsage;
import com.savvas.sm.utils.sql.helper.FixupFunction;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;
import com.savvas.sm.utils.sql.helper.SqlHelperUsage;

public class GetStudentPageStudentUsageTest extends UserAPI {

	 private String smUrl;
	    private String browser;
	    private String teacherDetails;
	    private String coTeacherUsername;
	    private String coTeacherID;
	 //   private String flexSchool;
	    private String mathSchool;
	    private String orgId;
	    private String mathOrgId;
	    private String teacherId;
	    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
	    private static HashMap<String, String> assignmentDetails = new HashMap<>();
	    private static Map<String, String> contentBase = new HashMap<>();
	    private static Map<String, String> contentBaseName = new HashMap<>();
	    private static Map<String, String> assignmentIds = new HashMap<>();
	    private static List<String> studentRumbaIds = new ArrayList<>();
	    private static List<String> studentRumbaUsernames = new ArrayList<>();
	    RBSUtils rbsUtils = new RBSUtils();
	    private List<String> courseIDs = new ArrayList<>();
	    private Map<String, String> response = new HashMap<>();
	    private HashMap<String, String> groupDetails = new HashMap<>();
	    private String exception = null;
	    private String message = null;
	    private String teacherUsername;
	    private String schoolAdminUsername;
	    private String districtAdminUsername;
	    private String savvasAdminUsername;
	    private String schoolAdminUserId;
	    private String districtAdminUserId;
	    private String savvasAdminUserId;
	    private BaseAPITest baseAPITest = new BaseAPITest();
	  

	    @BeforeClass ( alwaysRun = true )
	    public void BeforeTest() throws Exception {
	        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
	        browser = configProperty.getProperty( "BrowserPlatformToRun" );

	        schoolAdminUsername = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
	        districtAdminUsername = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
	        savvasAdminUsername = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );

	        schoolAdminUserId = rbsUtils.getUserIDByUserName( schoolAdminUsername );
	        districtAdminUserId = rbsUtils.getUserIDByUserName( districtAdminUsername );
	        savvasAdminUserId = rbsUtils.getUserIDByUserName( savvasAdminUsername );

	 //       flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
	        orgId = RBSDataSetup.organizationIDs.get( school );
//	        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
//	        mathOrgId = RBSDataSetup.organizationIDs.get( mathSchool );

	        String teacherDetails = RBSDataSetup.getMyTeacher( school );
	        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
	        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

	        IntStream.rangeClosed( 1, 4 ).forEach( itr -> {
	            String studentDetail = RBSDataSetup.getMyStudent( school, teacherUsername );
	            studentRumbaUsernames.add( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME ) );
	            studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID ) );
	        } );

	        String token = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );

	        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
	        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
	        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
	        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "Auto Test Group" );

	        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
	        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
	        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

	        Log.message( "Test Auto Group " + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

	        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
	        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
	        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
	        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );

	        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
	        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_READING, System.nanoTime() ) );
	        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.STANDARD_COURSE, String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
	        contentBaseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );

	        Log.message( "contentbasename" + contentBaseName );
	        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
	        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
	                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
	        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
	                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );
	        contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE,
	                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) ) );

	        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
	        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE,
	                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
	        contentBase.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE,
	                new CourseAPI().createCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) ) );

	        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
	        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ) );
	        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
	        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

	        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
	        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
	        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ) );

	        Log.message( "contentBaseName- " + contentBaseName );
	        Log.message( "contentBase- " + contentBase );
	        Log.message( "courseIDs- " + courseIDs );

	        Log.message( "Assigning assignment..." );

	        Log.message( "Assignment Details: " + assignmentDetails );
	        Log.message( "Student Details: " + studentRumbaIds );

	        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
	        Log.message( "Assignment Details" + assignmentResponse );

	        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
	        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

	        for ( Object assignment : assignmentList ) {
	            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
	            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
	        }

	        Log.message( "Assignment IDs - " + assignmentIds );

	        String username = studentRumbaUsernames.get( 0 );
	        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
	        executeCourse( studentRumbaUsernames.get( 1 ), contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
	        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ), true );
	        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), true );
	        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.STANDARD_COURSE ), true );

	        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
	        executeCourse( username, contentBaseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.SETTINGS_COURSE ), false );
	        
	        // Running fix-up query to get previous week data
//	         FixupFunction.executeFixupFunctions( orgId );

	        
	    }


    @Test ( priority = 1, dataProvider = "studentUsagePositive", groups = { "SMK-52120", "smoke_test_case", "Student Usage", "P1", "API" } )
    public void tcPositiveTestcases( String tcId, String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
  //      List<String> assignments = new ArrayList<>();
        List<String> assignments = null;
     //   String studentId;
        List<String> studentId;
        List<String> schools = new ArrayList<>();
        String token = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );

        switch ( scenario ) {
            case "VALID":

                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
                //for empty assignment array
                assignments = new ArrayList<>();
    //            studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" );
                studentId = studentRumbaIds;
    //            studentId = studentRumbaIds.get(0);  
     //           response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), new ArrayList<>(), studentId, "" );
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
       //         verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, Arrays.asList( studentId ) );
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, studentId );
                break;

            case "MATH_ASSIGNMENT_ALONE":

                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

           //     studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), "userId" );
           //     studentId = studentRumbaIds.get(1);
           //     response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, studentId, "" );
                studentId = studentRumbaIds;
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                
                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
     //           verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>( assignmentIds.values()), Arrays.asList( studentId ) );
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, studentId );
                break;

            case "READING_ASSIGNMENT_ALONE":

                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
         //       studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student3" ), "userId" );
//                studentId = studentRumbaIds.get(2);
//                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, studentId, "" );
                studentId = studentRumbaIds;
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );
                
                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
//                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>( assignmentIds.values()), Arrays.asList( studentId ) );
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, studentId );
                break;

            case "AFTER_DELETE_THE_ASSIGNMENT":

                HashMap<String, String> assignmentDetail = new HashMap<>();
                assignmentDetail.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, token );
                assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID,
                        new SqlHelperCourses().getAssignmentUserId( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), "userId" ), assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetail, "null" );

                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
           //     studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), "userId" );

//                studentId = studentRumbaIds.get(3);
//                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, studentId, "" );

                studentId = studentRumbaIds;
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
           //     verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>( assignmentIds.values()), Arrays.asList( studentId ) );
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, studentId );
                break;

            case "ZERO_STATE":

                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        //        studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student4" ), "userId" );
//                studentId = studentRumbaIds.get(4);
//                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), new ArrayList<>( assignmentIds.values()), studentId, "" );
                studentId = studentRumbaIds;
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "STUDENT_ASSOCIATED_WITH_TWO_GROUPS_FOR_DIFF_TEACHER":

                //Creating the teacher in the Same school
                coTeacherUsername = "SchTeacher" + System.nanoTime();

                schools.add( RBSDataSetup.organizationIDs.get( school ) );
   //             String coTeacherDetails = createUserWithCustomization( coTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, schools );
                String coTeacherDetails = RBSDataSetup.getMyTeacher(school);
                coTeacherID = SMUtils.getKeyValueFromResponse( coTeacherDetails, RBSDataSetupConstants.USERID );
                Log.message("coteacherId: "+coTeacherID);

                //Creating group with existing student for above created teacher
                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), coTeacherID, Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) ),
                        RBSDataSetup.organizationIDs.get( school ), new RBSUtils().getAccessToken( coTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                headers.put( UserConstants.USERID, coTeacherID );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( coTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        //        studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" );
//                studentId = studentRumbaIds.get(0);
//                Log.message("student ID"+studentId.toString());
//                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), new ArrayList<>( assignmentIds.values()), studentId, "" );
                studentId = studentRumbaIds;
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );

                //                Log.message("response: "+response);
                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
         //       verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, Arrays.asList( studentId ) );
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, studentId );
                break;

            case "MULTIPLE_TEACHER_GROUP":

                String sharedGroup = "Shared Group" + System.nanoTime();

                //creating Shared group
                new RBSUtils().createClassWithMultipleTeacher( sharedGroup, Arrays.asList( teacherId, coTeacherID ), Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), "userId" ) ),
                        RBSDataSetup.organizationIDs.get( school ), token );

                headers.put( UserConstants.USERID, coTeacherID );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( coTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
      //          studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student2" ), "userId" );
//                studentId = studentRumbaIds.get(1);
//                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), new ArrayList<>( assignmentIds.values()), studentId, "" );

                studentId = studentRumbaIds;
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );

                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
         //       verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, Arrays.asList( studentId ) );
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, studentId );
                break;

            case "AFTER_REMOVE_THE_STUDENT_FROM _GROUP_WITH_ASSIGNMENT":

                //adding the student to the  group for the  teacher
                String newGroupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student4" ), "userId" ) ),
                        RBSDataSetup.organizationIDs.get( school ), token );

                //Assigning the assignment
                String courseName = "MATH Custom Settings" + System.nanoTime();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
         //       assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, baseAPITest.createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName ) );
       //         new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE );
                HashMap<String, String> assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE );
                String assignmentId = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.REPORT_BODY ), "data,assignmentId" );

                //execute course through student dashboard
                executeCourse( studentRumbaUsernames.get(1) , courseName, true );
         //       studentId = studentRumbaIds.get(0);
                new RBSUtils().deleteStudentFromSection( newGroupId, teacherId, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student3" ), "userId" ) );
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

     //           studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student4" ), "userId" );
//                studentId = studentRumbaIds.get(2);
//
//                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, studentId, "" );
                studentId = studentRumbaIds;
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, "", "" );


                //Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                //data Validation
          //      verifyResponseWithDB( response.get( Constants.REPORT_BODY ), new ArrayList<>( assignmentIds.values()), Arrays.asList( studentId ) );
                verifyResponseWithDB( response.get( Constants.REPORT_BODY ), assignments, studentId );
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        //Schema validation
        if ( !scenario.equalsIgnoreCase( "ZERO_STATE" ) ) {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "getStudentUsageSchema", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        } else {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "400_Schema", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

            //Exception validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ).equalsIgnoreCase( CommonAPIConstants.DATA_NOT_FOUND_EXCEPTION ), "Exception Verified successfully!",
                    "Issue in displaying exception! Expected - " + exception + "Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ) );

            //Message Validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( "Student usage not found" ), "Message Verified successfully!",
                    "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ) );
        }

    }

    @DataProvider ( name = "studentUsagePositive" )
    public Object[][] studentUsagePositive() {

        Object[][] inputData = { { "tc_StudentPage_StudentUsage001", "Verify the status code is 200 when searching with query parameter student id alone", "VALID", CommonAPIConstants.STATUS_CODE_OK },
                  { "tc_StudentPage_StudentUsage002", "Verify the status code is 200 while pass the student id in query param and the student attended math assignments alone", "MATH_ASSIGNMENT_ALONE", CommonAPIConstants.STATUS_CODE_OK },
                { "tc_StudentPage_StudentUsage003", "Verify the status code is 200 while pass the student id in query param and the student attended reading assignments alone", "READING_ASSIGNMENT_ALONE", CommonAPIConstants.STATUS_CODE_OK }};
//                { "tc_StudentPage_StudentUsage004", "Verify response will not return soft deleted assignment student usage if the soft deleted assignment is deleted for student.", "AFTER_DELETE_THE_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK },
//                { "tc_StudentPage_StudentUsage005", "Verify the empty response returned when there is no usage data for the student and status code is 200", "ZERO_STATE", CommonAPIConstants.STATUS_CODE_OK },
//                  { "tc_StudentPage_StudentUsage006", "Verify usage data in response while pass the student id query param if the student is associated with two different groups of two different teacher",
//                        "STUDENT_ASSOCIATED_WITH_TWO_GROUPS_FOR_DIFF_TEACHER", CommonAPIConstants.STATUS_CODE_OK },
//                 { "tc_StudentPage_StudentUsage007", "Verify usage data in while pass the student id query param response if the two teachers are the owner for single group", "MULTIPLE_TEACHER_GROUP", CommonAPIConstants.STATUS_CODE_OK },
//                { "tc_StudentPage_StudentUsage008", "Verify the student Page - student usage if the student removed from the group(group with assignments)", "AFTER_REMOVE_THE_STUDENT_FROM _GROUP_WITH_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK } };
        return inputData;
    }

    @Test ( priority = 2, dataProvider = "studentUsageNegative", groups = { "SMK-52120", "Students", "Student Usage", "P2", "API" } )
    public void tcNegativeTestcases( String tcId, String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        List<String> assignments = new ArrayList<>();
        String studentId;
        String token = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );

        Log.message( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ) );
        switch ( scenario ) {
            case "WITH_SCHOOL_ADMIN_CREDENTIAL":
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN ), "userId" ) );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentId = studentRumbaIds.get(0);
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, studentId, "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "WITH_STUDENT_CREDENTIAL":
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
           //     studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" );
                studentId = studentRumbaIds.get(1);
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, studentId, "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "WITH_DISTRICT_ADMIN_CREDENTIAL":
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), "userId" ) );
                headers.put( UserConstants.ORGID, configProperty.getProperty( "district_ID" ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
         //       studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" );
                studentId = studentRumbaIds.get(2);
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, studentId, "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "WITH_SAVVAS_ADMIN_CREDENTIAL":
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN ), "userId" ) );
                headers.put( UserConstants.ORGID, configProperty.getProperty( "district_ID" ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
         //       studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" );
                studentId = studentRumbaIds.get(0);
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, studentId, "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "INVALID_HEADER":
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) + "invalid" );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
           //     studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" );
                studentId = studentRumbaIds.get(0);
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, studentId, "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "INVALID_USERID":
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) + "invalid" );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            //    studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" );
                studentId = studentRumbaIds.get(0);
                Log.message("studentID: "+studentId);
                response = new UserAPI().getStudentUsage( smUrl, headers, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ), headers.get( UserConstants.ORGID ), assignments, studentId, "" );
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "EMPTY_ORGID":
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( UserConstants.ORGID, "" );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );
          //      studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" );
                studentId = studentRumbaIds.get(0);
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), RBSDataSetup.organizationIDs.get( school ), assignments, studentId, "" );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "INVALID_ACCESS_TOKEN":
                headers.put( UserConstants.USERID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( school ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token + "invalid" );
       //         studentId = SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" );
                studentId = studentRumbaIds.get(0);
                response = new UserAPI().getStudentUsage( smUrl, headers, headers.get( UserConstants.USERID ), headers.get( UserConstants.ORGID ), assignments, studentId, "" );
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            default:
                Log.message( "Not a valid scenario....." );
                break;

        }

        Log.message(response.get( Constants.STATUS_CODE ));
        Log.message(response.toString());
        //Status code validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

        if ( !scenario.equalsIgnoreCase( "INVALID_ENDPOINT" ) ) {
            //Schema Validation
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "getStudentUsageSchema", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

            //Exception validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ).equalsIgnoreCase( exception ), "Exception Verified successfully!",
                    "Issue in displaying exception! Expected - " + exception + "Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,exception" ) );

            //Status Validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,status" ).equalsIgnoreCase( "failure" ), "Status Verified successfully!", "Issue in displaying Status!" );

            //message Validation
            Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( message ), "Message Verified successfully!",
                    "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ) );

        }
    }

//    @DataProvider ( name = "studentUsageNegative" )
//    public Object[][] studentUsageNegative() {
//
//        Object[][] inputData = {
//                { "tc_StudentPage_StudentUsage009", "Verify the status code is 401 for incorrect authorization for invalids roles(Give school customer admin authorization) while pass the student id in quer param", "WITH_SCHOOL_ADMIN_CREDENTIAL",
//                        CommonAPIConstants.STATUS_CODE_FORBIDDAN },
//                { "tc_StudentPage_StudentUsage010", "Verify the status code is 403 for incorrect authorization for invalids roles(Give student authorization) while pass the student id in quer param", "WITH_STUDENT_CREDENTIAL",
//                        CommonAPIConstants.STATUS_CODE_FORBIDDAN },
//                { "tc_StudentPage_StudentUsage011", "Verify the status code is 401 for incorrect authorization for invalids roles(Give district customer admin authorization) while pass the student id in quer param", "WITH_DISTRICT_ADMIN_CREDENTIAL",
//                        CommonAPIConstants.STATUS_CODE_FORBIDDAN },
//                { "tc_StudentPage_StudentUsage012", "Verify the status code is 403 for incorrect authorization for invalids roles(Give savvas admin authorization) while pass the student id in quer param", "WITH_SAVVAS_ADMIN_CREDENTIAL",
//                        CommonAPIConstants.STATUS_CODE_FORBIDDAN },
//                { "tc_StudentPage_StudentUsage013", "Verify the status code is 403 when invalid headers is passed while pass the student id in quer param", "INVALID_HEADER", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
//                  { "tc_StudentPage_StudentUsage014", "Verify response 401 when invalid/empty user id given in header while pass the student id in quer param", "INVALID_USERID", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
//                { "tc_StudentPage_StudentUsage015", "Verify response 401 when empty orgid given in header while pass the student id in quer param", "EMPTY_ORGID", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
//                { "tc_StudentPage_StudentUsage016", "Verify response 401 when user give invalid token for authorization. while pass the student id in quer param", "INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED } };
//        return inputData;
//    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "10" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "3" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    /**
     * To verify the response with DB
     * 
     */
    private void verifyResponseWithDB( String response, List<String> assignmentIds, List<String> studentIds ) {
        Map<String, Map<String, String>> usageDetailsFromResponse = new HashMap<>();
        String reponseData = SMUtils.getKeyValueFromResponse( response, "data" );
        IntStream.rangeClosed( 0, 7 ).forEach( iter -> {
            Map<String, String> subjectUsage = new HashMap<>();
            JSONObject jsonObj = new JSONObject( reponseData );
            JSONArray ja = jsonObj.getJSONArray( "studentUsageData" );
            JSONObject jObj = ja.getJSONObject( iter );
            subjectUsage.put( StudentUsage.MATH_MINS, jObj.get( StudentUsage.MATH_MINS ).toString() );
            subjectUsage.put( StudentUsage.READING_MINS, jObj.get( StudentUsage.READING_MINS ).toString() );
            usageDetailsFromResponse.put( jObj.get( StudentUsage.WEEK ).toString(), subjectUsage );
        } );
        Map<String, String> individualFields = new HashMap<>();

        individualFields.put( StudentUsage.THIS_WEEK_MINS, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.THIS_WEEK_MINS ) );
        individualFields.put( StudentUsage.LAST_WEEK_MINS, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.LAST_WEEK_MINS ) );
        individualFields.put( StudentUsage.TOTAL_MINTUES, SMUtils.getKeyValueFromResponse( reponseData, StudentUsage.TOTAL_MINTUES ) );
        usageDetailsFromResponse.put( "individualFields", individualFields );

        Map<String, Map<String, String>> usageDetailsFromDB = new SqlHelperUsage().getStudentUsage( assignmentIds, studentIds );

        Log.message( "usage Data from Db - " + usageDetailsFromDB );

//        Log.assertThat( usageDetailsFromDB.entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), usageDetailsFromResponse.get( entry.getKey() ) ) ), "Usage data are fetched properly",
//                "Usage data are not fetched properly. Expected -" + usageDetailsFromDB.toString() + ": Actual -" + usageDetailsFromResponse.toString() );
        Log.assertThat( usageDetailsFromDB.entrySet().stream().allMatch( entry -> {
            if ( entry.getValue().containsKey( StudentUsage.MATH_MINS ) ) {
                int mathDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.MATH_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.MATH_MINS ) );
                int readDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.READING_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.READING_MINS ) );
                return ( mathDeviation >= -1 && mathDeviation <= 1 ) && ( readDeviation >= -1 && readDeviation <= 1 );
            } else if ( entry.getValue().containsKey( StudentUsage.THIS_WEEK_MINS ) ) {
                int thisWeekMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.THIS_WEEK_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.THIS_WEEK_MINS ) );
                int lastWeekMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.LAST_WEEK_MINS ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.LAST_WEEK_MINS ) );
                int toatalMinsDeviation = Integer.parseInt( entry.getValue().get( StudentUsage.TOTAL_MINTUES ) ) - Integer.parseInt( usageDetailsFromResponse.get( entry.getKey() ).get( StudentUsage.TOTAL_MINTUES ) );
                return ( thisWeekMinsDeviation >= -2 && thisWeekMinsDeviation <= 2 ) && ( lastWeekMinsDeviation >= -2 && lastWeekMinsDeviation <= 2 ) && ( toatalMinsDeviation >= -2 && toatalMinsDeviation <= 2 );
            } else {
                return false;
            }
        } ), "Usage data are fetched properly", "Usage data are not fetched properly. Expected -" + usageDetailsFromDB.toString() + ": Actual -" + usageDetailsFromResponse.toString() );
    

    }

}
