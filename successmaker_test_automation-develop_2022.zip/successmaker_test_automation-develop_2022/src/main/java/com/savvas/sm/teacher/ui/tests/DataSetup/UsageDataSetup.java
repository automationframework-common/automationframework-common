package com.savvas.sm.teacher.ui.tests.DataSetup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants.UsageGoal;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.SqlHelperUsage;

import LSTFAI.customfactories.EventFiringWebDriver;

public class UsageDataSetup extends BaseTest {
    private static String smUrl;
    private static String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;

    @BeforeTest ( alwaysRun = true )
    public static void createData() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );

        //To create data for student usage chart
        studentUsageChartDataSetup();
        //To create data for Home Page  usage chart
        homePageUsageChartDataSetup();
        //To create data for Group usage chart
        groupUsageDataSetup();
        //To create data for Usage goal student list
        usageGoalStudentListDataSetup();

        //execute query
        executeShareUsageDataQuery();
    }

    public static void studentUsageChartDataSetup() throws Exception {
        BaseAPITest baseApiObject = new BaseAPITest();

        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher21" );
        String teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        String studentDetails = DataSetup.teacherStudentMap.get( teacherUsername ).get( "Student1" );
        List<String> studentIds = new ArrayList<>();
        IntStream.range( 1, 4 ).forEach( studentCount -> studentIds.add( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( teacherUsername ).get( String.format( "Student%s", studentCount ) ), "data,personId" ) ) );

        String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, "data,userName" );

        String sessionCookie = baseApiObject.getJessionCookie( smUrl, teacherUsername, password );
        baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.MATH, DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "1", studentIds );
        baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.READING, DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "2", studentIds );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            //Executing math assignments and Reading in student dashboard            
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "Math", "95", "5", "5" );
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "Reading", "95", "1", "2" );
            studentDashboardPage.logout();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            driver.quit();
        }
        driver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
        eventListner = new EventListener();
        driver.register(eventListner);
        try {
            String studentDetail = DataSetup.teacherStudentMap.get( teacherUsername ).get( "Student3" );
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( SMUtils.getKeyValueFromResponse( studentDetail, "data,userName" ), password, true );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "Math", "95", "5", "20" );
            studentDashboardPage.logout();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            driver.quit();
        }
    }

    public static void homePageUsageChartDataSetup() throws Exception {
        BaseAPITest baseApiObject = new BaseAPITest();

        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher22" );
        String teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        String studentDetails = DataSetup.teacherStudentMap.get( teacherUsername ).get( "Student1" );
        List<String> studentIds = new ArrayList<>();
        IntStream.range( 1, 4 ).forEach( studentCount -> studentIds.add( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( teacherUsername ).get( String.format( "Student%s", studentCount ) ), "data,personId" ) ) );

        String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, "data,userName" );

        String sessionCookie = baseApiObject.getJessionCookie( smUrl, teacherUsername, password );
        baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.MATH, DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "1", studentIds );
        baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.READING, DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "2", studentIds );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            //Executing math assignments and Reading in student dashboard            
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
            studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "Math", "95", "5", "5" );
            studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "Reading", "95", "1", "2" );
            studentDashboardPage.logout();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            driver.quit();
        }
    }

    public static void groupUsageDataSetup() throws Exception, IOException {
        BaseAPITest baseApiObject = new BaseAPITest();

        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher34" );
        String teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        List<String> studentId = new ArrayList();
        String sessionCookie = baseApiObject.getJessionCookie( smUrl, teacherUsername, password );
        IntStream.rangeClosed( 1, DataSetup.teacherStudentMap.get( teacherUsername ).size() ).forEach( studentCount -> {
            studentId.add( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( teacherUsername ).get( "Student" + studentCount ), "data,personId" ) );
        } );

        new BaseAPITest().assignCourse( smUrl, sessionCookie, "Math", DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "1", studentId );
        new BaseAPITest().assignCourse( smUrl, sessionCookie, "Reading", DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "2", studentId );

        IntStream.rangeClosed( 1, 3 ).forEach( student -> {

            WebDriver driver = WebDriverFactory.get( chromePlatform );
            String studentUsername = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( teacherUsername ).get( "Student" + student ), "data,userName" );
            LoginPage smStudentLoginPage = new LoginPage( driver, smUrl ).get();
            try {
                StudentDashboardPage studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUsername, password, true );
                studentDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "Math", "80", "5", "5" );
                studentDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "Reading", "80", "1", "2" );
                studentDashboardPage.logout();
            } catch ( Exception e ) {
                e.printStackTrace();
            } finally {
                driver.quit();
            }
        } );

    }

    public static void usageGoalStudentListDataSetup() throws Exception {
        BaseAPITest baseApiObject = new BaseAPITest();

        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher69" );
        String teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
        String studentDetails = DataSetup.teacherStudentMap.get( teacherUsername ).get( "Student1" );
        String studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, "data,userName" );

        final WebDriver driver = WebDriverFactory.get( chromePlatform );
        try {

            String sessionCookie = baseApiObject.getJessionCookie( smUrl, teacherUsername, password );
            String teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" );
            List<String> studentIdList = new ArrayList<>();
            IntStream.rangeClosed( 1, 3 ).forEach( studentCount -> {
                String studentDetail = DataSetup.teacherStudentMap.get( teacherUsername ).get( String.format( UsageGoal.STUDENT_COUNT, studentCount ) );
                studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetail, "data,personId" ) );
            } );

            baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.MATH, DataSetup.organizationId.toString(), teacherId, "1", studentIdList );
            baseApiObject.assignCourse( smUrl, sessionCookie, DataSetupConstants.READING, DataSetup.organizationId.toString(), teacherId, "2", studentIdList );

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            StudentDashboardPage studentsPage = smLoginPage.loginToSMasStudent( SMUtils.getKeyValueFromResponse( studentDetails, "data,userName" ), password, false );
            IntStream.rangeClosed( 1, 3 ).forEach( iter -> {
                try {
                    studentsPage.executeMathCourse( studentUsername, "Math", "100", "2", "30" );
                } catch ( IOException e ) {
                    Log.message( "Error occured while running simulator" );
                }
            } );
            IntStream.rangeClosed( 1, 3 ).forEach( iter -> {
                try {
                    studentsPage.executeReadingCourse( studentUsername, "Reading", "100", "1", "30" );
                } catch ( IOException e ) {
                    Log.message( "Error occured while running simulator" );
                }
            } );
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            driver.quit();
        }
    }

    public static void executeShareUsageDataQuery() {
        //Share usage data for student
        SqlHelperUsage.shareUsageData( DataSetupConstants.BVT_SCHOOL );
    }
}
