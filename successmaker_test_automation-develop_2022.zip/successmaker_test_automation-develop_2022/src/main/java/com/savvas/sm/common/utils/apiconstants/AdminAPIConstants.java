package com.savvas.sm.common.utils.apiconstants;

public interface AdminAPIConstants {
    // Constants - API
    public static String ORGID = "org-id";
    public static String USERID = "user-id";
    public static String AUTHORISATION = "Authorization";
    public static String BEARER = "Bearer ";

    // HolidayScheduler
    public static String START_DATE = "startDate";
    public static String END_DATE = "endDate";
    public static String DESCRIPTION = "description";
    public static String HOLIDAY = "holiday";

    // ShareCourse
    public static String ORGANIZATION_ID = "organizationId";
    public static String COURSE_ID = "courseId";
    public String ID = "id";
    public String OWNER_ORG_ID = "ownerOrgId";
    public String SHARED_ORG_COUNT = "sharedOrgCount";
    public String PARENT_NODE = "parentNode";
    public String CHILD_NODE = "childNode";
    String SUBJECT = "subject";
    String COURSE_TYPE = "courseType";
    String COURSE_NAME = "courseName";
    String STATUS_CODE = "statuCode";
    String VALID = "valid";
    String TRUE = "true";
    String FALSE = "false";

    // OrganizationFlags
    String IS_DIAGNOSTIC_ENABLED = "isDiagnosticEnabled";
    String IS_AUTOASSIGN_ENABLED = "isAutoAssignEnabled";
    String FLAGS = "flags";

    // Constants - Endpoints
    public static String GET_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/getHolidays";
    public static String PUT_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/addHolidays";
    public static String DELETE_HOLIDAY_SCHEDULER = "/lms/web/api/v1/holidayScheduler/deleteHolidays";
    public static String GET_CHILD_ORGANIZATIONS = "/lms/web/api/v1/organizations/getChildren";
    public static String CHILD_ORGANIZATION_FROM_ORGSERVICE = "/org-service/v1/organizations/{organizationId}/childtree";
    public static String GET_SHARE_COURSE = "/lms/web/api/v1/sharedCourse";
    public static String GET_SHARED_COURSE = "/lms/web/api/v1/sharedCourse";

    String GET_ORGANIZATION_FLAGS = "/lms/web/api/v1/organizations/getOrganizationFlags";
    String POST_ORGANIZATION_FLAGS = "/lms/web/api/v1/organizations/setOrganizationFlags";

    String GET_SUCCESS_MSG = "Operation succeeded!";
    String AUTHENTICATION_FAILED = "Authentication Failed";
    String PARAMETER_MISSING = "Required String[] parameter 'flags' is not present";
    String ORG_ID_MISSING = "Missing request header 'org-id' for method parameter of type String";
    String ACCESS_DENIED = "Access is denied";
    String FLAGS_CREATED = "Flags created successfully";
    String MISSING_BODY = "Required request body is missing: public com.savvas.core.rest.RestResponse com.savvas.organization.web.OrganizationController.setOrganizationFlags(java.lang.String,com.pst.lms.dto.OrgSettings) throws java.lang.Exception";
    String INVALID_BODY_VALUE = "Values for Organization Settings are invalid";
    String VALID_RESPONSE_MSG = "Message response is correct and valid";
    String INVALID_RESPONSE_MSG = "Message is not expected value and invalid";

    String UNAUTHORIZED_MESSAGE = "UNAUTHORIZED";
    String UNAUTHORIZED_401 = "401: Unauthorized";
    String FORBIDDEN_403 = "403: Forbidden";
    String FAILED = "failed";

    // AssignmentAPI
    public static String TEACHER_ID = "teacherID";
    public static String ORG_ID = "orgID";
    public static String STUDENT_RUMBA_IDS = "studentRumbaIds";
    public static String STUDENT_RUMBA_GRADE_IDS = "studentRumbaIds_Grades";
    public static String STATUS = "status";

    //Attributes
    public static String USERS_TYPE = "users";
    public static String GROUPS_TYPE = "groups";
    public static String ASSIGNMENT_COURSE_ID = "courseID";
    public static String ASSIGNMENT_USER_ID = "assignmentUserID";

    public static String CREATE_ASSIGNMENT_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courses/{courseID}/assign";
    public static String DELETE_ASSIGNMENT_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courseassignments/{contentbaseId}";
    public static String ASSIGN_MULTIPLE_ASSIGNMENTS_API = "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courses/assign";
    public static String COURSE_IDS = "courseIds";

    String INVALID_MESSAGE_FOR_USERID = "Invalid value passed for userId";
    String INVALID_MESSAGE_FOR_ORGID = "Invalid value passed for organizationId";
    String ORGANIZATION_NAME = "organizationName";
    String SHARED = "shared";
    String ASSIGNED = "assigned";
    String NOT_FOUND_404 = "404: Not Found";
}
