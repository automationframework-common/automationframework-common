package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class RemoveStudentFromAssignmentsTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    String studentDetails;
    String studentDetailsSecond;
    String studentDetailsThree;
    String studentSMDetails;
    String studentSMDetailsSecond;
    String studentSMDetailsThree;
    private HashMap<String, String> groupDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String token = null;
    List<String> expectedCourseTypesInDropdown = Arrays.asList( "Focus Courses", "Default Courses", "Custom Courses",
			"All Courses", "My Custom Courses" );

    @BeforeClass (alwaysRun = true)
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse(  teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentDetails = RBSDataSetup.getMyStudent(school, username);
        studentDetailsSecond = RBSDataSetup.getMyStudent(school, username);
        studentDetailsThree = RBSDataSetup.getMyStudent(school, username);

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsThree, "userId" ) );

      //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

      //Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

    }

    @Test ( description = "Verify the 'Assignment Details' page displays with all the students assigned to the assignments on clicking 'View Assignment' button", enabled = true, priority = 1, groups = { "SMK-40869", "removeStudent", "assignmentDetailsPage" } )
    public void tc_RemoveStudentFromAssignments001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_RemoveStudentFromAssignments001: Assignment Details' page displays with all the students assigned to the assignments on clicking 'View Assignment' button. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Login to the SM_Application
        	LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
         	TeacherHomePage tHomePage = new TeacherHomePage(driver);

         	boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
         	Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Navigate to courseWare tab and Courses
            tHomePage.topNavBar.getCourseListingPage();

            // Select Math Course
            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickMathCourse();
            coursepage.clickAssignBtn();
            coursepage.addCourseToStudents();

            // Navigate to 'Assignments' page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            SMUtils.logDescriptionTC( "SMK-9450- Verify the 'Assignment Details' page displays with all the students" );
            // Clicking on 'view Assignments' button
            assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.MATH );

            // Verification of getting Assignment Details Page
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver ).get();

            SMUtils.logDescriptionTC( "SMK-9451- Verify the title of the Assignment Details Page is correct" );
            // Verification of Assignment Title
            Log.assertThat( assignmentDetailsPage.gettitleOfAssignmentDetailsPage().trim().equals( Constants.MATH ), "Assignment Title is displayed", "Assignment Title is not displayed" );

            SMUtils.logDescriptionTC( "SMK-9454- Verify that the number of active and inactive students displayed are correct." );
            // Verification of Assignment Sub-Title
            Log.assertThat(
                    ( assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage().contains( Constants.ACTIVE_STUDENTS_ASSIGMENT_SUBTITILE )
                            && assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage().contains( Constants.PAUSED_STUDENTS_ASSIGMENT_SUBTITILE ) ),

                    "Assignment SubTitle (Active Students and Paused Students) is displayed", "Assignment SubTitle (Active Students and Paused Students) is not displayed" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that all students assigned to the particular assignment are listed", enabled = true, priority = 1, groups = { "SMK-40869", "removeStudent", "assignmentDetailsPage" } )
    public void tc_RemoveStudentFromAssignments002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_RemoveStudentFromAssignments002: Verify that all students assigned to the particular assignment are listed. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Login to the SM_Application
        	LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
         	TeacherHomePage tHomePage = new TeacherHomePage(driver);

         	boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
         	Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to students tab and get the all students list
            StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();
            Map<String, List<String>> studentDetailsFromStudentTab = studentPage.getColumnDetailsAsList();
            List<String> studenListFromStudentTab = new ArrayList<>();
            CoursesPage customCourses = new CoursesPage( driver );

            IntStream.range( 0, studentDetailsFromStudentTab.get( Constants.FIRSTNAME ).size() ).forEach( studentValue -> {
                String studentFN = studentDetailsFromStudentTab.get( Constants.FIRSTNAME ).get( studentValue );
                String studentLN = studentDetailsFromStudentTab.get( Constants.LASTNAME ).get( studentValue );
                studenListFromStudentTab.add( customCourses.completeStudentName( studentFN, "", studentLN ) );
            } );

            // Navigate to courseWare tab and Courses
            tHomePage.topNavBar.getCourseListingPage();

            // Select Focus course
            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickCourseName( Constants.READING );

            // Clicking on 'Assign-Widget' and assigning
            coursepage.clickAssignBtn();

            SMUtils.logDescriptionTC( "SMK-9453 : Verify that all students assigned to the particular assignment" );
            // Assigning all students to Particular Course
            coursepage.addCourseToStudents();

            // Navigate 'CourseWare' tab and select the 'Assignments' option
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment
            assignmentsPage.clickAssignmentSubMenu();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.READING );

            SMUtils.logDescriptionTC( "SMK-9452 - Verify that the list of students displayed belongs to the specific assignment" );
            List<String> studentsFromAssignmentPage = assignmentDetailsPage.getStudentFNLNListfromAssignementDetails();
            Log.assertThat( SMUtils.sortList( studentsFromAssignmentPage ).equals( SMUtils.sortList( studenListFromStudentTab ) ), "Assigned students are displayed in Assignments Table", "Assigned students are not displayed in Assignments Table" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that the Elipses menu(...) available for each student is clickable.", enabled = true, priority = 1, groups = { "SMK-40869", "removeStudent", "assignmentDetailsPage" } )
    public void tc_RemoveStudentFromAssignments003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
    	

        Log.testCaseInfo( "tc_RemoveStudentFromAssignments003 :Verify that the Elipses menu(...) available for each student is clickable.. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Login to the SM_Application
        	LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
         	TeacherHomePage tHomePage = new TeacherHomePage(driver);

         	boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
         	Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to courseWare tab and Courses
            tHomePage.topNavBar.getCourseListingPage();

            // Select Focus course
            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickCourseName( Constants.SM_FOCUS_READING_GRADE1 );

            // Clicking on 'Assign-Widget' and assigning
            SMUtils.nap(3);
            coursepage.clickAssignBtn();
            SMUtils.nap(3);
            coursepage.addCourseToStudents();

            // Navigate 'CourseWare' tab and select the 'Assignments' option
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment
            SMUtils.nap(3);
            assignmentsPage.clickAssignmentSubMenu();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_READING_GRADE1 );

            // To get the student list in assignment details page
            List<String> studentsUI = assignmentDetailsPage.getStudentListfromAssignementDetails();

            SMUtils.logDescriptionTC( "SMK-9455 Verify that the Elipses menu(...) available for each student is clickable." );
            SMUtils.logDescriptionTC( "Verify the 'Action Menu' is getting disappeared on clicking Eclipse icon second time in Assignment details page" );

            // Clicking on Ellipsis icon at the student level for each student
            SMUtils.nap(3);
            studentsUI.forEach( name -> {
                Log.softAssertThat( assignmentDetailsPage.getAllEllipsisOptionAtStudentLevel( name ).equals( Constants.STUDENT_LEVEL_ASSIGNMENT_ELLIPSIS_OPTION ), "Ellipsis is clicked for the students ", "Ellispe is not clicked for the students" );
            } );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify when the teacher clicks on the ellipse icon the teacher is able to view the dropdown option", priority = 1, groups = { "SMK-40869", "removeStudent", "assignmentDetailsPage" } )
    public void tc_RemoveStudentFromAssignments004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_RemoveStudentFromAssignments004: Verify the Student level Elipses options . <small><b><i>[" + browser + "]</b></i></small>" );

        try {
        	LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
         	TeacherHomePage tHomePage = new TeacherHomePage(driver);

         	boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
         	Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            // Navigate to courseWare tab and Courses
            tHomePage.topNavBar.getCourseListingPage();

            // Select Math Course
            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickMathCourse();
            coursepage.clickAssignBtn();
            coursepage.addCourseToStudents();

            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage(); // Navigate to 'Assignments' page

            // Clicking on 'view Assignments' button
            assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.MATH );

            // Verification of getting Assignment Details Page
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver ).get();

            SMUtils.logDescriptionTC( "SMK-9457 : Verify that clicking on Elipses menu(...) while the options are displayed, closes the options dropdown" );
            assignmentDetailsPage.clickDotEllipsisButton(); // Clicking Dot ellipsis on First time
            assignmentDetailsPage.clickDotEllipsisButton(); // Clicking Dot ellipsis on second time
            Log.assertThat( !assignmentDetailsPage.getStudentRemoveEllipsis().isDisplayed(), "Student Level Ellispsis is Closed", "Student Level Ellispsis is not Closed" );

            SMUtils.logDescriptionTC( "SMK-9456 : Verify that when you click on the Elipses menu, then options are displayed" );
            // Getting all the Ellipsis options at the student level
            assignmentDetailsPage.clickDotEllipsisButton();
            Log.assertThat( assignmentDetailsPage.fluencyFilesInEllipsis().contains( Constants.FLUENCY_FILES ), "Fluency_Files option is displayed", "Fluency_Files option is not displayed" );
            Log.assertThat( assignmentDetailsPage.assignmentSettingInEllipsis().equals( Constants.ASSIGMENT_SETTINGS ), "Assignment_Settings option is displayed", "Assignment Settings option is not displayed" );
            Log.assertThat( assignmentDetailsPage.pauseAssignmentForStudentTabInEllipsis().equals( Constants.PAUSE_ASSIGNMENT_FOR_STUDENTS ), "Pause_Assignment_For_Student option is displayed", "Pause_Assignment_For_Student option is not displayed" );
            Log.assertThat( assignmentDetailsPage.removeStudentTabInEllipsis().equals( Constants.REMOVE_STUDENTS ), "Remove_Student option is displayed", "Remove_Student option is not displayed" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Remove student in view assignmnet details page", enabled = true, priority = 1, groups = { "SMK-40869", "removeStudent", "assignmentDetailsPage" } )
    public void tc_RemoveStudentFromAssignments005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_RemoveStudentFromAssignments005: Remove student in view assignmnet details page. <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // Login to the SM_Application
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
         	TeacherHomePage tHomePage = new TeacherHomePage(driver);

         	boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
         	Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            String studentFNLN = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetails, "lastName" );
            CoursesPage coursepage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursepage.clickCourseName( Constants.SM_FOCUS_READING_GRADE3 );// Select Focus course

            // Clicking on 'Assign-Widget' and assigning
            SMUtils.nap(3);
            coursepage.clickAssignBtn();
            SMUtils.nap(3);
            coursepage.addCourseToStudents();

            // Navigate 'CourseWare' tab and select the 'Assignments' option
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment
            SMUtils.nap(3);
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_READING_GRADE3 );

            SMUtils.logDescriptionTC( "SMK-9459 : Verify that the Remove Student link is clickable" );
            assignmentDetailsPage.removeStudentTab();
            SMUtils.nap(3);
            Log.assertThat( assignmentDetailsPage.checkCancelbuttonremoveStudent(), "Remove Student option is clickable", "Remove Student option is not clickable" );

            SMUtils.logDescriptionTC( "SMK-9460 : Verify the confirmation popup displays when the user click on the Remove Student link from the Elipses(...) menu" );
            SMUtils.logDescriptionTC( "SMK-9463 : Verify that the Remove Student confirmation popup contains the correct information about the student to be removed." );
            Log.assertThat( assignmentDetailsPage.isRemoveStudentAssignmentPopupDisplayed().contentEquals( Constants.REMOVE_STUDENT_POPUP_HEADSUP_TEXT ), "Remove Student pop-up is displayed with all components",
                    "Remove Student pop-up is not getting displayed properly" );

            SMUtils.logDescriptionTC( "SMK-9461 : Verify that the Remove Student confirmation popup is closed, when we click on Close(X) button" );
            SMUtils.nap(3);
            assignmentDetailsPage.clickCloseRemoveStudentPopup();
            Log.assertThat( !assignmentDetailsPage.checkCancelbuttonremoveStudent(), "Remove Student Popup is closed successfully after clicking of Close icon", "Remove Student Popup is not closed after clicking of Close icon" );

            SMUtils.logDescriptionTC( "SMK-9462: Verify the student is not removed from the list when the user click on 'Cancel' button" );
            SMUtils.nap(3);
            assignmentDetailsPage.removeStudentTab();
            SMUtils.nap(3);
            assignmentDetailsPage.clickCancelButtononRemoveStudentpopup();
            Log.assertThat( !assignmentDetailsPage.checkCancelbuttonremoveStudent(), "Remove Student Popup is closed successfully after clicking of cancel button",
                    "Remove Student Popup is not closed after clicking of cancel button" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that you are able to remove both active and inactive(Paused) students.", priority = 1, groups = { "SMK-40869", "removeStudent", "assignmentDetailsPage" } )
    public void tc_RemoveStudentFromAssignments006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_RemoveStudentFromAssignments006: SMK-9466 - Verify that you are able to remove both active and inactive(Paused) students. <small><b><i>[\" + browser + \"]</b></i></small>\" " );

        try {
        	LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
         	TeacherHomePage tHomePage = new TeacherHomePage(driver);

         	boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
         	Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            String studentFNLN = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetails, "lastName" );

         	// Get Assignments Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            assignmentsPage.clickAssignmentSubMenu();
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickOnTheHoveredAssignment( Constants.MATH );

            // Verifying the Remove_Student (active student)
            assignmentDetailsPage.removeStudentFromAssignment( studentFNLN );
            Log.assertThat( !assignmentDetailsPage.getStudentListfromAssignementDetailsTable().contains( studentFNLN ), "Mentioned (active) student is removed from Assignment",
                    "Mentioned (active) student is not removed from Assignment" );

            // Verify Pause for one student
            SMUtils.nap(3);
            assignmentDetailsPage.pauseAssignmentForStudentTabInEllipsis();
            assignmentDetailsPage.pauseAssignmentForStudentTab();
            assignmentDetailsPage.clickPauseButtononPopUpPage();
            Log.assertThat( assignmentDetailsPage.isAssignmentPaused(), "Assignment paused successfully", "Assignment has not Paused" );

            // Verifying the Remove_Student (inactive student)
            SMUtils.nap(3);
            assignmentDetailsPage.removeStudentTab();
            SMUtils.logDescriptionTC( "SMK-10224 : Verify the \"Remove\" button color in Remove Student from Assignment popup for teacher user" );
            Log.assertThat( assignmentDetailsPage.verifyColorCodeRemoveBtnForAssignment(), "Delete button color code is displayed as " + Constants.BUTTON_COLOR_CODE, "Delete button color code is not displayed as " + Constants.BUTTON_COLOR_CODE );
            SMUtils.nap(3);
            assignmentDetailsPage.removeStudent();
            Log.assertThat( !assignmentDetailsPage.getStudentListfromAssignementDetailsTable().contains( studentFNLN ), "Mentioned (inactive) student is removed from Assignment",
                    "Mentioned (inactive) student is not removed from Assignment" );

            // SignOut from SM
            tHomePage.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Remove all the student in assignment details page", enabled = true, priority = 1, groups = { "SMK-40869", "removeStudent", "assignmentDetailsPage" } )
    public void tc_RemoveStudentFromAssignments007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_RemoveStudentFromAssignments007: Remove all the student in assignment details page <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // Login to the SM_Application
        	LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
         	TeacherHomePage tHomePage = new TeacherHomePage(driver);

         	boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
         	Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            List<String> assignmentNames = new ArrayList<>();
//            String studentDetails = DataSetup.teacherStudentMap.get( username ).get( "Student1" );
            String studentFNLN = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetails, "lastName" );

            // Select Focus course
            CoursesPage coursepage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursepage.clickCourseName( Constants.SM_FOCUS_READING_GRADE4 );

            // Clicking on 'Assign-Widget' and assigning
            coursepage.clickAssignBtn();
            coursepage.addCourseToStudents();

            // Navigate 'CourseWare' tab and select the 'Assignments' option
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_READING_GRADE4 );

            // Removing all the students from assignment
            assignmentDetailsPage.removeStudentForEachStudent();
            tHomePage.topNavBar.navigateToAssignmentsPage();
            assignmentNames = assignmentsPage.getAllAssignmentNames();
            Log.assertThat( !assignmentNames.contains( Constants.SM_FOCUS_READING_GRADE4 ), "Assignment has deleted successfully", "Assignment has not deleted successfully" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the user able to remove the student after modified the Assignment settings", enabled = true, priority = 1, groups = { "SMK-40869", "removeStudent", "assignmentDetailsPage" } )
    public void tc_RemoveStudentFromAssignments008() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tc_RemoveStudentFromAssignments008: SMK-9475: Verify the user able to remove the student after modified the Assignment settings. <small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // Login to the SM_Application
        	LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
         	TeacherHomePage tHomePage = new TeacherHomePage(driver);

         	boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
         	Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            String studentFNLN = SMUtils.getKeyValueFromResponse( studentDetails, "firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentDetails, "lastName" );

            // Navigate to courseWare tab and Courses
            SMUtils.nap(3);
            tHomePage.topNavBar.getCourseListingPage();
            CoursesPage coursepage = new CoursesPage( driver );
            coursepage.clickCourseName( Constants.SM_FOCUS_READING_GRADE3 );// Select Focus course

            // Clicking on 'Assign-Widget' and assigning
            coursepage.clickAssignBtn();
            SMUtils.nap(3);
            coursepage.addCourseToGroups();

            // Navigate 'CourseWare' tab and select the 'Assignments' option
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Clicking on View Assignment
            assignmentsPage.clickAssignmentSubMenu();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.SM_FOCUS_READING_GRADE3 );

            // Clicking on Ellipsis at studentLevel and AssignmentSettings option
            assignmentDetailsPage.clickAssignmentSetting();

            SMUtils.logDescriptionTC( "SMK-7241 - Edit Assignment settings in the view assignmnet details page." );
            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED ); // Editing the values using Assignment settings
            assignmentDetailsPage.clickSaveButton();
            SMUtils.nap( 2 ); //To wait for Page to load
            //Remove the student after editing
            assignmentDetailsPage.removeStudentFromAssignment( studentFNLN );
            Log.assertThat( !assignmentDetailsPage.getStudentListfromAssignementDetailsTable().contains( studentFNLN ), "Mentioned student removed", "Mentioned student not removed" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
