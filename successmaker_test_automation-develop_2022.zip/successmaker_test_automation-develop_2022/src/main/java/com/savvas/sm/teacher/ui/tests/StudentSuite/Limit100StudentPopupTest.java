package com.savvas.sm.teacher.ui.tests.StudentSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.StopWatch;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.ReportAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.GetGroupListAPI;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentDetailsForStudentIdAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This is used to test Popup for "Limit the 100 student or less in you Group"
 * and Student Id Test For Stories "SMK-56783", "SMK-57260" Popup Error in UI
 * And Solar search Group search
 *
 * @author suriya.kumar
 *
 */

public class Limit100StudentPopupTest extends UserAPI {

    private String smUrl;
    private String browser;
    private String username;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public ArrayList<String> GroupNames = new ArrayList<>();
    public ArrayList<String> studentUsernames = new ArrayList<>();

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;
    // Object
    AtomicReference<String> schoolUsed = new AtomicReference<>();
    private long startTime;
    public ArrayList<String> studentIdList= new ArrayList<>();
    GroupAPI groupApi = new GroupAPI();
    private ArrayList<String> teacherGroupNames;
    private ArrayList<String> teacherGroupId;
    private String orgId;
    private String teacherId;
    private String secondTeacherUsername;
    private String secondTeacherId;

    AtomicReference<String> readingSchool = new AtomicReference<>();
    private String readingSchoolId;
    private String readingSchoolTeacherUsername;
    private Object readingSchoolTeacherId;
    private String readingSchoolStudentUsername;
    private Object readingSchoolStudentId;
    private String districtId;

    @BeforeTest
    public void BeforeTest() {

        startTime = StopWatch.startTime();
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );

        // Teacher used Details
        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        orgId = RBSDataSetup.organizationIDs.get( schoolUsed.get() );
        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ));
        String teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

        // Getting student details for the Teacher
        ArrayList<String> studentDetails = new ArrayList<>();
        int StudentCount = Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) );

        IntStream.range( 0, StudentCount ).forEach( count -> {
            studentDetails.add( RBSDataSetup.getMyStudent( schoolUsed.get(), username ) );
        } );



        IntStream.range( 0, StudentCount ).forEach( counter -> {
            studentIdList.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERID ) );
            studentUsernames.add( SMUtils.getKeyValueFromResponse( studentDetails.get( counter ), RBSDataSetupConstants.USERNAME ) );
        } );

        // Getting GroupId of the Teacher
        HashMap<String, String> response = new HashMap<>();
        HashMap<String, String> apiDetails = new HashMap<>();
        try {
            String accessToken = new RBSUtils().getAccessToken( username, password );
            apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
            apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            apiDetails.put( GroupConstants.STAFF_ID, teacherId );
            response = groupApi.getGroupListingForTeacherID( smUrl, apiDetails );
            Log.message( "GroupListing respone: " + response.toString() );

            JSONObject jsonObject = new JSONObject( response.get( Constants.REPORT_BODY ) );
            JSONArray array = jsonObject.getJSONArray( CreateGroupAPIConstants.DATA );

            teacherGroupNames = new ArrayList<>();
            teacherGroupId = new ArrayList<>();

            IntStream.range( 0, array.length() ).forEach( iter -> {
                String eachObject = array.getJSONObject( iter ).toString();
                teacherGroupNames.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_NAME ) );
                teacherGroupId.add( SMUtils.getKeyValueFromResponse( eachObject, GetGroupListAPI.GROUP_ID ) );
            } );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        Log.message( "The teachers studentusernames is :"+studentUsernames.toString() );
        Log.message( "The teachers GroupNames is :"+teacherGroupNames.toString() );

        // Second Teacher for Data Setup purposes
        secondTeacherUsername = "teacher165454d57d19" +  districtId.substring( 25, 31 )+"@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        String teacherdetailsCreate = null;
        try {
            if ( !new RBSUtils().isUserExits( secondTeacherUsername, orgId ) ) {
                teacherdetailsCreate = new UserAPI().createUserWithCustomization( secondTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
            }
            secondTeacherId = new RBSUtils().getUserIDByUserName( secondTeacherUsername );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        // Other School Details
        readingSchool.set( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) );
        readingSchoolId = RBSDataSetup.organizationIDs.get( readingSchool.get() );

        //teacher create
        readingSchoolTeacherUsername = "teacher165d593d153" +  districtId.substring( 25, 31 )+ "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        readingSchoolTeacherId = null;
        try {
            if ( !new RBSUtils().isUserExits( readingSchoolTeacherUsername, readingSchoolId ) ) {
                teacherdetailsCreate = new UserAPI().createUserWithCustomization( readingSchoolTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( readingSchoolId ) );
            }
            readingSchoolTeacherId = new RBSUtils().getUserIDByUserName( readingSchoolTeacherUsername );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        readingSchoolStudentUsername = "teacher165566d9153" +  districtId.substring( 25, 31 )+"@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        readingSchoolStudentId = null;
        try {
            if ( !new RBSUtils().isUserExits( readingSchoolStudentUsername, readingSchoolId ) ) {
                teacherdetailsCreate = new UserAPI().createUserWithCustomization( readingSchoolTeacherUsername, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( readingSchoolId ) );
            }
            readingSchoolStudentId = new RBSUtils().getUserIDByUserName( readingSchoolStudentUsername );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

    }

    @AfterClass
    public void enofExecution() {
        long totalTime = StopWatch.elapsedTime( startTime );
        long sec = totalTime % 60;
        long min = ( totalTime / 60 ) % 60;
        Log.message( "=====================================================" );
        Log.message( " Student Limit to 100 and Solar Search Result class Ran for : " + min + " minute (s)" + ":" + sec + " seconds (s)" );
    }

    @Test ( description = "Student and Group Limit 100 Scenarios Test", groups = { "Students", "SMK-56783", "SMK-57260" }, priority = 1, enabled = true)
    public void tcPopupErrorMessage001( ITestContext context ) throws Exception {

        // Creating Test Data
        int count = 105;
        List<String> StudentIds = null;

        // Teacher create
        username = "teachert1655280d8974" + "_" + "@" +  districtId.substring( 25, 31 )+smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        try {
            if ( !new RBSUtils().isUserExits( username, orgId ) ) {
                new UserAPI().createTeacherAndResetPassword( orgId, username );
            }
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }
        String teacherId = new RBSUtils().getUserIDByUserName( username );

        String accessToken = new RBSUtils().getAccessToken( username, password );
        Log.message( "Teacher having 100 plus Group and Student :" + username );

        IntStream.rangeClosed( 1, count ).forEach( index -> {
            Log.message( "Student creating and enrolling in class of : " + index + "/" + count );
            String studentId = null;
            // Student create
            String studentName = "student16528012778974" + "_" + index +  districtId.substring( 25, 31 )+"@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );

            try {
                if ( !new RBSUtils().isUserExits( studentName, orgId ) ) {
                    String studentDetails = new UserAPI().createUserWithCustomization( studentName, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                }
                // new BaseAPITest().updateGrade( studentId, "random" );
            } catch ( Exception e1 ) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            studentId = new RBSUtils().getUserIDByUserName( studentName );

            //  enorlled in one class
            String groupName = "group" + ( index + 1 ) + "_" + System.nanoTime();
            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, teacherId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, orgId );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            try {
                new com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( studentId ) );
            } catch ( Exception e ) {}
            GroupNames.add( groupName );
            studentUsernames.add( studentName );

        } );

        // Student filter by using grade
        ArrayList<String> gradeStudents = new ArrayList<>();
        String studentconst = "165232491"+ districtId.substring( 25, 31 );
        gradeStudents.add( "student" + studentconst + "1" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" ) );
        gradeStudents.add( "student" + studentconst + "2" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" ) );
        gradeStudents.add( "student" + studentconst + "2" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" ) );
        gradeStudents.add( "student" + studentconst + "4" + "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" ) );

        // Student creation
        gradeStudents.forEach( username -> {
            try {
                if ( !new RBSUtils().isUserExits( username, orgId ) ) {
                    String studentDetails = new UserAPI().createUserWithCustomization( username, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
                    new SMUtils();
                    String studentId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
                    // new BaseAPITest().updateGrade( studentId, "G03" );
                }
            } catch ( Exception e ) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);

        SMUtils.logDescriptionTC( "" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Selecting all  101 Student
            JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
            String scriptForSelectingStudent = "const count = 101 ; const nodeList = document.querySelectorAll('tbody cel-checkbox.hydrated'); for ( let i=0 ; i <count; i++ ) { nodeList[i].shadowRoot.querySelector('label  span').click(); }";
            javascriptExecutor.executeScript( scriptForSelectingStudent );

            studentsPage.clickGroupButtoninStudentLisitngPage();
            Thread.sleep( 2000 );
            SMUtils.logDescriptionTC( " Verify in UI in the Student Listing page given selected 100 plus Students and Selected Groups" );
            // Error message Verification of Add Student to Group
            Log.assertThat( studentsPage.VerifyLimitStudentTo100Popup(), "The Pop Message is correct!", "The Pop Message is not correct!" );
            studentsPage.clickOkButton();

            studentsPage.selectAllStudents();
            // Adding 100 Students into 100 plus Groups
            // Selecting all Student
            String scriptForSelecting100Students = "const count = 100 ; const nodeList = document.querySelectorAll('tbody cel-checkbox.hydrated'); for ( let i=0 ; i <count; i++ ) { nodeList[i].shadowRoot.querySelector('label  span').click(); }";
            javascriptExecutor.executeScript( scriptForSelecting100Students );
            studentsPage.clickGroupButtoninStudentLisitngPage();

            // Add Button
            Thread.sleep( 2000 );
            String scriptForClickingAddButton = "const nodeList = document.querySelectorAll('div.add-button cel-button'); for ( let i=0 ; i <nodeList.length; i++ ) { nodeList[i].shadowRoot.querySelector('button').click(); }";
            javascriptExecutor.executeScript( scriptForClickingAddButton );

            studentsPage.clickSaveButtonOnAddStudentToGroupPopup();
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            Log.assertThat( studentsPage.VerifyToastMessageForAddStudentToGroup(), "The student is added into Group", "The student is not added into Group" );

            // Groups Tab checking
            GroupPage grouppage = tHomePage.topNavBar.navigateToGroupsTab();

            tHomePage.topNavBar.navigateToGroupsTab();
            grouppage.viewGroup( GroupNames.get( 0 ) );
            SMUtils.logDescriptionTC( " Verify in UI in Groups - Users Add Student to Groups Modal window given that 100 plus  student is added" );
            grouppage.clickAddStudentToGroup();
            grouppage.addNameInTextField( "Student" );
            Thread.sleep( 2000 );
            new SMUtils();
            SMUtils.waitForSpinnertoDisapper( driver, 60 );

            // Add Button
            SMUtils.logDescriptionTC( " Verify in UI if the create Group Modal will not create group with 100 plus  Students" );
            scriptForClickingAddButton = "const nodeList = document.querySelectorAll('div.add-button cel-button'); const count = 101 ; for ( let i=0 ; i <count; i++ ) { nodeList[i].shadowRoot.querySelector('button').click(); }";
            javascriptExecutor.executeScript( scriptForClickingAddButton );

            // Verification of Error message
            SMUtils.logDescriptionTC( "Verify the teacher can able to see validation message when the teacher adds more then 100 students." );
            SMUtils.logDescriptionTC( " Verify user cannot  able to add the 100+ users in the text box and then user can save." );
            Log.assertThat( grouppage.errorMessageForLimit100Students.getText().equals( GroupPage.PLEASE_LIMIT_THE_100_STUDENT_TO_YOUR_GROUP_ERROR ), "The error message is correct!", "The error message is not correct!" );
            grouppage.clickBackIcon();

            // In Create Group Test
            grouppage.clickCreateGroup();
            grouppage.enterGroupNameinPopup( "Group" );
            grouppage.addNameInTextField( "Student" );
            Thread.sleep( 2000 );
            new SMUtils();
            SMUtils.waitForSpinnertoDisapper( driver, 60 );

            // Add Button
            scriptForClickingAddButton = "const nodeList = document.querySelectorAll('div.add-button cel-button'); const count = 101 ; for ( let i=0 ; i <count; i++ ) { nodeList[i].shadowRoot.querySelector('button').click(); }";
            javascriptExecutor.executeScript( scriptForClickingAddButton );

            // Verification of Error message
            Log.assertThat( grouppage.errorMessageForLimit100Students.getText().equals( GroupPage.PLEASE_LIMIT_THE_100_STUDENT_TO_YOUR_GROUP_ERROR ), "The error message is correct!", "The error message is not correct!" );
            grouppage.clickCancelButtonOnCreateGroupPopup();

            Thread.sleep( 2000 );
            SMUtils.logDescriptionTC( " Verify in UI if the create Group Modal will create group with Empty Students" );
            String groupName = "Group without Students" + System.nanoTime();
            grouppage.createGroupWithoutStudent( groupName );
            Log.assertThat( grouppage.isGroupExist( groupName ), "The Group Created is present", "The Group Created is not present" );
            SMUtils.logDescriptionTC( " Verify in UI if the create Group Modal will create group with one Students" );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupName = "Groupwith 1 Student" + System.nanoTime();
            grouppage.createGroup( groupName, Arrays.asList( studentUsernames.get( 0 ) ) );
            Log.assertThat( grouppage.isGroupExist( groupName ), "The Group Created is present", "The Group Created is not present" );

            SMUtils.logDescriptionTC( "Verify the group is not created with more than 100+ Users" );
            // In Create Group Test
            grouppage.clickCreateGroup();
            SMUtils.logDescriptionTC( " Verify in UI if the create Group Modal will create group with 100 Students" );
            groupName = "Group with 100 Students" + System.nanoTime();
            grouppage.enterGroupNameinPopup( groupName );
            grouppage.addNameInTextField( "Student" );
            Thread.sleep( 2000 );
            new SMUtils();
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
            SMUtils.logDescriptionTC( " Verify in UI in Add Students to the Groups Modal window given that 100 Student is added to 100 plus Group" );
            scriptForClickingAddButton = "const nodeList = document.querySelectorAll('div.add-button cel-button'); const count = 101 ;for ( let i=0 ; i <count; i++ ) { nodeList[i].shadowRoot.querySelector('button').click(); }";
            javascriptExecutor.executeScript( scriptForClickingAddButton );
            grouppage.clickCreateGroupButtoninPopup();

            // create a group by filtering the student of Grade
            SMUtils.logDescriptionTC( " Verify user can able to add the student into the  group by adding Filtering the grade" );
            SMUtils.logDescriptionTC( " Verify user can able to add the student into the  group in which the student is not part of any group" );
            grouppage.clickCreateGroup();
            groupName = "Group With Grade" + System.nanoTime();
            grouppage.enterGroupNameinPopup( groupName );

            SMUtils.logDescriptionTC( "Verify the teacher can able to filter the students with grade while creating the group." );
            grouppage.clickGradeDropdowninCreateNewGroupPopup();
            grouppage.FilterGradeandAddStudents( StudentDetailsForStudentIdAPIConstants.GRADE_NAME.get( 3 ), gradeStudents );
            grouppage.clickCreateGroupButtoninPopup();

            Log.assertThat( grouppage.isGroupExist( groupName ), "The Group created is Exist", "The Group created is not Exist" );
            tHomePage.topNavBar.clickSignOut();

            Log.testCaseResult();
        } catch ( Exception e ) {

            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "StudentId is optional Test", groups = { "Students", "SMK-56783", "SMK-57260" }, priority = 2, enabled = true)
    public void tcPopupErrorMessage002( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            studentsPage.clickAddStudent();
            SMUtils.logDescriptionTC( " Verify the Student has a studentIdentification number is empty by default of the Student for basic user" );

            studentsPage.enterOnlyStudentDetails();
            SMUtils.logDescriptionTC( " Verfiy the student can be created without the StudentIdentification number in basic" );
            studentsPage.txtboxStudentID.clear();
            studentsPage.clickAddStudentinAddStudentPopup();
            SMUtils.waitForSpinnertoDisapper( driver, 5 );
            SMUtils.waitForElement( driver, studentsPage.popupHeader );
            Log.assertThat( studentsPage.popupHeader.getText().trim().equals( StudentsPage.STUDENTS_ADDED_SUCCESSFULLY ), "The Student is created", "The Student is not created" );
            studentsPage.clickCloseButton();

            studentsPage.clickviewStudentByEllipsis( studentUsernames.get( 0 ) );
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            String studentIdupdated = "StudentId1" + System.nanoTime();
            SMUtils.logDescriptionTC( " Verify the Basic student's studentIdentification number can be updated with user input" );
            studentsPage.changeStudentId( studentIdupdated );
            String updated = studentsPage.getStudentId();
            Log.assertThat( updated.equals( studentIdupdated ), "The studentId can be updated with the string", "The studentId cannot be updated with the string" );

            // update with empty
            studentsPage.clickSubNavigation( Constants.Students.LIST_OF_SUBNAVIGATION.get( 2 ) );
            studentsPage.clickSubNavigation( Constants.Students.NAVIGATE_USER_PROFILE );
            SMUtils.logDescriptionTC( " Verfiy the Basic student user id can be updated with empty value" );
            studentsPage.clearStudentIdField();
            studentsPage.clickSaveButtoninUserProfile();
            Log.assertThat( studentsPage.getStudentId().equals( "" ), "The studentId can be updated with the empty string", "The studentId cannot be updated with the empty string" );

            tHomePage.topNavBar.clickSignOut();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "StudentId is optional Test", groups = { "Students", "SMK-56783", "SMK-57260" }, priority = 2 , enabled = true)
    public void tcSolarSearch01( ITestContext context ) throws Exception {
        String suffixStudent = studentUsernames.get( 0 ).substring( 0, 4 );

        // Creating a New Student
        String studentUsernameCreate = "student446436d362341" +  districtId.substring( 25, 31 )+"@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        String studentDetailsCreate = null;
        String studentIdCreate = null;
        try {
            if ( !new RBSUtils().isUserExits( studentUsernameCreate, orgId ) ) {
                studentDetailsCreate = new UserAPI().createUserWithCustomization( studentUsernameCreate, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
            }
            studentIdCreate = new RBSUtils().getUserIDByUserName( studentUsernameCreate );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            GroupPage grouppage = tHomePage.topNavBar.navigateToGroupsTab();

            grouppage.clickCreateGroup();
            String groupName = "Group With Grade" + System.nanoTime();

            SMUtils.logDescriptionTC(
                    "Verify the teacher should see the add student field indication as 'To search for students in your school, start typing their username or given name. You can also select a grade from the 'All Grades' drop-down list to refine your search results.'" );
            Log.assertThat( grouppage.verifySkillsNameIsPresent(), "The message is valid in create group", "The message is not valid in create group" );

            grouppage.enterGroupNameinPopup( groupName );
            grouppage.addStudentTxtBox.sendKeys( suffixStudent );
            waitForSpinnerandDisapper( driver );

            SMUtils.logDescriptionTC( "Verify the teacher can able to see all the grades from K to 12 and Not specified." );
            grouppage.clickGradeDropdowninCreateNewGroupPopup();
            Log.assertThat( grouppage.verifyGradeDropdown(), "The Grade Dropdown value in the Create Group Popup is matched", "The Grade Dropdown value in the Create Group Popup is not matched" );
            grouppage.clickGradeDropdowninCreateNewGroupPopup();
            HashMap<String, HashMap<String, String>> studentDetailsResultinSolarSearch = grouppage.getStudentDetailsResultinSolarSearch();
            SMUtils.logDescriptionTC( "Verify the teacher can able to see the students with firstname,Lastname,username and grade while creating the group." );
            SMUtils.logDescriptionTC( "Verify the teacher can able to see the students while adding the group." );
            SMUtils.logDescriptionTC( "Verify the teacher can able to see the students which is not part of the group." );
            Log.assertThat( studentDetailsResultinSolarSearch.size() > 0, "The Student Details is displayed correctly", "The Student Details is not displayed correctly" );

            // Removing the student by remove button
            SMUtils.logDescriptionTC( "Verify the teacher can able to see the student single time only." );
            grouppage.addSelectedStudents( studentUsernames.get( 0 ) );
            grouppage.removeSelectedStudent( studentUsernames.get( 0 ) );

            // Removing the student by x button
            grouppage.addSelectedStudents( studentUsernames.get( 0 ) );

            SMUtils.logDescriptionTC( "Verify the teacher can able to remove the student by X icon in chip text." );
            grouppage.clickXinChipAreaForStudent( "Karl Murray" );

            // Clicking Add button and Remove Button for 100 Student
            SMUtils.logDescriptionTC( "Verify the teacher can see remove button for the students which is added" );
            grouppage.addStudentTxtBox.clear();
            grouppage.addStudentTxtBox.sendKeys( suffixStudent );
            waitForSpinnerandDisapper( driver );
            grouppage.clickAddButtonForNTimes( 100 );
            grouppage.clickRemoveButtonForNTimes( 100 );

            SMUtils.logDescriptionTC( "Verify the teacher can able to see the newly created student in list while adding the student into group." );
            Log.assertThat( grouppage.addSelectedStudents( studentUsernameCreate ), "The Newly created Student is present on the solar search", "The Newly created Student is not present on the solar search" );

            grouppage.clickCancelButtonInCreateGroup();

            tHomePage.topNavBar.clickSignOut();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Students From org Test", groups = { "Students", "SMK-56783", "SMK-57260" }, priority = 2 ,enabled = true)
    public void tcSolarSearch02( ITestContext context ) throws Exception {

        SMUtils.logDescriptionTC( "Verify the teacher can able to see all the students when from the organization while creating the group." );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            GroupPage grouppage = tHomePage.topNavBar.navigateToGroupsTab();

            grouppage.viewGroup( teacherGroupNames.get( 0 ) );
            grouppage.clickAddStudentToGroup();
            SMUtils.logDescriptionTC( "Verify the teacher can not see the students when the students are already part of the group." );
            Log.assertThat( !grouppage.isStudentFoundInSolarSearch( studentUsernames.get( 0 ) ), "The Student is found in the Solar Search", "The Student is not found in the Solar Search" );
            Thread.sleep( 1000 );
            grouppage.clickCancelButtoninAddStudentToGroupPopup();
            grouppage.clickBackIcon();
            SMUtils.waitForElementToBeClickable( grouppage.btnCreateNewGroup, driver );
            grouppage.clickCreateGroup();

            Log.assertThat( grouppage.isStudentFoundInSolarSearch( SMUtils.getRandomVariableFromArrayList( getStudentList( orgId ) ) ), "The Student is found in the Solar Search", "The Student is not found in the Solar Search" );

            String suffixStudent = studentUsernames.get( 0 ).substring( 0, 4 );

            String groupName = "Group With Grade" + System.nanoTime();
            grouppage.enterGroupNameinPopup( groupName );
            grouppage.addStudentTxtBox.clear();

            SMUtils.logDescriptionTC( "Verify the teacher can see the validation error message while giving the search string as 2 or less" );
            Log.assertThat( grouppage.verifyErrorForStudentSearchLessThan3(), "The Error message is valied For student search less than 2", "The Error message is not valid For student search less than 2" );
            grouppage.addStudentTxtBox.clear();
            grouppage.addStudentTxtBox.sendKeys( suffixStudent );
            waitForSpinnerandDisapper( driver );
            final ArrayList<String> StudentNames = new ArrayList<>();

            List<WebElement> elements = grouppage.listOfStudentNamesSolarSearchResult;

            for ( WebElement element : elements ) {
                StudentNames.add( element.getText().trim() );
            }

            ArrayList<String> javaSortedNames = new ArrayList<>( StudentNames );
            Collections.sort( javaSortedNames );

            Log.assertThat( javaSortedNames.equals( StudentNames ), "The Student Sorting order is matched", "The Student Sorting order is not matched Actual" + StudentNames.toString() + " Expected" + javaSortedNames.toString() );
            grouppage.clickGradeDropdowninCreateNewGroupPopup();
            grouppage.selectGradeFromAddStudPopup( "Grade 1" );
            waitForSpinnerandDisapper( driver );
            final HashMap<String, HashMap<String, String>> studentDetailAfterGradeFilter = grouppage.getStudentDetailsResultinSolarSearch();
            StudentNames.clear();

            for ( WebElement element : grouppage.listOfStudentNamesSolarSearchResult ) {
                StudentNames.add( element.getText().trim() );
            }

            javaSortedNames = new ArrayList<>( StudentNames );
            Collections.sort( javaSortedNames );

            Log.assertThat( javaSortedNames.equals( StudentNames ), "The Student Sorting order is matched", "The Student Sorting order is not matched Actual" + StudentNames.toString() + " Expected" + javaSortedNames.toString() );

            grouppage.clickCancelButtonInCreateGroup();

            tHomePage.topNavBar.clickSignOut();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "StudentId is optional Test", groups = { "Students", "SMK-56783", "SMK-57260" }, priority = 2 ,enabled = true)
    public void tcSolarSearch03( ITestContext context ) throws Exception {
        String suffixStudent = studentUsernames.get( 0 ).substring( 0, 4 );

        SMUtils.logDescriptionTC( "Verify the teacher can able to see the zero state when the school does not have any students while creating the group." );

        String orgName = "SuccessMaker Organization Without Students 1654859403186";
        String orgIdNoStudent = null;

        try {
            orgIdNoStudent = new RBSUtils().getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), orgName );
        } catch ( Exception e ) {}

        if ( orgIdNoStudent == null ) {
            HashMap<String, String> orgDetails = new HashMap<>();
            orgDetails.put( RBSDataSetupConstants.ORGANIZATION_NAME, orgName );
            orgDetails.put( RBSDataSetupConstants.ORGANIZATION_TYPE, RBSDataSetupConstants.ORGANIZATION_TYPE_SCHOOL );
            orgDetails.put( RBSDataSetupConstants.SCHOOL_ID, new RBSUtils().createOrg( orgDetails ) );
            Log.message( "Created School - " + orgDetails.get( RBSDataSetupConstants.ORGANIZATION_NAME ) );
            orgDetails.put( RBSDataSetupConstants.DISTRICT_ID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
            new RBSUtils().relateOrganization( orgDetails );
            orgIdNoStudent = orgDetails.get( RBSDataSetupConstants.SCHOOL_ID );
        }

        //teacher create
        String teacherUsernameCreate = "teacher16548d6345459" +  districtId.substring( 25, 31 )+"@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        String teacherdetailsCreate = null;
        String teacherIdCreate = null;
        try {
            if ( !new RBSUtils().isUserExits( teacherUsernameCreate, orgIdNoStudent ) ) {
                teacherdetailsCreate = new UserAPI().createUserWithCustomization( teacherUsernameCreate, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgIdNoStudent ) );
            }
            teacherIdCreate = new RBSUtils().getUserIDByUserName( teacherUsernameCreate );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( teacherUsernameCreate, password, true );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            GroupPage grouppage = tHomePage.topNavBar.navigateToGroupsTab();

            grouppage.clickCreateGroup();

            String groupName = "Group With Grade" + System.nanoTime();
            grouppage.enterGroupNameinPopup( groupName );
            grouppage.addStudentTxtBox.clear();
            grouppage.addStudentTxtBox.sendKeys( suffixStudent );
            waitForSpinnerandDisapper( driver );

            Log.assertThat( grouppage.gradeNotSelectedErrMsg.isDisplayed(), "The Student is not found in the Solar Search", "The Student is found in the Solar Search" );

            tHomePage.topNavBar.clickSignOut();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Student is suspended and Deleted", groups = { "Students", "SMK-56783", "SMK-57260" }, priority = 2,enabled = true )
    public void tcSolarSearch04( ITestContext context ) throws Exception {

        // Creating a New Student
        String studentSuspend = "student16334535578" +  districtId.substring( 25, 31 )+"@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        String studentDetailsCreate = null;
        String studentIdSuspened = null;

        try {
            if ( !new RBSUtils().isUserExits( studentSuspend, orgId ) ) {
                studentDetailsCreate = new UserAPI().createUserWithCustomization( studentSuspend, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
            }
            studentIdSuspened = new RBSUtils().getUserIDByUserName( studentSuspend );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        // Creating a New Student
        String studentDelete = "student163454445107" + districtId.substring( 25, 31 )+ "@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        studentDetailsCreate = null;
        String studentIdSDeleted = null;
        try {
            if ( !new RBSUtils().isUserExits( studentDelete, orgId ) ) {
                studentDetailsCreate = new UserAPI().createUserWithCustomization( studentDelete, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( orgId ) );
            }
            studentIdSDeleted = new RBSUtils().getUserIDByUserName( studentDelete );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            GroupPage grouppage = tHomePage.topNavBar.navigateToGroupsTab();

            grouppage.clickCreateGroup();

            String groupName = "Group With Grade" + System.nanoTime();
            grouppage.enterGroupNameinPopup( groupName );

            SMUtils.logDescriptionTC( "Verify the teacher can see suspended students in the list." );
            new RBSUtils().suspendUser( Arrays.asList( studentIdSuspened ) );

            AtomicReference<Boolean> flag = new AtomicReference<>();
            flag.set( false );
            IntStream.rangeClosed( 0, 3 ).forEach( index ->{
                flag.set( grouppage.isStudentFoundInSolarSearch( studentSuspend ));
                SMUtils.nap( 3 );
                grouppage.addStudentTxtBox.clear();
            });

            Log.assertThat( !flag.get(), "The Student is found in the Solar Search", "The Student is not found in the Solar Search" );
            grouppage.clickCancelButtonInCreateGroup();

            grouppage.clickCreateGroup();
            SMUtils.logDescriptionTC( "Verify the teacher can not see the deleted students in the list. " );
            new RBSUtils().deleteUser( Arrays.asList( studentIdSDeleted ) );
            Log.assertThat( !grouppage.isStudentFoundInSolarSearch( studentDelete ), "The Student is not found in the Solar Search", "The Student is found in the Solar Search" );

            tHomePage.topNavBar.clickSignOut();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Multiple school Teacher", groups = { "Students", "SMK-56783", "SMK-57260" }, priority = 2,enabled = true)
    public void tcSolarSearch05( ITestContext context ) throws Exception {
        String suffixStudent = studentUsernames.get( 0 ).substring( 0, 4 );

        SMUtils.logDescriptionTC( "Verify the teacher can see only students from selected schools when the teacher has multiple school." );

        //teacher create
        String mulitpleSchoolTeacherUn = "teacher11d3d71288" +  districtId.substring( 25, 31 )+"@" + smUrl.substring( 8 ).replaceAll( "[^a-zA-Z0-9]", "" ).replace( "smdemoinfo", "" );
        String teacherdetailsCreate = null;
        String teacherIdCreate = null;
        try {
            if ( !new RBSUtils().isUserExits( mulitpleSchoolTeacherUn, orgId ) ) {
                teacherdetailsCreate = new UserAPI().createUserWithCustomization( mulitpleSchoolTeacherUn, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId, readingSchoolId ) );
            }
            teacherIdCreate = new RBSUtils().getUserIDByUserName( mulitpleSchoolTeacherUn );
        } catch ( Exception e1 ) {
            e1.printStackTrace();
        }

        new RBSUtils().resetPassword( orgId, password, teacherIdCreate );

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
        	LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
        	TeacherHomePage tHomePage = smLoginPage.loginToSM( mulitpleSchoolTeacherUn, password, true );

            // Navigate to Students Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            GroupPage grouppage = tHomePage.topNavBar.navigateToGroupsTab();
            grouppage.clickCreateGroup();

            String groupName = "Group With Grade" + System.nanoTime();
            grouppage.enterGroupNameinPopup( groupName );
            grouppage.addStudentTxtBox.clear();
            grouppage.addStudentTxtBox.sendKeys( suffixStudent );
            waitForSpinnerandDisapper( driver );

            Log.assertThat( grouppage.isStudentFoundInSolarSearch( SMUtils.getRandomVariableFromArrayList( getStudentList( orgId ) ) ), "The Student is found in the Solar Search", "The Student is not found in the Solar Search" );
            SMUtils.logDescriptionTC( "Verify the teacher cannot able to see the students from other school while creating the group." );

            // Will not list the Already added Student into Group
            Log.assertThat( !grouppage.isStudentFoundInSolarSearch( readingSchoolStudentUsername ), "The Student is found in the Solar Search", "The Student is not found in the Solar Search" );

            tHomePage.topNavBar.clickSignOut();
            Log.testCaseResult();


        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    public void waitForSpinnerandDisapper( WebDriver driver ) {
        try {
            SMUtils.waitForLocator( driver, By.cssSelector( SMUtils.spinnerElement ), 3 );
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
        } catch ( InterruptedException e ) {}
    }

    /**
     * To get all the StudenUsernames Details From the OrgIds
     *
     * @param orgIds
     * @return
     */
    public List<String> getStudentList( String orgId ) {
        Log.message( "Getting Student usernames.." );
        ArrayList<String> studentUsernames = new ArrayList<>();
        JSONArray teacherJsonArray = new RBSUtils().getAllStudentsForOrg( orgId );
        if ( !teacherJsonArray.equals( new JSONArray() ) ) {
            for ( Object user : teacherJsonArray ) {
                JSONObject userJson = new JSONObject( user.toString() );
                studentUsernames.add( userJson.get( ReportAPIConstants.TNS_USESRNAME ).toString() );
            }
        }
        Log.message( "Student details done" );
        return studentUsernames;
    }

}