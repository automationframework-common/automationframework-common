package com.savvas.sm.api.tests.smnew.courses;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * This class is used to test the delete course API
 *
 * @author Subbu
 */

public class CreateCustomCourseBySkill extends CourseAPI {

    public static final EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private final String orgUsed = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String smUrl;
    String teacherUsed;
    String orgId;
    String teacherId;
    String username;
    String accessCode;
    RBSUtils rbsutils = new RBSUtils();
    String createcourseId = null;
    Map<String, String> response = null;
    Map<String, String> responseFrom_AssignCourse = null;
    private String CourseId;
    // AssignmentAPI assignmentAPI;
    CourseAPI courseAPI;
    String StudentId;
    String flexSchoolStudentDetails;
    AssignmentAPI assignmentObg = new AssignmentAPI();
    HashMap<String,String> mathGradeStandardDetails = new HashMap<String,String>();
    HashMap<String,String> readingGradeStandardDetails = new HashMap<String,String>();
    HashMap<String,String> mathGradeSkillDetails = new HashMap<String,String>();
    HashMap<String,String> readingGradeSkillDetails = new HashMap<String,String>();

    @BeforeClass(alwaysRun=true)
    public void InitializedSchoolData() throws IOException {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        teacherUsed = RBSDataSetup.getMyTeacher( orgUsed );
        JSONObject teacherJson = new JSONObject( teacherUsed );
        teacherId = new SMAPIProcessor().getKeyValues( teacherJson, RBSDataSetupConstants.USERID ).get( 0 );
        username = new SMAPIProcessor().getKeyValues( teacherJson, RBSDataSetupConstants.USERNAME ).get( 0 );
        flexSchoolStudentDetails = RBSDataSetup.getMyStudent( orgUsed, username );
        courseAPI = new CourseAPI();
        
        //To get Random Skill and Standard ID's for Math and Reading Courses
    	mathGradeSkillDetails = SqlHelperCourses.getSCOIDsOfRandomSkillID(Constants.MATH);
    	while( readingGradeSkillDetails.get("LOName")==null || readingGradeSkillDetails.get("LOName").isEmpty() || readingGradeSkillDetails.get("LOName").startsWith("_") ) {
        	readingGradeSkillDetails = SqlHelperCourses.getSCOIDsOfRandomSkillID(Constants.READING); 
        	}
    }

    @Test ( dataProvider = "CreateCustomCourseBySkillPositiveScenarios", groups = { "SMK-52108", "Create Custom Course By Skill", "Course", "P1", "API", "smoke_test_case" } )
    public void createCourseBySkillPositiveScenarios( String description, String scenario, String statusCode, String gradeId, String courseId, String parentNode, String ChildNode, String status, String message ) throws Exception {
        Log.testCaseInfo( description );
        Map<String, String> courseDetails = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        Map<String, String> response = new HashMap<>();
        StudentId = SMUtils.getKeyValueFromResponse( flexSchoolStudentDetails, "userId" );

        // Authorization
        accessCode = rbsutils.getAccessToken( SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.USERID_SM_HEADER, teacherId );
        courseDetails.put( Constants.GRADE_VALUE, gradeId );
        courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
        courseDetails.put( CourseAPIConstants.PARENT_NODE, parentNode );
        courseDetails.put( CourseAPIConstants.CHILD_NODE, ChildNode );
        courseDetails.put( Constants.COURSE_NAME, "Skills" + System.nanoTime() );
        response = createCourseBySkill( smUrl, headers, courseDetails, scenario );
        // String customCourseId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,id" );
        Log.message( "response from POST Call - " + response );

        switch ( scenario ) {
            case "Assign_Course":

                //Assigning a newly created course to student
                List<String> studentRumbaIdsTc001 = new ArrayList<>();

                //Adding students to group
                studentRumbaIdsTc001 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, accessCode, orgUsed );

                //Assigning assignment to student
                addAssignmentsToStudents( CommonAPIConstants.STATUS_CODE_OK, courseId, orgUsed, studentRumbaIdsTc001.get( 0 ) );

                courseDetails.put( Constants.COURSE_NAME, "Skills" + System.nanoTime() );
                response = createCourseBySkill( smUrl, headers, courseDetails, scenario );
                // response = courseAPI.createCourseBySkill( smUrl,  token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL,  String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() )  );
                Log.message( "response from POST Call for assigned course - " + response );
                break;
        }

        // Validations
        if ( response != null ) {
            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Response status code is as expected - " + response.get( "statusCode" ), "Response status code is not as expected - " + response.get( "statusCode" ) );
            verifyResponse( response.get( Constants.REPORT_BODY ), message, status );
            createcourseId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,id" );
            Log.message( "createcourseId=" + createcourseId );
            // Verify the created course is available in the Organization
            verifyCourseAvailable( teacherId, orgId, createcourseId, status, message );
        } else {
            Log.fail( "Create Course by Skill Response is null" );
        }

       
    }

    @Test ( dataProvider = "CreateCustomCourseBySkillNegativeScenarios", groups = { "SMK-52108", "Create Custom Course By Skill", "Course", "P1", "API" } )
    public void createCourseBySkillNegativeScenarios( String description, String scenario, String statusCode, String gradeId, String courseId, String parentNode, String ChildNode, String status, String message ) throws Exception {
        Log.testCaseInfo( description );
        Map<String, String> courseDetails = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        // Authorization
        accessCode = rbsutils.getAccessToken( SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        Map<String, String> response = null;
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.USERID_SM_HEADER, teacherId );
        if ( scenario.equalsIgnoreCase( "NULL_COURSE_NAME_READING" ) ) {
            courseDetails.put( Constants.COURSE_NAME, "" );

        } else if ( scenario.equalsIgnoreCase( "INVALID_ORG_ID_READING" ) ) {
            courseDetails.put( Constants.COURSE_NAME, "Skills" + System.nanoTime() );
            headers.put( Constants.ORGID_SM_HEADER, CourseAPIConstants.INVALID_ORG_ID_CONSTANT_VALUE );

        } else if ( scenario.equalsIgnoreCase( "INVALID_STAFF_ID_READING" ) ) {
            courseDetails.put( Constants.COURSE_NAME, "Skills" + System.nanoTime() );
            headers.put( Constants.USERID_SM_HEADER, CourseAPIConstants.INVALID_ORG_ID_CONSTANT_VALUE );
        } else if ( scenario.equalsIgnoreCase( "DUPLICATE_COURSE_NAME" ) ) {
            courseDetails.put( Constants.COURSE_NAME, "SM Focus Reading: Grade 1" );
        } else {
            courseDetails.put( Constants.COURSE_NAME, "Skills" + System.nanoTime() );

        }
        courseDetails.put( Constants.GRADE_VALUE, gradeId );
        courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
        courseDetails.put( CourseAPIConstants.PARENT_NODE, parentNode );
        courseDetails.put( CourseAPIConstants.CHILD_NODE, ChildNode );
        response = createCourseBySkill( smUrl, headers, courseDetails, scenario );
        Log.message( "response from POST Call - " + response );

        // Validations
        if ( response != null ) {
            Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "Response status code is as expected - " + response.get( "statusCode" ), "Response status code is not as expected - " + response.get( "statusCode" ) );
//            verifyResponse( response.get( Constants.REPORT_BODY ), message, status );
            createcourseId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "data,id" );
            Log.message( "createcourseId=" + createcourseId );
            // Verify the created course is available in the Organization
            verifyCourseAvailable( teacherId, orgId, createcourseId, status, message );
        } else {
            Log.fail( "Create Course by Skill Response is null" );
        }

//        Log.testCaseResult();
    }

    @DataProvider ( name = "CreateCustomCourseBySkillPositiveScenarios" )
    public Object[][] createCoursevalidData() {
        Object[][] inputData = { { "TC001_Validate the response 201 when use valid teacher credentials", "CREATE_COURSE_MATH", "201", mathGradeSkillDetails.get("GradeID"), "1", mathGradeSkillDetails.get("ParentNode"), mathGradeSkillDetails.get("LOName"), "success", "Operation succeeded!" },
                { "TC004_Validate  the response 201 when the course is already assigned", "Assign_Course", "201", mathGradeSkillDetails.get("GradeID"), "1", mathGradeSkillDetails.get("ParentNode"), mathGradeSkillDetails.get("LOName"), "success", "Operation succeeded!" },
                { "TC002_Validate the response 201 when Org is having only Math licence and when give valid Math Course Id", "CREATE_COURSE_MATH", "201", mathGradeSkillDetails.get("GradeID"), "1", mathGradeSkillDetails.get("ParentNode"), mathGradeSkillDetails.get("LOName"), "success", "Operation succeeded!" },
                { "TC003_Validate the response 201 when Org is having only Reading licence and when give valid Reading Course Id", "CREATE_COURSE_READING", "201", readingGradeSkillDetails.get("GradeID"), "2", readingGradeSkillDetails.get("ParentNode"), readingGradeSkillDetails.get("LOName"), "success", "Operation succeeded!" }, };

        return inputData;
    }

    @DataProvider ( name = "CreateCustomCourseBySkillNegativeScenarios" )
    public Object[][] createCourseInvalidData() {

        Object[][] inputData = { { "TC005_Validate the response 200 invalid taxonomy", "CREATE_COURSE_MATH", "200", "6", "1", "588", "SMMA_LO_01771_583", "failure", "Leaf node id: 588 not found in cache" },
                { "TC006_Validate the response 400 Without Los", "CREATE_COURSE_MATH", "400", "6", "1", "533", "", "failure", "Invalid Los found for leaf Node id : 533" },
                { "TC007_Validate error 400 for the change grade ID", "CREATE_COURSE_MATH", "400", "8", "1", "533", "SMMA_LO_01771_533", "failure", "Leaf Node id in request: 533 is not related to given grade id :8" },
                { "TC008_Validate the response 400 with null course id", "READING", "400", "3281", "null", "4891", "smre_di_02533_4891", "failure",
                        "Failed to convert value of type 'java.lang.String' to required type 'java.lang.Long'; nested exception is java.lang.NumberFormatException" },
                { "TC009_Validate the response 200 with invalid course id", "CREATE_COURSE_READING", "200", "3281", "14238", "4891", "smre_di_02533_4891", "failure", "Course Id : 14238 not found in Organization id" },
                { "TC010_Validate the response 400 for null course name", "NULL_COURSE_NAME_READING", "400", "6", "1", "533", "SMMA_LO_01771_533", "failure", "newCourseName can not be null or empty" },
                { "TC011_Validate the response 401 for incorrect staff id", "INVALID_STAFF_ID_READING", "401", "6", "1", "533", "SMMA_LO_01771_533", "failure", "Authentication Failed" },
                { "TC013_Validate the response 403 for invalid  org id", "INVALID_ORG_ID_READING", "403", "6", "1", "533", "SMMA_LO_01771_533", "failure", "Access is denied" },
                { "TC015_Validate the response 200 when the Standard Los are submitted instead of Skill Los", "CREATE_COURSE_MATH", "200", "6", "1", "1000028370", "SMMA_LO_01098_1000028370", "failure", "Leaf node id: 1000028370 not found in cache" },
                { "TC016_Verify C400 POST call to validate the error for duplicate course name test", "DUPLICATE_COURSE_NAME", "400", "6", "1", "533", "SMMA_LO_01771_533", "failure",
                        "A course with given courseName :SM Focus Reading: Grade 1 already exists.." },
                { "TC017_Validate C400 when the incorect Los are submitted instead of relevant Skill Los", "CREATE_COURSE_MATH", "200", "6", "1", "1000028370", "SMMA_LO_01098_1000028370", "failure", "Leaf node id: 1000028370 not found in cache" }

        };
        return inputData;
    }

    //Adding Students to group
    public List<String> addStudentsToGroup( String statusCode, String userName, String school ) {
        HashMap<String, String> response;
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        try {
            //Adding students to group
            String groupName = "Successmaker API Test Group " + System.nanoTime();
            studentRumbaIds.add( StudentId );
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, userName );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherUsed, "userId" ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            Log.message( "groupDetails is " + groupDetails );
            GroupAPI GroupAPI = new GroupAPI();
            response = GroupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );
            Log.message( "response for group creation is " + response );
            Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        } catch ( Exception e ) {
            Log.message( "Issue occured in addStudentsToGroup" );
        }
        return studentRumbaIds;
    }

    //Assigning assignment to student
    public void addAssignmentsToStudents( String statusCode, String courseId, String school, String studentRumbaId ) {
        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( studentRumbaId );
        try {
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessCode );
            assignmentDetails.put( CourseAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherUsed, "userId" ) );
            assignmentDetails.put( CourseAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            assignmentDetails.put( CourseAPIConstants.COURSE_ID, courseId );
            HashMap<String, String> assignCourseToTheStudent = assignmentObg.assignAssignment( smUrl, assignmentDetails, studentRumbaIds, AssignmentAPIConstants.USERS_TYPE );
            if ( assignCourseToTheStudent.get( Constants.STATUS_CODE ).equals( statusCode ) ) {
                Log.message( "Course has been assigned to the student!" );
            } else {
                Log.message( "Something went wrong while assigning the course to the student! - " + assignCourseToTheStudent.get( Constants.REPORT_BODY ) );
            }
        } catch ( Exception e ) {
            Log.message( "Issue occured in addAssignmentsToStudents" );
        }
    }

    /**
     * Get response for the Create Course By Skill API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public Map<String, String> createCourseBySkill( String envUrl, Map<String, String> headers, Map<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "READING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySkillsReading" ) ) );

            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySkillsMath" ) ) );

            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

    public void verifyResponse( String actualResponse, String message, String status ) {

        try {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
                Log.pass( CommonAPIConstants.COURSE_DELETE_SUCCESS_MESSAGE );
            } else {
                Log.fail( CommonAPIConstants.COURSE_DELETE_FAILURE_MESSAGE );
            }
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( status ) ) {
                Log.pass( CommonAPIConstants.COURSE_DELETE_SUCCESS_STATUS );
            } else {
                Log.fail( CommonAPIConstants.COURSE_DELETE_FAILURE_STATUS );
            }

        } catch ( Exception e ) {
            Log.message( "Error in verifyResponse method" );
        }

    }

    public void verifyCourseAvailable( String teacherId, String orgId, String courseId, String status, String message ) {
        try {
            // Endpoint
            String endpoint = CourseAPIConstants.CUSTOM_COURSE_SETTINGS;
            endpoint = endpoint.replace( Constants.ORG_ID, orgId );
            endpoint = endpoint.replace( Constants.STAFF_ID, teacherId );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseId );

            // headers
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + accessCode );
            headers.put( Constants.ORGID_SM_HEADER, orgId );
            headers.put( Constants.USERID_SM_HEADER, teacherId );
            response = RestHttpClientUtil.GET( smUrl, endpoint, headers, new HashMap<>() );

            if ( response != null ) {
                Log.assertThat( response.get( Constants.STATUS_CODE ).equals( "200" ), "Course is available as expected", "Course is not available" );
                verifyResponse( response.get( Constants.REPORT_BODY ), message, status );
            } else {
                Log.fail( "verifyCourseAvailable Response is null" );
            }

        } catch ( Exception e ) {
            Log.message( "Error in verifyCourseAvailable method" );
        }
    }

    /**
     * Get response for the Create Course By Setting API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySetting( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySetting= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "READING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsReadingPayload" ) ) );

            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCourseBySettingsMathPayload" ) ) );
            }

            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySetting method" );
            return null;
        }
    }
}
