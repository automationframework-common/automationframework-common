package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.TimeZone;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.SkillTested;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class SkillsTestedAPITest extends AssignmentAPI {
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String smUrl;
    private String flexSchoolTeacherDetails;
    private String orgID;
    private String userID;
    private String studentDetail;
    private String studentUserID;
    private String studentUsername;
    private String teacherUsername;
    private String password;
    private String courseName;
    private String courseId;
    private String assignmentID;
    private String assignmentUserId;
    private boolean lastSessionValue;
    private String subject;
    RBSUtils rbsUtils = new RBSUtils();
    Map<String, String> assignmentResponse = new HashMap<>();
    HashMap<String, String> groupdetails = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    Map<String, String> response = new HashMap<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        // Getting Teacher from flex School
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        userID = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        // Getting ORGID of Flex school
        orgID = RBSDataSetup.organizationIDs.get( flexSchool );
        // Getting Students from Flex school
        studentDetail = RBSDataSetup.getMyStudent( flexSchool, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( dataProvider = "positiveData", priority = 1, groups = { "smoke_test_case", "SMK-55763", "Assignments", "SkillsTested", "API" } )

    public void skillsTestedPositiveTest( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        String currentDate = "";
        String accessToken = new RBSUtils().getAccessToken( teacherUsername, password );
        // Creating Group to add the student to assign assignment
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, userID );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgID );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );

        Log.testCaseInfo( testcaseID + " - " + testDescription );
        switch ( scenario ) {
            case "valid with no sessions attended":
                // Create a custom course for the flex teacher
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

                // Create Assignment and assign to a student
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
                lastSessionValue = true;
                subject = DataSetupConstants.MATH;
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, new ArrayList<>() );
                break;
            case "valid with single LO attended":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, courseName, true, "100", "1", "1" );
                lastSessionValue = true;
                subject = DataSetupConstants.MATH;
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, new ArrayList<>() );
                break;

            case "valid with no LO attended":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                lastSessionValue = true;
                subject = DataSetupConstants.MATH;
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, new ArrayList<>() );
                break;
            case "valid with multiple LO attended":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, courseName, true, "100", "1", "10" );
                lastSessionValue = true;
                subject = DataSetupConstants.MATH;
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, new ArrayList<>() );
                break;
            case "valid with custom Math last session":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, courseName, true, "100", "1", "10" );
                lastSessionValue = true;
                subject = DataSetupConstants.MATH;
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, new ArrayList<>() );
                break;
            case "valid with custom Math current date":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, courseName, true, "100", "1", "2" );
                subject = DataSetupConstants.MATH;
                lastSessionValue = false;
                currentDate = getCurrentDate();
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, Arrays.asList( currentDate ) );
                break;
            case "valid with custom Math current date and last session":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, courseName, true, "100", "1", "5" );
                subject = DataSetupConstants.MATH;
                lastSessionValue = true;
                currentDate = getCurrentDate();
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, Arrays.asList( currentDate ) );
                break;
            case "valid with default math last session":

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, AssignmentAPIConstants.MATH_COURSE, true, "100", "1", "5" );
                subject = DataSetupConstants.MATH;
                lastSessionValue = true;
                currentDate = "";
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, new ArrayList<>() );
                break;
            case "valid with default reading last session":

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, AssignmentAPIConstants.READING_COURSE, false, "100", "1", "5" );
                lastSessionValue = true;
                currentDate = "";
                subject = DataSetupConstants.READING;
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, new ArrayList<>() );
                break;
            case "valid with custom Reading last session":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.READING, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_READING.json" );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, courseName, false, "100", "1", "5" );
                subject = DataSetupConstants.READING;
                lastSessionValue = true;
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, new ArrayList<>() );
                break;
            case "valid with custom Reading current date":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.READING, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_READING.json" );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, courseName, false, "100", "1", "2" );
                currentDate = getCurrentDate();
                lastSessionValue = false;
                subject = DataSetupConstants.READING;
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, Arrays.asList( currentDate ) );
                break;
            case "valid with custom Reading current date and last session":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.READING, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_READING.json" );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, courseName, false, "100", "1", "2" );
                currentDate = getCurrentDate();
                lastSessionValue = true;
                subject = DataSetupConstants.READING;
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, subject, assignmentUserId, lastSessionValue, Arrays.asList( currentDate ) );
                break;

            case "valid with student from teacher 1 to another":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, courseName, true, "100", "1", "1" );

                //Creating the teacher in the Same school
                String coTeacherUsername = "SchTeacher" + System.nanoTime();

                String coTeacherDetails = new UserAPI().createUserWithCustomization( coTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.organizationIDs.get( flexSchool ) ) );
                String coTeacherID = SMUtils.getKeyValueFromResponse( coTeacherDetails, RBSDataSetupConstants.USERID );

                //Creating group with existing student for above created teacher
                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), coTeacherID, Arrays.asList( studentUserID ), orgID, new RBSUtils().getAccessToken( coTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                lastSessionValue = true;
                subject = DataSetupConstants.MATH;
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, coTeacherID, new RBSUtils().getAccessToken( coTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ), studentUserID, assignmentID, subject, assignmentUserId,
                        lastSessionValue, new ArrayList<>() );
                break;

            case "valid with muliple school teacher":
                // Create a custom course for the flex teacher 
                courseName = "CustomSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

                // Create Assignment and assign to a student HashMap<String, String>
                assignmentDetails = new HashMap<>();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
                assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

                executeCourse( studentUsername, courseName, true, "100", "1", "1" );

                // multiple school teacher creation
                String multiSchoolT = "MultiSchTeacher" + System.nanoTime();
                UserAPI userAPIObj = new UserAPI();
                String multiSchoolTID = userAPIObj.createMultiOrgTeacher( Arrays.asList( orgID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) ), multiSchoolT );

                //group creation for the above created teacher
                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), multiSchoolTID, Arrays.asList( studentUserID ), orgID, new RBSUtils().getAccessToken( multiSchoolT, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                lastSessionValue = true;
                subject = DataSetupConstants.MATH;
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, multiSchoolTID, new RBSUtils().getAccessToken( multiSchoolT, RBSDataSetupConstants.DEFAULT_PASSWORD ), studentUserID, assignmentID, subject, assignmentUserId,
                        lastSessionValue, new ArrayList<>() );
                break;
            default:
                break;
        }

        Log.message( response.toString() );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        /*
         * if ( !scenario.equals( "valid with no sessions attended" ) ||
         * !scenario.equals( "valid with no LO attended" ) ) Log.assertThat( new
         * SMAPIProcessor().isSchemaValid( "skillsTested", statusCode,
         * response.get( "body" ) ) || new SMAPIProcessor().isSchemaValid(
         * "skillsTested_lastSession", statusCode, response.get( "body" ) ),
         * "Schema Validated for status code " + statusCode,
         * "Schema Validation failed for status code " + statusCode );
         */
        Map<String, Map<String, String>> db = new SqlHelperAssignment().getSkillsTested( assignmentUserId, subject, lastSessionValue, currentDate );
        Log.message( db.toString() );
        Map<String, Map<String, String>> sessionLOResponse = new HashMap<>();
        String currentDateValue = currentDate;
        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), "skillId" ) ).forEach( iter -> {
            Map<String, String> loDetails = new HashMap<String, String>();
            loDetails.put( "skillId", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "skillId", iter ) );
            loDetails.put( "skillName", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "skillName", iter ) );
            loDetails.put( "completedTotalLoAttempts", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "completedTotalLoAttempts", iter ) );
            loDetails.put( "completedTotalLoCorrect", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "completedTotalLoCorrect", iter ) );
            loDetails.put( "percentageCorrect", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "percentageCorrect", iter ) );

            if ( lastSessionValue && ( currentDateValue.equals( "" ) ) ) {
                loDetails.put( "lastSessionDate", SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "lastSessionDate", iter ) );
            }
            String loDet = SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "loDetails", iter );
            IntStream.range( 0, SMUtils.getWordCount( loDet, "catalogNum" ) ).forEach( iter1 -> {
                //                JSONObject js = new JSONObject(SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "", arrayIndex ));
                JSONArray arr = new JSONArray( loDet );
                JSONObject jso = arr.getJSONObject( iter1 );
                jso.get( "catalogNum" );
                if ( Objects.nonNull( loDetails.get( "catalogNum" ) ) ) {
                    loDetails.put( "catalogNum", loDetails.get( "catalogNum" ) + "," + jso.get( "catalogNum" ) );
                } else {
                    loDetails.put( "catalogNum", jso.get( "catalogNum" ).toString() );
                }
            } );
            sessionLOResponse.put( SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "skillId", iter ), loDetails );
        } );

        Log.message( sessionLOResponse.toString() );

        /*
         * Log.assertThat( db.entrySet().stream().allMatch( entry ->
         * SMUtils.compareTwoHashMap( entry.getValue(), sessionLOResponse.get(
         * entry.getKey() ) ) ), "API fetched all the skills tested properly",
         * "API is not fetching all the skills tested properly" );
         */
        Log.assertThat( db.entrySet().stream().allMatch( entry -> {
            if ( !entry.getValue().get( "skillId" ).equals( sessionLOResponse.get( entry.getKey() ).get( "skillId" ) ) ) {
                return false;
            }
            if ( !entry.getValue().get( "skillName" ).equals( sessionLOResponse.get( entry.getKey() ).get( "skillName" ) ) ) {
                return false;
            }
            if ( !entry.getValue().get( "completedTotalLoAttempts" ).equals( sessionLOResponse.get( entry.getKey() ).get( "completedTotalLoAttempts" ) ) ) {
                return false;
            }
            if ( !entry.getValue().get( "completedTotalLoCorrect" ).equals( sessionLOResponse.get( entry.getKey() ).get( "completedTotalLoCorrect" ) ) ) {
                return false;
            }
            if ( !entry.getValue().get( "completedTotalLoCorrect" ).equals( sessionLOResponse.get( entry.getKey() ).get( "completedTotalLoCorrect" ) ) ) {
                return false;
            }
            if ( !entry.getValue().get( "percentageCorrect" ).equals( sessionLOResponse.get( entry.getKey() ).get( "percentageCorrect" ) ) ) {
                return false;
            }
            if ( !entry.getValue().get( "catalogNum" ).equals( sessionLOResponse.get( entry.getKey() ).get( "catalogNum" ) ) ) {
                String[] split = entry.getValue().get( "catalogNum" ).split( "," );
                String[] split2 = sessionLOResponse.get( entry.getKey() ).get( "catalogNum" ).split( "," );
                if ( !Arrays.asList( split ).containsAll( Arrays.asList( split2 ) ) ) {
                    return false;
                }
            }
            if ( entry.getValue().containsKey( "lastSessionDate" ) ) {
                if ( !entry.getValue().get( "lastSessionDate" ).equals( sessionLOResponse.get( entry.getKey() ).get( "lastSessionDate" ) ) ) {
                    return false;
                }
            }
            return true;
        } ), "API fetched all the skills tested properly", "API is not fetching all the skills tested properly" );
        Log.testCaseResult();

    }

    @Test ( dataProvider = "negativeData", priority = 1, groups = { "SMK-55763", "Assignments", "SkillsTested", "API" } )
    public void skillsTestedNegativeTest( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        String accessToken = new RBSUtils().getAccessToken( teacherUsername, password );
        // Creating Group to add the student to assign assignment
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, userID );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgID );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );

        // Create a custom course for the flex teacher 
        courseName = "CustomSettingCourse" + System.nanoTime();
        courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

        // Create Assignment and assign to a student HashMap<String, String>
        assignmentDetails = new HashMap<>();
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
        assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );

        executeCourse( studentUsername, courseName, true, "100", "1", "1" );

        Log.testCaseInfo( testcaseID + " - " + testDescription );

        switch ( scenario ) {
            case "invalid with empty org-id in headers":
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, " ", userID, accessToken, studentUserID, assignmentID, DataSetupConstants.MATH, assignmentUserId, true, Arrays.asList() );
                break;
            case "invalid with invalid org-id in headers":
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID + "invalid", userID, accessToken, studentUserID, assignmentID, DataSetupConstants.MATH, assignmentUserId, true, Arrays.asList() );
                break;
            case "invalid with empty user-id in headers":
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, "", accessToken, studentUserID, assignmentID, DataSetupConstants.MATH, assignmentUserId, true, Arrays.asList() );
                break;
            case "invalid with invalid user-id in headers":
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID + "invalid", accessToken, studentUserID, assignmentID, DataSetupConstants.MATH, assignmentUserId, true, Arrays.asList() );
                break;

            case "invalid with organizationId /Staff as boolean/String":
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, DataSetupConstants.MATH, assignmentUserId, true, Arrays.asList() );
                String endPoint = "/lms/web/api/v1/organizations/" + "\"" + orgID + "\"" + "/staffs/" + userID + "/assignments/" + assignmentID + "/students/" + studentUserID + "/skillsTestedReport";
                Log.message( endPoint );
                // Creating headers for the API call
                Map<String, String> headers = new HashMap<>();
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                headers.put( Constants.USERID_SM_HEADER, userID );
                headers.put( Constants.ORGID_SM_HEADER, orgID );
                // Setting payload
                String subject = "1";
                String payload = "{ \"subjectTypeId\": subjectID,  \"assignmentUserId\": assignmentUserid,  \"sessionDates\": dates, \"lastSessionFlag\": lsBoolean}";
                payload = payload.replace( "subjectID", subject ).replace( "assignmentUserid", assignmentUserId ).replace( "dates", Arrays.asList().toString() ).replace( "lsBoolean", true + "" );
                Log.message( payload );
                response = RestHttpClientUtil.POST( smUrl, headers, new HashMap<>(), endPoint, payload );
                break;
            case "invalid with studentId /assignmentsId as boolean/String":
                response = new SkillTested().postSkillsTestedForAssignment( smUrl, orgID, userID, accessToken, studentUserID, assignmentID, DataSetupConstants.MATH, assignmentUserId, true, Arrays.asList() );
                endPoint = "/lms/web/api/v1/organizations/" + orgID + "/staffs/" + userID + "/assignments/" + "\"" + assignmentID + "\"" + "/students/" + studentUserID + "/skillsTestedReport";
                Log.message( endPoint );
                // Creating headers for the API call
                headers = new HashMap<>();
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + accessToken );
                headers.put( Constants.USERID_SM_HEADER, userID );
                headers.put( Constants.ORGID_SM_HEADER, orgID );
                // Setting payload
                subject = "1";
                payload = "{ \"subjectTypeId\": subjectID,  \"assignmentUserId\": assignmentUserid,  \"sessionDates\": dates, \"lastSessionFlag\": lsBoolean}";
                payload = payload.replace( "subjectID", subject ).replace( "assignmentUserid", assignmentUserId ).replace( "dates", Arrays.asList().toString() ).replace( "lsBoolean", true + "" );
                Log.message( payload );
                response = RestHttpClientUtil.POST( smUrl, headers, new HashMap<>(), endPoint, payload );
                break;

            default:
                break;
        }

        Log.message( response.toString() );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "skillsTested", statusCode, response.get( "body" ) ), "Schema Validated for status code " + statusCode, "Schema Validation failed for status code " + statusCode );

        Log.testCaseResult();

    }

    @DataProvider ( name = "positiveData" )
    public Object[][] getDataforPostive() {
        Object[][] data = { { "tcSkillTested001", "Verify the status code is 200 for fetching skill tested with session range LAST_SESSION when student is not attended any session so far", "200", "valid with no sessions attended" },
                { "tcSkillTested002", "Verify the status code is 200 for fetching skill tested with session range LAST_SESSION when student attended single LO during last session", "200", "valid with single LO attended" },
                { "tcSkillTested003", "Verify the status code is 200 for fetching skill tested with session range LAST_SESSION when student attended multiple LOs during last session", "200", "valid with multiple LO attended" },
                { "tcSkillTested004", "Verify the status code is 200 for fetching skill tested for Math custom course with session range LAST_SESSION", "200", "valid with custom Math last session" },
                { "tcSkillTested005", "Verify the status code is 200 for fetching skill tested for Math assignment with session range for current date", "200", "valid with custom Math current date" },
                { "tcSkillTested006", "Verify the status code is 200 for fetching skill tested for Math assignment with session range for last session and current date", "200", "valid with custom Math current date and last session" },
                { "tcSkillTested007", "Verify the status code is 200 for fetching skill tested for Math default course with session range LAST_SESSION", "200", "valid with default math last session" },
                { "tcSkillTested008", "Verify the status code is 200 for fetching skill tested for Reading default course with session range LAST_SESSION", "200", "valid with default reading last session" },
                { "tcSkillTested009", "Verify the status code is 200 for fetching skill tested for Reading custom course with session range LAST_SESSION", "200", "valid with custom Reading last session" },
                { "tcSkillTested0010", "Verify the status code is 200 for fetching skill tested for Reading assignment with session range for current date", "200", "valid with custom Reading current date" },
                { "tcSkillTested0011", "Verify the status code is 200 for fetching skill tested for Reading assignment with session range for last session and current date", "200", "valid with custom Reading current date and last session" },
                { "tcSkillTested0012", "Verify the status code is 200 for fetching skill tested for math assignment with session range LAST_SESSION when student attended LO, but not answered any questions during last session", "200",
                        "valid with no LO attended" },
                { "tcSkillTested0013", "Verify the status code is 200 and response should fetch correct LOs when student from other teacher attended LO assignment given by other teacher", "200", "valid with student from teacher 1 to another" },
                { "tcSkillTested0014", "Verify status code 200 for skill tested with session range LAST_SESSION when teacher is part of multiple school", "200", "valid with muliple school teacher" } };
        return data;
    }

    @DataProvider ( name = "negativeData" )
    public Object[][] getDataforNegative() {
        Object[][] data = { { "tcSkillTested0015", "Verify responce 403 when empty org-id passed in headers", "403", "invalid with empty org-id in headers" },
                { "tcSkillTested0016", "Verify responce 403 when invalid org-id passed in headers", "403", "invalid with invalid org-id in headers" },
                { "tcSkillTested0017", "Verify responce 401 when empty user-id passed in headers", "401", "invalid with empty user-id in headers" },
                { "tcSkillTested0018", "Verify responce 401 when invalid user-id passed in headers", "401", "invalid with invalid user-id in headers" },
                { "tcSkillTested0019", "Verify status code 400, when organizationId /Staff Id has pass as boolean or String data types", "400", "invalid with organizationId /Staff as boolean/String" },
                { "tcSkillTested0020", "Verify status code 400, when studentId /assignmentsId has pass as boolean or String data types", "400", "invalid with studentId /assignmentsId as boolean/String" } };
        return data;
    }

    /**
     * To execute the course
     *
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, String percentage, String numberOfSession, String loCount ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

    public String getCurrentDate() {
        TimeZone de = TimeZone.getDefault();

        TimeZone.setDefault( TimeZone.getTimeZone( "GMT-7" ) );
        Calendar cal = Calendar.getInstance();
        cal.setTime( new Date() );
        Date date = cal.getTime(); // converted date time
        System.out.println( date.toString() );
        SimpleDateFormat formatter = new SimpleDateFormat( "MM/dd/yyyy" );
        String sol = "\"" + formatter.format( date ) + "\"";
        // Set Back to System Default
        TimeZone.setDefault( de );

        return sol;
    }

}
