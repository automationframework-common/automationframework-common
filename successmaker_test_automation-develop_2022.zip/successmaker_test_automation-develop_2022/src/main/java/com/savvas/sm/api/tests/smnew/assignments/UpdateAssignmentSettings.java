package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class UpdateAssignmentSettings extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String flexSchoolTeacherDetails = null;
    private String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String token = null;
    String customCourseId = null;
    String orgID = null;
    String userID = null;
    private String assignmentID;
    private String AssignmentUserId;
    String sessionLengthName = null;
    Long sessionLengthId = null;
    String sessionLengthValue = null;
    String sessionLengthValue1 = null;
    String idleTimeName = null;
    Long idleTimeId = null;
    String idleTimeValue = null;
    String initialPlacementName = null;
    Long initialPlacementId = null;
    String initialPlacementValue = null;
    String calculatorName = null;
    Long calculatorId = null;
    String calculatorValue = null;
    HashMap<String, String> assignmentSettings = new HashMap<>();
    GroupAPI groupAPI = new GroupAPI();
    HashMap<String,String> mathGradeStandardDetails = new HashMap<String,String>();
    HashMap<String,String> readingGradeStandardDetails = new HashMap<String,String>();
    HashMap<String,String> mathGradeSkillDetails = new HashMap<String,String>();
    HashMap<String,String> readingGradeSkillDetails = new HashMap<String,String>();
    String studentUsername = null;
    private String studentDetails = null;
    String studentUserId = null;
    public String isItMt = "";

    @SuppressWarnings("static-access")
	@BeforeClass(alwaysRun=true)
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        orgID = RBSDataSetup.organizationIDs.get( flexSchool );
        userID = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" );
        
        studentDetails = RBSDataSetup.getMyStudent( flexSchool, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );
        isItMt = configProperty.getProperty( "isMTExecution" );
               
        //To get Random Skill and Standard ID's for Math and Reading Courses
    	mathGradeStandardDetails = SqlHelperCourses.getGradeStandardID( Constants.MATH, isItMt.equalsIgnoreCase( "true" ));
    	readingGradeStandardDetails = SqlHelperCourses.getGradeStandardID( Constants.READING, isItMt.equalsIgnoreCase( "true" ));
    	mathGradeSkillDetails = SqlHelperCourses.getSCOIDsOfRandomSkillID(Constants.MATH);
    	while( readingGradeSkillDetails.get("LOName")==null || readingGradeSkillDetails.get("LOName").isEmpty() || readingGradeSkillDetails.get("LOName").startsWith("_") ) {
        	readingGradeSkillDetails = SqlHelperCourses.getSCOIDsOfRandomSkillID(Constants.READING); 
        	}
    }

    @Test ( priority = 1, dataProvider = "UpdateAssignmentSettings_PositiveScenarios", groups = { "SMK-51890", "update assignment settings", "Assignments", "P1", "API", "smoke_test_case" } )
    public void updateAssignmentSettingsPositiveScenarios( String description, String scenario, String scenario1, String scenario2, String statusCode, String gradeId, String courseId, String contentBaseId, String standardFrmeworkId, String parentNode,
            String ChildNode ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();
        HashMap<String, String> courseDetails = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();

        // Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        //Create Custom course by standards
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, orgID );
        headers.put( Constants.USERID_SM_HEADER, userID );

        courseDetails.put( Constants.GRADE_VALUE, gradeId );
        courseDetails.put( Constants.STANDARD_FRAMEWORK_VALUE, standardFrmeworkId );
        courseDetails.put( CourseAPIConstants.COURSE_ID, courseId );
        courseDetails.put( CourseAPIConstants.PARENT_NODE, parentNode );
        courseDetails.put( CourseAPIConstants.CHILD_NODE, ChildNode );
        courseDetails.put( Constants.COURSE_NAME, "Skills" + System.nanoTime() );

        //Create custom course
        switch ( scenario1 ) {
            case "customByStandards":
                apiResponse = createCourseByStandard( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );

                customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                break;
            case "customBySkill":
                apiResponse = createCourseBySkill( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );

                customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                break;
            case "customBySettings":
                apiResponse = createCourseBySettings( smUrl, headers, courseDetails, scenario );
                Log.message( "response from POST Call - " + apiResponse );

                customCourseId = SMUtils.getKeyValueFromResponse( apiResponse.get( Constants.REPORT_BODY ), "data,id" );
                break;

        }

        //Assigning a newly created course to student
        List<String> studentRumbaIdsTc001 = new ArrayList<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> Response = new HashMap<>();

        //Adding students to group
        studentRumbaIdsTc001 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, token, flexSchool );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );

        switch ( scenario2 ) {
            case "Default and Focus":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIdsTc001, AssignmentAPIConstants.USERS_TYPE );
                Log.message( "Assigment Response: "+ Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentSettings( smUrl, headers, assignmentDetails );
                break;

            case "custom":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, customCourseId );
                Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIdsTc001, AssignmentAPIConstants.USERS_TYPE );
                Log.message( "Assigment Response: "+Response.get( "body" ) );
                assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
                AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
                assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );
                assignmentSettings( smUrl, headers, assignmentDetails );
                break;
        }

        apiResponse = UpdateAssignmentSettings1( smUrl, headers, assignmentDetails, assignmentSettings, scenario );

        Log.message( "Update Assignment Settings API changes : " + apiResponse );

        //Assertion

        Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    @Test ( priority = 1, dataProvider = "UpdateAssignmentSettings_NegativeScenarios", groups = { "SMK-51890", "update assignment settings", "Assignemnts", "P1", "API" } )
    public void updateAssignmentSettingsNegativeScenarios( String description, String scenario2, String statusCode, String courseId, String invalidOrgAnsStaffId, String enrollmentOptionId, String invalidCourseId ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> apiResponse = new HashMap<>();

        // Authorization
        tokenCreation( CommonAPIConstants.FLEX_LICENSE_SCHOOL );

        //Assigning a newly created course to student
        List<String> studentRumbaIdsTc001 = new ArrayList<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> Response = new HashMap<>();

        HashMap<String, String> headers = new HashMap<>();

        //Create Custom course by standards
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, orgID );
        headers.put( Constants.USERID_SM_HEADER, userID );

        //Adding students to group
        studentRumbaIdsTc001 = addStudentsToGroup( CommonAPIConstants.STATUS_CODE_CREATED, token, flexSchool );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );

        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        Response = assignAssignment( smUrl, assignmentDetails, studentRumbaIdsTc001, AssignmentAPIConstants.USERS_TYPE );
        Log.message( Response.get( "body" ) );
        assignmentID = SMUtils.getKeyValueFromResponse( Response.get( "body" ), "data,assignmentId" );
        AssignmentUserId = SqlHelperAssignment.getAssignmentUserId( assignmentID );
        assignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, AssignmentUserId );

        assignmentSettings( smUrl, headers, assignmentDetails );

        HashMap<String, String> headersInvalidToken = new HashMap<>();

        switch ( scenario2 ) {

            case "invalid authorization":

                headersInvalidToken.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.AUTHORIZATION, "Bearer " + CourseAPIConstants.INVALID_AUTHORIZATION_ID );
                headersInvalidToken.put( Constants.ORGID_SM_HEADER, orgID );
                headersInvalidToken.put( Constants.USERID_SM_HEADER, userID );

                apiResponse = UpdateAssignmentSettings1( smUrl, headersInvalidToken, assignmentDetails, assignmentSettings, scenario2 );
                Log.message( "Save API Changes : " + apiResponse );
                break;

            case "invalid org id":

                headersInvalidToken.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headersInvalidToken.put( Constants.AUTHORIZATION, "Bearer " + token );
                headersInvalidToken.put( Constants.ORGID_SM_HEADER, invalidOrgAnsStaffId );
                headersInvalidToken.put( Constants.USERID_SM_HEADER, userID );

                apiResponse = UpdateAssignmentSettings1( smUrl, headersInvalidToken, assignmentDetails, assignmentSettings, scenario2 );
                Log.message( "Save API Changes : " + apiResponse );

                break;
            case "invalid staff id":

                assignmentDetails.put( AssignmentAPIConstants.INVALID_TEACHER_ID, invalidOrgAnsStaffId );

                apiResponse = UpdateAssignmentSettings1( smUrl, headers, assignmentDetails, assignmentSettings, scenario2 );
                Log.message( "Save API Changes : " + apiResponse );

                break;

            case "invalid content base id":
                assignmentDetails.put( AssignmentAPIConstants.INVALID_COURSE_ID, invalidCourseId );
                apiResponse = UpdateAssignmentSettings1( smUrl, headers, assignmentDetails, assignmentSettings, scenario2 );
                Log.message( "Save API Changes : " + apiResponse );

                break;

            case "invalid enrollmentOptionId":

                assignmentSettings.put( CourseAPIConstants.INVALID_SESSION_STRENGTH_ID, String.valueOf( enrollmentOptionId ) );

                apiResponse = UpdateAssignmentSettings1( smUrl, headers, assignmentDetails, assignmentSettings, scenario2 );
                Log.message( "Save API Changes : " + apiResponse );

                break;
            case "Verify that values are updated or not":

                assignmentSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, CourseAPIConstants.STRING_FOUR );

                apiResponse = UpdateAssignmentSettings1( smUrl, headers, assignmentDetails, assignmentSettings, scenario2 );
                Log.message( "Save API Changes : " + apiResponse );

                String sessionLengthValue1 = getSessionLengthValue( smUrl, headers, assignmentDetails );

                Log.softAssertThat( sessionLengthValue1.equals( assignmentSettings.get( CourseAPIConstants.SESSION_STRENGTH_VALUE ) ), "Values are updated based on Update Assignment Settings API", "Values are not updated" );

                break;

        }

        //Assertion
        Log.softAssertThat( apiResponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + apiResponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + apiResponse.get( Constants.STATUS_CODE ) );

        //Logging final status(pass/fail) for each case
        Log.testCaseResult();
    }

    /**
     * Data provider for update assignment settings api changes positive
     * scenarios
     * 
     * @return
     */
    @DataProvider ( name = "UpdateAssignmentSettings_PositiveScenarios" )
    public Object[][] UpdateAssignmentSettings_PositiveScenarios() {
        Object[][] inputData = {
                { "TC01_assignment which has been created from Default Reading, Verify that the status code is 200 and response is as expected while passing valid input  and multiple enrollment options", "READING", "No need to create custom course",
                        "Default and Focus", "200", readingGradeStandardDetails.get("GradeID"), "2", "4", readingGradeStandardDetails.get("StandardID"), readingGradeStandardDetails.get("bankID"), readingGradeStandardDetails.get("scoID") },
                { "TC02_assignment which has been created from Custom Reading Standards", "DEFAULTREADING", "customByStandards", "custom", "200", readingGradeStandardDetails.get("GradeID"), "2", "4", readingGradeStandardDetails.get("StandardID"), readingGradeStandardDetails.get("bankID"), readingGradeStandardDetails.get("scoID") },
                { "TC03_assignment which has been created from Default Math.", "MATH", "No need to create custom course", "Default and Focus", "200", mathGradeStandardDetails.get("GradeID"), "1", "4", mathGradeStandardDetails.get("StandardID"), mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID") },
                { "TC04_assignment which has been created from Custom Skills Math.", "DEFAULTMATH", "customBySkill", "custom", "200", mathGradeSkillDetails.get("GradeID"), "1", "3", null, mathGradeSkillDetails.get("ParentNode"), mathGradeSkillDetails.get("LOName") },
                { "TC05_assignment which has been created from Custom ReadingSkills", "DEFAULTREADING", "customBySkill", "custom", "200", readingGradeSkillDetails.get("GradeID"), "2", "3", null, readingGradeSkillDetails.get("ParentNode"), readingGradeSkillDetails.get("LOName") },
                { "TC06_assignment which has been created from Custom ReadingSettings", "DEFAULTREADING", "customBySettings", "custom", "200", null, "2", "2", null, readingGradeSkillDetails.get("ParentNode"), readingGradeSkillDetails.get("LOName") },
                { "TC07_assignment which has been created from Focus Reading.", "READING", "No need to create custom course", "Default and Focus", "200", readingGradeStandardDetails.get("GradeID"), "15", "4", readingGradeStandardDetails.get("StandardID"), readingGradeStandardDetails.get("bankID"), readingGradeStandardDetails.get("scoID") },
                { "TC08_assignment which has been created from Custom Focus Reading.", "READING", "customByStandards", "custom", "200", readingGradeStandardDetails.get("GradeID"), "15", "4", readingGradeStandardDetails.get("StandardID"), readingGradeStandardDetails.get("bankID"), readingGradeStandardDetails.get("scoID") },
                { "TC09_assignment which has been created from Focus Math.", "MATH", "No need to create custom course", "Default and Focus", "200", mathGradeStandardDetails.get("GradeID"), "5", "4", mathGradeStandardDetails.get("StandardID"), mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID") },
                { "TC10_assignment which has been created from Custom Focus Math.", "FOCUSMATH", "customByStandards", "custom", "200", mathGradeStandardDetails.get("GradeID"), "3", "4", mathGradeStandardDetails.get("StandardID"), mathGradeStandardDetails.get("bankID"), mathGradeStandardDetails.get("scoID") }

        };
        return inputData;
    }

    /**
     * Data provider update assignment settings api changes negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "UpdateAssignmentSettings_NegativeScenarios" )
    public Object[][] UpdateAssignmentSettings_NegativeScenarios() {
        Object[][] inputData = { { "invalid authorization", "invalid authorization", "401", "2", null, null, null }, { "invalid org id", "invalid org id", "403", "2", "22220a5a7f2c9dcf017f3fe81bc602we", null, null },
                { "non-existing org id", "invalid org id", "403", "2", "8a720a5a7f2c9dcf017f3fe81bc602we", null, null }, { "invalid staff id", "invalid staff id", "400", "2", "22220a5a7f2c9dcf017f3fe81bc602we", null, null },
                { "different staff id", "invalid staff id", "400", "2", "ffffffff623ad85dbaa845002e41ff18", null, null }, { "invalic content base id", "invalid content base id", "400", "2", null, null, "abc" },
                { "invalic content base id", "invalid content base id", "200", "2", null, null, "7030761" }, { "invalid enrollmentOptionId", "invalid enrollmentOptionId", "400", "2", null, "abc", null },
                { "invalid enrollmentOptionId", "invalid enrollmentOptionId", "500", "2", null, null, null }, { "Verify that values are updated or not", "Verify that values are updated or not", "200", "2", null, null, null }

        };
        return inputData;
    }

    //Token creation
    public void tokenCreation( String school ) {
        try {

            teacherDetails = flexSchoolTeacherDetails;

            token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        } catch ( Exception e ) {
            Log.message( "Issue occured in tokenCreation" );
        }
    }

    /**
     * Get response for the Create Course By Standard API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseByStandard( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();

            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardReading" ) ) );

            } else if ( scenario.contains( "DEFAULTMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardMath" ) ) );
            } else if ( scenario.contains( "FOCUSMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusMath" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.STANDARDFRAMEWORK_ID, courseDetails.get( Constants.STANDARD_FRAMEWORK_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseByStandard method" );
            return null;
        }
    }

    /**
     * Get response for the Create Course By Skill API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySkill( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySkillsReading" ) ) );

            } else if ( scenario.contains( "DEFAULTMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySkillsMath" ) ) );
            } else if ( scenario.contains( "FOCUSMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusMath" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.GRADE_ID, courseDetails.get( Constants.GRADE_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.PARENT_NODE, courseDetails.get( CourseAPIConstants.PARENT_NODE ) ) );
            requestBody.set( requestBody.get().replace( CourseAPIConstants.CHILD_NODE, courseDetails.get( CourseAPIConstants.CHILD_NODE ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

    /**
     * Get response for the Create Course By Settings API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> createCourseBySettings( String envUrl, HashMap<String, String> headers, HashMap<String, String> courseDetails, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.CREATE_CUSTOM_COURSE;
            Log.message( "createCourseBySkill= " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, courseDetails.get( CourseAPIConstants.COURSE_ID ) );
            Log.message( "endpoint=" + endpoint );
            AtomicReference<String> requestBody = new AtomicReference<>();
            if ( scenario.contains( "DEFAULTREADING" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySettingsReading" ) ) );

            } else if ( scenario.contains( "DEFAULTMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseBySettingsMath" ) ) );
            } else if ( scenario.contains( "FOCUSMATH" ) ) {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusMath" ) ) );
            } else {
                requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "createCustomCourseByStandardsFocusReading" ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.COURSENAME_VALUE, courseDetails.get( Constants.COURSE_NAME ) ) );
            return RestHttpClientUtil.POST( envUrl, headers, new HashMap<String, String>(), endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in createCourseBySkill method" );
            return null;
        }
    }

    //Adding Students to group
    public List<String> addStudentsToGroup( String statusCode, String userName, String school ) {
        HashMap<String, String> response;
        HashMap<String, String> groupDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();
        try {
            //Adding students to group
            String groupName = "Successmaker API Test Group " + System.nanoTime();
            studentRumbaIds.add(studentUserId);
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, userName );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, groupName );
            Log.message( "groupDetails is " + groupDetails );
            response = groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds );
            Log.message( "response for group creation is " + response );
            Log.softAssertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        } catch ( Exception e ) {
            Log.message( "Issue occured in addStudentsToGroup" );
        }
        return studentRumbaIds;
    }

    /**
     * Get response for Get Assignment Settings api
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public void assignmentSettings( String envUrl, HashMap<String, String> headers, HashMap<String, String> assignmentDetails1 ) {
        try {
            HashMap<String, String> apiResponse = new HashMap<>();
            apiResponse = getAssignmentSettings( smUrl, headers, assignmentDetails1 );
            JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj( apiResponse.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );
            JSONObject data2 = getSettingsResp.getJSONObject( CourseAPIConstants.SESSION_LENGTH );
            sessionLengthName = data2.getString( CourseAPIConstants.NAME );
            sessionLengthId = data2.getLong( CourseAPIConstants.ID );
            sessionLengthValue = data2.getString( CourseAPIConstants.CURRENT_VALUE );
            Log.message( "Name of the session length : " + sessionLengthName );
            Log.message( "Id of the session length : " + sessionLengthId );
            Log.message( "CurrentValue of the session length : " + sessionLengthValue );

            JSONObject data3 = getSettingsResp.getJSONObject( CourseAPIConstants.IDLE_TIME );
            idleTimeName = data3.getString( CourseAPIConstants.NAME );
            idleTimeId = data3.getLong( CourseAPIConstants.ID );
            idleTimeValue = data3.getString( CourseAPIConstants.CURRENT_VALUE );
            Log.message( "Name of the idleTime : " + idleTimeName );
            Log.message( "Id of the idleTime : " + idleTimeId );
            Log.message( "CurrentValue of the idleTime : " + idleTimeValue );

            JSONObject data4 = getSettingsResp.getJSONObject( CourseAPIConstants.INITIAL_PLACEMENT );
            initialPlacementName = data4.getString( CourseAPIConstants.NAME );
            initialPlacementId = data4.getLong( CourseAPIConstants.ID );
            initialPlacementValue = data4.getString( CourseAPIConstants.CURRENT_VALUE );
            Log.message( "Name of the idleTime : " + idleTimeName );
            Log.message( "Id of the idleTime : " + idleTimeId );
            Log.message( "CurrentValue of the idleTime : " + idleTimeValue );

            JSONObject data5 = getSettingsResp.getJSONObject( CourseAPIConstants.CALCULATOR );
            calculatorName = data5.getString( CourseAPIConstants.NAME );
            calculatorId = data5.getLong( CourseAPIConstants.ID );
            calculatorValue = data5.getString( CourseAPIConstants.CURRENT_VALUE );
            Log.message( "Name of the idleTime : " + idleTimeName );
            Log.message( "Id of the idleTime : " + idleTimeId );
            Log.message( "CurrentValue of the idleTime : " + idleTimeValue );

            assignmentSettings.put( CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf( sessionLengthId ) );
            assignmentSettings.put( CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName );
            assignmentSettings.put( CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue );
            assignmentSettings.put( CourseAPIConstants.IDLE_TIME_ID, String.valueOf( idleTimeId ) );
            assignmentSettings.put( CourseAPIConstants.IDLE_TIME_NAME, idleTimeName );
            assignmentSettings.put( CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue );
            assignmentSettings.put( CourseAPIConstants.INITIAL_PLACEMENT_ID, String.valueOf( initialPlacementId ) );
            assignmentSettings.put( CourseAPIConstants.INITIAL_PLACEMENT_NAME, initialPlacementName );
            assignmentSettings.put( CourseAPIConstants.INITIAL_PLACEMENT_VALUE, initialPlacementValue );
            assignmentSettings.put( CourseAPIConstants.CALCULATOR_ID, String.valueOf( calculatorId ) );
            assignmentSettings.put( CourseAPIConstants.CALCULATOR_NAME, calculatorName );
            assignmentSettings.put( CourseAPIConstants.CALCULATOR_VALUE, calculatorValue );

        } catch ( Exception e ) {
            Log.message( "Error in assignmentSettings method" );

        }
    }

    /**
     * Get response for Get Assignment Settings api
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public String getSessionLengthValue( String envUrl, HashMap<String, String> headers, HashMap<String, String> assignmentDetails1 ) {
        try {
            HashMap<String, String> apiResponse = new HashMap<>();
            apiResponse = getAssignmentSettings( smUrl, headers, assignmentDetails1 );
            JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj( apiResponse.get( Constants.REPORT_BODY ).toString(), Constants.REPORT_BODY_DATA, null, null, null );
            JSONObject data2 = getSettingsResp.getJSONObject( CourseAPIConstants.SESSION_LENGTH );
            sessionLengthName = data2.getString( CourseAPIConstants.NAME );
            sessionLengthId = data2.getLong( CourseAPIConstants.ID );
            sessionLengthValue1 = data2.getString( CourseAPIConstants.CURRENT_VALUE );
            Log.message( "Name of the session length : " + sessionLengthName );
            Log.message( "Id of the session length : " + sessionLengthId );
            Log.message( "CurrentValue of the session length : " + sessionLengthValue1 );

        } catch ( Exception e ) {
            Log.message( "Error in getSessionLengthValue method" );

        }
        return sessionLengthValue1;
    }

    /**
     * Get response for Get Assignment Settings api
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> getAssignmentSettings( String envUrl, HashMap<String, String> headers, HashMap<String, String> assignmentDetails ) {
        try {

            String endpoint = CourseAPIConstants.GET_ASSIGNMENT_SETTINGS;
            Log.message( "Save SCO Start Time changes = " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            endpoint = endpoint.replace( Constants.COURSE_ID, assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );

            Log.message( "endpoint=" + envUrl + endpoint );

            //Parameters
            HashMap<String, String> params = new HashMap<>();
            params.put( CourseAPIConstants.ASSIGN, CourseAPIConstants.TRUE );

            HashMap<String, String> response = RestHttpClientUtil.GET( envUrl, endpoint, headers, params );

            return response;

        } catch ( Exception e ) {
            Log.message( "Error in getAssignmentSettings method" );
            return null;
        }
    }

    /**
     * Get response for Update Assignment Settins API
     *
     * @param envUrl
     * @param headers
     * @param courseDetails
     * @param scenario
     * @return
     */
    public HashMap<String, String> UpdateAssignmentSettings1( String envUrl, HashMap<String, String> headers, HashMap<String, String> assignmentDetails, HashMap<String, String> assignmentSettings, String scenario ) {
        try {

            String endpoint = CourseAPIConstants.UPDATE_ASSIGNMENT_SETTINGS;
            Log.message( "Update Assignment Settings API Changes = " + endpoint );
            endpoint = endpoint.replace( Constants.ORG_ID, headers.get( Constants.ORGID_SM_HEADER ) );
            if ( scenario.contains( "invalid staff id" ) ) {
                endpoint = endpoint.replace( Constants.STAFF_ID, assignmentDetails.get( AssignmentAPIConstants.INVALID_TEACHER_ID ) );
            } else {
                endpoint = endpoint.replace( Constants.STAFF_ID, headers.get( Constants.USERID_SM_HEADER ) );
            }

            if ( scenario.contains( "invalid content base id" ) ) {
                endpoint = endpoint.replace( Constants.COURSE_ID, assignmentDetails.get( AssignmentAPIConstants.INVALID_COURSE_ID ) );
            } else {
                endpoint = endpoint.replace( Constants.COURSE_ID, assignmentDetails.get( AssignmentAPIConstants.COURSE_ID ) );
            }
            Log.message( "endpoint=" + envUrl + endpoint );

            //Parameters
            HashMap<String, String> params = new HashMap<>();
            params.put( CourseAPIConstants.APPY_TO_USERS, CourseAPIConstants.TRUE );

            AtomicReference<String> requestBody = new AtomicReference<>();

            requestBody.set( SMUtils.convertFileToString( configProperty.getProperty( "updateAssignmentSettings" ) ) );

            if ( scenario.contains( "invalid enrollmentOptionId" ) ) {
                requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_ID, assignmentSettings.get( CourseAPIConstants.INVALID_SESSION_STRENGTH_ID ) ) );

            } else {
                requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_ID, assignmentSettings.get( CourseAPIConstants.SESSION_STRENGTH_ID ) ) );
            }
            requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_NAME, assignmentSettings.get( CourseAPIConstants.SESSION_STRENGTH_NAME ) ) );
            requestBody.set( requestBody.get().replace( Constants.SESSION_LENGTH_VALUE, assignmentSettings.get( CourseAPIConstants.SESSION_STRENGTH_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.IDLE_TIME_ID, assignmentSettings.get( CourseAPIConstants.IDLE_TIME_ID ) ) );
            requestBody.set( requestBody.get().replace( Constants.IDLE_TIME_NAME, assignmentSettings.get( CourseAPIConstants.IDLE_TIME_NAME ) ) );
            requestBody.set( requestBody.get().replace( Constants.IDLE_TIME_VALUE, assignmentSettings.get( CourseAPIConstants.IDLE_TIME_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.INITIAL_PLACEMENT_ID_PAYLOAD, assignmentSettings.get( CourseAPIConstants.INITIAL_PLACEMENT_ID ) ) );
            requestBody.set( requestBody.get().replace( Constants.INITIAL_PLACEMENT_NAME_PAYLOAD, assignmentSettings.get( CourseAPIConstants.INITIAL_PLACEMENT_NAME ) ) );
            requestBody.set( requestBody.get().replace( Constants.INITIAL_PLACEMENT_VALUE_PAYLOAD, assignmentSettings.get( CourseAPIConstants.INITIAL_PLACEMENT_VALUE ) ) );
            requestBody.set( requestBody.get().replace( Constants.CALCULATOR_ID_PAYLOAD, assignmentSettings.get( CourseAPIConstants.CALCULATOR_ID ) ) );
            requestBody.set( requestBody.get().replace( Constants.CALCULATOR_NAME_PAYLOAD, assignmentSettings.get( CourseAPIConstants.CALCULATOR_NAME ) ) );
            requestBody.set( requestBody.get().replace( Constants.CALCULATOR_VALUE_PAYLOAD, assignmentSettings.get( CourseAPIConstants.CALCULATOR_VALUE ) ) );

            Log.message( "payload : " + requestBody.get() );
            Log.message( headers.toString() );

            return RestHttpClientUtil.PUT( envUrl, headers, params, endpoint, requestBody.get() );

        } catch ( Exception e ) {
            Log.message( "Error in UpdateAssignmentSettings1 method" );
            return null;
        }
    }
}