package com.savvas.sm.admin.ui.tests;

import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.AuditHistoryPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants.AuditHistory;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants.AuditHistory.AUDIT_HISTORY_NAVIGATION_BUTTONS;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants.AuditHistory.AUDIT_HISTORY_TABLE_HEADER;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class AuditHistoryUI extends BaseTest {

    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify Audit History should display in left nav bar and other components in the Audit History Page", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory001: Verify Audit History  should display in left nav bar. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page 
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify Audit History  should display in left nav bar" );
            Log.assertThat( auditHistoryPage.verifyAuditHistoryinSubNavigation(), "The Audit History Page is displayed in Left navigation bar", "The Audit History Page is not displayed in Left navigation bar" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify page should navigate to Audit History filters - UI ,when admin click on Audit History." );
            Log.assertThat( auditHistoryPage.getAuditHistoryURL().equals( AuditHistory.URL ), "The Audit History Page URL is verified", "The Audit History Page url is not verified" );
            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "The Audit History page Header is verified as Audit History: Assignments",
                    "The Audit History page Header is not verified as Audit History: Assignments" );
            Log.assertThat( auditHistoryPage.verifyHelpIconAuditHistoryPageDisplayed(), "The Audit History page Header Help Icon ? is Displayed", "The Audit History page Header Help Icon ? is not Displayed" );
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "The Organization drop down is displayed in Audit History Page", "The Organization drop down is not displayed in Audit History Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify page should navigate to Audit History filters - UI ,when admin click on Audit History." );
            Log.assertThat( auditHistoryPage.getAuditHistoryURL().equals( AuditHistory.URL ), "The Audit History Page URL is verified", "The Audit History Page url is not verified" );
            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "The Audit History page Header is verified as Audit History: Assignments",
                    "The Audit History page Header is not verified as Audit History: Assignments" );
            Log.assertThat( auditHistoryPage.verifyHelpIconAuditHistoryPageDisplayed(), "The Audit History page Header Help Icon ? is Displayed", "The Audit History page Header Help Icon ? is not Displayed" );
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "The Organization drop down is displayed in Audit History Page", "The Organization drop down is not displayed in Audit History Page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verfiy the default zero state message in Audit history Page.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory002: Verfiy the default zero state message in Audit history Page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page 
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verfiy the default zero state message in Audit history Page." );
            Log.assertThat( auditHistoryPage.getZeroStateHeader().equals( AuditHistory.ZERO_STATE_HEADER ) && auditHistoryPage.getZeroStateMessage().equals( AuditHistory.ZERO_STATE_MESSAGE ), "The Zero State message is displayed and verified",
                    "The Zero state message is not displayed and verified" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify audit history list columns for audit history.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory003: Verify audit history list columns for audit history. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page 
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            auditHistoryPage.selectOrganization( allOrganizationsfromdropdown.get( 0 ) );

            SMUtils.logDescriptionTC( "Verify audit history list columns for audit history." );
            Log.assertThat( auditHistoryPage.verifyColumnHeadersdisplayed(), "The Column Headers are displayed", "The Column Headers are not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the total number of audit history are displayed in the audit history list page and number of pages for more than 100 records.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory004: Verify the total number of audit history are displayed in the audit history list page and number of pages for more than 100 records. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page 
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify the total number of audit history are displayed in the audit history list page" );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            auditHistoryPage.selectOrganization( allOrganizationsfromdropdown.get( 0 ) );
            Log.assertThat( auditHistoryPage.verifypageCountisDisplayed(), "The Page count is displayed", "The Page count is not displayed" );
            Log.assertThat( auditHistoryPage.verifyPageCountFormat(), "The Page format is displayed and verified", "The page format is not verified" );
            Log.assertThat( auditHistoryPage.getTotalCountInPaginationNumber() == auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.COURSE ).size(), "Audit History Count and number of records displayed are same and verified",
                    "Audit History Count and number of records displayed are not same and not verified" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the number of pages of audit history displayed for the results more than 100 count in the audit history page." );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.FIRST ).equals( "true" ), "The backward button is disabled by default", "The backward button is enabled by default" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST ).equals( "false" ), "The forward button is enabled by default", "The forward button is disabled by default" );
            Log.assertThat( auditHistoryPage.verifyPageCountFormat(), "The Page format is displayed and verified", "The page format is not verified" );
            Log.assertThat( auditHistoryPage.verifyNumberOfPagesFormat(), "The Number of Pages and the page format is verified", "The Number of Pages and the page format is not verified" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of forward navigation in the page navigation for more than 100 count in the audit history page.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory005: Verify the functionality of forward navigation in the page navigation for more than 100 count in the audit history page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page 
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify the functionality of forward navigation in the page navigation for more than 100 count in the audit history page." );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            auditHistoryPage.selectOrganization( allOrganizationsfromdropdown.get( 0 ) );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST ).equals( "false" ), "The forward button is enabled by default", "The forward button is disabled by default" );
            auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT );
            Log.message( "Navigated to the Next Page" );
            Log.assertThat( auditHistoryPage.getCurrentPageNumber() == auditHistoryPage.getAllPageNumber(), "Navigated to the last page and it is verified", "Navigated to the next page" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT ).equals( "true" ), "The Next button is disabled", "The Next button is enabled" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST ).equals( "true" ), "The Last button is disabled", "The Last button is enabled" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of fast forward navigation in the page navigation for more than 100 count in the audit history page.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory006: Verify the functionality of fast forward navigation in the page navigation for more than 100 count in the audit history page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page 
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify the functionality of fast forward navigation in the page navigation for more than 100 count in the audit history page." );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            auditHistoryPage.selectOrganization( allOrganizationsfromdropdown.get( 0 ) );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST ).equals( "false" ), "The forward button is enabled by default", "The forward button is disabled by default" );
            auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST );
            Log.message( "Navigated to the Last Page" );
            Log.assertThat( auditHistoryPage.getCurrentPageNumber() == auditHistoryPage.getAllPageNumber(), "Navigated to the last page and it is verified", "Navigated to the next page" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT ).equals( "true" ), "The Next button is disabled", "The Next button is enabled" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST ).equals( "true" ), "The Last button is disabled", "The Last button is enabled" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of backward navigation in the page navigation for more than 100 count in the audit history page.s", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory007: Verify the functionality of backward navigation in the page navigation for more than 100 count in the audit history page.s <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page 
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify the functionality of backward navigation in the page navigation for more than 100 count in the audit history page." );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            auditHistoryPage.selectOrganization( allOrganizationsfromdropdown.get( 0 ) );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.PREVIOUS ).equals( "true" ), "The previous button is disabled by default", "The previuos button is enabled by default" );
            auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.NEXT );
            Log.message( "Navigated to the Next Page" );
            Log.assertThat( auditHistoryPage.getCurrentPageNumber() == auditHistoryPage.getAllPageNumber(), "Navigated to the last page and it is verified", "Navigated to the next page" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.PREVIOUS ).equals( "false" ), "The Previous button is enabled", "The Previous button is disabled" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.FIRST ).equals( "false" ), "The First button is enabled", "The First button is disabled" );
            int currentPageNumber = auditHistoryPage.getCurrentPageNumber();
            auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.PREVIOUS );
            int newPageNumber = auditHistoryPage.getCurrentPageNumber();
            Log.assertThat( newPageNumber == currentPageNumber - 1, "The previous navigated to the one page backward and verified", "The previous is not navigated to the one page backward" );

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of pre backward navigation in the page navigation for more than 100 count in the audit history page.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory008: Verify the functionality of pre backward navigation in the page navigation for more than 100 count in the audit history page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page 
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify the functionality of backward navigation in the page navigation for more than 100 count in the audit history page." );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            auditHistoryPage.selectOrganization( allOrganizationsfromdropdown.get( 0 ) );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.PREVIOUS ).equals( "true" ), "The previous button is disabled by default", "The previuos button is enabled by default" );
            auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.LAST );
            Log.message( "Navigated to the Last Page" );
            Log.assertThat( auditHistoryPage.getCurrentPageNumber() == auditHistoryPage.getAllPageNumber(), "Navigated to the last page and it is verified", "Navigated to the next page" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.PREVIOUS ).equals( "false" ), "The Previous button is enabled", "The Previous button is disabled" );
            Log.assertThat( auditHistoryPage.verifyNavigationButtonDisabled( AUDIT_HISTORY_NAVIGATION_BUTTONS.FIRST ).equals( "false" ), "The First button is enabled", "The First button is disabled" );
            auditHistoryPage.clickNavigationButton( AUDIT_HISTORY_NAVIGATION_BUTTONS.FIRST );
            int newPageNumber = auditHistoryPage.getCurrentPageNumber();
            Log.assertThat( newPageNumber == 1, "The First Button navigated to the one page backward and verified", "The First Button is not navigated to the one page backward" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to sort by ascending/descending all the column.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory009: Verify user can able to sort by ascending/descending all the column. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page 
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "Verify user can able to sort by ascending/descending all the column." );
            List<String> allOrganizationsfromdropdown = auditHistoryPage.getAllOrganizationsfromdropdown();
            auditHistoryPage.selectOrganization( allOrganizationsfromdropdown.get( 0 ) );

            Log.message( "Verifying the sort functionality for Assignment Name" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.ASSIGNMENT_NAME );
            List<String> beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNMENT_NAME );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.ASSIGNMENT_NAME );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNMENT_NAME ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNMENT_NAME ).equals( beforeSort ), "After clicking the Assignment Name header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

            Log.message( "Verifying the sort functionality for Group/Student" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.GROUP_STUDENT );
            beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.GROUP_STUDENT );
            Collections.sort( beforeSort );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.GROUP_STUDENT );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.GROUP_STUDENT ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.GROUP_STUDENT ).equals( beforeSort ), "After clicking the GROUP/STUDENT header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

            Log.message( "Verifying the sort functionality for Type" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.TYPE );
            beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.TYPE );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.TYPE );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.TYPE ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.TYPE ).equals( beforeSort ), "After clicking the TYPE header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

            Log.message( "Verifying the sort functionality for Assigned By" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.ASSIGNED_BY );
            beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNED_BY );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.ASSIGNED_BY );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNED_BY ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.ASSIGNED_BY ).equals( beforeSort ), "After clicking the ASSIGNED BY header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

            Log.message( "Verifying the sort functionality for Courses" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.COURSE );
            beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.COURSE );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.COURSE );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.COURSE ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.COURSE ).equals( beforeSort ), "After clicking the COURSE header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

            Log.message( "Verifying the sort functionality for Dates Deleted" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.DATE_DELETED );
            beforeSort = auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.DATE_DELETED );
            Collections.reverse( beforeSort );
            Log.message( beforeSort + "" );
            auditHistoryPage.clickColumnHeader( AUDIT_HISTORY_TABLE_HEADER.DATE_DELETED );
            Log.message( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.DATE_DELETED ) + "" );
            Log.assertThat( auditHistoryPage.getAllColumnValues( AUDIT_HISTORY_TABLE_HEADER.DATE_DELETED ).equals( beforeSort ), "After clicking the DATE DELETED header, the values are decending sorted",
                    "After clicking the Assignment Name header, the values are not decending sorted" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify the audit history listing for school admin", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory010() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory010: verify the audit history listing for school admin <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            username = RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN );
            password = RBSDataSetupConstants.DEFAULT_PASSWORD;
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page 
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "verify the audit history listing for school admin" );
            Log.assertThat( auditHistoryPage.getAuditHistoryURL().equals( AuditHistory.URL ), "The Audit History Page URL is verified", "The Audit History Page url is not verified" );
            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "The Audit History page Header is verified as Audit History: Assignments",
                    "The Audit History page Header is not verified as Audit History: Assignments" );
            Log.assertThat( auditHistoryPage.verifyHelpIconAuditHistoryPageDisplayed(), "The Audit History page Header Help Icon ? is Displayed", "The Audit History page Header Help Icon ? is not Displayed" );
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "The Organization drop down is displayed in Audit History Page", "The Organization drop down is not displayed in Audit History Page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify the audit history listing for sub-district admin.", groups = { "SMK-51928", "adminDashboard", "AuditHistory" }, priority = 1 )
    public void tcSMAuditHistory011() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSMAuditHistory011: verify the audit history listing for sub-district admin. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            username = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
            password = RBSDataSetupConstants.DEFAULT_PASSWORD;
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            // Navigating to Audit History Page 
            AuditHistoryPage auditHistoryPage = dashBoardPage.navigateToAuditHistoryPage();

            SMUtils.logDescriptionTC( "verify the audit history listing for sub-district admin." );
            Log.assertThat( auditHistoryPage.getAuditHistoryURL().equals( AuditHistory.URL ), "The Audit History Page URL is verified", "The Audit History Page url is not verified" );
            Log.assertThat( auditHistoryPage.getAuditHistoryPageTitle().equals( AuditHistory.TITLE ), "The Audit History page Header is verified as Audit History: Assignments",
                    "The Audit History page Header is not verified as Audit History: Assignments" );
            Log.assertThat( auditHistoryPage.verifyHelpIconAuditHistoryPageDisplayed(), "The Audit History page Header Help Icon ? is Displayed", "The Audit History page Header Help Icon ? is not Displayed" );
            Log.assertThat( auditHistoryPage.verifyOrganizationDropdownDisplayed(), "The Organization drop down is displayed in Audit History Page", "The Organization drop down is not displayed in Audit History Page" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
