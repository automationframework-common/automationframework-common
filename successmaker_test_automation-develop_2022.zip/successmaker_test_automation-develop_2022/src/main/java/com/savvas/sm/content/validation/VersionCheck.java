package com.savvas.sm.content.validation;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.utils.SMUtils;

public class VersionCheck extends BaseTest {

    @Test ( description = "Verify Version Check", priority = 1 )
    public void TCVersionCheck() throws Exception {
        int failcount = 0;
        String browser = configProperty.getProperty( "BrowserPlatformToRun" );

        HashMap<String, String> expectedVersions = new HashMap<String, String>();

        expectedVersions.put( "Administrator / Student Client", configProperty.getProperty( "adminClient" ) );
        expectedVersions.put( "Teacher Client", configProperty.getProperty( "teacherClient" ) );
        expectedVersions.put( "SM Server", configProperty.getProperty( "smServer" ) );
        expectedVersions.put( "Database Server", configProperty.getProperty( "databaseServer" ) );
        expectedVersions.put( "Reporting System", configProperty.getProperty( "reportingSystem" ) );
        expectedVersions.put( "Math", configProperty.getProperty( "mathVersion" ) );
        expectedVersions.put( "Reading", configProperty.getProperty( "readingVersion" ) );
        String prodInstanceList = configProperty.getProperty( "prodInstanceList" );
        WebDriver driver = WebDriverFactory.get( browser );
        try {

            String[] prodList = prodInstanceList.split( "," );
            for ( int prod = 0; prod < prodList.length; prod++ ) {
                String instance = prodList[prod].trim();
                instance = "https://" + instance + ".smhost.net";
                Log.message( "<p style=\"color:blue;font-weight:bold\">" + "Checking versions for the instance: " + instance + "</p>" );
                driver.get( instance );
                SMUtils.nap( 2 );
                driver.findElement( By.xpath( "//div[@class='login-version']/a" ) ).click();
                SMUtils.nap( 2 );
                List<WebElement> versions = driver.findElements( By.xpath( "//div[@class='version-info-row']/div" ) );
                SMUtils.nap( 2 );
                String key = null;
                String val;

                for ( int i = 0; i < versions.size(); i++ ) {

                    if ( i % 2 == 0 ) {
                        key = versions.get( i ).getText().trim();
                        key = key.substring( 0, key.length() - 1 );
                        //                    Log.message( "Key: " + key );
                    } else {
                        val = versions.get( i ).getText().trim();
                        //                    Log.message( "val: " + val );
                        if ( expectedVersions.get( key ).equals( val ) ) {
                            Log.message( "<p style=\"color:green;font-weight:bold\">" + key + " matched with application. for the instance: " + instance + "</p>" );
                        } else {
                            if ( val.equals( "" ) ) {
                                Log.message( "<p style=\"color:orange;font-weight:bold\">" + "Expected version of " + key + " is :" + expectedVersions.get( key ) + " Actual version of: " + key + " is :" + val + "</p>" );
                            } else {
                                Log.message( "<p style=\"color:red;font-weight:bold\">" + "Expected version of " + key + " is :" + expectedVersions.get( key ) + " Actual version of: " + key + " is :" + val + "</p>" );
                                failcount += 1;
                            }

                        }

                        key = null;
                        val = null;
                    }

                }

            }
            Log.assertThat( failcount == 0, "All the instances were updated with latest versions", "Version not updated properly in few instances. Please check the redcolor line" );
        } catch ( Exception e ) {
            Log.fail( "FAILED CHECK THE INSTANCE STATUS" );
        } finally {
            driver.quit();
        }
    }

}
