package com.savvas.sm.api.tests.smnew.courses;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetupProcessor;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;

public class PutCustomBySetting {
	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	private String smUrl;
	private String teacherDetails = null;
	private String flexSchoolTeacherDetails = null;
	private String flexSchool = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String token = null;
	String customCourseId = null;
	String sessionLengthName = null;
	Long sessionLengthId = null;
	String sessionLengthValue = null;
	String idleTimeName = null;
	Long idleTimeId = null;
	String idleTimeValue = null;
	String orgID = null;
	String userID = null;
	DataSetupProcessor dataprocess = new DataSetupProcessor();

	@BeforeClass(alwaysRun = true)
	public void BeforeTest() {
		smUrl = configProperty.getProperty("SMAppUrl");
		flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher(flexSchool);
	}

	@Test(priority = 1, dataProvider = "putCustomBySetting", groups = { "SMK-52097", "Update Custom by Settings course",
			"Course", "P1", "API", "smoke_test_case" })
	public void createCourseAndUpdateCustomBySetting(String description, String scenario, String scenario1,
			String statusCode, String courseId, String contentBaseId, String message) throws Exception {
		Log.testCaseInfo(description);
		HashMap<String, String> apiResponse = new HashMap<>();
		HashMap<String, String> headers = new HashMap<>();

		// Authorization
		tokenCreation(CommonAPIConstants.FLEX_LICENSE_SCHOOL);
		orgID = RBSDataSetup.organizationIDs.get(flexSchool);
		userID = SMUtils.getKeyValueFromResponse(flexSchoolTeacherDetails, "userId");

		// Create Custom course by standards
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.AUTHORIZATION, "Bearer " + token);
		headers.put(Constants.ORGID_SM_HEADER, orgID);
		headers.put(Constants.USERID_SM_HEADER, userID);

		String courseName = "Setting" + System.nanoTime();
		apiResponse = createCourseSetting(smUrl, token, scenario, userID, orgID, courseName);
		Log.message("response from POST Call - " + apiResponse);

		customCourseId = SMUtils.getKeyValueFromResponse(apiResponse.get(Constants.REPORT_BODY), "data,id");

		// Get Settings
		HashMap<String, String> courseSettings = new HashMap<>();
		HashMap<String, String> apiResponseGetSettings = new HashMap<>();

		courseSettings.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		courseSettings.put(CourseAPIConstants.TEACHER_ID, userID);
		courseSettings.put(CourseAPIConstants.ORG_ID, orgID);
		courseSettings.put(CourseAPIConstants.COURSE_ID, customCourseId);

		apiResponseGetSettings = new CourseAPI().getCoursesSettings(smUrl, courseSettings, "false", customCourseId);
		Log.message("Get Settings : " + apiResponseGetSettings);

		JSONObject getSettingsResp = SMUtils.convertResponseAsJsonObj(
				apiResponseGetSettings.get(Constants.REPORT_BODY).toString(), Constants.REPORT_BODY_DATA, null, null,
				null);

		JSONObject data2 = getSettingsResp.getJSONObject("SESSION_LENGTH");
		sessionLengthName = data2.getString("name");
		sessionLengthId = data2.getLong("id");
		sessionLengthValue = data2.getString("currentValue");
		Log.message("Name of the session length : " + sessionLengthName);
		Log.message("Id of the session length : " + sessionLengthId);
		Log.message("CurrentValue of the session length : " + sessionLengthValue);

		JSONObject data3 = getSettingsResp.getJSONObject("IDLE_TIME");
		idleTimeName = data3.getString("name");
		idleTimeId = data3.getLong("id");
		idleTimeValue = data3.getString("currentValue");
		Log.message("Name of the idleTime : " + idleTimeName);
		Log.message("Id of the idleTime : " + idleTimeId);
		Log.message("CurrentValue of the idleTime : " + idleTimeValue);

		// Updating the Settings As per Scenarios
		courseSettings.put(Constants.COURSE_NAME, "Settings Renamed" + System.nanoTime());
		courseSettings.put(CourseAPIConstants.CONTENT_BASE_TYPE, contentBaseId);
		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_ID, String.valueOf(sessionLengthId));
		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_NAME, sessionLengthName);
		courseSettings.put(CourseAPIConstants.SESSION_STRENGTH_VALUE, sessionLengthValue);
		courseSettings.put(CourseAPIConstants.IDLE_TIME_ID, String.valueOf(idleTimeId));
		courseSettings.put(CourseAPIConstants.IDLE_TIME_NAME, idleTimeName);
		courseSettings.put(CourseAPIConstants.IDLE_TIME_VALUE, idleTimeValue);

		if (scenario1.equals("Invalid Math")) {
			courseSettings.replace(CourseAPIConstants.COURSE_ID, CourseAPIConstants.INVALID_COURSE_ID);
		} else if (scenario1.equals("Invalid Reading")) {
			courseSettings.replace(CourseAPIConstants.COURSE_ID, CourseAPIConstants.INVALID_MAP_LO_TAXONOMY);
		} else if (scenario1.equals("Invalid Course ID")) {
			courseSettings.replace(CourseAPIConstants.COURSE_ID, CourseAPIConstants.INVALID_COURSE_ID_SYMBOL);
		} else if (scenario1.equals("Invalid Org ID")) {
			courseSettings.replace(CourseAPIConstants.ORG_ID, CourseAPIConstants.INVALID_ORGANIZATION_ID);
		} else if (scenario1.equals("Invalid Org ID-Non Existing")) {
			courseSettings.replace(CourseAPIConstants.ORG_ID, CourseAPIConstants.NON_EXISTING_ORGANIZATION_ID);
		} else if (scenario1.equals("Invalid Org ID-Different Teacher")) {
			courseSettings.replace(CourseAPIConstants.ORG_ID, CourseAPIConstants.DIFFERENT_ORG_ID);
		} else if (scenario1.equals("Invalid Content Base ID")) {
			courseSettings.replace(CourseAPIConstants.CONTENT_BASE_TYPE, CourseAPIConstants.INVALID_CONTENT_BASE_TYPE);
		} else if (scenario1.equals("Invalid Content Base ID - Skill Content Base ID")) {
			courseSettings.replace(CourseAPIConstants.CONTENT_BASE_TYPE, CourseAPIConstants.STRING_THREE);
		} else if (scenario1.equals("Invalid Content Base ID - Null")) {
			courseSettings.replace(CourseAPIConstants.CONTENT_BASE_TYPE, "");
		} else if (scenario1.equals("Invalid Course Name - Duplicate")) {
			courseSettings.replace(CourseAPIConstants.COURSE_NAME, DataSetupConstants.MATH);
		} else if (scenario1.equals("Invalid  Course Name - More than 255 charc")) {
			courseSettings.replace(CourseAPIConstants.COURSE_NAME, CourseAPIConstants.TEACHER_ID_MORE_THAN_255_CHAR);
		} else if (scenario1.equals("Invalid  Course Name - Null")) {
			courseSettings.replace(CourseAPIConstants.COURSE_NAME, "");
		} else if (scenario1.equals("Invalid  Enrollment option Name")) {
			courseSettings.replace(CourseAPIConstants.SESSION_STRENGTH_NAME, CourseAPIConstants.INVALID_GRADE_ID);
		} else if (scenario1.equals("Invalid  Enrollment option Name - String")) {
			courseSettings.replace(CourseAPIConstants.SESSION_STRENGTH_NAME, CourseAPIConstants.COURSE_NAME);
		} else if (scenario1.equals("Invalid  Enrollment option Name - Symbols")) {
			courseSettings.replace(CourseAPIConstants.SESSION_STRENGTH_NAME,
					CourseAPIConstants.INVALID_COURSE_ID_SYMBOL);
		} else if (scenario1.equals("Invalid  Enrollment option ID")) {
			courseSettings.replace(CourseAPIConstants.IDLE_TIME_ID, CourseAPIConstants.INVALID_GRADE_ID);
		} else if (scenario1.equals("Invalid  Enrollment option ID - Null")) {
			courseSettings.replace(CourseAPIConstants.IDLE_TIME_ID, "");
		} else if (scenario1.equals("Invalid  Enrollment option Current Value")) {
			courseSettings.replace(CourseAPIConstants.IDLE_TIME_VALUE, CourseAPIConstants.INVALID);
		} else if (scenario1.equals("Invalid  Enrollment option Current Value - Null")) {
			courseSettings.replace(CourseAPIConstants.IDLE_TIME_VALUE, "");
		} else if (scenario1.equals("Invalid  Enrollment option Current Value - Exceeds")) {
			courseSettings.replace(CourseAPIConstants.IDLE_TIME_VALUE, CourseAPIConstants.STRING_FIFTEEN);
		} else if (scenario1.equals("Invalid  Enrollment option Current Value - Below")) {
			courseSettings.replace(CourseAPIConstants.IDLE_TIME_VALUE, CourseAPIConstants.STRING_ONE);
		} else if (scenario1.equals("Invalid Authorization")) {
			headers.replace(Constants.AUTHORIZATION, CourseAPIConstants.INVALID_AUTHORIZATION_ID);
		} else if (scenario1.equals("Invalid Enrollment ID - Duplicate")) {
			courseSettings.replace(CourseAPIConstants.IDLE_TIME_ID,
					courseSettings.get(CourseAPIConstants.SESSION_STRENGTH_ID));
			courseSettings.replace(CourseAPIConstants.IDLE_TIME_NAME,
					courseSettings.get(CourseAPIConstants.SESSION_STRENGTH_NAME));
		}

		// Updating the Custom By Settings
		apiResponse = updateCustomCourseBySetting(smUrl, headers, courseSettings, scenario, description);
		Log.message("Update course : " + apiResponse);

		// Assertion
		if (scenario1.contains("Invalid") && smUrl.contains(Constants.NIGHTLY_SM_URL)) {
			Log.softAssertThat(verifyExceptionMessage(apiResponse.get("body"), message), "Message gatting as expected",
					"Message getting as not expected");
		} else if (smUrl.contains(Constants.NIGHTLY_SM_URL)) {
			Log.softAssertThat(verifyMessage(apiResponse.get("body"), message), "Message gatting as expected",
					"Message getting as not expected");
		}
		Log.softAssertThat(apiResponse.get(Constants.STATUS_CODE).equalsIgnoreCase(statusCode),
				"Status code is returned as expected and the same is " + apiResponse.get(Constants.STATUS_CODE),
				"Status code is not returned as expected and the same is " + statusCode + " Actual - "
						+ apiResponse.get(Constants.STATUS_CODE));

		// Logging final status(pass/fail) for each case
		Log.testCaseResult();
	}

	/**
	 * Data provider for Custom Course by Settings scenarios
	 * 
	 * @return
	 */
	@DataProvider(name = "putCustomBySetting")
	public Object[][] createCourseAndUpdateCustomBySetting() {
		Object[][] inputData = {
				{ "TC001 Update default custom by Setting math course ", "Math", "Valid Math", "200", "1", "2",
						"Course updated successfully" },
				{ "TC002 Update default custom by Setting reading course", "Reading", "Valid Rading", "200", "2", "2",
						"Course updated successfully" },
				{ "TC006 Update custom by Settings Invalid Course ID", "Math", "Invalid Math", "400", "1", "2",
						"org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
				{ "TC007 Update custom by Settings Non Existing Course ID", "Reading", "Invalid Reading", "200", "2",
						"2", "com.savvas.core.exceptions.DataNotFoundException" },
				{ "TC008_Verify the status code is 400 when the invalid Course Id(&*&) is given.", "Math",
						"Invalid Course ID", "400", "1", "2",
						"org.springframework.web.method.annotation.MethodArgumentTypeMismatchException" },
				{ "TC009_Verify the status code is 400 when the invalid organization Id is given.", "Math",
						"Invalid Org ID", "400", "1", "2",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC010_Verify the status code is 400 when the non existing organization Id is given.", "Math",
						"Invalid Org ID-Non Existing", "400", "1", "2",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC011_Verify the status code is 400 when org id which is belongs to different teacher is given.",
						"Math", "Invalid Org ID-Different Teacher", "400", "1", "2",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC016_Verify the response is 400 when we pass invalid data(12#) for 'ContentBaseType' in request body",
						"Reading", "Invalid Content Base ID", "400", "2", "2",
						"org.springframework.http.converter.HttpMessageNotReadableException" },
				{ "TC017_Verify the response is 400 when we pass 'ContentBaseType' id of skill/standard base course in request body",
						"Reading", "Invalid Content Base ID - Skill Content Base ID", "400", "2", "2",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC018_Verify the response is 400 when we pass value as Null for 'ContentBaseType' and in request body",
						"Reading", "Invalid Content Base ID - Null", "400", "2", "2",
						"com.pst.exceptions.ValidationException" },
				{ "TC019_Verify the response is 400 when we pass duplicate name for 'New Course Name' in request body",
						"Math", "Invalid Course Name - Duplicate", "400", "1", "2",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC020_Verify the response is 400 when we exceeding the defined limit of characters for 'New Course Name' in request body",
						"Reading", "Invalid  Course Name - More than 255 charc", "400", "2", "2",
						"com.pst.exceptions.ValidationException" },
				{ "TC021_Verify the response is 400 when we pass value as Null for 'New Course Name' and in request body",
						"Reading", "Invalid  Course Name - Null", "400", "2", "2",
						"com.pst.exceptions.ValidationException" },
				{ "TC022_Verify the response is 400 when we pass numerical value for 'name' (enrollment option ) in request body",
						"Reading", "Invalid  Enrollment option Name", "400", "2", "2",
						"com.pst.exceptions.ValidationException" },
				{ "TC023_Verify the response is 400 when we pass invalid data(aaa) for 'name' (enrollment option ) and in request body",
						"Reading", "Invalid  Enrollment option Name - String", "400", "2", "2",
						"com.pst.exceptions.ValidationException" },
				{ "TC024_Verify the response is 400 when we pass invalid data(@#) for 'name' (enrollment option ) and in request body",
						"Reading", "Invalid  Enrollment option Name - Symbols", "400", "2", "2",
						"com.pst.exceptions.ValidationException" },
				{ "TC025_Verify the response when is 400 we pass invalid value for setting id (enrollment option ) in request body && TC027_Verify the response when we pass non existing id for setting id (enrollment option ) in request body",
						"Reading", "Invalid  Enrollment option ID", "400", "2", "2",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC026_Verify the response when we pass value as Null for setting id (enrollment option ) in request body",
						"Reading", "Invalid  Enrollment option ID - Null", "400", "2", "2",
						"com.pst.exceptions.ValidationException" },
				{ "TC028_Verify the response when we pass invalid data for \"current value\" (enrollment option ) in request body",
						"Reading", "Invalid  Enrollment option Current Value", "400", "2", "2",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC029_Verify the response when we keep \"current value\" (enrollment option ) as a null in request body",
						"Reading", "Invalid  Enrollment option Current Value - Null", "400", "2", "2",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC030_Verify the response is 400 when we exceeding the limit of Max value in request body.Ex.Idle time (max value=6)",
						"Reading", "Invalid  Enrollment option Current Value - Exceeds", "400", "2", "2",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC031_Verify the response is 400 when we pass value below the limit of minimum value in request body.Ex.Idle time (min value=3)",
						"Reading", "Invalid  Enrollment option Current Value - Below", "400", "2", "2",
						"com.savvas.core.exceptions.BusinessRuleViolationException" },
				{ "TC032_Verify the status code is 401 when the invalid authorization is given", "Reading",
						"Invalid Authorization", "401", "2", "2", "java.lang.Exception" },
				{ "TC035_Verify the status code is 500 when we pass duplicate enrollment id in request body", "Reading",
						"Invalid Enrollment ID - Duplicate", "500", "2", "2", "java.lang.IllegalStateException" }

		};
		return inputData;
	}

	// Token creation
	public void tokenCreation(String school) {
		try {

			token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(flexSchoolTeacherDetails, "userName"),
					RBSDataSetupConstants.DEFAULT_PASSWORD);

		} catch (Exception e) {
			Log.message("Issue occured in tokenCreation");
		}
	}

	/**
	 * Verifying the message
	 * 
	 * @param actualResponse
	 * @param message
	 * @return boolean
	 * @throws IOException
	 */
	public boolean verifyMessage(String actualResponse, String message) throws IOException {

		boolean flag = false;
		if (SMUtils.getKeyValueFromResponse(actualResponse, "messages,message").equalsIgnoreCase(message)) {
			Log.message("status Verified successfully!");
			flag = true;
		} else {
			Log.message("Issue in displaying status!");
		}
		return flag;
	}

	/**
	 * Verifying the Exception information
	 * 
	 * @param actualResponse
	 * @param exception
	 * @return boolean
	 * @throws IOException
	 */
	public boolean verifyExceptionMessage(String actualResponse, String exception) throws IOException {

		boolean flag = false;
		if (SMUtils.getKeyValueFromResponse(actualResponse, "messages,exception").equalsIgnoreCase(exception)) {
			Log.message("Exception Verified successfully!");
			flag = true;
		} else {
			Log.message("Issue in displaying exception!");
		}
		return flag;
	}

	/**
	 * To create a course based on Setting.
	 * 
	 * @param smUrl
	 * @param sessionCookie
	 * @param subject
	 * @param teacherID
	 * @param schoolID
	 * @param courseName
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, String> createCourseSetting(String smUrl, String token, String subject, String teacherID,
			String orgID, String courseName) throws Exception {
		HashMap<String, String> response_post = new HashMap<>();
		try {
			Map<String, String> headers = new HashMap<String, String>();
			headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
			headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
			headers.put(Constants.AUTHORIZATION, "Bearer " + token);
			headers.put(Constants.USERID_SM_HEADER, teacherID);
			headers.put(Constants.ORGID_SM_HEADER, orgID);
			// Input Params
			HashMap<String, String> params = new HashMap<>();

			// EndPoint Details
			String endPoint_post = CourseAPIConstants.CREATE_CUSTOM_COURSE;
			if (subject.contentEquals(DataSetupConstants.MATH)) {
				endPoint_post = endPoint_post.replace(Constants.COURSE_ID, "1");
			} else {
				endPoint_post = endPoint_post.replace(Constants.COURSE_ID, "2");
			}

			endPoint_post = endPoint_post.replace(Constants.ORG_ID, orgID);
			endPoint_post = endPoint_post.replace(Constants.STAFF_ID, teacherID);

			Map<String, String> courseDetails = new HashMap<String, String>();
			courseDetails.put(Constants.COURSE_NAME, courseName);
			String requestBody = null;
			if (subject.equalsIgnoreCase(DataSetupConstants.MATH)) {
				requestBody = dataprocess.generateRequestBody(
						SMUtils.convertFileToString(SMUtils.getPayLoadDirPath() + "customBySettings_MATH.json"),
						courseDetails);
			} else {
				requestBody = dataprocess.generateRequestBody(
						SMUtils.convertFileToString(SMUtils.getPayLoadDirPath() + "customBySettings_READING.json"),
						courseDetails);
			}

			response_post = RestHttpClientUtil.POST(smUrl, headers, params, endPoint_post, requestBody);
			if (response_post.get(Constants.STATUS_CODE).equals("201")) {
				return response_post;
			} else {
				return response_post;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response_post;
	}

	/**
	 * Get response for the update Course By Setting API
	 *
	 * @param envUrl
	 * @param headers
	 * @param courseDetails
	 * @param scenario
	 * @return
	 */
	public HashMap<String, String> updateCustomCourseBySetting(String envUrl, HashMap<String, String> headers,
			HashMap<String, String> updateSettings, String scenario, String description) {
		try {

			String endpoint = CourseAPIConstants.UPDATE_CUSTOM_COURSE_BY_STANDARDS;
			Log.message("update custom course by standard= " + endpoint);
			endpoint = endpoint.replace(Constants.ORG_ID, updateSettings.get(CourseAPIConstants.ORG_ID));
			endpoint = endpoint.replace(Constants.STAFF_ID, updateSettings.get(CourseAPIConstants.TEACHER_ID));
			endpoint = endpoint.replace(Constants.COURSE_ID, updateSettings.get(CourseAPIConstants.COURSE_ID));
			Log.message("endpoint=" + envUrl + endpoint);
			String requestBody = null;

			if (scenario.contains(DataSetupConstants.READING)) {
				requestBody = SMUtils.convertFileToString(
						new EnvProperties().configProperty.getProperty("updateCustomBySettingsReading"));
			} else {
				requestBody = SMUtils.convertFileToString(
						new EnvProperties().configProperty.getProperty("updateCustomBySettingsMath"));
			}

			requestBody = requestBody.replace(Constants.COURSENAME_VALUE, updateSettings.get(Constants.COURSE_NAME));
			requestBody = requestBody.replace(Constants.SESSION_LENGTH_ID,
					updateSettings.get(CourseAPIConstants.SESSION_STRENGTH_ID));
			requestBody = requestBody.replace(Constants.SESSION_LENGTH_NAME,
					updateSettings.get(CourseAPIConstants.SESSION_STRENGTH_NAME));
			requestBody = requestBody.replace(Constants.SESSION_LENGTH_VALUE,
					updateSettings.get(CourseAPIConstants.SESSION_STRENGTH_VALUE));
			requestBody = requestBody.replace(Constants.IDLE_TIME_ID,
					updateSettings.get(CourseAPIConstants.IDLE_TIME_ID));
			requestBody = requestBody.replace(Constants.IDLE_TIME_NAME,
					updateSettings.get(CourseAPIConstants.IDLE_TIME_NAME));
			requestBody = requestBody.replace(Constants.IDLE_TIME_VALUE,
					updateSettings.get(CourseAPIConstants.IDLE_TIME_VALUE));
			requestBody = requestBody.replace(Constants.CONTENTBASE_ID,
					updateSettings.get(CourseAPIConstants.CONTENT_BASE_TYPE));

			Log.message("payload : " + requestBody);
			Log.message(headers.toString());

			return RestHttpClientUtil.PUT(envUrl, headers, new HashMap<String, String>(), endpoint, requestBody);

		} catch (Exception e) {
			Log.message("Error in updating the Course method");
			return null;
		}
	}

}
