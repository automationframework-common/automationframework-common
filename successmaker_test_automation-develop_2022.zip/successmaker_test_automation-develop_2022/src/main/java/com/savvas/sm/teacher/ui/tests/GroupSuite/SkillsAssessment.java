package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.stream.IntStream;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.GetGroupMostAssessedSkill;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

public class SkillsAssessment extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String chromePlatform = "Windows_10_Chrome_latest"; //for Simulator Execution
    private static String groupOne;
    private static String groupThree;
    private static String teacherDetails;
    private static String groupDetails1;
    private static String groupDetails2;
    private static String studentOne;
    private static String studentTwo;
    private static String studentFour;
    private static String studentFive;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String customCourse;

    WebDriver driver;
    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    @BeforeClass
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );

        String studentDetails1 = RBSDataSetup.getMyStudent( school, username );
        String studentDetails2 = RBSDataSetup.getMyStudent( school, username );
        String studentDetails4 = RBSDataSetup.getMyStudent( school, username );
        String studentDetails5 = RBSDataSetup.getMyStudent( school, username );

        studentOne = ( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ) );
        studentTwo = ( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERNAME ) );
        studentFour = ( SMUtils.getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERNAME ) );
        studentFive = ( SMUtils.getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERNAME ) );

        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERID ) );

        HashMap<String, String> groupDetailsMap = new HashMap<>();
        groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, "SM Regression Group" + System.nanoTime() );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );
        groupDetails1 = createGroup.get( Constants.BODY );
        groupOne = SMUtils.getKeyValueFromResponse( groupDetails1, "data,groupName" );

        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, "SM Regression Group" + System.nanoTime() );
        createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );
        groupDetails2 = createGroup.get( Constants.BODY );
        groupThree = SMUtils.getKeyValueFromResponse( groupDetails2, "data,groupName" );

    }

    @Test ( description = "Verify zero state is displayed if the assessment is not started by the students", groups = { "SMK-43939", "groups", "groupSkillsAssessment" }, priority = 1 )
    public void tcSkillsAssessment001() throws Exception {

        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcSkillsAssessment001: Verify zero state is displayed if the assessment is not started by the students <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to Course Listing Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Math Course and assigning to groups
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();
            coursePage.clickBackIcon();

            // Selecting Reading Course and assigning to groups
            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();

            SMUtils.logDescriptionTC( "SMK-14077 - Verify zero state is displayed if the assessment is not started by the students" );
            // Navigate to Groups Tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupOne );

            //Verify zero state message for student usage chart
            String zeroStateFromUI = groupsTab.getSkillsAssessmentZeroState();
            Log.assertThat( zeroStateFromUI.contains( Constants.GroupUIConstants.SKILLASSESS_ZEROSTATEMESSAGE.get( 0 ) ) && zeroStateFromUI.contains( Constants.GroupUIConstants.SKILLASSESS_ZEROSTATEMESSAGE.get( 1 ) ),
                    "Zero state message is displayed sucessfully for Skills Assessment!", "Zero state message is not displayed properly for Skills Assessment." );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify headers and assignment dropdown in Skills Assessment.", groups = { "SMK-43939", "groups", "groupSkillsAssessment" }, priority = 1 )
    public void tcSkillsAssessment002() throws Exception {

        WebDriver driver = null;
        WebDriver chromeDriver = WebDriverFactory.get( chromePlatform ); //for simulator run

        Log.testCaseInfo( "tcSkillsAssessment002: Verify headers and assignment dropdown in Skills Assessment. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Executing math and reading assignments in student dashboard
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage = smStudentLoginPage.loginToSMasStudent( studentOne, password, true );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ), "Math", "100", "3", "10" );
            studentOneDashboardPage.executeReadingCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ), "Reading", "100", "3", "10" );
            studentOneDashboardPage.logout();
            chromeDriver.quit();

            // Get driver
            driver = WebDriverFactory.get( browser );
            // Login as Teacher
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupOne );

            SMUtils.logDescriptionTC( "SMK-14074 - Verify the header is displayed in the Skills assessed in group details page" );
            Log.assertThat( groupsTab.getGroupDetailsHeader( Constants.GroupUIConstants.SKILLS_ASSESSMENT ).equals( Constants.GroupUIConstants.SKILLS_ASSESSMENT ), "Skills Assessment header is present", "Skills Assessment header is wrong" );

            SMUtils.logDescriptionTC( "SMK-14078 - Verify the text PERCENT OF STUDENTS MASTERED is displayed in the skills assessed in group details page" );
            Log.assertThat( groupsTab.getGroupDetailsHeader( Constants.GroupUIConstants.PERCENT_OF_STUDENTS_MASTERED ).equals( Constants.GroupUIConstants.PERCENT_OF_STUDENTS_MASTERED ), "PERCENT OF STUDENTS MASTERED header is present",
                    "PERCENT OF STUDENTS MASTERED header is wrong" );

            SMUtils.logDescriptionTC( "SMK-14079 - Verify the drop down to select the assignment to show the progress in the skill assessed of the group is displayed" );
            Log.assertThat( groupsTab.isAssignmentDropdownPresent(), "Assignment dropdown is present in Skills Assessment", "Assignment dropdown is not present in Skills Assessment" );

            SMUtils.logDescriptionTC( "SMK-14083 - Verify the assignments assigned for the group is displayed in the assignment drop down in skills assessed" );
            Log.assertThat( groupsTab.getValuesFromAssignmentsDropdown().containsAll( Constants.Reports.SUBJECTS ), "All assignments are listed in Assignments dropdown", "All assignments are not listed in Assignments dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of LO, progress bar and View Details link", groups = { "SMK-43939", "groups", "groupSkillsAssessment" }, priority = 1 )
    public void tcSkillsAssessment003() throws Exception {
        // Get driver
        driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSkillsAssessment003: Verify the functionality of LO and progress bar <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Login as Teacher
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupOne );

            //Get skills assess data from API

            HashMap<String, String> groupDetailsMap = new HashMap<>();

            groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
            groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
            groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
            groupDetailsMap.put( CreateGroupAPIConstants.GROUP_ID, SMUtils.getKeyValueFromResponse( groupDetails1, "data,groupId" ) );
            groupDetailsMap.put( GetGroupMostAssessedSkill.SUBJECT_TYPE_ID, AssignmentAPIConstants.MATH );
            groupDetailsMap.put( GetGroupMostAssessedSkill.CONTENT_BASE, AssignmentAPIConstants.MATH );

            HashMap<String, String> dataFromAPI = new GroupAPI().getMostSkillAssessedForGroup( smUrl, groupDetailsMap );

            Log.message( "Skill tested Response: " + dataFromAPI );
            // getting list of skill names
            List<String> skillName = new ArrayList<>();
            IntStream.rangeClosed( 1, 3 ).forEach( index -> skillName.add( SMUtils.getKeyValueFromJsonArray( dataFromAPI.get( Constants.REPORT_BODY ), "skillName", index ) ) );

            //getting list of mastered percentage
            List<String> percentMastered = new ArrayList<>();
            IntStream.rangeClosed( 1, 3 ).forEach( index -> percentMastered.add( SMUtils.getKeyValueFromJsonArray( dataFromAPI.get( Constants.REPORT_BODY ), "percentMastered", index ) ) );

            SMUtils.logDescriptionTC( "SMK-14090 - Verify the LO is displayed in the skills assessed" );
            SMUtils.logDescriptionTC( "SMK-14091 - Verify the LO is displayed in order in the skills assessed" );
            // Verifying LO is displayed in order
            Log.assertThat( groupsTab.getSkillsName().equals( skillName ), "All skill names are displayed in order", "All skill names are not displayed in order" );

            SMUtils.logDescriptionTC( "SMK-14093 - Verify the LO displayed is clickable" );
            // Verifying LO is clicked and LO description
            groupsTab.clickLO();
            Log.assertThat( groupsTab.getSkillNameInSkillPopup().equals( skillName.get( 0 ) ), "LO is clickable and LO description is displayed as expected", "LO is not clickable or LO description is wrong" );
            groupsTab.cickCloseBtnInSkillPopup();

            SMUtils.logDescriptionTC( "SMK-14098 - Verify the progress percentage range in the progress bar for each LO listed in the skills assessed" );
            // Verifying progress percent range
            boolean loPercent = false;
            for ( String percentRange : percentMastered ) {
                loPercent = Integer.parseInt( percentRange ) <= 100;
            }
            Log.assertThat( loPercent, "The progress percent rage is correct as excepted", "The progress percent rage is wrong" );

            SMUtils.logDescriptionTC( "SMK-14095 - Verify the progress bar is displayed for each LO listed in the skills assessed" );
            SMUtils.logDescriptionTC( "SMK-14097 - Verify the progress percentage is displayed in the progress bar for the LOs that are assessed and not mastered" );
            // Verifying progress bar is displayed in each LO
            Log.assertThat( groupsTab.isProgressBarDisplayedForEachLO(), "Progress bar is displayed in each LO for both mastered and not mastered", "Progress bar is not displayed in each LO for both mastered and not mastered" );

            SMUtils.logDescriptionTC( "SMK-14096 - Verify the progress percentage is displayed in the progress bar for each LO listed in the skills assessed" );
            // Verifying progress percent is displaying for each LO
            List<String> progressPercent = new ArrayList<>();
            for ( String percent : percentMastered ) {
                progressPercent.add( percent + "%" );
            }
            Log.assertThat( groupsTab.getProgressPrecent().equals( progressPercent ), "Progress percent is displayed for each LO", "Progress percent is not displayed for each LO" );

            SMUtils.logDescriptionTC( "SMK-14089 - Verify the functionality of View Details link in the skills assessed" );
            // Verifying view details link navigation
            groupsTab.cickViewDetails();
            AssignmentDetailsPage assignmentPage = new AssignmentDetailsPage( driver );
            Log.assertThat( assignmentPage.gettitleOfAssignmentDetailsPage().contains( Constants.Reports.SUBJECTS.get( 0 ) ), "View Details link is navigate to the selected assignment details page",
                    "View Details link is not navigate to the selected assignment details page" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the progress change is displayed when the student is removed/added to the group", groups = { "SMK-43939", "groups", "groupSkillsAssessment" }, priority = 1 )
    public void tcSkillsAssessment004() throws Exception {

        WebDriver driver = null;
        WebDriver chromeDriver = WebDriverFactory.get( chromePlatform ); //for simulator run

        Log.testCaseInfo( "tcSkillsAssessment004: Verify the progress change is displayed when the student is removed/added to the group. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Executing math assignments in student dashboard
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage = smStudentLoginPage.loginToSMasStudent( studentTwo, password, true );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ), "Math", "100", "3", "10" );
            studentOneDashboardPage.logout();
            chromeDriver.quit();

            // Get driver
            driver = WebDriverFactory.get( browser );
            // Login as Teacher
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupOne );
            List<String> beforeStudentRemoved = groupsTab.getProgressPrecent();

            SMUtils.logDescriptionTC( "SMK-14108 - Verify the progress change is displayed when the student is removed from the group/transfered/deleted from admin dashboard" );
            SMUtils.logDescriptionTC( "SMK-14099 - Verify the progress percentage range in the progress bar for each LO is increasing/decreasing" );

            // Remove student from group
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();
            SMUtils.nap( 2 ); // wait required for Student page loading
            studentsTab.clickviewStudentByEllipsis( studentTwo );
            studentsTab.clickRemoveStudentToGroupText( groupOne );
            SMUtils.nap( 2 ); // wait is required to get remove pop-up
            studentsTab.clickRemoveButtonInPopup();

            // Navigate to Groups Tab
            teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupOne );
            List<String> afterStudentRemoved = groupsTab.getProgressPrecent();

            // Validating the progress after removing the Student
            Log.assertThat( !beforeStudentRemoved.equals( afterStudentRemoved ), "The progress is changed after removing the Student", "The progress is not changed after removing the Student" );

            SMUtils.logDescriptionTC( "SMK-14110 - Verify the progress done by the individual Student who is added to the group with same assignment is updated" );
            SMUtils.logDescriptionTC( "SMK-14112 - Verify the progress change is displayed when a new student is added to the group" );

            // Add Student to the group
            groupsTab.clickAddStudentToGroup();
            groupsTab.addStudentToGroup( studentTwo );
            List<String> afterStudentAdded = groupsTab.getProgressPrecent();

            // Validating the progress after adding the Student
            Log.assertThat( afterStudentAdded.equals( beforeStudentRemoved ), "The progress done by the student is added", "The progress done by the student is not added" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the progress after assignment paused/deleted in Skills Assessment.", groups = { "SMK-43939", "groups", "groupSkillsAssessment" }, priority = 1 )
    public void tcSkillsAssessment005() throws Exception {
        // Get driver
        driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSkillsAssessment005: Verify the progress after assignment paused/deleted in Skills Assessment. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // Login as Teacher
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupOne );
            List<String> beforeAssignmentPaused = groupsTab.getProgressPrecent();
            List<String> beforeAssignmentDeleted = groupsTab.getValuesFromAssignmentsDropdown();

            SMUtils.logDescriptionTC( "SMK-14106 - Verify the assignements deleted are not listed in the assignments drop down of the skills assessed" );

            // To delete Reading assignment
            AssignmentsPage assignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.GroupUIConstants.READING );
            AssignmentDetailsPage assignmentDetails = new AssignmentDetailsPage( driver );
            assignmentDetails.clickDeleteAssignmenttabTopEllipsis();
            SMUtils.nap( 2 ); //wait is required for assignment listing page to get loaded

            SMUtils.logDescriptionTC( "SMK-14111 - Verify the skills assessed displays the paused assignment LOs assessed within last 30 days by the students of the group" );

            // To pause Math assignment
            assignmentsPage.viewAssignmentDetailsByAssignmentName( Constants.GroupUIConstants.MATH );
            assignmentDetails.pauseAllStudent();
            assignmentDetails.clickPauseButtononPopUpPage();

            // Navigate to Groups Tab
            teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupOne );
            List<String> afterAssignmentPaused = groupsTab.getProgressPrecent();
            List<String> afterAssignmentDeleted = groupsTab.getValuesFromAssignmentsDropdown();

            // Validating the progress after assignment paused
            Log.assertThat( beforeAssignmentPaused.equals( afterAssignmentPaused ), "The progress are listed for paused assignments", "The progress are not listed for paused assignments" );
            // Verifying the assignment drop down after deleting an assignment
            Log.assertThat( !beforeAssignmentDeleted.equals( afterAssignmentDeleted ), "Deleted assignment is not displayed in assignment dropdown", "Deleted assignment is displayed in assignment dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify zero state and functionality of assignment dropdown", groups = { "SMK-43939", "groups", "groupSkillsAssessment" }, priority = 3 )
    public void tcSkillsAssessment006() throws Exception {

        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcSkillsAssessment006: Verify zero state and functionality of assignment dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithoutStudent( Constants.Groups.GROUP_ALLGRADES );

            // navigate to Course Listing Page
            CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Selecting Reading Course and assigning to groups
            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();
            coursePage.clickBackIcon();

            // Selecting Reading Course and assigning to groups
            teacherHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();
            coursePage.clickBackIcon();

            teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( Constants.Groups.GROUP_ALLGRADES );

            //Verify zero state message for student usage chart
            SMUtils.logDescriptionTC( "Verify zero state is displayed if no assignments are available for the teacher" );
            String zeroStateMessage = groupsTab.getSkillsAssessmentZeroState();
            Log.assertThat(
                    zeroStateMessage.contains( Constants.GroupUIConstants.SKILLASSESS_NO_ASSIGNMENT_ZERO_STATE_MESSAGE.get( 0 ) ) && zeroStateMessage.contains( Constants.GroupUIConstants.SKILLASSESS_NO_ASSIGNMENT_ZERO_STATE_MESSAGE.get( 1 ) )
                            && zeroStateMessage.contains( Constants.GroupUIConstants.SKILLASSESS_NO_ASSIGNMENT_ZERO_STATE_MESSAGE.get( 2 ) ),
                    "Zero state message is displayed sucessfully for Skills Assessment if no assignment", "Zero state message is not displayed sucessfully for Skills Assessment if no assignment" );

            teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( Constants.Groups.GROUP_ALLGRADES );
            groupsTab.clickAddStudentToGroup();
            groupsTab.addStudentToGroup( studentFour );

            // navigate to Course Listing Page
            teacherHomePage.topNavBar.navigateToCourseListingPage();

            //Create and add custom course to group
            customCourse = Constants.CUSTOM_BY_STANDARDS_COURSE + System.nanoTime();
            coursePage.createCustomByStandardCourse( customCourse, Constants.MATH );
            coursePage.clickCourseName( customCourse );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();
            teacherHomePage.topNavBar.navigateToCourseListingPage();
            String lognCourseName = Constants.MAX_LENGTH_COURSE_NAME + RandomStringUtils.randomAlphanumeric( 5 );
            coursePage.createCustomByStandardCourse( lognCourseName, Constants.MATH );
            coursePage.clickCourseName( lognCourseName );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();
            teacherHomePage.topNavBar.navigateToCourseListingPage();

            // Add focus course to group
            coursePage.clickCourseName( Constants.SM_FOCUS_READING_GRADE1 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();

            teacherHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( Constants.SM_FOCUS_MATH_GRADE1 );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();
            teacherHomePage.topNavBar.navigateToAssignmentsPage();

            // Navigate to Groups tab
            teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( Constants.Groups.GROUP_ALLGRADES );

            SMUtils.logDescriptionTC( "Verify zero state is displayed if there is no progress for the last 30 days" );
            String zeroStateFromUI = groupsTab.getSkillsAssessmentZeroState();
            Log.assertThat( zeroStateFromUI.contains( Constants.GroupUIConstants.SKILLASSESS_ZEROSTATEMESSAGE.get( 0 ) ) && zeroStateFromUI.contains( Constants.GroupUIConstants.SKILLASSESS_ZEROSTATEMESSAGE.get( 1 ) ),
                    "Zero state message is displayed sucessfully for Skills Assessment!", "Zero state message is not displayed properly for Skills Assessment." );

            SMUtils.logDescriptionTC( "Verify the default selected option in the assignment drop down in the skills assessed if group has Foucs or custom course assignment" );
            Log.assertThat( groupsTab.getSelectedAssignment().equalsIgnoreCase( Constants.MATH ), "The default selected option in the assignment drop down is same as excepted if group has Foucs or custom course assignment",
                    "The default selected option in the assignment drop down is wrong if group has Foucs or custom course assignment" );

            SMUtils.logDescriptionTC( "Verify the drop down to select the assignment to show the progress in the skill assessed of the group is selectable" );
            Log.assertThat( groupsTab.selectValuesFromAssignmentsDropdown( Constants.SM_FOCUS_READING_GRADE1 ), "Assignment in assignments dropdown is selectable", "Assignment in assignments dropdown is not selectable" );

            List<String> valuesFromAssignmentsDropdown = groupsTab.getValuesFromAssignmentsDropdown();
            SMUtils.logDescriptionTC( "Verify the longer assignment names are displayed in the drop down with the ellipse at the end of the name in the skills assessed" );
            SMUtils.logDescriptionTC( "Verify the LO / Assignmnet with longer names are displayed with ellipse icon" );
            Log.assertThat( valuesFromAssignmentsDropdown.stream().anyMatch( value -> value.contains( "..." ) ), "The longer assignment name is displayed in the drop down with the ellipse at the end of the name",
                    "The longer assignment name is not displayed in the drop down with the ellipse at the end of the name" );

            SMUtils.logDescriptionTC( "Verify the down arrow is displayed in the assignment drop down in skills assessed" );
            Log.assertThat( groupsTab.verifyDownArrowPresentInAssignmentDropdown(), "The down arrow is displayed in the assignment drop down in skills assessed", "The down arrow is not displayed in the assignment drop down in skills assessed" );

            List<String> exceptedOrder = Arrays.asList( Constants.MATH, Constants.READING, Constants.SM_FOCUS_MATH_GRADE1, Constants.SM_FOCUS_READING_GRADE1, customCourse, Constants.COURSE_NAME_WITH_ELLIPSE );

            SMUtils.logDescriptionTC( "Verify the list in the assignment select drop down is sorted alphabetically for Foucs course assignment" );

            SMUtils.logDescriptionTC( "Verify the list in the assignment select drop down is sorted in the order of assignment assigned for custom course assignment" );
            Log.assertThat( valuesFromAssignmentsDropdown.equals( exceptedOrder ), "The order in assignment dropdown is same as excepted for focus and custom course assignments",
                    "The order in assignment dropdown is not same as excepted for focus and custom course assignments" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the LO skill name is displayed for all courses in the skills assessed", groups = { "SMK-43939", "groups", "groupSkillsAssessment" }, priority = 3 )
    public void tcSkillsAssessment007() throws Exception {

        WebDriver driver = null;
        WebDriver chromeDriver = WebDriverFactory.get( chromePlatform ); //for simulator run

        Log.testCaseInfo( "tcSkillsAssessment007: Verify the LO skill name is displayed for all courses in the skills assessed. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            // Get driver
            driver = WebDriverFactory.get( browser );
            // Login as Teacher
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            AssignmentsPage navigateToAssignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();
            List<String> allAssignmentNames = navigateToAssignmentsPage.getAllAssignmentNames();
            String standardAssignment = null;
            for ( String assignment : allAssignmentNames ) {
                if ( assignment.toLowerCase().contains( "math" ) && assignment.toLowerCase().contains( "standard" ) ) {
                    standardAssignment = assignment;
                }
            }
            teacherHomePage.topNavBar.signOutfromSM();
            driver.quit();

            //Executing custom and focus assignments in student dashboard
            LoginPage smStudentLoginPage = new LoginPage( chromeDriver, smUrl ).get();
            StudentDashboardPage studentOneDashboardPage = smStudentLoginPage.loginToSMasStudent( studentFour, password, true );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ), customCourse, "100", "1", "1" );
            studentOneDashboardPage.executeMathCourse( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ), Constants.SM_FOCUS_MATH_GRADE1, "100", "3", "10" );
            studentOneDashboardPage.logout();
            chromeDriver.quit();

            // Get driver
            driver = WebDriverFactory.get( browser );
            // Login as Teacher
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupOne );

            SMUtils.logDescriptionTC( "Verify the default selected option in the assignment drop down in the skills assessed for a teacher with default license" );
            Log.assertThat( groupsTab.getSelectedAssignment().equalsIgnoreCase( Constants.MATH ), "The default selected option in the assignment drop down is same as excepted for default license",
                    "The default selected option in the assignment drop down is wrong for default license" );

            SMUtils.logDescriptionTC( "Verify the LO skill name is displayed in the skills assessed" );
            SMUtils.logDescriptionTC( "Verify the skills assessed displays all the LOs assessed within last 30 days by the students of the group" );
            Log.assertThat( groupsTab.verifySkillsNameIsPresent(), "Lo skill name is displayed in Skills Assessd", "Lo skill name is not displayed in Skills Assessd" );

            SMUtils.logDescriptionTC( "Verify the skills assessed displays the minimum LOs assessed within last 30 days by the students of the group" );
            groupsTab.selectValuesFromAssignmentsDropdown( customCourse );
            Log.assertThat( groupsTab.getSkillsName().size() < 3, "Skills assessed displays the minimum LOs assessed within last 30 days by the students of the group",
                    "Skills assessed is not displays the minimum LOs assessed within last 30 days by the students of the group" );

            SMUtils.logDescriptionTC( "Verify the skills assessed displays the default math/reading LOs assessed within last 30 days by the students of the group" );
            groupsTab.selectValuesFromAssignmentsDropdown( Constants.READING );
            Log.assertThat( groupsTab.verifySkillsNameIsPresent(), "skills assessed displays the default math/reading LOs assessed within last 30 days by the students of the group",
                    "skills assessed is not displays the default math/reading LOs assessed within last 30 days by the students of the group" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify skills assessed displays for all courses", groups = { "SMK-43939", "groups", "groupSkillsAssessment" }, priority = 3 )
    public void tcSkillsAssessment008() throws Exception {

        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcSkillsAssessment008: Verify skills assessed displays for all courses <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( Constants.Groups.GROUP_ALLGRADES );

            groupsTab.selectValuesFromAssignmentsDropdown( Constants.SM_FOCUS_MATH_GRADE1 );
            SMUtils.logDescriptionTC( "Verify the skills assessed displays the focused course LOs assessed within last 30 days by the students of the group" );
            Log.assertThat( groupsTab.verifySkillsNameIsPresent(), "skills assessed displays the focused course LOs assessed within last 30 days by the students of the group",
                    "skills assessed is not displays the default math/reading LOs assessed within last 30 days by the students of the group" );

            groupsTab.selectValuesFromAssignmentsDropdown( customCourse );
            SMUtils.logDescriptionTC( "Verify the skills assessed displays the shared course LOs assessed within last 30 days by the students of the group" );
            SMUtils.logDescriptionTC( "Verify the skills assessed displays the custom course LOs assessed within last 30 days by the students of the group" );
            Log.assertThat( groupsTab.verifySkillsNameIsPresent(), "skills assessed displays the default custom / shared course LOs assessed within last 30 days by the students of the group",
                    "skills assessed is not displays the default custom / shared course LOs assessed within last 30 days by the students of the group" );

            groupsTab.clickBackIcon();
            groupsTab.viewGroup( groupThree );

            groupsTab.clickAddStudentToGroup();
            groupsTab.addStudentToGroup( studentFive );

            //            SMUtils.logDescriptionTC( "Verify Zero State is displayed when removing the older Student and adding new Student" );
            //            String zeroStateFromUI = groupsTab.getSkillsAssessmentZeroState();
            //            Log.assertThat( zeroStateFromUI.contains( Constants.GroupUIConstants.SKILLASSESS_ZEROSTATEMESSAGE.get( 0 ) ) && zeroStateFromUI.contains( Constants.GroupUIConstants.SKILLASSESS_ZEROSTATEMESSAGE.get( 1 ) ),
            //                    "Zero State is displayed when removing the older Student and adding new Student", "Zero State is not displayed when removing the older Student and adding new Student" );

            groupsTab.clickAddStudentToGroup();
            groupsTab.addStudentToGroup( studentOne );
            groupsTab.clickAddStudentToGroup();
            groupsTab.addStudentToGroup( studentTwo );
            groupsTab.clickBackIcon();

            groupsTab.viewGroup( groupOne );
            List<String> exceptedProgress = groupsTab.getProgressPrecent();
            groupsTab.clickBackIcon();

            groupsTab.viewGroup( groupThree );
            List<String> actualProgress = groupsTab.getProgressPrecent();

            SMUtils.logDescriptionTC( "Verify the progress of a student from another group is added to a group with same assignment" );
            Log.assertThat( actualProgress.containsAll( exceptedProgress ), "The progress is same as excepted when a student from another group is added to a group with same assignment",
                    "The progress is wrong when a student from another group is added to a group with same assignment" );

            SMUtils.logDescriptionTC( "Verify the ? icon on the top nav bar of Group details page navigates the user content page" );
            teacherHomePage.topNavBar.navigateToHelpPage();
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();
            Log.assertThat( teacherHomePage.getGroupsPageHelpPageHeader().getText().trim().contains( Constants.GROUP_HELP_PAGE_TEXT ), "Group page help icon navigates the user to content page",
                    "Group page help icon is not navigates the user to content page" );
            Log.testCaseResult();
            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                teacherHomePage = new TeacherHomePage( driver );
                teacherHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

}
