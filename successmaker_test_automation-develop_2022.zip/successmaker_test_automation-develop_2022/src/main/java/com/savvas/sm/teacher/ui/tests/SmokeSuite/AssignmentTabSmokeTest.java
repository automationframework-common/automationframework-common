package com.savvas.sm.teacher.ui.tests.SmokeSuite;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class AssignmentTabSmokeTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String SESSION_LENGHT_SELECTED_FOR = "20 minutes";
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherID;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify Assignment Listing", priority = 1 )
    public void tcSMBVT022() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

        Log.testCaseInfo( "tcSMBVT022: Verify Assignment Listing <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Get Assignments Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            Log.assertThat( assignmentsPage.viewAssignmentElement().isDisplayed(), "View Assignment button is displayed", "View Assignment button is not displayed" );

            Log.assertThat( assignmentsPage.getColumnAssignmnetTitle().equals( Constants.ASSIGNMENT_TITLE ), "Assignment Title column is displayed", "Assignment Title column is not displayed" );
            Log.assertThat( assignmentsPage.getColumnDateAssigned().equals( Constants.DATE_ASSIGNED ), "Date Assigned column is displayed", "Date Assigned column is not displayed" );
            Log.assertThat( assignmentsPage.getColumnActiveStudents().equals( Constants.ACTIVE_STUDENTS ), "Active Students column is displayed", "Active Students column is not displayed" );
            Log.assertThat( assignmentsPage.getColumnPausedStudents().equals( Constants.PAUSED_STUDENTS ), "Paused Students column is displayed", "Paused Students column is not displayed" );
            Log.assertThat( assignmentsPage.getColumnFluencyFiles().equals( Constants.FLUENCY_FILES ), "Fluency Files column is displayed", "Fluency Files column is not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Assignment Details Page", priority = 1 )
    public void tcSMBVT023() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

        Log.testCaseInfo( "tcSMBVT023: Verify Assignment Details Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
        	 LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
             TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

             // Get Assignments Page
             AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

             AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.clickViewAssignment();

             //            Log.assertThat( assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals( Constants.CUSTOM_ASSIGMENT_TITLE ), "Assignment Title is displayed", "Assignment Title is not displayed" );
             Log.assertThat( ( assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage().contains( Constants.ACTIVE_STUDENTS_ASSIGMENT_SUBTITILE )
                     && assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage().contains( Constants.PAUSED_STUDENTS_ASSIGMENT_SUBTITILE ) ), "Assignment SubTitle is displayed", "Assignment SubTitle is not displayed" );

             Log.assertThat( assignmentDetailsPage.assignElement().isDisplayed(), "Assign button is displayed", "Assign button is not displayed" );

             assignmentDetailsPage.assignmentLevelEllipsis();

             Log.assertThat( assignmentDetailsPage.assignmentSettingTabTopEllipsis().equals( Constants.ASSIGMENT_SETTINGS ), "Assignment Settings Tab is displayed", "Assignment Settings Tab is not displayed" );
             Log.assertThat( assignmentDetailsPage.pauseAllStudentTopEllipsis().equals( Constants.PAUSED_ALL_STUDENTS ), "Pause All Student is displayed", "Pause All Student is not displayed" );
             Log.assertThat( assignmentDetailsPage.deleteAssignmenttabTopEllipsis().equals( Constants.DELETED_ASSIGNMENT ), "Delete Assignment Tab is displayed", "Delete Assignment Tab is not displayed" );

             Log.assertThat( assignmentDetailsPage.getColumnName().trim().equals( Constants.NAME ), "NAME Column is displayed in the Assignment_Details_Page", "NAME Column is not displayed in the Assignment_Details_Page" );
             Log.assertThat( assignmentDetailsPage.getColumnLastSession().trim().equals( Constants.LAST_SESSION ), "LAST_SESSION Column is displayed in the Assignment_Details_Page", "LAST_SESSION Column is not displayed in the Assignment_Details_Page" );
             Log.assertThat( assignmentDetailsPage.getColumnIPLevel().trim().equals( Constants.IP_LEVEL ), "IP_LEVEL Column is displayed in the Assignment_Details_Page", "IP_LEVEL Column is not displayed in the Assignment_Details_Page" );
             Log.assertThat( assignmentDetailsPage.getColumnAssignedLevel().trim().equals( Constants.ASSIGNED_LEVEL ), "ASSIGNED_LEVEL Column is displayed in the Assignment_Details_Page",
                     "ASSIGNED_LEVEL Column is not displayed in the Assignment_Details_Page" );
             Log.assertThat( assignmentDetailsPage.getColumnCurrentLevel().trim().equals( Constants.CURRENT_LEVEL ), "CURRENT_LEVEL Column is displayed in the Assignment_Details_Page",
                     "CURRENT_LEVEL Column is not displayed in the Assignment_Details_Page" );
             Log.assertThat( assignmentDetailsPage.getColumnGain().trim().equals( Constants.GAIN ), "GAIN Column is displayed in the Assignment_Details_Page", "GAIN Column is not displayed in the Assignment_Details_Page" );

             assignmentDetailsPage.clickDotEllipsisButton();

             Log.assertThat( assignmentDetailsPage.assignmentSettingInEllipsis().equals( Constants.ASSIGMENT_SETTINGS ), "Assignment Settings Tab is displayed", "Assignment Settings Tab is not displayed" );
             Log.assertThat( assignmentDetailsPage.pauseAssignmentForStudentTabInEllipsis().equals( Constants.PAUSE_ASSIGNMENT_FOR_STUDENTS ), "Pause Assignment For Student Tab is displayed", "Pause Assignment For Student Tab is not displayed" );
             Log.assertThat( assignmentDetailsPage.removeStudentTabInEllipsis().equals( Constants.REMOVE_STUDENTS ), "Remove Student Tab is displayed", "Remove Student Tab is not displayed" );
             Log.testCaseResult();
             
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify assign existing assignment", priority = 1 )
    public void tcSMBVT024() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

    	Log.testCaseInfo( "tcSMBVT024: Verify assign existing assignment <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            studentsPage.createStudent();
            studentsPage.createStudent();
            // Get Assignments Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.clickViewAssignment();
            AssignAssignmentPopup assigAssignmentPopup = assignmentDetailsPage.clickAssignButton();
            assigAssignmentPopup.assignMultipleStudentsToCourse();
            assigAssignmentPopup.getStudentListFromPopUp();
            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );
            assigAssignmentPopup.clickAssignButtonOnPopup();
            Log.message( "Successfully Assigned Multiple Students To Course" );

            Log.assertThat( assignmentDetailsPage.getStudentListfromAssignementDetailsTable().containsAll( assigAssignmentPopup.getStudentListFromPopUp() ), "Added students are displayed in Assignments Table",
                    "Added students are not displayed in Assignments Table" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify view and edit assignment settings", priority = 1 )
    public void tcSMBVT025() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

        Log.testCaseInfo( "tcSMBVT025: Verify view and edit assignment settings <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Get Student Page
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            List<String> studentUserNames = new ArrayList<>();
            String studentID = studentsPage.createStudent();
            studentsPage.closePopup();
            studentUserNames.add( studentID );
            studentID = studentsPage.createStudent();
            studentsPage.closePopup();
            studentUserNames.add( studentID );
            SMUtils.nap( 60 );
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( "Successmaker Group 1" );
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            SMUtils.nap( 60 );
            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();
            groupsTab.addStudGroupWithHomeRoomStudents( "Successmaker Group 1", studentUserNames );
            groupsTab.clickOnAddStudentsBtn();

            // Get Assignments Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.clickViewAssignment();
            AssignAssignmentPopup assigAssignmentPopup = assignmentDetailsPage.clickAssignButton();
            assigAssignmentPopup.assignMultipleStudentsToCourse();
            String firstStudentsName = assigAssignmentPopup.getFirstStudentsName();
            Log.message( "firstStudentsName: " + firstStudentsName );

            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );
            Log.message( "Session Length selected" );
            assigAssignmentPopup.clickAssignButtonOnPopup();
            Log.message( "Successfully Assigned Multiple Students To Course" );

            // assignmentdetails page
            //            assignmentDetailsPage = new AssignmentDetailsPage( driver );
            assignmentDetailsPage.clickAssignmentSettingsOfStudent( firstStudentsName );

            Log.assertThat( assignmentDetailsPage.getSessionLength().equalsIgnoreCase( Constants.SESSION_LENGHT_SELECTED ), "Session Length showed correct", "Session Length showed Incorrect" );
            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );
            String idealTimeValue = assignmentDetailsPage.getIdealTime();
            assignmentDetailsPage.clickSaveButton();

            // assignmentdetails page
            assignmentDetailsPage = new AssignmentDetailsPage( driver );
            assignmentDetailsPage.clickAssignmentSettingsOfStudent( firstStudentsName );

            String idealTimeValueBottomEllipsis = assignmentDetailsPage.getIdealTime();
            Log.assertThat( idealTimeValue.equalsIgnoreCase( idealTimeValueBottomEllipsis ), "Idle Time Is Updated", "Idle Time Is Updated" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Pause / Resume assignment", priority = 1 )
    public void tcSMBVT026() throws Throwable {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

        Log.testCaseInfo( "tcSMBVT026: Verify Pause / Resume assignment<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to CourseWaare Tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click on ViewAssignments
            AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();

            // Click on Dot ellipsis
            assignmentDetailsPage.clickDotEllipsisButton();

            // Click on Pause Assignment
            assignmentDetailsPage.pauseAssignmentForStudentTab();

            // Click On Pause Button
            assignmentDetailsPage.clickPauseButtononPopUpPage();

            Log.assertThat( assignmentDetailsPage.isAssignmentPaused(), "Assignment paused successfully", "Assignment has not Paused" );

            // Click Dot ellipsis
            assignmentDetailsPage.clickDotEllipsisButton();

            // Click Resume Element
            assignmentDetailsPage.resumeAssignment();

            // CLick Resume button
            assignmentDetailsPage.clickResumeButtononPopUpPage();

            Log.assertThat( !assignmentDetailsPage.isStudentPaused(), "Assignment has Resumed successfully", "Assignment has Paused not resumed" );

            // Click Ellipsis at Assignment Level
            assignmentDetailsPage.assignmentLevelEllipsis();

            // Click on Pause Assignment Level Student
            assignmentDetailsPage.pauseAllStudent();

            // CLick Pause button at assignment level

            assignmentDetailsPage.pauseButtonFoAllSTudent();

            // Verify the assignment got pause

            Log.assertThat( assignmentDetailsPage.isAssignmentPausedatAssignmentLevel(), "Assignment paused for all successfully", "Assignment has not Paused" );

            // ************Resume all
            // Assignment************************************

            // Click Ellipsis at Assignment
            assignmentDetailsPage.assignmentLevelEllipsis();

            // Click All Resume Tab
            assignmentDetailsPage.resumeAllAssignment();

            // CLick Resume all assignment
            assignmentDetailsPage.resumeButtonFoAllSTudent();

            // Verify the Pauses After Resume all
            Log.assertThat( !assignmentDetailsPage.isStudentPaused(), "Assignment resumed at asignment leve for all successfully", "Assignment Paused for all successfully" );

            // close browser
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Remove assignment", priority = 1 )
    public void tcSMBVT027() throws Throwable {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

    	Log.testCaseInfo( "tcSMBVT027: Verify Remove assignments<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to CourseWaare Tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click on ViewAssignments
            AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();

            // Click on Dot ellipsis
            assignmentDetailsPage.clickDotEllipsisButton();

            // Click on removeAssignmets
            assignmentDetailsPage.removeStudentTab();

            // CLick save and remove the student
            assignmentDetailsPage.removeStudent();

            // Remove studentvalidation
            if ( !( assignmentDetailsPage.isStudentDisplayed() ) ) {
                Log.message( "Student has not removed" );
            } else {
                Log.message( "Student has removed " );

            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Edit Assignment settings at assignment level", priority = 1 )
    public void tcSMBVT028() throws Throwable {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

        Log.testCaseInfo( "tcSMBVT028: Verify Edit Assignment settings at assignment level<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click on ViewAssignments
            AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();

            // Click on Dot ellipsis Assignment leve;

            assignmentDetailsPage.assignmentLevelEllipsis();
            // Click on Assignments setting

            assignmentDetailsPage.allAssignmenttSettingTab();
            // Update Length Session
            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            // Click Save Button

            assignmentDetailsPage.clickSaveButton();
            SMUtils.nap( 5 );

            // Click on Dot ellipsis
            assignmentDetailsPage.allAssignmenttSettingTab();

            // Validate the Session length field

            Log.assertThat( assignmentDetailsPage.getSessionLength().equals( SESSION_LENGHT_SELECTED_FOR ), "Selected Sesion Length Is displaying", "Selected Sesion Length Is not displaying" );

            // Click Cancel Button
            assignmentDetailsPage.clickCancelButton();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify assignment deletion", priority = 1 )
    public void tcSMBVT029() throws Throwable {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	// Get Test Data

        Log.testCaseInfo( "tcSMBVT029: Verify assignment deletion<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Courseware tab
            AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on Assignment SubMenu
            page.clickAssignmentSubMenu();

            // Click on ViewAssignments
            AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();

            // Click On dot ellipsis beside assign button
            assignmentDetailsPage.assignmentLevelEllipsis();

            // Click Delete Assignment
            assignmentDetailsPage.deleteAssignmenttab();

            // Static Wait

            // Click Delete Button
            assignmentDetailsPage.deleteAssignmentButton();

            Log.assertThat( assignmentDetailsPage.isAssignmentDisplayed(), "Assignment has deleted successfullyAssignment has deleted successfully", "Assignment has not deleted successfully" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

}
