package com.savvas.sm.admin.api.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.Dashboard;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.grade;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class PostOrganizationUsageGoalTest extends EnvProperties {

    private static List<String> studentRumbaIds = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String flexSchool;
    private String mathSchool;
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();
    private static String studentDetail;

    private List<String> courseIDs = new ArrayList<>();
    private Map<String, String> response = new HashMap<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private String exception;
    private String message = null;

    @BeforeClass(alwaysRun = true)
    public void beforeClass() throws Exception {

        flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        orgId = RBSDataSetup.organizationIDs.get( flexSchool );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        String teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        
        String studentDetail1 = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        String studentDetail2 = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        String studentDetail3 = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        studentDetail = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        
        studentRumbaIds.add(SMUtils.getKeyValueFromResponse( studentDetail1, "userId" ));
        studentRumbaIds.add(SMUtils.getKeyValueFromResponse( studentDetail2, "userId" ));
        studentRumbaIds.add(SMUtils.getKeyValueFromResponse( studentDetail3, "userId" ));
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );

        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );

        Log.message( "Assignment Details: " + assignmentDetails );
        Log.message( "Student Details: " + studentRumbaIds );
        
        Log.message( "Assigning assignment..." );
        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        // Creating data for math School
        String mathSchoolTeacherDetails = RBSDataSetup.orgTeacherDetails.get( mathSchool ).get( "Teacher1" );
        String mathSchoolTeacherId = SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, "userId" );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, mathSchoolTeacherId );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        groupDetails.put( GroupConstants.GROUP_NAME, "groupName" + System.nanoTime() );

        String studentdetails = RBSDataSetup.getMyStudent( mathSchool, SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ) );
        String studentId =  SMUtils.getKeyValueFromResponse( studentdetails, "userId"  );
        new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList(studentId) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( mathSchool ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, mathSchoolTeacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        HashMap<String, String> assignMultipleAssignments = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList(studentId),Arrays.asList( AssignmentAPIConstants.MATH  ) );
        Log.message( assignMultipleAssignments.toString() );
    }

    @Test ( priority = 1, dataProvider = "organizationUsagepositiveScenario", groups = { "smoke_test_case", "OrganizationUsageGoal", "SMK-51760", "P1", "API" } )
    public void tcPositiveTestCase( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {

        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        String adminDetails = RBSDataSetup.adminDetails.get( admin );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        String adminOrgId;
        if ( admin.equals( Admins.MULTI_SCHOOL_ADMIN ) ) {
            adminOrgId = SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgId" );
        } else {
            adminOrgId = SMUtils.getKeyValueFromResponse( adminDetails, "primaryOrgIds" ).replace( "[\"", "" ).replace( "\"]", "" );
        }
        List<String> studentIds;

        String token = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        switch ( scenario ) {
            case "FOR_SINGLE_STUDENT_ID":
                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList(studentRumbaIds.get( 0 ));
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                // Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "FOR_MULTIPLE_STUDENTS":

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList(studentRumbaIds.get( 0 ),studentRumbaIds.get( 1 ),studentRumbaIds.get( 2 ));
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                // Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "WITHOUT_USAGE_STUDENT":
                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList(studentRumbaIds.get( 0 ));
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                // Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "AFTER_DELETE_THE_STUDENT'S_ASSIGNMENT":

                // delete assignment
                HashMap<String, String> assignmentDetail = new HashMap<>();
                assignmentDetail.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetail.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetail.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetail.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID,
                        new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 1 ), assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) ) );
                new AssignmentAPI().removeStudentAssignment( smUrl, assignmentDetail, "null" );

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList(studentRumbaIds.get( 0 ),studentRumbaIds.get(1),studentRumbaIds.get( 2 ),SMUtils.getKeyValueFromResponse( studentDetail, "userId" ));
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                // Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

            case "AFTER_DELETE_THE_GROUP'S_ASSIGNMENT":

                // adding the student to the group for the teacher
                String newGroupId = new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), teacherId, Arrays.asList( SMUtils.getKeyValueFromResponse(studentDetail,"userId") ),
                        RBSDataSetup.organizationIDs.get( flexSchool ), new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                // Assigning the assignment
                String courseName = "MATH Custom Settings" + System.nanoTime();
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID,
                        new CourseAPI().createCourse( smUrl, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ), DataSetupConstants.MATH, teacherId,
                                orgId, DataSetupConstants.SETTINGS, courseName ) );
                new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( newGroupId ), AssignmentAPIConstants.GROUPS_TYPE );

                // delete assignment from group
                new AssignmentAPI().deleteAssignmentfromGroup( smUrl, assignmentDetails, "" );

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList(studentRumbaIds.get( 0 ),
                        studentRumbaIds.get( 1 ), studentRumbaIds.get( 2 ),
                        SMUtils.getKeyValueFromResponse(studentDetail,"userId") );

                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                // Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "ZERO_STATE":

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse(studentDetail,"userId") );
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                // Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "ORPHAN_STUDENT":

                // delete Student from all groups
                HashMap<String, String> studentDetails = new HashMap<String, String>();
                studentDetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
                studentDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
                studentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                studentDetails.put( GroupConstants.STUDENT_ID, studentRumbaIds.get( 2 ) );
                HashMap<String, String> groupsForStudentID = new GroupAPI().getGroupsForStudentID( smUrl, studentDetails );
                List<String> groupIds = new ArrayList<>();
                IntStream.rangeClosed( 1, SMUtils.getWordCount( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId" ) ).forEach(
                        iter -> groupIds.add( SMUtils.getKeyValueFromJsonArray( groupsForStudentID.get( Constants.REPORT_BODY ), "groupId", iter ) ) );

                groupIds.stream().forEach( groupId -> {
                    try {
                        new GroupAPI().removeStudentFromGroup( smUrl, studentRumbaIds.get( 2 ), groupId, teacherId, orgId,
                                new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    } catch ( Exception e ) {

                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                } );

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( studentRumbaIds.get( 2 ) );
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                // Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "SCHOOL_ADMIN":

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, adminOrgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student1" ), "userId" ) );
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                // Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
                break;

            case "MULTIPLE_SCHOOL_ADMIN":

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, adminOrgId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student1" ), "userId" ) );
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                // Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

                break;

            case "SUBDISTRICT_ADMIN":

                // Creating teacher and student
                String subdistrictSchoolTeacher = "SchTeacher" + System.nanoTime();
                String subdistrictSchoolTeacherDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolTeacher, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
                String subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( subdistrictSchoolTeacherDetails, RBSDataSetupConstants.USERID );

                // creating student
                String subdistrictSchoolStudent = "SchStudent" + System.nanoTime();
                String subdistrictSchoolStudentDetails = new UserAPI().createUserWithCustomization( subdistrictSchoolStudent, RBSDataSetupConstants.STUDENT_ROLE, Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId ) );
                String subdistrictSchoolStudentId = SMUtils.getKeyValueFromResponse( subdistrictSchoolStudentDetails, RBSDataSetupConstants.USERID );
                HashMap<String, String> studentInfo = new HashMap<>();
                studentInfo = generateRequestValues( subdistrictSchoolStudentDetails, studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, subdistrictSchoolTeacherID );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( "Updating grade..." );

                new UserAPI().updateStudentProfile( configProperty.getProperty( ConfigConstants.SM_APP_URL ), studentInfo );
                new RBSUtils().resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, subdistrictSchoolStudentId );

                // Creating group for above created teacher & student
                new GroupAPI().createGroupWithCustomization( "Group " + System.nanoTime(), subdistrictSchoolTeacherID, Arrays.asList( subdistrictSchoolStudentId ), RBSDataSetup.schoolUnderSubDistrict_SchoolId,
                        new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, subdistrictSchoolTeacherID );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( subdistrictSchoolTeacher, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
                HashMap<String, String> assignAssignment = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( subdistrictSchoolStudentId ), AssignmentAPIConstants.USERS_TYPE );
                Log.message( assignAssignment.toString() );

                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, RBSDataSetup.subDistrictwithSchoolId );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( subdistrictSchoolStudentId );
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                // Status code validation
                Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
            default:
                Log.message( "Not a valid scenario....." );
                break;

        }

        // Status code validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

    }

    @DataProvider ( name = "organizationUsagepositiveScenario" )
    public Object[][] organizationUsagepositiveScenario() {

        Object[][] inputData = { { "tc_OrganizationUsageGoal001", "Verify the status code and response, if pass the single studentId in the request body.", "FOR_SINGLE_STUDENT_ID", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoal002", "Verify the status code and response, if pass the multiple studentId in the request body.", "FOR_MULTIPLE_STUDENTS", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoal003", "Verify the status code and response, if pass the studentId who is not having usage data", "WITHOUT_USAGE_STUDENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoal004", "Verify the response, after delete the assignment for some students", "AFTER_DELETE_THE_STUDENT'S_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoal005", "Verify the response, after delete the assignment for group ", "AFTER_DELETE_THE_GROUP'S_ASSIGNMENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoal006", "Verify the response, if pass studentId who is not having default or custom by setting Math course assignment", "ZERO_STATE", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoal007", "Verify the response, if the give the orphan student id", "ORPHAN_STUDENT", CommonAPIConstants.STATUS_CODE_OK, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoal008", "Verify the 200 status code and response, if pass the school admin credential.", "SCHOOL_ADMIN", CommonAPIConstants.STATUS_CODE_OK, Admins.SCHOOL_ADMIN },
                { "tc_OrganizationUsageGoal009", "Verify the 200 status code and response, if pass the multiple school admin credential.", "MULTIPLE_SCHOOL_ADMIN", CommonAPIConstants.STATUS_CODE_OK, Admins.MULTI_SCHOOL_ADMIN },
                { "tc_OrganizationUsageGoal010", "Verify the 200 status code and response, if pass the subdistrict admin credential.", "SUBDISTRICT_ADMIN", CommonAPIConstants.STATUS_CODE_OK, Admins.SUBDISTRICTWITHSCHOOL_ADMIN } };
        return inputData;
    }

    /**
     * This method is used to test the Organization Usage API.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 2, dataProvider = "organizationUsageGoalNegativeScenario", groups = { "OrganizationUsageGoal", "SMK-51760", "P2", "API" } )
    public void tcNegativeTestcases( String tcId, String description, String scenario, String statusCode, Admins admin ) throws Exception {
        Log.testCaseInfo( tcId + ":-" + description );

        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        String adminDetails = RBSDataSetup.adminDetails.get( admin );
        String adminUserId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        List<String> studentIds;

        String token = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        switch ( scenario ) {

            case "INVALID_USERID":

                headers.put( UserConstants.USERID, "" );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( studentRumbaIds.get( 0 ),
                        studentRumbaIds.get( 1 ), studentRumbaIds.get( 2 ) );
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "EMPTY_ORGID":
                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, "" );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token );

                studentIds = Arrays.asList( studentRumbaIds.get( 0 ),
                        studentRumbaIds.get( 1 ), studentRumbaIds.get( 2 ) );
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "INVALID_ACCESS_TOKEN":
                headers.put( UserConstants.USERID, adminUserId );
                headers.put( UserConstants.ORGID, configProperty.getProperty( ConfigConstants.DISTRICT_ID ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + token + "invalid" );

                studentIds = Arrays.asList( studentRumbaIds.get( 0 ),
                        studentRumbaIds.get( 1 ), studentRumbaIds.get( 2 ) );
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );

                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                break;

            case "WITH_STUDENT_CREDENTIAL":
                headers.put( UserConstants.USERID, studentRumbaIds.get( 0 ) );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( flexSchool ).get( "Student1" ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                studentIds = Arrays.asList( studentRumbaIds.get( 0 ),
                        studentRumbaIds.get( 1 ), studentRumbaIds.get( 2 ) );
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;

            case "WITH_TEACHER_CREDENTIAL":
                headers.put( UserConstants.USERID, teacherId );
                headers.put( UserConstants.ORGID, RBSDataSetup.organizationIDs.get( flexSchool ) );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                studentIds = Arrays.asList( studentRumbaIds.get( 0 ),
                        studentRumbaIds.get( 1 ), studentRumbaIds.get( 2 ) );
                response = new Dashboard().postOrganizationUsageGoal( smUrl, headers, studentIds );
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                break;
            default:
                Log.message( "Not a valid scenario....." );
                break;
        }

        // Status code validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

    }

    @DataProvider ( name = "organizationUsageGoalNegativeScenario" )
    public Object[][] organizationNegativeScenario() {

        Object[][] inputData = { { "tc_OrganizationUsageGoal010", "Verify status code 401 when user id is not passed in header parameter", "INVALID_USERID", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoal011", "Verify status code 401 when SSO token is not passed in header parameter", "INVALID_ACCESS_TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoal012", "Verify status code 400 when Org ID is not passed in query parameter", "EMPTY_ORGID", CommonAPIConstants.STATUS_CODE_FORBIDDAN, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoal013", "Verify status code 403 when User ID is student rumba id in headers", "WITH_STUDENT_CREDENTIAL", CommonAPIConstants.STATUS_CODE_FORBIDDAN, Admins.DISTRICT_ADMIN },
                { "tc_OrganizationUsageGoal014", "Verify status code 403 when User ID is teacher rumba id in headers", "WITH_TEACHER_CREDENTIAL", CommonAPIConstants.STATUS_CODE_FORBIDDAN, Admins.DISTRICT_ADMIN } };
        return inputData;
    }

    /**
     * This methos requires to generate request value
     * 
     * @param studentExistingData
     * @param newDetails
     * @param key
     * @param value
     * @return
     */
    public HashMap<String, String> generateRequestValues( String studentExistingData, HashMap<String, String> newDetails, String key, String value ) {

        HashMap<String, String> generatedStudentDetails = newDetails;
        generatedStudentDetails.put( RBSDataSetupConstants.FIRSTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.FIRSTNAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.MIDDLENAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.MIDDLENAME ) );
        generatedStudentDetails.put( RBSDataSetupConstants.LASTNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.LASTNAME ) );
        generatedStudentDetails.put( UserConstants.UpdateStudentProfileConstants.STUDENT_ID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );
        generatedStudentDetails.put( UserConstants.GRADE, grade.values()[new Random().nextInt( grade.values().length )].toString() );
        generatedStudentDetails.put( UserConstants.BIRTHDAY, "2001-09-23" );
        generatedStudentDetails.put( UserConstants.STUDENT_IDENTIFICATION_NUMBER, new Faker().name().username() );
        generatedStudentDetails.put( RBSDataSetupConstants.USERNAME, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERNAME ) );
        generatedStudentDetails.put( UserConstants.USER_PASSWORD, RBSDataSetupConstants.DEFAULT_PASSWORD );
        generatedStudentDetails.put( UserConstants.ETHINICITY, ethnicity.HISPANIC_OR_LATINO.toString() );
        generatedStudentDetails.put( UserConstants.SPECIAL_SERVICES, specialServices.GIFTED_TALENTED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_DISABILITY, hasDisability.YES.toString() );
        generatedStudentDetails.put( UserConstants.GENDER_FIELD, gender.FEMALE.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ECONOMIC_DISADVANTAGE, hasEconomicDisadvantage.ECONOMICALLY_DISADVANTAGED.toString() );
        generatedStudentDetails.put( UserConstants.HAS_ENGLISH_PROFICIENCY, hasEnglishProficiency.ENGLISH_LANGUAGE_LEARNER.toString() );
        generatedStudentDetails.put( UserConstants.ISMIGRANT, isMigrant.MIGRANT.toString() );
        generatedStudentDetails.put( UserConstants.PERSONID, SMUtils.getKeyValueFromResponse( studentExistingData, RBSDataSetupConstants.USERID ) );

        return generatedStudentDetails;
    }

}