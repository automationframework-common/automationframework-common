package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

/**
 * This class refers edit goals usage popup
 *
 */
public class EditUsageGoalsPopupPage extends LoadableComponent<EditUsageGoalsPopupPage> {
    public  WebDriver driver;
    boolean isPageLoaded;
    public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();



    // ********* SuccessMaker Edit goals usage popup Page Elements ***************

   @IFindBy ( how = How.CSS, using = "cel-dialog-header div h1" , AI=false)
   public WebElement lblEditGoalsPopupHeader;

   @IFindBy ( how = How.CSS, using = "div.sub-header span" , AI=false)
   public WebElement lblGoalsPageDesc;

   @IFindBy ( how = How.CSS, using = "div.child-container cel-button" , AI=false)
   public WebElement btnEditUsageGoals;

   @IFindBy ( how = How.CSS, using = "#date" , AI=false)
   public WebElement txtDatePickerRoot;

   @IFindBy ( how = How.CSS, using = "cel-button[class='action-btn-wrapper mb-2 hydrated'][color='secondary']" , AI=false)
   public WebElement btnResetRoot;

   @IFindBy ( how = How.CSS, using = "cel-button[class='action-btn-wrapper mb-2 hydrated'][color='primary']" , AI=false)
   public WebElement btnOKRoot;

   @IFindBy ( how = How.CSS, using = "cel-button[class='cancel-btn-wrapper mb-2 mr-2 hydrated'][color='secondary']" , AI=false)
   public WebElement btnCancelRoot;

   @IFindBy ( how = How.CSS, using = "div.form-grp.mt-4.target-hours label" , AI=false)
   public WebElement lblTargetHoursLable;

   @IFindBy ( how = How.CSS, using = "cel-dialog-header div div button" , AI=false)
   public WebElement btnIicon;

   @IFindBy ( how = How.CSS, using = "span.default-label" , AI=false)
   public WebElement lblDefault;

   @IFindBy ( how = How.CSS, using = "#sliderValue div div div span span:nth-child(1)" , AI=false) //There are two span without any attribute so index taken
   public WebElement lblSliderValue;

   @IFindBy ( how = How.CSS, using = "#sliderValue" , AI=false)
   public WebElement lblSliderValuechangeIcon;

   @IFindBy ( how = How.CSS, using = "table tbody" , AI=false)
   public WebElement goalsTable;

   @IFindBy ( how = How.CSS, using = "#sliderValue div div div input" , AI=false)
   public WebElement sliderInput;

   @IFindBy ( how = How.CSS, using = "th.th-check cel-checkbox" , AI=false)
   public WebElement goalsSelectAllCheckbox;

    @FindBy ( css = "span[class='pl-1']" )
    List<WebElement> studentLastNames;

    @FindBy ( css = "td:nth-child(6) span" ) //There are two span without any attribute so index taken
    List<WebElement> targetHours;

    @FindBy ( css = "td.td-check cel-checkbox" )
    List<WebElement> checkBoxes;

    private static String btnPrimary = ".primary_button";
    private static String btnSecondary = ".secondary_button";
    private static String iconCalenderparent = "div div button cel-icon";
    private static String iconCalenderChild = "img[alt*='icon calendar']";
    private static String datePickerParent = "div div cel-date-picker-popup";
    private static String datePickerTable = "div > div.date-picker-modal-dates";
    private static String chBoxSelectStudentChild = "div label.checkbox__container span";
    private static String selectAllCheckBoxChild = "div input";
    private static String txtBoxEndDate = "input.date-picker-input";

    //These index related POM used in methods to get dynamic data. And these locators are child elements
    private static String datePickerChild = "div div.date-picker-modal-dates button:nth-child(%s)";

    public EditUsageGoalsPopupPage() {}
    /**
     * Constructor to invoke the add student to assignment component
     *
     * @param driver
     */
    public EditUsageGoalsPopupPage( WebDriver driver ) {
        this.driver = driver;
        // Have Topbar here and init
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
    	PageFactory.initElements(finder, this);
    	elementLayer = new ElementLayer(driver);
    }

    @Override
    protected void isLoaded() {
        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( SMUtils.waitForElement( driver, lblEditGoalsPopupHeader ) ) {
            Log.message( "Edit goals popup loaded successfully." );
        } else {
            Log.fail( "Edit goals popup did not load." );
        }
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, lblEditGoalsPopupHeader );
    }

    /**
     * Moving the target hour slider
     *
     * @param value
     */
    public void moveSlider( String value ) {
        int valueNumber = Integer.parseInt( value );
        int temp = -115; //This value is starting offset value for slider
        boolean sliderMoved = false;
        String UIValue;
        SMUtils.waitForElement( driver, lblSliderValue );
        Actions action = new Actions( driver );

        for ( int sliderValue = -120; sliderValue <= 120; sliderValue += 5 ) { //Here the offset value is used for moving the slider to particuler method
            action.moveToElement( sliderInput, sliderValue, 0 ).click();
            action.build().perform();
            UIValue = lblSliderValuechangeIcon.getAttribute( "data-default-value" );
            if ( UIValue.trim().equals( value.trim() ) ) {
                action.moveToElement( sliderInput, sliderValue, 0 ).click();
                action.build().perform();
                Log.message( "Slider Moved to " + value );
                sliderMoved = true;
                break;
            }
        }

        if ( !sliderMoved ) {
            for ( int sliderValue = 1; sliderValue <= 50; sliderValue++ ) { //If the slider not selected then this logic will select the slider target which is given
                if ( sliderValue == valueNumber ) {
                    action.moveToElement( sliderInput, temp, 0 ).click();
                    action.build().perform();
                    Log.message( "Slider Moved to " + value );
                    break;
                }
                temp += 5;
            }
        }
    }

    /**
     * To get the default hour
     *
     * @return
     */
    public String getDefaultHour() {
        SMUtils.waitForElement( driver, lblSliderValue );
        return lblSliderValue.getText();
    }

    /**
     * To get cancel button
     *
     * @return
     */
    public WebElement getCancelButton() {
        WebElement cancelButton = SMUtils.getWebElement( driver, btnCancelRoot, btnSecondary );
        return cancelButton;
    }

    /**
     * To click cancel button
     */
    public void clickCancelButton() {
        WebElement cancelButton = SMUtils.getWebElement( driver, btnCancelRoot, btnSecondary );
        SMUtils.clickJS( driver, cancelButton );
        Log.message( "Cancel button clicked." );
    }

    /**
     * To get OK button
     *
     * @return
     */
    public WebElement getOKButton() {
        WebElement oKButton = SMUtils.getWebElement( driver, btnOKRoot, btnPrimary );
        return oKButton;
    }

    public WebElement getSelectAllCheckbox() {
        WebElement selectAllCheckBox = SMUtils.getWebElement( driver, goalsSelectAllCheckbox, selectAllCheckBoxChild );
        return selectAllCheckBox;
    }

    /**
     * Clicking ok button
     */
    public void clickOKButton() {
        WebElement okButton = SMUtils.getWebElement( driver, btnOKRoot, btnPrimary );
        SMUtils.waitForElementToBeClickable( okButton, driver );
        SMUtils.clickJS( driver, okButton );
        Log.message( "OK button clicked." );
        SMUtils.waitForElementToBeClickable( btnEditUsageGoals, driver );
    }

    /**
     * Getting reset button
     *
     * @return
     */
    public WebElement getResetButton() {
        WebElement resetButton = SMUtils.getWebElement( driver, btnResetRoot, btnSecondary );
        return resetButton;
    }

    /**
     * Clicking the reset button
     */
    public void clickResetButton() {
        WebElement resetButton = SMUtils.getWebElement( driver, btnResetRoot, btnSecondary );
        SMUtils.waitForElementToBeClickable( resetButton, driver );
        SMUtils.clickJS( driver, resetButton );
        Log.message( "Reset button clicked." );
    }

    /**
     * Clicking the calendar Icon
     */
    public void clickCalenderIcon() {
        try {
            WebElement calenderIconRoot = SMUtils.getWebElement( driver, txtDatePickerRoot, iconCalenderparent );
            WebElement calenderIcon = SMUtils.getWebElement( driver, calenderIconRoot, iconCalenderChild );
            SMUtils.clickJS( driver, calenderIcon );
            Log.message( "Calender icon clicked." );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * Clicking the date from calendar for the same month
     *
     * @param date
     */
    public void clickDateFromCalender( String date ) {
        try {
            WebElement calenderIconRoot = SMUtils.getWebElement( driver, txtDatePickerRoot, datePickerParent );
            WebElement dateTable = SMUtils.getWebElement( driver, calenderIconRoot, datePickerTable );
            String dateCount = dateTable.getAttribute( "childElementCount" );
            WebElement dateButton = null;
            for ( int dates = 1; dates <= Integer.parseInt( dateCount ); dates++ ) {
                dateButton = SMUtils.getWebElement( driver, calenderIconRoot, String.format( datePickerChild, dates ) );
                String dateText = dateButton.getText();
                if ( date.equals( dateText ) ) {
                    SMUtils.clickJS( driver, dateButton );
                    break;
                }
            }
            SMUtils.clickJS( driver, dateButton );
            Log.message( "Date Selected - " + date );
            SMUtils.waitForElementToBeClickable( getOKButton(), driver );
        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * To enter date in Gola End DateText box
     *
     */
    public void setEndDate( String date ) {
        SMUtils.waitForElement( driver, txtDatePickerRoot );
        WebElement calenderIconRoot = SMUtils.getWebElementDirect( driver, txtDatePickerRoot, txtBoxEndDate );
        calenderIconRoot.clear();
        calenderIconRoot.sendKeys( date + Keys.ENTER );
    }

    /**
     * Selecting student check box based on student last name
     *
     * @param StudentLastname
     */
    public void selectStudentCheckBox( String StudentLastname ) {

        for ( int studentCount = 0; studentCount < studentLastNames.size(); studentCount++ ) {

            String studentLastName = studentLastNames.get( studentCount ).getText();

            if ( StudentLastname.trim().equals( studentLastName.trim() ) ) {
                WebElement chboxRoot = checkBoxes.get( studentCount );
                WebElement checkBox = SMUtils.getWebElement( driver, chboxRoot, chBoxSelectStudentChild );
                SMUtils.clickJS( driver, checkBox );
                Log.message( "Student selected - " + studentLastName );
                break;
            }
        }
    }

    /**
     * Get student target hour based on student last name
     *
     * @param StudentLastname
     * @return Target hours
     */
    public String getStudentTargetHour( String StudentLastname ) {
        String targetHour = null;

        try {
            SMUtils.waitForElementToBeClickable( btnEditUsageGoals, driver );

            for ( int studentCount = 0; studentCount < studentLastNames.size(); studentCount++ ) {
                String studentLastName = studentLastNames.get( studentCount ).getText();

                if ( StudentLastname.trim().equals( studentLastName.trim() ) ) {
                    targetHour = targetHours.get( studentCount ).getText().trim();
                    Log.message( studentLastName + "Student target hour - " + targetHour );
                    break;
                }
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return targetHour;
    }

    /**
     * Clicking the editbutton
     */
    public void clickEditButton() {
        SMUtils.waitForElementToBeClickable( btnEditUsageGoals, driver );
        SMUtils.clickJS( driver, btnEditUsageGoals );
    }

}
