package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.Utils;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class CoursesEditAssignmentSettingsPage extends LoadableComponent<CourseListingPage> {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    private WebDriver driver;
    boolean isPageLoaded;
    
    public ElementLayer elementLayer;
    public static List<Object> pageFactoryKey = new ArrayList<Object>();
    public static List<String> pageFactoryValue = new ArrayList<String>();

    
 
    
    @IFindBy (how = How.CSS, using = "div[class='tile'] .tile__body>span[class='tile__title tile__tooltip']", AI = false )
    public WebElement pageTitle;

    @IFindBy (how = How.CSS, using = "h1.dialog-header__message", AI = false )
    public WebElement editSettingsPopUpTitle;

    @FindBy ( css = "div[class='first column'] .setting-wrapper .setting-label" )
    List<WebElement> listOfFirstColumnSections;

    @FindBy ( css = "div[class='second column'] .setting-label" )
    List<WebElement> listOfSecondColumnSections;

    @FindBy ( css = ".dialog-wrapper ul.dropdown-select-options span.dropdown-option-label" )
    List<WebElement> showLimitList;

    @FindBy ( css = "span.dropdown-option-label.sc-cel-dropdown-select" )
    List<WebElement> idleTimeList;

    @IFindBy (how = How.CSS, using = "cel-button.edit-btn.hydrated", AI = false )
    public WebElement editShadowHostCssSelector;

    @IFindBy (how = How.CSS, using = "cel-multi-check-dropdown.hydrated", AI = false )
    public WebElement languageDropDownShadowHost;

    @IFindBy (how = How.CSS, using = "cel-button:not([class=cancel-button])[class=hydrated]", AI = false )
    public WebElement btnSaveRoot;

    @IFindBy (how = How.CSS, using = "cel-button.cel-button-assign", AI = false )
    public WebElement defaultAssignBtn;

    private static String ElementTypeForToggle = ".switch-button";
    private static String ElementTypeForDropdown = ".dropdown-select-trigger";

    //edit button child
    private String editButtonCssSelector = "button.secondary_button";

    //languages child
    private String languageDropDownParentCss = "div.multi-check-dropdown-container";
    //save button child
    private static String btnPrimary = ".primary_button";

    public CoursesEditAssignmentSettingsPage() {}
    
    /**
     * Constructor class for CoursesEditAssignmentSettingsPage and initializing
     * the driver for page factory objects.
     *
     * @param driver
     */

    public CoursesEditAssignmentSettingsPage( WebDriver driver ) {
        this.driver = driver;
        ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
        PageFactory.initElements(finder, this);
        elementLayer = new ElementLayer(driver);
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, pageTitle );
    }

    @Override
    public void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 60 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, pageTitle ) ) {
            Log.message( "SM Course Details Page loaded successfully." );
        } else {
            Log.fail( "SM Course Details Page did not load." );
        }

    }

    /**
     * To click on Edit button at Course setting level
     */
    public void clickOnEditButton() {
        WebElement editButtonTab = SMUtils.getWebElementDirect( driver, editShadowHostCssSelector, editButtonCssSelector );
        SMUtils.waitForElementToBeClickable( editButtonTab, driver );
        SMUtils.clickJS( driver, editButtonTab );
        Log.message( "Clicked on Edit button" );
    }

    /**
     * To verify Edit button is in enable state
     */
    public boolean isEditButtonEnabled() {
        WebElement editButtonTab = SMUtils.getWebElementDirect( driver, editShadowHostCssSelector, editButtonCssSelector );
        SMUtils.waitForElementToBeClickable( editButtonTab, driver );
        return editButtonTab.isEnabled();
    }

    /**
     * To verify Course EditSettings Pop Up is displayed
     */
    public boolean isDisplayedEditSettingsPopUp() {
        SMUtils.waitForElement( driver, editSettingsPopUpTitle );
        return SMUtils.isElementPresent( editSettingsPopUpTitle );
    }

    /**
     * To verify Courses Assignment Setting FirstColumn Sections displayed
     */
    public boolean isCourseAssignmentSettingsFirstColumnDisplayed( String elementType, String labelType ) {

        String getElementType;
        if ( elementType.equals( Constants.TOGGLE_BUTTON ) ) {
            getElementType = ElementTypeForToggle;
        } else {
            getElementType = ElementTypeForDropdown;
        }

        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement sessionLengthSection = parentElement.findElement( By.cssSelector( getElementType ) );
                SMUtils.waitForElement( driver, sessionLengthSection, 5 );
                status.set( SMUtils.isElementPresent( sessionLengthSection ) );
            }
        } ) );
        return status.get();
    }

    /**
     * To verify Initial Placement section is displayed
     */
    public boolean isDisplayedInitialPlacementSections( String labelType ) {
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                SMUtils.waitForElement( driver, element, 5 );
                status.set( SMUtils.isElementPresent( element ) );
            }
        } ) );
        return status.get();
    }

    /**
     * To verify Courses Assignment Setting SecondColumn Sections displayed
     */
    public boolean isCourseAssignmentSettingsSecondColumnDisplayed( String elementType, String labelType ) {

        String getElementType;
        if ( elementType.equals( Constants.TOGGLE_BUTTON ) ) {
            getElementType = ElementTypeForToggle;
        } else {
            getElementType = ElementTypeForDropdown;
        }
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfSecondColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement sessionLengthSection = parentElement.findElement( By.cssSelector( getElementType ) );
                SMUtils.waitForElement( driver, sessionLengthSection, 5 );
                status.set( SMUtils.isElementPresent( sessionLengthSection ) );
            }
        } ) );
        return status.get();
    }

    /**
     * To verify Manually Set Course Level Section displayed
     */
    public boolean isDisplayedManuallySetCourseLevelSection( String labelType ) {
        AtomicReference<Boolean> status = new AtomicReference<>( false );
        this.listOfSecondColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                SMUtils.waitForElement( driver, element, 5 );
                status.set( SMUtils.isElementPresent( element ) );
            }
        } ) );
        return status.get();
    }

    /**
     * To verify Languages DropDown section is displayed
     */
    public boolean isDisplayedLanguagesDropDown() {
        WebElement languageChild = SMUtils.getWebElementDirect( driver, languageDropDownShadowHost, languageDropDownParentCss );
        WebElement languagesDropDown = languageChild.findElement( By.cssSelector( "button.dropdown-head" ) );
        SMUtils.waitForElement( driver, languagesDropDown );
        return SMUtils.isElementPresent( languagesDropDown );
    }

    /**
     * To click on Translate section
     */
    public void clickOnTranslate( String labelType ) {
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equals( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement translateSection1 = parentElement.findElement( By.cssSelector( ".switch-button" ) );
                SMUtils.waitForElement( driver, translateSection1, 5 );
                SMUtils.clickJS( driver, translateSection1 );
                Log.message( "Clicked on Translate toggle" );
            }
        } ) );
    }

    /**
     * To verify Save button is displayed
     */
    public boolean isDisplayedSaveButton() {
        WebElement saveBtn = SMUtils.getWebElementDirect( driver, btnSaveRoot, btnPrimary );
        SMUtils.waitForElement( driver, saveBtn, 5 );
        return SMUtils.isElementPresent( saveBtn );
    }

    /**
     * To verify Max Limit Of Idle Time is 6 minutes
     */
    public boolean verifyMaxLimitOfIdleTime( String labelType ) {
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement idleTimeSection = parentElement.findElement( By.cssSelector( ".dropdown-select-trigger" ) );
                SMUtils.waitForElement( driver, idleTimeSection, 5 );
                SMUtils.clickJS( driver, idleTimeSection );
                Log.message( "Clicked on Idle Time section drop down" );
            }
        } ) );

        List<String> list = SMUtils.getAllTextFromWebElementList( idleTimeList );
        String maxValue = list.stream().max( ( i1, i2 ) -> i1.compareTo( i2 ) ).get();
        return maxValue.equalsIgnoreCase( Constants.MAX_IDLE_TIME );
    }

    /**
     * To verify Max Limit Of Show Limit Progress Report is 10 per session
     */
    public boolean verifyMaxLimitOfShowLimitProgress( String labelType ) {
        this.listOfFirstColumnSections.stream().forEach( element -> Optional.ofNullable( element.getText().trim() ).ifPresent( filteredValues -> {
            if ( filteredValues.equalsIgnoreCase( labelType ) ) {
                WebElement parentElement = element.findElement( By.xpath( "./.." ) );
                WebElement showLimitSection = parentElement.findElement( By.cssSelector( ".dropdown-select-trigger" ) );
                SMUtils.waitForElement( driver, showLimitSection, 5 );
                SMUtils.clickJS( driver, showLimitSection );
                Log.message( "Clicked on Show Limit Progress Report section drop down" );
            }
        } ) );

        List<String> list = new ArrayList<>();
        showLimitList.stream().forEach( e -> Optional.ofNullable( SMUtils.getTextOfWebElement( e, driver ) ).ifPresent( elementText -> list.add( elementText ) ) );

        Collections.reverse( list );

        return list.get( 0 ).equalsIgnoreCase( Constants.MAX_SHOWLIMIT );
    }

    /**
     * To generate unique Course name
     */
    public String generateCourseName() {
        String courseName = String.join( "", Constants.RANDOM_STRING_CHAR, RandomStringUtils.randomAlphabetic( 10 ) ).trim().replaceAll( "\\s{2,}", " " );
        Log.message( "Course name generated" );
        return courseName;
    }

    /**
     * Click on Assign Button in assignment details page
     */
    public void clickAssignBtnDetails() {
        SMUtils.waitForElement( driver, defaultAssignBtn );
        SMUtils.clickJS( driver, defaultAssignBtn );
        Log.message( "Clicked Assign Button in default course details page" );
    }
}