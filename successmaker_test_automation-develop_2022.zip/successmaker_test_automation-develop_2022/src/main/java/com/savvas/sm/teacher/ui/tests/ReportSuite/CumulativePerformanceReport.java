package com.savvas.sm.teacher.ui.tests.ReportSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.Reports;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CPRPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.ReportComponent;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class CumulativePerformanceReport extends BaseTest {
    private String smUrl;
    private String browser;
    private String sessionCookie;
    private String username = null;
    private String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String studentLastName;
    ReportComponent reportComponent;
    CPRPage reportPage;
    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;
    TeacherHomePage tHomePage;

    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher25" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( description = "Verify Cumulative performance Report (CPR) should display under Reports menu.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 1 )
    public void tcSMCPR001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR001: Verify Cumulative performance Report (CPR) should display under Reports menu. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Verify Cumulative Performance Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.CPR_REPORT ), "Cumulative Performance Report sub menu is Present under report menu", "Cumulative Performance Report sub menu is not Present under report menu" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all available fields in CPR page", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 1 )
    public void tcSMCPR002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR002: Verify all available fields in CPR page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            CPRPage reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Verify CPR header
            Log.assertThat( reportComponent.getReportPageHeader().equals( Constants.Reports.CPR_HEADER ), "Cumulative Performance Report header is Present", "Cumulative Performance Report header is not Present" );

            // Verify Filters heading
            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.FILTERS ), "Filters heading is present in the CPR Page", "Filters heading is not present in the CPR Page" );

            // Verify Select Groups or Students heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.GROUP_OR_STUDENT_HEADER ), "Select Groups or Students heading is present in the CPR Page",
                    "Select Groups or Students heading is not present in the CPR Page" );

            // Verify group dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.GROUP_DROPDOWN ), "Group dropdown is present in the CPR Page", "Group dropdown is not present in the CPR Page" );

            // Verify student dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.STUDENTS_DROPDOWN ), "Student dropdown is present in the CPR Page", "Students dropdown is not present in the CPR Page" );

            // Verify Refine search heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.REFINE_SEARCH ), "Refine search heading is present in the CPR Page", "Refine search heading is present in the CPR Page" );

            // Verify subject dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject dropdown is present in the CPR Page", "Subjects dropdown is not present in the CPR Page" );

            // Verify assignment dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "Assignments dropdown is present in the CPR Page", "Assignments dropdown is not present in the CPR Page" );

            // Verify Report option heading
            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.REPORT_OPTION_HEADER ), "Report option heading is present in the CPR Page", "Report option heading is not present in the CPR Page" );

            // Verify Saved Option dropdown heading
            Log.assertThat( reportComponent.isSavedOptionDropdownHeadingPresent(), "Saved Option dropdown is present in the CPR Page", "Saved Option dropdown is not present in the CPR Page" );

            // Verify additional grouping dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.ADDITIONAL_GROUPING ), "Additional grouping dropdown heading is present in the CPR Page", "Additional grouping dropdown is not present in the CPR Page" );

            // Verify Display dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.DISPLAY_DROPDOWN ), "Display dropdown heading is present in the CPR Page", "Display dropdown heading is not present in the CPR Page" );

            // Verify Display dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.SORT_DROPDOWN ), "Sort dropdown heading is present in the CPR Page", "Sort dropdown heading is not present in the CPR Page" );

            // Verify Remove page break field
            Log.assertThat( reportComponent.isMaskStudentDisplayAndRemovePageBreakFieldDisplayed( Constants.Reports.MASK_STUDENT_DISPLAY ), "Remove page break field is present in the CPR page", "Remove page break field is not present in the CPR page" );

            // Verify Mask student display field
            Log.assertThat( reportComponent.isMaskStudentDisplayAndRemovePageBreakFieldDisplayed( Constants.Reports.REMOVE_PAGE_BREAKS ), "Mask student display is present in the CPR page", "Mask student display field is not present in the CPR page" );

            // Verify "all date" field
            Log.assertThat( reportPage.isAllDatesAndSelectedDateRangeFieldPresent( Constants.Reports.CPR_ALL_DATES ), "All Date field is present in the CPR page", "All Date field is not present in the CPR page" );

            // Verify "Selected date Range" field
            Log.assertThat( reportPage.isAllDatesAndSelectedDateRangeFieldPresent( Constants.Reports.CPR_SELECTED_DATE_RANGE ), "Selected date Range field is present in the CPR page", "Selected date Range field is not present in the CPR page" );

            // Verify Save Report Option button
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getSaveReportOptionButton() ), "Saved Report option button is present", "Saved Report option button is not present!" );

            // Verify Run Report
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getRunReportOption() ), "Run report button present!", "Run report not button present!" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'CPR description text' available on CPR Page.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR003: Verify 'CPR description text' available on CPR Page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Verifying CPR Report Description report
            Log.assertThat( reportComponent.isReportDescriptionPresent(), "Cumulative Performance Report description is present and display expected text", "Cumulative Performance Report description is not Present or display wrong text" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify fields available after clicking on Filters option.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR004: Verify fields available after clicking on Filters option. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Collapse and Expand the Filters
            reportComponent.collapseFilterButton();
            reportComponent.expandFilterButton();

            // Verify Select Groups or Students heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.GROUP_OR_STUDENT_HEADER ), "Select Groups or Students heading is present in the CPR Page",
                    "Select Groups or Students heading is not present in the CPR Page" );

            // Verify group dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.GROUP_DROPDOWN ), "Group dropdown is present in the CPR Page", "Group dropdown is not present in the CPR Page" );

            // Verify student dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.STUDENTS_DROPDOWN ), "Student dropdown is present in the CPR Page", "Students dropdown is not present in the CPR Page" );

            // Verify Refine search heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.REFINE_SEARCH ), "Refine search heading is present in the CPR Page", "Refine search heading is present in the CPR Page" );

            // Verify subject dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject dropdown is present in the CPR Page", "Subjects dropdown is not present in the CPR Page" );

            // Verify assignment dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "Assignments dropdown is present in the CPR Page", "Assignments dropdown is not present in the CPR Page" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Groups' dropdown field display under Filters option when only one Group is selected.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR005: Verify 'Groups' dropdown field display under Filters option when only one Group is selected. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupOptions = new ArrayList<>();

            // Verify the Dropdown text after selecting one Group
            if ( groupsFromUI.size() > 1 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( groupsFromUI.get( 0 ).equals( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ) ), "Selected group name is Displayed", "Selected group name is not Displayed" );
            } else if ( groupsFromUI.size() == 1 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "1" ) ),
                        "All Groups text and count of the Groups is Display Properly", "All Groups text or count of the Groups is not Display Properly" );
            } else {
                Log.message( "Given teacher don't have goups" );
            }

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Groups' dropdown field display under Filters option when more than one Groups are selected.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR006: Verify 'Groups' dropdown field display under Filters option when more than one Groups are selected. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> allGroupsFromUI = reportComponent.getValuesFromDropDownMS();

            // Verify the Dropdown text after selecting multiple Groups
            List<String> groupOptions = new ArrayList<>();

            if ( allGroupsFromUI.size() > 2 ) {
                groupOptions.add( allGroupsFromUI.get( 0 ) );
                groupOptions.add( allGroupsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Count of selected group is Displayed",
                        "count of selected group name is not Displayed" );
            } else if ( allGroupsFromUI.size() == 2 ) {
                groupOptions.add( allGroupsFromUI.get( 0 ) );
                groupOptions.add( allGroupsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All Groups text and count of the Groups is Display Properly", "All Groups text or count of the Groups is not Display Properly" );
            } else {
                Log.message( "Given teacher has less than one goup" );
            }

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify deleted groups should not display under Groups dropdown.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR007: Verify deleted groups should not display under Groups dropdown. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // getting the groups names from data setup
            List<String> groupsList = new ArrayList<>();
            String groupDetails = DataSetup.teacherGroupMap.get( username ).get( username );
            for ( int groupCount = 1; groupCount <= SMUtils.getWordCount( groupDetails, "groupName" ); groupCount++ ) {
                groupsList.add( SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", groupCount ) );
            }

            // Getting groups from UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            Log.assertThat( groupsList.equals( groupsFromUI ), "All Groups displayed successfully!", "Groups not displayed properly" );

            if ( groupsFromUI.size() > 0 ) {
                // getting Group Name
                String groupName = groupsFromUI.get( 0 );

                // Delete Group
                GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
                groupPage.viewGroup( groupName );
                SMUtils.nap( 2 ); //needed for page load
                groupPage.deleteGroup( groupName );

                // navigate to CPR Page
                teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

                // again Getting groups from UI
                reportComponent.setDropDownMS( "Groups" );
                groupsFromUI = reportComponent.getValuesFromDropDownMS();

                // validate delete group should not display under groups dropdown
                Log.assertThat( !( groupsFromUI.contains( groupName ) ), "Deleted Group is not present under Groups Dropdown", "Deleted Group is present under Groups Dropdown" );
            } else {
                Log.message( "Given teacher don't have goups" );
            }
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'students' dropdown field display under Filters option when more than one students are selected.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR008() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR008: Verify 'students' dropdown field display under Filters option when more than one students are selected. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> allStudentsFromUI = reportComponent.getValuesFromDropDownMS();

            // getting the Student names from data setup
            List<String> studentList = new ArrayList<>();
            List<String> studentFirstNameAndLastNameList = new ArrayList<>();
            for ( int studentCount = 1; studentCount <= DataSetup.teacherStudentMap.get( username ).size(); studentCount++ ) {
                studentList.add( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ) );
                studentFirstNameAndLastNameList.add( SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,middleName" ) + ". "
                        + SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,lastName" ) );
            }

            Log.assertThat( SMUtils.sortList( studentFirstNameAndLastNameList ).containsAll( allStudentsFromUI ), "All Students displayed properly in the student dropdown!", "Students not displayed properly in thes student dropdown" );
            List<String> studentOptions = new ArrayList<>();
            // Verify the Dropdown text after selecting multiple Students
            if ( allStudentsFromUI.size() > 2 ) {
                studentOptions.add( allStudentsFromUI.get( 0 ) );
                studentOptions.add( allStudentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_STUDENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Count of selected student is Displayed",
                        "count of selected student is not Displayed" );
            } else if ( allStudentsFromUI.size() == 2 ) {
                studentOptions.add( allStudentsFromUI.get( 0 ) );
                studentOptions.add( allStudentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_STUDENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All Students text and count of the Students is Display Properly", "AllStudents text or count of the Students is not Display Properly" );
            } else {
                Log.message( "Given teacher has less than one student" );
            }

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Assignments' dropdown field display under Filters option when only one assignment is selected.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR009: Verify 'Assignments' dropdown field display under Filters option when only one assignment is selected. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Getting groups from UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();

            // getting the Student names from data setup
            List<String> assignmentList = new ArrayList<>();
            String assignments = DataSetup.teacherAssignmentMap.get( username ).get( username );
            for ( int assignmentCount = 1; assignmentCount <= SMUtils.getWordCount( assignments, "name" ); assignmentCount++ ) {
                assignmentList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", assignmentCount ) );
            }

            Log.assertThat( assignmentList.containsAll( assignmentsFromUI ), "All assignments displayed properly in the assignment dropdown!", "Assignments not displayed properly in thes assignment dropdown" );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );

            List<String> assignmentOptions = new ArrayList<>();

            // Verify the Dropdown text after selecting one assignment
            if ( assignmentsFromUI.size() > 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( assignmentsFromUI.get( 0 ).equals( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ) ), "Selected assignment name is Displayed", "Selected assignment name is not Displayed" );
            } else if ( assignmentsFromUI.size() == 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.ASSIGNMENTS_DROPDOWN, "1" ) ),
                        "All assignments text and count of the assignments is Display Properly", "All assignments text or count of the assignments is not Display Properly" );
            } else {
                Log.message( "Given teacher don't have assignments" );
            }
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Assignments' dropdown field display under Filters option when more than one assignments are selected.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR010() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR010: Verify 'Assignments' dropdown field display under Filters option when more than one assignments are selected. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();
            // Verify the Dropdown text after selecting multiple assignment
            if ( assignmentsFromUI.size() > 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "Count of selected assignment is Displayed", "count of selected assignment name is not Displayed" );
            } else if ( assignmentsFromUI.size() == 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All assignment text and count of the assignments is Display Properly", "All assignment text or count of the assignments is not Display Properly" );
            } else {
                Log.message( "Given teacher has less than two assignment" );
            }
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify removed assignments should not display under assignment dropdown.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR011: Verify removed assignments should not display under assignment dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Getting Assignments from UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();

            if ( assignmentsFromUI.size() > 0 ) {
                // getting Assignment Name
                String assignmentsName = assignmentsFromUI.get( 0 );
                // Navigate to Courseware tab
                AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

                // Click on Assignment SubMenu
                page.clickAssignmentSubMenu();

                // Click Delete Assignment
                AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( assignmentsName );
                assignmentDetailsPage.assignmentLevelEllipsis();
                assignmentDetailsPage.deleteAssignmenttab();
                SMUtils.nap( 2 );
                assignmentDetailsPage.deleteAssignmentButton();
                Log.assertThat( assignmentDetailsPage.isAssignmentDisplayed(), "Assignment has deleted successfully", "Assignment has not deleted successfully" );

                // navigate to CPR Report page
                teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();
                reportComponent.setDropDownMS( "Assignments" );
                assignmentsFromUI = reportComponent.getValuesFromDropDownMS();

                // validate delete group should not display under groups dropdown
                Log.assertThat( !( assignmentsFromUI.contains( assignmentsName ) ), "Deleted assignments is not present under Assignments Dropdown", "Deleted assignments is present under assignments Dropdown" );
            } else {
                Log.message( "Teacher don't have assignments" );
            }
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify count of all Groups/Students and Assignments should display beside filters,if filters has collapsed.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR012() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR012: Verify count of all Groups/Students and Assignments should display beside filters,if filters has collapsed. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupOptions = new ArrayList<>();

            // selecting one group
            if ( groupsFromUI.size() > 1 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.GROUPS_SELECTED_COUNT.replace( Constants.Reports.SELECTED_COUNT, "1" );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.GROUP_DROPDOWN ).equals( expectedFiltersCount ), "Count of Selected Group filters displayed Properly after collapse the fiters",
                        "Count of Selected Group filter is not displayed Properly after collapse the fiters" );

                reportComponent.expandFilterButton();
            } else {
                Log.message( "Teacher don't have enough group" );
            }

            // deSelect all the group
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            // selecting All groups
            if ( groupsFromUI.size() > 0 ) {
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.SELECTED_ALL_GROUPS.replace( Constants.Reports.SELECTED_COUNT, Integer.toString( groupsFromUI.size() ) );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.GROUP_DROPDOWN ).equals( expectedFiltersCount ), "Count of all Group is displayed Properly after collapse the fiters",
                        "Count of all Group is not displayed Properly after collapse the fiters" );
                reportComponent.expandFilterButton();
            } else {
                Log.message( "Teacher don't have enough group" );
            }

            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> studentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();

            // selecting one student
            if ( studentsFromUI.size() > 1 ) {
                studentOptions.add( studentsFromUI.get( 0 ) );
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.STUDENTS_SELECTED_COUNT.replace( Constants.Reports.SELECTED_COUNT, "1" );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.STUDENTS_DROPDOWN ).equals( expectedFiltersCount ), "Count of Selected student filters displayed Properly after collapse the fiters",
                        "Count of Selected student filter is not displayed Properly after collapse the fiters" );

                reportComponent.expandFilterButton();

            } else {
                Log.message( "Teacher don't have enough student" );
            }

            // deSelect all the group
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // selecting All students
            if ( studentsFromUI.size() > 0 ) {
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.SELECTED_ALL_STUDENTS.replace( Constants.Reports.SELECTED_COUNT, Integer.toString( studentsFromUI.size() ) );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.STUDENTS_DROPDOWN ).equals( expectedFiltersCount ), "Count of all student is displayed Properly after collapse the fiters",
                        "Count of all student is not displayed Properly after collapse the fiters" );

                reportComponent.expandFilterButton();
            } else {
                Log.message( "Teacher don't have enough student" );
            }

            reportComponent.setDropDownMS( Constants.Reports.SUBJECT_DROPDOWN );
            List<String> optionsFromSubjectDropDown = reportComponent.getValuesFromDropDownMS();
            List<String> subjectOption = new ArrayList<>();

            // Select Math from subject dropdown
            subjectOption.add( optionsFromSubjectDropDown.get( 0 ) );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            reportComponent.collapseFilterButton();
            String expectedFilters = optionsFromSubjectDropDown.get( 0 );
            Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.SUBJECT_DROPDOWN ).equals( expectedFilters ), "Subject filters displayed Properly after collapse the fiters",
                    "Selected subject filter is not displayed Properly after collapse the fiters" );
            reportComponent.expandFilterButton();
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            // Selecting All subject filters
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.collapseFilterButton();
            String expectedSubjectFiterCount = Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" );
            Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.SUBJECT_DROPDOWN ).equals( expectedSubjectFiterCount ), "count of Subject filters displayed Properly after collapse the fiters",
                    "count of Selected subject filter is not displayed Properly after collapse the fiters" );
            reportComponent.expandFilterButton();

            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            // selecting one assignment
            if ( assignmentsFromUI.size() > 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.ASSIGNMENTS_SELECTED_COUNT.replace( Constants.Reports.SELECTED_COUNT, "1" );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( expectedFiltersCount ), "Count of Selected assignment filters displayed Properly after collapse the fiters",
                        "Count of Selected assignment filter is not displayed Properly after collapse the fiters" );

                reportComponent.expandFilterButton();

            } else {
                Log.message( "Teacher don't have enough Assignments" );
            }

            // deSelect all the assignment
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );

            // selecting all assignment
            if ( assignmentsFromUI.size() > 0 ) {

                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, Integer.toString( assignmentsFromUI.size() ) );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( expectedFiltersCount ), "Count of all assignment filters displayed Properly after collapse the fiters",
                        "Count of all assignment filter is not displayed Properly after collapse the fiters" );
            } else {
                Log.message( "Teacher don't have enough Assignments" );
            }
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Additional Grouping' dropdown should display on CPR page.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR013() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR013: Verify 'Additional Grouping' dropdown should display on CPR page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Getting values for Additional grouping
            List<String> additionalGroupingFromUI = reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN );

            // Validation for Additional grouping
            Log.assertThat( ( additionalGroupingFromUI ).equals( ( Constants.Reports.ADDITION_GROUPING ) ), "Additional grouping information loaded successfully!", "Additional grouping information not loaded properly!" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Display' dropdown should display on CPR page", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR014() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR014: Verify 'Display' dropdown should display on CPR page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Getting values for Display
            List<String> displayFromUI = reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.DISPLAY_DROPDOWN );

            // Validation for Sort
            Log.assertThat( ( displayFromUI ).equals( Constants.Reports.DISPLAY ), "Display information loaded successfully!", "Display information not loaded properly!" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Sort' drop down should display on CPR page.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR015() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR015: Verify 'Sort' drop down should display on CPR page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Getting values for Sort
            List<String> sortFromUI = reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.SORT_DROPDOWN );

            // Validation for Sort
            Log.assertThat( ( sortFromUI ).equals( ( Constants.Reports.SORT ) ), "Sort information loaded successfully!", "Sort information not loaded properly!" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Start date' and 'End date'should display on CPR page.", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR016() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR016: Verify 'Start date' and 'End date'should display on CPR page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to CPR Page
            CPRPage reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            reportPage.selectShowStudentPerformancefor( Constants.Reports.CPR_SELECTED_DATE_RANGE );

            // Verify From date field
            Log.assertThat( reportPage.isFromDateAndToDateHeaderPresent( Constants.Reports.CPR_FROM_DATE ), "From Date field is available in CPR Page.", "From Date field is not available in CPR Page." );
            // Verify To date field
            Log.assertThat( reportPage.isFromDateAndToDateHeaderPresent( Constants.Reports.CPR_TO_DATE ), "To Date field is available in CPR Page.", "To Date field is not available in CPR Page." );
            // verify date picker for from date field
            Log.assertThat( reportPage.isDatePickerDisplayedForFomDAte(), "Date picker is available for From date", "Date picker is not available for From date" );
            // verify date picker for To date field
            Log.assertThat( reportPage.isDatePickerDisplayedForToDAte(), "Date picker is available for To date", "Date picker is not available for To date" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify default selection of subject dropdown", groups = { "SMK-38393", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR017() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMCPR017: Verify default selection of subject dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Verify Select ALL check box is checked or not
            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.SUBJECT_DROPDOWN ), "Select All is checked", "Select All is not checked" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the availablity and Options  of Subject dropdown in Subject filter in Cumulative Reports Page", groups = { "SMK-43900", "reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSMCPR018() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMCPR018: Verify the option of Subject drop down is displayed in Cumulative Report Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Verifying the availability of Subject dropdown
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject dropdown is present", "Subject dropdown is not present" );

            // Verifying the options of Subject dropdown
            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.SUBJECT_DROPDOWN ), "Select All option is present in Subject dropdown", "Select All option is not present in Subject dropdown" );
            reportComponent.setDropDownMS( Constants.Reports.SUBJECT_DROPDOWN );
            Log.assertThat( reportComponent.getValuesFromDropDownMS().containsAll( Constants.Reports.SUBJECTS ), "All options are available in Subject dropdown", "Some option is missing in Subject dropdown" );

            // Verifying default selection of Subject dropdown
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "All options are selected by default in Subject dropdown", "All options are not selected by default in Subject dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in Cumulative Performance Report Page", groups = { "SMK-43900", "reports",
            "cumulativePerformanceReport" }, priority = 1 )
    public void tcSMCPR019() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSMCPR019: Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in Cumulative Performance Report Page <small><b><i>[" + browser
                + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> subjectOption = new ArrayList<>();

            // Select Math from subject dropdown
            subjectOption.add( Constants.Reports.SUBJECTS.get( 0 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            if ( !reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String mathReportFilter = "Math Subject " + System.nanoTime();
                reportComponent.saveReportOption( mathReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( mathReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SUBJECTS.get( 0 ) ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );
            } else {
                Log.message( "No assignments available for Math subject" );
            }

            // Select Reading from subject dropdown
            subjectOption.add( Constants.Reports.SUBJECTS.get( 1 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            if ( !reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String readingReportFilter = "Reading Subject " + System.nanoTime();
                reportComponent.saveReportOption( readingReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( readingReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SUBJECTS.get( 1 ) ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );
            } else {
                Log.message( "No assignments available for Reading subject" );
            }

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in Cumulative Report Page", groups = { "SMK-40023", "Saved Reports Option",
            "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR001: Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in Cumulative Report Page <small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> subjectOption = new ArrayList<>();

            // Select Math from subject dropdown
            subjectOption.add( Constants.Reports.SUBJECTS.get( 0 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            if ( !reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String mathReportFilter = "Math Subject " + System.nanoTime();
                reportComponent.saveReportOption( mathReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( mathReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SUBJECTS.get( 0 ) ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );
            } else {
                Log.message( "No assignments available for Math subject" );
            }

            // Select Reading from subject dropdown
            subjectOption.add( Constants.Reports.SUBJECTS.get( 1 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            if ( !reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String readingReportFilter = "Reading Subject " + System.nanoTime();
                reportComponent.saveReportOption( readingReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( readingReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SUBJECTS.get( 1 ) ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );
            } else {
                Log.message( "No assignments available for Reading subject" );
            }
            //SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all available fields in 'Save Report Option As' Popup on CPR", groups = { "SMK-40023", "Saved Reports Option", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR002: Verify all available fields in 'Save Report Option As' Popup on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();
            reportComponent.clickSaveReportOption();

            Log.assertThat( reportComponent.getSaveReportPopUpTextHeader().equals( Constants.Reports.SAVEREPORT_POUP_HEADER ), "Save Report Option As Is displaying", "Save Report Option As is not displaying" );

            Log.assertThat( reportComponent.isSaveBtnDisplayedOnSaveReportPopUp(), "Save Button on save report option Field is displaying on Poup", "Save Button on save report option Field is not displaying on Poup" );

            Log.assertThat( reportComponent.isCancelBtnDisplayedOnSaveReport(), "Cancel Button on save report option Field is displaying on Poup", "Cancel Button on save report option Field is not displaying on Poup" );

            //SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if click the save button with empty Name in 'Save Report Option As' Popup on CPR.", groups = { "SMK-40023", "Saved Reports Option", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR003: Verify all available fields in 'Save Report Option As' Popup on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();
            reportComponent.clickSaveReportOption();

            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "save button is not clickable with already existing name", "save button is clickable with already existing name" );

            //SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if click the save button with already existing name in 'Save Report Option As' Popup on CPR.", groups = { "SMK-40023", "Saved Reports Option", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR004: Verify all available fields in 'Save Report Option As' Popup on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            //Save report options filter with new Name
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );

            //enter already existing name in the text box
            reportComponent.clickSaveReportOption();
            reportComponent.setReportFilterName( reportFilterName );
            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "save button is not clickable with already existing name", "save button is clickable with already existing name" );

            //SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = " Verify user can able to select any one existing name from 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup on CPR.", groups = { "SMK-40023", "Saved Reports Option",
            "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR005:  Verify user can able to select any one existing name from 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup on CPR. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );
            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            reportComponent.clickSaveReportOption();
            reportComponent.replaceExistingReport( Constants.Reports.CHOOSE_ONE );
            reportComponent.replaceExistingReport( reportFilterName );
            reportComponent.clickSaveOnSaveReportPopUp();
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> loadedOptions = reportPage.getAllSelectedFilters( reportComponent );
            // Validate default retained after selecting the save report
            Log.assertThat( selectedOptions.equals( loadedOptions ), "All default values loaded properly after selecting save reports ", "All dafaul field not loaded Properly" );

            //SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = " Verify user can able to save the reports with any one Group and All Assignments on CPR.", groups = { "SMK-40023", "Saved Reports Option", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR006:  Verify user can able to save the reports with any one Group and All Assignments on CPR. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            //getting groups From UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupOptions = new ArrayList<>();

            //selecting one Group
            if ( groupsFromUI.size() >= 1 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
            }

            //getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            //Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            //load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = " Verify user can able to save the reports with Multiple groups and multiple Assignment on CPR.", groups = { "SMK-40023", "Saved Reports Option", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR007:  Verify user can able to save the reports with Multiple groups and multiple Assignment on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            //getting groups From UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupOptions = new ArrayList<>();

            //selecting  Groups
            if ( groupsFromUI.size() >= 2 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                groupOptions.add( groupsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
            }

            //getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            //selecting multiple assignments
            if ( assignmentsFromUI.size() >= 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            }

            //getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            //Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            //load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to save the reports with All groups and one Assignment on CPR.", groups = { "SMK-40023", "Saved Reports Option", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR008() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR008:  Verify user can able to save the reports with All groups and one Assignment on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            //getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            //selecting one assignment
            if ( assignmentsFromUI.size() >= 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            }

            //getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            //Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            //load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to save the reports with one Students and multiple Assignments on CPR.", groups = { "SMK-40023", "Saved Reports Option", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR009:  Verify user can able to save the reports with one Students and multiple Assignments on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            //getting students From UI
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> studentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();

            //selecting one Student
            if ( studentsFromUI.size() >= 1 ) {
                studentOptions.add( studentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );
            }

            //getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            //selecting multiple assignments
            if ( assignmentsFromUI.size() >= 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            }

            //getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            //Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            //load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to save the reports with All Students and one Assignments on CPR.", groups = { "SMK-40023", "Saved Reports Option", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR010() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR010: Verify user can able to save the reports with All Students and one Assignments on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            //getting students From UI
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );

            //getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            //selecting one assignment
            if ( assignmentsFromUI.size() >= 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            }

            //getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            //Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            //load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to save the reports with multiple Students and Multiple Assignment on CPR.", groups = { "SMK-40023", "Saved Reports Option", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR011: Verify user can able to save the reports with multiple Students and Multiple Assignment on CPR.<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            //getting students From UI
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> studentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();

            //selecting multiple Students
            if ( studentsFromUI.size() >= 2 ) {
                studentOptions.add( studentsFromUI.get( 0 ) );
                studentOptions.add( studentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );
            }

            //getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            //selecting multiple assignments
            if ( assignmentsFromUI.size() >= 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            }

            //getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            //Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            //load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify If delete the group after saved the report option with that student on CPR.", groups = { "SMK-40023", "Saved Reports Option", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR012() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR012: Verify If delete the group after saved the report option with that student on CPR.<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // getting the groups names from data setup
            List<String> groupsList = new ArrayList<>();
            String groupDetails = DataSetup.teacherGroupMap.get( username ).get( username );
            for ( int groupCount = 1; groupCount <= SMUtils.getWordCount( groupDetails, "groupName" ); groupCount++ ) {
                groupsList.add( SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", groupCount ) );
            }

            // Getting groups from UI
            reportComponent.setDropDownMS( "Groups" );

            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

            if ( groupsFromUI.size() > 0 ) {
                // getting Group Name
                String groupName = groupsFromUI.get( 0 );

                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String reportFilterName = "reportFilter" + System.nanoTime();
                reportComponent.saveReportOption( reportFilterName );

                // Delete Group
                GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
                groupPage.viewGroup( groupName );
                // Need For Page load
                SMUtils.nap( 2 );
                groupPage.deleteGroup( groupName );

                // navigate to CPR Page
                reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

                // again Getting groups from UI
                reportComponent.setDropDownMS( "Groups" );
                groupsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

                // validate delete group should not display under groups
                Log.assertThat( !( groupsFromUI.contains( groupName ) ), "Deleted Group is not present under Groups Dropdown", "Deleted Group is present under Groups Dropdown" );

                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( reportFilterName );

                // validate delete group should not display under groups
                Log.assertThat( !( groupsFromUI.contains( groupName ) ), "Deleted Group is not present under Groups Dropdown fo saved report", "Deleted Group is present under Groups Dropdown for saved report" );

                //SignOut from SM
                teacherHomePage.topNavBar.signOutfromSM();
            } else {
                Log.message( "Given teacher don't have goups" );
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify If soft delete the assignment after saved the report option with that assignment on CPR", groups = { "SMK-40023", "Saved Reports Option", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_SavedReportCPR013() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SavedReportCPR013:Verify If soft delete the assignment after saved the report option with that assignment on CPR.<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            studentLastName = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,lastName" );
            sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
            List<String> studentId = new ArrayList();
            studentId.add( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,personId" ) );
            new BaseAPITest().assignCourse( smUrl, sessionCookie, "Math", DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "1", studentId );
            smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );
            reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();
            // Take all assignments from Data SetUp
            List<String> assignmnetsList = new ArrayList<>();
            String assignmentsDetails = DataSetup.teacherAssignmentMap.get( username ).get( username );
            for ( int assignmentsCount = 1; assignmentsCount <= SMUtils.getWordCount( assignmentsDetails, "name" ); assignmentsCount++ ) {
                assignmnetsList.add( SMUtils.getKeyValueFromJsonArray( assignmentsDetails, "name", assignmentsCount ) );
            }

            // Getting Assignments from UI
            reportComponent.setDropDownMS( "Assignments" );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

            if ( assignmentsFromUI.size() > 0 ) {
                // getting Assignment Name
                String assignmentsName = assignmentsFromUI.get( 0 );

                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String reportFilterName = "reportFilter" + System.nanoTime();
                reportComponent.saveReportOption( reportFilterName );
                // Navigate to Courseware tab
                AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

                // Click on Assignment SubMenu
                page.clickAssignmentSubMenu();

                // Click Delete Assignment
                AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( assignmentsName );
                assignmentDetailsPage.assignmentLevelEllipsis();
                assignmentDetailsPage.deleteAssignmenttab();
                SMUtils.nap( 2 );// This is required to load page
                assignmentDetailsPage.deleteAssignmentButton();
                Log.assertThat( assignmentDetailsPage.isAssignmentDisplayed(), "Assignment has deleted successfully", "Assignment has not deleted successfully" );

                // navigate to SPR Report page
                tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
                reportComponent.setDropDownMS( "Assignments" );
                assignmentsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

                Log.assertThat( !( assignmentsFromUI.contains( assignmentsName ) ), "Deleted assignments is not present under Assignments Dropdown", "Deleted assignments is present under assignments Dropdown" );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( reportFilterName );

                Log.assertThat( !( assignmentsFromUI.contains( assignmentsName ) ), "Deleted assignments is not present under Assignments Dropdown", "Deleted assignments is present under assignments Dropdown" );
            } else {
                Log.message( "Teacher dont have assignments" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Test Cases for CPR", groups = { "SMK-38393", "Reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_CPRP3P4_001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        Log.testCaseInfo( "tcSM_CPRP3P4_001:P3 and P4 Test Cases for CPR <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();
            // Getting values for Additional grouping
            reportComponent.setDropDownMS( Constants.Reports.SUBJECT_DROPDOWN );
            SMUtils.logDescriptionTC( "SMK-38393-Verify SELECT ALL Option is selectable in Subject drop down in Cumulative Report Page" );
            SMUtils.logDescriptionTC( "SMK-38393- Verify that Subject drop down in Subject fileter in Cumulative Reports Page is a multi select drop down " );
            // Verify Select ALL check box is checked or not
            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.SUBJECT_DROPDOWN ), "Select All is checked", "Select All is not checked" );
            SMUtils.logDescriptionTC( "SMK-38393-Verify the Filters option should be a expandable and collapse field." );
            //Collapse filter
            reportComponent.collapseFilterButton();
            //Expand Filter
            reportComponent.expandFilterButton();

            // Verify Group radio button
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.GROUP_DROPDOWN );
            SMUtils.logDescriptionTC( "SMK-38393-Verify 'Groups' dropdown should display under filters option." );
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.GROUP_DROPDOWN ), "Groups radio button is present and checked", "Groups radio button is not present" );

            // get WebElements of dopdown option checkboxes
            List<String> optionsFromSubjectDropDown = reportComponent.getValuesFromDropDownMS();
            List<String> subjectOption = new ArrayList<>();

            // Select Reading from subject dropdown
            subjectOption.add( optionsFromSubjectDropDown.get( 1 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );

            Log.assertThat( reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SPR_MATH ), "Math is selected for Subject filter", "Math is not selected for Subject filter" );

            // Select Reading from subject dropdown
            subjectOption.add( optionsFromSubjectDropDown.get( 0 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            Log.assertThat( reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SPR_READING ), "Reading is selected for Subject filter", "Reading is not selected for Subject filter" );

            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );
            Log.assertThat( !reportComponent.isSelectALLChecked( Constants.Reports.GROUP_DROPDOWN ), "All groups has been deselected now", "All groups has not deselected now" );

            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            Log.assertThat( !reportComponent.isSelectALLChecked( Constants.Reports.SUBJECT_DROPDOWN ), "All Subject has been deselected now", "All Subject has not deselected now" );

            // Validating groups names are listed in Groups drop-down
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsOnUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupsList = groupsOnUI;
            Collections.sort( groupsList );
            SMUtils.logDescriptionTC( "SMK-39429-Verify the Groups name should display in ascending order under Groups dropdown." );
            Log.assertThat( groupsList.equals( groupsOnUI ), "Groups name is showing as sorted order", "Groups name is not showing as sorted order" );

            // Verify Students radio button
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.STUDENTS_DROPDOWN ), "Students radio button is present and checked", "Students radio button is not present" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Test Cases for CPR", groups = { "SMK-38393", "Reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_CPRP3P4_002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_002: P3 and P4 Cases for cumulative performance report <small><b><i>[" + browser + "]</b></i></small>" );

        String teacherUsername = "AutomatedTeacher_ForZeroState" + System.nanoTime();
        //Creating teacher for Zero state test
        new UserSqlHelper().createTeacher( teacherUsername, teacherUsername, teacherUsername, Constants.PASSWORD_HASH, DataSetup.organizationId );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );
            // Navigate to CPR page
            reportPage = tHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            Log.assertThat( reportComponent.isZeroStateMessageDisplayed(), "Zero state message is displaying", "Zero state message is not displaying" );

            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            String studentID = studentsPage.createStudent();
            // Navigate to SPR Page

            reportPage = tHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            Log.assertThat( reportComponent.getZeroStateTextGroups().equalsIgnoreCase( Constants.Reports.ZERO_STATE_TEXT_GRP ), "Zero state message is displaying for group", "Zero state message is not displaying" );
            Log.assertThat( reportComponent.getZeroStateTextAssignments().equalsIgnoreCase( Constants.Reports.ZERO_STATE_TEXT_ASSIGNMENTS ), "Zero state message is displaying for assignments", "Zero state message is not displaying" );

            Log.assertThat( !reportComponent.isRunReportButtonEnabled(), "Run Report Button is disabled when teacher doesnot have assignments", "Run Report Button is not disabled when teacher doesnot have assignments" );
            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Test Cases for CPR", groups = { "SMK-38393", "Reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_CPRP3P4_003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_003:P3 and P4 Test Cases for CPR <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            //getting students From UI
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            List<String> studentFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();

            // Verify the Dropdown text after selecting one Group
            if ( studentFromUI.size() > 1 ) {
                studentOptions.add( studentFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );
                Log.assertThat( studentFromUI.get( 0 ).equals( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ) ), "Selected Student name is Displayed", "Selected student name is not Displayed" );
            } else {
                Log.message( "Teacher dont have Student" );
            }
            // Verify assignment dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "Assignments dropdown is present in the CPR Page", "Assignments dropdown is not present in the CPR Page" );

            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            Log.assertThat( !reportComponent.isSelectALLChecked( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "All Assignments has been deselected now", "All Assignments has not deselected now" );

            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentsPage assignmentpage = new AssignmentsPage( driver );

            List<String> actualAssignmenstList = new ArrayList<>();
            List<String> assignmentsList = assignmentpage.assignmentsList();
            Collections.sort( assignmentsList );
            for ( String value : assignmentsList ) {
                actualAssignmenstList.add( value.trim() );
            }
            tHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> valuesFromDropDownMS = reportComponent.getValuesFromDropDownMS();
            Log.assertThat( valuesFromDropDownMS.containsAll( actualAssignmenstList ), "All assignments are listed in Assignments dropdown in sorted order", "Assignments dropdowm is not listed all assignments in sorted order" );

            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "All the options in the drop down are selected by default", "All the options in the drop down are not selected by default" );

            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            Log.assertThat( !reportComponent.isSelectALLChecked( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "All the options in the drop down are unchecked", "All the options in the drop down are not unchecked" );

            // Verify Saved Option dropdown heading
            Log.assertThat( reportComponent.isSavedOptionDropdownHeadingPresent(), "Saved Options dropdown is present in the CPR Page", "Saved Option dropdown is not present in the CPR Page" );

            // Verify Display dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.SORT_DROPDOWN ), "Sort dropdown heading is present in the CPR Page", "Sort dropdown heading is not present in the CPR Page" );

            reportComponent.checkOrUncheckMaskStudentDisplay();
            reportComponent.checkOrUncheckRemovePageBreak();
            Log.assertThat( reportComponent.isMaskStudentDisplayChecked(), "Mask Student checkbox selected", "Mask Student checkbox is not selected" );
            Log.assertThat( reportComponent.isRemovePageBreakChecked(), "Remove Page Break checkbox selected", "Remove Page Break checkbox is not selected" );

            // Verify "all date" field
            Log.assertThat( reportPage.isAllDatesAndSelectedDateRangeFieldPresent( Constants.Reports.CPR_ALL_DATES ), "All Date field is present in the CPR page", "All Date field is not present in the CPR page" );

            // Verify "Selected date Range" field
            Log.assertThat( reportPage.isAllDatesAndSelectedDateRangeFieldPresent( Constants.Reports.CPR_SELECTED_DATE_RANGE ), "Selected date Range field is present in the CPR page", "Selected date Range field is not present in the CPR page" );

            reportPage.selectShowStudentPerformancefor( Constants.Reports.CPR_SELECTED_DATE_RANGE );

            // Verify From date field
            Log.assertThat( reportPage.isFromDateAndToDateHeaderPresent( Constants.Reports.CPR_FROM_DATE ), "From Date field is available in CPR Page.", "From Date field is not available in CPR Page." );
            // Verify To date field
            Log.assertThat( reportPage.isFromDateAndToDateHeaderPresent( Constants.Reports.CPR_TO_DATE ), "To Date field is available in CPR Page.", "To Date field is not available in CPR Page." );
            // verify date picker for from date field
            Log.assertThat( reportPage.isDatePickerDisplayedForFomDAte(), "Date picker is available for From date", "Date picker is not available for From date" );
            // verify date picker for To date field
            Log.assertThat( reportPage.isDatePickerDisplayedForToDAte(), "Date picker is available for To date", "Date picker is not available for To date" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Test Cases for CPR", groups = { "SMK-38393", "Reports", "cumulativePerformanceReport" }, priority = 2 )
    public void tcSM_CPRP3P4_004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_004:P3 and P4 Test Cases for CPR <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Verify Run Report
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getRunReportOption() ), "Run report button present!", "Run report not button present!" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            Log.assertThat( !reportComponent.isRunReportButtonEnabled(), "Run Report Button is disabled when teacher doesnot have assignments", "Run Report Button is not disabled when teacher doesnot have assignments" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            reportPage.selectShowStudentPerformancefor( Constants.Reports.CPR_SELECTED_DATE_RANGE );

            reportPage.setDateRange( Constants.Reports.START_DATE, Constants.Reports.END_DATE );

            Log.assertThat( reportPage.getErrorMessage( Constants.Reports.CPR_FROM_DATE ).equalsIgnoreCase( Constants.Reports.DATE_ERROR_MESSAGE ), "Wrong date is not accepting by Start date , Error message is throwing",
                    "Wrong date is  accepting by Start date , Error message is not throwing" );
            Log.assertThat( reportPage.getErrorMessage( Constants.Reports.CPR_TO_DATE ).equalsIgnoreCase( Constants.Reports.DATE_ERROR_MESSAGE ), "Wrong date is not accepting by End date , Error message is throwing",
                    "Wrong date is  accepting by End date , Error message is not throwing" );
            Log.assertThat( !reportComponent.isRunReportButtonEnabled(), "Run Report Button is disabled when Error Message is displaying", "Run Report Button is not disabled when error message is not displaying" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Save Report Option' on CPR.", groups = { "SMK-40022", "saveReports", "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_CPRP3P4_005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify 'Save Report Option' on CPR." + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to CPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            SMUtils.logDescriptionTC( "Verify 'Save Report Option' on CPR." );
            // Verify Save Report Option button
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getSaveReportOptionButton() ), "Saved Report option button is present", "Saved Report option button is not present!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify user can able to cancel the in 'Save Report Option As' Popup on CPR.\n" + "Verify the report options are not saved when the user click on 'Cancel' button in 'Save Report option' modal popup" );
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.setFilterName( reportFilterName );
            reportComponent.clickcancelButtoninSaveReportPopup();
            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "Save Report option popup is closed", "Save Report option popup is not closed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify If User enter more than 50 characters in name text box." );
            reportComponent.clickSaveReportOption();
            reportComponent.setFilterName( Reports.MAX_LENGTH_FILTER_NAME );
            reportComponent.clickSaveButtoninSavedOptionPopup();
            Log.assertThat( reportComponent.getSaveReportOptionErrorMsg().equals( Constants.Reports.EXCEED_MAX_LENGTH ), "Save Report Option popup throws the error message for lengthy name",
                    "Save Report Option popup is not throwing the error message for lengthy name" );
            Log.testCaseResult();

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify If click the 'Replace Existing Report Options' radio button in 'Save Report Option As' Popup on CPR.", groups = { "SMK-40022", "saveReports", "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_CPRP3P4_006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_006: Verify If click the 'Replace Existing Report Options' radio button in 'Save Report Option As' Popup on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            // Select values in static drop down
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, Constants.Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENT_USERNAME );

            SMUtils.logDescriptionTC( "Verify If click the 'Replace Existing Report Options' radio button in 'Save Report Option As' Popup on CPR." );
            // Save the report
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            reportComponent.selectValueFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, Constants.Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENTID );

            // Click Save Report Option
            reportComponent.clickSaveReportOption();
            // Click Replace Existing Report radio button
            reportComponent.clickExistingReportValue( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equals( Constants.Reports.STUDENTID ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify If click the 'Replace Existing Report Options' radio button in 'Save Report Option As' Popup on CPR.", groups = { "SMK-40022", "saveReports", "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_CPRP3P4_007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_007: Verify If click the 'Replace Existing Report Options' radio button in 'Save Report Option As' Popup on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Remove Page breaks and Mask student display on CPR.\n" + "Verify User can able to save the report option with Grade option in Additional Grouping on CPR.\n"
                    + "Verify User can able to save the report option with Student ID option in Display on CPR.\n" + "Verify User can able to save the report option with Assgned Course Level option in sort on CPR.\n"
                    + "Verify User can able to save the report option with Mask Student Display on CPR.\n" + "Verify User can able to save the report option with Remove Page Break on CPR.\n"
                    + "Verify User can able to save the report option with Grade option in Additional Grouping, Student Id in display and assigned course level in Sort on CPR." );

            //Selecting fields
            reportComponent.checkOrUncheckMaskStudentDisplay();
            reportComponent.checkOrUncheckRemovePageBreak();
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 1 ) );

            // Save the report
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equals( Constants.Reports.STUDENTID ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 1 ) ), "The selected option is displayed in Sort dropdown",
                    "The selected option is not displayed in Sort dropdown" );
            Log.assertThat( reportComponent.isMaskStudentDisplayChecked(), "Mask student display is checked as Expected", "Mask student display is not checked" );
            Log.assertThat( reportComponent.isRemovePageBreakChecked(), "Remove page breaks is checked as Expected", "Remove page breaks is not checked" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Current course level in Sort on CPR.", groups = { "SMK-40022", "saveReports",
            "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_CPRP3P4_008() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_008: Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Current course level in Sort on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Current course level in Sort on CPR." );
            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 2 ) );

            // Save the report
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 2 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Grade option in Additional Grouping, Student Id in display and IP level in Sort on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 3 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENTID ), "The selected option is displayed in Display dropdown", "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 3 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Gain in Sort on CPR.", groups = { "SMK-40022", "saveReports",
            "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_CPRP3P4_009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_009: Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Gain in Sort on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Gain in Sort on CPR." );
            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 4 ) );

            // Save the report
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 4 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in sort dropdown" );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Grade option in Additional Grouping, Student Id in display and Time Spent in Sort on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 5 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENTID ), "The selected option is displayed in Display dropdown", "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 5 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Total Sessions in Sort on CPR.", groups = { "SMK-40022", "saveReports",
            "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_CPRP3P4_010() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_010: Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Total Sessions in Sort on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Total Sessions in Sort on CPR." );
            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 6 ) );

            // Save the report
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 6 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Grade option in Additional Grouping, Student Id in display and Exercise correct in Sort on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 7 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENTID ), "The selected option is displayed in Display dropdown", "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 7 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Exercise Attempted in Sort on CPR.", groups = { "SMK-40022", "saveReports",
            "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_CPRP3P4_011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_011: Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Exercise Attempted in Sort on CPR. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Exercise Attempted in Sort on CPR." );
            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 8 ) );

            // Save the report
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 8 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Grade option in Additional Grouping, Student Id in display and Skils assessed in Sort with Selected date range on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 9 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENTID ), "The selected option is displayed in Display dropdown", "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 9 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Skils Mastered in Sort with Selected date range on CPR.", groups = { "SMK-40022", "saveReports",
            "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_CPRP3P4_012() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_012: Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Skils Mastered in Sort with Selected date range on CPR.<small><b><i>[" + browser
                + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and Skils Mastered in Sort with Selected date range on CPR." );
            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 10 ) );

            // Save the report
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 10 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Grade option in Additional Grouping, Student Id in display and Skils Percentn Mastered in Sort with Selected date range on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 11 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENTID ), "The selected option is displayed in Display dropdown", "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 11 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Grade option in Additional Grouping, Student Username in display and AP in Sort with Selected date range on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 12 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GRADES ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 12 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with Group option in Additional Grouping on CPR.", groups = { "SMK-40022", "saveReports", "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_CPRP3P4_013() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_013: Verify User can able to save the report option with Group option in Additional Grouping on CPR.<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping on CPR.\n"
                    + "Verify User can able to save the report option with Group option in Additional Grouping, Student Id in display and assigned course level in Sort on CPR." );
            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 1 ) );

            // Save the report
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GROUP ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENTID ), "The selected option is displayed in Display dropdown", "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 1 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping, Student Username in display and Current course level in Sort on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 2 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GROUP ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 2 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping, Student Id in display and IP level in Sort on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 3 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GROUP ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENTID ), "The selected option is displayed in Display dropdown", "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 3 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping, Student Username in display and Gain in Sort on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 4 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GROUP ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 4 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with Group option in Additional Grouping, Student Id in display and Time Spent in Sort on CPR.", groups = { "SMK-40022", "saveReports",
            "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_CPRP3P4_014() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_CPRP3P4_014: Verify User can able to save the report option with Group option in Additional Grouping, Student Id in display and Time Spent in Sort on CPR..<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping, Student Id in display and Time Spent in Sort on CPR." );
            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 5 ) );

            // Save the report
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GROUP ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENTID ), "The selected option is displayed in Display dropdown", "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 5 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping, Student Username in display and Total Sessions in Sort on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 6 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GROUP ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 6 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping, Student Id in display and Exercise correct in Sort on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 7 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GROUP ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENTID ), "The selected option is displayed in Display dropdown", "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 7 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping, Student Username in display and Exercise Attempted in Sort on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 8 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GROUP ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENT_USERNAME ), "The selected option is displayed in Display dropdown",
                    "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 8 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with Group option in Additional Grouping, Student Id in display and Skils assessed in Sort with Selected date range on CPR.", groups = { "SMK-40022", "saveReports",
            "cumulativePerformanceReport" }, priority = 3 )
    public void tcSM_CPRP3P4_015() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo(
                "tcSM_CPRP3P4_015: Verify User can able to save the report option with Group option in Additional Grouping, Student Id in display and Skils assessed in Sort with Selected date range on CPR..<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // navigate to PSR Page
            reportPage = teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping, Student Id in display and Skils assessed in Sort with Selected date range on CPR.\n"
                    + "Verify the multiple Students and multiple assignments with other fields on CPR" );
            //getting groups From UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupOptions = Arrays.asList( groupsFromUI.get( 0 ), groupsFromUI.get( 1 ) );

            //selecting  Groups
            reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );

            //getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = Arrays.asList( assignmentsFromUI.get( 0 ), assignmentsFromUI.get( 1 ) );

            reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 9 ) );
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );
            // Save the report
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the Loaded report options
            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );
            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping, Student Username in display and Skils Mastered in Sort with Selected date range on CPR.\n"
                    + "Verify the multiple Students and multiple assignments with other fields on CPR" );

            //getting students From UI
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> studentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = Arrays.asList( studentsFromUI.get( 0 ), studentsFromUI.get( 1 ) );

            //selecting  Groups
            reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );

            //getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            assignmentOptions = Arrays.asList( assignmentsFromUI.get( 0 ), assignmentsFromUI.get( 1 ) );

            reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 10 ) );
            selectedOptions = reportPage.getAllSelectedFilters( reportComponent );
            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );
            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );
            Log.testCaseResult();
            Log.testCaseResult();

            reportComponent.loadReportOption( Reports.CHOOSE_ONE );

            SMUtils.logDescriptionTC( "Verify User can able to save the report option with Group option in Additional Grouping, Student Id in display and Skils Percentn Mastered in Sort with Selected date range on CPR." );

            //Selecting fields
            reportComponent.selectValueFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN, Reports.GROUP );
            reportComponent.selectValueFromStaticDropdown( Reports.DISPLAY_DROPDOWN, Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Reports.SORT_DROPDOWN, Reports.SORT.get( 11 ) );

            // Save the report
            reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportFilterName );

            //load report
            reportComponent.loadReportOption( Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            // Verify the saved report
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Reports.GROUP ), "The selected option is displayed in Additional Grouping dropdown",
                    "The selected option is not displayed in Additional Grouping dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.DISPLAY_DROPDOWN ).equals( Reports.STUDENTID ), "The selected option is displayed in Display dropdown", "The selected option is not displayed in Display dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Reports.SORT_DROPDOWN ).equals( Reports.SORT.get( 11 ) ), "The selected option is displayed in Sort dropdown", "The selected option is not displayed in Sort dropdown" );
            Log.testCaseResult();

            // Navigate to Cumulative Performance Page
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();

            SMUtils.logDescriptionTC( "SMK-11069 - Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Math and Reading subject alone in Cumulative Performance report page" );
            String selectedAssignments = reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            if ( !selectedAssignments.equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String allSubjectReportFilter = "All Subject " + System.nanoTime();
                reportComponent.saveReportOption( allSubjectReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( allSubjectReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "Selected subject filters are loaded Successfully", "Selected subject filters are not loaded Successfully" );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( selectedAssignments ), "Selected assignment filters are loaded Successfully",
                        "Selected assignment filters are not loaded Successfully" );
            } else {
                Log.message( "No assignments available for Math subject" );
            }
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11070 - Verify the teacher able to see All Subjects (2) while colapsing the Filters if both subjects are selected in Subjects dropdown" );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "All Subjects (2) is displayed while colapsing the filters if both subjects are selected in Subjects dropdown", "All Subjects (2) is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11071 - Verify the teacher able to see Math while colapsing the Filters if Math subject is selected in Subjects dropdown" );
            // Expanding filters
            reportComponent.expandFilterButton();
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.MATH ) );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.MATH ), "Math is displayed while colapsing the filters if both subjects are selected in Subjects dropdown",
                    "Math is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11072 - Verify the teacher able to see Reading while colapsing the Filters if Reading subject is selected in Subjects dropdown" );
            // Expanding filters
            reportComponent.expandFilterButton();
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.READING ) );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.READING ), "Reading is displayed while colapsing the filters if both subjects are selected in Subjects dropdown",
                    "Reading is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }
}
