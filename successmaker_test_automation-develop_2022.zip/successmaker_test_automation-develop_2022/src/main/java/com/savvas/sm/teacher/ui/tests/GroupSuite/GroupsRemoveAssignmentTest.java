package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This class test the Delete Group Assignments UI testing.
 *
 * @author madhan.nagarathinam
 *
 */

@Listeners ( EmailReport.class )
public class GroupsRemoveAssignmentTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String username = null;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String groupDetails;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );

        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), RBSDataSetupConstants.USERID ) );

        HashMap<String, String> groupDetailsMap = new HashMap<>();
        groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, "SM Regression Group" + System.nanoTime() );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );
        groupDetails = createGroup.get( Constants.BODY );
    }

    @Test ( priority = 1, groups = { "SMK-39205", "groups", "groupsDeleteAssignment" } )
    public void tcDeleteGroupAssignment001( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "data,groupName" );
        String assignmentName = Constants.GroupsAssignments.MATH;
        context.setAttribute( "groupName", groupName );
        context.setAttribute( "assignmentName", assignmentName );
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Assigning assignment for group
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( assignmentName );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.clickViewGroupUsingGroupName( groupName );

            // Navigate to Groups Assignment sub-Nav
            groupsTab.getAssignmentDetailsBasedOnGroup();

            // Verifying the Remove Assignments pop-up menu
            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickDeleteAssignmentonThreeDotEllipses();

            SMUtils.logDescriptionTC( "tcDeleteGroupAssignment001: Verify the Teacher can able to view the Delete assignment popup Menu after clicking the delete assignment link from three dots ellipsis corresponding to the assignment title" );
            Log.assertThat( groupsTab.isDeleteAssignmentPopupLoaded(), "Teacher is able to view delete Assignment pop-up", "Teacher is not able to view delete Assignment pop-up" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "tcDeleteGroupAssignment002: Verify the teacher able to view the message displayed in the Delete assignment popup Menu after clicking the delete assignment link from three dots ellipsis corresponding to the assignment title" );
            Log.assertThat( groupsTab.isDeleteAssignmentPopupMessageDisplayed().contentEquals( Constants.GroupsAssignments.DELETE_ASSIGNMENT_POPUP_MESSAGE ), "Delete Assignment pop-up message is displayed for the selected Assignment",
                    "Delete Assignment pop-up message is not getting displayed for the selected Assignment" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "tcDeleteGroupAssignment003: Verify by clicking the Delete button displayed in the Delete assignment popup Menu after clicking the delete assignment link from three dots ellipsis corresponding to the assignment title, Teacher can able to remove the assignment from the group " );
            SMUtils.logDescriptionTC(
                    "tcDeleteGroupAssignment006: Verify by clicking the Delete button displayed in the Delete assignment popup Menu after clicking the delete assignment link from three dots ellipsis corresponding to the assignment title, The Page should land on the Groups->assignments Sub-tab Page" );
            Log.assertThat( groupsTab.deleteGroupAssignment(), "Teacher is able to delete assignment", "Teacher is not able to delete the assignment in the group" );
            Log.assertThat( groupsTab.getZeroStateAssignmentMessage().contentEquals( Constants.GroupsAssignments.ZERO_STATE_ASSIGNMENT_MESSAGE ), "The Assignment is deleted successfully",
                    "The Assignment is not getting deleted after clicking delete button in the Delete Assignment pop-up" );
            Log.testCaseResult();
            Log.testCaseResult();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            driver.quit();

        }

        catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-39205", "groups", "groupsDeleteAssignment" } )
    public void tcDeleteGroupAssignment002( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        String groupName = context.getAttribute( "groupName" ).toString();
        String assignmentName = context.getAttribute( "assignmentName" ).toString();
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Assigning assignment for the created group
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickCourseName( assignmentName );
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            // Verify the groupName present
            groupsTab.clickViewGroupUsingGroupName( groupName );
            groupsTab.getAssignmentDetailsBasedOnGroup();
            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickDeleteAssignmentonThreeDotEllipses();
            groupsTab.isDeleteAssignmentPopupLoaded();
            SMUtils.logDescriptionTC(
                    "tcDeleteGroupAssignment004: Verify by clicking the Cancel button displayed in the Delete assignment popup Menu after clicking the delete assignment link from three dots ellipsis corresponding to the assignment title, Teacher cannot able to remove the assignment from the group" );
            SMUtils.logDescriptionTC(
                    "tcDeleteGroupAssignment007: Verify by clicking the Cancel button displayed in the Delete assignment popup Menu after clicking the delete assignment link from three dots ellipsis corresponding to the assignment title, The Page should land on the Groups->assignments Sub-tab Page" );
            Log.assertThat( groupsTab.clickCancelButtononDeleteAssignmentPopup(), "Teacher is able to click cancel button in the delete assignment and the assignment is not deleted!", "Teacher is not able to click cancel button in the delete assignment" );
            Log.testCaseResult();
            Log.testCaseResult();

            SMUtils.logDescriptionTC(
                    "tcDeleteGroupAssignment005: Verify by clicking the X button displayed in the Delete assignment popup Menu after clicking the delete assignment link from three dots ellipsis corresponding to the assignment title, Teacher cannot able to remove the assignment from the group" );
            SMUtils.logDescriptionTC(
                    "tcDeleteGroupAssignment008: Verify by clicking the X button displayed in the Delete assignment popup Menu after clicking the delete assignment link from three dots ellipsis corresponding to the assignment title, The Page should land on the Groups->assignments Sub-tab Page " );
            groupsTab.clickDeleteAssignmentonThreeDotEllipses();
            groupsTab.isDeleteAssignmentPopupLoaded();
            Log.assertThat( groupsTab.clickingXButtoninDeleteAssignmentPopup(), "Teacher is able to click 'X' button in the delete assignment and the assignment is not deleted!", "Teacher is not able to click 'X' button in the delete assignment" );
            Log.testCaseResult();
            Log.testCaseResult();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            driver.quit();

        }

        catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( priority = 3, groups = { "SMK-39205", "groups", "groupsDeleteAssignment" } )
    public void tcDeleteGroupAssignment003( ITestContext context ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        String testMethodName = new Object() {}.getClass().getEnclosingMethod().getName();
        String groupName = context.getAttribute( "groupName" ).toString();
        String assignmentName = context.getAttribute( "assignmentName" ).toString();
        Log.testCaseInfo( testMethodName + "-" + "" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            // Verify the groupName present
            groupsTab.clickViewGroupUsingGroupName( groupName );
            groupsTab.getAssignmentDetailsBasedOnGroup();
            SMUtils.logDescriptionTC( "tcDeleteGroupAssignment009: Verify the Teacher can able to view three dots ellipsis corresponding to the assignment title for the group" );
            groupsTab.clickThreeDotEllipsesonAssignment( assignmentName );
            groupsTab.clickDeleteAssignmentonThreeDotEllipses();
            Log.assertThat( groupsTab.isDeleteAssignmentBtnPresentonThreeDotEllipses(), "The Teacher can able to view three dots ellipsis corresponding to the assignment title for the group",
                    "The Teacher is not able to view three dots ellipsis corresponding to the assignment title for the group!" );
            Log.testCaseResult();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            driver.quit();
        }

        catch ( Exception e ) {
            Log.exception( e, driver );
        }

        finally {

            Log.endTestCase();
            driver.quit();
        }
    }

}