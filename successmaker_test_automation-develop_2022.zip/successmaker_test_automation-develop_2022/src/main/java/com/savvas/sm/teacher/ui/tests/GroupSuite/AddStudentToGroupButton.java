package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * Test the add student to group button popup functionality
 *
 * @author nishanth.kamaraj
 *
 */
@Listeners ( EmailReport.class )
public class AddStudentToGroupButton extends BaseTest {

    private String smUrl;
    private String browser;
    private String username = null;
    private String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String groupDetails;

    private static String studentOne;
    private static String studentTwo;
    private static String studentFour;
    private static String studentFive;
    private static String studentSix;

    String studentDetails1;
    String studentDetails2;
    String studentDetails3;
    String studentDetails4;
    String studentDetails5;

    @BeforeClass
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentDetails1 = RBSDataSetup.getMyStudent( school, username );
        studentDetails2 = RBSDataSetup.getMyStudent( school, username );
        studentDetails4 = RBSDataSetup.getMyStudent( school, username );
        studentDetails5 = RBSDataSetup.getMyStudent( school, username );
        studentDetails3 = RBSDataSetup.getMyStudent( school, username );

        studentOne = ( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERNAME ) );
        studentTwo = ( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERNAME ) );
        studentFour = ( SMUtils.getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERNAME ) );
        studentFive = ( SMUtils.getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERNAME ) );
        studentSix = ( SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERNAME ) );

        List<String> studentRumbaIds = new ArrayList<>();
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails1, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails2, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails4, RBSDataSetupConstants.USERID ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails5, RBSDataSetupConstants.USERID ) );

        HashMap<String, String> groupDetailsMap = new HashMap<>();
        groupDetailsMap.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetailsMap.put( CreateGroupAPIConstants.GROUP_NAME, "SM Regression Group" + System.nanoTime() );
        HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetailsMap, studentRumbaIds );
        groupDetails = SMUtils.getKeyValueFromResponse( createGroup.get( Constants.BODY ), "data" );
    }

    @Test ( priority = 1, groups = { "SMK-43184", "Group", "View Group", "Users", "AddStudentToGroupButton" } )
    public void tcAddStudentToGroupButtonPopup01( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify that Group name is displayed in the title of Add Students to Group popup" + "<small><b><i>[" + browser + "]</b></i></small>" );
        //SMUtils.logDescriptionTC( Verify that Group name is displayed in the title of Add Students to Group popup );
        try {

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "groupName" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();

            // Verify the add students to group title
            SMUtils.logDescriptionTC( "Verify that Group name is displayed in the title of Add Students to Group popup" );
            Log.message( groupsTab.addStudentToGroupTitle() );
            Log.message( Constants.Groups.ADDSTUDENT_TO_GROUP_TITLE + " " + groupName );
            Log.assertThat( groupsTab.addStudentToGroupTitle().equals( Constants.Groups.ADDSTUDENT_TO_GROUP_TITLE + " " + groupName ), "Add student to group title name is displayed successfully", "Add student to group title name is not displayed " );

            //Verify the list of students in add student to group popup
            SMUtils.logDescriptionTC( "Verify the list of students displayed on Add Students to Group popup" );
            String err_msg = groupsTab.getErrorMessageGradeNotSelect();
            Log.message( err_msg );
            Log.message( Constants.Groups.GET_ERROR_MSG_GRDAENOT_SELECTED );
            String exp_err_msg = Constants.Groups.GET_ERROR_MSG_GRDAENOT_SELECTED;

            Log.assertThat( err_msg.equals( exp_err_msg ), "Grade not selected error message is displayed ", "Grade not selected error message is not displayed " );
            groupsTab.clickOnCancelButtoninAddStudentPopup();

            //Verify the students list from add student popup and fname,lname,grade and username
            SMUtils.logDescriptionTC( "Verify that Student First Name, Last name, User name and Grade are displayed on Add Students to Group popup\r\n" + "" );
            groupsTab.clickAddStudentToGroup();
            HashMap<String, List<String>> AllStudentDetails = new HashMap<>();
            //AllStudentDetails = groupsTab.getStudentDetailsBasedOnGroup( groupName );
            AllStudentDetails = groupsTab.getAllStudentListFromAddStudent();
            Log.message( "All students listed from group" + groupName );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43184", "Group", "View Group", "Users", "AddStudentToGroupButton" } )
    public void tcAddStudentToGroupButtonPopup02( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify that user is able to add multiple student to a group" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "groupName" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();

            //add student to group
            SMUtils.logDescriptionTC( "Verify that user is able to add multiple student to a group" );

            String studentUN4 = studentOne;
            String studentUN5 = studentTwo;
            String studentUN6 = studentFour;
            List<String> studentUserNames = new ArrayList<>();
            studentUserNames.add( studentUN4 );
            studentUserNames.add( studentUN5 );
            studentUserNames.add( studentUN6 );
            groupsTab.addStudGroupWithHomeRoomStudents( groupName, studentUserNames );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43184", "Group", "View Group", "Users", "AddStudentToGroupButton" } )
    public void tcAddStudentToGroupButtonPopup03( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify that user is able to add single student to a group" + "<small><b><i>[" + browser + "]</b></i></small>" );

    	try {

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "groupName" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();

            //add student to group
            SMUtils.logDescriptionTC( "Verify that user is able to add single student to a group" );
            String studentUN4 = studentOne;
            List<String> studentUserNames = new ArrayList<>();
            studentUserNames.add( studentUN4 );
            groupsTab.addStudGroupWithHomeRoomStudents( groupName, studentUserNames );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43184", "Group", "View Group", "Users", "AddStudentToGroupButton" } )
    public void tcAddStudentToGroupButtonPopup04( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo(
    			"Verify the list of students are filtered based on grade is displayed on Add Students to Group popup when the \"Search all students in your school\" checkbox is checked\r\n" + "" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "groupName" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();

            //verify the checkbox checked and grade flitered
            SMUtils.logDescriptionTC( "Verify the list of students are filtered based on grade is displayed on Add Students to Group popup when the \"Search all students in your school\" checkbox is checked\r\n" + "" );
            String gradeValue = groupsTab.clickAllStudentsAndSelectGrade( Constants.Groups.GRADE_5 );
            groupsTab.selectGradeFromAddStudPopup( gradeValue );
            Log.message( gradeValue );
            Log.message( groupsTab.getGradeValue() );
            Log.assertThat( groupsTab.getGradeValue().equals( gradeValue ), "Grade updated", "Grade Id not updated properly" );
            groupsTab.clickOnCancelButtoninAddStudentPopup();

            //verify the checkbox checked and invalid grade flitered
            SMUtils.logDescriptionTC( "Verify that none of the students are displayed on Add Students to Group popup when the \"Search all students in your school\" checkbox is checked and invalid grade is selected\r\n" + "" );
            groupsTab.clickAddStudentToGroup();
            String gradeValue2 = groupsTab.clickAllStudentsAndSelectGrade( Constants.Groups.GRADE_2 );
            Log.message( gradeValue2 );
            Log.message( groupsTab.getGradeValue() );
            Log.assertThat( groupsTab.getGradeValue().equals( gradeValue2 ), "Grade updated", "Grade Id not updated properly" );
            groupsTab.clickOnCancelButtoninAddStudentPopup();

            //verify the checkbox checked and not specified grade flitered
            groupsTab.clickAddStudentToGroup();
            String gradeValueNS = groupsTab.clickAllStudentsAndSelectGrade( Constants.Groups.GRADE_NOT_SPECIFIED );
            Log.message( gradeValueNS );
            Log.message( groupsTab.getGradeValue() );
            Log.assertThat( groupsTab.getGradeValue().equals( gradeValueNS ), "Grade updated", "Grade Id not updated properly" );
            groupsTab.clickOnCancelButtoninAddStudentPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43184", "Group", "View Group", "Users", "AddStudentToGroupButton" } )
    public void tcAddStudentToGroupButtonPopup05( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify that data is erased on reopening \"Add students to Group\" popup --> add stud and verify " + "" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "groupName" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();

            // checking pop up after closing
            SMUtils.logDescriptionTC( "Verify that data is erased on reopening \"Add students to Group\" popup" + "" );
            String studentUN4 = studentOne;
            List<String> studentUserNames = new ArrayList<>();
            studentUserNames.add( studentUN4 );
            groupsTab.addStudGroupWithHomeRoomStudents( groupName, studentUserNames );
            groupsTab.clickonHoveredChipTxt( groupName );
            List<String> textValueBefore = groupsTab.getAddStudChipTextValue();
            Log.assertThat( Objects.nonNull( textValueBefore ), "Verified the text value is successfully ", "Verified the text value is not successfully " );
            // groupsTab.getValueAddStudTxtBox();
            groupsTab.clickCloseAddStudGroupButtoninPopup();
            groupsTab.clickAddStudentToGroup();
            //groupsTab.clickonHoveredChipTxt( groupName );
            String textValue = groupsTab.getValueAddStudTxtBox();
            //String textValueAfter = groupsTab.verifyTextBoxValue();
            Log.assertThat( Objects.isNull( textValue ), "Verified the text value is successfully ", "Verified the text value is not successfully " );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43184", "Group", "View Group", "Users", "AddStudentToGroupButton" } )
    public void tcAddStudentToGroupButtonPopup06( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify that remove button is displayed for corresponding student once it is added in the text field" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String groupName = "SMGroupTest" + System.nanoTime();

            // Navigate to Groups Tab.
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithoutStudent( groupName );

            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();

            // verify the remove button
            SMUtils.logDescriptionTC( "Verify that remove button is displayed for corresponding student once it is added in the text field" + "" );
            String studentUN5 = SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERNAME );
            List<String> studentUserNames = new ArrayList<>();
            studentUserNames.add( studentUN5 );
            groupsTab.addStudGroupWithHomeRoomStudents( groupName, studentUserNames );
            Log.assertThat( groupsTab.isRemoveButtonDisplayed( studentUN5 ), "remove button is enabled", "remove button is disabled" );
            groupsTab.removeSelectedStudent( studentUN5 );
            groupsTab.addStudentTxtBox.clear();
            groupsTab.clickCloseAddStudGroupButtoninPopup();

            // Verify that clicking on remove button should remove the student name from "Search Student or Username" text field
            SMUtils.logDescriptionTC( "Verify that data is erased on reopening \"Add students to Group\" popup" + "" );
            String studentUN4 = SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERNAME );
            studentUserNames.add( studentUN4 );
            groupsTab.addStudGroupWithHomeRoomStudents( groupName, studentUserNames );
            Log.assertThat( groupsTab.removeSelectedStudent( studentUN4 ), "remove student successfully", "remove student not successfully" );
            groupsTab.addStudentTxtBox.clear();
            groupsTab.clickCloseAddStudGroupButtoninPopup();

            // Verify that clicking on close button for corresponding student name "Search Student or Username" text field, should remove the student
            SMUtils.logDescriptionTC( "Verify that clicking on remove button should remove the student name from \"Search Student or Username\" text field\r\n" + "" + "" );
            String studentUN6 = SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERNAME );
            studentUserNames.add( studentUN6 );
            groupsTab.addStudGroupWithHomeRoomStudents( groupName, studentUserNames );
            Log.assertThat( groupsTab.isRemoveButtonDisplayed( studentUN6 ), "removed student is successfully", "removed student is not successfully" );
            groupsTab.addStudentTxtBox.clear();
            groupsTab.clickCloseAddStudGroupButtoninPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43184", "Group", "View Group", "Users", "AddStudentToGroupButton" } )
    public void tcAddStudentToGroupButtonPopup07( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify that the student name search results are accurate on Add Students to Group popup" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String groupName = "SuccessmakerGroup" + System.nanoTime();

            // Navigate to Groups Tab.
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithoutStudent( groupName );
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();

            //searching value via text box
            SMUtils.logDescriptionTC( "Verify that the student name search results are accurate on Add Students to Group popup" + "" + "" );
            String studentUN6 = SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, username ), RBSDataSetupConstants.USERNAME );
            SMUtils.waitForElement( driver, groupsTab.addStudentTxtBox );
            groupsTab.addStudentTxtBox.sendKeys( studentUN6 );
            SMUtils.nap( 2 );
            // String searchValue = groupsTab.addStudentTxtBox.getText();
            String studentList = groupsTab.studentlistingroup.getText().trim();
            Log.message( studentUN6 );
            Log.message( studentList );
            Log.assertThat( studentUN6.equalsIgnoreCase( studentList ), "Searched value matched accuratly", "Searched value not matched accuratly" );
            groupsTab.addStudentTxtBox.clear();

            //searching invalid value via text box
            SMUtils.logDescriptionTC( "Verify that, none of the students are listed on Add Students to Group popup while searching with invalid username or students name\r\n" + "" + "" + "" );
            SMUtils.waitForElement( driver, groupsTab.addStudentTxtBox );
            groupsTab.addStudentTxtBox.sendKeys( "nnnnnnnnn" );
            SMUtils.waitForElement( driver, groupsTab.invalidSearchErrMsg );
            String invalidErrMsg = groupsTab.invalidSearchErrMsg.getText().trim();
            groupsTab.addStudentTxtBox.clear();
            Log.message( invalidErrMsg );
            Log.message( Constants.Groups.INVALID_SEARCH_TXT );
            Log.assertThat( invalidErrMsg.equals( Constants.Groups.INVALID_SEARCH_TXT ), "Searched value matched accuratly", "Searched value not matched accuratly" );

            //student who already part of group
            SMUtils.logDescriptionTC( "Verify that the students who are already part of the group must not be displayed in Add Student to Group\r\n" + "" );
            // String studentUN1 = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,userName" );
            String studentUN10 = SMUtils.getKeyValueFromResponse( studentDetails3, RBSDataSetupConstants.USERNAME );
            List<String> studentUserNames = new ArrayList<>();
            studentUserNames.add( studentUN10 );
            groupsTab.addStudGroupWithHomeRoomStudents( groupName, studentUserNames );
            groupsTab.clickOnAddStudentsBtn();
            groupsTab.clickAddStudentToGroup();
            SMUtils.waitForElement( driver, groupsTab.addStudentTxtBox );
            groupsTab.addStudentTxtBox.sendKeys( studentUN10 );
            String alreadyPartOfGroup = groupsTab.invalidSearchErrMsg.getText().trim();
            groupsTab.addStudentTxtBox.clear();
            Log.message( alreadyPartOfGroup );
            Log.message( Constants.Groups.GET_ERROR_MSG_GRDAENOT_SELECTED );
            Log.assertThat( alreadyPartOfGroup.equals( Constants.Groups.GET_ERROR_MSG_GRDAENOT_SELECTED ), "student who are already part of the group", "student who are already not part of the group" );

            groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.viewGroup( groupName );
            groupsTab.clickAddStudentToGroup();
            //partial search value via text box
            SMUtils.logDescriptionTC( "Verify that the student name search results are accurate on Add Students to Group popup, while searching with partial student or username text\r\n" + "" );
            String studentUN4 = studentOne;
            SMUtils.waitForElement( driver, groupsTab.addStudentTxtBox );
            groupsTab.addStudentTxtBox.sendKeys( studentUN4 );
            Log.message( studentUN4 );
            SMUtils.nap( 2 );
            String partialSearchValue = groupsTab.studentlistingroup.getText().trim();
            Log.message( partialSearchValue );
            Log.assertThat( studentUN4.equals( partialSearchValue ), "Searched value matched accuratly", "Searched value not matched accuratly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43184", "Group", "View Group", "Users", "AddStudentToGroupButton" } )
    public void tcAddStudentToGroupButtonPopup08( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify that \"Add Students to Group\" button is disabled when none of the students are selected in add the students to corresponding group popup" + "" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "groupName" );

            // Navigate to Groups Tab.
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();

            //Verify that "Add Students to Group" button is disabled when none of the students are selected in add the students to corresponding group popup
            SMUtils.logDescriptionTC( "Verify that \"Add Students to Group\" button is disabled when none of the students are selected in add the students to corresponding group popup\r\n" + "" );
            groupsTab.addStudentsBtnIsEnable();

            //Click on add students button
            SMUtils.logDescriptionTC( "Verify that clicking on Add Students button should add the students to corresponding group\r\n" + "" );
            String studentUN4 = studentOne;
            List<String> studentUserNames = new ArrayList<>();
            studentUserNames.add( studentUN4 );
            groupsTab.addStudGroupWithHomeRoomStudents( groupName, studentUserNames );
            groupsTab.clickOnAddStudentsBtn();

            //Click on cancel button
            SMUtils.logDescriptionTC( "Verify that cicking on cancel button should close the \"Add students to Group\" popup" + "" );
            groupsTab.clickOnCancelButtoninAddStudentPopup();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43184", "Group", "View Group", "Users", "AddStudentToGroupButton" } )
    public void tcAddStudentToGroupButtonPopup09( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "Verify that 'Add Students to group' popup opens after navigating to multiple tags and clicking on 'Add Students to group' button\\r\\n" + "<small><b><i>[" + browser + "]</b></i></small>" );

        try {

            //Logging in as teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            String groupName = SMUtils.getKeyValueFromResponse( groupDetails, "groupName" );

            // Navigate to Groups Tab.
            tHomePage.topNavBar.navigateToHomeTab();
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupName );

            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();
            Log.message( "Add students to group button pop up dispalyed properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-43184", "Group", "View Group", "Users", "AddStudentToGroupButton" } )
    public void tcAddStudentToGroupButtonPopup10( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner); 
    	Log.testCaseInfo( "Verify that none of the students are listed when teacher does not contain any students\r\n" + "" + "<small><b><i>[" + browser + "]</b></i></small>" );

        //String newOrgName = "Automation_TeacherwithoutStudent_Org";
        String newTeacherName = "School_Teacheralone" + System.nanoTime();

        try {
            //Creating new teacher in same school .

            HashMap<String, String> userDetails = new HashMap<>();
            userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );

            userDetails.put( RBSDataSetupConstants.USERNAME, newTeacherName );
            userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
            userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, RBSDataSetup.organizationIDs.get( school ) );
            String createUser = new RBSUtils().createUser( userDetails );
            new RBSUtils().resetPassword( userDetails.get( RBSDataSetupConstants.ORGANIZATIONIDS ), RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( createUser, RBSDataSetupConstants.USERID ) );

            //Login as new teacher
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( newTeacherName, password, true );

            // Navigate to Groups Tab.
            tHomePage.topNavBar.navigateToHomeTab();
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithoutStudent( Constants.Groups.EMPTY_GRP );
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( Constants.Groups.EMPTY_GRP );

            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();
            Log.message( "Add students to group button pop up dispalyed properly" );
            SMUtils.waitForElement( driver, groupsTab.invalidSearchErrMsg );
            String zeroStud = groupsTab.invalidSearchErrMsg.getText();
            Log.message( zeroStud );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( enabled = false, priority = 1, groups = { "SMK-43184", "Group", "View Group", "Users", "AddStudentToGroupButton" } )
    public void tcAddStudentToGroupButtonPopup11( ITestContext context ) throws Exception {
        Log.testCaseInfo( "Verify that unassigned students are displayed on Add Students to Group popup when the \"Search all students in your school\" checkbox is checked and 'Not Specified' grade is selected\r\n" + "" + "" + "<small><b><i>[" + browser
                + "]</b></i></small>" );

        //Creating unassignedStudent
        // String unassignedStudentDetails = createUnassignedStudent();
        String groupName = "UnassignedGroupAuto" + System.nanoTime();
        //  String unassignedStudentName = SMUtils.getKeyValueFromResponse( unassignedStudentDetails, "data,userName" );
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
        EventListener eventListner = new EventListener();
        driver.register(eventListner);
        try {
        	LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            //create group with unassigned students
            //   groupsTab.createGroupWithSchoolStudents( groupName, unassignedStudentName, Constants.GroupUIConstants.GROUP_ALLGRADES );

            StudentsPage studentTab = tHomePage.topNavBar.navigateToStudentsTab();

            studentTab.sortByUserID();
            //   studentTab.clickviewStudentByEllipsis( unassignedStudentName );
            Log.assertThat( studentTab.isGroupnamePresent( groupName ), "Newly created group present in student associated group", "Newly created group is not present in student details groups tab" );
            Log.assertThat( !studentTab.isGroupnamePresent( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in student details page." );

            tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( !groupsTab.isGroupExist( Constants.GroupUIConstants.UNASSIGNED_GROUP ), "Unassigned group not present.", "Unassigned group present in group listing page." );

            tHomePage.topNavBar.navigateToStudentsTab();
            studentTab.selectAllStudents();
            studentTab.clickGroupButtoninStudentLisitngPage();
            List<String> groupsListFromPopup = studentTab.getListOfGroupName();
            // String txtlegend = groupsListFromPopup.stream().filter( lbllegend -> lbllegend.trim().equals( Constants.GroupUIConstants.UNASSIGNED_GROUP ) ).findAny().orElse( null );
            //            if ( Objects.isNull( txtlegend ) ) {
            //                Log.pass( "Unassigned group is not displayed in assignment popup." );
            //            } else {
            //                Log.fail( "Unassigned group is displayed in assignment popup." );
            //
            //            }

            // Navigate to Groups Tab.
            tHomePage.topNavBar.navigateToHomeTab();
            GroupPage groupsTabUN = tHomePage.topNavBar.navigateToGroupsTab();
            String groupNameUN = SMUtils.getKeyValueFromResponse( groupDetails, "groupName" );
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
            groupsTab.viewGroup( groupNameUN );

            //Verify usersTab
            groupsTab.clickGroupsSubNav( Constants.USERS );
            SMUtils.waitForElement( driver, groupsTab.userTabHeader );
            Log.assertThat( groupsTab.userTabHeader.getText().equals( Constants.USERS ), "The 'Users' tab is loaded successfully", "The 'Users' tab is not loaded successfully" );

            // Click on the add students to group button
            groupsTab.clickAddStudentToGroup();
            Log.message( "Add students to group button pop up dispalyed properly" );
            SMUtils.waitForElement( driver, groupsTab.addStudentTxtBox );
            //  groupsTab.addStudentTxtBox.sendKeys( unassignedStudentName );
            String studentList = groupsTab.studentlistingroup.getText().trim();
            //    Log.message( unassignedStudentName );
            Log.message( studentList );
            //   Log.assertThat( unassignedStudentName.equals( studentList ), "Searched value matched accuratly", "Searched value not matched accuratly" );
            groupsTab.addStudentTxtBox.clear();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }
}
