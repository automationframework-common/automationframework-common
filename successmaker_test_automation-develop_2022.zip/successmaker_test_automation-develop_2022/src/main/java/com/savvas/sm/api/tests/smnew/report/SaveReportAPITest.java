package com.savvas.sm.api.tests.smnew.report;

import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.smnew.report.model.ReportResponse;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.ReportAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetupProcessor;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;

public class SaveReportAPITest extends EnvProperties {
    String smUrl;
    Map<String, String> response;
    String orgId;
    String username;
    String userId;
    String groupId;
    String browser;
    List<ReportResponse> actualLst = new ArrayList<>();
    List<ReportResponse> lst = new ArrayList<>();
    HashMap<String, String> mathAssignmentDetails = new HashMap<>();
    HashMap<String, String> readingAssignmentDetails = new HashMap<>();
    static List<String> studentId = new ArrayList<>();
    String flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    String flexSchoolTeacherDetails;
    String orgID;
    String userID;
    String studentDetail;
    String studentUserID;
    String studentUsername;
    String teacherUsername;
    String password;
    String courseName;
    String courseId;
    String assignmentID;
    String assignmentUserId;
    boolean lastSessionValue;
    String subject;
    RBSUtils rbsUtils = new RBSUtils();
    Map<String, String> assignmentResponse = new HashMap<>();
    HashMap<String, String> groupdetails = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    private Map<String, String> postResponse;
    HashMap<String, String> headers = new HashMap<>();
    HashMap<String, String> params = new HashMap<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;
    String authorization = "Basic YWRtaW50ZXN0OnRlc3Q=";
   // String invalidauthorization = "Basic YWRtaW50ZXN0OnRlc3Q123=";
    String requestID = "";
    String districtID;
    public String isItMt = "";
    
    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        // Getting Teacher from flex School        
        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        userID = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        // Getting ORGID of Flex school       
        orgID = RBSDataSetup.organizationIDs.get( flexSchool );
        districtID = configProperty.getProperty( "district_ID" );
        // Getting Students from Flex school        
        studentDetail = RBSDataSetup.getMyStudent( flexSchool, SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();

        // Create a custom course for the flex teacher 
        courseName = "CustomSettingCourse" + System.nanoTime();
        courseId = createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, userID, orgID, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );

        String accessToken = new RBSUtils().getAccessToken( teacherUsername, password );

        // Creating Group to add the student to assign assignment
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, userID );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgID );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );
        // Create Assignment and assign to a student HashMap<String, String>
        assignmentDetails = new HashMap<>();
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
        assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
        isItMt = configProperty.getProperty( "isMTExecution" );

    }

    @Test ( dataProvider = "getDataForSaveReportScenarios", groups = { "smoke_test_case", "Smoke getSaveReportTest", "Save Report", "P1", "SMK-58182", "Java API for save report", "API" }, priority = 1 )
    public void getSaveReportTest( String testcaseName, String statusCode, String testcaseDescription, String reporttype, String scenarioType ) throws Exception {

        String request = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "GetSaveReport.json" );
        String postEndPoint = ReportAPIConstants.POST_SAVE_REPORT;

        switch ( scenarioType ) {
            case "VALID_REQUEST_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                Log.message( postResponse.get( Constants.RESPONSE_BODY ).toString() );

                break;
            case "INVALID_AUTHORIZATION":
                String invalidAuthorization = authorization + getRandomNumber();
                headers.put( ReportAPIConstants.AUTHORISATION, invalidAuthorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "INVALID_USER_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                String invalidUserID = userID + getRandomNumber();
                headers.put( ReportAPIConstants.USERID_HEADER, invalidUserID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "EMPTY_USER_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, "" );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "INVALID_ORG_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                String invalidOrgID = orgID + getRandomNumber();
                headers.put( ReportAPIConstants.ORGID_HEADER, invalidOrgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "EMPTY_ORG_ID":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, "" );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "INVALID_REPORT_TYPE":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.INVALID );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "INVALID_PERSON_REPORT":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, ReportAPIConstants.INVALID );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "INVALID_FILTER_NAME":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.STUDENT_ID );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "INVALID_REPORT_PARAMETERS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.PAYLOAD_FILTER_NAME );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "INVALID_USER_TYPE":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.SUBJECT );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "EMPTY_REPORT_TYPE":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID);
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, "" );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "EMPTY_PERSON_REPORT":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, "" );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "EMPTY_FILTER_NAME":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, "" );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "EMPTY_REPORT_PARAMETERS":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID);
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, "" );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "EMPTY_USER_TYPE":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, "" );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "EMPTY_REQUEST_BODY":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = "";
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "EXISTING_FILTER_NAME":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_FILTER_NAME, ReportAPIConstants.SUBJECT );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;
            case "WITHOUT_FILTER_NAME":
                headers.put( ReportAPIConstants.AUTHORISATION, authorization );
                headers.put( ReportAPIConstants.ORGID_HEADER, orgID );
                headers.put( ReportAPIConstants.USERID_HEADER, userID );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( ReportAPIConstants.DISTRITC_ID, districtID.trim() );
                request = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "SaveReportInvalid.json" );
                request = request.replace( ReportAPIConstants.PAYLOAD_REPORT_TYPE, ReportAPIConstants.REPORT_TYPE );
                request = request.replace( ReportAPIConstants.PAYLOAD_SUBJECT, Constants.MATH );
                request = request.replace( ReportAPIConstants.PAYLOAD_PERSON_REPORT, Boolean.TRUE.toString() );
                request = request.replace( ReportAPIConstants.PAYLOAD_USER_TYPE, ReportAPIConstants.TEACHER );
                postResponse = RestHttpClientUtil.POST( smUrl, headers, params, postEndPoint, request );
                break;

        }
        Log.message( postResponse.toString() );
        Log.assertThat( postResponse.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + postResponse.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + postResponse.get( Constants.STATUS_CODE ) + "is not Verified" );
        Log.testCaseResult();
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataForSaveReportScenarios() {
        Object[][] data = { 
                { "TC001", "201", "TC001_Verify status code is 201 when valid test data is given.", "LS", "VALID_REQUEST_ID" },
                { "TC002", "401", "TC002_Verify 401 status code and response body when invalid Authoriztion token", "LS", "INVALID_AUTHORIZATION" },
                { "TC003", "201", "TC003_Verify 201 status code and response body when valid bearer token and user-id is invalid", "LS", "INVALID_USER_ID" },
                { "TC004", "400", "TC004_Verify 400 status code and response body when invalid bearer token and user-id is empty", "LS", "EMPTY_USER_ID" },
                { "TC005", "201", "TC005_Verify 401 status code and response body when invalid bearer token and org-id is invalid", "LS", "INVALID_ORG_ID" },
                { "TC006", "400", "TC006_Verify 400 status code and response body when invalid bearer token and org is empty", "LS", "EMPTY_ORG_ID" },
                { "TC007", "201", "TC007_Verify 201 status code and response body when valid user-id and invalid org-id is given in the headers", "LS", "INVALID_ORG_ID" },
                { "TC008", "201", "TC008_Verify 201 status code in the response when the reportType in the request payload is provided with invalid values", "123", "INVALID_REPORT_TYPE" },
                { "TC009", "201", "TC009_Verify 201 status code in the response when the personReport in the request payload is provided with invalid values", "LS", "INVALID_PERSON_REPORT" },
                { "TC010", "400", "TC010_Verify 400 status code in the response when the filterName in the request payload is provided with invalid values", "LS", "INVALID_FILTER_NAME" },
                { "TC011", "201", "TC011_Verify 400 status code in the response when the reportParameters in the request payload is provided with invalid values", "LS", "INVALID_REPORT_PARAMETERS" },
                { "TC012", "201", "TC012_Verify 400 status code in the response when the userType in the request payload is provided with invalid values", "LS", "INVALID_USER_TYPE" },
                { "TC013", "400", "TC013_Verify 400 status code in the response when the reportType in the request payload is provided with empty value", "LS", "EMPTY_REPORT_TYPE" },
                { "TC014", "201", "TC014_Verify 201 status code in the response when the personReport in the request payload is provided with with empty value", "LS", "EMPTY_PERSON_REPORT" },
                { "TC015", "400", "TC015_Verify 400 status code in the response when the filterName in the request payload is provided with empty value", "LS", "EMPTY_FILTER_NAME" },
                { "TC016", "201", "TC016_Verify 201 status code in the response when the reportParameters in the request payload is provided with empty value", "LS", "EMPTY_REPORT_PARAMETERS" },
                { "TC017", "400", "TC017_Verify 400 status code in the response when the userType in the request payload is provided with empty value", "LS", "EMPTY_USER_TYPE" },
                { "TC018", "400", "TC018_Verify 400 status code in the response when empty request body is provided", "LS", "EMPTY_REQUEST_BODY" },
                { "TC019", "201", "TC019_Verify 201 status code in the response when the filterName in the request payload is provided with already existing filter name values", "LS", "EXISTING_FILTER_NAME" },
                { "TC020", "400", "TC020_Verify 400 status code in the response when the personReport is provided and filterName not provided in the request payload", "LS", "WITHOUT_FILTER_NAME" }

        };

        return data;
    }
    /**
     * To create a custom course
     * 
     * @param smUrl
     * @param token
     * @param subject
     * @param teacherID
     * @param orgID
     * @param courseType
     * @param courseName
     * @param jsonFileName
     * @return
     * @throws Exception
     */
    public String createCustomCourse( String smUrl, String token, String subject, String teacherID, String orgID, String courseType, String courseName, String jsonFileName ) throws Exception {
        HashMap<String, String> response_post = new HashMap<>();
        DataSetupProcessor dataprocess = new DataSetupProcessor();
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( Constants.AUTHORIZATION, "Bearer " + token );
            headers.put( Constants.USERID_SM_HEADER, teacherID );
            headers.put( Constants.ORGID_SM_HEADER, orgID );
            // Input Params
            HashMap<String, String> params = new HashMap<>();

            // EndPoint Details
            String endPoint_post = CourseAPIConstants.POST_STANDARD_COURSE_COPY;
            if ( subject.contentEquals( DataSetupConstants.MATH ) ) {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "1" );
            } else {
                endPoint_post = endPoint_post.replace( Constants.COURSE_ID, "2" );
            }

            endPoint_post = endPoint_post.replace( Constants.ORG_ID, orgID );
            endPoint_post = endPoint_post.replace( Constants.STAFF_ID, teacherID );

            Map<String, String> courseDetails = new HashMap<String, String>();
            courseDetails.put( Constants.COURSE_NAME, courseName );
            String requestBody = null;
            if ( courseType.equalsIgnoreCase( DataSetupConstants.SETTINGS ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.SKILL ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }
            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.STANDARD ) ) {
                List<String> standardDetails = new ArrayList<>();

                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    standardDetails = SqlHelperAssignment.getRandomStandardGradeID( DataSetupConstants.MATH, isItMt.equalsIgnoreCase( "true" ) );
                } else {
                    standardDetails = SqlHelperAssignment.getRandomStandardGradeID( DataSetupConstants.READING, isItMt.equalsIgnoreCase( "true" ) );
                }

                List<String> listLO = SqlHelperAssignment.getLOIDsRandomStandard( standardDetails.get( 0 ), standardDetails.get( 1 ), isItMt.equalsIgnoreCase( "true" ) );
                courseDetails.put( Constants.STANDARDFRAMEWORK_ID, standardDetails.get( 0 ) );
                courseDetails.put( Constants.GRADE_ID, standardDetails.get( 1 ) );
                courseDetails.put( Constants.BANKID, listLO.get( 0 ).split( "_" )[3] ); //To get Bank ID from LO
                courseDetails.put( Constants.LOID, listLO.get( 0 ) );
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                } else {
                    requestBody = dataprocess.generateRequestBody( SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + jsonFileName ), courseDetails );
                }

            } else if ( courseType.equalsIgnoreCase( DataSetupConstants.ONE_LO ) ) {
                if ( subject.equalsIgnoreCase( DataSetupConstants.MATH ) ) {
                    requestBody = dataprocess.generateRequestBody( DataSetupConstants.CUSTOM_BY_SKILL_ONE_LO, courseDetails );
                }
            }
            response_post = RestHttpClientUtil.POST( smUrl, headers, params, endPoint_post, requestBody );
            if ( response_post.get( Constants.STATUS_CODE ).equals( "201" ) ) {
                return SMUtils.getKeyValueFromResponse( response_post.get( Constants.REPORT_BODY ), Constants.REPORT_BODY_DATA + "," + Constants.REPORT_COURSEID );
            } else {
                return response_post.get( Constants.REPORT_BODY );
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }
        return response_post.get( Constants.REPORT_BODY );
    }

    /**
     * This Method will generate headers
     * 
     * @param userreqDetails should contains bearer token, teacher rumbaID & org
     *            ID
     * @return
     */
    public Map<String, String> getHeaders( HashMap<String, String> userreqDetails ) {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userreqDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        headers.put( Constants.USERID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.ORG_ID ) );
        return headers;
    }

    /**
     * To assign an assignment to a user(s) or groups(s)
     * 
     * @param envUrl
     * @param assignmentDetails should contains bearer token, teacher rumbaID,
     *            org ID & course ID
     * @param studentRumbaIds
     * @param type should be users or groups
     * @return
     * @throws Exception
     */
    public HashMap<String, String> assignAssignment( String envUrl, HashMap<String, String> assignmentDetails, List<String> studentRumbaIds, String type ) throws Exception {
        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );

        //Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.CREATE_ASSIGNMENT_API;

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.TEACHER, FileConstants.ASSIGN_ASSIGNMENT_PAYLOAD ) );

        if ( !studentRumbaIds.isEmpty() ) {
            String listString = "";
            for ( String studentID : studentRumbaIds ) {

                listString += studentID.concat( "\",\"" );

            }
            listString = listString.substring( 0, listString.length() - 3 );
            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_IDS ), listString ) );

            requestBody.set( requestBody.get().replace( new RBSUtils().getRequestBodyParameter( AssignmentAPIConstants.STUDENT_RUMBA_GRADE_IDS ), listString ).replace( ",,", "," ) );
        } else {
            Log.fail( "Student / Group ID missing" );
        }

        if ( type.equalsIgnoreCase( AssignmentAPIConstants.USERS_TYPE ) ) {
            requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.USERS_TYPE ) );
        } else if ( type.equalsIgnoreCase( AssignmentAPIConstants.GROUPS_TYPE ) ) {
            requestBody.set( requestBody.get().replace( "{type}", AssignmentAPIConstants.GROUPS_TYPE ) );
        } else {
            Log.fail( "Invalid Type: " + type );
        }

        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID ).replace( "{courseID}", courseID );

        return RestHttpClientUtil.POST( envUrl, headers, params, endPoint, requestBody.get() );

    }

    public String getRandomNumber() {
        Random random = new Random();
        int randomNumber = random.nextInt( 1000 );
        String generatedRandomNumber = Integer.toString( randomNumber );
        return generatedRandomNumber;
    }
}
