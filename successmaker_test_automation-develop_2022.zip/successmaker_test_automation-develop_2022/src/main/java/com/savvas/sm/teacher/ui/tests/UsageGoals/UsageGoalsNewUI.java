package com.savvas.sm.teacher.ui.tests.UsageGoals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.rbs.RBSUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

public class UsageGoalsNewUI extends BaseTest {

    private String smUrl;
    private String browser;
    private String username;
    private String password;
    private HashMap<String, String> userDetails = new HashMap<>();
    private String orgId;

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty( "SMAppUrl" );
        orgId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        // Creating Admin user data to login
        String districtAdmin = "District_Admin" + System.nanoTime();
        userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( ConfigConstants.ADMIN_ID ) );
        userDetails.put( RBSDataSetupConstants.USERNAME, districtAdmin );
        userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.ADMIN_ROLE );
        // Creating District Admin
        userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, orgId );
        String adminDetails = new RBSUtils().createUser( userDetails );
        // Retrieving username and resetting password from the response
        username = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERNAME );
        Log.message( username );
        new RBSUtils().resetPassword( orgId, RBSDataSetupConstants.DEFAULT_PASSWORD, SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID ) );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify Math Usage Goal", groups = { "SMK-51715", "HomePage", "UsageGoal", "UI", "P1" } )
    public void tcUsageGoal01( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SMDashBoardPage usagePage = new SMDashBoardPage( driver );

            // Verify user able to toggle to usage goal button
            Log.assertThat( usagePage.toggleToUsageGoals(), "Successfully Toggled to usage button", "Issue in toggle to usage button" );

            // Validate the Hint Message on the top right corner of the Organization usage section
            Log.assertThat( usagePage.validateNoteText( Constants.UsageGoal.HINT_MESSAGE ), "Hint Message is shown Successfully", "Correct Message Not Thrown" );

            // Validate % of students text for math usage goal
            Log.assertThat( usagePage.validatePercentageTextForAllLegends( Constants.MATH ), "% of students text displayed below of all legends ", "Error in Text" );

            // Validate the Header Text of Progress Bar
            Log.assertThat( usagePage.validateHeaderTextOfProgressBar( Constants.MATH, Constants.UsageGoal.USAGE_GOAL_MATH_HEADER ), "Header Text For Math Progress Bar is Shown as expected", "Header Text is  not shown properly" );

            // Validate Organization Selected Text Bottom of the Page
            String noOfOrganizationSelectedText = usagePage.getNoOfOrganizationSelectedText();
            Log.assertThat( noOfOrganizationSelectedText.contains( Constants.UsageGoal.ORGANIZATION_SELECTED_TEXT ), "Organization Selected text is shown Successfully", "Correct Message Not Thrown" );

            Log.assertThat( usagePage.validateLegendText( Constants.MATH, Constants.UsageGoal.ONTRACK ), "OnTrack Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( usagePage.validateLegendText( Constants.MATH, Constants.UsageGoal.WATCH_CLOSELY ), "Watch Closely Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( usagePage.validateLegendText( Constants.MATH, Constants.UsageGoal.FALLING_BEHIND ), "Falling Behind Text Legend Validated Successfully", "Error in Text" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Reading Usage Goal", groups = { "SMK-51715", "HomePage", "UsageGoal", "UI", "P1" } )
    public void tcUsageGoal02( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SMDashBoardPage usagePage = new SMDashBoardPage( driver );

            usagePage.toggleToUsageGoals();

            // Validate the Header Text of Progress Bar
            Log.assertThat( usagePage.validateHeaderTextOfProgressBar( Constants.READING, Constants.UsageGoal.USAGE_GOAL_READING_HEADER ), "Header Text For Reading Progress Bar is Shown as expected", "Header Text is  not shown properly" );

            // Validate % of students text for Reading usage goal
            Log.assertThat( usagePage.validatePercentageTextForAllLegends( Constants.READING ), "% of students text displayed below of all legends ", "Error in Text" );

            // Validate Organization Selected Text Bottom of the Page
            String noOfOrganizationSelectedText = usagePage.getNoOfOrganizationSelectedText();
            Log.assertThat( noOfOrganizationSelectedText.contains( Constants.UsageGoal.ORGANIZATION_SELECTED_TEXT ), "Organization Selected text is shown Successfully", "Correct Message Not Thrown" );

            Log.assertThat( usagePage.validateLegendText( Constants.READING, Constants.UsageGoal.ONTRACK ), "OnTrack Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( usagePage.validateLegendText( Constants.READING, Constants.UsageGoal.WATCH_CLOSELY ), "Watch Closely Text Legend Validated Successfully", "Error in Text" );

            Log.assertThat( usagePage.validateLegendText( Constants.READING, Constants.UsageGoal.FALLING_BEHIND ), "Falling Behind Text Legend Validated Successfully", "Error in Text" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Percentage of Progress Bar", groups = { "SMK-51715", "HomePage", "UsageGoal", "UI", "P1" } )
    public void tcUsageGoal03( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SMDashBoardPage usagePage = new SMDashBoardPage( driver );

            usagePage.toggleToUsageGoals();

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.verifyPercentageIsBetween0To100( Constants.MATH, Constants.UsageGoal.ONTRACK ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.verifyPercentageIsBetween0To100( Constants.MATH, Constants.UsageGoal.WATCH_CLOSELY ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.verifyPercentageIsBetween0To100( Constants.MATH, Constants.UsageGoal.FALLING_BEHIND ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.verifyPercentageIsBetween0To100( Constants.READING, Constants.UsageGoal.ONTRACK ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.verifyPercentageIsBetween0To100( Constants.READING, Constants.UsageGoal.WATCH_CLOSELY ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.verifyPercentageIsBetween0To100( Constants.READING, Constants.UsageGoal.FALLING_BEHIND ), "Percentage is shown between 0 t0 100 as expected", "Issue in total Percentage" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.validateColourForAllLegends( Constants.MATH, Constants.UsageGoal.ONTRACK, Constants.UsageGoal.HEX_VALUE_ONTRACK ), "Colour is validated for given Legend", "Issue in colour of given legend" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.validateColourForAllLegends( Constants.MATH, Constants.UsageGoal.WATCH_CLOSELY, Constants.UsageGoal.HEX_VALUE_WATCHCLOSELY ), "Colour is validated for given Legend", "Issue in colour of given legend" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.validateColourForAllLegends( Constants.MATH, Constants.UsageGoal.FALLING_BEHIND, Constants.UsageGoal.HEX_VALUE_FALLINGBEHIND ), "Colour is validated for given Legend", "Issue in colour of given legend" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.validateColourForAllLegends( Constants.READING, Constants.UsageGoal.ONTRACK, Constants.UsageGoal.HEX_VALUE_ONTRACK ), "Colour is validated for given Legend", "Issue in colour of given legend" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.validateColourForAllLegends( Constants.READING, Constants.UsageGoal.WATCH_CLOSELY, Constants.UsageGoal.HEX_VALUE_WATCHCLOSELY ), "Colour is validated for given Legend", "Issue in colour of given legend" );

            // Validate the progress bar percentage for legend is between 0 to 100
            Log.assertThat( usagePage.validateColourForAllLegends( Constants.READING, Constants.UsageGoal.FALLING_BEHIND, Constants.UsageGoal.HEX_VALUE_FALLINGBEHIND ), "Colour is validated for given Legend", "Issue in colour of given legend" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify sum of all percentage is 100", groups = { "SMK-51715", "HomePage", "UsageGoal", "UI", "P1" } )
    public void tcUsageGoal04( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	try {
    		AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SMDashBoardPage usagePage = new SMDashBoardPage( driver );

            usagePage.toggleToUsageGoals();

            // Verify the total of % of student is equal to 100 for the Reading Usage Goals
            Log.assertThat( usagePage.verifySumOfAllPercentageIsHundred( Constants.READING ), "SUM of all legend percentage for Reading sub is 100", "Issue in total sum in percentage" );

            // Verify the total of % of student is equal to 100 for the Math Usage Goals
            Log.assertThat( usagePage.verifySumOfAllPercentageIsHundred( Constants.MATH ), "SUM of all legend percentage for Math sub is 100", "Issue in total sum in percentage" );

            // Verify the text colour of Usage Goals
            Log.assertThat( usagePage.validateUsageGoalTextColour(), "Text Colour of usage goal is validated and shown as expected", "Colour not matched" );

            // Verify all the organization is selected matches with text
            Log.assertThat( usagePage.VerifyAllOrganizationSelectedMatchWithText(), "Matched with the No of Organization selected", "Not matched" );

            // scroll to top of the page
            usagePage.scrollIntoTopOfPage();

            // Verify the if no Organization is selected
            Log.assertThat( usagePage.verifyNoOrganizationSelectedOnTheDropDown(), "No of Org selected shows as Zero when no org is selected", "Not shown as expected" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify data changed based on Organization selected", groups = { "SMK-51715", "HomePage", "UsageGoal", "UI", "P1" } )
    public void tcUsageGoal05( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        try {
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );
            SMDashBoardPage usagePage = new SMDashBoardPage( driver );

            // Hard coded value due to static data. Need to replace with dynamic data

            List<String> listOfOrgToSelect = new ArrayList<>();
            listOfOrgToSelect.add( "Test-School-1" );
            listOfOrgToSelect.add( "Test-School-2" );

            // Toggle Usage goal
            usagePage.toggleToUsageGoals();

            // Percentage Details Before changing changes in Oraganization selected
            int percentageDetails = usagePage.getPercentageDetails( Constants.MATH, Constants.UsageGoal.ONTRACK );

            usagePage.clickAllOptionsInOrganizationDropdown();

            usagePage.selectOrganizationsFromOrgDropdown( listOfOrgToSelect );

            // Click Apply filter Button
            usagePage.clickApplySelectionButton();

            // Percentage Details After changing changes in Oraganization selected
            int percentageDetails2 = usagePage.getPercentageDetails( Constants.MATH, Constants.UsageGoal.ONTRACK );

            // Verify the total of % of student is equal to 100 for the Reading Usage Goals
            Log.assertThat( percentageDetails != percentageDetails2, "Changes in data according to the organization selected", "Data not updated after changing organization selected" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
