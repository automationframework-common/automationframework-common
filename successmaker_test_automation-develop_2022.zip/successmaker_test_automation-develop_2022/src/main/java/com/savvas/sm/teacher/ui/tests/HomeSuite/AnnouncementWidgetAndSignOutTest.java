package com.savvas.sm.teacher.ui.tests.HomeSuite;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.teacher.ui.pages.TopNavBar;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class AnnouncementWidgetAndSignOutTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private AtomicReference<String> schoolUsed = new AtomicReference<String>();


    @BeforeClass
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        schoolUsed.set( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );
        String teacherDetails = RBSDataSetup.getMyTeacher( schoolUsed.get() );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        

    }

    @Test ( description = "Verify the Announcement section and screen elements present in Announcement section in Home Page for teacher user", groups = { "SMK-38817", "HomePage", "Announcement Widget" }, priority = 1 )
    public void tcSMAnnouncementCard001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAnnouncementCard001: Verify the Announcement section and screen elements present in Announcement section in Home Page for teacher user. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            TopNavBar topNavBar = tHomePage.topNavBar;
            // Validate announcement widget visible in home page
            Log.assertThat( tHomePage.isAnnouncementWidgetDisplayed(), "Announcement widget is displayed in HomePage", "Announcement widget is not displayed in HomePage" );
            // Validate announcement icon present in topnav bar
            Log.assertThat( topNavBar.isAnnouncementDisplayed(), "Announcement Icon is displayed in TopNavBar", "Announcement Icon is not displayed in TopNavBar" );
            // Validate announcement widget content is displayed
            Log.assertThat( tHomePage.isAnnouncementWidgetContentDisplayed(), "Announcement widget content is displayed in HomePage", "Announcement widget content is not displayed in HomePage" );
            // Validate announcement widget displays view all link
            Log.assertThat( tHomePage.isAnnouncementWidgetViewAllDisplayed(), "Announcement widget ViewAll link  is displayed in HomePage", "Announcement widget ViewAll link is not displayed in HomePage" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Date and Title are present for each of the content present in Announcement section", groups = { "SMK-38817", "HomePage", "Announcement Widget" }, priority = 1 )
    public void tcSMAnnouncementCard002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAnnouncementCard002: Verify the Date and Title are present for each of the content present in Announcement section. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Validate announcement widget date and title values
            Log.assertThat( tHomePage.isAnnouncementWidgetTextContentDisplayed(), "Announcement widget text content is displayed in HomePage", "Announcement widget text content is not displayed in HomePage" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the inside widget announcement content are matching with the respective url or not", groups = { "SMK-38817", "HomePage", "Announcement Widget" }, priority = 1 )
    public void tcSMAnnouncementCard003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAnnouncementCard003: Verify the inside widget announcement content are matching with the respective url or not. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Get the announcement widget text content
            List<String> announcementTextContentFromHomePage = tHomePage.getAnnouncementWidgetTextContent();
            tHomePage.clickViewALLInAnnouncementWidget();
            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();
            // Get SuccessMaker announcement help content
            List<String> announcementTextContentFromHelp = tHomePage.getSuccessmakerAnnouncementExternalSiteTextContent();
            // Compare the announcement widget content with SuccessMaker announcement help content
            Log.assertThat( announcementTextContentFromHomePage.containsAll( announcementTextContentFromHelp ), "SuccessMaker Announcement External site content is matching with HomePage Announcement content",
                    "SuccessMaker Announcement External site content is not matched with HomePage Announcement content" );
            // Skip switch driver to previous window due to Mac Safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                tHomePage = new TeacherHomePage( driver );
                tHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Validate the View All link in Announcement section will navigate to announcement help page", groups = { "SMK-38817", "HomePage", "Announcement Widget" }, priority = 1 )
    public void tcSMAnnouncementCard004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAnnouncementCard004: Validate the View All link in Announcement section will navigate to announcement help page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SuccessMaker Help Announcement page
            tHomePage.clickViewALLInAnnouncementWidget();
            new WebDriverWait( driver,  Duration.ofSeconds(10) ).until( ExpectedConditions.numberOfWindowsToBe( 2 ) );
            String currentWindow = driver.getWindowHandle();
            Set<String> windowHandles = driver.getWindowHandles();
            List<String> windowList = new ArrayList<>( windowHandles );
            driver.switchTo().window( windowList.get( 1 ) );
            driver.manage().window().maximize();
            Log.assertThat( tHomePage.isSuccessmakerAnnouncementHelpPageDisplayed(), "SuccessMaker Announcement Help page is loaded", "SuccessMaker Announcement Help page is not loaded" );
            // Skip switch driver to previous window due to Mac safari limitation
            if ( !browser.toLowerCase().contains( "safari" ) ) {
                driver.close();
                driver.switchTo().window( currentWindow );
                // Signout
                tHomePage = new TeacherHomePage( driver );
                tHomePage.topNavBar.signOutfromSM();
            }

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Teacher logout functionality from SM Application from Headless Chrome for non-integrated site", groups = { "SMK-40161", "HomePage", "Signout" }, priority = 1 )
    public void tcSMHomePageLogout01() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMHomePageLogout01: Verify the Teacher logout functionality from SM Application from Headless Chrome for nonintegrated site. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // SignOut from SM Home page
            tHomePage.topNavBar.signOutfromSM();
            //Checking the Logout URL is displayed after signout
            String LogoutURL = driver.getCurrentUrl();
            Log.assertThat( LogoutURL.contains( Constants.LOGOUT_URL_RESOURCE ), "Logout URL is displayed", "Logout URL is not displayed" );
            Log.message( driver.getCurrentUrl() );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

	//The test case is Invalid and hence skipping this test case
    @Test (enabled = false, description = "Verify the Teacher log out from a session when the same teacher login from another session", groups = { "SMK-40161", "HomePage", "Signout" }, priority = 1 )
    public void tcSMHomePageLogout02() throws Exception {
		// Get driver
		EventFiringWebDriver primaryDriver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		primaryDriver.register(eventListner);
		// Get driver
		EventFiringWebDriver secondaryDriver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		eventListner = new EventListener();
		secondaryDriver.register(eventListner);
		//   final WebDriver primaryDriver = WebDriverFactory.get( browser );
        //	 final WebDriver secondaryDriver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcSMHomePageLogout02: Verify the Teacher log out from a session when the same teacher login from another session. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            // SM Login in browser1
            LoginPage primaryLoginPage = new LoginPage( primaryDriver, smUrl ).get();
            TeacherHomePage primaryTeacherHomePage = primaryLoginPage.loginToSM( username, password, true );
            // SM login in browser2 with same teacher            
            LoginPage secondaryLoginPage = new LoginPage( secondaryDriver, smUrl ).get();
            TeacherHomePage secondaryTeacherHomePage = secondaryLoginPage.loginToSM( username, password, true );
            //Validate browser1 was session timed out by navigating to student tab.            
            SMUtils.clickJS( primaryDriver, primaryTeacherHomePage.topNavBar.getStudentSubMenu() );
            Log.assertThat( primaryTeacherHomePage.isSessionEndPopupDisplayed(), "Session End Popup is displayed", "Session End Popup is not displayed" );
            Log.assertThat( secondaryTeacherHomePage.topNavBar.isHomeTabDisplayed(), "Home Page is displayed", "Home Page is not displayed" );

        } catch ( Exception e ) {
            Log.exception( e, primaryDriver );
        } finally {
            Log.endTestCase();
            primaryDriver.quit();
            secondaryDriver.quit();
        }
    }
	 
}
