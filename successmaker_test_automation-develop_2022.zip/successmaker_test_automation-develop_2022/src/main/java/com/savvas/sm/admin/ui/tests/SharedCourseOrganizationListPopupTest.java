package com.savvas.sm.admin.ui.tests;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.admin.ui.pages.AdminLauncherPage;
import com.savvas.sm.admin.ui.pages.SMDashBoardPage;
import com.savvas.sm.admin.ui.pages.SharedCourseOrganizationPopupPage;
import com.savvas.sm.admin.ui.pages.SharedCoursesListViewPage;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants.Dashboard;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants.SharedCourses;
import com.savvas.sm.common.utils.adminUIConstants.AdminConstants.SharedCourses.SHARED_COURSE_TABLE_HEADER;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;

public class SharedCourseOrganizationListPopupTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String username;
    private String password;

    @BeforeClass
    public void initTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    }

    @Test ( description = "Verify the Edit share list popup", groups = { "SMK-51736", "orgListPopup", "sharedCourseListView" }, priority = 1 )
    public void tcSharedCourseOrgListPopup001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSharedCourseOrgListPopup001: Verify the Edit share list popup <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //navigate to shared course page
            SharedCoursesListViewPage sharedCoursePage = dashBoardPage.navigateToSharedCoursesListPage();

            List<String> courses = sharedCoursePage.getListFromTable( SHARED_COURSE_TABLE_HEADER.COURSE_NAME );
            //click Edit button
            SharedCourseOrganizationPopupPage editPopup = sharedCoursePage.clickEditButton( courses.get( 0 ) );

            SMUtils.logDescriptionTC( "Verify the title of the Edit share list pop up" );
            Log.assertThat( editPopup.getPopupHeaderText().equals( SharedCourses.ORG_LIST_POPUP_HEADER ), "Popup Header - " + SharedCourses.ORG_LIST_POPUP_HEADER + " is displayed properly",
                    "Popup Header - " + SharedCourses.ORG_LIST_POPUP_HEADER + " is not displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the help icon is displayed along with the title of the Edit share list pop up" );
            Log.assertThat( editPopup.isHelpIconPresent(), "Help icon is displayed properly in the Edit share list pop up", "Help icon is not displayed in the Edit share list pop up" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close icon(X) is displayed in the Edit share list pop up" );
            Log.assertThat( editPopup.isCloseIconPresent(), "Close icon is displayed properly in the Edit share list pop up", "Close icon is not displayed properly in the Edit share list pop up" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the close button is clickable in the Edit share list pop up" );
            sharedCoursePage = editPopup.clickCloseIcon();
            Log.assertThat( sharedCoursePage.isEditBtnDisplayed(), "The close button is clickable in the Edit share list pop up", "The close button is not clickable in the Edit share list pop up" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the selected course header is displayed in the Edit share list page." );
            editPopup = sharedCoursePage.clickEditButton( courses.get( 0 ) );
            Log.assertThat( editPopup.getSelectedCourseName().equalsIgnoreCase( courses.get( 0 ) ), "Selected course name is displayed Properly in the Edit share list pop up",
                    "Selected course name is not displayed Properly in the Edit share list pop up" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the search organization search box is displayed in the Edit share list pop up" );
            List<String> orgList = editPopup.getAllListedOrganization();
            editPopup.enterTextInSearchBox( SharedCourses.ORG );
            Log.assertThat( editPopup.getEneteredValueInSearchBox().equalsIgnoreCase( SharedCourses.ORG ), "organization search box is displayed in the Edit share list pop up and user can able to enter the organization name",
                    "organization search box is not displayed in the Edit share list pop up or user cannot able to enter the organization name" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Organizations title is displayed on top of the organizaiton listing in the Edit share list pop up" );
            Log.assertThat( editPopup.getOrganizationLabel().equalsIgnoreCase( SharedCourses.ORGANIZATIONS ), "Organizations title is displayed on top of the organizaiton listing in the Edit share list pop up",
                    "Organizations title is not displayed on top of the organizaiton listing in the Edit share list pop up" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Show Shared only and check box is displayed in the Edit share list pop up" );
            Log.assertThat( editPopup.getShowSharedCourseLabel().contains( SharedCourses.SHOW_SHARED_ONLY ) && editPopup.isShowSharedOnlyCheckboxPresent(), "The Show Shared only and check box is displayed in the Edit share list pop up",
                    "The Show Shared only and check box is not displayed in the Edit share list pop up" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Share All button is displayed in the Edit share list pop up" );
            Log.assertThat( editPopup.isShareAllButtonPresent(), "Share All button is displayed in the Edit share list pop up", "Share All button is not displayed in the Edit share list pop up" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify Cancel button is displayed and enabled in the Edit share list pop up" );
            Log.assertThat( editPopup.getCancelButtonText().equalsIgnoreCase( SharedCourses.CANCEL ), "Cancel button is displayed in the Edit share list pop up", "Cancel button is displayed in the Edit share list pop up" );
            Log.assertThat( editPopup.isCancelButtonEnabled(), "Cancel button is enabled in the Edit share list pop up", "Cancel button is not enabled in the Edit share list pop up" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Save button is displayed and disabled by default." );
            Log.assertThat( editPopup.getSaveButtonText().equalsIgnoreCase( SharedCourses.SAVE ), "Save button is displayed in the Edit share list pop up", "Save button is not displayed in the Edit share list pop up" );
            Log.assertThat( !editPopup.isSaveButtonEnabled(), "Save button is disabled by default in the Edit share list pop up", "Save button is enabled by default in the Edit share list pop up" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Search bar accepts valid organization name to search" );
            editPopup.enterTextInSearchBox( orgList.get( 0 ) );
            List<String> filteredList = editPopup.getAllListedOrganization();
            Log.assertThat( filteredList.stream().allMatch( orgName -> orgName.toLowerCase().contains( orgList.get( 0 ).toLowerCase() ) ), "User able to filter the organizations by using search box",
                    "User cannot able to filter the organizations by using search box" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the search bar accepts invalid organization name to search" );
            editPopup.enterTextInSearchBox( Dashboard.INVALID_ORGNAME );
            Log.assertThat( editPopup.getNoResultFoundErrorMessage().contains( SharedCourses.INVALID_SEARCH_RESULT ), "The search bar accepts the invalid organization name to search", "The search bar not accepts the invalid organization name to search" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the search bar accepts minimum valid characters to search in Edit share list" );
            editPopup.enterTextInSearchBox( orgList.get( 0 ).substring( 0, 2 ) );
            filteredList = editPopup.getAllListedOrganization();
            Log.assertThat( filteredList.stream().allMatch( orgName -> orgName.toLowerCase().contains( orgList.get( 0 ).substring( 0, 2 ).toLowerCase() ) ), "The search bar accepts minimum valid characters to search in Edit share list",
                    "the search bar not accepts minimum valid characters to search in Edit share list" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the search bar accepts special characters to search in Edit share list" );
            editPopup.enterTextInSearchBox( SharedCourses.ALPHA_NUMERIC_SPECIAL_CHAR );
            Log.assertThat( editPopup.getEneteredValueInSearchBox().equalsIgnoreCase( SharedCourses.ALPHA_NUMERIC_SPECIAL_CHAR.trim() ), "The search bar accepts special characters to search in Edit share list",
                    "The search bar not accepts special characters to search in Edit share list" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Cancel button is clickable and navigating to the shared course page" );
            sharedCoursePage = editPopup.clickCancelButton();
            Log.assertThat( sharedCoursePage.isEditBtnDisplayed(), "The cancel button is clickable and navigating to the shared course page", "The cancel button is not clickable" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Edit share list popup", groups = { "SMK-51736", "orgListPopup", "sharedCourseListView" }, priority = 1 )
    public void tcSharedCourseOrgListPopup002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSharedCourseOrgListPopup002: Verify the Edit share list popup <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //navigate to shared course page
            SharedCoursesListViewPage sharedCoursePage = dashBoardPage.navigateToSharedCoursesListPage();

            List<String> courses = sharedCoursePage.getListFromTable( SHARED_COURSE_TABLE_HEADER.COURSE_NAME );
            //click Edit button
            SharedCourseOrganizationPopupPage editPopup = sharedCoursePage.clickEditButton( courses.get( 0 ) );

            SMUtils.logDescriptionTC( "Verify the Share/Unshare button is displayed with all the organizations listed" );
            Log.assertThat( editPopup.isShareOrUnshareButtonDisplayedForAllOrganizations(), "The Share/Unshare button is displayed for all the organizations listed", "The Share/Unshare button is not displayed for all the organizations listed" );
            Log.testCaseResult();

            List<String> orgList = editPopup.getAllListedOrganization();
            SMUtils.logDescriptionTC( "Verify the unselecting of Show Selected only displays all the organizations in the district" );
            SMUtils.logDescriptionTC( "Verify the Show Shared only check box is clicked the listing only shared organizations" );
            SMUtils.logDescriptionTC( "Verify the Show Shared only check box is not clicked the listing all the organizations" );
            List<String> sharedOrganizations = editPopup.getCourseSharedOrganizations();
            editPopup.clickShowSharedOnlyCheckbox();
            Log.assertThat( SMUtils.compareTwoList( sharedOrganizations, editPopup.getAllListedOrganization() ), "Course shared organizations are displayed properly after selecting the show shared only checkbox",
                    "Course shared organizations are not displayed properly after selecting the show shared only checkbox" );
            editPopup.clickShowSharedOnlyCheckbox();
            Log.assertThat( SMUtils.compareTwoList( orgList, editPopup.getAllListedOrganization() ), "All organizations are displayed properly after unselecting the show shared only checkbox",
                    "All organizations are not displayed properly after unselecting the show shared only checkbox" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Unshare All button is displayed with all shared course is shared with all the organizations listed" );
            editPopup.clickShareButtonForGivenOrganizations( orgList );
            editPopup.clickShowSharedOnlyCheckbox();
            Log.assertThat( editPopup.isUnshareAllButtonPresent(), "The Unshare All button is displayed with all shared course is shared with all the organizations listed",
                    "The Unshare All button is not displayed with all shared course is shared with all the organizations listed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Share All button is displayed with the course is shared with no organizations listed" );
            editPopup.clickShowSharedOnlyCheckbox();
            editPopup.clickUnShareButtonForGivenOrganizations( orgList );
            Log.assertThat( editPopup.isShareAllButtonPresent(), "The Share All button is displayed with the course is shared with no organizations listed", "The Share All button is not displayed with the course is shared with no organizations listed" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Share All button is displayed when the search result contains the mixture of shared and unshared organizations name" );
            editPopup.clickShareButtonForGivenOrganizations( Arrays.asList( orgList.get( 0 ) ) );
            Log.assertThat( editPopup.isShareAllButtonPresent(), "The Share All button is displayed when the search result contains the mixture of shared and unshared organizations name",
                    "The Share All button is not displayed when the search result contains the mixture of shared and unshared organizations name" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Show Shared Only Checkbox, shared and unshared button functionality in Edit share list popup", groups = { "SMK-51736", "orgListPopup", "sharedCourseListView" }, priority = 1 )
    public void tcSharedCourseOrgListPopup003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcSharedCourseOrgListPopup003: Verify Show Shared Only Checkbox, shared and unshared button functionality in Edit share list popup. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            //Login into SM using admin credential
            AdminLauncherPage smLoginPage = new AdminLauncherPage( driver, smUrl ).get();
            SMDashBoardPage dashBoardPage = smLoginPage.loginToSM( username, password );

            //navigate to shared course page
            SharedCoursesListViewPage sharedCoursePage = dashBoardPage.navigateToSharedCoursesListPage();

            List<String> courses = sharedCoursePage.getListFromTable( SHARED_COURSE_TABLE_HEADER.COURSE_NAME );
            //click Edit button
            SharedCourseOrganizationPopupPage editPopup = sharedCoursePage.clickEditButton( courses.get( 0 ) );

            SMUtils.logDescriptionTC( "Verify the Share All button is working in the Edit share list" );
            editPopup.clickShareAll();
            Log.assertThat( editPopup.isUnshareAllButtonPresent(), "Share All button is working as excepted", "Share All button is not working as excepted" );
            Log.assertThat( editPopup.getCourseUnsharedOrganizations().isEmpty(), "All courses are shared after clicking Share All button", "All courses are not shared after clicking Share All button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Unshare All button is working in the Edit share list" );
            editPopup.clickUnShareAll();
            Log.assertThat( editPopup.isShareAllButtonPresent(), "Unshare All button is working as excepted", "Unshare All button is not working as excepted" );
            Log.assertThat( editPopup.getCourseSharedOrganizations().isEmpty(), "All courses are Unshare after clicking Unshare All button", "All courses are not Unshare after clicking Unshare All button" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the save button is clickable in the Edit Share list pop up" );
            Log.assertThat( editPopup.isSaveButtonEnabled(), "save button is clickable in the Edit Share list pop up", "save button is not clickable in the Edit Share list pop up" );
            Log.testCaseResult();

            // Getting shared organization from list
            List<String> allOrg = editPopup.getAllListedOrganization();
            List<String> listOfsharedOrg = editPopup.getCourseSharedOrganizations();
            String sharedOrg;
            if ( listOfsharedOrg.isEmpty() ) {
                editPopup.clickShareButtonForGivenOrganizations( Arrays.asList( allOrg.get( 0 ) ) );
                sharedOrg = allOrg.get( 0 );
            } else {
                sharedOrg = listOfsharedOrg.get( 0 );
            }

            SMUtils.logDescriptionTC( "Verify the results of Search Bar after checking the Show shared only displaying the Shared Organizations" );
            editPopup.clickShowSharedOnlyCheckbox();
            editPopup.enterTextInSearchBox( sharedOrg );
            Log.assertThat( editPopup.getAllListedOrganization().equals( editPopup.getCourseSharedOrganizations() ), "The results of Search Bar after checking the Show shared only is displaying the Shared Organizations only",
                    "The results of Search Bar after checking the Show shared only is not displaying the Shared Organizations only" );
            Log.assertThat( editPopup.isUnshareAllButtonPresent(), "Unshare All button is present after checking the Show shared only", "Unshare All button is not present after checking the Show shared only" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the Show Shared only displayes only the shared organizations after the search" );
            editPopup.clickShowSharedOnlyCheckbox();
            editPopup.enterTextInSearchBox( sharedOrg );
            editPopup.clickShowSharedOnlyCheckbox();
            Log.assertThat( editPopup.getAllListedOrganization().equals( editPopup.getCourseSharedOrganizations() ), "The results of Search Bar after checking the Show shared only is displaying the Shared Organizations only",
                    "The results of Search Bar after checking the Show shared only is not displaying the Shared Organizations only" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify the results of Search Bar after checking the Show shared only displaying the No result found for unshared organizations" );
            editPopup.enterTextInSearchBox( sharedOrg + System.nanoTime() );
            Log.assertThat( editPopup.getNoResultFoundErrorMessage().equals( SharedCourses.NO_SHARED_ORGANIZATIONS ), "No result found message is displayed", "No result found message is not displayed" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
