package com.savvas.sm.api.tests.smnew.homePage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.homepage.HomePage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sql.helper.FixupFunction;

public class UsageGoalAPITest extends EnvProperties {
    private String browser;
    private String  flexSchool = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );   
    private String  mathSchool = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String readingSchool = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    private String smUrl;
    private String flexSchoolTeacherDetails;
    private String orgID;
    private String userID;
    private String studentDetail;
    private String studentUserID;
    private String studentUsername;
    private String teacherUsername;
    private String password;
    private String mathSchoolTeacherDetails;
    private String readingSchoolTeacherDetails;
    HashMap<String, String> assignmentDetails = new HashMap<>();
    HashMap<String, String> groupdetails = new HashMap<>();
    HashMap<String, String> response = new HashMap<>();
    HashMap<String, String> assignmentIdResponse = new HashMap<>();
    Map<String, String> assignmentResponse = new HashMap<>();
    private String mathSchoolTeacherUserID;
    private String mathSchoolTeacherUsername;
    private String mathSchoolOrgID;
    private String mathSchoolStudentDetail;
    private String mathSchoolStudentUserID;
    private String mathSchoolAccessToken;
    private String readingSchoolTeacherUserID;
    private String readingSchoolTeacherUsername;
    private String readingSchoolOrgID;
    private String readingSchoolStudentDetail;
    private String readingSchoolStudentUserID;
    private String readingSchoolAccessToken;
    private Boolean usageGoalBodyValidation;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        flexSchoolTeacherDetails = RBSDataSetup.getMyTeacher( flexSchool );
        mathSchoolTeacherDetails = RBSDataSetup.getMyTeacher( mathSchool );
        readingSchoolTeacherDetails = RBSDataSetup.getMyTeacher( readingSchool );

        userID = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERID );
        teacherUsername = SMUtils.getKeyValueFromResponse( flexSchoolTeacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        // Getting ORGID of Flex school
        orgID = RBSDataSetup.organizationIDs.get( flexSchool );

        // Getting Students from Flex school
        studentDetail = RBSDataSetup.getMyStudent( flexSchool, teacherUsername );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );

        mathSchoolTeacherUserID = SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, RBSDataSetupConstants.USERID );
        mathSchoolTeacherUsername = SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, RBSDataSetupConstants.USERNAME );
        // Getting ORGID of Flex school
        mathSchoolOrgID = RBSDataSetup.organizationIDs.get( mathSchool );
        // Getting Students from Flex school
        mathSchoolStudentDetail = RBSDataSetup.getMyStudent( mathSchool, mathSchoolTeacherUsername );
        mathSchoolStudentUserID = SMUtils.getKeyValueFromResponse( mathSchoolStudentDetail, Constants.USERID_HEADER );
        String mathSchoolStudentUsername = SMUtils.getKeyValueFromResponse( mathSchoolStudentDetail, RBSDataSetupConstants.USERNAME );

        mathSchoolAccessToken = new RBSUtils().getAccessToken( mathSchoolTeacherUsername, password );
        // Creating Group to add the student to assign assignment
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, mathSchoolAccessToken );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, mathSchoolTeacherUserID );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, mathSchoolOrgID );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( mathSchoolStudentUserID ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, mathSchoolOrgID );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, mathSchoolTeacherUserID );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, mathSchoolAccessToken );
        assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( mathSchoolStudentUserID ), AssignmentAPIConstants.USERS_TYPE );

        executeCourse( mathSchoolStudentUsername, Constants.MATH, true );

        FixupFunction.executeFixupFunctions( mathSchoolOrgID );

        readingSchoolTeacherUserID = SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, RBSDataSetupConstants.USERID );
        readingSchoolTeacherUsername = SMUtils.getKeyValueFromResponse( readingSchoolTeacherDetails, RBSDataSetupConstants.USERNAME );
        // Getting ORGID of Flex school
        readingSchoolOrgID = RBSDataSetup.organizationIDs.get( readingSchool );
        // Getting Students from Flex school
        readingSchoolStudentDetail = RBSDataSetup.getMyStudent( readingSchool, readingSchoolTeacherUsername );
        readingSchoolStudentUserID = SMUtils.getKeyValueFromResponse( readingSchoolStudentDetail, Constants.USERID_HEADER );
        String readingSchoolStudentUsername = SMUtils.getKeyValueFromResponse( readingSchoolStudentDetail, RBSDataSetupConstants.USERNAME );
        readingSchoolAccessToken = new RBSUtils().getAccessToken( readingSchoolTeacherUsername, password );

        // Creating Group to add the student to assign assignment
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, readingSchoolAccessToken );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, readingSchoolTeacherUserID );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, readingSchoolOrgID );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( readingSchoolStudentUserID ) );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, readingSchoolOrgID );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, readingSchoolTeacherUserID );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, readingSchoolAccessToken );
        assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( readingSchoolStudentUserID ), AssignmentAPIConstants.USERS_TYPE );

        executeCourse( readingSchoolStudentUsername, Constants.READING, false );

//        FixupFunction.executeFixupFunctions( readingSchoolOrgID );

    }

    @Test ( dataProvider = "mathPositiveData", priority = 1, groups = { "smoke_test_case", "SMK-51805", "Dashboard", "UsageGoal", "API" } )
    public void getUsageGoal_Positive_Math( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseID + " - " + testDescription );
        String accessToken = new RBSUtils().getAccessToken( teacherUsername, password );
        // Creating Group to add the student to assign assignment
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, userID );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgID );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );
        HomePage usageGoalAPI = new HomePage();
        switch ( scenario ) {

            case "Positive with correct credentials":
                response = usageGoalAPI.getUsageGoalAPI( smUrl, accessToken, orgID, userID );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( "Usage Goals Data Not Found" ), "Message Verified successfully!", "Issue in displaying Message! Expected - " );
                break;
            case "Positive when student has not attended any course":
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgID );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, userID );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                assignmentResponse = new AssignmentAPI().assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
                response = usageGoalAPI.getUsageGoalAPI( smUrl, accessToken, orgID, userID );
                assignmentIdResponse = getassignmentIDS( smUrl, accessToken, orgID, userID, "1" );
                usageGoalBodyValidation = usageGoalValidation( response, assignmentIdResponse, "math" );
                Log.assertThat( usageGoalBodyValidation, "Usage goal data validation is displaying successfully", "Usage goal data validation not displaying properly" );
                //Schema Validation
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "UsageGoalAPIMath", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                break;
            case "Positive when teacher not having any assignments":
                response = usageGoalAPI.getUsageGoalAPI( smUrl, accessToken, orgID, userID );
                Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( "Usage Goals Data Not Found" ), "Message Verified successfully!", "Issue in displaying Message! Expected - " );
                break;
            case "Positive when teacher have only Math assignment":
                response = usageGoalAPI.getUsageGoalAPI( smUrl, mathSchoolAccessToken, mathSchoolOrgID, mathSchoolTeacherUserID );
                assignmentIdResponse = getassignmentIDS( smUrl, mathSchoolAccessToken, mathSchoolOrgID, mathSchoolTeacherUserID, "1" );
                usageGoalBodyValidation = usageGoalValidation( response, assignmentIdResponse, "math" );
                Log.assertThat( usageGoalBodyValidation, "Usage goal data validation is displaying successfully", "Usage goal data validation not displaying properly" );
                Log.message( response.get( "body" ) );
                //Schema Validation
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "UsageGoalAPIMath", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                break;
           
            case "Positive when student is associated with multiple groups of same teacher":

                groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, mathSchoolAccessToken );
                groupdetails.put( GroupConstants.GROUP_OWNER_ID, mathSchoolTeacherUserID );
                groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, mathSchoolOrgID );
                groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
                new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( mathSchoolStudentUserID ) );

                groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
                new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( mathSchoolStudentUserID ) );

                response = usageGoalAPI.getUsageGoalAPI( smUrl, mathSchoolAccessToken, mathSchoolOrgID, mathSchoolTeacherUserID );
                assignmentIdResponse = getassignmentIDS( smUrl, mathSchoolAccessToken, mathSchoolOrgID, mathSchoolTeacherUserID, "1" );
                usageGoalBodyValidation = usageGoalValidation( response, assignmentIdResponse, "math" );
                Log.assertThat( usageGoalBodyValidation, "Usage goal data validation is displaying successfully", "Usage goal data validation not displaying properly" );
                Log.message( response.get( "body" ) );

                Log.assertThat( new SMAPIProcessor().isSchemaValid( "UsageGoalAPIMath", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                break;

            case "Positive when student is associated with multiple groups of multiple teacher":
                // Creating Group to add the student to assign assignment
                groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, mathSchoolAccessToken );
                groupdetails.put( GroupConstants.GROUP_OWNER_ID, mathSchoolTeacherUserID );
                groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, mathSchoolOrgID );
                groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
                new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( mathSchoolStudentUserID ) );
                groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
                groupdetails.put( GroupConstants.GROUP_OWNER_ID, userID );
                groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgID );
                groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
                new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( mathSchoolStudentUserID ) );

                response = usageGoalAPI.getUsageGoalAPI( smUrl, mathSchoolAccessToken, mathSchoolOrgID, mathSchoolTeacherUserID );
                assignmentIdResponse = getassignmentIDS( smUrl, mathSchoolAccessToken, mathSchoolOrgID, mathSchoolTeacherUserID, "1" );
                usageGoalBodyValidation = usageGoalValidation( response, assignmentIdResponse, "math" );
                Log.assertThat( usageGoalBodyValidation, "Usage goal data validation is displaying successfully", "Usage goal data validation not displaying properly" );
                Log.message( response.get( "body" ) );

                Log.assertThat( new SMAPIProcessor().isSchemaValid( "UsageGoalAPIMath", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                break;
            case "Positive when multiple teacher having same group":
                String mathSchoolTeacherUserID3 = SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, RBSDataSetupConstants.USERID );
                String mathSchoolTeacherUsername3 = SMUtils.getKeyValueFromResponse( mathSchoolTeacherDetails, RBSDataSetupConstants.USERNAME );
                mathSchoolOrgID = RBSDataSetup.organizationIDs.get( mathSchool );

                //Creating the teacher in the Same school
                String coTeacherUsername = "SchTeacher" + System.nanoTime();
                List<String> schools = new ArrayList<>();
                schools.add( mathSchoolOrgID );
                String coTeacherDetails = new UserAPI().createUserWithCustomization( coTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, schools );
                String coTeacherID = SMUtils.getKeyValueFromResponse( coTeacherDetails, RBSDataSetupConstants.USERID );
                // Getting Students from Flex school
                String mathSchoolAccessToken3 = new RBSUtils().getAccessToken( mathSchoolTeacherUsername3, password );

                String sharedGroup = "Shared Group" + System.nanoTime();

                //creating Shared group
                new RBSUtils().createClassWithMultipleTeacher( sharedGroup, Arrays.asList( mathSchoolTeacherUserID3, coTeacherID ),
                        Arrays.asList( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( mathSchool ).get( "Student2" ), "userId" ) ), RBSDataSetup.organizationIDs.get( mathSchool ), mathSchoolAccessToken3 );

                response = usageGoalAPI.getUsageGoalAPI( smUrl, mathSchoolAccessToken3, mathSchoolOrgID, mathSchoolTeacherUserID3 );
                assignmentIdResponse = getassignmentIDS( smUrl, mathSchoolAccessToken3, mathSchoolOrgID, mathSchoolTeacherUserID3, "1" );
                usageGoalBodyValidation = usageGoalValidation( response, assignmentIdResponse, "math" );
                Log.assertThat( usageGoalBodyValidation, "Usage goal data validation is displaying successfully", "Usage goal data validation not displaying properly" );
                Log.message( response.get( "body" ) );

                Log.assertThat( new SMAPIProcessor().isSchemaValid( "UsageGoalAPIMath", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );
                break;
        }
        Log.message( "Response: " + response );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );

    }

    @Test (enabled =false, dataProvider = "readingPositiveData", priority = 1, groups = { "smoke_test_case", "SMK-51805", "Dashboard", "UsageGoal", "API" } )
    public void getUsageGoal_Positive_Reading( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseID + " - " + testDescription );
        String accessToken = new RBSUtils().getAccessToken( teacherUsername, password );
        // Creating Group to add the student to assign assignment
        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, accessToken );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, userID );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgID );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );
        HomePage usageGoalAPI = new HomePage();
        switch ( scenario ) {
            case "Positive when teacher have only Reading assignment":
                response = usageGoalAPI.getUsageGoalAPI( smUrl, readingSchoolAccessToken, readingSchoolOrgID, readingSchoolTeacherUserID );
                assignmentIdResponse = getassignmentIDS( smUrl, readingSchoolAccessToken, readingSchoolOrgID, readingSchoolTeacherUserID, "2" );
                usageGoalBodyValidation = usageGoalValidation( response, assignmentIdResponse, "reading" );
                Log.assertThat( usageGoalBodyValidation, "Usage goal data validation is displaying successfully", "Usage goal data validation not displaying properly" );
                //Schema Validation
                Log.assertThat( new SMAPIProcessor().isSchemaValid( "UsageGoalAPIReading", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

                break;
        }
    }

    @Test ( dataProvider = "negativeData", priority = 1, groups = { "SMK-51805", "Dashboard", "UsageGoal", "API" } )
    public void getUsageGoal_Negative( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseID + " - " + testDescription );
        String accessToken = new RBSUtils().getAccessToken( teacherUsername, password );
        HomePage usageGoalAPI = new HomePage();

        switch ( scenario ) {
            case "Negative with invalid bearer token":
                response = usageGoalAPI.getUsageGoalAPI( smUrl, accessToken + "invalid", orgID, userID );
                break;
            case "Negative with invalid UserID":
                response = usageGoalAPI.getUsageGoalAPI( smUrl, accessToken, orgID, userID + "invalid" );
                break;
            case "Negative with invalid OrgID":
                response = usageGoalAPI.getUsageGoalAPI( smUrl, accessToken, orgID + "invalid", userID );
                break;
            case "Negative with userID as districtID":
                response = usageGoalAPI.getUsageGoalAPI( smUrl, accessToken, orgID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN ), RBSDataSetupConstants.USERID ) );
                break;
            case "Negative with orgID as districtID":
                response = usageGoalAPI.getUsageGoalAPI( smUrl, accessToken, configProperty.getProperty( "district_ID" ), userID );
                break;
            case "Negative with userID as school admin":
                response = usageGoalAPI.getUsageGoalAPI( smUrl, accessToken, orgID, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN ), RBSDataSetupConstants.USERID ) );
                break;
            case "Negative with orgID as school admin":
                response = usageGoalAPI.getUsageGoalAPI( smUrl, accessToken, SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN ), RBSDataSetupConstants.USERID ), userID );
                break;
        }
        Log.message( "Response: " + response );
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );

    }

    @DataProvider ( name = "mathPositiveData" )
    public Object[][] getMathDataforPostive() {
        Object[][] data = { { "tcUsageGoal001", "Verify status code 200 should display when correct credential is given for Usage goals.", "200", "Positive with correct credentials" },
                { "tcUsageGoal002", "Verify status code 200 should display when Teacher does not have any assignments.", "200", "Positive when teacher not having any assignments" },
                { "tcUsageGoal003", "Verify status code 200 should display when student has not attended any course.", "200", "Positive when student has not attended any course" },
                { "tcUsageGoal004", "Verify status code 200 , If teacher  have only Math assignments", "200", "Positive when teacher have only Math assignment" },
                { "tcUsageGoal005", "Verify usage data in response if the student is associated with two different groups of same teacher ", "200", "Positive when student is associated with multiple groups of same teacher" },
                { "tcUsageGoal006", "Verify usage data in response if the student is associated with two different groups of two different teacher ", "200", "Positive when student is associated with multiple groups of multiple teacher" },
                { "tcUsageGoal007", "Verify usage data in response if the two teachers are the owner for single group", "200", "Positive when multiple teacher having same group" } };
        return data;
    }

    @DataProvider ( name = "ReadingPositiveData" )
    public Object[][] getReadingDataforPostive() {
        Object[][] data = { { "tcUsageGoal008", "Verify status code 200 , If teacher have only Reading assignments", "200", "Positive when teacher have only Reading assignment" }, };
        return data;
    }

    @DataProvider ( name = "negativeData" )
    public Object[][] getDataforNegative() {
        Object[][] data = { { "tcUsageGoal009", "Verify status code 401 when invalid bearer token is passed in header parameter", "401", "Negative with invalid bearer token" },
                { "tcUsageGoal0010", "Verify status code 401 when User ID is invalid is in headers", "401", "Negative with invalid UserID" },
                { "tcUsageGoal0011", "Verify status code 403 when Org ID is invalid is in headers", "403", "Negative with invalid OrgID" },
                { "tcUsageGoal0012", "Verify status code 401 when User ID is District admin rumba id in headers", "401", "Negative with userID as districtID" },
                { "tcUsageGoal0013", "Verify status code 403 when org ID is District admin rumba id in headers", "403", "Negative with orgID as districtID" },
                { "tcUsageGoal0014", "Verify status code 401 when User ID is school admin rumba id in headers", "401", "Negative with userID as school admin" },
                { "tcUsageGoal0015", "Verify status code 403 when org ID is school admin rumba id in headers", "403", "Negative with orgID as school admin" } };
        return data;
    }

    /**
     * @param usageGoal
     * @param assignmentUserId
     * @param subject
     * @return
     */
    public boolean usageGoalValidation( HashMap<String, String> usageGoal, HashMap<String, String> assignmentUserId, String subject ) {
        try {

            String keyValueFromResponse = SMUtils.getKeyValueFromResponse( usageGoal.get( "body" ), "data" );
            String math = SMUtils.getKeyValueFromResponse( keyValueFromResponse, subject );
            String mathAssignedAssignmentUserIds = SMUtils.getKeyValueFromResponse( math, "assignedAssignmentUserIds" );

            mathAssignedAssignmentUserIds = mathAssignedAssignmentUserIds.replace( "[", "" ).replace( "]", "" );
            List<String> mathReadingAssignmentUserIds = new ArrayList<>( Arrays.asList( mathAssignedAssignmentUserIds.split( "," ) ) );
            Log.message( mathReadingAssignmentUserIds.size() + "" );

            String eligibleAssignmentUserIds = SMUtils.getKeyValueFromResponse( math, "eligibleAssignmentUserIds" );
            eligibleAssignmentUserIds = eligibleAssignmentUserIds.replace( "[", "" ).replace( "]", "" );
            List<String> eligibleAssignmentIds = new ArrayList<>();
            if ( !eligibleAssignmentUserIds.isEmpty() ) {

                eligibleAssignmentIds = Arrays.asList( eligibleAssignmentUserIds.split( "," ) );
                Log.message( eligibleAssignmentIds.size() + "" );
            }

            String totalIneligibleStudents = SMUtils.getKeyValueFromResponse( math, "totalIneligibleStudents" );
            String totalEligibleStudents = SMUtils.getKeyValueFromResponse( math, "totalEligibleStudents" );
            String totalStudentsOnTrack = SMUtils.getKeyValueFromResponse( math, "totalStudentsOnTrack" );
            String totalStudentsOnTrackPercentage = SMUtils.getKeyValueFromResponse( math, "totalStudentsOnTrackPercentage" );
            String totalStudentsToWatchClosely = SMUtils.getKeyValueFromResponse( math, "totalStudentsToWatchClosely" );
            String totalStudentsToWatchCloselyPercentage = SMUtils.getKeyValueFromResponse( math, "totalStudentsToWatchCloselyPercentage" );
            String totalStudentsFallingBehind = SMUtils.getKeyValueFromResponse( math, "totalStudentsFallingBehind" );
            String totalStudentsFallingBehindPercentage = SMUtils.getKeyValueFromResponse( math, "totalStudentsFallingBehindPercentage" );
            int onTrackPercentage = 0;
            int watchCloselyPercentage = 0;
            int fallingBehindPercentage = 0;

            List<String> query = getstudusagedetails( eligibleAssignmentUserIds );
            for ( int i = 0; i < query.size(); i++ ) {

                if ( Integer.parseInt( query.get( i ) ) <= 0 ) {
                    onTrackPercentage = onTrackPercentage + 1;

                } else if ( Integer.parseInt( query.get( i ) ) > 0 ) {
                    if ( Integer.parseInt( query.get( i ) ) <= 3 ) {
                        watchCloselyPercentage = watchCloselyPercentage + 1;

                    } else {
                        fallingBehindPercentage = fallingBehindPercentage + 1;

                    }

                }

            }
            Log.assertThat( totalStudentsOnTrack.equals( String.valueOf( onTrackPercentage ) ), "Total student On Track is displaying as expected", "Total student On Track not displaying properly" );
            onTrackPercentage = Math.round( ( Float.valueOf( onTrackPercentage ) / Float.valueOf( eligibleAssignmentIds.size() ) * 100 ) );
            Log.assertThat( totalStudentsOnTrackPercentage.equals( String.valueOf( onTrackPercentage ) ), "Total student On Track percentage is displaying as expected", "Total student On track percentage not displaying properly" );

            Log.assertThat( totalStudentsToWatchClosely.equals( String.valueOf( watchCloselyPercentage ) ), "Total student Watch Closely is displaying as expected", "Total student Watch Closely not displaying properly" );
            watchCloselyPercentage = Math.round( ( Float.valueOf( watchCloselyPercentage ) / Float.valueOf( eligibleAssignmentIds.size() ) * 100 ) );
            Log.assertThat( totalStudentsToWatchCloselyPercentage.equals( String.valueOf( watchCloselyPercentage ) ), "Total student Watch Closely Percentage is displaying as expected", "Total student Watch Closely Percentage not displaying properly" );

            Log.assertThat( totalStudentsFallingBehind.equals( String.valueOf( fallingBehindPercentage ) ), "Total students Falling Behind is displaying as expected", "Total students Falling Behind not displaying properly" );
            fallingBehindPercentage = Math.round( ( Float.valueOf( fallingBehindPercentage ) / Float.valueOf( eligibleAssignmentIds.size() ) * 100 ) );
            Log.assertThat( totalStudentsFallingBehindPercentage.equals( String.valueOf( fallingBehindPercentage ) ), "Total students Falling Behind Percentage is displaying as expected",
                    "Total students Falling Behind Percentage not displaying properly" );

            String assignmentUserIdKeyValueFromResponse = SMUtils.getKeyValueFromResponse( assignmentUserId.get( "body" ), "data" );
            JSONArray ja = new JSONArray( assignmentUserIdKeyValueFromResponse );
            List<String> assignmentID = new ArrayList<>();
            for ( int i = 0; i < ja.length(); i++ ) {
                assignmentID.add( ja.getJSONObject( i ).get( "studentAssignmentId" ).toString() );
            }
            Log.assertThat( mathReadingAssignmentUserIds.containsAll( assignmentID ), "Assigned assignment user Ids is displaying as expected", "Assigned assignment user Ids not displaying properly" );
            Log.assertThat( totalIneligibleStudents.equals( String.valueOf( mathReadingAssignmentUserIds.size() - eligibleAssignmentIds.size() ) ), "Total ineligible students is displaying as expected",
                    "Total ineligible students not displaying properly" );
            Log.assertThat( totalEligibleStudents.equals( String.valueOf( eligibleAssignmentIds.size() ) ), "Total eligible students is displaying as expected", "Total eligible students not displaying properly" );
            return true;
        } catch ( Exception e ) {
            return false;
        }
    }

    /**
     * @param assignmentUserId
     * @return
     * @throws IOException
     */
    public static List<String> getstudusagedetails( String assignmentUserId ) throws IOException {
        List<String> details = new ArrayList<String>();
        String query = SMUtils.convertFileToString( SMUtils.getQueryDirPath() + "getUsageGoal.sql" );
        query = query.replace( "<assignment_user_id>", assignmentUserId );

        List<Object[]> result = SQLUtil.executeQuery( query );
        for ( Object[] list : result ) {
            if ( list.length > 0 ) {
                details.add( list[0].toString() );
            }
        }
        Log.message( details.toString() );
        return details;
    }

    /**
     * @param smUrl
     * @param token
     * @param orgId
     * @param userId
     * @param subjectId
     * @return
     * @throws Exception
     */
    public HashMap<String, String> getassignmentIDS( String smUrl, String token, String orgId, String userId, String subjectId ) throws Exception {
        String endPoint = "/lms/web/api/v1/organizations/{ordID}/staffs/{stafID}/courseassignments/{courseID}/students";
        endPoint = endPoint.replace( "{ordID}", orgId ).replace( "{stafID}", userId ).replace( "{courseID}", "1" );
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.USERID_SM_HEADER, userId );
        return RestHttpClientUtil.GET( smUrl, endPoint, headers, new HashMap<>() );
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "10" );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "1", "3" );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        }
    }

}
