package com.savvas.sm.teacher.ui.tests.GroupSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

public class SearchStudent extends BaseTest {

    private String smUrl;
    private String browser;

    public String username;
    private String password;
    private String schoolID;
    private String lName;
    private String fName;
    private String teacherID;
    private String studentID1;
    private String studentID2;
    private String stuUserName1;
    private String stuUserName2;
    private String stuFName1;
    private String stuFName2;
    private String personID1;
    public List<String> stuDetails = new ArrayList<>();
    public HashMap<String, String> stuDetailsMap = new HashMap<>();
    String teacherDetails;
    String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );

        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        IntStream.range( 0, Integer.parseInt( configProperty.getProperty( ConfigConstants.STUDENT_COUNT ) ) ).forEach( count -> {
            String studentDetails = RBSDataSetup.getMyStudent( school, username );
            stuDetails.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ) );
            stuUserName1 = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
            stuDetailsMap.put( "Student" + count + "", stuUserName1 );
        } );

    }

    @Test ( description = " Verify whether the teacher is able to create the group with two,three and nine students", groups = { "SMK-43590", "Groups", "SearchStudent" }, priority = 1 )
    public void tcSearchStudent001( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        SMUtils.logDescriptionTC( "SMK-10854 : Verify whether the teacher is able to create the group with two student by adding a single student and typing in the field for another one" );
        SMUtils.logDescriptionTC( "SMK-10855 : Verify whether the teacher is able to create the group with three students by adding a two student and typing in the field for another one" );
        SMUtils.logDescriptionTC( "SMK-10856 : Verify whether the teacher is able to create the group with nine students by adding all eight student and typing in the field for the last one" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Groups tab 
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();

            // Case 1
            groupsPage.clickCreateNewGroupBtn();

            String groupName = "SM Auto Group " + System.nanoTime();
            groupsPage.enterGroupNameinPopup( groupName );

            IntStream.rangeClosed( 1, 2 ).forEach( count -> {
                groupsPage.addNameInTextField( stuDetailsMap.get( "Student" + count ) );
                groupsPage.clickAddButton();
            } );

            groupsPage.clickCreateButton();

            int totalStudentCount = Integer.parseInt( groupsPage.getStudentsCount( groupName ) );

            // Validation
            Log.assertThat( totalStudentCount == 2, "Group created as expected successfully", "Not created as expected" );

            // Case 2
            groupName = "SM Auto Group " + System.nanoTime();
            groupsPage.clickCreateNewGroupBtn();
            groupsPage.enterGroupNameinPopup( groupName );

            IntStream.rangeClosed( 1, 3 ).forEach( count -> {
                groupsPage.addNameInTextField( stuDetailsMap.get( "Student" + count ) );
                groupsPage.clickAddButton();
            } );
            groupsPage.clickCreateButton();

            totalStudentCount = Integer.parseInt( groupsPage.getStudentsCount( groupName ) );
            // Validation
            Log.assertThat( totalStudentCount == 3, "Group created as expected successfully", "Not created as expected" );

            // Case 3
            groupName = "SM Auto Group " + System.nanoTime();
            groupsPage.clickCreateNewGroupBtn();
            groupsPage.enterGroupNameinPopup( groupName );
            IntStream.rangeClosed( 1, 9 ).forEach( count -> {
                try {
                    groupsPage.addNameInTextField( stuDetailsMap.get( "Student" + count ) );
                    SMUtils.waitForSpinnertoDisapper( driver );
                    groupsPage.clickAddButton();
                } catch ( InterruptedException e ) {
                    e.printStackTrace();
                }
            } );
            groupsPage.clickCreateButton();

            totalStudentCount = Integer.parseInt( groupsPage.getStudentsCount( groupName ) );
            // Validation
            Log.assertThat( totalStudentCount == 9, "Group created as expected successfully", "Not created as expected" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();

        }
    }

    @Test ( description = "Verify whether the teacher is able to create group containing students within the school as well and typing in the field for another one", groups = { "SMK-43590", "Groups", "SearchStudent" }, priority = 1 )
    public void tcSearchStudent002( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-10857 : Verify whether the teacher is able to create group containing students within the school as well and typing in the field for another one" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Groups tab 
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();

            // Click Create New Group Button
            String groupName = "SM Auto Group " + System.nanoTime();
            groupsPage.clickCreateNewGroupBtn();
            groupsPage.enterGroupNameinPopup( groupName );
            for ( int count = 1; count <= 4; count++ ) {
                groupsPage.addNameInTextField( stuDetailsMap.get( "Student" + count ) );
                groupsPage.clickAddButton();
            }
            groupsPage.SelectAllGradesFromDropDown( "All Grades" );
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student5" ) );
            groupsPage.clickAddButton();
            groupsPage.clickCreateButton();

            // Navigating to the Groups tab 
            groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );

            // Validation
            Log.assertThat( groupsPage.isUserPresentInGrp( stuDetailsMap.get( "Student5" ) ), "Student Successfully added to new group", "Not added to Group" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify whether the teacher is able to assign assignment to two and five group", groups = { "SMK-43590", "Group", "SearchStudent" }, priority = 1 )
    public void tcSearchStudent003( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    			
        SMUtils.logDescriptionTC( "SMK-10862 : Verify whether the teacher is able to assign assignment to two group by searching the name of a single group and clicking Add button for another one" );
        SMUtils.logDescriptionTC( "SMK-10863 : Verify whether the teacher is able to assign assignment to five group by searching the name of a single group and clicking Add button for another four" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            AssignAssignmentPopup assignPopup = new AssignAssignmentPopup( driver );
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();

            String groupName = "SM Auto Group " + System.nanoTime();
            groupsPage.clickCreateNewGroupBtn();
            groupsPage.enterGroupNameinPopup( groupName );
            for ( int count = 1; count <= 4; count++ ) {
                groupsPage.addNameInTextField( stuDetailsMap.get( "Student" + count ) );
                SMUtils.waitForSpinnertoDisapper( driver );
                groupsPage.clickAddButton();
            }
            groupsPage.SelectAllGradesFromDropDown( "All Grades" );
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student5" ) );
            groupsPage.clickAddButton();
            groupsPage.clickCreateButton();

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            // Case 1 

            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();

            // Case 2
            coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            coursePage.clickReadingCourse();
            coursePage.clickAssignBtn();
            coursePage.addCourseToGroups();

            // Navigating to the Groups tab 
            groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName );
            groupsPage.clickAssignmentSideBar();

            // Validation
            Log.assertThat( groupsPage.isAssignmentAvailableForGroup( "Reading" ), "Assigment Added for the Group Successfully", "Assignment not added Sucessfully" );

            Log.assertThat( groupsPage.isAssignmentAvailableForGroup( "Math" ), "Assigment Added for the Group Successfully", "Assignment not added Sucessfully" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify whether the teacher is able to Add student to the group using single and Multiple checkboxes and click on the group label button", groups = { "SMK-43590", "Group", "SearchStudent" }, priority = 1 )
    public void tcSearchStudent004( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    			
        SMUtils.logDescriptionTC( "SMK-10858 : Verify whether the teacher is able to Add student to the group using single checkboxes and click on the group label button" );
        SMUtils.logDescriptionTC( "SMK-10859 : Verify whether the teacher is able to Add student to the group using multiple checkboxes and click on the group label button " );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Object creation for group page
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();

            String groupName = "SM AutoGroup" + System.nanoTime();
            String groupName1 = "SM AutoGroup" + System.nanoTime();
            groupsPage.createGroupWithoutStudent( groupName );
            groupsPage.createGroupWithoutStudent( groupName1 );

            // Navigate to Studnet Tab
            StudentsPage stuPage = tHomePage.topNavBar.navigateToStudentsTab();

            // Case 1

            stuPage.selectStudentByUsername( stuDetailsMap.get( "Student4" ) );
            groupsPage.clickGrouptabButton();
            groupsPage.addGrpInAddStudentToGrpPopUp( groupName );
            groupsPage.addGrpNameInSearFieldAddStuToGrpPopUp( groupName1 );
            groupsPage.clickSaveBtnAddStudToGrpPopUp();

            // Case 2
            stuPage.selectStudentByUsername( stuDetailsMap.get( "Student5" ) );
            stuPage.selectStudentByUsername( stuDetailsMap.get( "Student6" ) );
            stuPage.selectStudentByUsername( stuDetailsMap.get( "Student7" ) );
            stuPage.selectStudentByUsername( stuDetailsMap.get( "Student8" ) );
            groupsPage.clickGrouptabButton();
            groupsPage.addGrpInAddStudentToGrpPopUp( groupName );
            groupsPage.addGrpNameInSearFieldAddStuToGrpPopUp( groupName1 );
            groupsPage.clickSaveBtnAddStudToGrpPopUp();

            // Navigating to the Groups tab 
            groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName1 );

            // case 1 Validation
            Log.assertThat( groupsPage.isUserPresentInGrp( stuDetailsMap.get( "Student4" ) ), " User Added to the group successfully", "User not added" );

            // case 2 Validation
            Log.assertThat( groupsPage.isUserPresentInGrp( stuDetailsMap.get( "Student5" ) ), " User Added to the group successfully", "User not added" );

            Log.assertThat( groupsPage.isUserPresentInGrp( stuDetailsMap.get( "Student6" ) ), " User Added to the group successfully", "User not added" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify whether the teacher is able to add two and four students to the group", groups = { "SMK-43590", "Group", "SearchStudent" }, priority = 1 )
    public void tcSearchStudent005( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        SMUtils.logDescriptionTC( "SMK-10861 : Verify whether the teacher is able to add two students to the group by going into particular group and typing in the field for another one" );
        SMUtils.logDescriptionTC( "SMK-10861 : Verify whether the teacher is able to add four students to the group by going into particular group and typing in the field for another one" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigating to the Groups tab 
            GroupPage groupsPage = tHomePage.topNavBar.navigateToGroupsTab();

            String groupName1 = "SM AutoGroup" + System.nanoTime();
            groupsPage.createGroupWithoutStudent( groupName1 );

            groupsPage.viewGroup( groupName1 );

            // Click add student to group button
            groupsPage.clickAddStudentToGrpBtnGrpPage();

            // Case 1
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student9" ) );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickAddButton();
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student10" ) );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickAddButton();
            groupsPage.clickSaveBtnAddStudToGrpPopUp();

            // Navigating to the Groups tab 
            tHomePage.topNavBar.navigateToHomeTab();
            groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName1 );

            groupsPage.clickAddStudentToGroup();

            // case 2
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student11" ) );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickAddButton();
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student12" ) );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickAddButton();
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student13" ) );
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsPage.clickAddButton();
            groupsPage.clickSaveBtnAddStudToGrpPopUp();

            // Navigating to the Groups tab 
            groupsPage = tHomePage.topNavBar.navigateToGroupsTab();
            groupsPage.viewGroup( groupName1 );

            // Validation

            Log.assertThat( groupsPage.isUserPresentInGrp( stuDetailsMap.get( "Student10" ) ), "Student Successfully added to group", "Not added to Group" );

            Log.assertThat( groupsPage.isUserPresentInGrp( stuDetailsMap.get( "Student11" ) ), "Student Successfully added to group", "Not added to Group" );

            Log.assertThat( groupsPage.isUserPresentInGrp( stuDetailsMap.get( "Student12" ) ), "Student Successfully added to group", "Not added to Group" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify whether the teacher is able to assign assignment to two students and Five Students", groups = { "SMK-43590", "Group", "SearchStudent" }, priority = 1 )
    public void tcSearchStudent006( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	SMUtils.logDescriptionTC( "SMK-10864 : Verify whether the teacher is able to assign assignment to two students by searching the name of a single student and clicking Add button for another one" );
        SMUtils.logDescriptionTC( "SMK-10865 : Verify whether the teacher is able to assign assignment to five students by searching the name of a single student and clicking Add button for another four" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();

            AssignAssignmentPopup assignPopup = new AssignAssignmentPopup( driver );
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            AssignmentsPage navigateToAssignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

            navigateToAssignmentsPage.deleteAllAssignments();
            GroupPage groupsPage = new GroupPage( driver );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

            // Case 1
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            groupsPage.clickStudentRadioBtn();
            groupsPage.addStuInAssignPopUp( stuDetailsMap.get( "Student9" ) );
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student10" ) );
            groupsPage.clickAddBtnOnAssignPoPUp();
            assignPopup.clickAssignButtonOnPopup();

            // Case 2
            coursePage.clickMathCourse();
            coursePage.clickAssignBtn();
            groupsPage.clickStudentRadioBtn();
            groupsPage.addStuInAssignPopUp( stuDetailsMap.get( "Student11" ) );
            groupsPage.addStuInAssignPopUp( stuDetailsMap.get( "Student12" ) );
            groupsPage.addNameInTextField( stuDetailsMap.get( "Student13" ) );
            groupsPage.clickAddBtnOnAssignPoPUp();
            assignPopup.clickAssignButtonOnPopup();

            StudentsPage stuPage = tHomePage.topNavBar.navigateToStudentsTab();
            stuPage.clickviewStudentByEllipsis( stuDetailsMap.get( "Student10" ) );
            stuPage.clickSubNavigation( "Assignments" );
            // Validation
            Log.assertThat( groupsPage.isUserPresentInGrp( "Math" ), "Assignment Successfully added to Student", "Assignment Not added to Student" );

            stuPage = tHomePage.topNavBar.navigateToStudentsTab();
            stuPage.clickviewStudentByEllipsis( stuDetailsMap.get( "Student13" ) );
            stuPage.clickSubNavigation( "Assignments" );

            // Validation
            Log.assertThat( groupsPage.isUserPresentInGrp( "Math" ), "Assignment Successfully added to Student", "Assignment Not added to Student" );

            // Sign Out 
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
