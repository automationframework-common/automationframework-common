package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.ElementLayer;
import com.learningservices.utils.Log;
import com.learningservices.utils.ShadowDOMUtils;
import com.learningservices.utils.StopWatch;
import com.learningservices.utils.Utils;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.AjaxElementLocatorFactory;
import LSTFAI.customfactories.IFindBy;
import LSTFAI.customfactories.PageFactory;

public class RealizeTeacherHomePage extends LoadableComponent<RealizeTeacherHomePage> {

	private WebDriver driver;
	boolean isPageLoaded;
	public TopNavBar topNavBar;
	public ElementLayer elementLayer;
	public static List<Object> pageFactoryKey = new ArrayList<Object>();
	public static List<String> pageFactoryValue = new ArrayList<String>();
	
	public final static String enter_stud_name = "table[class*='student'] tbody:not(.ng-valid-student-name) td.student-name input";
	public static String subNavClassSettings = "cel-side-item[data-label='Settings'] button, *[data-label='Settings']";
	public static String subNavClassSettingsSpanish = "class-listing-cel-side-item[data-label='Settings'] button";

	public static String profile = "button.profile-container";
	public static String saveButton = "button.button";
	public static String pickProgram = "span.checkbox-label";
	
	@IFindBy(how = How.CSS, using = ".class-search-bar.hydrated", AI=false)
	public WebElement classSearch;

	@FindBy(css = "button[data-e2e-id='connectGoogleClass'], .zeroState__connectClass, .import-google-classes-btn")
	List<WebElement> btnConnectGoogleClassButton;

	@FindBy(css = "div.class-card")
	List<WebElement> lstClassesNames;

	@IFindBy(how = How.CSS, using = "h1[class*=class-name-header]", AI = false)
	public WebElement classNameHeader;

	@FindBy(css = "span[data-e2e-id='class-name'],ul[class='rosterData'] div[class='details'] h3 a")
	List<WebElement> lstClassNamesMFE;

	@IFindBy(how = How.CSS, using = "cel-side-navigation, cel-side-navigation[class*='sidebar-navigation'],class-listing-cel-side-navigation[class*='sidebar-navigation']", AI = false)
	public WebElement classDetailsSideBar;

	@IFindBy(how = How.CSS, using = "class-listing-cel-side-navigation.sidebar-navigation", AI = false)
	public WebElement assignments;

	@IFindBy(how = How.CSS, using = "class-listing-cel-side-navigation", AI = false)
	public WebElement eleee;

	String wenele = "class-listing-cel-side-item[data-label='Settings']";

	@FindBy(css = "ul>li[class*='program-box'] cel-checkbox-item,div[class*='program-box'] cel-checkbox-item")
	List<WebElement> lstQlPickProgramMfe;

	@FindBy (css = "class-settings-cel-checkbox-item.checkbox-sm")
	List<WebElement> pickProgramhost;
	
	@IFindBy(how = How.CSS, using = "class-settings-cel-button.save-button", AI = false)
	public WebElement pickSavehost;

	@IFindBy(how = How.CSS, using = "class-settings-cel-button.save-button", AI = false)
	public WebElement profileHost;

	@IFindBy(how = How.CSS, using = ".bottom button[ng-click*='saveRoster']", AI = false)
	public WebElement btnSaveBottom;

	@IFindBy(how = How.CSS, using = "input[name='classNameInput']", AI = false)
	public WebElement fldClassName;

	@FindBy(css = "ul.programList li div span")
	List<WebElement> lstPickPrograms;

	@IFindBy(how = How.CSS, using = ".quicklinks.moreOrLess a", AI = false)
	public WebElement lnkShowAllPrograms;

	@FindBy(css = enter_stud_name)
	List<WebElement> lstTxtStudentName;

	@FindBy(css = "table[class*='student'] tbody td.username input:not(.ng-valid-required)")
	List<WebElement> lstTxtUserName;

	@FindBy(css = "table[class*='student'] tbody td.password:not(.invalid) div:not(.ng-valid) input[type='text']:not(.ng-valid-required):not([disabled])")
	List<WebElement> lstTxtPassword;

	@IFindBy(how = How.CSS, using = "table[class*='student']", AI = false)
	public WebElement tableStudent;

	// Nightly
	@IFindBy(how = How.CSS, using = "shell-cel-navbar.header__navbar ", AI = false)
	public WebElement topNavBarwithShadow;

	/*
	 * for prod
	 * 
	 * @IFindBy ( how = How.CSS, using = "cel-navbar.header__navbar ", AI = false )
	 * public WebElement topNavBarwithShadow;
	 */

	@IFindBy(how = How.CSS, using = "div.stepInner[data-e2e-id=\"createClass\"] > h3.ng-binding", AI = false)
	public WebElement createClass;

	@IFindBy(how = How.CSS, using = "button.create-new-class-btn", AI = false)
	public WebElement createclass;

	//Welcome Page
	
	public static String STUD_WELCOME_MSG = "Your account is almost ready for you! Just answer a few more questions about yourself and you're all set to start.";
	@FindBy(id = "navHello")
    WebElement navHello;

    @FindBy(id = "navStep1")
    WebElement navStep1;

    @FindBy(id = "navStep2")
    WebElement navStep2;

    @FindBy(id = "navStep3")
    WebElement navStep3;

    @FindBy(id = "navStep4")
    WebElement navStep4;

    @FindBy(id = "navStep5")
    WebElement navStep5;

    @FindBy(id = "navDone")
    WebElement navDone;

    // ********** Hello section ***************
    @FindBy(css = "#hello .content .text")
    WebElement txtWelcomeMsg;

    // ********** Teacher Step1 section ***************
    @FindBy(css = ".grades li div span")
    List<WebElement> lstGrade;

    @FindBy(css = ".grades ul li")
    List<WebElement> chkGrades;

    @FindBy(css = ".grades ul li div i[aria-checked='true']")
    List<WebElement> lstSelectedGrades;

    // ********** Student Step1 section **********
    @FindBy(css = "ul[aria-labelledby='languageDropdown']  a")
    List<WebElement> selectLang;

    @FindBy(id = "languageDropdown")
    WebElement drpLanguage;

    @FindBy(css = ".language .subtitle")
    WebElement langSelectMsg;
    
    @FindBy(css = "#languageDropdown .icon-caret-down")
    WebElement langDropDownArrow;

    // ********** Teacher Step2 section **********
    @FindBy(css = ".content .program div span")
    List<WebElement> lstProgram;

    @FindBy(css = ".program .customCheckbox i")
    List<WebElement> chkPrograms;

    // ********** Teacher Step3 section **********
    @FindBy(css = "input[name='facingName']")
    WebElement txtTeacherName;

    @FindBy(css = "input[name='facingName']")
    WebElement txtStudName;

    // ********** Teacher Step4 section **********
    @FindBy(css = ".thumbSelector.profile li")
    List<WebElement> lstProfileImgs;
    
    @FindBy(css = ".thumbSelector.profile li div.image")
    List<WebElement> lstProfileImages;

    // ********** Teacher Step5 section **********
    @FindBy(css = ".thumbSelector.homepage li")
    List<WebElement> lstBackgroundImgs;
    
    @FindBy(xpath = "previewButton")
    WebElement btnPreview;

    @FindBy(css = "img.previewBG")
    WebElement homepagepreview;

    @FindBy(css = "#homeBGPreview button")
    WebElement btnPreviewOk;
    
    // ********** Teacher Done Section **********
    @FindBy(css = "div[data-e2e-id='agreement'] i")
    List<WebElement> checkAgreementOnWelcome;

    @FindBy(css = "#licenseAgreementInput a")
    WebElement lnkLicenseAgreement;

    @FindBy(css = ".text .customCheckbox .customCheckboxInput")
    WebElement chkAgree;

    @FindBy(css = "button[ng-click*='finish()']")
    WebElement btnLetsGoOnWelcome;

    @FindBy(css = ".alert .message-container")
    WebElement txtErrorMsgContainer;

    @FindBy(css = "a .text")
    WebElement scrollkey;

    @FindBy(css = ".logo")
    WebElement pearsonLogo;

    @FindBy(css = "#step2 .content .title")
    WebElement lblProgramSection;

    @FindBy(css = "#step2 .programs .text")
    WebElement msgProgram;
    
    @FindBy(css = "div[class='scrollDivider'] a")
    List<WebElement> lstScroll;
    
    //Google Classroom modal for Student
   	
   	@FindBy(css = "#simpleDialog")
    WebElement mdlGoogleClassRoom;
   	
    @FindBy(css = "#dialogTitle")
    WebElement txtGoogleClassRoomModalTitle;
    
    @FindBy(css = "#dialogContent")
    WebElement txtGoogleClassRoomModalDescription;
    //Realize Welcome Page
	public RealizeTeacherHomePage() {
	}

	public RealizeTeacherHomePage(WebDriver driver) {
		this.driver = driver;
		ElementLocatorFactory finder = new AjaxElementLocatorFactory(driver, Utils.maxElementWait);
		PageFactory.initElements(finder, this);
		elementLayer = new ElementLayer(driver);
		topNavBar = new TopNavBar(driver);
	}

	@Override
	protected void isLoaded() {

		if (!isPageLoaded) {
			Assert.fail();
		}
		try {
			SMUtils.waitForSpinnertoDisapper(driver);
		} catch (InterruptedException e) {
			Log.message("Issue in Spinner Loading");
		}
		
		if (driver.getCurrentUrl().toLowerCase().contains("/community/welcome"))
		{	
			SMUtils.waitForElement(driver, txtWelcomeMsg);
	        if (txtWelcomeMsg.getText().equals(STUD_WELCOME_MSG))
	        	Log.message("Realize welcome page loaded successfully");
	        else
	        	Log.fail("Realize welcome page could not be loaded");
		} else {	
		if (SMUtils.waitForElement(driver, topNavBarwithShadow, 30)) 
			Log.message("Realize Teacher home page loaded successfully.");
		 else 
			Log.fail("Realize Teacher home page did not load.");
		}
	}

	@Override
	protected void load() {
		isPageLoaded = true;
		SMUtils.waitForElement(driver, topNavBarwithShadow);
	}

	/**
	 * Click classes tab
	 *
	 * @return
	 */
	public void clickClassestab() {

		try {
			SMUtils.nap(5);
			String queryToExecute = "return document.querySelector('app-root app-home .header_fixed .hydrated').shadowRoot.querySelector('div > ul > li.tab-item:nth-of-type(3)')";
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement classsss = (WebElement) js.executeScript(queryToExecute);
			SMUtils.click(driver, classsss);
			Log.message("clicked classes tab", driver, true);
			SMUtils.nap(5);
		} catch (Exception e) {
			Log.message(e.getMessage());
		}

	}

	/**
	 * create Classes
	 *
	 * @return
	 */
	public void createClasses() {
		SMUtils.waitForElement(driver, createclass);
		SMUtils.clickJS(driver, createclass);
		Log.message("Create classes Button Clicked");
	}

	/**
	 * Enter class name
	 * 
	 * @param classname  as string
	 * @param screenshot to capture screenshot
	 * 
	 */
	public void enterClassName(String classname) {

		SMUtils.waitForElement(driver, fldClassName);
		fldClassName.clear();
		fldClassName.sendKeys(classname);
		Log.message("classname entered successfully");
	}

	/**
	 * Checks and returns the visibility state of Courses Widget
	 *
	 * @return
	 */
	public boolean isCreateClassPageDisplayed() {

		try {
			SMUtils.waitForElement(driver, createClass, 10);
			Log.message("Create class page is displayed", driver, true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return createClass.isDisplayed();
	}

	/**
	 * To pick specific program while creating a class
	 * 
	 * @param programName program to be selected
	 *
	 */
	public void pickProgram(String programName) {
		WebElement element = null;

		if (SMUtils.waitForElement(driver, lnkShowAllPrograms)) {
			SMUtils.scrollIntoView(driver, lnkShowAllPrograms);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", lnkShowAllPrograms);
			try {
				SMUtils.waitForSpinnertoDisapper(driver);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		List<String> programNames = Arrays.asList(programName.split("\\|"));
		SMUtils.scrollIntoView(driver, lstPickPrograms.get(0));
		for (int i = 0; i < programNames.size(); i++) {

			try {
				element = SMUtils.getMachingTextElementFromList(lstPickPrograms, programNames.get(i).trim());
			} catch (Exception e) {
				e.printStackTrace();
				Log.message("Subscription not found on Create class page : " + programNames.get(i).trim());
			}
			WebElement programLink = element.findElement(By.xpath("preceding-sibling::i"));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", programLink);
		}

		Log.event("Picked programs:: " + programNames);
		Log.message("Picked programs:: " + programNames, driver, true);

	}

	/**
	 * To enter student name in create new class page
	 * 
	 * @param row
	 * @param studentName
	 */
	public void enterStudentName(int row, String studentName) {
		Log.event("Entering student name");

		SMUtils.scrollIntoView(driver, lstTxtStudentName.get(row));
		lstTxtStudentName.get(row).sendKeys(studentName);
		Log.message("Entered the student name: " + studentName);
	}

	/**
	 * To enter user name for student in create new class page
	 * 
	 * @param row
	 * @param userName
	 */
	public void enterUserName(int row, String userName) {
		Log.event("Entering '" + userName + "' student username");
		SMUtils.scrollIntoView(driver, tableStudent);

		try {
			lstTxtUserName.get(row).sendKeys(userName);
		} catch (Exception e) {
			Log.event("This is the last row in the student table and the details are entered");
		}
		Log.message("Entered the student username: " + userName);

	}

	/**
	 * To enter password for student in create new class page
	 * 
	 * @param row
	 * @param password
	 */
	public void enterPassword(int row, String password) {
		Log.event("Entering student password");
		lstTxtPassword.get(row).sendKeys(password);
		Log.message("Entered the Student password: " + password);

	}

	/**
	 * To create a class with no student
	 * 
	 * @param classname  Class Name
	 * @param program    program to select
	 * @param screenshot To capture screenshot
	 */
	public void createClassWithNoStudents(String classname, String program, boolean screenshot) {
		Log.event("Creating class " + classname + " with No Students");
		enterClassName(classname);
		pickProgram(program);
		clickSaveBtn(screenshot);
		Log.message("Created class " + classname + " with no Students", driver, screenshot);
	}

	/**
	 * To click save button on create new class page
	 * 
	 * @param screenshot to capture screenshot
	 * 
	 */
	public void clickSaveBtn(boolean screenshot) {
		final long startTime = StopWatch.startTime();
		Log.event("Clicking Save button on create new class page");

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			Log.event("catch part");
		}
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", btnSaveBottom);
		SMUtils.waitForPageLoad(driver);
		Log.event("Clicked Save button on create new class page", StopWatch.elapsedTime(startTime));
		Log.message("'Save' button is clicked in Create New Class Page", driver, screenshot);
	}

	

	/**
	 * verify the Class by Search
	 * 
	 * @param Classname
	 * @return searched Class names if present
	 * 
	 */
	public void verifyClassbySearch(String classname, boolean screenshot) {
		// Searching class
		Log.message("Searching for the Class name: " + classname);
		WebElement searchClass = ShadowDOMUtils.findElementFromParent(".search-field", classSearch, driver);
		searchClass.clear();
		Log.message("Enter the Class name: " + classname + "in Class SearchBox");
		searchClass.sendKeys(classname);
		if ((btnConnectGoogleClassButton.get(0).isDisplayed())) {
			Log.message("Classes are Found");
		} else {
			Log.message("Classes are not Found");
		}

	}

	public void navigateToClassSettingsPage(String classname, boolean screenshot) throws Exception {
		WebElement elementMachingText = null;
		Log.event("Clicking the class's(" + classname + ") settings quick link");

		verifyClassbySearch(classname, screenshot);

		List<WebElement> classNameList = lstClassNamesMFE;
		elementMachingText = SMUtils.getMachingTextElementFromList(classNameList, classname);
		Log.message("The value of matching text is " + elementMachingText.getText().trim());
		elementMachingText.click();
		SMUtils.nap(10);

		List<WebElement> ele1 = SMUtils.getAllWebElements(driver, eleee, wenele);
		Log.message("the text is " + ele1.get(0).getText().trim());

		SMUtils.clickJS(driver, ele1.get(0));

		Log.message("Clicked on 'Class Settings' subnav", driver, true);

		SMUtils.nap(10);

	}

	/*
	 * To pick specific program in class settings page
	 * 
	 * @param String programName
	 * 
	 * @param screenShot
	 * 
	 * @return boolean
	 *
	 */
	public boolean pickProgramClassSettings(String programName, boolean screenShot) {

		boolean programFound = false;
		try {
			Log.message("To add a program subscription to the class settings page");
			for (WebElement prog : pickProgramhost) {
				WebElement checkProg = SMUtils.getWebElement(driver, prog, pickProgram);
			if (checkProg.getText().toString().trim().equalsIgnoreCase(programName)) {
				Log.message("Selecting the program " + programName);
					SMUtils.clickJS(driver, checkProg);
					programFound = true;
					break;
				}
			}
			SMUtils.nap(5);

		} catch (Exception e) {
			Log.message("Exception occured while selecting product subscription" + e.getMessage());
			return false;
		}
		return programFound;

	}

	/**
	 * To click Save button
	 * 
	 * @param position   - top or bottom save button
	 * @param screenShot
	 * @throws Exception
	 */
	public void clickSaveBtnClassSettings() throws Exception {

		try {
			SMUtils.nap(5);

			Log.event("Clicking 'Save' button");

			List<WebElement> ele2 = SMUtils.getAllWebElements(driver, pickSavehost, saveButton);

			for (WebElement ele3 : ele2) {
				if (ele3.getText().trim().equalsIgnoreCase("Save")) {
					Log.message("Save button found.. clicking it");
					SMUtils.clickJS(driver, ele3);
					SMUtils.nap(2);
					Log.message("clicked save button", driver, true);
					break;
				} else {
					Log.message("Save button not found");
				}
			}

			SMUtils.waitForPageLoad(driver);

		} catch (Exception e) {
			Log.message("Exception occuured while clicking on save button " + e.getMessage());
		}
	}

	public boolean clickClassName(String classname) {
		boolean clickedClass = false;

		for (WebElement element : lstClassesNames) {
			if (element.getText().trim().equals(classname)) {
				Log.message("The class name is " + element.getText().trim());
				clickedClass = true;
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0,0)");
				SMUtils.waitForElementToBeClickable(element, driver);
				SMUtils.nap(2);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
				SMUtils.waitForElement(driver, classNameHeader);
				Log.message("Clicked on the class '" + classname + "' present on the classes page to check assignments",
						driver, true);
				break;

			}
		}

		return clickedClass;
	}
	
	// Welcome page
	 /**
     * 
     * To navigate from welcome to home page as a Teacher at the first time of
     * teacher login
     * 
     * @param programName
     *            program name
     * @param teacherName
     *            teacher name
     * @param gradeSelect
     *            grade name
     * @throws Exception
     */
    public void welcomeToTeacherRegistration(String programName, String teacherName) throws Exception {

            if (lstGrade.size() > 0) {
                selectGrades("Grade 1", true);
            }
            if (lstProgram.size() > 0) {
                selectPrograms(programName);
            }
            enterTeacherName(teacherName);
            if (checkAgreementOnWelcome.size() > 0) {
                checkAgreementOnWelcome.get(0).click();
            }
            SMUtils.clickJS(driver, btnLetsGoOnWelcome);
            //(new WebDriverWait(driver, 60).pollingEvery(250, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class).withMessage("Unable to click Lets Go button on welcome page")).until(ExpectedConditions.elementToBeClickable(btnLetsGoOnWelcome)).click();
            SMUtils.waitForPageLoad(driver);
        
    }

    /**
     * To Enter Teacher Name
     * 
     * @param teachername
     */
    public void enterTeacherName(String teachername) {
        SMUtils.waitForElement(driver, txtTeacherName, 5);
        txtTeacherName.clear();
        txtTeacherName.sendKeys(teachername);
    }

    /**
     * To pick programs using program names
     * 
     * @param programName
     * @throws Exception
     */
    public void selectPrograms(String programName) throws Exception {
        WebElement element = null;
        final long startTime = StopWatch.startTime();

        List<String> programNames = Arrays.asList(programName.split("\\|"));
        for (int i = 0; i < programNames.size(); i++) {
            SMUtils.waitForElement(driver, lstProgram.get(0));
        	//(new WebDriverWait(driver, 60).pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class).withMessage("Programs not visible to select")).until(ExpectedConditions.visibilityOfAllElements(lstProgram));

            element = SMUtils.getMachingTextElementFromList(lstProgram, programNames.get(i).trim());
            WebElement programLink = element.findElement(By.xpath("preceding-sibling::i"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", programLink);
            //SMUtils.scroll(driver, programLink, "top");
            SMUtils.scrollWebElementToView(driver, programLink, "top");
            Log.event("Picked 'Programs' are :: " + programNames.get(i).trim(), StopWatch.elapsedTime(startTime));
            Log.message("Picked 'Programs' are :: " + programNames.get(i).trim(), driver, true);
        }
    }

    /**
     * To select grades using grade names
     * 
     * @param gradesName
     * @param screenshot
     *            to capture screenShot
     * @throws Exception
     */
    public void selectGrades(String gradesName, boolean screenshot) throws Exception {
        WebElement element = null;
        final long startTime = StopWatch.startTime();
        List<String> gradeNames = Arrays.asList(gradesName.split("\\|"));
        for (int i = 0; i < gradeNames.size(); i++) {
        	SMUtils.waitForElement(driver, lstGrade.get(0));
        	
            //(new WebDriverWait(driver, 60).pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class).withMessage("Grades not visible to select")).until(ExpectedConditions.visibilityOfAllElements(lstGrade));
            element = SMUtils.getMachingTextElementFromList(lstGrade, gradeNames.get(i).trim());
            WebElement gradesLink = element.findElement(By.xpath("preceding-sibling::i"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", gradesLink);
            //SMUtils.scrollElementIntoView(driver, gradesLink, "top");
            SMUtils.scrollWebElementToView(driver, gradesLink, "top");
            SMUtils.waitForElement(driver, navStep2);
            Log.event("Picked Grades:: " + gradeNames.get(i).trim(), StopWatch.elapsedTime(startTime));
            Log.message("Selected 'Grades' are :: " + gradeNames.get(i).trim(), driver, screenshot);
        }
    }

    

    /**
     * 
     * To click on Let's Go button in Welcome page
     * 
     * @param screenshot
     *            to capture screenShot
     * 
     * @return HomePage
     */
    public void clickLetsGoBtn(boolean screenshot) {
        if (SMUtils.waitForElement(driver, btnLetsGoOnWelcome)) {
        	SMUtils.scrollIntoView(driver, btnLetsGoOnWelcome);
            btnLetsGoOnWelcome.click();
            SMUtils.waitForPageLoad(driver);
            Log.message("Clicked 'Lets Go'/'¡Vamos!' button in Welcome page", driver, screenshot);
        }

    }
  

    /**
     * To verify Hello section welcome message for student/teacher
     * 
     * @return boolean status - true if welcome message is displayed else, false
     * 
     */

    public boolean isWelcomeMsgdisplayed() {
        boolean status = false;
        SMUtils.waitForElement(driver, txtWelcomeMsg);
        if (txtWelcomeMsg.getText().equals(STUD_WELCOME_MSG)) {
            status = true;
        }
        return status;

    }

    
    /**
     * To select I Agree checkbox
     * 
     * @param screenshot
     *            to capture screenShot
     * 
     */
    public void selectIAgreeChkBox(boolean screenshot) {

        if (SMUtils.waitForElement(driver, chkAgree)) {
            chkAgree.click();
            Log.message("'I Agree'/'Acepto las' License agreement is selected", driver, screenshot);
        } else {
            Log.message("'I Agree'/'Acepto las' License agreement is not selected", driver, screenshot);
        }
    }

    
    
    /**
	 * To click License Agreement link
	 * 
	 * @param screenShot
	 *            to capture screenShot
	 */
    public void clickLicenseAgreement(Boolean screenShot)
    {
    	Log.event("Clicking on 'License Agreement' link");
    	if (SMUtils.waitForElement(driver,lnkLicenseAgreement)) {
    		SMUtils.scrollIntoView(driver, lnkLicenseAgreement);
			lnkLicenseAgreement.click();
			SMUtils.waitForPageLoad(driver);
			Log.message("Clicked on 'License Agreement link", driver, screenShot);
		} else {
			Log.message("Unable to click on License Agreementt link");
		}
    }
	// Welcome page

}
