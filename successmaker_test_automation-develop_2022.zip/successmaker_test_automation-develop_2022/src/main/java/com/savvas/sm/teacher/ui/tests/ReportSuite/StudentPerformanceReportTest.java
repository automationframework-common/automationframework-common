package com.savvas.sm.teacher.ui.tests.ReportSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.ReportComponent;
import com.savvas.sm.teacher.ui.pages.SPRPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class StudentPerformanceReportTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String sessionCookie;
    private String username = null;
    private String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String teacherDetails;
    private String studentLastName;
    SPRPage reportPage;
    String reportFilterName;
    ReportComponent reportComponent;

    @BeforeClass
    public void initTest( ITestContext context ) throws Exception, IOException {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher6" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( description = "Verify Student performance Report (SPR) should display under Reports menu.", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 1 )
    public void tcSM_SPR001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        reportComponent = new ReportComponent( driver );

        Log.testCaseInfo( "tcSM_SPR001: Verify Student performance Report (SPR) should display under Reports menu<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Validate SPR Availability
            Log.assertThat( tHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.SPR_SUBMENU ), "SPR is available in Reports Sub Menu", "SPR is  not available in Reports Sub Menu" );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "SPR page loaded successfully" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student performance Report (SPR) decription text and availability of SPR Header on reports page", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 2 )
    public void tcSM_SPR002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSM_SPR002: Verify Student performance Report (SPR) decription text<small><b><i>[" + browser + "]</b></i></small>" );
        reportComponent = new ReportComponent( driver );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // Validate Header decription of SPR
            Log.assertThat( reportPage.reportDescriptionText( Constants.Reports.SPR_DESCRIPTIONTEXT ), "Correct description is showing in SPR Header", "wrong Header is showing in SPR header" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify subject filter availability for SPR and also verifying list of all subjects available in filter", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 3 )
    public void tcSM_SPR003() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        reportComponent = new ReportComponent( driver );
        Log.testCaseInfo( "tcSM_SPR003: Verify subject filter availability for SPR<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // Validate subject filter
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject filter is displaying", "Subject filter is not displaying" );
            // Getting values for Additional grouping
            reportComponent.setDropDownMS( Constants.Reports.SUBJECT_DROPDOWN );
            List<String> displayFromUI = reportComponent.getValuesFromDropDownMS();
            // Validation for Subject dropdown
            Log.assertThat( ( displayFromUI ).equals( Constants.Reports.SUBJECTS ), "Subject options loaded successfully", "Subject options not loaded Properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify All filds displayed on SPR Page", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 4 )
    public void tcSM_SPR004() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        reportComponent = new ReportComponent( driver );
        Log.testCaseInfo( "tcSM_SPR004:Verify All filds displayed on SPR Page<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            // Validate All fields on SPR
            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.FILTERS ), "Filter Option is available", "Filter Option is not available" );
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.GROUP_OR_STUDENT_HEADER ), "Select Groups or Students is available", "Select Groups or Students is not available" );
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.GROUP_DROPDOWN ), "Groups header is displaying", "Groups header is not displaying" );
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.STUDENTS_DROPDOWN ), "Student header is displaying", "Student header is not displaying" );
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.REFINE_SEARCH ), "Refine search header is displaying", "Refine search header is not displaying" );
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "Assignments dropdown header is displaying", "Assignments dropdown header is not displaying" );
            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.REPORT_OPTION_HEADER ), "Report Options header is displaying", "Report Options header is not displaying" );
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.DISPLAY_DROPDOWN ), "Display dropdown header is displaying", "Display dropdown header is not displaying" );
            Log.assertThat( reportPage.isMaskStudentDisplayed( Constants.Reports.MASK_STUDENT_DISPLAY ), "Mask Student header is displaying", "Mask Student header is not displaying" );
            Log.assertThat( reportPage.islabelOfperforamanceSummaryStarndAndAODHeadingPresent( Constants.Reports.SPR_INCLUDEPERFORMANCE ), "Include Performance summary header is displaying", "Include Performance summary header is not displaying" );
            Log.assertThat( reportPage.islabelOfperforamanceSummaryStarndAndAODHeadingPresent( Constants.Reports.SPR_INCLUDEPERFORMANCESTRAND ), "Include Performance by strand header is displaying",
                    "Include Performance by strand header is not displaying" );
            Log.assertThat( reportPage.islabelOfperforamanceSummaryStarndAndAODHeadingPresent( Constants.Reports.SPR_INCLUDEAOD ), "Include Area of difficulty header is displaying", "Include Area of difficulty header is not displaying" );
            Log.assertThat( reportPage.islabelOfperforamanceSummaryStarndAndAODHeadingPresent( Constants.Reports.DATEATRISK_DROPDOWN ), "Date at risk dropdown header is displaying", "Date at risk dropdown header is not displaying" );
            Log.assertThat( reportPage.islabelOfperforamanceSummaryStarndAndAODHeadingPresent( Constants.Reports.SPR_LANGUAGE_DROPDOWN ), "Language dropdown header is displaying", "Language dropdown header is not displaying" );
            Log.assertThat( reportPage.isRunReportDisplayed(), "Run report button is displaying", "Run report button is not displaying" );
            Log.assertThat( reportPage.isSaveReportDisplayed(), "Save report options link is displaying", "Save report options link is not displaying" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the default selection of Subject drop down in Student Performance Reports Page", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 5 )
    public void tcSM_SPR005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
        reportComponent = new ReportComponent( driver );
        Log.testCaseInfo( "tcSM_SPR005:Verify the default selection of Subject drop down in Student Performance Reports Page<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();

            Log.message( "Student Performance page has loaded" );
            // Verify Select ALL check box is checked or not
            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.SUBJECT_DROPDOWN ), "Select All is checked", "Select All is not checked" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can select all and de select all assignments through SELECT ALL check box", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 6 )
    public void tcSM_SPR006() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        reportComponent = new ReportComponent( driver );
        Log.testCaseInfo( "tcSM_SPR006:Verify user can select all and de select all assignments through SELECT ALL check box<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            reportComponent.clickSelectALLFromMSDropdownwithJS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            Log.assertThat( !( reportPage.isSelectALLChecked() ), "SELECt ALL Check unchecked successfully", "SELECT ALL Checkbox has not  unchecked yet" );
            reportComponent.clickSelectALLFromMSDropdownwithJS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            reportPage.collapseFilterButton();
            Log.assertThat( !reportPage.isSelectALLChecked(), "SELECT ALL Check checked successfully", "SELECT ALL Checkbox has not checked yet" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Groups' dropdown field display under Filters option when only one Group is selected on SPR", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 7 )
    public void tcSM_SPR007() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        reportComponent = new ReportComponent( driver );
        Log.testCaseInfo( "tcSMSPR007: Verify 'Groups' dropdown field display under Filters option when only one Group is selected. <small><b><i>[" + browser + "]</b></i></small>" );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdownwithJS( Constants.Reports.GROUP_DROPDOWN );

            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupOptions = new ArrayList<>();
            // Verify the Dropdown text after selecting one Group
            if ( groupsFromUI.size() > 1 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( groupsFromUI.get( 0 ).equals( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ) ), "Selected group name is Displayed", "Selected group name is not Displayed" );
            } else if ( groupsFromUI.size() == 1 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All Groups text and count of the Groups is Display Properly", "All Groups text or count of the Groups is not Display Properly" );
            } else {
                Log.message( "Given teacher don't have goups" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Display' dropdown should display on SPR page ,verify all list of Display filter", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 8 )
    public void tcSM_SPR008() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSM_SPR008:Verify 'Display' dropdown should display on SPR page<small><b><i>[" + browser + "]</b></i></small>" );
        reportComponent = new ReportComponent( driver );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            Log.assertThat( reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.DISPLAY_DROPDOWN ).equals( Constants.Reports.DISPLAY ), "All Display filter list is avaialble", "Display filter list is not available" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify deleted groups should not display under Groups dropdown.", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 9 )
    public void tcSM_SPR009() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSM_SPR009:Verify deleted groups should not display under Groups dropdown.<small><b><i>[" + browser + "]</b></i></small>" );
        reportComponent = new ReportComponent( driver );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // getting the groups names from data setup
            List<String> groupsList = new ArrayList<>();
            String groupDetails = DataSetup.teacherGroupMap.get( username ).get( username );
            for ( int groupCount = 1; groupCount <= SMUtils.getWordCount( groupDetails, "groupName" ); groupCount++ ) {
                groupsList.add( SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", groupCount ) );
            }

            // Getting groups from UI
            reportComponent.setDropDownMS( "Groups" );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMultiSelect();
            Log.assertThat( groupsList.equals( groupsFromUI ), "All Groups displayed successfully!", "Groups not displayed properly", driver );

            if ( groupsFromUI.size() > 0 ) {
                // getting Group Name
                String groupName = groupsFromUI.get( 0 );

                // Delete Group
                GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
                groupPage.viewGroup( groupName );
                // Need For Page load
                SMUtils.nap( 2 );
                groupPage.deleteGroup( groupName );

                // navigate to SPR Page
                reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

                // again Getting groups from UI
                reportComponent.setDropDownMS( "Groups" );
                groupsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

                // validate delete group should not display under groups
                // dropdown
                Log.assertThat( !( groupsFromUI.contains( groupName ) ), "Deleted Group is not present under Groups Dropdown", "Deleted Group is present under Groups Dropdown" );
            } else {
                Log.message( "Given teacher don't have goups" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify removed assignments should not display under assignment dropdown.", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 10 )
    public void tcSM_SPR010() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSM_SPR0010:Verify removed assignments should not display under assignment dropdown.<small><b><i>[" + browser + "]</b></i></small>" );
        reportComponent = new ReportComponent( driver );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            List<String> assignmentsList = new ArrayList<>();
            String assignmentsDetails = DataSetup.teacherAssignmentMap.get( username ).get( username );
            for ( int assignmentsCount = 1; assignmentsCount <= SMUtils.getWordCount( assignmentsDetails, "name" ); assignmentsCount++ ) {
                assignmentsList.add( SMUtils.getKeyValueFromJsonArray( assignmentsDetails, "name", assignmentsCount ) );
            }

            // Getting Assignments from UI
            reportComponent.setDropDownMS( "Assignments" );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

            if ( assignmentsFromUI.size() > 0 ) {
                // getting Assignment Name
                String assignmentsName = assignmentsFromUI.get( 0 );
                // Navigate to Courseware tab
                AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
                // Click on Assignment SubMenu
                page.clickAssignmentSubMenu();
                // Click Delete Assignment
                AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( assignmentsName );
                assignmentDetailsPage.assignmentLevelEllipsis();
                assignmentDetailsPage.deleteAssignmenttab();
                SMUtils.nap( 2 );
                assignmentDetailsPage.deleteAssignmentButton();
                Log.assertThat( assignmentDetailsPage.isAssignmentDisplayed(), "Assignment has deleted successfully", "Assignment has not deleted successfully" );
                // navigate to CPR Report page

                tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
                reportComponent.setDropDownMS( "Assignments" );
                assignmentsFromUI = reportComponent.getValuesFromDropDownMultiSelect();
                Log.assertThat( !( assignmentsFromUI.contains( assignmentsName ) ), "Deleted assignments is not present under Assignments Dropdown", "Deleted assignments is present under assignments Dropdown" );
            } else {
                Log.message( "Teacher don't have assignments" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify all field on Saved Report Window pop up on SPR page Including button and drop down", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 11 )
    public void tcSM_SPR011() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSM_SPR0011:Verify all field on Saved Report Window pop up on SPR page.<small><b><i>[" + browser + "]</b></i></small>" );
        reportComponent = new ReportComponent( driver );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            reportComponent.clickSaveReportOption();
            Log.assertThat( reportComponent.getSaveReportPopUpTextHeader().equals( Constants.Reports.SPR_SAVEREPORT_POUP_HEADER ), "Save Report Option As Is displaying", "Save Report Option As is not displaying" );
            Log.assertThat( reportComponent.saveReportOptionNewFieldHeader().equals( Constants.Reports.SPR_NEW_HEADER_SAVEREPORT ), "NEW Field is displaying on Poup", "NEW Field is not displaying on Poup" );
            Log.assertThat( reportComponent.saveReportOptionReplaceExistingFieldHeader().equals( Constants.Reports.SPR_REPLACE_EXISTING_HEADER ), "Replace Existing Report Option Field is displaying on Poup",
                    "Replace Existing Report Option Field is not displaying on Poup" );
            Log.assertThat( reportComponent.isSaveBtnDisplayedOnSaveReportPopUp(), "Save Button on save report option Field is displaying on Poup", "Save Button on save report option Field is not displaying on Poup" );

            Log.assertThat( reportComponent.isCancelBtnDisplayedOnSaveReport(), "Cancel Button on save report option Field is displaying on Poup", "Cancel Button on save report option Field is not displaying on Poup" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Assignments' dropdown field display under Filters option when only one assignment is selected on SPR", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 12 )
    public void tcSM_SPR012() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSM_SPR0012:Verify 'Assignments' dropdown field display under Filters option when only one assignment is selected on SPR<small><b><i>[" + browser + "]</b></i></small>" );
        reportComponent = new ReportComponent( driver );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdownwithJS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();
            // Verify the Dropdown text after selecting one assignment
            if ( assignmentsFromUI.size() > 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( assignmentsFromUI.get( 0 ).equals( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ) ), "Selected assignment name is Displayed", "Selected assignment name is not Displayed" );
            } else if ( assignmentsFromUI.size() == 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "1" ) ),
                        "All assignments text and count of the assignments is Display Properly", "All assignments text or count of the assignments is not Display Properly" );
            } else {
                Log.message( "Given teacher don't have assignments" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Student Summary Performance field,Include Performance by Strand,Include Areas of Difficulty radio button, Verifying when Area of difficulty is No,then Date at risk dropdwon should not display ", groups = { "SMK-39429",
            "reports", "StudentPerformanceReport" }, priority = 13 )
    public void tcSM_SPR013() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSM_SPR0013:Verify Student Summary Performance,Include Performance by Strand,Include Areas of Difficulty radio button<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            SPRPage reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            // Click Performance Summary Radio Button
            reportPage.clickIncludePerformaceSummaryradioButton();
            Log.assertThat( !reportPage.isPerformanceSummaryYes(), "Include Perfoamnce Summary is selected as Yes", "Include Perfoamnce Summary is selected as No" );
            reportPage.clickIncludePerformaceByStarndRadioButton();
            Log.assertThat( !reportPage.isPerformanceByStrandYes(), "Include Performance By starnd is selected as Yes", "Include Performance is selected as No" );
            reportPage.clickAODRdiobutton();
            Log.assertThat( !( reportPage.isDateAtRiskDisplaying() ), "Date At Risk is not displaying when AOD is No", "Date At Risk is displaying when AOD is No,Validation fail." );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify List of all 'Date At Risk ' dropdwon list and list of all Language dropdown field options available on SPR", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 14 )
    public void tcSM_SPR014() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSM_SPR0014:Verify 'Date At Risk ' dropdown,Language Dropdown, Mask Student checkbox field options<small><b><i>[" + browser + "]</b></i></small>" );
        reportComponent = new ReportComponent( driver );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            SPRPage reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // Vallidate all list of Date At Risk Dropdown Elements

            Log.assertThat( reportComponent.getValuesFromStaticDropDown( Constants.Reports.SPR_DATEATRISK_DROPDOWN ).equals( Constants.Reports.DATE_AT_RISK ), "All Date at risk filter list is avaialble", "Date at risk filter list is not available" );
            // Validate all List of Language elements
            Log.assertThat( reportComponent.getValuesFromStaticDropDown( Constants.Reports.SPR_LANGUAGE_DROPDOWN ).equals( Constants.Reports.LANGUAGE ), "List of languages is displaying", "List of language is not displaying" );
            reportPage.clickMaskStudentCB();
            Log.assertThat( !( reportPage.isMaskStudentSelected() ), "Mask Student Check Box Selected now", "Mask Student is not selected Yes" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'Groups' dropdown field display under Filters option when more than one Groups are selected.", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 15 )
    public void tcSM_SPR015() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSM_SPR0015:Verify 'Groups' dropdown field display under Filters option when more than one Groups are selected.<small><b><i>[" + browser + "]</b></i></small>" );
        reportComponent = new ReportComponent( driver );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdownwithJS( Constants.Reports.GROUP_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<WebElement> optionsFromGroupsDropdown = reportComponent.getWebElementsForMSDropdownOptions( Constants.Reports.GROUP_DROPDOWN );

            // Verify thed Dropdown text after selecting multiple Groups
            if ( optionsFromGroupsDropdown.size() > 2 ) {
                optionsFromGroupsDropdown.get( 0 ).click();
                optionsFromGroupsDropdown.get( 1 ).click();
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Count of selected group is Displayed",
                        "count of selected group name is not Displayed" );

            } else if ( optionsFromGroupsDropdown.size() == 2 ) {
                optionsFromGroupsDropdown.get( 0 ).click();
                optionsFromGroupsDropdown.get( 1 ).click();
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All Groups text and count of the Groups is Display Properly", "All Groups text or count of the Groups is not Display Properly" );

            } else {
                Log.message( "Given teacher has less than one group" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify 'students' dropdown field display under Filters option when more than one students are selected.", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 21 )
    public void tcSM_SPR016() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMSPR016:Verify 'students' dropdown field display under Filters option when more than one students are selected.<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );
            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdownwithJS( Constants.Reports.STUDENTS_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> allStudentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();

            // Verify thed Dropdown text after selecting multiple Students
            if ( allStudentsFromUI.size() > 2 ) {
                studentOptions.add( allStudentsFromUI.get( 0 ) );
                studentOptions.add( allStudentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_STUDENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Count of selected student is Displayed",
                        "count of selected student is not Displayed" );
            } else if ( allStudentsFromUI.size() == 2 ) {
                studentOptions.add( allStudentsFromUI.get( 0 ) );
                studentOptions.add( allStudentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_STUDENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All Students text and count of the Students is Display Properly", "AllStudents text or count of the Students is not Display Properly" );
            } else {
                Log.message( "Given teacher has less than one student" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify 'Assignments' dropdown field display under Filters option when more than one assignments are selected.", groups = { "SMK-39429", "reports", "StudentPerformanceReport" }, priority = 22 )
    public void tcSM_SPR017() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMSPR017:Verify 'Assignments' dropdown field display under Filters option when more than one assignments are selected.<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdownwithJS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMultiSelect();
            List<String> assignmentOptions = new ArrayList<>();
            // Verify the Dropdown text after selecting multiple assignment
            if ( assignmentsFromUI.size() > 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "Count of selected assignment is Displayed", "count of selected assignment name is not Displayed" );
            } else if ( assignmentsFromUI.size() == 3 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "3" ) ),
                        "All assignment text and count of the assignments is Display Properly", "All assignment text or count of the assignments is not Display Properly" );
            } else {
                Log.message( "Given teacher has less than one assignment" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in Student Performance Report", groups = { "SMK-40023", "Save reports options",
            "StudentPerformanceReport" }, priority = 19 )
    public void tcSM_SPRSavedReport001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSM_SPRSavedReport001:Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in Student Performance Repor<small><b><i>[" + browser
                + "]</b></i></small>" );
        reportComponent = new ReportComponent( driver );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> optionsFromSubjectDropDown = reportComponent.getValuesFromDropDownMS();
            List<String> subjectOption = new ArrayList<>();

            // Select Reading from subject dropdown
            subjectOption.add( optionsFromSubjectDropDown.get( 1 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );
            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Math subject alone in Student Performance Repor", groups = { "SMK-40023", "Save reports options",
            "StudentPerformanceReport" }, priority = 20 )
    public void tcSM_SPRSavedReport002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSM_SPRSavedReport002:Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Math subject alone in Student Performance Repor<small><b><i>[" + browser
                + "]</b></i></small>" );
        reportComponent = new ReportComponent( driver );

        try {

            studentLastName = SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,lastName" );
            sessionCookie = new BaseAPITest().getJessionCookie( smUrl, username, password );
            List<String> studentId = new ArrayList();
            studentId.add( SMUtils.getKeyValueFromResponse( DataSetup.teacherStudentMap.get( username ).get( "Student1" ), "data,personId" ) );
            new BaseAPITest().assignCourse( smUrl, sessionCookie, "Math", DataSetup.organizationId.toString(), SMUtils.getKeyValueFromResponse( teacherDetails, "data,personId" ), "1", studentId );
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> optionsFromSubjectDropDown = reportComponent.getValuesFromDropDownMS();
            List<String> subjectOption = new ArrayList<>();

            // Select Reading from subject dropdown
            subjectOption.add( optionsFromSubjectDropDown.get( 0 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );
            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if click the save button with empty Name in 'Save Report Option As' Popup on SPR ", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 21 )
    public void tcSM_SPRSavedReport003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport003: Verify if click the save button with empty Name in 'Save Report Option As' Popup on SPR <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            reportComponent.clickSaveReportOption();

            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "save button is not clickable with empty name", "save button is clickable with empty name" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if click the save button with already existing name in 'Save Report Option As' Popup on SPR", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 22 )
    public void tcSM_SPRSavedReport004() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport004:Verify if click the save button with already existing name in 'Save Report Option As' Popup on SPR <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // Save report options filter with new Name
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );

            // enter already existing name in the text box
            reportComponent.clickSaveReportOption();
            reportComponent.setReportFilterName( reportFilterName );
            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "save button is not clickable with already existing name", "save button is clickable with already existing name" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Math and Reading subject alone in Students Performance Report Page", groups = { "SMK-40023",
            "Save reports options", "StudentPerformanceReport" }, priority = 23 )
    public void tcSM_SPRSavedReport005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport005:Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Math and Reading subject alone in Students Performance Report Page<small><b><i>["
                + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            SPRPage reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            Log.assertThat( !( reportPage.isDateAtRiskDisplaying() ), "Date at risk dropdown is not dispalying", "Date at risk is displaying" );
            Log.assertThat( reportPage.isAODAsNo(), "Areas of disfficulty is NO", "Areas of disfficulty is YES " );
            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            SMUtils.logDescriptionTC( "SMK039429:-Verify user can filter all saved SPR under Saved Options dropdown on SPR page." );
            reportComponent.loadReportOption( reportFilterName );
            Log.assertThat( reportPage.isAODAsNo(), "Areas of disfficulty is NO for already  saved report", "Areas of disfficulty is YES for already save report " );
            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.SUBJECT_DROPDOWN ), "Select All is checked, Save report is showing math and reading", "Select All is not checked Save report is not showing math and reading" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = " Verify If teacher enter more than 50 characters in name text box ", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 24 )
    public void tcSM_SPRSavedReport006() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport006: Verify If User enter more than 50 characters in name text box<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // Click Save Report Option Link
            reportComponent.clickSaveReportOption();
            reportFilterName = Constants.Reports.SPR_SAVEDREPORT_NAME + System.nanoTime();
            reportComponent.typeReportName( reportFilterName );

            // Validate Error Message when Character Limit exceed
            reportComponent.getErrorMessageForExceedMaximumLength();
            // validate Save button enable or not after giving more than 50 cahr
            Log.assertThat( !reportComponent.isPopupSaveButtonEnable(), "save button is not clickable when teacher give more than 50 character", "save button is  clickable when teacher give more than 50 character" );

            // Validate Cancel Button is displaying and click cancel button
            Log.assertThat( reportComponent.isCancelBtnDisplayedOnSaveReport(), "Cancel Button on save report option Field is displaying on Poup", "Cancel Button on save report option Field is not displaying on Poup" );
            reportComponent.clickCancelButtonFromPopup();
            // Validate save report window pop up should not display

            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.REPORT_OPTION_HEADER ), "Saved Report Option window popup is not displaying now", "Saved Report Option window popup is  displaying" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify User can able to save the report option with name and default Values on SPR", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 25 )
    public void tcSM_SPRSavedReport007() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport007:Verify User can able to save the report option with name and default Values on SPR<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // Select all default value on SPR
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> loadedOptions = reportPage.getAllSelectedFilters( reportComponent );
            // Validate default retained after selecting the save report
            Log.assertThat( selectedOptions.equals( loadedOptions ), "All default values loaded properly after selecting save reports ", "All dafaul field not loaded Properly" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to select the one option in 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup on SPR.", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 26 )
    public void tcSM_SPRSavedReport008() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport008:Verify user can able to select the one option in 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup on SPR.<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );
            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            reportComponent.clickSaveReportOption();
            reportComponent.replaceExistingReport( Constants.Reports.CHOOSE_ONE );
            reportComponent.replaceExistingReport( reportFilterName );
            reportComponent.clickSaveOnSaveReportPopUp();
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> loadedOptions = reportPage.getAllSelectedFilters( reportComponent );
            // Validate default retained after selecting the save report
            Log.assertThat( selectedOptions.equals( loadedOptions ), "All default values loaded properly after selecting save reports ", "All dafaul field not loaded Properly" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify If delete the group after saved the report option with that student on SPR.", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 27 )
    public void tcSM_SPRSavedReport009() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport009:Verify If delete the group after saved the report option with that student on SPR<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            // getting the groups names from data setup
            List<String> groupsList = new ArrayList<>();
            String groupDetails = DataSetup.teacherGroupMap.get( username ).get( username );
            for ( int groupCount = 1; groupCount <= SMUtils.getWordCount( groupDetails, "groupName" ); groupCount++ ) {
                groupsList.add( SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", groupCount ) );
            }

            // Getting groups from UI
            reportComponent.setDropDownMS( "Groups" );

            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

            if ( groupsFromUI.size() > 0 ) {
                // getting Group Name
                String groupName = groupsFromUI.get( 0 );

                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String reportFilterName = "reportFilter" + System.nanoTime();
                reportComponent.saveReportOption( reportFilterName );

                // Delete Group
                GroupPage groupPage = tHomePage.topNavBar.navigateToGroupsTab();
                groupPage.viewGroup( groupName );
                // Need For Page load
                SMUtils.nap( 2 );
                groupPage.deleteGroup( groupName );

                // navigate to SPR Page
                reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

                // again Getting groups from UI
                reportComponent.setDropDownMS( "Groups" );
                groupsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

                // validate delete group should not display under groups
                // dropdown
                Log.assertThat( !( groupsFromUI.contains( groupName ) ), "Deleted Group is not present under Groups Dropdown", "Deleted Group is present under Groups Dropdown" );

                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( reportFilterName );

                // validate delete group should not display under groups
                // dropdown
                Log.assertThat( !( groupsFromUI.contains( groupName ) ), "Deleted Group is not present under Groups Dropdown fo saved report", "Deleted Group is present under Groups Dropdown for saved report" );

            } else {
                Log.message( "Given teacher don't have goups" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify If soft delete the assignment after saved the report option with that assignment on SPR", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 28 )
    public void tcSM_SPRSavedReport010() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport010:Verify If soft delete the assignment after saved the report option with that assignment on SPR<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            // Take all assignments from Data SetUp
            List<String> assignmnetsList = new ArrayList<>();
            String assignmentsDetails = DataSetup.teacherAssignmentMap.get( username ).get( username );
            for ( int assignmentsCount = 1; assignmentsCount <= SMUtils.getWordCount( assignmentsDetails, "name" ); assignmentsCount++ ) {
                assignmnetsList.add( SMUtils.getKeyValueFromJsonArray( assignmentsDetails, "name", assignmentsCount ) );
            }

            // Getting Assignments from UI
            reportComponent.setDropDownMS( "Assignments" );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

            if ( assignmentsFromUI.size() > 0 ) {
                // getting Assignment Name
                String assignmentsName = assignmentsFromUI.get( 0 );

                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String reportFilterName = "reportFilter" + System.nanoTime();
                reportComponent.saveReportOption( reportFilterName );
                // Navigate to Courseware tab
                AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

                // Click on Assignment SubMenu
                page.clickAssignmentSubMenu();

                // Click Delete Assignment
                AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( assignmentsName );
                assignmentDetailsPage.assignmentLevelEllipsis();
                assignmentDetailsPage.deleteAssignmenttab();
                SMUtils.nap( 2 );
                assignmentDetailsPage.deleteAssignmentButton();
                Log.assertThat( assignmentDetailsPage.isAssignmentDisplayed(), "Assignment has deleted successfully", "Assignment has not deleted successfully" );

                // navigate to SPR Report page
                tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
                reportComponent.setDropDownMS( "Assignments" );
                assignmentsFromUI = reportComponent.getValuesFromDropDownMultiSelect();

                Log.assertThat( !( assignmentsFromUI.contains( assignmentsName ) ), "Deleted assignments is not present under Assignments Dropdown", "Deleted assignments is present under assignments Dropdown" );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( reportFilterName );

                Log.assertThat( !( assignmentsFromUI.contains( assignmentsName ) ), "Deleted assignments is not present under Assignments Dropdown", "Deleted assignments is present under assignments Dropdown" );
            } else {
                Log.message( "Teacher dont have assignments" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to save the reports with Multiple groups and multiple Assignment on SPR.", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 29 )
    public void tcSM_SPRSavedReport011() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport011:Verify user can able to save the reports with Multiple groups and multiple Assignment on SPR.<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            // getting groups From UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupOptions = new ArrayList<>();

            // selecting one Group
            if ( groupsFromUI.size() >= 2 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                groupOptions.add( groupsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
            }

            // getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            // selecting multiple assignments
            if ( assignmentsFromUI.size() >= 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            }

            // getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();

        }
    }

    @Test ( description = "Verify user can able to save the reports with one Students and multiple Assignments on SPR.", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 30 )
    public void tcSM_SPRSavedReport012() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport012:Verify user can able to save the reports with one Students and multiple Assignments on SPR<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            // getting students From UI
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> studentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();

            // selecting one Student
            if ( studentsFromUI.size() >= 1 ) {
                studentOptions.add( studentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );
            }

            // getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            // selecting multiple assignments
            if ( assignmentsFromUI.size() >= 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            }

            // getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to save the reports with any one Group and All Assignments on SPR", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 31 )
    public void tcSM_SPRSavedReport013() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport013:Verify user can able to save the reports with any one Group and All Assignments on SPR<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            // getting groups From UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupOptions = new ArrayList<>();

            // selecting one Group
            if ( groupsFromUI.size() > 1 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
            }

            // getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to save the reports with All groups and one Assignment on SPR", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 32 )
    public void tcSM_SPRSavedReport014() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport014:Verify user can able to save the reports with All groups and one Assignment on SPR<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            // getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            // selecting one assignment
            if ( assignmentsFromUI.size() >= 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            }

            // getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to save the reports with All Students and one Assignments on SPR", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 33 )
    public void tcSM_SPRSavedReport015() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport015:Verify user can able to save the reports with All Students and one Assignments on SPR<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            // getting students From UI
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );

            // getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            // selecting one assignment
            if ( assignmentsFromUI.size() >= 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            }

            // getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify user can able to save the reports with multiple Students and Multiple Assignment on SPR", groups = { "SMK-40023", "Save reports options", "StudentPerformanceReport" }, priority = 34 )
    public void tcSM_SPRSavedReport016() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReport016:Verify user can able to save the reports with multiple Students and Multiple Assignment on SPR<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            // getting students From UI
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> studentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();

            // selecting multiple Students
            if ( studentsFromUI.size() >= 2 ) {
                studentOptions.add( studentsFromUI.get( 0 ) );
                studentOptions.add( studentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );
            }

            // getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            // selecting multiple assignments
            if ( assignmentsFromUI.size() >= 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            }

            // getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            // Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify P3 and P4 Test case for SPR", groups = { "SMK-39429", "Report", "Student Performance Report" }, priority = 35 )
    public void tcSM_SPRP3ANDP4UI_001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRP3ANDP4UI_001: Verify P3 and P4 Test case for SPR<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            // Getting groups names from UI
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            List<String> groupsList = groupsTab.getGroupNames();
            Collections.sort( groupsList );
            // navigate to LSR Page
            tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            // Validating groups names are listed in Groups drop-down
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsOnUI = reportComponent.getValuesFromDropDownMS();
            SMUtils.logDescriptionTC( "SMK-39429-Verify the Groups name should display in ascending order under Groups dropdown." );
            Log.assertThat( groupsList.equals( groupsOnUI ), "All Groups displayed successfully! in sorted order", "Groups not displayed properly in sorted order", driver );

            SMUtils.logDescriptionTC( "SMK-39429-Verify the Groups name should display in ascending order under Groups dropdown." );

            // Collapse and Expand the Filters
            SMUtils.logDescriptionTC( "SMK-39429-Verify the Filters option should be a expandable and collapse field." );
            reportComponent.collapseFilterButton();
            String expectedSubjectFiterCount = Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" );
            Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.SUBJECT_DROPDOWN ).equals( expectedSubjectFiterCount ), "count of Subject filters displayed Properly after collapse the fiters",
                    "count of Selected subject filter is not displayed Properly after collapse the fiters" );
            reportComponent.expandFilterButton();

            // Verify Select Groups or Students heading
            SMUtils.logDescriptionTC( "SMK-39429-Verify fields available after clicking on Filters option.." );
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.GROUP_OR_STUDENT_HEADER ), "Select Groups or Students heading is present in the SPR Page",
                    "Select Groups or Students heading is not present in the SPR Page" );

            SMUtils.logDescriptionTC( "SMK-39429-Verify 'Groups' dropdown should display under filters option." );
            // Verify group dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.GROUP_DROPDOWN ), "Group dropdown is present in the SPR Page", "Group dropdown is not present in the SPR Page" );

            SMUtils.logDescriptionTC( "SMK-39429-Verify 'Students' dropdown field display under Filters option." );
            // Verify student dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.STUDENTS_DROPDOWN ), "Student dropdown is present in the SPR Page", "Students dropdown is not present in the SPR Page" );

            // Verify Refine search heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.REFINE_SEARCH ), "Refine search heading is present in the SPR Page", "Refine search heading is present in the SPR Page" );

            // Verify subject dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject dropdown is present in the SPR Page", "Subjects dropdown is not present in the SPR Page" );

            SMUtils.logDescriptionTC( "SMK-39429-Verify 'Assignments' dropdown field display under Filters option." );
            // Verify assignment dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "Assignments dropdown is present in the SPR Page", "Assignments dropdown is not present in the SPR Page" );
            SMUtils.logDescriptionTC( "SMK-39429- Verify 'SELECT ALL' Check box under Assignment dropdown on SPR Page." );
            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "All the options in the drop down are selected by default", "All the options in the drop down are not selected by default" );
            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify P3 and P4 Test case for SPR", groups = { "SMK-39429", "Report", "Student Performance Report" }, priority = 36 )
    public void tcSM_SPRP3ANDP4UI_002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRP3ANDP4UI_002: Verify P3 and P4 Test case for SPR<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            Log.assertThat( !reportComponent.isSelectALLChecked( Constants.Reports.SUBJECT_DROPDOWN ), "Select all Unchecked", "Select all not yet unchecked" );

            // get WebElements of dopdown option checkboxes
            List<String> optionsFromSubjectDropDown = reportComponent.getValuesFromDropDownMS();
            List<String> subjectOption = new ArrayList<>();

            // Select Reading from subject dropdown
            subjectOption.add( optionsFromSubjectDropDown.get( 0 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );

            Log.assertThat( reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SPR_MATH ), "Math is selected for Subject filter", "Math is not selected for Subject filter" );

            reportComponent.collapseFilterButton();

            Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SPR_MATH ), "Teacher able to see Math while colapsing the Filters if Math subject is selected",
                    "Teacher is not able to see Math while colapsing the Filters if Math subject is selected" );

            reportComponent.expandFilterButton();

            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            // Select Reading from subject dropdown
            subjectOption.add( optionsFromSubjectDropDown.get( 0 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            Log.assertThat( reportComponent.getSelectedValuesFromDropDownMS( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SPR_READING ), "Reading is selected for Subject filter", "Reading is not selected for Subject filter" );

            reportComponent.collapseFilterButton();

            Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SPR_READING ), "Teacher able to see Reading while colapsing the Filters if Math subject is selected",
                    "Teacher is not able to see Reading while colapsing the Filters if Reading subject is selected" );

            reportComponent.expandFilterButton();

            SMUtils.logDescriptionTC( "SMK-39429:-Verify 'Run Report' button should display on SPR page." );
            Log.assertThat( reportPage.isRunReportDisplayed(), "Run report button is displaying", "Run report button is not displaying" );
            SMUtils.logDescriptionTC( "SMK-39429:-Verify 'Save Report Option' button should display on SPR page." );
            Log.assertThat( reportPage.isSaveReportDisplayed(), "Save report options link is displaying", "Save report options link is not displaying" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify count of all Groups/Students and Assignments should display beside filters,if filters has collapsed.", groups = { "SMK-39429", "Report", "Student Performance Report" }, priority = 37 )
    public void tcSM_SPRP3ANDP4UI_003() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRP3ANDP4UI_003:Verify count of all Groups/Students and Assignments should display beside filters,if filters has collapsed.<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> groupOptions = new ArrayList<>();

            // selecting one group
            if ( groupsFromUI.size() > 1 ) {
                groupOptions.add( groupsFromUI.get( 0 ) );
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.GROUPS_SELECTED_COUNT.replace( Constants.Reports.SELECTED_COUNT, "1" );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.GROUP_DROPDOWN ).equals( expectedFiltersCount ), "Count of Selected Group filters displayed Properly after collapse the fiters",
                        "Count of Selected Group filter is not displayed Properly after collapse the fiters" );

                reportComponent.expandFilterButton();
            } else {
                Log.message( "Teacher don't have enough group" );
            }

            // deSelect all the group
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            // selecting All groups
            if ( groupsFromUI.size() > 0 ) {
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.SELECTED_ALL_GROUPS.replace( Constants.Reports.SELECTED_COUNT, Integer.toString( groupsFromUI.size() ) );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.GROUP_DROPDOWN ).equals( expectedFiltersCount ), "Count of all Group is displayed Properly after collapse the fiters",
                        "Count of all Group is not displayed Properly after collapse the fiters" );
                reportComponent.expandFilterButton();
            } else {
                Log.message( "Teacher don't have enough group" );
            }

            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> studentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> studentOptions = new ArrayList<>();

            // selecting one student
            if ( studentsFromUI.size() > 1 ) {
                studentOptions.add( studentsFromUI.get( 0 ) );
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );
                reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, studentOptions );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.STUDENTS_SELECTED_COUNT.replace( Constants.Reports.SELECTED_COUNT, "1" );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.STUDENTS_DROPDOWN ).equals( expectedFiltersCount ), "Count of Selected student filters displayed Properly after collapse the fiters",
                        "Count of Selected student filter is not displayed Properly after collapse the fiters" );

                reportComponent.expandFilterButton();

            } else {
                Log.message( "Teacher don't have enough student" );
            }

            // deSelect all the group
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // selecting All students
            if ( studentsFromUI.size() > 0 ) {
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.SELECTED_ALL_STUDENTS.replace( Constants.Reports.SELECTED_COUNT, Integer.toString( studentsFromUI.size() ) );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.STUDENTS_DROPDOWN ).equals( expectedFiltersCount ), "Count of all student is displayed Properly after collapse the fiters",
                        "Count of all student is not displayed Properly after collapse the fiters" );

                reportComponent.expandFilterButton();
            } else {
                Log.message( "Teacher don't have enough student" );
            }

            reportComponent.setDropDownMS( Constants.Reports.SUBJECT_DROPDOWN );
            List<String> optionsFromSubjectDropDown = reportComponent.getValuesFromDropDownMS();
            List<String> subjectOption = new ArrayList<>();

            // Select Math from subject dropdown
            subjectOption.add( optionsFromSubjectDropDown.get( 0 ) );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            reportComponent.collapseFilterButton();
            String expectedFilters = optionsFromSubjectDropDown.get( 0 );
            Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.SUBJECT_DROPDOWN ).equals( expectedFilters ), "Subject filters displayed Properly after collapse the fiters",
                    "Selected subject filter is not displayed Properly after collapse the fiters" );
            reportComponent.expandFilterButton();
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            // Selecting All subject filters
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.collapseFilterButton();
            String expectedSubjectFiterCount = Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" );
            Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.SUBJECT_DROPDOWN ).equals( expectedSubjectFiterCount ), "count of Subject filters displayed Properly after collapse the fiters",
                    "count of Selected subject filter is not displayed Properly after collapse the fiters" );
            reportComponent.expandFilterButton();

            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            // selecting one assignment
            if ( assignmentsFromUI.size() > 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.ASSIGNMENTS_SELECTED_COUNT.replace( Constants.Reports.SELECTED_COUNT, "1" );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( expectedFiltersCount ), "Count of Selected assignment filters displayed Properly after collapse the fiters",
                        "Count of Selected assignment filter is not displayed Properly after collapse the fiters" );

                reportComponent.expandFilterButton();

            } else {
                Log.message( "Teacher don't have enough Assignments" );
            }

            // deSelect all the assignment
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );

            // selecting all assignment
            if ( assignmentsFromUI.size() > 0 ) {

                reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );

                reportComponent.collapseFilterButton();

                String expectedFiltersCount = Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, Integer.toString( assignmentsFromUI.size() ) );

                Log.assertThat( reportComponent.getCountOfSelectedFilter( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( expectedFiltersCount ), "Count of all assignment filters displayed Properly after collapse the fiters",
                        "Count of all assignment filter is not displayed Properly after collapse the fiters" );
            } else {
                Log.message( "Teacher don't have enough Assignments" );
            }

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Test case for Student performance report", groups = { "SMK-39429", "Report", "Student Performance Report" }, priority = 37 )
    public void tcSM_SPRP3ANDP4UI_004() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRP3ANDP4UI_004:P3 and P4 Test case for Student performance report <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            tHomePage.topNavBar.navigateToAssignmentsPage();
            AssignmentsPage assignmentpage = new AssignmentsPage( driver );

            List<String> actualAssignmenstList = new ArrayList<>();
            List<String> assignmentsList = assignmentpage.assignmentsList();

            Collections.sort( assignmentsList );
            for ( String value : assignmentsList ) {
                actualAssignmenstList.add( value.trim() );
            }
            tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> valuesFromDropDownMS = reportComponent.getValuesFromDropDownMS();

            Log.assertThat( valuesFromDropDownMS.equals( actualAssignmenstList ), "All assignments are listed in Assignments dropdown in sorted order", "Assignments dropdowm is not listed all assignments in sorted order" );

            // Take all student from Data SetUp
            List<String> studentsList = new ArrayList<>();

            IntStream.rangeClosed( 1, DataSetupConstants.STUDENT_COUNT ).forEach( studentCount -> {
                String studentsDetails = DataSetup.teacherStudentMap.get( username ).get( String.format( "Student%s", studentCount ) );
                studentsList.add( SMUtils.getKeyValueFromResponse( studentsDetails, "data,lastName" ) );
            } );
            Collections.sort( studentsList );
            //getting students From UI
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> studentsFromUI = reportComponent.getValuesFromDropDownMS();

            Log.assertThat( IntStream.range( 0, DataSetupConstants.STUDENT_COUNT ).allMatch( studentCount -> studentsFromUI.get( studentCount ).contains( studentsList.get( studentCount ) ) ), "Student name is displaying in order",
                    "Stundet name is not diplaying in order" );
            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Cases for Student performance report", groups = { "SMK-39429", "Report", "Student Performance Report" }, priority = 37 )
    public void tcSM_SPRP3ANDP4UI_005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRP3ANDP4UI_005: P3 and P4 Cases for Student performance report <small><b><i>[" + browser + "]</b></i></small>" );

        String teacherUsername = "AutomatedTeacher_ForZeroState" + System.nanoTime();
        //Creating teacher for Zero state test
        new UserSqlHelper().createTeacher( teacherUsername, teacherUsername, teacherUsername, Constants.PASSWORD_HASH, DataSetup.organizationId );

        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( teacherUsername, password, true );

            // Initiating the reports filter components
            reportComponent = new ReportComponent( driver );

            // Navigate to Mastery Tab
            StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

            String studentID = studentsPage.createStudent();
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();

            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );

            Log.assertThat( reportComponent.getZeroStateTextGroups().equalsIgnoreCase( Constants.Reports.ZERO_STATE_TEXT_GRP ), "Zero state message is displaying for group", "Zero state message is not displaying" );
            Log.assertThat( reportComponent.getZeroStateTextAssignments().equalsIgnoreCase( Constants.Reports.ZERO_STATE_TEXT_ASSIGNMENTS ), "Zero state message is displaying for assignments", "Zero state message is not displaying" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Save Report Test cases for Student Performance", groups = { "SMK-40022", "Save reports options", "StudentPerformanceReport" }, priority = 34 )
    public void tcSM_SPRSavedReportP3P4_001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReportP3P4_001:P3 and P4 Save Report Test cases for Student Performance<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            reportPage.clickMaskStudentCB();
            reportPage.clickIncludePerformaceSummaryradioButton();
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.SPR_LANGUAGE_DROPDOWN, Constants.Reports.SPR_SPANISH );
            reportComponent.clickSaveReportOption();
            Log.assertThat( reportComponent.getSaveReportPopUpTextHeader().equals( Constants.Reports.SPR_SAVEREPORT_POUP_HEADER ), "Save Report Option As Is displaying", "Save Report Option As is not displaying" );
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equalsIgnoreCase( Constants.Reports.STUDENTID ), "Student ID is selected while selecting save report",
                    "Student ID is not selected while selecting save report" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SPR_LANGUAGE_DROPDOWN ).equalsIgnoreCase( Constants.Reports.SPR_SPANISH ), "Spanish language is selected while selecting save report",
                    "Spanish language is not selected while selecting save report" );
            Log.assertThat( !reportPage.isPerformanceSummaryYes(), "Performance By Summary is selected as No", "Performance By Summary is not selected as No" );

            Log.assertThat( reportPage.isMaskStudentSelected(), "Mask Student is selected", "Mask Student is not selected" );
            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Save Report Test cases for Student Performance", groups = { "SMK-40022", "Save reports options", "StudentPerformanceReport" }, priority = 34 )
    public void tcSM_SPRSavedReportP3P4_002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReportP3P4_002:P3 and P4 Save Report Test cases for Student Performance<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENT_USERNAME );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.SPR_LANGUAGE_DROPDOWN, Constants.Reports.ENGLISH );
            reportPage.clickIncludePerformaceByStarndRadioButton();
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equalsIgnoreCase( Constants.Reports.STUDENT_USERNAME ), "Student Username is selected while selecting save report",
                    "Student username is not selected while selecting save report" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SPR_LANGUAGE_DROPDOWN ).equalsIgnoreCase( Constants.Reports.ENGLISH ), "English language is selected while selecting save report",
                    "English language is not selected while selecting save report" );

            Log.assertThat( !reportPage.isPerformanceByStrandYes(), "Performance by stard is displaying No", "Performance by stard is not displaying No" );
            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Save Report Test cases for Student Performance", groups = { "SMK-40022", "Save reports options", "StudentPerformanceReport" }, priority = 34 )
    public void tcSM_SPRSavedReportP3P4_003() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReportP3P4_003:P3 and P4 Save Report Test cases for Student Performance<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.SPR_LANGUAGE_DROPDOWN, Constants.Reports.ENGLISH );
            reportPage.clickIncludePerformaceSummaryradioButton();
            reportPage.clickAODRdiobutton();
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            // load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equalsIgnoreCase( Constants.Reports.STUDENTID ), "Student ID is selected while selecting save report",
                    "Student ID is not selected while selecting save report" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SPR_LANGUAGE_DROPDOWN ).equalsIgnoreCase( Constants.Reports.ENGLISH ), "English language is selected while selecting save report",
                    "English language is not selected while selecting save report" );
            Log.assertThat( !reportPage.isPerformanceSummaryYes(), "Performance By Summary is selected as No", "Performance By Summary is not selected as No" );
            Log.assertThat( reportPage.isAODAsNo(), "AOD is no is displaying after selecting saved report", "AOD is no is not displaying after selecting saved report" );
            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Save Report Test cases for Student Performance", groups = { "SMK-40022", "Save reports options", "StudentPerformanceReport" }, priority = 34 )
    public void tcSM_SPRSavedReportP3P4_004() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReportP3P4_004:P3 and P4 Save Report Test cases for Student Performance<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            //getting assignments From UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> assignmentOptions = new ArrayList<>();

            //selecting one assignment
            if ( assignmentsFromUI.size() >= 1 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
            }

            //getting all the selected filter
            HashMap<String, String> selectedOptions = reportPage.getAllSelectedFilters( reportComponent );

            //Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            //load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            HashMap<String, String> LoadedOptions = reportPage.getAllSelectedFilters( reportComponent );

            Log.assertThat( selectedOptions.equals( LoadedOptions ), "Filters loaded Successfully.", "Filters not loaded properly." );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Save Report Test cases for Student Performance", groups = { "SMK-40022", "Save reports options", "StudentPerformanceReport" }, priority = 34 )
    public void tcSM_SPRSavedReportP3P4_005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReportP3P4_005:P3 and P4 Save Report Test cases for Student Performance<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            reportPage.clickAODRdiobutton();
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENT_USERNAME );
            reportPage.clickMaskStudentCB();
            reportPage.clickIncludePerformaceByStarndRadioButton();
            //Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            //load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            Log.assertThat( reportPage.isAODAsNo(), "AOD is no is displaying after selecting saved report", "AOD is no is not displaying after selecting saved report" );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equalsIgnoreCase( Constants.Reports.STUDENT_USERNAME ), "Student Username is selected while selecting save report",
                    "Student username is not selected while selecting save report" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SPR_LANGUAGE_DROPDOWN ).equalsIgnoreCase( Constants.Reports.ENGLISH ), "English language is selected while selecting save report",
                    "English language is not selected while selecting save report" );

            Log.assertThat( !reportPage.isPerformanceByStrandYes(), "Performance by stard is displaying No", "Performance by stard is not displaying No" );
            Log.assertThat( reportPage.isMaskStudentSelected(), "Mask Student is selected", "Mask Student is not selected" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Save Report Test cases for Student Performance", groups = { "SMK-40022", "Save reports options", "StudentPerformanceReport" }, priority = 34 )
    public void tcSM_SPRSavedReportP3P4_006() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReportP3P4_006:P3 and P4 Save Report Test cases for Student Performance<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            reportPage.clickAODRdiobutton();
            reportPage.clickIncludePerformaceByStarndRadioButton();
            reportPage.clickIncludePerformaceSummaryradioButton();
            reportPage.clickMaskStudentCB();
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENTID );
            //Click SaveReport Option
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            //load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );

            Log.assertThat( reportPage.isAODAsNo(), "AOD is no is displaying after selecting saved report", "AOD is no is not displaying after selecting saved report" );
            Log.assertThat( !reportPage.isPerformanceByStrandYes(), "Performance by stard is displaying No", "Performance by stard is not displaying No" );
            Log.assertThat( !reportPage.isPerformanceByStrandYes(), "Performance by stard is displaying No", "Performance by stard is not displaying No" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equalsIgnoreCase( Constants.Reports.STUDENTID ), "Student ID is selected while selecting save report",
                    "Student ID is not selected while selecting save report" );
            Log.assertThat( reportPage.isMaskStudentSelected(), "Mask Student is selected", "Mask Student is not selected" );
            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "P3 and P4 Save Report Test cases for Student Performance", groups = { "SMK-40022", "Save reports options", "StudentPerformanceReport" }, priority = 34 )
    public void tcSM_SPRSavedReportP3P4_007() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SPRSavedReportP3P4_007:P3 and P4 Save Report Test cases for Student Performance<small><b><i>[" + browser + "]</b></i></small>" );

        username = "pm_teacher1";
        password = "pm_teacher1";

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );
            // Navigate to SPR Page
            reportPage = tHomePage.topNavBar.navigateToReportsStudentPerformanceTab();
            reportComponent.getReportPageHeader();
            Log.message( "Student Performance page has loaded" );
            reportPage.clickIncludePerformaceByStarndRadioButton();
            reportPage.clickIncludePerformaceSummaryradioButton();
            reportPage.clickMaskStudentCB();
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DATE_AT_RISK_DROPDOWN, Constants.Reports.SINCE_IP );
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName );
            //load report
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportFilterName );
            Log.assertThat( !reportPage.isPerformanceByStrandYes(), "Performance by stard is displaying No", "Performance by stard is not displaying No" );
            Log.assertThat( !reportPage.isPerformanceByStrandYes(), "Performance by stard is displaying No", "Performance by stard is not displaying No" );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equalsIgnoreCase( Constants.Reports.STUDENTID ), "Student ID is selected while selecting save report",
                    "Student ID is not selected while selecting save report" );

            Log.assertThat( reportPage.isMaskStudentSelected(), "Mask Student is selected", "Mask Student is not selected" );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DATEATRISK_DROPDOWN ).equalsIgnoreCase( Constants.Reports.SINCE_IP ), "Since IP is selected in Date at risk", "Since IP is not selected in Date at risk" );

            //SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            //Log message for test case
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }
}