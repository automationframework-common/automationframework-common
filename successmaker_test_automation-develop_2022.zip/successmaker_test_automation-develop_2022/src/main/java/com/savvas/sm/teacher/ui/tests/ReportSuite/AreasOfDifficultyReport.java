package com.savvas.sm.teacher.ui.tests.ReportSuite;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.ReportComponent;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.sql.helper.UserSqlHelper;

import LSTFAI.customfactories.EventFiringWebDriver;

public class AreasOfDifficultyReport extends BaseTest {
    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;

    TeacherHomePage teacherHomePage;
    LoginPage smLoginPage;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher8" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( description = "Verify Areas of difficulty Report (AOD) should display under Reports menu and verify the header and description text in Areas of Difficulty Page", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD001() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAOD001: Verify Areas of difficulty Report (AOD) should display under Reports menu and verify the header and description text in Areas of Difficulty Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Verify Area of Difficulty Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.AOD_REPORT ), "Areas of difficulty Report sub menu is Present under report menu", "Areas of difficulty Report sub menu is not Present under report menu" );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Verify the header and description in Area of Difficulty Page
            Log.assertThat( reportComponent.getReportPageHeader().equals( Constants.Reports.AOD_HEADER ), "Areas of difficulty Report header is Present", "Areas of difficulty Report header is not Present" );

            // Verifying AOD Report Description report
            Log.assertThat( reportComponent.getReportDescription().equals( Constants.Reports.AOD_DESCRIPTION ), "Areas of difficulty Report description is present and displayed as expected",
                    "Areas of difficulty Report description is not Present or displaying wrong text" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all fields are available in the Area of Difficulty Report page.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD002: Verify all fields are available in the Area of Difficulty Report page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Verify Area of Difficulty Sub menu
            Log.assertThat( teacherHomePage.topNavBar.isReportNameDisplayed( Constants.Reports.AOD_REPORT ), "Areas of difficulty Report sub menu is Present under report menu", "Areas of difficulty Report sub menu is not Present under report menu" );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Verify the available fields in the Area of Difficulty Page

            // Verify AOD header
            Log.assertThat( reportComponent.getReportPageHeader().equals( Constants.Reports.AOD_HEADER ), "Areas of Difficulty Report header is Present", "Areas of Difficulty Report header is not Present" );

            // Verify Filters heading
            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.FILTERS ), "Filters heading is present in the AOD Page", "Filters heading is not present in the AOD Page" );

            // Verify Select Groups or Students heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.GROUP_OR_STUDENT_HEADER ), "Select Groups or Students heading is present in the AOD Page",
                    "Select Groups or Students heading is not present in the AOD Page" );

            // Verify group dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.GROUP_DROPDOWN ), "Group dropdown is present in the AOD Page", "Group dropdown is not present in the AOD Page" );

            // Verify student dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.STUDENTS_DROPDOWN ), "Student dropdown is present in the AOD Page", "Students dropdown is not present in the AOD Page" );

            // Verify Refine search heading
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.REFINE_SEARCH ), "Refine search heading is present in the AOD Page", "Refine search heading is present in the AOD Page" );

            // Verify subject dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject dropdown is present in the AOD Page", "Subjects dropdown is not present in the AOD Page" );

            // Verify assignment dropdown heading
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.ASSIGNMENTS_DROPDOWN ), "Assignments dropdown is present in the AOD Page", "Assignments dropdown is not present in the AOD Page" );

            // Verify Report option heading
            Log.assertThat( reportComponent.isFilterAndReportOptionsHeadingPresent( Constants.Reports.REPORT_OPTION_HEADER ), "Report option heading is present in the AOD Page", "Report option heading is not present in the AOD Page" );

            // Verify Saved Option dropdown heading
            Log.assertThat( reportComponent.isSavedOptionDropdownHeadingPresent(), "Saved Option dropdown is present in the AOD Page", "Saved Option dropdown is not present in the AOD Page" );

            // Verify additional grouping dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.ADDITIONAL_GROUPING ), "Additional grouping dropdown heading is present in the AOD Page", "Additional grouping dropdown is not present in the AOD Page" );

            // Verify Display dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.DISPLAY_DROPDOWN ), "Display dropdown heading is present in the AOD Page", "Display dropdown heading is not present in the AOD Page" );

            // Verify Display dropdown heading
            Log.assertThat( reportComponent.isStaticDropdownHeadingPresent( Constants.Reports.SORT_DROPDOWN ), "Sort dropdown heading is present in the AOD Page", "Sort dropdown heading is not present in the AOD Page" );

            // Verify Remove page break field
            Log.assertThat( reportComponent.isMaskStudentDisplayAndRemovePageBreakFieldDisplayed( Constants.Reports.MASK_STUDENT_DISPLAY ), "Mask student display is present in the AOD page", "Mask student display field is not present in the AOD page" );

            // Verify Mask student display field
            Log.assertThat( reportComponent.isMaskStudentDisplayAndRemovePageBreakFieldDisplayed( Constants.Reports.REMOVE_PAGE_BREAKS ), "Remove page break field is present in the AOD page", "Remove page break field is not present in the AOD page" );

            // Verify Save Report Option button
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getSaveReportOptionButton() ), "Saved Report option button is present", "Saved Report option button is not present!" );

            // Verify Run Report
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getRunReportOption() ), "Run report button present!", "Run report not button present!" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the group names listed in the Groups dropdown and able to select one or more groups from the drop down", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD003() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD003: Verify the group names listed in the Groups dropdown and able to select one or more groups from the drop down <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.GROUP_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> allGroupsFromUI = reportComponent.getValuesFromDropDownMS();

            // Verify the Dropdown text after selecting multiple Groups
            List<String> groupOptions = new ArrayList<>();

            if ( allGroupsFromUI.size() > 2 ) {
                groupOptions.add( allGroupsFromUI.get( 0 ) );
                groupOptions.add( allGroupsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ), "Count of selected group is Displayed",
                        "count of selected group name is not Displayed" );
            } else if ( allGroupsFromUI.size() == 2 ) {
                groupOptions.add( allGroupsFromUI.get( 0 ) );
                groupOptions.add( allGroupsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.GROUP_DROPDOWN, groupOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_GROUPS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All Groups text and count of the Groups is Display Properly", "All Groups text or count of the Groups is not Display Properly" );
            } else {
                Log.message( "Given teacher has less than one goup" );
            }

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );

        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Removed group should not display in the Groups dropdown.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAOD004: Verify the Removed group should not display in the Groups dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Getting the groups names from data setup
            List<String> groupsList = new ArrayList<>();
            String groupDetails = DataSetup.teacherGroupMap.get( username ).get( username );
            for ( int groupCount = 1; groupCount <= SMUtils.getWordCount( groupDetails, "groupName" ); groupCount++ ) {
                groupsList.add( SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", groupCount ) );
            }

            // Getting groups from UI
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            Log.assertThat( groupsList.equals( groupsFromUI ), "All Groups displayed successfully!", "Groups not displayed properly" );

            if ( groupsFromUI.size() > 0 ) {
                // getting Group Name
                String groupName = groupsFromUI.get( 0 );

                // Delete Group
                GroupPage groupPage = teacherHomePage.topNavBar.navigateToGroupsTab();
                groupPage.viewGroup( groupName );
                SMUtils.nap( 2 ); //needed for page load
                groupPage.deleteGroup( groupName );

                // navigate to CPR Page
                teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

                // again Getting groups from UI
                reportComponent.setDropDownMS( "Groups" );
                groupsFromUI = reportComponent.getValuesFromDropDownMS();

                // validate delete group should not display under groups dropdown
                Log.assertThat( !( groupsFromUI.contains( groupName ) ), "Deleted Group is not present under Groups Dropdown", "Deleted Group is present under Groups Dropdown" );

                // SignOut from SM
                teacherHomePage.topNavBar.signOutfromSM();
            }
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Student names listed in the Students dropdown.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD005: Verify the Student names listed in the Students dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Check Students RB
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );

            // get WebElements of dropdown option checkboxes
            List<String> allStudentsFromUI = reportComponent.getValuesFromDropDownMS();
            // getting the Student names from data setup
            List<String> studentList = new ArrayList<>();
            List<String> studentFirstNameAndLastNameList = new ArrayList<>();
            for ( int studentCount = 1; studentCount <= DataSetup.teacherStudentMap.get( username ).size(); studentCount++ ) {
                studentList.add( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ) );
                studentFirstNameAndLastNameList.add( SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,middleName" ) + ". "
                        + SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,lastName" ) );
            }

            Log.assertThat( studentFirstNameAndLastNameList.containsAll( allStudentsFromUI ), "All Students displayed properly in the student dropdown!", "Students not displayed properly in thes student dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the assignments listed in the Assignments dropdown and able to select one or more assignments.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD006() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD006: Verify the assignments listed in the Assignments dropdown and able to select one or more assignments. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Getting assignments from UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();

            // getting the Assignment List from data setup
            List<String> assignmentList = new ArrayList<>();
            String assignments = DataSetup.teacherAssignmentMap.get( username ).get( username );
            for ( int assignmentCount = 1; assignmentCount <= SMUtils.getWordCount( assignments, "name" ); assignmentCount++ ) {
                assignmentList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", assignmentCount ) );
            }

            Log.assertThat( assignmentList.containsAll( assignmentsFromUI ), "All assignments displayed properly in the assignment dropdown!", "Assignments not displayed properly in thes assignment dropdown" );

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentOptions = new ArrayList<>();
            // Verify the Dropdown text after selecting multiple assignment
            if ( assignmentsFromUI.size() > 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "Count of selected assignment is Displayed", "count of selected assignment name is not Displayed" );
            } else if ( assignmentsFromUI.size() == 2 ) {
                assignmentOptions.add( assignmentsFromUI.get( 0 ) );
                assignmentOptions.add( assignmentsFromUI.get( 1 ) );
                reportComponent.selectDropdownMSOptions( Constants.Reports.ASSIGNMENTS_DROPDOWN, assignmentOptions );
                Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "All assignment text and count of the assignments is Display Properly", "All assignment text or count of the assignments is not Display Properly" );
            } else {
                Log.message( "Given teacher has less than two assignment" );
            }
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the removed Assignments should not display in the Assignments dropdown.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD007: Verify the removed Assignments should not display in the Assignments dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Getting Assignments List from UI
            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();

            if ( assignmentsFromUI.size() > 0 ) {
                // getting Assignment Name
                String assignmentsName = assignmentsFromUI.get( 0 );
                // Navigate to Courseware tab
                AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

                // Click on Assignment SubMenu
                page.clickAssignmentSubMenu();

                // Click Delete Assignment
                AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName( assignmentsName );
                assignmentDetailsPage.assignmentLevelEllipsis();
                assignmentDetailsPage.deleteAssignmenttab();
                SMUtils.nap( 2 );
                assignmentDetailsPage.deleteAssignmentButton();
                Log.assertThat( assignmentDetailsPage.isAssignmentDisplayed(), "Assignment has deleted successfully", "Assignment has not deleted successfully" );

                // navigate to AOD Report page
                teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();
                reportComponent.setDropDownMS( "Assignments" );
                assignmentsFromUI = reportComponent.getValuesFromDropDownMS();

                // validate delete group should not display under groups dropdown
                Log.assertThat( !( assignmentsFromUI.contains( assignmentsName ) ), "Deleted assignments is not present under Assignments Dropdown", "Deleted assignments is present under assignments Dropdown" );
            }
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all available fields under the 'Additional grouping' dropdown and able to select one option in the drop down on AOD page.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD008() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD008: Verify all available fields under the 'Additional grouping' dropdown and able to select one option in the drop down on AOD page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Verify all available fields
            Log.assertThat( reportComponent.isAdditionalGroupingDropdownPresent(), "Additional Grouping dropdown is present", "Additional Grouping dropdown is not present" );

            List<String> additionalGroupingvalues = reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN );
            Log.assertThat( additionalGroupingvalues.containsAll( Constants.Reports.ADDITION_GROUPING ), "All the Additional Grouping drop down values are displayed", "All the Additional Grouping drop down values are not displayed" );

            // Verify user can able to select one option
            Log.assertThat( reportComponent.selectValueFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, Constants.Reports.GRADES ), "The given option is selected in the Additional Grouping Drop down",
                    "The given option is selected in the Additional Grouping Drop down" );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.GRADES ), "The selected option is verified", "The selected option is not verified" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all available fields under the 'Display' dropdown and able to select one option in the drop down on AOD page.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD009: Verify all available fields under the 'Display' dropdown and able to select one option in the drop down on AOD page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Verify all available fields
            Log.assertThat( reportComponent.isDisplayDropdownPresent(), "Display dropdown is present", "Display dropdown is not present" );

            List<String> displayValues = reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.DISPLAY_DROPDOWN );
            Log.assertThat( displayValues.containsAll( Constants.Reports.DISPLAY ), "All the Display drop down values are displayed", "All the Display drop down values are not displayed" );

            // Verify user can able to select one option
            Log.assertThat( reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENTID ), "The given option is selected in the Display Drop down",
                    "The given option is selected in the Display Drop down" );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equals( Constants.Reports.STUDENTID ), "The selected option is verified", "The selected option is not verified" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify all available fields under the 'Sort' dropdown and able to select one option in the drop down on AOD page.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD010() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD010: Verify all available fields under the 'Sort' dropdown and able to select one option in the drop down on AOD page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Verify all available fields
            Log.assertThat( reportComponent.isSortDropdownPresent(), "Sort dropdown is present", "Sort dropdown is not present" );

            List<String> displayValues = reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.SORT_DROPDOWN );
            Log.assertThat( displayValues.containsAll( Constants.Reports.AOD_SORT ), "All the Sort drop down values are displayed", "All the Sort drop down values are not displayed" );

            // Verify user can able to select one option
            Log.assertThat( reportComponent.selectValueFromStaticDropdown( Constants.Reports.SORT_DROPDOWN, Constants.Reports.LEVEL ), "The given option is selected in the Sort Drop down", "The given option is selected in the Sort Drop down" );

            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Constants.Reports.LEVEL ), "The selected option is verified", "The selected option is not verified" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify 'Remove Page Breaks' and 'Mask Student Display' checkboxes on AOD page.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD011: Verify 'Remove Page Breaks' and 'Mask Student Display' checkboxes on AOD page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Verify Remove Page Breaks
            reportComponent.checkOrUncheckRemovePageBreak();
            Log.assertThat( reportComponent.isRemovePageBreakChecked(), "The Remove Page Breaks check box is clickable and clicked", "The Remove Page Breaks check box is not clickable and clicked" );

            // Verify Mask Student Display
            reportComponent.checkOrUncheckMaskStudentDisplay();
            Log.assertThat( reportComponent.isMaskStudentDisplayChecked(), "The Mask Student Display check box is clickable and clicked", "The Mask Student Display check box is not clickable and clicked" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify all available fields under the 'Date at Risk' dropdown and able to select one option from the drop down on AOD page.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD012() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD012: Verify all available fields under the 'Date at Risk' dropdown and able to select one option from the drop down on AOD page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Verify all available fields
            Log.assertThat( reportComponent.isDateAtRiskDropdownPresent(), "Date At Risk dropdown is present", "Date At Risk dropdown is not present" );

            List<String> displayValues = reportComponent.getValuesFromStaticDropDownMS( Constants.Reports.DATE_AT_RISK_DROPDOWN );

            boolean flag = true;
            // Log.assertThat( displayValues.containsAll( Constants.Reports.AOD_DATE_AT_RISK ), "All the Date at Risk drop down values are displayed", "All the Date at Risk drop down values are not displayed" );
            if ( displayValues.size() == Constants.Reports.AOD_DATE_AT_RISK.size() ) {
                for ( int i = 0; i < displayValues.size(); i++ ) {
                    if ( !displayValues.get( i ).equalsIgnoreCase( Constants.Reports.AOD_DATE_AT_RISK.get( i ) ) ) {
                        flag = false;
                    }
                }
                Log.assertThat( flag, "All the Date at Risk drop down values are displayed", "All the Date at Risk drop down values are not displayed" );
            }

            // Verify user can able to select one option
            Log.assertThat( reportComponent.selectValueFromStaticDropdown( Constants.Reports.DATE_AT_RISK_DROPDOWN, Constants.Reports.WEEKS_20 ), "The given option is selected in the Date at Risk Drop down",
                    "The given option is selected in the Date at Risk Drop down" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Save Report Option Link in available in AOD page and all fields are available in Save Report Option Pop-up", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD013() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD013: Verify Save Report Option Link in available in AOD page and all fields are available in Save Report Option Pop-up <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Verify Save Report Option is available in the AOD Page

            reportComponent.clickSaveReportOption();
            Log.assertThat( reportComponent.getSaveReportPopUpTextHeader().equals( Constants.Reports.SAVEREPORT_POUP_HEADER ), "Save Report Pop up is displayed and verified the header", "Save Report Pop up is not displayed and verified the header" );

            // Verifying all available fields in Save Report Option
            Log.assertThat( reportComponent.getSaveReportOptionFieldHeaders( Constants.Reports.NEW_HEADER_SAVEREPORT ).equals( Constants.Reports.NEW_HEADER_SAVEREPORT ), "New Radio button is displayed in Save Report Popup",
                    "New Radio button is displayed in Save Report Popup" );
            Log.assertThat( reportComponent.getSaveReportOptionFieldHeaders( Constants.Reports.REPLACE_EXISTING_HEADER ).equals( Constants.Reports.REPLACE_EXISTING_HEADER ), "Replace Existing Radio button is displayed in Save Report Popup",
                    "Replace Existing Radio button is displayed in Save Report Popup" );
            Log.assertThat( reportComponent.saveBtnOnSaveReportPopUp().equalsIgnoreCase( Constants.Reports.SAVEBTN_SAVEREPORT_OPTION ), "Save button is displayed in Save Report Popup", "Save button is not displayed in Save Report Popup" );
            Log.assertThat( reportComponent.cancelBtnOnSaveReportPopUp().equals( Constants.Reports.CANCELBTN_SAVEREPORT_OPTION ), "Cancel button is displayed in Save Report Popup", "Cancel button is not displayed in Save Report Popup" );
            reportComponent.clickcancelButtoninSaveReportPopup();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify User can able to save the report option with new name.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD014() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD014: Verify User can able to save the report option with new name. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyy/MM/dd HH:mm:ss" );
            String reportName = "New Saved Report - " + dateFormat.format( new Date() );
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportName );
            Log.assertThat( reportComponent.isReportOptionSaved( reportName ), "Saved report is displyed in Saved Options dropdown", "Saved report is not displyed in Saved Options dropdown" );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify if click the save button with already existing name in 'Save Report Option As' Popup.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD015() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD015: Verify if click the save button with already existing name in 'Save Report Option As' Popup. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyy/MM/dd HH:mm:ss" );
            String reportName = "Modified Report - " + dateFormat.format( new Date() );
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportName );
            Log.assertThat( reportComponent.isReportOptionSaved( reportName ), "Saved report is displyed in Saved Options dropdown", "Saved report is not displyed in Saved Options dropdown" );
            reportComponent.isReportOptionSaved( "Choose One" );
            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( reportName );
            Log.assertThat( reportComponent.getSaveReportOptionErrorMsg().equals( Constants.Reports.EXISTING_NAME_ERROR ), "Save Report Option popup throws the error message for existing name",
                    "Save Report Option popup is not throwing the error message for existing name" );
            reportComponent.clickcancelButtoninSaveReportPopup();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify user can able to edit the Saved Filters using 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD016() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD016: Verify user can able to edit the Saved Filters using 'Replace Existing Report Options' dropdown in 'Save Report Option As' Popup. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            reportComponent.clickSaveReportOption();
            String reportName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportName );
            Log.assertThat( reportComponent.isReportOptionSaved( reportName ), "Saved report is displyed in Saved Options dropdown", "Saved report is not displyed in Saved Options dropdown" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( "Reading" ) );
            reportComponent.clickSaveReportOption();

            reportComponent.replaceExistingReport( Constants.Reports.CHOOSE_ONE );
            reportComponent.replaceExistingReport( reportName );
            reportComponent.clickSaveOnSaveReportPopUp();
            reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
            reportComponent.loadReportOption( reportName );

            Log.assertThat( reportComponent.isReportOptionSaved( reportName ), "Saved report is displyed in Saved Options dropdown", "Saved report is not displyed in Saved Options dropdown" );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( "Reading" ), "The Subject Drop down is populated with saved option vales",
                    "The Subject Drop down is not populated with saved option vales" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();

        } catch (

        Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the Subject dropdown in report page.", groups = { "SMK-43900", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD017() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAOD017: Verify the Subject dropdown in report page. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Verifying the availability of Subject dropdown
            Log.assertThat( reportComponent.isMSDropdownHeadingPresent( Constants.Reports.SUBJECT_DROPDOWN ), "Subject dropdown is present", "Subject dropdown is not present" );

            // Verifying the options of Subject dropdown
            Log.assertThat( reportComponent.isSelectALLChecked( Constants.Reports.SUBJECT_DROPDOWN ), "Select All option is present in Subject dropdown", "Select All option is not present in Subject dropdown" );
            reportComponent.setDropDownMS( Constants.Reports.SUBJECT_DROPDOWN );
            Log.assertThat( reportComponent.getValuesFromDropDownMS().containsAll( Constants.Reports.SUBJECTS ), "All options are available in Subject dropdown", "Some option is missing in Subject dropdown" );

            // Verifying default selection of Subject dropdown
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "All options are selected by default in Subject dropdown", "All options are not selected by default in Subject dropdown" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in AOD Report Page", groups = { "SMK-43900", "reports",
            "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD018() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSMAOD018: Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Reading subject alone in AOD Report Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Uncheck Select All checkbox
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );

            // get WebElements of dopdown option checkboxes
            List<String> subjectOption = new ArrayList<>();

            // Select Math from subject dropdown
            subjectOption.add( Constants.Reports.SUBJECTS.get( 0 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            if ( !reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String mathReportFilter = "Math Subject " + System.nanoTime();
                reportComponent.saveReportOption( mathReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( mathReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SUBJECTS.get( 0 ) ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );
            } else {
                Log.message( "No assignments available for Math subject" );
            }

            // Select Reading from subject dropdown
            subjectOption.add( Constants.Reports.SUBJECTS.get( 1 ) );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, subjectOption );
            if ( !reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String readingReportFilter = "Reading Subject " + System.nanoTime();
                reportComponent.saveReportOption( readingReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( readingReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SUBJECTS.get( 1 ) ), "Filters loaded Successfully", "Selected Filters not loaded Properly" );
            } else {
                Log.message( "No assignments available for Reading subject" );
            }
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the functionality of check-box in subject dropdown", groups = { "SMK-43900", "reports", "areasOfDifficultyReport" }, priority = 3 )
    public void tcSM_SubjectDropdownAOD001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SubjectDropdownAOD001: Verify the functionality of check-box in subject dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            SMUtils.logDescriptionTC( "SMK-11138 - Verify unchecking all options in Subject drop down in Areas of Difficulty Reports Page" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.UNCHECKED_SUBJECTS ), "Subject dropdown is unchecked in Areas of Difficulty Reports Page",
                    "Subject dropdown is not unchecked in Areas of Difficulty Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11135 - Verify Math Option is selectable in Subject drop down in Areas of Difficulty Reports Page" );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.MATH ) );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.MATH ), "Math option is selected in Subject dropdown in Areas of Difficulty Reports Page",
                    "Math option is not selected in Subject dropdown in Areas of Difficulty Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11136 - Verify Reading Option is selectable in Subject drop down in Areas of Difficulty Reports Page" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.READING ) );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.READING ), "Reading option is selected in Subject dropdown in Areas of Difficulty Reports Page",
                    "Reading option is not selected in Subject dropdown in Areas of Difficulty Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11137 - Verify SELECT ALL Option is selectable in Subject drop down in Areas of Difficulty Reports Page" );
            // Uncheck all subject
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            // Select all subjects
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "Select All option is selected in Subject dropdown in Areas of Difficulty Reports Page", "Select All option is not selected in Subject dropdown in Areas of Difficulty Reports Page" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11132 - Verify that Subject drop down in Subject filter in Areas of Difficulty Reports Page is a multiselect drop down" );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Constants.Reports.SUBJECTS );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "Subject dropdown is a multi-select dropdown in Areas of Difficulty Reports Page", "Subject dropdown is not a multi-select dropdown in Areas of Difficulty Reports Page" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify subjects are displayed in subject dropdown", groups = { "SMK-43900", "reports", "areasOfDifficultyReport" }, priority = 3 )
    public void tcSM_SubjectDropdownAOD002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "tcSM_SubjectDropdownAOD002: Verify subjects are displayed in subject dropdown <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            SMUtils.logDescriptionTC( "SMK-11145 - Verify teacher is able to see the saved subject selected in subject dropdown while selecting the report options saved with Math and Reading subject alone in Areas of Difficulty report page" );
            String selectedAssignments = reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            if ( !selectedAssignments.equals( Constants.Reports.NO_ASSIGNMENTS ) ) {
                // Click SaveReport Option
                reportComponent.clickSaveReportOption();
                String allSubjectReportFilter = "All Subject " + System.nanoTime();
                reportComponent.saveReportOption( allSubjectReportFilter );
                // load report
                reportComponent.loadReportOption( Constants.Reports.CHOOSE_ONE );
                reportComponent.loadReportOption( allSubjectReportFilter );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                        "Selected subject filters are loaded Successfully", "Selected subject filters are not loaded Successfully" );
                Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( selectedAssignments ), "Selected assignment filters are loaded Successfully",
                        "Selected assignment filters are not loaded Successfully" );
            } else {
                Log.message( "No assignments available for Math subject" );
            }
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11146 - Verify the teacher able to see All Subjects (2) while colapsing the Filters if both subjects are selected in Subjects dropdown" );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "All Subjects (2) is displayed while colapsing the filters if both subjects are selected in Subjects dropdown", "All Subjects (2) is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11147 -Verify the teacher able to see Math while colapsing the Filters if Math subject is selected in Subjects dropdown" );
            // Expanding filters
            reportComponent.expandFilterButton();
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.MATH ) );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.MATH ), "Math is displayed while colapsing the filters if both subjects are selected in Subjects dropdown",
                    "Math is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-11148 - Verify the teacher able to see Reading while colapsing the Filters if Reading subject is selected in Subjects dropdown" );
            // Expanding filters
            reportComponent.expandFilterButton();
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( Constants.READING ) );
            // Collapsing filters
            reportComponent.collapseFilterButton();
            Log.assertThat( reportComponent.getvaluesFromCollapsedFilter().contains( Constants.READING ), "Reading is displayed while colapsing the filters if both subjects are selected in Subjects dropdown",
                    "Reading is not displayed while colapsing the filters if both subjects are selected in Subjects dropdown" );
            Log.testCaseResult();
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify FILTERS field should be expandable and collapse.", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD019() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD019: Verify FILTERS field should be expandable and collapse. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Verify filter drop down is expandable or not
            Log.assertThat( reportComponent.verifyFilterButtonisExpanded(), "Initially Filter is expanded", "Initially filter is collapsed" );

            reportComponent.collapseFilterButton();
            Log.assertThat( !reportComponent.verifyFilterButtonisExpanded(), "After clicking collpase, Filter is collapsed", "After clicking collpase, Filter is not collapsed" );

            reportComponent.expandFilterButton();
            Log.assertThat( reportComponent.verifyFilterButtonisExpanded(), "After clicking expand, Filter is expanded", "After clicking expand, Filter is collapsed" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify fields are available, After click the Filters option.", groups = { "SMK-43782", "reports", "areasOfDifficultyReport" }, priority = 1 )
    public void tcSMAOD020() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD020:  Verify fields are available, After click the Filters option.<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            // Verify filter drop down is expandable or not
            Log.assertThat( reportComponent.verifyFilterButtonisExpanded(), "Initially Filter is expanded", "Initially filter is collapsed" );
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.GROUP_OR_STUDENT_HEADER ), "The Step 1 Filter header is displayed", "The Step 1 Filter header is not displayed" );

            // Verify Groups drop down is selected by default
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.GROUP_DROPDOWN ), "The group drop down is selected by default", "The group drop down is not selected by default" );
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.GROUP_DROPDOWN ).contains( "All Groups" ), "The default text from Groups header is displayed", "The default text from Groups header is not displayed" );
            Log.assertThat( !reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.STUDENTS_DROPDOWN ), "The Students drop down is not selected by default", "The Students drop down is selected by default" );

            // Verify Groups drop down is displayed
            Log.assertThat( reportComponent.verifyGroupsorStudentsDropdownPresent( Constants.Reports.GROUP_DROPDOWN ), "The Groups drop down is displayed", "Groups drop down is not displayed" );

            //Verify Students drop down is selected and displayed
            reportComponent.checkGroupsOrStudentRB( "Students" );
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.STUDENTS_DROPDOWN ), "The Students drop down is selected", "The Students drop down is not selected" );
            Log.assertThat( reportComponent.verifyGroupsorStudentsDropdownPresent( Constants.Reports.STUDENTS_DROPDOWN ), "The Students drop down is displayed", "The Students drop down is not displayed" );
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).contains( "All Students" ), "The default text from Groups header is displayed", "The default text from Groups header is not displayed" );

            // Verify Subject drop down is available
            Log.assertThat( reportComponent.isRefineSearchAndGroupsOrStudentsHeadingPresent( Constants.Reports.REFINE_SEARCH ), "The Step 2 Filter header is displayed", "The Step 2 Filter header is not displayed" );
            Log.assertThat( reportComponent.verifySubjectDropdownPresent(), "The Subject drop down is displayed", "The Subject drop down is displayed" );
            reportComponent.setDropDownMS( Constants.Reports.SUBJECT_DROPDOWN );
            List<String> subject = reportComponent.getValuesFromDropDownMS();
            Log.message( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ) );
            Log.message( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, subject.size() + "" ) );
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_SUBJECTS.replace( Constants.Reports.SELECTED_COUNT, subject.size() + "" ) ),
                    "Subject Drop down text verified", "Subject drop down text not verified" );

            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignments = reportComponent.getValuesFromDropDownMS();
            Log.assertThat( reportComponent.getTextFromInsideMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, assignments.size() + "" ) ),
                    "Assignment drop down text verified", "Assignment drop down text not verified" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Groups and Students radio button Inside the FILTERS.", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD021() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD021: Verify Groups and Students radio button Inside the FILTERS. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.GROUP_DROPDOWN ), "By default, Group drop down is selected and enabled", "Group drop down is not selected" );
            Log.assertThat( !reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.STUDENTS_DROPDOWN ), "Students drop down is not selected and disabled", "Students drop down is selected" );

            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.STUDENTS_DROPDOWN ), "Students drop down is selected and enabled", "Students drop down is not selected" );
            Log.assertThat( !reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.GROUP_DROPDOWN ), "Groups drop down is not selected and disabled", "Groups drop down is selected" );

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the 'Saved option' dropdown, if none of the Saved Filter options there.", priority = -1, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD022() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD022: Verify the 'Saved option' dropdown, if none of the Saved Filter options there. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            int size = reportComponent.getSavedReportOptionList().size();
            Log.message( size + "" );
            Log.assertThat( size == 1, "No Saved Report Found initially", "Saved Report Exist initially" );
            Log.testCaseResult();

            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( "Save Report Option 1" );

            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOption( "Save Report Option 2" );

            List<String> afterSave = reportComponent.getSavedReportOptionList();
            Log.assertThat( afterSave.containsAll( Arrays.asList( "Save Report Option 1", "Save Report Option 2" ) ), "The Saved report option saved is listed", "The Saved report option saved is not listed" );
            Log.testCaseResult();
            reportComponent.loadReportOption( "Save Report Option 1" );
            Log.assertThat( reportComponent.getSavedOptionSelectedValue().equals( "Save Report Option 1" ), "Saved Report option selected", "Saved Report Option is not selected" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if click the save button with empty Name in 'Save Report Option As' Popup.", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD023() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD023: Verify if click the save button with empty Name in 'Save Report Option As' Popup. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            reportComponent.clickSaveReportOption();
            reportComponent.saveReportOptionNegative( "" );
            String errorMessage = reportComponent.getErrorMessageForExceedMaximumLength();
            Log.assertThat( errorMessage.equals( Constants.Reports.SAVE_REPORT_ERROR_MESSAGE ), "Saved Report option Error Message verified: " + errorMessage, "Saved Report Option error message is not verified: " + errorMessage );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify If click the 'Replace Existing Report Options' radio button in 'Save Report Option As' Popup.", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD024() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD024: Verify If click the 'Replace Existing Report Options' radio button in 'Save Report Option As' Popup. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            reportComponent.clickSaveReportOption();
            reportComponent.checkReplaceExistingReportOption();
            Log.assertThat( !reportComponent.verifyNewOptionisSelected(), "The New Option is enabled", "The New Option is disabled" );
            Log.assertThat( reportComponent.verifyReplaceExisitngReportOptionisSelected(), "The Replace Existing Report Option is enabled", "The Replace Exisiting Report Option is disabled" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Assignments name should display in Alphabetical order under Assignments dropdown and SELECT ALL option in assignment drop down.", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD025() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD025: Verify the Assignments name should display in Alphabetical order under Assignments dropdown and SELECT ALL option in assignment drop down. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            List<String> OrderedAssignmentsList = new ArrayList<>( assignmentsFromUI );
            Collections.sort( OrderedAssignmentsList );
            Log.assertThat( OrderedAssignmentsList.equals( assignmentsFromUI ), "The Assignment values are sorted alphabetically", "The Assignment values are not sorted alphabetically" );
            Log.testCaseResult();

            String selection = reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).trim();
            Log.assertThat( selection.equals( Constants.Reports.SELECTED_ALL_ASSIGNMENTS.replace( Constants.Reports.SELECTED_COUNT, assignmentsFromUI.size() + "" ) ), "All assignments are selected after clicking SELECT ALL option",
                    "All assignments are not selected after clicking SELECT ALL option" );
            reportComponent.clickSelectALLFromMSDropdownwithJS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            selection = reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).trim();
            Log.assertThat( selection.equals( Constants.Reports.UNCHECKED_ASSIGNMENT_DROPDOWN_DEFAULT_VALUE ), "All assignments are unselected after clicking SELECT ALL option", "All assignments are selected after clicking SELECT ALL option" );

            Log.message( selection );
            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Groups/Students name should display in Alphabetical order under Groups/Students dropdown.", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD026() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD026: Verify the Groups/Students name should display in Alphabetical order under Groups/Students dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            Log.message( groupsFromUI + "" );
            List<String> OrderedGroupsList = new ArrayList<>( groupsFromUI );
            Collections.sort( OrderedGroupsList );
            Log.message( OrderedGroupsList + "" );
            Log.assertThat( OrderedGroupsList.equals( groupsFromUI ), "The Group values are sorted alphabetically", "The Group values are not sorted alphabetically" );

            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the Functionality of Saved Report option..", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD027() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD027: Verify the Functionality of Saved Report option.. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.SUBJECT_DROPDOWN, Arrays.asList( "Math" ) );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN, Constants.Reports.GRADES );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN, Constants.Reports.STUDENTID );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.SORT_DROPDOWN, Constants.Reports.LEVEL );
            reportComponent.selectValueFromStaticDropdown( Constants.Reports.DATE_AT_RISK_DROPDOWN, Constants.Reports.WEEKS_20 );

            reportComponent.clickSaveReportOption();
            String reportName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportName );
            Log.assertThat( reportComponent.isReportOptionSaved( reportName ), "Saved report is displyed in Saved Options dropdown", "Saved report is not displyed in Saved Options dropdown" );
            teacherHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();
            reportComponent.loadReportOption( reportName );

            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.STUDENTS_DROPDOWN ), "The Student drop down is selected", "The Student drop down is selected" );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.SUBJECT_DROPDOWN ).equalsIgnoreCase( Constants.Reports.SUBJECTS.get( 0 ) ), "Math subject is selected", "Math subject is not selected" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.ADDITIONAL_GROUPING_DROPDOWN ).equals( Constants.Reports.GRADES ), "The selected option in Additional Grouping Drop down is Grades",
                    "The selected option in Additional Grouping Drop down is not Grades" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DISPLAY_DROPDOWN ).equals( Constants.Reports.STUDENTID ), "The selected option in Display Drop down is Student ID",
                    "The selected option in Display Drop down is not Student ID" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.SORT_DROPDOWN ).equals( Constants.Reports.LEVEL ), "The selected option in Sort Drop down is Level", "The selected option in Sort Drop down is not Level" );
            Log.assertThat( reportComponent.getSelectedOptionFromStaticDropdown( Constants.Reports.DATE_AT_RISK_DROPDOWN ).equalsIgnoreCase( Constants.Reports.WEEKS_20 ), "The selected option in Date at risk Drop down is Week 20",
                    "The selected option in Date at risk Drop down is not Week 20" );

            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher should be able to select one or more Student in the Students dropdown.", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD028() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD028: Verify teacher should be able to select one or more Student in the Students dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();

            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );
            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> allStudentsFromUI = reportComponent.getValuesFromDropDownMS();
            reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, Arrays.asList( allStudentsFromUI.get( 1 ) ) );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).equalsIgnoreCase( allStudentsFromUI.get( 1 ) ), "One student can be selected in the Students drop down",
                    "One student can not be selected in the Students drop down" );

            reportComponent.clickSelectALLFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN );
            reportComponent.selectDropdownMSOptions( Constants.Reports.STUDENTS_DROPDOWN, Arrays.asList( allStudentsFromUI.get( 1 ), allStudentsFromUI.get( 2 ) ) );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.STUDENTS_DROPDOWN ).equalsIgnoreCase( Constants.Reports.SELECTED_STUDENTS.replace( Constants.Reports.SELECTED_COUNT, "2" ) ),
                    "More than One student can be selected in the Students drop down", "More than One student can not be selected in the Students drop down" );

            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if Groups, Students and Assignments name having maximum character in dropdown.", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD029() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD029: Verify if Groups, Students and Assignments name having maximum character in dropdown. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( username, password, true );

            String studentFirstName = Constants.Reports.LONG_STUDENT_FIRST_NAME;
            String studentLastName = Constants.Reports.LONG_STUDENT_LAST_NAME;
            String groupName = Constants.Reports.LONG_GROUP_NAME;
            String assignmentName = Constants.Reports.LONG_ASSIGNMENT_NAME;
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();
            studentFirstName = studentsTab.createStudent( studentFirstName, studentLastName, "Grade 2" );

            GroupPage groupsTab = teacherHomePage.topNavBar.navigateToGroupsTab();
            groupsTab.createGroupWithoutStudent( groupName );

            CoursesPage cp = teacherHomePage.topNavBar.navigateToCourseListingPage();
            cp.clickCourseFromTheListing( "Math" );
            cp.clickMakeCopyBtn();
            cp.enterCourseName( assignmentName );
            cp.clickNextBtn();
            SMUtils.nap( 2 );
            cp.clickCreateBtn();
            cp.clickCourseFromTheListing( assignmentName );
            cp.clickAssignBtn();
            cp.addCourseToGroups();

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();
            reportComponent.checkGroupsOrStudentRB( Constants.Reports.STUDENTS_DROPDOWN );
            reportComponent.setDropDownMS( Constants.Reports.STUDENTS_DROPDOWN );
            List<String> allStudentsFromUI = reportComponent.getValuesFromDropDownMS();
            Log.assertThat( allStudentsFromUI.contains( studentFirstName + " " + studentLastName ), "The Longest Student name is displayed in the drop down", "The Longest Student name is not displayed in the drop down" );

            reportComponent.checkGroupsOrStudentRB( Constants.Reports.GROUP_DROPDOWN );
            reportComponent.setDropDownMS( Constants.Reports.GROUP_DROPDOWN );
            List<String> allGroupList = reportComponent.getValuesFromDropDownMS();
            Log.assertThat( allGroupList.contains( groupName ), "The longest Group name is displayed in the drop down", "The longest Group name is not displayed in the drop down" );

            reportComponent.setDropDownMS( Constants.Reports.ASSIGNMENTS_DROPDOWN );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();
            Log.assertThat( assignmentsFromUI.contains( assignmentName ), "The Longest Assignment name is displayed in the drop down", "The Longest Assignment name is not displayed in the drop down" );

            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if teacher don't have any students, Then what should be AOD Report Page.", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD030() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD030: Verify if teacher don't have any students, Then what should be AOD Report Page. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            String firstTeacher = "TestAODReportTestTeacher" + System.nanoTime();
            Faker teacherDetails = new Faker();
            Integer firstTeacherId = new UserSqlHelper().createTeacher( teacherDetails.name().firstName(), teacherDetails.name().lastName(), firstTeacher, Constants.PASSWORD_HASH, DataSetup.organizationId );

            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( firstTeacher, password, true );

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();
            Log.assertThat( reportComponent.isZeroStateMessageDisplayed(), "The Zero State message is verified", "The Zero State message is not verified" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if the teacher don't have any group, the dropdown should be empty.", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD031() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD031: Verify if the teacher don't have any group, the dropdown should be empty. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            String Teacher1 = "TestAODReportTestTeacher" + System.nanoTime();
            Faker teacherDetails = new Faker();
            Integer teacherId1 = new UserSqlHelper().createTeacher( teacherDetails.name().firstName(), teacherDetails.name().lastName(), Teacher1, Constants.PASSWORD_HASH, DataSetup.organizationId );

            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( Teacher1, password, true );

            // Navigate to Students Page
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();
            String student1 = studentsTab.createStudent();
            String student2 = studentsTab.createStudent();

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.STUDENTS_DROPDOWN ), "The Students drop down is enabled and selected by default", "The Student drop down is disabled" );
            Log.assertThat( !reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.GROUP_DROPDOWN ), "The Groups drop down is disabled", "The Groups drop down is enabled" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify If teacher have no assignments, then what should be display in Assignments dropdown", priority = 3, groups = { "SMK-43782", "reports", "areasOfDifficultyReport" } )
    public void tcSMAOD032() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
        Log.testCaseInfo( "tcSMAOD032: Verify If teacher have no assignments, then what should be display in Assignments dropdown. <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            String Teacher1 = "TestAODReportTestTeacher" + System.nanoTime();
            Faker teacherDetails = new Faker();
            Integer teacherId1 = new UserSqlHelper().createTeacher( teacherDetails.name().firstName(), teacherDetails.name().lastName(), Teacher1, Constants.PASSWORD_HASH, DataSetup.organizationId );

            smLoginPage = new LoginPage( driver, smUrl ).get();
            teacherHomePage = smLoginPage.loginToSM( Teacher1, password, true );

            // Navigate to Students Page
            StudentsPage studentsTab = teacherHomePage.topNavBar.navigateToStudentsTab();
            String student1 = studentsTab.createStudent();
            String student2 = studentsTab.createStudent();

            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // Navigate to Areas of Difficulty Page
            teacherHomePage.topNavBar.navigateToReportsAreasofDifficultyTab();
            Log.assertThat( reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.STUDENTS_DROPDOWN ), "The Students drop down is enabled and selected by default", "The Student drop down is disabled" );
            Log.assertThat( !reportComponent.isGroupsOrStudentRBChecked( Constants.Reports.GROUP_DROPDOWN ), "The Groups drop down is disabled", "The Groups drop down is enabled" );
            Log.assertThat( reportComponent.getSelectedOptionFromMSDropdown( Constants.Reports.ASSIGNMENTS_DROPDOWN ).equals( Constants.Reports.AOD_NO_ASSIGNMENT ), "No Assignment Available message verified",
                    "No Assignment Available message is not verified" );
            Log.testCaseResult();

            // SignOut from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            
            
            Log.endTestCase();
            driver.quit();
        }
    }

}
