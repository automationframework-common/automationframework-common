package com.savvas.sm.api.tests.smnew.sharedcourses;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.AdminAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.AdminConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.dashboard.OrganizationListing;
import com.savvas.sm.utils.sme187.admin.api.sharedcourse.SharedCourses;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class GetSharedCourseOrgList extends EnvProperties {

    private String smUrl;
    private String districtId;
    private String subDistrictOrgId;
    private String username;
    private String password;
    private String userId;
    private String subDistrictUsername;
    private String subDistrictUserId;
    private String adminAccessToken;
    private String teacherDetails;
    private String teacherUsername;
    private String teacherUserId;
    private String courseId;
    private RBSUtils rbsUtils = new RBSUtils();
    Map<String, String> response = new HashMap<>();
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    SharedCourses sharedCourse = new SharedCourses();
    Map<String, Map<String, String>> sharedOrgListFromDB;
    Map<String, Map<String, String>> detailsFromResponse;
    Map<String, String> headers = new HashMap<>();

    @BeforeClass ( alwaysRun = true )
    public void beforeClass() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        districtId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );

        // Getting admin details in RBS Datasetup
        username = RBSDataSetup.adminUserNames.get( Admins.DISTRICT_ADMIN );
        String adminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        userId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        // Getting sub-district admin details in RBS Datasetup
        String subDistrictAdminDetails = RBSDataSetup.adminDetails.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        subDistrictUsername = RBSDataSetup.adminUserNames.get( Admins.SUBDISTRICTWITHSCHOOL_ADMIN );
        subDistrictUserId = SMUtils.getKeyValueFromResponse( subDistrictAdminDetails, RBSDataSetupConstants.USERID );
        subDistrictOrgId = RBSDataSetup.subDistrictwithSchoolId;
        adminAccessToken = rbsUtils.getAccessToken( subDistrictUsername, password );

        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );

        //create shared course 
        courseId = sharedCourse.createCustomCourse( smUrl, rbsUtils.getAccessToken( teacherUsername, password ), DataSetupConstants.MATH, teacherUserId, RBSDataSetup.organizationIDs.get( school ), DataSetupConstants.SETTINGS,
                "Shared Math course" + System.nanoTime() );

    }

    /**
     * This method is used to test the positive scenarios.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 1, dataProvider = "poistiveScenarioTestData", groups = { "smoke_test_case", "sharedCourse", "SMK-54126", "P1", "API" } )
    public void getSharedCoursePositive( String tcID, String tcDescription, String statusCode, String scenarioType ) throws Exception {
        Log.testCaseInfo( tcID + ": " + tcDescription );

        switch ( scenarioType ) {
            case "FOR_DISTRICT_ADMIN":

                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.USERID_SM_HEADER, userId );
                headers.put( Constants.ORGID_SM_HEADER, districtId );
                response = sharedCourse.getSharedCourseOrgList( smUrl, headers, courseId, "" );

                sharedOrgListFromDB = getSharedCourseOrganizationDetailsFromDB( Admins.DISTRICT_ADMIN, courseId );
                detailsFromResponse = getSharedCourseOrganizationDetailsFromResponse( response.get( Constants.REPORT_BODY ) );
                break;

            case "FOR_SUBDISTRICT_ADMIN":

                //create subdistrict teacher
                Map<String, String> userDetails = new HashMap<>();
                String subdistrictSchoolTeacher = "SubdistrictSchoolTeacher" + System.nanoTime();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( "admin_id" ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, subdistrictSchoolTeacher );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.TEACHER_ROLE );
                List<String> schools = Arrays.asList( RBSDataSetup.schoolUnderSubDistrict_SchoolId );
                String schoolList = "";
                for ( String school : schools ) {
                    schoolList += school.concat( "\",\"" );
                }
                schoolList = schoolList.substring( 0, schoolList.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, schoolList );
                String subdistrictSchoolTeacherID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( (HashMap<String, String>) userDetails ), RBSDataSetupConstants.USERID );
                rbsUtils.resetPassword( RBSDataSetup.schoolUnderSubDistrict_SchoolId, RBSDataSetupConstants.DEFAULT_PASSWORD, subdistrictSchoolTeacherID );

                //create course for subdistrict teacher
                String courseIdBysubdistrictSchoolTeacher = sharedCourse.createCustomCourse( smUrl, rbsUtils.getAccessToken( subdistrictSchoolTeacher, password ), DataSetupConstants.MATH, subdistrictSchoolTeacherID,
                        RBSDataSetup.schoolUnderSubDistrict_SchoolId, DataSetupConstants.SETTINGS, "Shared Math course" + System.nanoTime() );

                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( subDistrictUsername, password ) );
                headers.put( Constants.USERID_SM_HEADER, subDistrictUserId );
                headers.put( Constants.ORGID_SM_HEADER, subDistrictOrgId );
                response = sharedCourse.getSharedCourseOrgList( smUrl, headers, courseId, "" );

                sharedOrgListFromDB = getSharedCourseOrganizationDetailsFromDB( Admins.SUBDISTRICTWITHSCHOOL_ADMIN, courseId );
                detailsFromResponse = getSharedCourseOrganizationDetailsFromResponse( response.get( Constants.REPORT_BODY ) );
                break;

            case "FOR_SCHOOL_ADMIN":
                // Getting school admin user data to login
                String schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );

                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( Admins.SCHOOL_ADMIN ), password ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( schoolAdminDetails, RBSDataSetupConstants.USERID ) );
                headers.put( Constants.ORGID_SM_HEADER, SMUtils.getKeyValueFromResponse( schoolAdminDetails, "primaryOrgId" ) );
                response = sharedCourse.getSharedCourseOrgList( smUrl, headers, courseId, "" );

                sharedOrgListFromDB = getSharedCourseOrganizationDetailsFromDB( Admins.SCHOOL_ADMIN, courseId );
                detailsFromResponse = getSharedCourseOrganizationDetailsFromResponse( response.get( Constants.REPORT_BODY ) );
                break;

            case "FOR_SAVVAS_ADMIN":
                // Getting savvas admin user data to login

                String savvasAdminDetail = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
                String savvasAdminUsername = RBSDataSetup.adminUserNames.get( Admins.SAVVAS_ADMIN );
                String savvasAdminUserId = SMUtils.getKeyValueFromResponse( savvasAdminDetail, RBSDataSetupConstants.USERID );
                String savvasAdminorgId = SMUtils.getKeyValueFromResponse( savvasAdminDetail, "primaryOrgId" );
                headers.put( AdminAPIConstants.ORGID, savvasAdminorgId );
                headers.put( AdminAPIConstants.USERID, savvasAdminUserId );
                headers.put( AdminAPIConstants.AUTHORISATION, AdminAPIConstants.BEARER + new RBSUtils().getAccessToken( savvasAdminUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                response = sharedCourse.getSharedCourseOrgList( smUrl, headers, courseId, districtId );

                sharedOrgListFromDB = getSharedCourseOrganizationDetailsFromDB( Admins.DISTRICT_ADMIN, courseId );
                detailsFromResponse = getSharedCourseOrganizationDetailsFromResponse( response.get( Constants.REPORT_BODY ) );
                break;

            default:
                Log.message( "not a valid scenario type" );
                break;
        }

        //status code validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " is not Verified" );

        //schema validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "GetShareCourseOrgList", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        //Data Validation
        Log.assertThat( sharedOrgListFromDB.entrySet().stream().anyMatch( entry -> SMUtils.compareTwoHashMap( entry.getValue(), detailsFromResponse.get( entry.getKey() ) ) ), "Shared course Organizations API fetched all the Organizations properly",
                "Shared course Organizations API is not fetched the Organizations properly" );

    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "poistiveScenarioTestData" )
    public Object[][] poistiveScenarioTestData() {
        return new Object[][] {
                { "tc001", "Verify the response code 200 and response contains all the organizations under the district and the assigned status of the shared course when a district admin and its org-id are passed.", CommonAPIConstants.STATUS_CODE_OK,
                        "FOR_DISTRICT_ADMIN" },
                { "tc002", "Verify response code 200 and the response when a sub-district admin id is passed as user id", CommonAPIConstants.STATUS_CODE_OK, "FOR_SUBDISTRICT_ADMIN" },
                { "tc003", "Verify response code 200 and the response when a sub-district admin id is passed as user id", CommonAPIConstants.STATUS_CODE_OK, "FOR_SUBDISTRICT_ADMIN_WITHOUT_SCHOOL" },
                { "tc004", "Verify response code 200 and the response when a school admin id is passed as user id", CommonAPIConstants.STATUS_CODE_OK, "FOR_SCHOOL_ADMIN" },
                { "tc009", "Verify the response code 200 and response contains all the organizations and the assigned status of the shared course when a savvas admin details are passed.", CommonAPIConstants.STATUS_CODE_OK, "FOR_SAVVAS_ADMIN" }, };
    }

    /**
     * This method is used to test the negative scenarios for Get- Shared
     * courses.
     * 
     * @param tcID
     * @throws Exception
     */
    @Test ( priority = 2, dataProvider = "negativeScenarioTestData", groups = { "sharedCourse", "SMK-54126", "P3", "API" } )
    public void getSharedCourseNegative( String tcID, String tcDescription, String statusCode, String scenarioType ) throws Exception {
        Log.testCaseInfo( tcID + ": " + tcDescription );

        Map<String, String> headers = new HashMap<>();
        // Input Params
        HashMap<String, String> params = new HashMap<>();

        String endPoint = AdminConstants.GET_SHARED_COURSE_ORG_LIST;
        endPoint = endPoint.replace( Constants.COURSE_ID, courseId );

        switch ( scenarioType ) {
            case "WITHOUT_USER_ID":

                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( username, password ) );
                headers.put( Constants.ORGID_SM_HEADER, districtId );

                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                break;
            case "WITHOUT_BEARER_TOKEN":

                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.USERID_SM_HEADER, userId );
                headers.put( Constants.ORGID_SM_HEADER, districtId );

                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                break;
            case "WITH_STUDENT_CREDENTIAL":

                String studentDetails = RBSDataSetup.getMyStudent(RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ), teacherUsername);
                
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME ), password ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( Schools.FLEX_SCHOOL ) );

                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                break;
            case "WITH_TEACHER_CREDENTIAL":

                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), password ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( Schools.MATH_SCHOOL ) );

                response = RestHttpClientUtil.GET( smUrl, endPoint, headers, params );
                break;
            default:
                Log.message( "not a valid scenario type" );
                break;
        }
        Log.message(response.get(Constants.REPORT_BODY));
        //status code validation
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " is not Verified" );

        //schema validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "GetShareCourseOrgList", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );


    }

    /**
     * Data provider to provide the scenarios
     * 
     * @return
     */
    @DataProvider ( name = "negativeScenarioTestData" )
    public Object[][] negativeScenarioTestData() {
        return new Object[][] { { "tc005", "Verify status code 401 when user id is not passed in header parameter", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, "WITHOUT_USER_ID" },
                { "tc006", "Verify status code 401 when SSO token is not passed in header parameter", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, "WITHOUT_BEARER_TOKEN" },
                { "tc007", "Verify status code 403 when User ID is student rumba id in headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN, "WITH_STUDENT_CREDENTIAL" },
                { "tc008", "Verify status code 403 when User ID is teacher rumba id in headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN, "WITH_TEACHER_CREDENTIAL" }, };
    }

    /**
     * To get shared course organizations details from graphql response
     *
     * @return
     */
    public Map<String, Map<String, String>> getSharedCourseOrganizationDetailsFromResponse( String response ) {
        Map<String, Map<String, String>> sharedCourseOrganizations = new HashMap<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( response, AdminAPIConstants.ORGANIZATION_NAME ) ).parallel().forEach( iter -> {
            Map<String, String> sharedCourseOrganization = new HashMap<>();
            sharedCourseOrganization.put( AdminAPIConstants.ORGANIZATION_NAME, SMUtils.getKeyValueFromJsonArray( response, AdminAPIConstants.ORGANIZATION_NAME, iter ) );
            sharedCourseOrganization.put( AdminAPIConstants.SHARED, SMUtils.getKeyValueFromJsonArray( response, AdminAPIConstants.SHARED, iter ) );
            sharedCourseOrganization.put( AdminAPIConstants.ASSIGNED, SMUtils.getKeyValueFromJsonArray( response, AdminAPIConstants.ASSIGNED, iter ) );

            sharedCourseOrganizations.put( SMUtils.getKeyValueFromJsonArray( response, AdminAPIConstants.ORGANIZATION_ID, iter ), sharedCourseOrganization );
        } );
        return sharedCourseOrganizations;
    }

    /**
     * To get the organization List for given admin
     *
     * @param admin
     * @return
     * @throws Exception
     */
    public List<String> getOrganizationIdsForAdmin( Admins admin ) throws Exception {
        String orgId;
        if ( admin.equals( Admins.SCHOOL_ADMIN ) ) {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" );
        } else {
            orgId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "primaryOrgId" ).replace( "[", "" ).replace( "]", "" ).replace( "\"", "" );
        }
        String userId = SMUtils.getKeyValueFromResponse( RBSDataSetup.adminDetails.get( admin ), "userId" );
        String accessToken = new RBSUtils().getAccessToken( RBSDataSetup.adminUserNames.get( admin ), password );

        Map<String, String> headers = new HashMap<>();
        //headers
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, AdminAPIConstants.BEARER + accessToken );
        headers.put( AdminAPIConstants.USERID, userId );
        headers.put( AdminAPIConstants.ORGID, orgId );
        Map<String, String> response = new OrganizationListing().getOrganizationList( smUrl, headers );
        List<String> organizationListFromAPI = new ArrayList<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_NAME ) ).parallel().forEach(
                iter -> organizationListFromAPI.add( SMUtils.getKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), AdminAPIConstants.ORGANIZATION_ID, iter ) ) );

        return organizationListFromAPI;
    }

    /**
     * To get SharedCourseOrganization Details from DB
     *
     * @throws Exception
     */
    public Map<String, Map<String, String>> getSharedCourseOrganizationDetailsFromDB( Admins admin, String courseId ) throws Exception {
        List<String> orgIds = getOrganizationIdsForAdmin( admin );
        Map<String, Map<String, String>> sharedCourseOrganizationsFromDB = new HashMap<>();
        Map<String, String> sharedListFromDB = new SqlHelperCourses().getSharedCourseOrgIdAndAssignedStatus( courseId );
        Set<String> keySet = sharedListFromDB.keySet();
        orgIds.stream().parallel().forEach( orgId -> {
            Map<String, String> sharedCourseOrganization = new HashMap<>();
            if ( keySet.contains( orgId ) ) {
                sharedCourseOrganization.put( AdminAPIConstants.SHARED, "true" );
                sharedCourseOrganization.put( AdminAPIConstants.ASSIGNED, sharedListFromDB.get( orgId ) );
            } else {
                sharedCourseOrganization.put( AdminAPIConstants.SHARED, "false" );
                sharedCourseOrganization.put( AdminAPIConstants.ASSIGNED, "false" );
            }
            sharedCourseOrganization.put( AdminAPIConstants.ORGANIZATION_NAME, SMUtils.getKeyValueFromResponse( new RBSUtils().getOrg( orgId ), "displayName" ) );
            sharedCourseOrganizationsFromDB.put( orgId, sharedCourseOrganization );
        } );
        return sharedCourseOrganizationsFromDB;
    }

}
