package com.savvas.sm.students.api.tests;

import java.io.IOException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPIConstants.SCOTYPE;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;
import com.savvas.sm.utils.sql.helper.SqlHelperUsage;
import com.savvas.sm.utils.student.api.dashboard.StudentAPI;
import com.savvas.sm.utils.student.api.dashboard.StudentConstants;

import io.restassured.response.Response;

public class PostSessionUsageThisWeek extends EnvProperties {

    private static String smUrl;
    private static String browser;
    private static String orgName;
    private static String orgId;
    private static String teacherDetails;
    private static String teacherUsername;
    private static String teacherUserId;
    private static String teacherAccesstoken;
    private static String studentUsername;
    private static String studentUserId;
    private static String studentAccessToken;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();
    private static String mathTeacherDetails;

    @BeforeClass ( alwaysRun = true )
    public void init() throws IOException {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        orgName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( orgName );

        teacherDetails = RBSDataSetup.getMyTeacher( orgName );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USER_NAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, Constants.USERID );
        teacherAccesstoken = new RBSUtils().getAccessToken( teacherUsername, password );

        mathTeacherDetails = RBSDataSetup.getMyTeacher( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) );

        String studentDetails = RBSDataSetup.getMyStudent( orgName, teacherUsername );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, Constants.USER_NAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, Constants.USERID );

        studentAccessToken = new RBSUtils().getAccessToken( studentUsername, password );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccesstoken );

        Map<String, String> assignmentResponse = new HashMap<>();
        try {
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( AssignmentAPIConstants.MATH, AssignmentAPIConstants.READING ) );
            if ( !assignmentResponse.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignments -" + assignmentResponse.get( Constants.STATUS_CODE ) + "- " + assignmentResponse.get( Constants.REPORT_BODY ) );
        }
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }
        executeCourse( studentUsername, AssignmentAPIConstants.MATH_COURSE, true, "1", false );
        executeCourse( studentUsername, AssignmentAPIConstants.READING_COURSE, false, "1", false );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek001() {

        Log.testCaseInfo( "tc001 :- Verify API is returning 200 status code and response should return sessionThisWeek and usageThisWeek details when we pass valid input" );

        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId, studentAccessToken );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        //status code
        Log.assertThat( response.getStatusCode() == 200, "Status code is returned as expected", "Status code is not returned as expected. Expected - 200 .Actual-" + response.getStatusCode() );

        //Schema validation
        try {
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "postSessionThisWeekUsage", String.valueOf( response.getStatusCode() ), response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );
        } catch ( Exception e ) {
            Log.message( "Getting Issue while validate the schema.Exception -" + e.getMessage() );
            e.printStackTrace();
        }
    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek002() {

        Log.testCaseInfo( "tc002 :- Verify API response should return sessionThisWeek and usageThisWeek details for default Math and Reading assignments" );

        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId, studentAccessToken );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        // To get the assignment user id
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( AssignmentAPIConstants.MATH_COURSE ) );

        JSONArray jsonArray = new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).getJSONArray( "sessionsThisWeek" );
        Log.assertThat( jsonArray.length() == 1, "The session this week usage is fetching the data for default course if the student attended only one session",
                "The session this week usage is not fetching the data  for default cours if the student attended only one session.Expected - 1. Actual -" + jsonArray.length() );

        Map<String, Map<String, String>> sessionThisWeekFromAPI = new HashMap<>();

        IntStream.range( 0, jsonArray.length() ).forEach( iter -> {
            Map<String, String> sessionThisWeek = new Gson().fromJson( jsonArray.get( iter ).toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            sessionThisWeekFromAPI.put( sessionThisWeek.get( "sessionDate" ), sessionThisWeek );
        } );

        //DB Validation
        Map<String, Object> sessionThisWeekUsageForStudent = SqlHelperUsage.getSessionThisWeekUsageForStudent( assignmentUserId, true );
        Log.message( String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) );
        Log.message( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).toString() );

        //Verifying the usage with DB
        Log.assertThat(
                new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                        String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ),
                "API is fetching the proper usage data for default course",
                "API is not fetching the proper usage data for default course. Expected - " + String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) + ".Actual - "
                        + new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                                String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ) );

        Log.assertThat( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( sessionThisWeekFromAPI.get( entry.getKey() ), entry.getValue() ) ),
                "API is fetching the proper session this week data for default course",
                "API is not fetching the proper session this week data for default course.Expected - " + (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) + ".Actual - " + sessionThisWeekFromAPI );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek003() {

        Log.testCaseInfo( "tc003 :- Verify API response should return sessionThisWeek and usageThisWeek details for math custom courses" );

        //Creating the math custom course
        String courseName = String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() );
        String courseId = null;
        try {
            courseId = new CourseAPI().createCourse( smUrl, teacherAccesstoken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName );
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignment!!!" );
        }

        //Assigning the assignment
        Map<String, String> assignmentResponse = new HashMap<>();
        try {
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
            if ( !assignmentResponse.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignments -" + assignmentResponse.get( Constants.STATUS_CODE ) + "- " + assignmentResponse.get( Constants.REPORT_BODY ) );
        }
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        try {
            executeCourse( studentUsername, courseName, true, "1", false );
        } catch ( IOException e ) {
            Log.failsoft( "Getting issue while execute the simulator!!!" );
        }
        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId, studentAccessToken );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        // To get the assignment user id
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName ) );

        JSONArray jsonArray = new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).getJSONArray( "sessionsThisWeek" );

        Map<String, Map<String, String>> sessionThisWeekFromAPI = new HashMap<>();

        IntStream.range( 0, jsonArray.length() ).forEach( iter -> {
            Map<String, String> sessionThisWeek = new Gson().fromJson( jsonArray.get( iter ).toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            sessionThisWeekFromAPI.put( sessionThisWeek.get( "sessionDate" ), sessionThisWeek );
        } );

        //DB Validation
        Map<String, Object> sessionThisWeekUsageForStudent = SqlHelperUsage.getSessionThisWeekUsageForStudent( assignmentUserId, true );
        Log.message( String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) );
        Log.message( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).toString() );

        //Verifying the usage with DB
        Log.assertThat(
                new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                        String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ),
                "API is fetching the proper usage data for custom Math course",
                "API is not fetching the proper usage data for custom Math course. Expected - " + String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) + ".Actual - "
                        + new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                                String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ) );

        Log.assertThat( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( sessionThisWeekFromAPI.get( entry.getKey() ), entry.getValue() ) ),
                "API is fetching the proper session this week data for custom Math course",
                "API is not fetching the proper session this week data for custom Math course.Expected - " + (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) + ".Actual - " + sessionThisWeekFromAPI );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek004() {

        Log.testCaseInfo( "tc004 :- Verify API response should return sessionThisWeek and usageThisWeek details for reading custom courses" );

        //Creating the math custom course
        String courseName = String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() );
        String courseId = null;
        try {
            courseId = new CourseAPI().createCourse( smUrl, teacherAccesstoken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName );
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignment!!!" );
        }

        //Assigning the assignment
        Map<String, String> assignmentResponse = new HashMap<>();
        try {
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
            if ( !assignmentResponse.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignments -" + assignmentResponse.get( Constants.STATUS_CODE ) + "- " + assignmentResponse.get( Constants.REPORT_BODY ) );
        }
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        try {
            executeCourse( studentUsername, courseName, false, "1", false );
        } catch ( IOException e ) {
            Log.failsoft( "Getting issue while execute the simulator!!!" );
        }
        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId, studentAccessToken );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        // To get the assignment user id
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName ) );

        JSONArray jsonArray = new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).getJSONArray( "sessionsThisWeek" );

        Map<String, Map<String, String>> sessionThisWeekFromAPI = new HashMap<>();

        IntStream.range( 0, jsonArray.length() ).forEach( iter -> {
            Map<String, String> sessionThisWeek = new Gson().fromJson( jsonArray.get( iter ).toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            sessionThisWeekFromAPI.put( sessionThisWeek.get( "sessionDate" ), sessionThisWeek );
        } );

        //DB Validation
        Map<String, Object> sessionThisWeekUsageForStudent = SqlHelperUsage.getSessionThisWeekUsageForStudent( assignmentUserId, false );
        Log.message( String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) );
        Log.message( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).toString() );

        //Verifying the usage with DB
        Log.assertThat(
                new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                        String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ),
                "API is fetching the proper usage data for custom Reading course",
                "API is not fetching the proper usage data for custom  course. Expected - " + String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) + ".Actual - "
                        + new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                                String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ) );

        Log.assertThat( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( sessionThisWeekFromAPI.get( entry.getKey() ), entry.getValue() ) ),
                "API is fetching the proper session this week data for custom reading course",
                "API is not fetching the proper session this week data for custom reading course.Expected - " + (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) + ".Actual - " + sessionThisWeekFromAPI );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek005() {

        Log.testCaseInfo( "tc005 :- Verify API response should return sessionThisWeek and usageThisWeek details for math and reading focus courses" );

        //Creating the math focus course
        String courseName = "SM Focus Math: Grade 1";
        String courseId = AssignmentAPIConstants.FOCUS_MATH;

        //Assigning the assignment
        Map<String, String> assignmentResponse = new HashMap<>();
        try {
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
            if ( !assignmentResponse.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignments -" + assignmentResponse.get( Constants.STATUS_CODE ) + "- " + assignmentResponse.get( Constants.REPORT_BODY ) );
        }
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        try {
            executeCourse( studentUsername, courseName, true, "1", false );
        } catch ( IOException e ) {
            Log.failsoft( "Getting issue while execute the simulator!!!" );
        }
        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId, studentAccessToken );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        // To get the assignment user id
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName ) );

        JSONArray jsonArray = new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).getJSONArray( "sessionsThisWeek" );

        Map<String, Map<String, String>> sessionThisWeekFromAPI = new HashMap<>();

        IntStream.range( 0, jsonArray.length() ).forEach( iter -> {
            Map<String, String> sessionThisWeek = new Gson().fromJson( jsonArray.get( iter ).toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            sessionThisWeekFromAPI.put( sessionThisWeek.get( "sessionDate" ), sessionThisWeek );
        } );

        //DB Validation
        Map<String, Object> sessionThisWeekUsageForStudent = SqlHelperUsage.getSessionThisWeekUsageForStudent( assignmentUserId, true );
        Log.message( String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) );
        Log.message( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).toString() );

        //Verifying the usage with DB
        Log.assertThat(
                new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                        String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ),
                "API is fetching the proper usage data for focus course",
                "API is not fetching the proper usage data for focus course. Expected - " + String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) + ".Actual - "
                        + new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                                String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ) );

        Log.assertThat( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( sessionThisWeekFromAPI.get( entry.getKey() ), entry.getValue() ) ),
                "API is fetching the proper session this week data for focus course",
                "API is not fetching the proper session this week data for focus course.Expected - " + (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) + ".Actual - " + sessionThisWeekFromAPI );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek006() {

        Log.testCaseInfo( "tc006 :- Verify API response should return sessionThisWeek and usageThisWeek details for all the assignments from both schools when student belongs to mutliple schools" );

        RBSUtils rbsUtils = new RBSUtils();
        String mutliSchStudentUsername = "multischstud@" + teacherUsername;
        String multiSchoolStudentID = null;
        String mathAssignmentId = null;
        //To create the multiple school student
        try {
            List<String> allUserNamesFromOrg = rbsUtils.getAllUserNamesFromOrg( orgId );

            if ( allUserNamesFromOrg.contains( mutliSchStudentUsername ) ) {
                String userDetail = rbsUtils.getUser( rbsUtils.getUserIDByUserName( mutliSchStudentUsername ) );
                multiSchoolStudentID = SMUtils.getKeyValueFromResponse( userDetail, RBSDataSetupConstants.USERID );
            } else {
                HashMap<String, String> userDetails = new HashMap<>();
                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, mutliSchStudentUsername );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );

                List<String> schools = Arrays.asList( orgId, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) ) );
                String finalSchool = "";
                for ( String school : schools ) {
                    finalSchool += school.concat( "\",\"" );
                }
                finalSchool = finalSchool.substring( 0, finalSchool.length() - 3 );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, finalSchool );
                String studentDetail = new RBSUtils().createUser( userDetails );
                multiSchoolStudentID = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERID );

                HashMap<String, String> studentInfo = new HashMap<>();
                studentInfo = RBSDataSetup.generateRequestValues( studentDetail, studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.SCHOOLID, orgId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, UserConstants.TEACHER_ID, teacherUserId );
                studentInfo = SMUtils.updateRequestBodyValues( studentInfo, RBSDataSetupConstants.BEARER_TOKEN, teacherAccesstoken );
                Log.message( "Updating grade..." );
                new UserAPI().updateStudentProfile( smUrl, studentInfo );

            }

            //Group Creation in flex school
            HashMap<String, String> groupDetails = new HashMap<>();
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccesstoken );
            groupDetails.put( GroupConstants.GROUP_OWNER_ID, teacherUserId );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
            groupDetails.put( GroupConstants.GROUP_NAME, "Group " + System.nanoTime() );

            HashMap<String, String> createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( multiSchoolStudentID ) );

            if ( createGroup.get( "statusCode" ).equals( "201" ) ) {
                Log.message( "Group Created in Flex School for multiple school student" );
            }

            //Group Creation in math school
            groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbsUtils.getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USER_NAME ), password ) );
            groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USERID ) );
            groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            groupDetails.put( GroupConstants.GROUP_NAME, "Group " + System.nanoTime() );

            createGroup = new GroupAPI().createGroup( smUrl, groupDetails, Arrays.asList( multiSchoolStudentID ) );

            if ( createGroup.get( "statusCode" ).equals( "201" ) ) {
                Log.message( "Group Created in Math School for multiple school student" );
            }

            //Assigning math assignment from math school teacher
            HashMap<String, String> assignmentDetails = new HashMap<>();
            assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.MATH_SCHOOL ) ) );
            assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USERID ) );
            assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, rbsUtils.getAccessToken( SMUtils.getKeyValueFromResponse( mathTeacherDetails, Constants.USER_NAME ), password ) );
            Map<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( multiSchoolStudentID ), Arrays.asList( "1" ) );

            JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
            JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

            for ( Object assignment : assignmentList ) {
                JSONObject assignmentInfo = new JSONObject( assignment.toString() );
                mathAssignmentId = assignmentInfo.get( "assignmentId" ).toString();
            }
        } catch ( Exception e ) {
            Log.message( "Issue in creating the assignment" );
            e.printStackTrace();
        }

        try {
            executeCourse( mutliSchStudentUsername, AssignmentAPIConstants.MATH_COURSE, true, "1", false );
        } catch ( IOException e ) {
            Log.failsoft( "Getting issue while execute the simulator!!!" );
        }
        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, multiSchoolStudentID, orgId, rbsUtils.getAccessToken( mutliSchStudentUsername, password ) );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        // To get the assignment user id
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( multiSchoolStudentID, mathAssignmentId );

        JSONArray jsonArray = new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).getJSONArray( "sessionsThisWeek" );

        Map<String, Map<String, String>> sessionThisWeekFromAPI = new HashMap<>();

        IntStream.range( 0, jsonArray.length() ).forEach( iter -> {
            Map<String, String> sessionThisWeek = new Gson().fromJson( jsonArray.get( iter ).toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            sessionThisWeekFromAPI.put( sessionThisWeek.get( "sessionDate" ), sessionThisWeek );
        } );

        //DB Validation
        Map<String, Object> sessionThisWeekUsageForStudent = SqlHelperUsage.getSessionThisWeekUsageForStudent( assignmentUserId, true );
        Log.message( String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) );
        Log.message( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).toString() );

        //Verifying the usage with DB
        Log.assertThat(
                new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                        String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ),
                "API is fetching the proper usage data for default course fro multiple school student",
                "API is not fetching the proper usage data for default course for Multiple school student . Expected - " + String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) + ".Actual - "
                        + new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                                String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ) );

        Log.assertThat( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( sessionThisWeekFromAPI.get( entry.getKey() ), entry.getValue() ) ),
                "API is fetching the proper session this week data for default course",
                "API is not fetching the proper session this week data for default course.Expected - " + (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) + ".Actual - " + sessionThisWeekFromAPI );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek007() {

        Log.testCaseInfo( "tc007 :- Verify API response should return sessionThisWeek will return 0 for session attempts and session corrects for fluency assignment" );

        //Creating the math custom course
        String courseName = String.format( DataSetupConstants.SKILL_COURSE_NAME_READING + "_fluency", System.nanoTime() );
        String courseId = null;
        try {
            courseId = new CourseAPI().createReadingCourseBasedOnSCO( smUrl, teacherAccesstoken, teacherUserId, orgId, courseName, Arrays.asList( SCOTYPE.Fluency, SCOTYPE.videoSco ) );
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignment!!!" );
        }

        //Assigning the assignment
        Map<String, String> assignmentResponse = new HashMap<>();
        try {
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
            if ( !assignmentResponse.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignments -" + assignmentResponse.get( Constants.STATUS_CODE ) + "- " + assignmentResponse.get( Constants.REPORT_BODY ) );
        }
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        try {
            executeCourse( studentUsername, courseName, false, "1", false );
        } catch ( IOException e ) {
            Log.failsoft( "Getting issue while execute the simulator!!!" );
        }
        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId, studentAccessToken );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        // To get the assignment user id
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName ) );

        JSONArray jsonArray = new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).getJSONArray( "sessionsThisWeek" );

        Map<String, Map<String, String>> sessionThisWeekFromAPI = new HashMap<>();

        IntStream.range( 0, jsonArray.length() ).forEach( iter -> {
            Map<String, String> sessionThisWeek = new Gson().fromJson( jsonArray.get( iter ).toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            sessionThisWeekFromAPI.put( sessionThisWeek.get( "sessionDate" ), sessionThisWeek );
        } );

        //DB Validation
        Map<String, Object> sessionThisWeekUsageForStudent = SqlHelperUsage.getSessionThisWeekUsageForStudent( assignmentUserId, false );
        Log.message( String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) );
        Log.message( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).toString() );

        //Verifying the usage with DB
        Log.assertThat(
                new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                        String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ),
                "API is fetching the proper usage data for fluency course",
                "API is not fetching the proper usage data for fluency course. Expected - " + String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) + ".Actual - "
                        + new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                                String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ) );

        Log.assertThat( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( sessionThisWeekFromAPI.get( entry.getKey() ), entry.getValue() ) ),
                "API is fetching the proper session this week data for fluency course",
                "API is not fetching the proper session this week data for fluency course.Expected - " + (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) + ".Actual - " + sessionThisWeekFromAPI );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek008() {

        Log.testCaseInfo( "tc008 :- Verify API response should return sessionThisWeek will return 5 for session attempts and session corrects for fluency with additional sco assignment" );

        //Creating the math custom course
        String courseName = String.format( DataSetupConstants.SKILL_COURSE_NAME_READING + "_fluency", System.nanoTime() );
        String courseId = null;
        try {
            courseId = new CourseAPI().createReadingCourseBasedOnSCO( smUrl, teacherAccesstoken, teacherUserId, orgId, courseName, Arrays.asList( SCOTYPE.Fluency, SCOTYPE.Comprehension ) );
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignment!!!" );
        }

        //Assigning the assignment
        Map<String, String> assignmentResponse = new HashMap<>();
        try {
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
            if ( !assignmentResponse.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignments -" + assignmentResponse.get( Constants.STATUS_CODE ) + "- " + assignmentResponse.get( Constants.REPORT_BODY ) );
        }
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        try {
            executeCourse( studentUsername, courseName, false, "1", false );
        } catch ( IOException e ) {
            Log.failsoft( "Getting issue while execute the simulator!!!" );
        }
        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId, studentAccessToken );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        // To get the assignment user id
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName ) );

        JSONArray jsonArray = new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).getJSONArray( "sessionsThisWeek" );

        Map<String, Map<String, String>> sessionThisWeekFromAPI = new HashMap<>();

        IntStream.range( 0, jsonArray.length() ).forEach( iter -> {
            Map<String, String> sessionThisWeek = new Gson().fromJson( jsonArray.get( iter ).toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            sessionThisWeekFromAPI.put( sessionThisWeek.get( "sessionDate" ), sessionThisWeek );
        } );

        //DB Validation
        Map<String, Object> sessionThisWeekUsageForStudent = SqlHelperUsage.getSessionThisWeekUsageForStudent( assignmentUserId, false );
        Log.message( String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) );
        Log.message( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).toString() );

        //Verifying the usage with DB
        Log.assertThat(
                new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                        String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ),
                "API is fetching the proper usage data for fluency course",
                "API is not fetching the proper usage data for fluency course. Expected - " + String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) + ".Actual - "
                        + new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                                String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ) );

        Log.assertThat( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( sessionThisWeekFromAPI.get( entry.getKey() ), entry.getValue() ) ),
                "API is fetching the proper session this week data for fluency course",
                "API is not fetching the proper session this week data for fluency course.Expected - " + (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) + ".Actual - " + sessionThisWeekFromAPI );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek009() {

        Log.testCaseInfo( "tc009 :- Verify API response should return sessionThisWeek will return 7 for session attempts and session corrects for Math tutorial assignment(which excludes tutorial attempts)" );

        //Creating the math custom course
        String courseName = String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH + "_tutorial", System.nanoTime() );
        String courseId = null;
        try {
            courseId = new CourseAPI().createCourse( smUrl, teacherAccesstoken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName );
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignment!!!" );
        }

        //Assigning the assignment
        Map<String, String> assignmentResponse = new HashMap<>();
        try {
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
            if ( !assignmentResponse.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignments -" + assignmentResponse.get( Constants.STATUS_CODE ) + "- " + assignmentResponse.get( Constants.REPORT_BODY ) );
        }
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        try {
            executeCourse( studentUsername, courseName, true, "2", true );
        } catch ( IOException e ) {
            Log.failsoft( "Getting issue while execute the simulator!!!" );
        }
        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId, studentAccessToken );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        // To get the assignment user id
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName ) );

        JSONArray jsonArray = new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).getJSONArray( "sessionsThisWeek" );

        Map<String, Map<String, String>> sessionThisWeekFromAPI = new HashMap<>();

        IntStream.range( 0, jsonArray.length() ).forEach( iter -> {
            Map<String, String> sessionThisWeek = new Gson().fromJson( jsonArray.get( iter ).toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            sessionThisWeekFromAPI.put( sessionThisWeek.get( "sessionDate" ), sessionThisWeek );
        } );

        //DB Validation
        Map<String, Object> sessionThisWeekUsageForStudent = SqlHelperUsage.getSessionThisWeekUsageForStudent( assignmentUserId, true );
        Log.message( String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) );
        Log.message( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).toString() );

        //Verifying the usage with DB
        Log.assertThat(
                new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                        String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ),
                "API is fetching the proper usage data for tutorial course",
                "API is not fetching the proper usage data for tutorial course. Expected - " + String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) + ".Actual - "
                        + new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                                String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ) );

        Log.assertThat( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( sessionThisWeekFromAPI.get( entry.getKey() ), entry.getValue() ) ),
                "API is fetching the proper session this week data for tutorial course",
                "API is not fetching the proper session this week data for tutorial course.Expected - " + (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) + ".Actual - " + sessionThisWeekFromAPI );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek010() {

        Log.testCaseInfo( "tc010 :- Verify API response should return sessionThisWeek will return 0 for session attempts and session corrects for video assignment" );

        //Creating the math custom course
        String courseName = String.format( DataSetupConstants.SKILL_COURSE_NAME_READING + "_VideoSco", System.nanoTime() );
        String courseId = null;
        try {
            courseId = new CourseAPI().createReadingCourseBasedOnSCO( smUrl, teacherAccesstoken, teacherUserId, orgId, courseName, Arrays.asList( SCOTYPE.videoSco, SCOTYPE.Fluency ) );
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignment!!!" );
        }

        //Assigning the assignment
        Map<String, String> assignmentResponse = new HashMap<>();
        try {
            assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, Arrays.asList( studentUserId ), Arrays.asList( courseId ) );
            if ( !assignmentResponse.get( Constants.STATUS_CODE ).startsWith( "2" ) ) {
                throw new Exception();
            }
        } catch ( Exception e ) {
            Log.fail( "Getting issue while assigning the assignments -" + assignmentResponse.get( Constants.STATUS_CODE ) + "- " + assignmentResponse.get( Constants.REPORT_BODY ) );
        }
        Log.message( "Assignment Details" + assignmentResponse );

        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }

        try {
            executeCourse( studentUsername, courseName, false, "1", false );
        } catch ( IOException e ) {
            Log.failsoft( "Getting issue while execute the simulator!!!" );
        }
        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId, studentAccessToken );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        // To get the assignment user id
        String assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName ) );

        JSONArray jsonArray = new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).getJSONArray( "sessionsThisWeek" );

        Map<String, Map<String, String>> sessionThisWeekFromAPI = new HashMap<>();

        IntStream.range( 0, jsonArray.length() ).forEach( iter -> {
            Map<String, String> sessionThisWeek = new Gson().fromJson( jsonArray.get( iter ).toString(), new TypeToken<HashMap<String, String>>() {}.getType() );
            sessionThisWeekFromAPI.put( sessionThisWeek.get( "sessionDate" ), sessionThisWeek );
        } );

        //DB Validation
        Map<String, Object> sessionThisWeekUsageForStudent = SqlHelperUsage.getSessionThisWeekUsageForStudent( assignmentUserId, false );
        Log.message( String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) );
        Log.message( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).toString() );

        //Verifying the usage with DB
        Log.assertThat(
                new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                        String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ),
                "API is fetching the proper usage data if the student attende only video sco",
                "API is not fetching the proper usage data if the student attende only video sco. Expected - " + String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) + ".Actual - "
                        + new JSONObject( new JSONObject( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ) ).get( assignmentUserId ).toString() ).get( "usageThisWeek" ).toString().equals(
                                String.valueOf( sessionThisWeekUsageForStudent.get( "usage" ) ) ) );

        Log.assertThat( ( (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) ).entrySet().stream().allMatch( entry -> SMUtils.compareTwoHashMap( sessionThisWeekFromAPI.get( entry.getKey() ), entry.getValue() ) ),
                "API is fetching the proper session this week data if the student attende only video sco", "API is not fetching the proper session this week data if the student attende only video sco.Expected - "
                        + (Map<String, Map<String, String>>) sessionThisWeekUsageForStudent.get( "sessionThisWeek" ) + ".Actual - " + sessionThisWeekFromAPI );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek011() {

        Log.testCaseInfo( "tc011 :-Verify API response should return status code as 403 when teacher access token is passed in header" );

        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId, teacherAccesstoken );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        //status code validation
        Log.assertThat( response.getStatusCode() == 401, "Status code is returned as expected", "Status code is not returned as expected. Expected - 401 .Actual-" + response.getStatusCode() );

        Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "messages,message" ).equalsIgnoreCase( "Authentication Failed" ), " error message is displayed as expected",
                "error message is not displayed as expected .Actual-" + response.getBody().asString() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek012() {

        Log.testCaseInfo( "tc012 :-Verify API response should return status code as 401 when invalid student access token is passed in header" );

        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId, studentAccessToken + "Invalid" );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        //status code validation
        Log.assertThat( response.getStatusCode() == 401, "Status code is returned as expected", "Status code is not returned as expected. Expected - 401 .Actual-" + response.getStatusCode() );

        Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "messages,message" ).equalsIgnoreCase( "Authentication Failed" ), " error message is displayed as expected",
                "error message is not displayed as expected .Actual-" + response.getBody().asString() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek013() {

        Log.testCaseInfo( "tc013 :-Verify API response should return status code as 404 when invalid end point is passed in API Request" );

        String endPoint = StudentConstants.POST_SESSTION_THIS_WEEK_USAGE + "/invalid";

        //Headers
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + studentAccessToken );
        headers.put( Constants.USERID_SM_HEADER, studentUserId );
        headers.put( Constants.ORGID_SM_HEADER, orgId );

        endPoint = endPoint.replace( "{studentId}", studentUserId );

        AtomicReference<String> requestBody = new AtomicReference<>();
        requestBody.set( SMUtils.getPayload( PayloadFor.STUDENT, "getSessionThisWeekUsage.json" ) );

        //To get first day of week and last day of week
        Calendar calendar = Calendar.getInstance();
        calendar.set( Calendar.DAY_OF_WEEK, Calendar.MONDAY );
        calendar.set( Calendar.HOUR_OF_DAY, 0 );
        calendar.set( Calendar.MINUTE, 0 );
        calendar.set( Calendar.SECOND, 0 );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "thisWeekStartDate", calendar.getTime().getTime() / 1000 ) );

        calendar.add( Calendar.DATE, 7 );
        requestBody.set( JSONUtil.setProperty( requestBody.get(), "thisWeekEndDate", calendar.getTime().getTime() / 1000 ) );

        Log.message( "Request Paylod - " + requestBody.get() );
        Response response = RestAssuredAPIUtil.POST( smUrl, headers, requestBody.get(), endPoint );

        //status code validation
        Log.assertThat( response.getStatusCode() == 404, "Status code is returned as expected", "Status code is not returned as expected. Expected - 404 .Actual-" + response.getStatusCode() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek014() {

        Log.testCaseInfo( "tc014 :- Verify API response should return status code as 401 when invalid user-id is passed in header" );

        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId + "invalid", orgId, studentAccessToken + "Invalid" );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        //status code validation
        Log.assertThat( response.getStatusCode() == 401, "Status code is returned as expected", "Status code is not returned as expected. Expected - 401 .Actual-" + response.getStatusCode() );

        Log.assertThat( SMUtils.getKeyValueFromResponse( response.getBody().asString(), "messages,message" ).equalsIgnoreCase( "Authentication Failed" ), " error message is displayed as expected",
                "error message is not displayed as expected .Actual-" + response.getBody().asString() );

    }

    @Test ( enabled = true, groups = { "smoke_test_case", "postSessionUsageThisWeek", "P1", "SMK-70073" }, priority = 1 )
    public void getSessionThisWeek015() {

        Log.testCaseInfo( "tc015 :- Verify API response should return status code as 403 when invalid org-id is passed in header" );

        //To hit the session this week API response
        Response response = StudentAPI.getSessionThisWeekUsageForStudent( smUrl, studentUserId, orgId + "invalid", studentAccessToken );
        Log.message( response.getStatusCode() + " - " + response.getBody().asString() );

        //status code validation
        Log.assertThat( response.getStatusCode() == 403, "Status code is returned as expected", "Status code is not returned as expected. Expected - 403 .Actual-" + response.getStatusCode() );

    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath, String sessionCount, boolean isTutorialSession ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                if ( isTutorialSession ) {
                    studentsPage.executeMathCourse( studentUserName, courseName, "2", sessionCount, "10" );
                } else {
                    studentsPage.executeMathCourse( studentUserName, courseName, "100", sessionCount, "2" );
                }
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", sessionCount, "1" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

}
