package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;

public class AssignGroupAssignmentMissingStudents extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String districtId;
    private String teacherId;
    private String assignmentID;
    private String AssignmentUserId;
    private String CourseId;
    RBSUtils rbsutils = new RBSUtils();
    Map<String, String> assignmentResponse = new HashMap<>();
    private String studentDetail;
    private String studentUserID;
    String studentID = null;
    GroupAPI add = new GroupAPI();
    CourseAPI courseAPI = new CourseAPI();
    String username;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        districtId = configProperty.getProperty( "district_ID" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentDetail = RBSDataSetup.getMyStudent( school, username );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
    }

    @Test ( priority = 1, dataProvider = "GroupAssignmentsPositiveFlow", groups = { "SMK-56779", "smoke_test_case", "GroupAssignmentsAPI", "GroupAssignmentsMissingStudentsAPI", "P1", "API" } )
    public void tcPostiveforassignGroupAssignmentAPI( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> userDetails = new HashMap<>();

        List<String> studentRumbaIds = new ArrayList<>();
        List<String> groupIds = new ArrayList<>();
        String endpoint = "null";
        String reqParam = "null";

        studentRumbaIds.add( studentUserID );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

        HashMap<String, String> Response = new HashMap<>();
        HashMap<String, String> studentResponse = new HashMap<>();

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );
        String organizationId = RBSDataSetup.organizationIDs.get( school );

        HashMap<String, String> response = add.createGroup( smUrl, groupDetails, studentRumbaIds );
        if ( response.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }
        Log.message( response.get( "body" ) );
        String groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

        switch ( scenario ) {
            case "Default Math Assignment Group":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                HashMap<String, String> assignAssignment = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignment.get( "body" ) );
                String studentUsername = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsername );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                break;

            case "Default Reading Assignment Group":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                HashMap<String, String> assignAssignmentReading = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentReading.get( "body" ) );
                String studentUsernamea = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernamea );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                break;

            case "Focus Reading Assignment Group":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_READING );
                HashMap<String, String> assignAssignmentfocusReading = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentfocusReading.get( "body" ) );
                String studentUsernameb = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernameb );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                break;

            case "Focus Math Assignment Group":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.FOCUS_MATH );
                HashMap<String, String> assignAssignmentfocusmath = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentfocusmath.get( "body" ) );
                String studentUsernamec = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernamec );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                break;

            case "Custom By Skills - Math Assignment Group":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.SKILL,
                        String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                HashMap<String, String> assignAssignmentCustomMathSkill = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentCustomMathSkill.get( "body" ) );
                String studentUsernamed = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernamed );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                break;

            case "Custom By Settings - Math Assignment Group":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.SETTINGS,
                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                HashMap<String, String> assignAssignmentCustomMathSettings = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentCustomMathSettings.get( "body" ) );
                String studentUsernamee = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernamee );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                break;

            case "Custom By Standard - Math Assignment Group":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.MATH, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.STANDARD,
                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );

                HashMap<String, String> assignAssignmentCustomMathStandards = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentCustomMathStandards.get( "body" ) );
                String studentUsernamef = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernamef );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                break;

            case "Custom By Skills - Reading Assignment Group":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.SKILL,
                        String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                HashMap<String, String> assignAssignmentCustomReadingSkills = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentCustomReadingSkills.get( "body" ) );
                String studentUsernameg = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernameg );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                break;

            case "Custom By Settings - Reading Assignment Group":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, teacherId.toString(), organizationId.toString(), DataSetupConstants.SETTINGS,
                        String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                HashMap<String, String> assignAssignmentCustomReadingSettings = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentCustomReadingSettings.get( "body" ) );
                String studentUsernamegh = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernamegh );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                break;
            case "Custom By Standard - Reading Assignment Group":
                CourseId = courseAPI.createCourse( smUrl, token, DataSetupConstants.READING, assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), assignmentDetails.get( AssignmentAPIConstants.ORG_ID ), DataSetupConstants.STANDARD,
                        String.format( DataSetupConstants.STANDARD_COURSE_NAME_READING, System.nanoTime() ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, CourseId );
                HashMap<String, String> assignAssignmentCustomReadingStandards = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentCustomReadingStandards.get( "body" ) );
                String studentUsernamei = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernamei );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                break;
            default:
                Log.message( "Case is invalid" );
                break;
        }

        HashMap<String, String> responsea = groupAssignmentGroupStudents( smUrl, assignmentDetails, endpoint, reqParam );
        Log.assertThat( responsea.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );
        //Log.message("Response: " + responsea.get("body"));
        // Log.testCaseResult();

    }

    @Test ( priority = 2, dataProvider = "GroupAssignmentNegativeFlow", groups = { "SMK-56779", "GroupAssignmentsAPI", "GroupAssignmentsMissingStudentsAPI", "P1", "API" } )
    public void tcNegativeforassignGroupAssignmentAPI( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );
        HashMap<String, String> assignmentDetails = new HashMap<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> userDetails = new HashMap<>();

        List<String> studentRumbaIds = new ArrayList<>();
        List<String> groupIds = new ArrayList<>();

        String endpoint = "null";
        String exception = null;
        boolean status = false;
        String message = null;
        String reqParam = "null";

        studentRumbaIds.add( studentUserID );
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );

        HashMap<String, String> studentResponse = new HashMap<>();

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" );

        HashMap<String, String> response = add.createGroup( smUrl, groupDetails, studentRumbaIds );
        if ( response.get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
            Log.message( "Group created for the student !" );
        }
        Log.message( response.get( "body" ) );
        String groupId = SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), Constants.GROUP_ID_DATAVALUE );

        switch ( scenario ) {
            case "Invalid Staffid - Path":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                HashMap<String, String> assignAssignment = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignment.get( "body" ) );
                String studentUsername = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsername );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                endpoint = AssignmentAPIConstants.GROUP_ASSIGNMNETS_GROUP;
                endpoint = endpoint.replace( "{teacherID}", "abc" );
                break;

            case "Invalid orgid - Path":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                HashMap<String, String> assignAssignmentOrg = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentOrg.get( "body" ) );
                String studentUsernameOrg = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernameOrg );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                endpoint = AssignmentAPIConstants.GROUP_ASSIGNMNETS_GROUP;
                endpoint = endpoint.replace( "{teacherID}", "abc" );
                break;

            case "Different orgid - Header":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                HashMap<String, String> assignAssignmentb = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentb.get( "body" ) );
                String studentUsernameb = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernameb );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, CommonAPIConstants.INVALID_ORG_ID );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                break;

            case "Different staffid -Header":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.READING );
                HashMap<String, String> assignAssignmentc = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentc.get( "body" ) );
                String studentUsernamec = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernamec );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, CommonAPIConstants.INVALID_STAFF_ID );
                exception = CommonAPIConstants.BUSINESS_RULE_VIOLATION;
                break;

            case "Empty staffid -Path":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                HashMap<String, String> assignAssignmentk = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentk.get( "body" ) );
                String studentUsernamek = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernamek );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                endpoint = AssignmentAPIConstants.GROUP_ASSIGNMNETS_GROUP;
                endpoint = endpoint.replace( "{teacherID}", "1" );
                break;

            case "Invalid staffid -Header":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                HashMap<String, String> assignAssignmente = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmente.get( "body" ) );
                String studentUsernamee = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernamee );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, "abc" );
                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;
                break;

            case "Invalid orgid - Header":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                HashMap<String, String> assignAssignmentHed = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentHed.get( "body" ) );
                String studentUsernameHed = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernameHed );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, "abc" );

                exception = CommonAPIConstants.FORBIDDAN_EXCEPTION;
                message = CommonAPIConstants.FORBIDDAN_MESSAGE;

                break;

            case "Invalid Authorization":
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.MATH );
                HashMap<String, String> assignAssignmentg = assignAssignment( smUrl, assignmentDetails, Arrays.asList( groupId ), AssignmentAPIConstants.GROUPS_TYPE );
                Log.message( assignAssignmentg.get( "body" ) );
                String studentUsernameg = "AddStudGRPS1" + System.nanoTime();

                userDetails.put( RBSDataSetupConstants.CREATED_BY, configProperty.getProperty( Constants.ADMIN_ID_VALUE ) );
                userDetails.put( RBSDataSetupConstants.USERNAME, studentUsernameg );
                userDetails.put( RBSDataSetupConstants.ROLE, RBSDataSetupConstants.STUDENT_ROLE );
                userDetails.put( RBSDataSetupConstants.ORGANIZATIONIDS, groupDetails.get( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID ) );

                studentID = SMUtils.getKeyValueFromResponse( new RBSUtils().createUser( userDetails ), RBSDataSetupConstants.USERID );
                studentRumbaIds.add( studentID );
                groupIds.add( groupId );
                studentResponse = add.addStudentToGroup( smUrl, groupDetails, studentRumbaIds, groupIds );
                Log.message( studentResponse.get( "body" ) );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                exception = CommonAPIConstants.AUTHENTICATION_EXCEPTION;
                message = CommonAPIConstants.INVALID_AUTHENTICATION_MESSAGE;
                status = true;
                break;

            default:
                Log.message( "Case is invalid" );
                break;
        }

        Log.message( "URL : " + smUrl );
        Log.message( "Assignment Details : " + assignmentDetails );
        Log.message( "Endpoint : " + endpoint );
        Log.message( "Req Param : " + reqParam );

        HashMap<String, String> responseNeg = groupAssignmentGroupStudents( smUrl, assignmentDetails, endpoint, reqParam );
        Log.assertThat( responseNeg.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + response.get( Constants.STATUS_CODE ) );

        Log.message( "Response: " + responseNeg.get( "body" ) );
        // Log.testCaseResult();

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */

    @DataProvider ( name = "GroupAssignmentsPositiveFlow" )
    public Object[][] groupAssignmentsPositiveFlow() {

        Object[][] inputData = { { "Validate 202 for Group Math Assignment", "Default Math Assignment Group", CommonAPIConstants.STATUS_CODE_ACCEPTED },
                { "Validate 202 for Group Reading Assignment", "Default Reading Assignment Group", CommonAPIConstants.STATUS_CODE_ACCEPTED },
                { "Validate 202 for Group Focus Reading Assignment", "Focus Reading Assignment Group", CommonAPIConstants.STATUS_CODE_ACCEPTED },
                { "Validate 202 for Group Focus Math Assignment", "Focus Math Assignment Group", CommonAPIConstants.STATUS_CODE_ACCEPTED },
                { "Validate 202 for Group Custom By Skills - Math Assignment", "Custom By Skills - Math Assignment Group", CommonAPIConstants.STATUS_CODE_ACCEPTED },
                { "Validate 202 for Group Custom By Settings - Math Assignment", "Custom By Settings - Math Assignment Group", CommonAPIConstants.STATUS_CODE_ACCEPTED },
                { "Validate 202 for Group Custom By Standard - Math Assignment", "Custom By Standard - Math Assignment Group", CommonAPIConstants.STATUS_CODE_ACCEPTED },
                { "Validate 202 for Group Custom By Skills - Reading Assignment", "Custom By Skills - Reading Assignment Group", CommonAPIConstants.STATUS_CODE_ACCEPTED },
                { "Validate 202 for Group Custom By Settings - Reading Assignment", "Custom By Settings - Reading Assignment Group", CommonAPIConstants.STATUS_CODE_ACCEPTED },
                { "Validate 202 for Group Custom By Standard - Reading Assignment", "Custom By Standard - Reading Assignment Group", CommonAPIConstants.STATUS_CODE_ACCEPTED }

        };
        return inputData;
    }

    /**
     * Data provider for negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "GroupAssignmentNegativeFlow" )
    public Object[][] groupAssignmentsNegativeFlow() {

        Object[][] inputData = { { "Verify the status code is 400 -Invalid orgid - Path", "Invalid orgid - Path", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the status code is 403 when the different ord-id passed in headers section", "Different orgid - Header", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code is 401 when the different StaffId passed in headers section", "Different staffid -Header", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify that the status code is 400 without passing assignmentUserId in request body", "Empty staffid -Path", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the status code is 400 -Invalid Staffid - Path ", "Invalid Staffid - Path", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },

                { "Verify the status code is 403 when the Invalid ord-id passed in headers section", "Invalid orgid - Header", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the status code is 401 when the Invalid StaffId passed in headers section", "Invalid staffid -Header", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },
                { "Verify that the status code is 401 while passing invalid Authorization", "Invalid Authorization", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED },

        };
        return inputData;
    }

    /**
     * Verifies the exception
     * 
     * @param actualResponse
     * @param exception
     * @param failureStatus
     * @param message
     * @return
     * @throws IOException
     */
    public boolean verifyException( String actualResponse, String exception, boolean failureStatus, String message ) throws IOException {

        boolean isVerified = false;
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,exception" ).equalsIgnoreCase( exception ) ) {
            Log.pass( "Exception Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying exception!" );
        }
        if ( failureStatus ) {
            if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {
                Log.pass( "Status Verified successfully!" );
                isVerified = true;
            } else {
                Log.fail( "Issue in displaying Status!" );
            }
        }
        if ( SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ).contains( message ) ) {
            Log.pass( "Message Verified successfully!" );
            isVerified = true;
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + message + " Actual - " + SMUtils.getKeyValueFromResponse( actualResponse, "messages,message" ) );
        }
        return isVerified;
    }

}
