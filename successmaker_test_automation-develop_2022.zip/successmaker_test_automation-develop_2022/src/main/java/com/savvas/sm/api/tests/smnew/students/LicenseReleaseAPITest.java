package com.savvas.sm.api.tests.smnew.students;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.student.api.licenses.StudentDashboardAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

import io.restassured.response.Response;

public class LicenseReleaseAPITest extends EnvProperties {

    private String smUrl;
    private String school;
    private String teacherDetails;
    private String teacherUsername;
    private String teacherUserId;
    private String orgId;
    private String studentDetails;
    private String studentUsername;
    private String studentUserId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private List<String> studentRumbaIds = new ArrayList<>();
    private Map<String, String> courseName = new HashMap<>();
    private Map<String, String> courseIds = new HashMap<>();
    private Map<String, String> assignmentIds = new HashMap<>();

    @BeforeClass ( alwaysRun = true )
    public void init() {
        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        studentDetails = RBSDataSetup.getMyStudent( school, teacherUsername );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERNAME );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, RBSDataSetupConstants.USERID ) );

        //Math Course Names
        courseName.put( Constants.MATH, AssignmentAPIConstants.MATH_COURSE );
        courseName.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_MATH, System.nanoTime() ) );
        courseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, "SM Focus Math: Grade 1" );

        //Reading Course Names
        courseName.put( Constants.READING, AssignmentAPIConstants.READING_COURSE );
        courseName.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE, String.format( DataSetupConstants.SETTINGS_COURSE_NAME_READING, System.nanoTime() ) );
        courseName.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, "SM Focus Reading: Grade 1" );

        String teacherAccessToken = null;
        try {
            teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
        } catch ( Exception e ) {
            Log.message( "Issue in get the accces token - " + e.getMessage() );
            try {
                Log.message( "Retrying to get the access token!!!!" );
                teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD );
            } catch ( Exception e1 ) {
                Log.fail( "Unable to create the access token for the teacher - " + teacherUsername );
            }
        }

        //Math course Ids
        courseIds.put( Constants.MATH, AssignmentAPIConstants.MATH );
        courseIds.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_MATH );
        try {
            courseIds.put( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.MATH, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );

        } catch ( Exception e ) {
            Log.message( "Issue in Math Custom course creation!! - " + e.getMessage() );
        }

        //Reading course Ids
        courseIds.put( Constants.READING, AssignmentAPIConstants.READING );
        courseIds.put( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS, AssignmentAPIConstants.FOCUS_READING_1 );
        try {
            courseIds.put( Constants.CUSTOM_BY_SETTINGS_READING_COURSE,
                    new CourseAPI().createCourse( smUrl, teacherAccessToken, DataSetupConstants.READING, teacherUserId, orgId, DataSetupConstants.SETTINGS, courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
        } catch ( Exception e ) {
            Log.message( "Issue in Reading Custom course creation!! - " + e.getMessage() );
        }

        Log.message( "Course Ids for " + school + ": " + courseIds );

        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        staffDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId );
        staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );

        try {
            //Assigning Assignment
            Log.message( "Assigning assignment..." );

            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, staffDetails, studentRumbaIds, new ArrayList<>( courseIds.values() ) );
            Log.message( "Assignment Response : " + assignmentResponse );

            JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
            JSONArray assignmentList = assignmentDetailsJson.getJSONArray( Constants.DATA );

            for ( Object assignment : assignmentList ) {
                JSONObject assignmentInfo = new JSONObject( assignment.toString() );
                assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
            }
            Log.message( "Assignment IDs - " + assignmentIds );
        } catch ( Exception e ) {
            Log.fail( "Issue in Assigning the assignment to the student!! - " + e.getMessage() );
        }
    }

    @Test ( dataProvider = "positiveScenarios", groups = { "smoke_test_case", "LicenseRelease", "studentDashboardAPI", "SMK-67610" }, priority = 1 )
    public void studentDashboard_licenseReleaseTest001( String tcId, String testDescription, String scenario ) {

        Response response = null;
        StudentDashboardAPI studentDashboardAPI = new StudentDashboardAPI();
        String sessionId;
        String assignmentUserId;
        switch ( scenario ) {
            case "MATH_ASSIGNMENT":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.MATH ) ) );
                sessionId = studentDashboardAPI.getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = studentDashboardAPI.releaseLicense( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                break;

            case "READING_ASSIGNMENT":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.READING ) ) );
                sessionId = studentDashboardAPI.getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = studentDashboardAPI.releaseLicense( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                break;

            case "MATH_CUSTOM_COURSE":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SETTINGS_MATH_COURSE ) ) );
                sessionId = studentDashboardAPI.getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = studentDashboardAPI.releaseLicense( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                break;

            case "READING_CUSTOM_COURSE":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( Constants.CUSTOM_BY_SETTINGS_READING_COURSE ) ) );
                sessionId = studentDashboardAPI.getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = studentDashboardAPI.releaseLicense( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                break;

            case "MATH_FOCUS_COURSE":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.FOCUS ) ) );
                sessionId = studentDashboardAPI.getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = studentDashboardAPI.releaseLicense( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                break;

            case "READING_FOCUS_COURSE":
                assignmentUserId = SqlHelperAssignment.getAssignmentUserID( studentUserId, assignmentIds.get( courseName.get( AssignmentAPIConstants.READING_COURSE + AssignmentAPIConstants.FOCUS ) ) );
                sessionId = studentDashboardAPI.getSessionId( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId );
                response = studentDashboardAPI.releaseLicense( smUrl, studentUserId, orgId, studentUsername, password, assignmentUserId, sessionId );
                break;

            default:
                break;
        }
        Log.assertThat( response.getStatusCode() == 200, "Getting the 200 satus code for license release Test", "Not Getting the 200 satus code for license release Test" );

    }

    @DataProvider ( name = "positiveScenarios" )
    public Object[][] positiveScenarios() {

        Object[][] inputData = { { "tc_licenseRelease001", "Verify the Put - lms/web/assignments/license/release/{assignmentUserId} for default Math assignment", "MATH_ASSIGNMENT" },
                { "tc_licenseRelease002", "Verify the Put - lms/web/assignments/license/release/{assignmentUserId} for default Reading assignment", "READING_ASSIGNMENT" },
                { "tc_licenseRelease003", "Verify the Put - lms/web/assignments/license/release/{assignmentUserId} for Math - Custom course assignment", "MATH_CUSTOM_COURSE" },
                { "tc_licenseRelease004", "Verify the Put - lms/web/assignments/license/release/{assignmentUserId} for Reading - Custom course assignment", "READING_CUSTOM_COURSE" },
                { "tc_licenseRelease005", "Verify the Put - lms/web/assignments/license/release/{assignmentUserId} for Math - Focus course assignment", "MATH_FOCUS_COURSE" },
                { "tc_licenseRelease006", "Verify the Put - lms/web/assignments/license/release/{assignmentUserId} for Reading - Focus course assignment", "READING_FOCUS_COURSE" } };
        return inputData;
    }

}
