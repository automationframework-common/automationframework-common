package com.savvas.sm.teacher.ui.tests.SmokeSuite;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.AssignAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.MyProfilePage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.teacher.ui.pages.TopNavBar;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class HomePageSmokeTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherID;
    private String Stu_Name;
   
    
    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    }

    @Test ( description = "Verify Home Page Components and Widgets", priority = 1 )
    public void tcSMBVT001() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	Log.testCaseInfo( "tcSMBVT001: Verify Home Page Components and Widgets. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            Log.assertThat( tHomePage.getCourseTitleFromCoursesWidget().size() == 4, "Title-Courses widget is displayed in HomePage", "Title-Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.getCourseAssignedDateFromCoursesWidget().size() == 2, "Assigned date-Courses widget is displayed in HomePage", "Assigned date-Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.getCourseTypesFromCoursesWidget().size() == 4, "Type-Courses widget is displayed in HomePage", "Type-Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.getAssignBtnFromCoursesWidget().size() == 4, "Assign Btn-Courses widget is displayed in HomePage", "Assign Btn-Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isCoursesWidgetDisplayed(), "Courses widget is displayed in HomePage", "Courses widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isAnnouncementWidgetDisplayed(), "Announcement widget is displayed in HomePage", "Announcement widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isMasteryWidgetDisplayed(), "Mastery widget is displayed in HomePage", "Mastery widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isAssignmentWidgetDisplayed(), "Assignment widget is displayed in HomePage", "Assignment widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isStudentUsageWidgetDisplayed(), "Student Usage widget is displayed in HomePage", "Student Usage widget is not displayed in HomePage" );

            Log.assertThat( tHomePage.isDidYouKnowWidgetDisplayed(), "Did You Know widget is displayed in HomePage", "Did You Know widget is not displayed in HomePage" );
          
            Log.testCaseResult();
            // Signout
            tHomePage.topNavBar.signOutfromSM();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify TopNav Bar and Logo", priority = 1 )
    public void tcSMBVT002() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMBVT002: Verify TopNav Bar and Logo. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            TopNavBar topNavBar = tHomePage.topNavBar;

            // Verify topNavBar items - Home, Students, Groups, Courseware, Mastery and
            // Reports
            Log.assertThat( topNavBar.isHomeTabDisplayed(), "Home Tab is displayed in TopNavBar", "Home Tab is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isStudentsTabDisplayed(), "Students Tab is displayed in TopNavBar", "Students Tab is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isGroupsTabDisplayed(), "Groups Tab is displayed in TopNavBar", "Groups Tab is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isCoursewareDisplayed(), "Courseware Tab is displayed in TopNavBar", "Courseware Tab is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isMasteryTabDisplayed(), "Mastery Tab is displayed in TopNavBar", "Mastery Tab is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isReportsTabDisplayed(), "Reports Tab is displayed in TopNavBar", "Reports Tab is not displayed in TopNavBar" );

            // Verify Announcement Icon, Help Icon, UserProfile menu
            Log.assertThat( topNavBar.isAnnouncementDisplayed(), "Announcement Icon is displayed in TopNavBar", "Announcement Icon is not displayed in TopNavBar" );

            Log.assertThat( topNavBar.isHelpDisplayed(), "Help Icon is displayed in TopNavBar", "Help Icon is not displayed in TopNavBar" );

            // expand user icon dropdown
            topNavBar.expandUserDropdown();

            Log.assertThat( topNavBar.isUserDropdownExpanded(), "User Icon dropdown is displayed in TopNavBar", "User Icon dropdown is not displayed in TopNavBar" );

            // Verify the presence of top left SM logo and bottom right Savvas Logo
            Log.assertThat( topNavBar.isSuccessMakerLogoDisplayed(), "SuccessMaker Logo is displayed in TopNavBar", "SuccessMaker Logo is not displayed in TopNavBar" );

            // navigate to Students tab
            StudentsPage studentsPage = topNavBar.navigateToStudentsTab();
            topNavBar = studentsPage.topNavBar;
            Log.assertThat( topNavBar.isSavvasLogoDisplayed(), "Savvas Logo is displayed in Footer", "Savvas Logo is not displayed in Footer" );
         
            Log.testCaseResult();
            
            // Signout
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Assign from Homepage", priority = 1 )
    public void tcSMBVT003() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

        Log.testCaseInfo( "tcSMBVT003: Verify Assign from Homepage. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            TopNavBar topNavBar = tHomePage.topNavBar;

            List<String> customCourseNames = tHomePage.getCustomCoursesNameFromCoursesWidget();
            // Get Assignments Page
            AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
            // click view assignment for the assigned assignment
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);

            CoursesPage coursepage = new CoursesPage(driver);
            coursepage.clickOnTheHoveredAssignment(customCourseNames.get( 0 ));
            // Click on Dot ellipsis
            assignmentDetailsPage.clickDotEllipsisButton();

            // Click on removeAssignmets
            assignmentDetailsPage.removeStudentTab();

            // CLick save and remove the student
            assignmentDetailsPage.removeStudent();
            
            topNavBar.navigateToHomeTab();
            SMUtils.nap(5);
            
            AssignAssignmentPopup popup = tHomePage.assignCustomCourseFromCoursesWidget( customCourseNames.get( 0 ) );
            String studentName = popup.addStudentsToAssignment();
            // navigate to assignment page
            assignmentsPage = topNavBar.navigateToAssignmentsPage();

            // click view assignment for the assigned assignment
            assignmentDetailsPage = assignmentsPage.viewAssignmentDetailsByAssignmentName( customCourseNames.get( 0 ) );

            // get student names associated to the assignment
            List<String> studentNames = assignmentDetailsPage.getStudentsAssociatedWithAssignment();
            List<String> StudentNameFromAssignment = new ArrayList<String>() ; 
            
            for (String StuName : studentNames) {
            	String[] StudentNameWithoutSpace = StuName.split(" ");
            	 Stu_Name = StudentNameWithoutSpace[0]+StudentNameWithoutSpace[1];  
            	  StudentNameFromAssignment.add(Stu_Name);
			}
          
            // validate the assigned student name is displayed
            Log.assertThat( StudentNameFromAssignment.contains( studentName ), "Student assigned from Courses widget of homepage is displayed in assignment details page", "Student assigned from Courses widget of homepage is not displayed in assignment details page" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

     @Test ( description = "Verify UserProfile Update", priority = 1 )
    public void tcSMBVT004() throws Exception {
    	// Get driver
 		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
 		EventListener eventListner = new EventListener();
 		driver.register(eventListner);
 		
        List<String> errorMessage = new ArrayList<String>();
        errorMessage.add( "User ID already exists" );
        String existingTeacherUserName = "39450_T_NoMathAsg";
        // String newPassword = new Faker().internet().password();
        String randomFirstName = new Faker().name().firstName();
        String randomLastName = new Faker().name().lastName();
        String randomMiddleName = new Faker().name().nameWithMiddle();
        String randomUserName = new Faker().name().name();

        Log.testCaseInfo( "tcSMBVT004: Verify UserProfile Update. <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );

            // navigate to my profile page
            MyProfilePage myProfilePage = tHomePage.topNavBar.navigateToMyProfile();

            // Verify it does not allow to edit with existing username
            //myProfilePage.modifyUserId( existingTeacherUserName );
            //myProfilePage.saveChanges();
            //Log.assertThat( myProfilePage.verifyErrorMessages( errorMessage ), "SM does not allows to edit with existing username", "SM allows to edit with existing username" );

            // cancel the changes
            myProfilePage.cancelChanges();

            /*
             * // Change the password myProfilePage.modifyPassword(password,
             * newPassword); myProfilePage.saveChanges();
             * 
             * // Logout and login with new passowrd
             * myProfilePage.topNavBar.signOutfromSM(); smLoginPage = new
             * LoginPage(driver, smUrl);
             * smLoginPage.enterCredentialsAndLogIn(username, newPassword);
             * 
             * tHomePage = new TeacherHomePage(driver);
             * 
             * // navigate to my profile page myProfilePage =
             * tHomePage.topNavBar.navigateToMyProfile();
             * 
             * // Change password to old password
             * myProfilePage.modifyPassword(newPassword, password);
             * 
             * // save the changes myProfilePage.saveChanges();
             */

            // navigate to my profile page
            myProfilePage = tHomePage.topNavBar.navigateToMyProfile();
            
            // Edit few other fields
            myProfilePage.modifyFirstName( randomFirstName );
            myProfilePage.modifyMiddleName( randomMiddleName );
            myProfilePage.modifyLastName( randomLastName );
//            myProfilePage.modifyUserName( randomUserName );

            // save the changes
            myProfilePage.saveChanges();

            // navigate to my profile page
            myProfilePage = tHomePage.topNavBar.navigateToMyProfile();
            
            // Verify it is all saved
            Log.assertThat( myProfilePage.getFirstName().equals( randomFirstName ), "FirstName got updated", "FirstName doesn't updated" );

            Log.assertThat( myProfilePage.getMiddleName().equals( randomMiddleName ), "MiddleName got updated", "MiddleName doesn't updated" );

            Log.assertThat( myProfilePage.getLastName().equals( randomLastName ), "LastName got updated", "LastName doesn't updated" );

//            Log.assertThat( myProfilePage.getUserName().equals( randomUserName ), "UserName got updated", "UserName doesn't updated" );
            Log.testCaseResult();
            // Signout
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
