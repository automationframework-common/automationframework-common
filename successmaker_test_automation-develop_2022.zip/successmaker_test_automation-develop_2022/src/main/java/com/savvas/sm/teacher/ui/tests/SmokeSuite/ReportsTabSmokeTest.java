package com.savvas.sm.teacher.ui.tests.SmokeSuite;

import java.util.ArrayList;
import java.util.List;

import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.CPRPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.ReportComponent;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

public class ReportsTabSmokeTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;

    @BeforeTest
    public void initTest( ITestContext context ) {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = DataSetup.teacherDetailsMap.get( "Teacher1" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "data,userId" );
    }

    @Test ( description = "Verify CPR Report Page", priority = 1 )
    public void tcSMBVT031() throws Exception {

        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcSMBVT031: Verify CPR Report Page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage tHomePage = smLoginPage.loginToSM( username, password, true );
            CPRPage reportPage = tHomePage.topNavBar.navigateToReportsCummulativePerformanceTab();
            reportPage.getReportPageHeader();
            // Initiating the reports filter components
            ReportComponent reportComponent = new ReportComponent( driver );

            // getting the groups names from data setup
            List<String> groupsList = new ArrayList<>();
            String groupDetails = DataSetup.teacherGroupMap.get( username ).get( username );
            for ( int groupCount = 1; groupCount <= SMUtils.getWordCount( groupDetails, "groupName" ); groupCount++ ) {
                groupsList.add( SMUtils.getKeyValueFromJsonArray( groupDetails, "groupName", groupCount ) );
            }

            // Getting groups from UI
            reportComponent.setDropDownMS( "Groups" );
            List<String> groupsFromUI = reportComponent.getValuesFromDropDownMS();
            Log.assertThat( groupsList.equals( groupsFromUI ), "Groups displayed successfully!", "Groups not displayed properly", driver );

            // getting the student names from data setup
            List<String> studentList = new ArrayList<>();
            List<String> studentFirstNameAndLastNameList = new ArrayList<>();
            for ( int studentCount = 1; studentCount <= DataSetup.teacherStudentMap.get( username ).size(); studentCount++ ) {
                studentList.add( DataSetup.teacherStudentMap.get( username ).get( "Student" + studentCount ) );
                studentFirstNameAndLastNameList.add( SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,firstName" ) + " " + SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,middleName" ) + ". "
                        + SMUtils.getKeyValueFromResponse( studentList.get( studentCount - 1 ), "data,lastName" ) );
            }

            // Get students from UI
            reportComponent.setDropDownMS( "Students" );
            List<String> studentsFromUI = reportComponent.getValuesFromDropDownMS();

            // Student verifications
            Log.assertThat( SMUtils.sortList( studentFirstNameAndLastNameList ).equals( SMUtils.sortList( studentsFromUI ) ), "Students displayed properly", "Students are not displayed properly" );

            reportComponent.setDropDownMS( "Assignments" );
            List<String> assignmentsFromUI = reportComponent.getValuesFromDropDownMS();

            // Getting assignment from data setup
            List<String> assignmentList = new ArrayList<>();
            String assignments = DataSetup.teacherAssignmentMap.get( username ).get( username );
            for ( int assignmentCount = 1; assignmentCount <= SMUtils.getWordCount( assignments, "name" ); assignmentCount++ ) {
                assignmentList.add( SMUtils.getKeyValueFromJsonArray( assignments, "name", assignmentCount ) );
            }

            // Validations for assignments
            Log.assertThat( SMUtils.sortList( assignmentList ).equals( SMUtils.sortList( assignmentsFromUI ) ), "Assignments are displayed properly!", "Assignments are not displayed properly!" );

            // Getting values for Additional grouping
            List<String> displayFromUI = reportComponent.getValuesFromStaticDropDownMS( "display" );
            List<String> sortFromUI = reportComponent.getValuesFromStaticDropDownMS( "sort" );
            List<String> additionalGroupingFromUI = reportComponent.getValuesFromStaticDropDownMS( "additionalGrouping" );

            // Validation for Additional grouping
            Log.assertThat( ( displayFromUI ).equals( Constants.Reports.DISPLAY ), "Display information loaded successfully!", "Display information not loaded properly!" );
            Log.assertThat( ( sortFromUI ).equals( ( Constants.Reports.SORT ) ), "Sort information loaded successfully!", "Sort information not loaded properly!" );
            Log.assertThat( ( additionalGroupingFromUI ).equals( ( Constants.Reports.ADDITION_GROUPING ) ), "Additional grouping information loaded successfully!", "Additional grouping information not loaded properly!" );

            // Validation of save reports
            reportComponent.clickSaveReportOption();
            String reportFilterName = "reportFilter" + System.nanoTime();
            reportComponent.saveReportOption( reportFilterName ); // Saving report
                                                                  // options
            reportComponent.loadReportOption( reportFilterName ); // Loading
                                                                  // report
                                                                  // options

            // Validating run report
            Log.assertThat( SMUtils.isElementPresent( reportComponent.getRunReportOption() ), "Run report button present!", "Run report not button present!" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }
}
