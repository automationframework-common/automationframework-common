package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CourseAPIConstants;
import com.savvas.sm.common.utils.apiconstants.StudentsAPIConstants.StudentProgressGraphAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.ui.constants.LoginConstants;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class PostProgressMonitoringGraph extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String orgId;
    private String teacherId;
    private String assignmentID;
    private String assignmentUserId;
    RBSUtils rbsutils = new RBSUtils();
    Map<String, String> assignmentResponse = new HashMap<>();
    private String studentDetail;
    private String studentUserID;
    private String studentUsername;
    private String courseName;
    private String courseId;
    private String subject;
    Map<String, String> postmonitoringresponse = new HashMap<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        Log.message( teacherDetails );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        studentDetail = RBSDataSetup.getMyStudent( school, SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ) );
        studentUserID = SMUtils.getKeyValueFromResponse( studentDetail, Constants.USERID_HEADER );
        studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, RBSDataSetupConstants.USERNAME );
        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();
    }

    @Test ( priority = 1, dataProvider = "ProgressMonitoringGraphPositiveFlow", groups = { "SMK-51903", "smoke_test_case", "ProgressMonitoringGraphAPI", "ProgressMonitoringGraphAPI", "P1", "API" } )
    public void tcPostiveforProgressMonitoringGraphAPI( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();

        HashMap<String, String> groupdetails = new HashMap<>();
        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        studentRumbaIds.add( studentUserID );

        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        HashMap<String, String> group = new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );
        switch ( scenario ) {
            case "Default_Math":
                courseName = "Math";
                courseId = AssignmentAPIConstants.MATH;
                subject = DataSetupConstants.MATH;
                break;
            case "Default_Reading":
                courseName = "Reading";
                courseId = AssignmentAPIConstants.READING;
                subject = DataSetupConstants.READING;
                break;
            case "Math_Custom_Course_Settings":
                subject = DataSetupConstants.MATH;
                courseName = "CustomMathSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );
                break;
            case "Math_Custom_Course_Settings_WITHOUTIP":
                subject = DataSetupConstants.MATH;
                courseName = "CustomMathSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );
                break;
            case "Reading_Custom_Course_Settings":
                subject = DataSetupConstants.READING;
                courseName = "CustomReadingSettingCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SETTINGS, courseName, "customBySettings_READING.json" );
                break;
            case "Math_Custom_Course_Skills":
                subject = DataSetupConstants.MATH;
                courseName = "CustomMathSkillCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, courseName, "customBySkills_MATH.json" );
                break;
            case "Reading_Custom_Course_Skills":
                subject = DataSetupConstants.READING;
                courseName = "CustomReadingSkillCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, token, DataSetupConstants.READING, teacherId, orgId, DataSetupConstants.SKILL, courseName, "customBySkills_READING.json" );
                break;
            case "Math_Custom_Course_Standard":
                subject = DataSetupConstants.MATH;
                courseName = "CustomMathStandardCourse" + System.nanoTime();
                courseId = createCustomCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.STANDARD, courseName, "customByStandardsRandom_MATH.json" );
                break;
            case "Focus_Course_Math":
                courseName = "SM Focus Math: Grade 1";
                courseId = AssignmentAPIConstants.FOCUS_MATH;
                subject = DataSetupConstants.MATH;
                break;
            case "Focus_Course_Reading":
                courseName = "SM Focus Reading: Grade 1";
                courseId = AssignmentAPIConstants.FOCUS_READING;
                subject = DataSetupConstants.READING;
                break;
            default:
                break;
        }
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( "assignmentResponse=" + assignmentResponse );
        assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
        Log.message( "assignmentUserId =" + assignmentUserId );
        if ( scenario.contains( "Math" ) && scenario.contains( "WITHOUTIP" ) ) {
            executeCourse( studentUsername, courseName, true, "100", "1", "1" );
        } else if ( scenario.contains( "Math" ) ) {
            executeCourse( studentUsername, courseName, true, "100", "5", "30" );

        } else {
            executeCourse( studentUsername, courseName, false, "100", "5", "30" );

        }
        HashMap<String, String> header = new HashMap<>();
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        header.put( Constants.AUTHORIZATION, "Bearer " + token );
        header.put( Constants.USERID_SM_HEADER, teacherId );
        header.put( Constants.ORGID_SM_HEADER, orgId );
        HashMap<String, String> pathparams = new HashMap<>();
        pathparams.put( Constants.TEACHER_ID, teacherId );
        pathparams.put( Constants.ORG_ID_VALUE, orgId );
        pathparams.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId );
        postmonitoringresponse = postProgressMonitoringGraph( smUrl, header, pathparams, studentUserID, assignmentID, subject, new ArrayList<>() );
        Log.message( "postmonitoringresponse=" + postmonitoringresponse );
        Log.softAssertThat( postmonitoringresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + postmonitoringresponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + postmonitoringresponse.get( Constants.STATUS_CODE ) );

    }

    /**
     * Data provider to give the positive data
     *
     * @return
     */
    @DataProvider ( name = "ProgressMonitoringGraphPositiveFlow" )
    public Object[][] ProgressMonitoringGraphPositiveFlow() {

        Object[][] inputData = {

                { "Verify the valid response to Default Math", "Default_Math", CommonAPIConstants.STATUS_CODE_OK }, { "Verify the valid response to Default Reading", "Default_Reading", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Math Custom Course by Settings", "Math_Custom_Course_Settings", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Math Custom Course by Settings", "Math_Custom_Course_Settings_WITHOUTIP", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Reading Custom Course by Settings", "Reading_Custom_Course_Settings", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Math Custom Course by Skills", "Math_Custom_Course_Skills", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Reading Custom Course by Skills", "Reading_Custom_Course_Skills", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Math Custom Course by Standard", "Math_Custom_Course_Standard", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to SM Focus Math Course", "Focus_Course_Math", CommonAPIConstants.STATUS_CODE_OK }, { "Verify the valid response to SM Focus Reading Course", "Focus_Course_Reading", CommonAPIConstants.STATUS_CODE_OK },

        };

        return inputData;
    }

    @Test ( priority = 1, dataProvider = "ProgressMonitoringGraphNegativeFlow", groups = { "SMK-51903", "ProgressMonitoringGraphAPI", "ProgressMonitoringGraphAPI", "P1", "API" } )
    public void tcNegativeforProgressMonitoringGraphAPI( String description, String scenario, String statusCode ) throws Exception {
        Log.testCaseInfo( description );
        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> studentRumbaIds = new ArrayList<>();

        HashMap<String, String> groupdetails = new HashMap<>();

        String token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        studentRumbaIds.add( studentUserID );

        groupdetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupdetails.put( GroupConstants.GROUP_OWNER_ID, teacherId );
        groupdetails.put( GroupConstants.GROUP_OWNER_ORG_ID, orgId );
        groupdetails.put( GroupConstants.GROUP_NAME, "Group Name" + System.nanoTime() );
        HashMap<String, String> group = new GroupAPI().createGroup( smUrl, groupdetails, Arrays.asList( studentUserID ) );
       
        subject = DataSetupConstants.MATH;
        courseName = "CustomMathSettingCourse" + System.nanoTime();
        courseId = createCustomCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SETTINGS, courseName, "customBySettings_MATH.json" );
        assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, courseId );
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        assignmentResponse = assignAssignment( smUrl, assignmentDetails, Arrays.asList( studentUserID ), AssignmentAPIConstants.USERS_TYPE );
        Log.message( "assignmentResponse=" + assignmentResponse );
        assignmentID = SMUtils.getKeyValueFromResponse( assignmentResponse.get( Constants.RESPONSE_BODY ), "data,assignmentId" );
        assignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentUserID, assignmentID );
        Log.message( "assignmentUserId =" + assignmentUserId );
        executeCourse( studentUsername, courseName, true, "100", "5", "30" );
      
        HashMap<String, String> header = new HashMap<>();
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        header.put( Constants.AUTHORIZATION, "Bearer " + token );
        header.put( Constants.USERID_SM_HEADER, teacherId );
        header.put( Constants.ORGID_SM_HEADER, orgId );

        HashMap<String, String> pathparams = new HashMap<>();
        pathparams.put( Constants.TEACHER_ID, teacherId );
        pathparams.put( Constants.ORG_ID_VALUE, orgId );
        pathparams.put( Constants.ASSIGNMENT_USER_ID, assignmentUserId );

        if ( scenario.contains( "INVALID_ORG" ) ) {
            pathparams.put( Constants.ORG_ID_VALUE, CourseAPIConstants.INVALID_ORGANIZATION_ID );
        }
        if ( scenario.contains( "INVALID_STAFF_ID" ) ) {
            pathparams.put( Constants.TEACHER_ID, CourseAPIConstants.INVALID_STAFF_ID_RANDOM );
        }
        if ( scenario.contains( "INVALID_ASSIGNMENT_USER_ID" ) ) {
            pathparams.put( Constants.ASSIGNMENT_USER_ID, StudentProgressGraphAPIConstants.INVALID_ASSIGNMENT_USER_ID );
        }
        if ( scenario.contains( "INVALID_DATATYPE_ASSIGNMENT_USER_ID" ) ) {
            pathparams.put( Constants.ASSIGNMENT_USER_ID, CourseAPIConstants.INVALID );
        }
        if ( scenario.contains( "INVALID_ORG_HEADER" ) ) {
            header.put( Constants.ORGID_SM_HEADER, CourseAPIConstants.INVALID_ORGANIZATION_ID );
        }
        if ( scenario.contains( "INVALID_STAFF_ID_HEADER" ) ) {
            header.put( Constants.USERID_SM_HEADER, CourseAPIConstants.INVALID_STAFF_ID_RANDOM );
        }
        postmonitoringresponse = postProgressMonitoringGraph( smUrl, header, pathparams, studentUserID, assignmentID, subject, new ArrayList<>() );
        Log.message( "postmonitoringresponse=" + postmonitoringresponse );
        Log.softAssertThat( postmonitoringresponse.get( Constants.STATUS_CODE ).equalsIgnoreCase( statusCode ), "Status code is returned as expected and the same is " + postmonitoringresponse.get( Constants.STATUS_CODE ),
                "Status code is not returned as expected and the same is " + statusCode + " Actual - " + postmonitoringresponse.get( Constants.STATUS_CODE ) );

        Log.testCaseResult();
    }

    @DataProvider ( name = "ProgressMonitoringGraphNegativeFlow" )
    public Object[][] ProgressMonitoringGraphNegativeFlow() {

        Object[][] inputData = { { "Verify the valid response to Math Custom Course by Settings", "INVALID_ORG", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the valid response to Math Custom Course by Settings", "INVALID_STAFF_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the valid response to Math Custom Course by Settings", "INVALID_ASSIGNMENT_USER_ID", CommonAPIConstants.STATUS_CODE_OK },
                { "Verify the valid response to Math Custom Course by Settings", "INVALID_DATATYPE_ASSIGNMENT_USER_ID", CommonAPIConstants.STATUS_CODE_BAD_REQUEST },
                { "Verify the valid response to Math Custom Course by Settings", "INVALID_ORG_HEADER", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "Verify the valid response to Math Custom Course by Settings", "INVALID_STAFF_ID_HEADER", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED }, };
        return inputData;
    }

    public Map<String, String> postProgressMonitoringGraph( String smUrl, HashMap<String, String> header, HashMap<String, String> path, String studentID, String assignmentID, String subjectType, List<String> sessionDates ) throws Exception {
        String endPoint = StudentProgressGraphAPIConstants.PROGRESS_MONITORING_GRAPH;
        endPoint = endPoint.replace( Constants.ORG_ID, path.get( Constants.ORG_ID_VALUE ) );
        endPoint = endPoint.replace( Constants.STAFF_ID, path.get( Constants.TEACHER_ID ) );
        endPoint = endPoint.replace( Constants.ASSIGNMENT_USER_ID_VALUE, path.get( Constants.ASSIGNMENT_USER_ID ) );
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, header.get( Constants.AUTHORIZATION ) );
        headers.put( Constants.USERID_SM_HEADER, header.get( Constants.USERID_SM_HEADER ) );
        headers.put( Constants.ORGID_SM_HEADER, header.get( Constants.ORGID_SM_HEADER ) );
        String subject = subjectType.equals( "Math" ) ? "1" : "2";
        String payload = "{ \"subjectId\": subjectID }";
        payload = payload.replace( "subjectID", subject );
        Log.message( payload );
        return RestHttpClientUtil.POST( smUrl, headers, new HashMap<>(), endPoint, payload );
    }

    public void executeCourse( String studentUserName, String courseName, boolean isMath, String percentage, String numberOfSession, String loCount ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( configProperty.getProperty( "BrowserPlatformToRun" ) );
        Log.message( "Student username :" + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        SMUtils.nap( 30 );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, percentage, numberOfSession, loCount );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }
    }

}