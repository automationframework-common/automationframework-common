package com.savvas.sm.api.tests.smnew.assignments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.FileNameConstatnts;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * This class used to test the API of get assignments listing in 'Mastery ->
 * Assignments' dropdown for the selected subject - SMK-51995
 * 
 * @author Baskar.Panchavarnam
 * 
 */

public class GetAssignmentsMasteryDropdown extends AssignmentAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String teacherDetails = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherUsername;
    List<String> studentRumbaIds = new ArrayList<>();
    GroupAPI groupAPI;
    CourseAPI courseAPI;
    SMAPIProcessor smAPIprocessor;

    @BeforeClass(alwaysRun = true)
    public void beforeClass() {

        smUrl = configProperty.getProperty( "SMAppUrl" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( RBSDataSetup.getMyStudent( school, teacherUsername ), Constants.USERID_HEADER ) );
        Log.message(studentRumbaIds.toString());

        groupAPI = new GroupAPI();
        courseAPI = new CourseAPI();
        smAPIprocessor = new SMAPIProcessor();

    }

    @Test ( priority = 1, dataProvider = "getAssignmentsListingPositive", groups = { "SMK-51995", "smoke_test_case", "Assignments", "AssignmentsListing", "P1", "API" } )
    public void tcGetAssignmentsListingPositive01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );

        HashMap<String, String> response = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> params = new HashMap<>();
        HashMap<String, String> assignmentDetails = new HashMap<>();
        List<String> getAssignmentsName = new ArrayList<>();
        HashMap<String, String> groupDetails = new HashMap<>();
        HashMap<String, String> createAssignment = new HashMap<>();
        String subjectId = null;
        HashMap<String, String> getResponse = new HashMap<>();
        String endPoint = AssignmentAPIConstants.GET_ASSIGNMENTS_BY_SUBJECTID_API;

        switch ( scenario ) {
            case "tc1-defaultMath":

                subjectId = "1"; // SujectID value for Request body
                groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupNameNew" );
                if ( groupAPI.createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.STATUS_CODE ).equals( CommonAPIConstants.STATUS_CODE_CREATED ) ) {
                    Log.message( "Group created for the student!" );
                }
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_MATH );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                createAssignment = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( "Response :" + createAssignment );

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                String requestBody = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "getAssignmentBySubjectID.json" );
                requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, subjectId );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );

                Log.message( "Response is : " + response.get( "body" ) );

                getAssignmentsName = getAssignmentFromResponse( response.get( "body" ) );

                Log.assertThat( getAssignmentsName.contains( AssignmentAPIConstants.MATH_COURSE ), "Math Assignment displays", "Math Assignment is not displaying" );

                break;

            case "tc2-defaultReading":
                subjectId = "2"; // SujectID value for Request body
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                getResponse = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( "Response is :" + getResponse );

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                requestBody = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "getAssignmentBySubjectID.json" );
                requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, subjectId );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );

                getAssignmentsName = getAssignmentFromResponse( response.get( "body" ) );

                Log.assertThat( getAssignmentsName.contains( AssignmentAPIConstants.READING_COURSE ), "Reading Assignment displays", "Reading Assignment is not displaying" );

                break;

            case "tc3-Math&Reading":
                subjectId = "-1"; // SujectID value for Request body
                assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
                assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, AssignmentAPIConstants.DEFAULT_READING );
                assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

                getResponse = assignAssignment( smUrl, assignmentDetails, studentRumbaIds, "users" );
                Log.message( "Response is :" + getResponse );

                headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                requestBody = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "getAssignmentBySubjectID.json" );
                requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, subjectId );

                endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );

                getAssignmentsName = getAssignmentFromResponse( response.get( "body" ) );

                // getAssignmentsName = SMUtils.getKeyValueFromResponse(response.toString(),
                // subjectId)
                Log.assertThat( getAssignmentsName.contains( AssignmentAPIConstants.READING_COURSE ) & getAssignmentsName.contains( AssignmentAPIConstants.MATH_COURSE ), "Both the Math & Reading Assignment displays",
                        "Assignments are not displaying as expected" );

                break;
            default:
                Log.fail( "Case is invalid" );
                break;
        }

        Log.message( response.get( "statusCode" ) );
        Log.message( response.get( "body" ) );
        String actualResponse = response.get( "body" );
        Log.assertThat( response.get( "statusCode" ).equals( statusCode ), "Status code is matched", "Status code is mismatched" );

        // Verifying schema
        VerifySchema( CommonAPIConstants.STATUS_CODE_OK, response );
        List<String> assignmentListsDB = validateResponse( assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID ), actualResponse, subjectId );

        Log.message( assignmentListsDB.toString() );
        Log.message( getAssignmentsName.toString() );

        // Verifying DB values
        Log.assertThat( SMUtils.compareTwoList( getAssignmentsName, assignmentListsDB ), "Assignment list is getting matched", "Assignmenets list mismatched" );
    }

    @Test ( priority = 2, dataProvider = "getAssignmentsListingNegative", groups = { "SMK-51995", "Assignments", "AssignmentsListing", "P1", "API" } )
    public void tcGetAssignmentsListingNegative01( String description, String scenario, String statusCode ) throws Exception {

        Log.testCaseInfo( description );
        HashMap<String, String> response = new HashMap<>();
        HashMap<String, String> headers = new HashMap<>();
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_ASSIGNMENTS_BY_SUBJECTID_API;
        String subjectId = AssignmentAPIConstants.DEFAULT_MATH;
        try {

            switch ( scenario ) {

                case "tc4-Invalid subjectId":
                    headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                    headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                    String requestBody = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "getAssignmentBySubjectID.json" );

                    requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, AssignmentAPIConstants.FOCUS_MATH_1 );

                    endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                    response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );

                    System.out.println( response.get( "statusCode" ) );
                    Log.assertThat( response.get( "statusCode" ).equals( CommonAPIConstants.STATUS_CODE_INTERNAL_ERROR ), "Status code is matched", "Status code is mismatched" );

                    VerifySchema( CommonAPIConstants.STATUS_CODE_INTERNAL_ERROR, response );
                    break;

                case "tc5-Invalid org-id in parameter":
                    headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                    headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                    requestBody = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "getAssignmentBySubjectID.json" );

                    requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, subjectId );

                    endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) + "invalid" ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                    response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );

                    System.out.println( response.get( "statusCode" ) );
                    Log.assertThat( response.get( "statusCode" ).equals( CommonAPIConstants.STATUS_CODE_BAD_REQUEST ), "Status code is matched", "Status code is mismatched" );

                    VerifySchema( CommonAPIConstants.STATUS_CODE_BAD_REQUEST, response );
                    break;

                case "tc6-Invalid staff-id in parameter":
                    headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                    headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                    requestBody = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "getAssignmentBySubjectID.json" );

                    requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, subjectId );

                    endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", "tempuser" );
                    response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );

                    System.out.println( response.get( "statusCode" ) );
                    Log.assertThat( response.get( "statusCode" ).equals( CommonAPIConstants.STATUS_CODE_BAD_REQUEST ), "Status code is matched", "Status code is mismatched" );

                    VerifySchema( CommonAPIConstants.STATUS_CODE_BAD_REQUEST, response );
                    break;

                case "tc7-Invalid org-id in headers":

                    headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                    headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) + "invalid" );

                    requestBody = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "getAssignmentBySubjectID.json" );

                    requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, subjectId );

                    endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                    response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );

                    System.out.println( response.get( "statusCode" ) );
                    Log.assertThat( response.get( "statusCode" ).equals( CommonAPIConstants.STATUS_CODE_FORBIDDAN ), "Status code is matched", "Status code is mismatched" );

                    VerifySchema( CommonAPIConstants.STATUS_CODE_FORBIDDAN, response );
                    break;

                case "tc8-Invalid user-id in headers":

                    headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    headers.put( Constants.USERID_SM_HEADER, "invalid" );
                    headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                    requestBody = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "getAssignmentBySubjectID.json" );

                    requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, subjectId );

                    endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
                    response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );
                    Log.assertThat( response.get( "statusCode" ).equals( CommonAPIConstants.STATUS_CODE_UNAUTHORIZED ), "Status code is matched", "Status code is mismatched" );

                    VerifySchema( CommonAPIConstants.STATUS_CODE_UNAUTHORIZED, response );
                    break;

                case "tc9-Incorrect credentials":

                    headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                    headers.put( Constants.AUTHORIZATION, "Bearer " + new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                    headers.put( Constants.USERID_SM_HEADER, SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                    headers.put( Constants.ORGID_SM_HEADER, RBSDataSetup.organizationIDs.get( school ) );

                    requestBody = SMUtils.convertFileToString( SMUtils.getPayLoadDirPath() + "getAssignmentBySubjectID.json" );

                    requestBody = requestBody.replace( Constants.PAYLOAD_SUBJECT_TYPE_ID, subjectId );

                    endPoint = endPoint.replace( "{orgID}", RBSDataSetup.organizationIDs.get( school ) ).replace( "{teacherID}", SMUtils.getKeyValueFromResponse( RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" ), "userId" ) );
                    response = RestHttpClientUtil.POST( smUrl, headers, params, endPoint, requestBody );

                    Log.message( response.get( "statusCode" ) );
                    Log.message( response.get( "body" ) );
                    Log.assertThat( response.get( "statusCode" ).equals( CommonAPIConstants.STATUS_CODE_FORBIDDAN ), "Status code is matched", "Status code is mismatched" );

                    VerifySchema( CommonAPIConstants.STATUS_CODE_FORBIDDAN, response );
                    break;

                default:
                    Log.fail( "Case is invalid" );
                    break;
            }

            Log.testCaseResult();

        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    /**
     * Verify the schema for the api
     *
     * @param StatusCode
     * @param Body
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = smAPIprocessor.isSchemaValid( FileNameConstatnts.GET_ASSIGNMENTS_SCHEMA_FILE, StatusCode, response.get( AssignmentAPIConstants.BODY_FIELD ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }

        Log.assertThat( isValid, "The schema is valid and mathching", "The schema is not valid and not mathching for the Status code :" + StatusCode );
    }

    public List<String> getAssignmentFromResponse( String response ) {
        List<String> actualAssignmentName = new ArrayList<String>();
        {
            JSONObject jsonObject = new JSONObject( response );

            JSONArray array = jsonObject.getJSONArray( "data" );
            for ( int j = 0; j < array.length(); j++ ) {
                String eachObject = array.getJSONObject( j ).toString();

                actualAssignmentName.add( SMUtils.getKeyValueFromResponse( eachObject, "assignmentName" ) );
            }
            return actualAssignmentName;
        }
    }

    /**
     * Data provider to give the positive data
     * 
     * @return
     */

    @DataProvider ( name = "getAssignmentsListingPositive" )
    public Object[][] getAssignmentsListingPositive() {

        Object[][] inputData = {

                { "1. Verify the assignments list in Mastery page dropdown for Math subject", "tc1-defaultMath", CommonAPIConstants.STATUS_CODE_OK },
                { "2. Verify the assignments list in Mastery page dropdown for Reading subject", "tc2-defaultReading", CommonAPIConstants.STATUS_CODE_OK },
                { "3. Verify the assignments list in Mastery page dropdown for Math & Reading subject", "tc3-Math&Reading", CommonAPIConstants.STATUS_CODE_OK } };

        return inputData;
    }

    /**
     * Data provider to give the Negative data
     * 
     * @return
     * 
     */

    @DataProvider ( name = "getAssignmentsListingNegative" )

    public Object[][] getAssignmentsListingNegative() {

        Object[][] inputData = { { "4. Invalid subjectId in request body", "tc4-Invalid subjectId", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "5. Invalid organization-id in parameter", "tc5-Invalid org-id in parameter", CommonAPIConstants.STATUS_CODE_OK }, { "6. Invalid staff-id in parameter", "tc6-Invalid staff-id in parameter", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "7. Invalid org-id in headers section", "tc7-Invalid org-id in headers", CommonAPIConstants.STATUS_CODE_FORBIDDAN }, { "8. Invalid user-id in headers section", "tc8-Invalid user-id in headers", CommonAPIConstants.STATUS_CODE_OK },
                { "9. Incorrect credentials", "tc9-Incorrect credentials", CommonAPIConstants.STATUS_CODE_NOTFOUND } };

        return inputData;
    }

    // DB Query Validation
    public List<String> validateResponse( String staffId, String actualResponse, String subjectID ) {
        JSONObject actualData = new JSONObject( actualResponse );
        HashMap<String, String> assignmentTitle = new HashMap<String, String>();
        List<String> assignmentNames = new ArrayList<>();

        if ( !SMUtils.getKeyValueFromResponse( actualResponse, "messages,status" ).equalsIgnoreCase( "failure" ) ) {

            JSONArray assignmentListFromResponse = actualData.getJSONArray( "data" );

            HashMap<String, List<String>> assignmentList = SqlHelperCourses.getAssignmentListingDetails( staffId );
            Log.message( "AssignmentDetails = " + assignmentList );

            IntStream.range( 0, assignmentList.get( AssignmentAPIConstants.ASSIGNMENT_ID ).size() ).filter( iter -> assignmentList.get( AssignmentAPIConstants.CONTENT_BASE_ID ).get( iter ).equals( subjectID ) || subjectID.equals( "-1" ) ).forEach(
                    iter -> assignmentNames.add( assignmentList.get( AssignmentAPIConstants.ASSIGNMENT_NAME ).get( iter ) ) );

        }
        return assignmentNames;
    }

    // **********************

    public Map<String, String> getHeaders( HashMap<String, String> userreqDetails ) {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + userreqDetails.get( RBSDataSetupConstants.BEARER_TOKEN ) );

        headers.put( Constants.USERID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.TEACHER_ID ) );
        headers.put( Constants.ORGID_SM_HEADER, userreqDetails.get( AssignmentAPIConstants.ORG_ID ) );
        return headers;
    }

    public HashMap<String, String> getAssignmentsBySubjectID( String envUrl, HashMap<String, String> assignmentDetails ) throws Exception {

        Map<String, String> headers = getHeaders( assignmentDetails );
        String orgID = assignmentDetails.get( AssignmentAPIConstants.ORG_ID );
        String teacherID = assignmentDetails.get( AssignmentAPIConstants.TEACHER_ID );
        String courseID = assignmentDetails.get( AssignmentAPIConstants.COURSE_ID );
        // Parameters
        HashMap<String, String> params = new HashMap<>();

        // Input Path Parameters
        String endPoint = AssignmentAPIConstants.GET_ASSIGNMENTS_BY_SUBJECTID_API;
        // String endPoint =
        // "/lms/web/api/v1/organizations/{orgID}/staffs/{teacherID}/courseassignments/{contentbaseId}/students";

        // endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}",
        // teacherID ).replace("{contentbaseId}", courseID);
        endPoint = endPoint.replace( "{orgID}", orgID ).replace( "{teacherID}", teacherID );

        return RestHttpClientUtil.GET( envUrl, endPoint, headers, params );
    }
}