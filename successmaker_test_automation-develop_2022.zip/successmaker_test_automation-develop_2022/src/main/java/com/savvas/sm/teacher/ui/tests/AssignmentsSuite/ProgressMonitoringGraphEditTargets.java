package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

@Listeners ( EmailReport.class )
public class ProgressMonitoringGraphEditTargets {
    private String smUrl;
    private String browser;
    private String username = null;
    private String password = null;
    private String orgId;
	private String teacherId;
	private String assignmentID;
	private String assignmentUserId;
    LocalDate today = LocalDate.now();
    //Change this index if you want to select use teacher other than "Teacher77"
    //private String teacherIndex = "77";
    String studentDetails;
    String teacherDetails;
    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String schoolID;
    private String teacherID;
    String studentDetailsSecond;
    String studentDetailsThree;
    String studentSMDetails;
    String studentSMDetailsSecond;
    String studentSMDetailsThree;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private HashMap<String, String> groupDetails = new HashMap<>();
    HashMap<String, String> assignmentDetails = new HashMap<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private List<String> courseIDs = new ArrayList<>();
    private String token = null;
    RBSUtils student=new RBSUtils();
    String studentUser=null;

    @BeforeClass (alwaysRun = true)
    public void initTest( ITestContext context ) throws Exception {
        UserAPI userAPIMethod = new UserAPI();
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get(school);
        teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, Constants.USERID_HEADER);
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        //New approach
        studentDetails = RBSDataSetup.getMyStudent( school, username );
        studentDetailsSecond = RBSDataSetup.getMyStudent( school, username );
        studentDetailsThree = RBSDataSetup.getMyStudent( school, username );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetailsThree, "userId" ) );

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Student SM Details
       // studentSMDetails = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( school ), token ).get( Constants.REPORT_BODY );
        studentSMDetailsSecond = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetailsSecond, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( school ), token ).get( Constants.REPORT_BODY );
        studentSMDetailsThree = userAPIMethod.getStudentDetailsByStudentId( SMUtils.getKeyValueFromResponse( studentDetailsThree, "userId" ), teacherID, RBSDataSetup.organizationIDs.get( school ), token ).get( Constants.REPORT_BODY );
        studentUser = student.getUser(studentRumbaIds.get(0));
        
        //Please remove before final merge
        Log.message( "Student details(studentSMDetails) are " + studentSMDetails );

        //Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );
        
        assignmentDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		assignmentDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
		assignmentDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherId);
	//	assignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
		
		 contentBaseName.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE, String.format( DataSetupConstants.SKILL_COURSE_NAME_MATH, System.nanoTime() ) );
		 Log.message( "contentbasename" + contentBaseName );
		 
		 contentBase.put( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE,
	              new CourseAPI().createCourse( smUrl, token, DataSetupConstants.MATH, teacherId, orgId, DataSetupConstants.SKILL, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) ) );
		 
		 courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE + AssignmentAPIConstants.SKILL_COURSE ) );
		 
		    Log.message( "contentBaseName- " + contentBaseName );
	        Log.message( "contentBase- " + contentBase );
	        Log.message( "courseIDs- " + courseIDs );
	        
	        Log.message( "Assigning assignment..." );
	        HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
	        Log.message( "Assignment Details" + assignmentResponse );
    }

    @Test ( description = "Verify the teacher is able to delete the custom courses", groups = { "SMK-45611", "Assignments", "PMG_EditTargets" }, priority = 1 )
    public void verifyAssignmentsPmgEditTarget_001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
    	
        Log.testCaseInfo( "Verify the teacher is able to delete the custom courses" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            CoursesPage customCourses = new CoursesPage( driver );
            AssignmentsPage assignmentsPage = new AssignmentsPage( driver );
            List<String> assignmentNames = new ArrayList<>();
            //Navigate to assignment listing page
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Get all the assignments in the assignment tab
            assignmentNames = assignmentsPage.getAllAssignmentNames();

            assignmentNames.forEach( assignment -> {
                //Traverse to Assignment Tab
                tHomePage.topNavBar.navigateToAssignmentsPage();

                //Click on the Assignment
                customCourses.clickOnTheHoveredAssignment( assignment );

                //Delete the Assignment
                assignmentDetailsPage.assignmentLevelEllipsis();

             
                // Click on removeAssignmets
                assignmentDetailsPage.deleteAssignmenttab();

                // CLick on Delete button for the assignment
                assignmentDetailsPage.deleteAssignmentButton();
            } );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the teacher is able to create custom course and the teacher is able to assign custom and default courses to student", groups = { "SMK-45611", "Assignments", "PMG_EditTargets" }, priority = 1 )
    public void verifyAssignmentsPmgEditTarget_002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify the teacher is able to create custom course and the teacher is able to assign custom and default courses to student" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage customCourses = new CoursesPage( driver );
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
            List<String> studentList = new ArrayList<>();

            //Traverse to Courses page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Click on the default Math course
            customCourses.clickFromCourseListingPage( Constants.MATH );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Get the count of the student from the assignment pop up
            studentListFromTheAssignmentPopup = customCourses.getAllStudentNameFromAssignPopUp();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            //Verify whether the student is present in the particular assignment
            studentList = customCourses.getStudentListfromAssignementDetailsTable();

            //Assert Statement
            Log.softAssertThat( ( studentList.size() == studentListFromTheAssignmentPopup.size() ), Constants.SUCCESS_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT,
                    Constants.FALIURE_MESSAGE_FOR_ALL_STUDENTS_SUCCESSFULLY_ASSIGNED_ASSIGNMENT );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the student is able to attend the Math course via simulator", groups = { "SMK-45611", "Assignments", "PMG_EditTargets" }, priority = 1 )
    public void verifyAssignmentsPmgEditTarget_003() throws Exception {
        Log.testCaseInfo( "Verify the student is able to attend the Math course via simulator" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            Log.message( "The subject name is " + Constants.MATH );

            //execute in new way
            String studentDetail = studentSMDetails;
            String studentUsername = SMUtils.getKeyValueFromResponse( studentDetail, "data,userName" );
            executeCourse( studentUsername, Constants.MATH, true );
            Log.testCaseResult();
        } catch ( Exception e ) {
            //Log.exception( e, driver );
        } finally {
            Log.endTestCase();
        }
    }

    @Test ( description = "Verify if teacher is able to see Edit Targets for PMG for default assignments", groups = { "SMK-45611", "Assignments", "PMG_EditTargets" }, priority = 2 )
    public void verifyAssignmentsPmgEditTarget_004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.testCaseInfo( "Verify if teacher is able to see Edit Targets for PMG for default assignments" + Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            CoursesPage customCourses = new CoursesPage( driver );
            String studentFirstName = SMUtils.getKeyValueFromResponse( studentUser, RBSDataSetupConstants.FIRSTNAME );
            String studentMiddleName = SMUtils.getKeyValueFromResponse( studentUser, RBSDataSetupConstants.MIDDLENAME );
            String studentLastName = SMUtils.getKeyValueFromResponse( studentUser, RBSDataSetupConstants.LASTNAME );

            //Navigate to assignment listing page
            tHomePage.topNavBar.navigateToAssignmentsPage();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( Constants.MATH );

            SMUtils.waitForSpinnertoDisapper( driver );

            //Click on to expand the skill details
            assignmentDetailsPage.clicktoggleButtonForStudent( studentFirstName, studentMiddleName, studentLastName );

            //Scroll if required
            assignmentDetailsPage.scrollInToExpandedStudent();

            //TC1
            SMUtils.logDescriptionTC( "SMK-13463 Verify the availability of 'Help' icon in 'Edit Targets' popup" );

            assignmentDetailsPage.waitForEditTargetsButton();

            //Click on the Edit targets
            assignmentDetailsPage.clickEditTargetButton();

            assignmentDetailsPage.waitForHelpIcon();

            Boolean presenceOfHelpIcon = assignmentDetailsPage.verifyThePresenceOfHelpIcon();

            //Check the availability of the help icon
           Log.softAssertThat( Boolean.TRUE.equals( presenceOfHelpIcon ), "The Help icon is present in the 'Edit Targets' popup", "The Help icon is absent in the 'Edit Targets' popup" );

            //TC2
            SMUtils.logDescriptionTC( "SMK-13465 Verify the Reset button and Cancel button as Enabled by default in the 'Edit Targets' popup" );

            //Verify Reset button is enabled by default
            assignmentDetailsPage.verifyResetButtonIsEnabled();

            //Assertion
            Log.softAssertThat( assignmentDetailsPage.verifyResetButtonIsEnabled(), "Reset button is enabled", "Reset button is not enabled" );

            //Verify Cancel button is enabled by default
            assignmentDetailsPage.verifyCancelButtonIsEnabled();

            //Assertion
            Log.softAssertThat( assignmentDetailsPage.verifyResetButtonIsEnabled(), "Cancel button is enabled", "Cancel button is not enabled" );

            //TC3
            SMUtils.logDescriptionTC( "SMK-134567 Verify the user able to close the 'Edit Targets' popup using 'Cancel' button" );

            //Click on the cancel button of 'Edit Targets' popup
            assignmentDetailsPage.clickCancelButtonOfEditTargetsPopup();

            SMUtils.logDescriptionTC( "SMK-19137 - Verify the user able to close the 'Edit Targets' popup using 'Cancel' button" );

            //Click on the Edit targets
            assignmentDetailsPage.clickEditTargetButton();

            assignmentDetailsPage.waitForHelpIcon();

            //TC4
            SMUtils.logDescriptionTC( "SMK-13466 Verify the user able to close the 'Edit Targets' popup using 'Close' icon" );

            //Click on the close button of 'Edit Targets' popup
            assignmentDetailsPage.clickCloseButtonOfEditTargets();

            //Click on the calendar icon
            assignmentDetailsPage.clickOnCalendarIcon();

            //TC5
            SMUtils.logDescriptionTC( "SMK-13469 Verify the user able to edit the date as 'Past' date from DatePicker box in the 'Edit Targets' popup" );

            SMUtils.logDescriptionTC( "SMK-19139 - Verify the user able to edit the date as 'Past' date from DatePicker box in the 'Edit Targets' popup" );

            //Past date
            LocalDate pastDateToBeSelected = today.minusDays( 1 );

            //Choose the required date
            LocalDate selectedDatePast = assignmentDetailsPage.chooseDate( pastDateToBeSelected );

            //Assertion
            Log.softAssertThat( selectedDatePast.equals( pastDateToBeSelected ), "Past date is as per selected by the Teacher", "Past date is not as per selected by the Teacher" );

            //TC6
            SMUtils.logDescriptionTC( "SMK-13470 Verify the user able to edit the date as 'Future' date from DatePicker box in the 'Edit Targets' popup" );

            SMUtils.logDescriptionTC( "SMK-19140 - Verify the user able to edit the date as 'Future' date from DatePicker box in the 'Edit Targets' popup" );

            //Required data
            LocalDate futureDateToBeSelected = today.plusDays( 1 );

            //Choose the required date
            LocalDate selectedDateFuture = assignmentDetailsPage.chooseDate( futureDateToBeSelected );

            //Assertion
            Log.softAssertThat( selectedDateFuture.equals( futureDateToBeSelected ), "Future date is as per selected by the Teacher", "Future date is not as per selected by the Teacher" );

            //Click on the save button
            assignmentDetailsPage.clickOnSaveButtonOfEditTargets();

            assignmentDetailsPage.waitForEditTargetsButton();

            //Click on the Edit targets
            assignmentDetailsPage.clickEditTargetButton();

            assignmentDetailsPage.waitForHelpIcon();

            //Enter the date in the date field
            assignmentDetailsPage.enterTheDateInTargetDateField();

            //Verify whether the Save button is enabled or disabled
            assignmentDetailsPage.verifySaveButtonIsEnabled();

            //TC7
            SMUtils.logDescriptionTC( "SMK-13473 Verify the user is restricted to enter the date manually in the 'Target Date' option" );

            SMUtils.logDescriptionTC( "SMK-19143 - Verify the user is restricted to enter the date manually in the 'Target Date' option" );

            //Assertion
            Log.softAssertThat( !assignmentDetailsPage.verifySaveButtonIsEnabled(), "Teacher is unable to enter the date directly via UI as expected", "Teaacher is able to enter the date directly via UI" );

            //Past date
            LocalDate pastDate = today.minusDays( 1 );

            //Choose the required date
            LocalDate selectedPastDate = assignmentDetailsPage.chooseDate( pastDate );

            //TC8
            SMUtils.logDescriptionTC( "SMK-13475 Verify the perviously selected date is able to retain on Clicking the 'Reset' button" );

            SMUtils.logDescriptionTC( "SMK-19135 - Verify the Reset button and Cancel button as Enabled by default in the 'Edit Targets' popup" );

            SMUtils.logDescriptionTC( "SMK-19145 - Verify the perviously selected date is able to retain on Clicking the 'Reset' button" );

            //Click on the cancel button of 'Edit Targets' popup
            assignmentDetailsPage.clickOnResetButtonOfEditTargets();

            //Assertion
            Log.softAssertThat( !selectedPastDate.equals( assignmentDetailsPage.getSelectedDate() ), "Data is getting retained when the teacher click on the Reset button",
                    "Data is not getting retained when the teacher click on the Reset button" );

            //TC11
            SMUtils.logDescriptionTC( "SMK-13481 Verify the min value and max value of Secondary target slider" );

            SMUtils.logDescriptionTC( "SMK-19147 - Verify the min value and max value of primary target slider" );

            SMUtils.logDescriptionTC( "SMK-19151 - Verify the min value and max value of Secondary target slider" );

            //Assertion for max value of primary target
            Log.softAssertThat( assignmentDetailsPage.verifyMaxValuesOfSliderOfEditTargetPopup(), "Slider max values for 'Edit Targets' popup are as expected", "Slider max values for 'Edit Targets' popup are not as expected" );

            //Assertion for min value of primary target
            Log.softAssertThat( assignmentDetailsPage.verifyMinValuesOfOfSliderOfEditTargetPopup(), "Slider min values for 'Edit Targets' popup are as expected", "Slider min values for 'Edit Targets' popup are not as expected" );

            //Future Date
            LocalDate dateDayAfterTomorrow = today.plusDays( 2 );

            //Choose the required date
            LocalDate selectedDateDayAfterTomorrow = assignmentDetailsPage.chooseDate( dateDayAfterTomorrow );

            //Assertion
            Log.softAssertThat( selectedDateDayAfterTomorrow.equals( dateDayAfterTomorrow ), "Future date is as per selected by the Teacher", "Future date is not as per selected by the Teacher" );

            //TC9
            SMUtils.logDescriptionTC( "SMK-13478 Verify the user able to change the values for primary target using the slider bar" );

            //Assertion for sliders
            Log.softAssertThat( assignmentDetailsPage.verifySliderValuesOfEditTargetPopup( Constants.DRAG_VALUES_FIRST ), "Sliders values for 'Edit Targets' popup  are appearing as expected",
                    "Sliders values for 'Edit Targets' popup  are not appearing as expected" );

            //TC12
            SMUtils.logDescriptionTC( "SMK-13482 Verify the user able to change the values for secondary target using the slider bar" );
            SMUtils.logDescriptionTC( "SMK-19152 - Verify the user able to change the values for secondary target using the slider bar" );

            SMUtils.logDescriptionTC( "SMK-19148 - Verify the user able to change the values for primary target using the slider bar" );

            //TC13
            SMUtils.logDescriptionTC( "SMK-13484 Verify the corresponding values are populating in Seondary target slider bar when user changes the value" );

            SMUtils.logDescriptionTC( "SMK- - Verify the corresponding values are populating in Seondary target slider bar when user changes the value" );

            //Click on the save button
            assignmentDetailsPage.clickOnSaveButtonOfEditTargets();

            //Tried with WebDriver Wait but its not effective as the page loading is taking some time hence using nap
            SMUtils.nap( 5 );

            assignmentDetailsPage.waitForEditTargetsButton();

            //Click on the Edit targets
            assignmentDetailsPage.clickEditTargetButton();

            assignmentDetailsPage.waitForHelpIcon();

            assignmentDetailsPage.setSliderValuesOfEditTargetPopup( Constants.DRAG_VALUES_SECOND );

            //TC10
            SMUtils.logDescriptionTC( "SMK-13479 - Verify the perviously selected value is retained for primary target on clicking the 'Reset' button" );
            SMUtils.logDescriptionTC( "SMK-19149 - Verify the perviously selected value is retained for primary target on clicking the 'Reset' button" );

            SMUtils.logDescriptionTC( "SMK-19150 - Verify the corresponding values are populating in the primary target slider bar when user changes the value" );

            SMUtils.logDescriptionTC( "SMK-19153 - Verify the previously selected value for secondary target is retained on clicking the 'Reset' button" );

            //Click on the cancel button of 'Edit Targets' popup
            assignmentDetailsPage.clickOnResetButtonOfEditTargets();

            //Assertion for sliders
            Log.softAssertThat( assignmentDetailsPage.getSliderValuesOfEditTargetPopup().equals( Constants.SLIDER_VALUES ), "Sliders values are getting retained as expected", "Sliders values are not getting retained as expected" );

            SMUtils.logDescriptionTC( "SMK-19154 - Verify the corresponding values are populating in Seondary target slider bar when user changes the value" );

            //Click on the 'Zoom In' button
            assignmentDetailsPage.clickZoomInButton();

            assignmentDetailsPage.waitForEditTargetsButton();

            //Click on the Edit targets
            assignmentDetailsPage.clickEditTargetButton();

            Boolean presenceOfHelpIconInZoomInPopup = assignmentDetailsPage.verifyThePresenceOfHelpIcon();

            //Check the availability of the help icon
            Log.softAssertThat( Boolean.TRUE.equals( presenceOfHelpIconInZoomInPopup ), "The Help icon is present in the 'Edit Targets' popup", "The Help icon is absent in the 'Edit Targets' popup" );

            //TC14
            SMUtils.logDescriptionTC( "SMK-13486 - Verify the user able to view the 'Edit Targets' popup via 'Zoom In' option" );

            SMUtils.logDescriptionTC( "SMK-19156 - Verify the user able to view the 'Edit Targets' popup via 'Zoom In' option" );

            assignmentDetailsPage.clickCloseButtonOfEditTargets();

            SMUtils.logDescriptionTC( "SMK-19136 - Verify the user able to close the 'Edit Targets' popup using 'Close' icon" );

            //Sign out
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    /**
     * To execute the course
     *
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "5", "30" );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "5", "30" );
                studentsPage.logout();
                driver.quit();
            } catch ( Exception e ) {
                driver.quit();
            }
        }

    }
}