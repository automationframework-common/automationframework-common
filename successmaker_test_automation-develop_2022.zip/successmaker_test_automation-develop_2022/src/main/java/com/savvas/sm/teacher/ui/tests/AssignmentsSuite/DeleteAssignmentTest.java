package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

@Listeners(EmailReport.class)
public class DeleteAssignmentTest extends BaseTest {
	private String smUrl;
	private String browser;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String schoolID;
	private String teacherID;
	private static String username = null;
	private String staticCourseName = null;
	private String stuFName;
	private String stuUserName;
	String teacherDetails;
	private static String password;
	TeacherHomePage teacherHomePage;
	LoginPage smLoginPage;
	String studentDetails;
	String studentDetailsSecond;
	String studentDetailsThree;
	String studentSMDetails;
	String studentSMDetailsSecond;
	String studentSMDetailsThree;
	private HashMap<String, String> groupDetails = new HashMap<>();
	private static List<String> studentRumbaIds = new ArrayList<>();
	private String token = null;

	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		schoolID = RBSDataSetup.organizationIDs.get(school);
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;

		studentDetails = RBSDataSetup.getMyStudent(school, username);
		stuUserName = SMUtils.getKeyValueFromResponse(studentDetails, "userName");
		stuFName = SMUtils.getKeyValueFromResponse(studentDetails, "firstName");
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails, "userId"));

		// token creation
		token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(teacherDetails, "userName"),RBSDataSetupConstants.DEFAULT_PASSWORD);

		// Group
		String groupName = "GroupNo_" + System.nanoTime();
		groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		groupDetails.put(GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetails.put(GroupConstants.GROUP_NAME, groupName);
		String groupId = SMUtils.getKeyValueFromResponse(
				new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds).get(Constants.REPORT_BODY),
				"data,groupId");

	}

	@Test(description = "Verify that clicking on View Assignment button, you are redirected to the Assignment Details page where all the students assigned to the assignments is listed", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 1)
	public void tcSMDeleteAssignment001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment001: SMK-6425: Verify that clicking on View Assignment button, you are redirected to the Assignment Details page where all the students assigned to the assignments is listed. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.message(assignmentDetailsPage.gettitleOfAssignmentDetailsPage());
			Log.message(staticCourseName);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),
					"Navigated to Assignment Details Page", "Not Navigated to Assignment Details Page");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the title of the Assignment Details Page is correct", groups = { "Assignments",
			"SMK-39227", "Delete_Assignment" }, priority = 1)

	public void tcSMDeleteAssignment002() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment002: SMK-6426: Verify the title of the Assignment Details Page is correct<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			Log.message("staticCourseName : " + staticCourseName);

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.message(assignmentDetailsPage.gettitleOfAssignmentDetailsPage());
			Log.message(staticCourseName);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),
					"Title is displayed correctly", "Title is not displayed correctly");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the Elipses menu(...) is clickable", groups = { "Assignments", "SMK-39227",
			"Delete_Assignment" }, priority = 1)
	public void tcSMDeleteAssignment003() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment003: SMK-6430: Verify that the Elipses menu(...) is clickable.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			Log.message("staticCourseName : " + staticCourseName);

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			// Click on Dot ellipsis
			assignmentDetailsPage.assignmentLevelEllipsis();
			Log.assertThat(assignmentDetailsPage.assignmentLevelEllipsisClicked(), "Ellipses button is clickable",
					"Ellipses button is not clickable");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that when you click on the Elipses menu(...). The following options must be displayed: Assignment Settings, Pause All Students, Delete Assignment", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 1)
	public void tcSMDeleteAssignment004() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment004: SMK-6432: Verify that when you click on the Elipses menu(...). The following options must be displayed: Assignment Settings, Pause All Students, Delete Assignment<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			Log.message("staticCourseName : " + staticCourseName);

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);

			// Click on Dot ellipsis

			assignmentDetailsPage.assignmentLevelEllipsis();
			Log.assertThat(assignmentDetailsPage.assignmentSettingTabTopEllipsis().equals(Constants.ASSIGMENT_SETTINGS),
					"Assignment Settings is displayed", "Assignment Settings is not displayed");
			Log.assertThat(assignmentDetailsPage.pauseAllStudentTopEllipsis().equals(Constants.PAUSED_ALL_STUDENTS),
					"Pause All Students is displayed", "Pause All Students is not displayed");
			Log.assertThat(assignmentDetailsPage.deleteAssignmenttabTopEllipsis().equals(Constants.DELETED_ASSIGNMENT),
					"Delete Assignment is displayed", "Delete Assignment is not displayed");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that clicking on Elipses menu(...) while the options are displayed, closes the options dropdown", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 2)
	public void tcSMDeleteAssignment005() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment005: SMK-6433: Verify that clicking on Elipses menu(...) while the options are displayed, closes the options dropdown<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password );
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();
			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
		    courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

		    // Click on CourseName
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			Log.message("staticCourseName : " + staticCourseName);

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			// Click on Dot ellipsis
			assignmentDetailsPage.assignmentLevelEllipsis();
			Log.assertThat(assignmentDetailsPage.assignmentLevelEllipsisClicked(), "Ellipses button is clickable",
					"Ellipses button is not clickable");
			// Click on Dot ellipsis to close it
			assignmentDetailsPage.assignmentLevelEllipsis();
			// Click again to open ellipses
			assignmentDetailsPage.assignmentLevelEllipsis();
			Log.assertThat(assignmentDetailsPage.assignmentLevelEllipsisClicked(), "Ellipses button is clickable",
					"Ellipses button is not clickable");
			assignmentDetailsPage.deleteAssignmenttab();
			SMUtils.logDescriptionTC(
					"SMK-10222 : Verify the \"Delete\" button color in Remove Assigment popup for teacher user");
			SMUtils.logDescriptionTC(
					"SMK-10228 : Verify the \"Delete\" button color in Delete Assignment popup in Assignment section for teacher user");
			Log.assertThat(assignmentDetailsPage.verifyColorCodeFordeleteAssignmentButton(),
					"Delete button color code is displayed as " + Constants.BUTTON_COLOR_CODE,
					"Delete button color code is not displayed as " + Constants.BUTTON_COLOR_CODE);
			assignmentDetailsPage.deleteAssignmentButton();
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the Delete Assignment option is clickable", groups = { "Assignments", "SMK-39227",
			"Delete_Assignment" }, priority = 1)
	public void tcSMDeleteAssignment006() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment006: SMK-6435: Verify that the Delete Assignment option is clickable<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			Log.message("staticCourseName : " + staticCourseName);

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			// Click on Dot ellipsis

			assignmentDetailsPage.assignmentLevelEllipsis();
			assignmentDetailsPage.deleteAssignmenttab();
			Log.assertThat(assignmentDetailsPage.checkDeleteAssignmentTabClicked(), "Clicked delete Assignment tab",
					"Did not click delete Assignment tab");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that when you click on the Delete Assignment option from the Elipses(...) menu. A Delete Assignment confirmation popup to delete the assignment is displayed", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 1)
	public void tcSMDeleteAssignment007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment007: SMK-6436: Verify that when you click on the Delete Assignment option from the Elipses(...) menu. A Delete Assignment confirmation popup to delete the assignment is displayed<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password );
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			Log.message("staticCourseName : " + staticCourseName);

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			// Click on Dot ellipsis

			assignmentDetailsPage.assignmentLevelEllipsis();
			assignmentDetailsPage.deleteAssignmenttab();
			Log.assertThat(assignmentDetailsPage.isDeleteAssignmentPopUpDisplayed(),
					"Delete Assignment Popup is displayed", "Delete Assignment Popup not displayed");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the Delete Confirmation popup is closed, when we click on Close(X) button.", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 1)
	public void tcSMDeleteAssignment008() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment008: SMK-6437: Verify that the Delete Confirmation popup is closed, when we click on Close(X) button.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			Log.message("staticCourseName : " + staticCourseName);

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			// Click on Dot ellipsis

			assignmentDetailsPage.assignmentLevelEllipsis();
			assignmentDetailsPage.deleteAssignmenttab();
			assignmentDetailsPage.clickCloseButton();
			Log.assertThat(assignmentDetailsPage.isDeleteAssignmentPopupClosed(), "Popup is closed",
					"Popup is not closed");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that when you Cancel the Delete Confirmation message, the assignment is not deleted.", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 1)
	public void tcSMDeleteAssignment009() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data
	
		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment009: SMK-6438: Verify that when you Cancel the Delete Confirmation message, the assignment is not deleted.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password );
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			Log.message("staticCourseName : " + staticCourseName);

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			// Click on Dot ellipsis

			assignmentDetailsPage.assignmentLevelEllipsis();
			assignmentDetailsPage.deleteAssignmenttab();
			assignmentDetailsPage.clickCancelButtonForDeleteAssignment();
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),
					"Assignment is not deleted", "Assignment not found");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that when you delete the assignment by accepting the Delete Confirmation message, the assignment is deleted from the Assignments listing page.", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 1)
	public void tcSMDeleteAssignment010() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment10: SMK-6440: Verify that when you delete the assignment by accepting the Delete Confirmation message, the assignment is deleted from the Assignments listing page.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");
			
			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);
			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			Log.message("staticCourseName : " + staticCourseName);

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);

			// Click on Dot ellipsis

			assignmentDetailsPage.assignmentLevelEllipsis();
			assignmentDetailsPage.deleteAssignmenttab();
			assignmentDetailsPage.deleteAssignmentButton();
			Log.assertThat(assignmentDetailsPage.assignmentDeleted(), "Assignment has deleted successfully",
					"Assignment has not deleted successfully");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that you can re-assign the deleted assignment to the same set of students.", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 2)
	public void tcSMDeleteAssignment011() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment011: SMK-6442: Verify that you can re-assign the deleted assignment to the same set of students.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);
		
			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();
			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
		    courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

		    // Click on CourseName
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			Log.message("staticCourseName : " + staticCourseName);

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().equals(staticCourseName),
					"Assignment Re-assigned", "Assignment not Re-assigned");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that when all the assignments created by the teacher is deleted, A zero state screen is displayed for the Assignment listing page.", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 1)
	public void tcSMDeleteAssignment012() throws Throwable {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment012: SMK-6445: Verify that when all the assignments created by the teacher is deleted, A zero state screen is displayed for the Assignment listing page.<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			Log.assertThat(Constants.ZERO_STATE_SCREEN_MESSAGE.equals(page.assignmentListingZeroState().trim()),
					"Zero State Screen displayed", "Zero State Screen not displayed");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that deleting a particular assignment doesn't affect other assignments", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 2)
	public void tcSMDeleteAssignment013() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data

		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment013: SMK-6446: Verify that deleting a particular assignment doesn't affect other assignments<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);

			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			page.getAssignments(); // Display Assignments before deletion
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);

			assignmentDetailsPage.assignmentLevelEllipsis();
			assignmentDetailsPage.deleteAssignmenttab();
			assignmentDetailsPage.deleteAssignmentButton();
			Log.assertThat(assignmentDetailsPage.assignmentDeleted(), "Assignment has deleted successfully",
					"Assignment has not deleted successfully");
			page.getAssignments(); // Display Assignments after deletion

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that the list of students displayed should belong to the specific assignment", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 3)
	public void tcSMDeleteAssignment014() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data
		SMUtils.logDescriptionTC(
				"SMK-6427: Verify that the list of students displayed should belong to the specific assignment<small><b><i>["
						+ browser + "]</b></i></small>");
		SMUtils.logDescriptionTC(
				"SMK-6428: Verify that all students assigned to the particular assignment are listed<small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);

			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToOneStudent(stuFName);

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(assignmentDetailsPage.verifyStudentsAssignedToAssignment(stuFName),
					"List of students displayed belongs to the specific assignment",
					"List of students displayed does not belong to the specific assignment");
			SMUtils.logDescriptionTC(
					"SMK-6429: Verify that the number of active and inactive students displayed are correct<small><b><i>["
							+ browser + "]</b></i></small>");
			Log.message(assignmentDetailsPage.getactivePausedText().trim());
			Log.message(Constants.STATUS_SUBTITLE);
			Log.assertThat(assignmentDetailsPage.getactivePausedText().trim().equals(Constants.STATUS_SUBTITLE),
					"Active/Paused Displayed Correctly", "Active/Paused Not Displayed Correctly");
			SMUtils.logDescriptionTC(
					"SMK-6439: Verify that the Delete Assignment confirmation popup contains the correct information about the Assignment to be deleted.<small><b><i>["
							+ browser + "]</b></i></small>");
			assignmentDetailsPage.assignmentLevelEllipsis();
			assignmentDetailsPage.deleteAssignmenttab();
			List<String> deletePopupInfoText = assignmentDetailsPage.getTextFromDeleteAssignmentPopup();
			Log.message(deletePopupInfoText.toString());
			Log.message(Constants.DELETE_POPUP_TEXT.toString());
			Log.assertThat((deletePopupInfoText.toString()).equals(Constants.DELETE_POPUP_TEXT.toString()),
					"Information displayed correctly", "Info not displayed correctly");
			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify that when you hover the mouse pointer over the Delete Assignment option it is highlighted", groups = {
			"Assignments", "SMK-39227", "Delete_Assignment" }, priority = 3)
	public void tcSMDeleteAssignment015() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
		SMUtils.logDescriptionTC(
				"tcSMDeleteAssignment015: SMK-6434: Verify that when you hover the mouse pointer over the Delete Assignment option it is highlighted<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage coursePage = teacherHomePage.topNavBar.navigateToCourseListingPage();
			CoursesPage customCourses = new CoursesPage(driver);
			staticCourseName = customCourses.generateRandomCourseName();
			// Get CourseLising Page
			CourseListingPage courseListingPage = teacherHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			Log.message("staticCourseName : " + staticCourseName);

			// Make a copy of the course
			customCourses.copyOfCourse(staticCourseName, Constants.SETTINGS, Constants.MATH);

			// Get CourseLising Page
			teacherHomePage.topNavBar.getCourseListingPage();
			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Verify that the new course showed in course listing page
			coursePage.verifyCourseRemovedSuccessfully(staticCourseName);
			coursePage.clickCourseName(staticCourseName);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();

			// Navigate to Courseware tab
			AssignmentsPage page = teacherHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);
			Log.assertThat(!assignmentDetailsPage.checkDeleteAssignmentHighlighted(),
					"Delete Assignment is not highlighted", "Delete Assignment is highlighted");

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			// Log message for test case
			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}
}
