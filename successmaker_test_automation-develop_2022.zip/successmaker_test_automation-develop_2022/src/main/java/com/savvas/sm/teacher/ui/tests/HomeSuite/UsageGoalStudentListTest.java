package com.savvas.sm.teacher.ui.tests.HomeSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.RestAssuredAPI;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.Constants.UsageGoal;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.JSONUtil;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.FileConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.CommonAPIConstants.PayloadFor;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.homepage.HomePage;
import com.savvas.sm.utils.sql.helper.FixupFunction;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.restassured.response.Response;

public class UsageGoalStudentListTest extends BaseTest {

    private String smUrl;
    private String browser;
    private String username = null;
    private static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private String studentDetails1;
    private String studentDetails2;
    private String teacherDetails;
    private String teacherUserID;
    private String school;
    private String studentDetails3;
    private String mathAssignmentUserId;
    private String readingAssignmentUserId;
    private static Map<String, String> contentBase = new HashMap<>();
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();

    private List<String> courseIDs = new ArrayList<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String studentUsername1;
    private String studentUsername2;
    private String orgId;
    private String token;

    @BeforeClass
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

        orgId = RBSDataSetup.organizationIDs.get( school );
        
        //Getting teacher details
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUserID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );

        //Getting student details
        studentDetails1 = RBSDataSetup.getMyStudent( school, username );
        studentDetails2 = RBSDataSetup.getMyStudent( school, username );
        studentDetails3 = RBSDataSetup.getMyStudent( school, username );

        //Getting access token
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Getting assignment details
        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserID );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        //Getting student rumbaId 
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails1, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails2, "userId" ) );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails3, "userId" ) );

        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );

        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );

        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );

        HashMap<String, String> mathAssignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, Arrays.asList( courseIDs.get( 0 ) ) );
        HashMap<String, String> readingAssignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, Arrays.asList( courseIDs.get( 1 ) ) );

        // Getting assignment id
        JSONObject mathAssignmentDetailsJson = new JSONObject( mathAssignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject mathAssignmentInfo = new JSONObject( mathAssignmentList.get( 0 ).toString() );
        String mathAssignmentId = mathAssignmentInfo.get( "assignmentId" ).toString();
        mathAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 2 ), mathAssignmentId );

        // Getting assignment id
        JSONObject readingAssignmentDetailsJson = new JSONObject( readingAssignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray readingAssignmentList = readingAssignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject readingAssignmentInfo = new JSONObject( readingAssignmentList.get( 0 ).toString() );
        String readingAssignmentId = readingAssignmentInfo.get( "assignmentId" ).toString();
        readingAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 2 ), readingAssignmentId );

        //Getting student username details
        studentUsername1 = SMUtils.getKeyValueFromResponse( studentDetails1, "userName" );
        studentUsername2 = SMUtils.getKeyValueFromResponse( studentDetails2, "userName" );

        //Executing the courses
        executeCourse( studentUsername1, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
        executeCourse( studentUsername1, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );

        //Executing fixup query 
        FixupFunction.executeFixupFunctions( orgId );

    }

    @Test ( description = "SMK-13373,SMK-13376 - Verify the student listing displays correctly for math usage goals in homepage", priority = 1, groups = { "SMK-43643", "Goals", "UsageGoalStudentList" } )
    public void tcUsageGoalsStudentList001() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcUsageGoalsStudentList001: SMK-13373,SMK-13376 - Verify the usage goals-student list in home page." + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-13373 - Verify the teacher is able to click the usage goals toggle button in home page." );
            SMUtils.logDescriptionTC( "SMK-13376 : Verify the Student is able to Navigate to Math Usage Goals Webpage and verify the following columns" );
            //navigate to Usage goal -student list for math assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.MATH );

            //verifying usage goal - student list Math Headers
            Log.assertThat( teacherHomePage.verifyUsageGoalStudentListHeader( Constants.MATH ), "Math Usage goal - student List header displayed properly!", "Math Usage goal - student List header not  displayed properly!" );
            //Verifying columns in usage goal -student listing Page
            Log.assertThat( teacherHomePage.verifyColumnsInUsageGoalStudentListingPage(), "Column headers displayed properly for math!", "Column headers displayed properly for math!" );

            teacherHomePage.clickBackIconInUsageGoalStudentListingPage();
            //navigate to Usage goal -student list for Reading assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.READING );

            //verifying usage goal - student list Reading Headers
            Log.assertThat( teacherHomePage.verifyUsageGoalStudentListHeader( Constants.READING ), "Reading Usage goal - student List header displayed properly!", "Reading Usage goal - student List header not  displayed properly!" );
            //Verifying columns in usage goal -student listing Page
            Log.assertThat( teacherHomePage.verifyColumnsInUsageGoalStudentListingPage(), "Column headers displayed properly for reading!", "Column headers not displayed properly for reading!" );
            Log.testCaseResult();

            //sign out from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "SMK-13374,SMK-13375 - Verify the student listing displays correctly for usage goals in homepage", dataProvider = "getUsageGoalFullListDataFromAPI", priority = 1, groups = { "SMK-43643", "Goals", "UsageGoalStudentList" } )
    public void tcUsageGoalsStudentList002( Map<String, HashMap<String, String>> studentMathUsageDetails ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "tcUsageGoalsStudentList002: SMK-13374,SMK-13375 - Verify the student listing displays correctly for usage goals in homepage." + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            SMUtils.logDescriptionTC( "SMK-13374 -  Verify the student listing displays correctly for math usage goals in homepage" );
            //navigate to Usage goal -student list for math assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.MATH );
            List<String> studentNameFromAPI = new ArrayList<>();
            IntStream.rangeClosed( 1, studentMathUsageDetails.size() ).forEach( index -> {
                String studentUsageDetails = studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL );
                studentNameFromAPI.add( SMUtils.getKeyValueFromResponse( studentUsageDetails, Constants.FIRSTNAME ) + " " + SMUtils.getKeyValueFromResponse( studentUsageDetails, Constants.LASTNAME ) );
            } );

            List<String> studentNamesFromUI = teacherHomePage.getStudentNamesFromUI();
            Log.assertThat( studentNamesFromUI.containsAll( studentNameFromAPI ), "All student names displayed properly", "All students names not displayed properly" );
            Log.testCaseResult();

            teacherHomePage.clickBackIconInUsageGoalStudentListingPage();

            SMUtils.logDescriptionTC( "SMK-13375 - Verify the student listing displays correctly for reading usage goals in homepage" );
            //navigate to Usage goal -student list for Reading assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.READING );
            studentNamesFromUI = teacherHomePage.getStudentNamesFromUI();
            Log.assertThat( studentNamesFromUI.containsAll( studentNameFromAPI ), "All student names displayed properly", "All students names not displayed properly" );
            Log.testCaseResult();

            //sign out from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "SMK-13378 - Verify Usage goals status is updated as IP when the assignment is not started by the student", dataProvider = "getUsageGoalFullListDataFromAPI", priority = 1, groups = { "SMK-43643", "Goals",
            "UsageGoalStudentList" } )
    public void tcUsageGoalsStudentList003( Map<String, HashMap<String, String>> studentMathUsageDetails ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcUsageGoalsStudentList003: SMK-13378 - Verify Usage goals status is updated as IP when the assignment is not started by the student" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            //navigate to Usage goal -student list for math assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.MATH );
            Map<String, String> studentGoalStatusFromUI = teacherHomePage.getGoalStatusFromUI();
            String studentName = SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( studentDetails3 ).get( UsageGoal.STUDENT_DETAIL ), Constants.FIRSTNAME ) + " "
                    + SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( studentDetails3 ).get( UsageGoal.STUDENT_DETAIL ), Constants.LASTNAME );
            Log.message( studentName );
            Log.assertThat( studentGoalStatusFromUI.get( studentName ).equals( "In IP" ), "In IP is displayed when the assignment is not started by the student", "In IP is not displayed when the assignment is not started by the student" );
            Log.testCaseResult();

            //sign out from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "SMK-13380,SMK-13381,SMK-13382,SMK-13383 - Verify the data represented under the total time, Avg Time /Wk, Target Hours, Goal End Date sections", dataProvider = "getUsageGoalFullListDataFromAPI", priority = 1, groups = {
            "SMK-43643", "Goals", "UsageGoalStudentList" } )
    public void tcUsageGoalsStudentList004( Map<String, HashMap<String, String>> studentMathUsageDetails ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcUsageGoalsStudentList004: SMK-13380,SMK-13381,SMK-13382,SMK-13383 - Verify the data represented under the total time, Avg Time /Wk, Target Hours, Goal End Date sections" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            //navigate to Usage goal -student list for math assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.MATH );
            Map<String, String> studentTotalTimeFromUI = teacherHomePage.getColumnValuesFromUI( "Total Time" );
            SMUtils.logDescriptionTC( "SMK-13380 - Verify the data represented under the total time section" );
            Map<String, String> studentTotalTimeFromAPI = new HashMap<>();
            IntStream.rangeClosed( 1, studentMathUsageDetails.size() ).forEach( index -> {
                if ( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.ACTUAL_MINUTES ).equals( "0" ) ) {
                    studentTotalTimeFromAPI.put( SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), Constants.FIRSTNAME ) + " "
                            + SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), Constants.LASTNAME ), "In IP" );
                } else {
                    String hour = teacherHomePage.convertMinutesIntoHours( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.ACTUAL_MINUTES ) );

                    studentTotalTimeFromAPI.put( SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), "firstName" ) + " "
                            + SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), "lastName" ), hour );
                }
            } );
            Log.assertThat( studentTotalTimeFromUI.equals( studentTotalTimeFromAPI ), "Total time displayed properly", "Total time is not displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13381 - Verify the data represented under the Avg Time /Wk Section" );
            Map<String, String> studentAvgTimePerWeekFromUI = teacherHomePage.getColumnValuesFromUI( "Avg Time / Wk" );
            Map<String, String> studentAvgTimePerWeekFromAPI = new HashMap<>();
            IntStream.rangeClosed( 1, studentMathUsageDetails.size() ).forEach( index -> {
                if ( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.AVERAGE_MINUTE_PER_WEEK ).equals( "0" ) ) {
                    studentAvgTimePerWeekFromAPI.put( SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), Constants.FIRSTNAME ) + " "
                            + SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), Constants.LASTNAME ), "In IP" );
                } else {
                    String hour = teacherHomePage.convertMinutesIntoHours( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.AVERAGE_MINUTE_PER_WEEK ) );
                    studentAvgTimePerWeekFromAPI.put( SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), "firstName" ) + " "
                            + SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), "lastName" ), hour );
                }
            } );
            Log.assertThat( studentAvgTimePerWeekFromUI.equals( studentAvgTimePerWeekFromAPI ), "Student Avg Time Per Week displayed properly", "Student Avg Time Per Week is not displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13382 - Verify the data represented under the Target Hours Section" );
            Map<String, String> studentTargetHoursFromUI = teacherHomePage.getColumnValuesFromUI( "Target Hours" );
            Map<String, String> studentTargetHoursFromAPI = new HashMap<>();
            IntStream.rangeClosed( 1, studentMathUsageDetails.size() ).forEach( index -> {
                String hour = teacherHomePage.convertMinutesIntoHours( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.GOAL_MINUTES ) );
                studentTargetHoursFromAPI.put( SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), Constants.FIRSTNAME ) + " "
                        + SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), Constants.LASTNAME ), hour );

            } );
            Log.assertThat( studentTargetHoursFromUI.equals( studentTargetHoursFromAPI ), "Student target hours displayed properly", "Student target hours is not displayed properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13383 - Verify the data represented under the Goal End Date" );
            Map<String, String> studentGoalEndDateFromUI = teacherHomePage.getColumnValuesFromUI( "Goal End Date" );
            Map<String, String> studentGoalEndDateFromAPI = new HashMap<>();
            IntStream.rangeClosed( 1, studentMathUsageDetails.size() ).forEach( index -> {
                studentGoalEndDateFromAPI.put(
                        SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), Constants.FIRSTNAME ) + " "
                                + SMUtils.getKeyValueFromResponse( studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL ), Constants.LASTNAME ),
                        studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.GOAL_END_DATE ) );
            } );
            Log.assertThat( studentGoalEndDateFromUI.equals( studentGoalEndDateFromAPI ), "Student Goal end date displayed properly", "Student Goal end date is not displayed properly" );
            Log.testCaseResult();

            //sign out from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "SMK-13402,SMK-134023 - Verify upon selecting the check box for single student Edit Usage goals is enabled", priority = 1, groups = { "SMK-43643", "Goals", "UsageGoalStudentList" } )
    public void tcUsageGoalsStudentList005() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcUsageGoalsStudentList005: SMK-13402,SMK-134023 -Verify upon selecting the check box for single student Edit Usage goals is enabled" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            //navigate to Usage goal -student list for math assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.MATH );
            List<String> studentNameFromUI = teacherHomePage.getStudentNamesFromUI();
            SMUtils.logDescriptionTC( "SMK-13402 - Verify upon selecting the check box for single student Edit Usage goals is enabled" );
            List<String> selectedStudents = Arrays.asList( studentNameFromUI.get( 0 ) );
            teacherHomePage.selectCheckForStudentsinUsageGoal( selectedStudents );
            Log.assertThat( teacherHomePage.isEditUsageGoalButtonEnabled(), "Edit Usage goals is enabled after selecting single student!", "Edit Usage goals is not enabled after selecting single student!" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13403 - Verify upon selecting all the students edit usage goals is enabled" );
            teacherHomePage.selectCheckForStudentsinUsageGoal( studentNameFromUI );
            Log.assertThat( teacherHomePage.isEditUsageGoalButtonEnabled(), "Edit Usage goals is enabled after selecting single student!", "Edit Usage goals is not enabled after selecting single student!" );
            Log.testCaseResult();

            //sign out from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-13415,SMK-13416 - Verify that the Usage goal status is updated as 'Falling Behind' and 'Watch Closely' when the min required is more than zero for Reading course", priority = 1, groups = { "SMK-43643", "Goals",
            "UsageGoalStudentList" } )
    public void tcUsageGoalsStudentList006() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "tcUsageGoalsStudentList006: SMK-13415,SMK-13416 -Verify that the Usage goal status is updated as 'Falling Behind' and 'Watch Closely' when the min required is more than zero for Reading course" + "<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            String studentName = SMUtils.getKeyValueFromResponse( studentDetails1, Constants.FIRSTNAME ) + " " + SMUtils.getKeyValueFromResponse( studentDetails1, Constants.LASTNAME );
            //navigate to Usage goal -student list for reading assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.READING );

            SMUtils.logDescriptionTC( "SMK-13415 - Verify that the Usage goal status is updated as 'Watch Closely' when the min required is between 0-5 for Reading course" );
            teacherHomePage.changeGoalstatusForStudent( studentName, UsageGoal.WATCH_CLOSELY );
            Log.assertThat( teacherHomePage.getGoalStatusFromUI().get( studentName ).equalsIgnoreCase( UsageGoal.WATCH_CLOSELY ), "Usage goal status is updated as 'Watch Closely' when the min required is between 0-5 for Reading course",
                    "Usage goal status is not updated as 'Watch Closely' when the min required is between 0-5 for Reading course" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13416 -Verify that the Usage goal status is updated as 'Falling Behind' when the min required is more than or equals to 6 for Reading course" );
            teacherHomePage.changeGoalstatusForStudent( studentName, UsageGoal.FALLING_BEHIND );
            Log.assertThat( teacherHomePage.getGoalStatusFromUI().get( studentName ).equalsIgnoreCase( UsageGoal.FALLING_BEHIND ), "Usage goal status is updated as 'Falling Behind' when the min required is more than or equals to 6 for Reading course",
                    "Usage goal status is not updated as 'Falling Behind' when the min required is more than or equals to 6 for Reading course" );
            Log.testCaseResult();

            //sign out from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-13417,SMK-13418 - Verify that the Usage goal status is updated as 'Falling Behind' and 'Watch Closely' when the min required is more than zero for Math course", priority = 1, groups = { "SMK-43643", "Goals",
            "UsageGoalStudentList" } )
    public void tcUsageGoalsStudentList007() throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcUsageGoalsStudentList007: SMK-13417,SMK-13418 - Verify that the Usage goal status is updated as 'Falling Behind' and 'Watch Closely' when the min required is more than zero for Math course" + "<small><b><i>[" + browser
                + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            String studentName = SMUtils.getKeyValueFromResponse( studentDetails1, Constants.FIRSTNAME ) + " " + SMUtils.getKeyValueFromResponse( studentDetails1, Constants.LASTNAME );
            //navigate to Usage goal -student list for math assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.MATH );

            SMUtils.logDescriptionTC( "SMK-13417 - Verify that the Usage goal status is updated as 'Watch Closely' when the min required is between 0-9 for Math course" );
            teacherHomePage.changeGoalstatusForStudent( studentName, UsageGoal.WATCH_CLOSELY );
            Log.assertThat( teacherHomePage.getGoalStatusFromUI().get( studentName ).equalsIgnoreCase( UsageGoal.WATCH_CLOSELY ), "Usage goal status is updated as 'Watch Closely' when the min required is between 0-9 for Math course",
                    "Usage goal status is not updated as 'Watch Closely' when the min required is between 0-9 for Math course" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13418 - Verify that the Usage goal status is updated as 'Falling Behind' when the min required is more than or equals to 10 for Math course" );
            teacherHomePage.changeGoalstatusForStudent( studentName, UsageGoal.FALLING_BEHIND );
            Log.assertThat( teacherHomePage.getGoalStatusFromUI().get( studentName ).equalsIgnoreCase( UsageGoal.FALLING_BEHIND ), "Usage goal status is updated as 'Falling Behind' when the min required is more than or equals to 10 for Math course",
                    "Usage goal status is not updated as 'Falling Behind' when the min required is more than or equals to 10 for Math course" );
            Log.testCaseResult();

            //sign out from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = " SMK-13444 - Verify the Usage Goals ,when the assignment is paused from one student", dataProvider = "getUsageGoalFullListDataFromAPI", priority = 1, groups = { "SMK-43643", "Goals", "UsageGoalStudentList" } )
    public void tcUsageGoalsStudentList008( Map<String, HashMap<String, String>> studentMathUsageDetails ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );

        Log.testCaseInfo( "tcUsageGoalsStudentList008: SMK-13444 - Verify the Usage Goals ,when the assignment is paused from one student" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            // Navigate to Assignment tab
            AssignmentsPage assignmentPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();

            // Click on ViewAssignments
            AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName( Constants.MATH );
            // Verify Resume all and click cancel
            assignmentDetailsPage.pauseAllStudent();
            assignmentDetailsPage.pauseButtonFoAllSTudent();
            SMUtils.logDescriptionTC( "SMK-13444 - Verify the Usage Goals ,when the assignment is paused from one student" );

            teacherHomePage.topNavBar.navigateToHomeTab();
            //navigate to Usage goal -student list for math assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.MATH );

            List<String> studentNameFromAPI = new ArrayList<>();
            IntStream.rangeClosed( 1, studentMathUsageDetails.size() ).forEach( index -> {
                String studentDetails = studentMathUsageDetails.get( String.format( UsageGoal.STUDENT_COUNT, index ) ).get( UsageGoal.STUDENT_DETAIL );
                studentNameFromAPI.add( SMUtils.getKeyValueFromResponse( studentDetails, Constants.FIRSTNAME ) + " " + SMUtils.getKeyValueFromResponse( studentDetails, Constants.LASTNAME ) );
            } );
            List<String> studentNamesFromUI = teacherHomePage.getStudentNamesFromUI();
            Log.assertThat( studentNamesFromUI.containsAll( studentNameFromAPI ), "All student names displayed properly after paused the assignment as Expected", "All students names not displayed properly after paused the assignment" );
            Log.testCaseResult();

            //sign out from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-13440,SMK-13441 - Verify the Usage Goals ,when the assignment is deleted for student", dataProvider = "getUsageGoalFullListDataFromAPI", priority = 1, groups = { "SMK-43643", "Goals", "UsageGoalStudentList" } )
    public void tcUsageGoalsStudentList009( Map<String, HashMap<String, String>> studentMathUsageDetails ) throws Exception {
        // Get driver
        EventFiringWebDriver driver = new EventFiringWebDriver( WebDriverFactory.get( browser ) );
        EventListener eventListner = new EventListener();
        driver.register( eventListner );
        Log.testCaseInfo( "tcUsageGoalsStudentList009: SMK-13440,SMK-13441 - Verify the Usage Goals ,when the  assignment is deleted for student" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginPage smLoginPage = new LoginPage( driver, smUrl ).get();
            TeacherHomePage teacherHomePage = smLoginPage.loginToSM( username, password, true );

            //            String assignmentID1 = SMUtils.getKeyValueFromResponse( studentDetails3, "assignmentId" );
            //            String AssignmentUserId =new SqlHelperAssignment().getAssignmentUserID( SMUtils.getKeyValueFromResponse( studentRumbaIds.get( 2 ), assignmentID1 )

            HashMap<String, String> mathAssignmentDetails = new HashMap<>();
            mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
            mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserID );
            mathAssignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, mathAssignmentUserId );
            mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );

            new AssignmentAPI().removeStudentAssignment( smUrl, mathAssignmentDetails, "null" );

            HashMap<String, String> readingAssignmentDetails = new HashMap<>();
            readingAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
            readingAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserID );
            readingAssignmentDetails.put( AssignmentAPIConstants.ASSIGNMENT_USER_ID, readingAssignmentUserId );
            readingAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD ) );

            new AssignmentAPI().removeStudentAssignment( smUrl, readingAssignmentDetails, "null" );

            SMUtils.logDescriptionTC( "SMK-13440 - Verify the Usage Goals ,when the math assignment is deleted for student" );

            teacherHomePage.topNavBar.navigateToHomeTab();
            //navigate to Usage goal -student list for math assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.MATH );

            String studentName = SMUtils.getKeyValueFromResponse( studentDetails3, Constants.FIRSTNAME ) + " " + SMUtils.getKeyValueFromResponse( studentDetails3, Constants.LASTNAME );

            List<String> studentNamesFromUI = teacherHomePage.getStudentNamesFromUI();
            Log.assertThat( !studentNamesFromUI.contains( studentName ), "Math usage detail is not displayed after delete the assignment for a student", "Math usage detail is displayed after delete the assignment for a student" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "SMK-13441 - Verify the Usage Goals ,when the Reading assignment is deleted for student" );

            teacherHomePage.clickBackIconInUsageGoalStudentListingPage();
            //navigate to Usage goal -student list for Reading assignment
            teacherHomePage.navigateToUsageGoalsStudentsList( Constants.READING );

            List<String> studentNamesFromUIForReading = teacherHomePage.getStudentNamesFromUI();
            Log.assertThat( !studentNamesFromUIForReading.contains( studentName ), "Reading usage detail is not displayed after delete the assignment for a student", "Reading usage detail is displayed after delete the assignment for a student" );
            Log.testCaseResult();

            //sign out from SM
            teacherHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {

            Log.endTestCase();
            driver.quit();
        }
    }

    @DataProvider ( name = "getUsageGoalFullListDataFromAPI" )
    public Object[][] getUsageGoalFullListDataFromAPI() throws Exception {

        List<String> assignmentUserIds = new ArrayList<String>();

        RBSUtils rbs = new RBSUtils();
        HomePage homePage = new HomePage();
        Map<String, String> header = new HashMap<>();
        header.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        header.put( Constants.AUTHORIZATION, Constants.BEARER + rbs.getAccessToken( username, password ) );
        header.put( Constants.ORGID_SM_HEADER, orgId );
        header.put( Constants.USERID_SM_HEADER, teacherUserID );

        //Get usage details
        String responseBody = getUsageGoal( smUrl, rbs.getAccessToken( username, password ), orgId, teacherUserID ).get( "body" );
        String mathDetails = SMUtils.getKeyValueFromResponse( responseBody, Constants.REPORT_BODY_DATA + "," + Constants.MATH.toLowerCase() );
        String assignmentId = SMUtils.getKeyValueFromResponse( mathDetails, "assignedAssignmentUserIds" ).replace( "[", "" ).replace( "]", "" );
        String[] split = assignmentId.split( "," );
        for ( int i = 0; i < split.length; i++ ) {
            assignmentUserIds.add( split[i] );
        }

        //Get usage details
        String postResponse = homePage.getUsageGoalStudentList( smUrl, header, teacherUserID, orgId, assignmentUserIds, "1" ).get( Constants.BODY );

        String studentkey = UsageGoal.STUDENT_COUNT;
        Map<String, HashMap<String, String>> studentMathUsageDetails = new HashMap<>();
        IntStream.rangeClosed( 1, SMUtils.getWordCount( postResponse, UsageGoal.STUDENT ) ).forEach( index -> {
            HashMap<String, String> usageDetailforStudent = new HashMap<>();
            //            Log.message( postResponse + SMUtils.getKeyValueFromJsonArray( postResponse, UsageGoal.STUDENT, index ) );
            usageDetailforStudent.put( UsageGoal.STUDENT_DETAIL, SMUtils.getKeyValueFromJsonArray( postResponse, UsageGoal.STUDENT, index ) );
            usageDetailforStudent.put( UsageGoal.GOAL_BUCKET, SMUtils.getKeyValueFromJsonArray( postResponse, UsageGoal.GOAL_BUCKET, index ) );
            usageDetailforStudent.put( UsageGoal.ACTUAL_MINUTES, SMUtils.getKeyValueFromJsonArray( postResponse, UsageGoal.ACTUAL_MINUTES, index ) );
            usageDetailforStudent.put( UsageGoal.AVERAGE_MINUTE_PER_WEEK, SMUtils.getKeyValueFromJsonArray( postResponse, UsageGoal.AVERAGE_MINUTE_PER_WEEK, index ) );
            usageDetailforStudent.put( UsageGoal.ADDITIONAL_MINUTE_PER_WEEK, SMUtils.getKeyValueFromJsonArray( postResponse, UsageGoal.ADDITIONAL_MINUTE_PER_WEEK, index ) );
            usageDetailforStudent.put( UsageGoal.GOAL_MINUTES, SMUtils.getKeyValueFromJsonArray( postResponse, UsageGoal.GOAL_MINUTES, index ) );
            usageDetailforStudent.put( UsageGoal.GOAL_END_DATE, SMUtils.getKeyValueFromJsonArray( postResponse, UsageGoal.GOAL_END_DATE, index ) );
            studentMathUsageDetails.put( String.format( studentkey, index ), usageDetailforStudent );
        } );
        Object[][] result = { { studentMathUsageDetails } };
        return result;
    }

    public Map<String, String> getUsageGoal( String smUrl, String token, String orgId, String userId ) throws Exception {
        String endPoint = "/lms/web/api/v1/usagegoals";
        Map<String, String> headers = new HashMap<>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( Constants.ORGID_SM_HEADER, orgId );
        headers.put( Constants.USERID_SM_HEADER, userId );
        return RestHttpClientUtil.GET( smUrl, endPoint, headers, new HashMap<>() );
    }

    /**
     * To execute the course
     * 
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, password );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );

        if ( studentUserName.equals( studentUsername1 ) ) {

            if ( isMath ) {
                try {
                    studentsPage.executeMathCourse( studentUserName, courseName, "100", "3", "60" );
                    studentsPage.logout();
                    driver.close();
                } catch ( Exception e ) {
                    driver.close();
                }
            } else {
                try {
                    studentsPage.executeReadingCourse( studentUserName, courseName, "100", "3", "100" );
                    studentsPage.logout();
                    driver.close();
                } catch ( Exception e ) {
                    driver.close();
                }
            }
        } else {
            if ( isMath ) {
                try {
                    studentsPage.executeMathCourse( studentUserName, courseName, "100", "1", "30" );
                    studentsPage.logout();
                    driver.close();
                } catch ( Exception e ) {
                    driver.close();
                }
            } else {
                try {
                    studentsPage.executeReadingCourse( studentUserName, courseName, "100", "3", "40" );
                    studentsPage.logout();
                    driver.close();
                } catch ( Exception e ) {
                    driver.close();
                }
            }

        }
    }

}
