package com.savvas.sm.api.tests.smnew.students;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.AssignmentAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.CreateGroupAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.student.api.licenses.StudentDashboardAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.homepage.HomePage;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class GetAssignmentSessionExist extends EnvProperties {
    private static List<String> studentRumbaIds = new ArrayList<>();
    private String smUrl;
    private String browser;
    private String teacherDetails;
    private String orgId;
    private String teacherId;
    private String teacherUsername;
    private String teacherAccessToken;
    private String mathAssignmentId;
    private String mathAssignmentUserId;
    private String readingAssignmentId;
    private String readingAssignmentUserId;
    private String studentUserName;
    private String studentUserId;

    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    private Map<String, String> response = new HashMap<>();
    AssignmentAPI assignmentAPI = new AssignmentAPI();
    HomePage homePage = new HomePage();
    StudentDashboardPage studentDashboardPage;
    WebDriver studentDriver;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() throws Exception {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        // Getting teacher details
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        orgId = RBSDataSetup.organizationIDs.get( school );
        teacherId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        teacherUsername = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherAccessToken = new RBSUtils().getAccessToken( teacherUsername, password );
        Log.message( "Teacher access token: " + teacherAccessToken );

        // getting student details
        String studentDetails = RBSDataSetup.getMyStudent( school, teacherUsername );
        studentUserId = SMUtils.getKeyValueFromResponse( studentDetails, "userId" );
        studentUserName = SMUtils.getKeyValueFromResponse( studentDetails, "userName" );

        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );

        // Getting group details
        HashMap<String, String> groupDetails = new HashMap<>();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( CreateGroupAPIConstants.GROUP_NAME, "groupName" + System.nanoTime() );
        // Creating a group
        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        // Assigning Math assignment
        HashMap<String, String> mathAssignmentDetails = new HashMap<>();
        mathAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        mathAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        mathAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "1" );
        mathAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
        HashMap<String, String> mathRssignmentResponse = assignmentAPI.assignMultipleAssignments( smUrl, mathAssignmentDetails, studentRumbaIds, Arrays.asList( "1" ) );
        Log.message( mathRssignmentResponse.toString() );

        // Getting assignment id
        JSONObject mathAssignmentDetailsJson = new JSONObject( mathRssignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray mathAssignmentList = mathAssignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject mathAssignmentInfo = new JSONObject( mathAssignmentList.get( 0 ).toString() );
        mathAssignmentId = mathAssignmentInfo.get( "assignmentId" ).toString();
        mathAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), mathAssignmentId );

        // Assigning Reading assignment
        HashMap<String, String> readingAssignmentDetails = new HashMap<>();
        readingAssignmentDetails.put( AssignmentAPIConstants.ORG_ID, orgId );
        readingAssignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherId );
        readingAssignmentDetails.put( AssignmentAPIConstants.COURSE_ID, "2" );
        readingAssignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken );
        HashMap<String, String> readingAssignmentResponse = assignmentAPI.assignMultipleAssignments( smUrl, readingAssignmentDetails, studentRumbaIds, Arrays.asList( "2" ) );

        // Getting assignment id
        JSONObject readingAssignmentDetailsJson = new JSONObject( readingAssignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray readingAssignmentList = readingAssignmentDetailsJson.getJSONArray( Constants.DATA );
        JSONObject readingAssignmentInfo = new JSONObject( readingAssignmentList.get( 0 ).toString() );
        readingAssignmentId = readingAssignmentInfo.get( "assignmentId" ).toString();
        readingAssignmentUserId = new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), readingAssignmentId );

        // Login as a Student
        studentDriver = WebDriverFactory.get( browser );
        LoginPage smStudentLoginPage = new LoginPage( studentDriver, smUrl ).get();
        studentDashboardPage = smStudentLoginPage.loginToSMasStudent( studentUserName, password, true );

    }

    @Test ( dataProvider = "getDataforPostive", priority = 1, groups = { "smoke_test_case", "SMK-67609", "Student_Dashboard", "Multiple_Assignment_Session_Check", "API" } )
    public void getUsageGoal_Positive( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseID + " - " + testDescription );

        HashMap<String, String> assignmentDetails = new HashMap<>();
        assignmentDetails.put( Constants.ORGID_SM_HEADER, orgId );
        assignmentDetails.put( Constants.USERID_SM_HEADER, studentUserId );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( studentUserName, password ) );
        StudentDashboardAPI studentAPI = new StudentDashboardAPI();

        String expectedSessionFlag = null;

        switch ( scenario ) {
            case "False when Math asiignment not started":

                assignmentDetails.put( Constants.ASSIGNMENT_USER_ID, mathAssignmentUserId );
                response = studentAPI.checkAssignmentSessionExist( smUrl, assignmentDetails );
                expectedSessionFlag = "false";
                break;

            case "False when Reading asiignment not started":
                assignmentDetails.put( Constants.ASSIGNMENT_USER_ID, readingAssignmentUserId );
                response = studentAPI.checkAssignmentSessionExist( smUrl, assignmentDetails );
                expectedSessionFlag = "false";
                break;

            case "True when Math asiignment started":
                studentDashboardPage.selectAssignmentByName( Constants.MATH );
                //Wait time is required to generate session Id.
                SMUtils.nap( 10 );
                assignmentDetails.put( Constants.ASSIGNMENT_USER_ID, mathAssignmentUserId );
                response = studentAPI.checkAssignmentSessionExist( smUrl, assignmentDetails );
                expectedSessionFlag = "true";
                break;

            case "True when Reading asiignment started":

                try {
                    SMUtils.waitForElement( studentDriver, studentDashboardPage.closeMathSimulatorPopup );
                    studentDashboardPage.closeMathSimulatorPopup.isDisplayed();
                } catch ( Exception e ) {
                    SMUtils.clickJS( studentDriver, studentDashboardPage.closeMathSimulatorPopup );
                }

                //Wait time is required to generate session Id.
                SMUtils.nap( 10 );
                studentDashboardPage.selectAssignmentByName( Constants.READING );
                assignmentDetails.put( Constants.ASSIGNMENT_USER_ID, readingAssignmentUserId );
                response = studentAPI.checkAssignmentSessionExist( smUrl, assignmentDetails );
                expectedSessionFlag = "true";
                break;

        }

        // Validating Status Code
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + " Verified",
                "The Status code is expected " + statusCode + " and actual " + response.get( Constants.STATUS_CODE ) + "is not Verified" );

        //Schema Validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "MultipleAssignmentSessionCheck", statusCode, response.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.", "Schema is not as expected." );

        // Data Validation
        Log.assertThat( SMUtils.getKeyValueFromResponse( response.get( "body" ), "data,isSessionExist" ).equals( expectedSessionFlag ), "API response returned as " + scenario, "API response is not returned as " + scenario );

    }

    @DataProvider ( name = "getDataforPostive" )
    public Object[][] getDataforPostive() {

        Object[][] data = { { "tcAssignmentSessionExist001", "Verify the status code and API response when Student not started Math assignment.", "200", "False when Math asiignment not started" },
                { "tcAssignmentSessionExist002", "Verify the status code and API response when Student not started reading assignment.", "200", "False when Reading asiignment not started" },
                { "tcAssignmentSessionExist003", "Verify the status code and API response when Student started Math assignment.", "200", "True when Math asiignment started" },
                { "tcAssignmentSessionExist004", "Verify the status code and API response when Student started reading assignment.", "200", "True when Reading asiignment started" } };
        return data;
    }

}
