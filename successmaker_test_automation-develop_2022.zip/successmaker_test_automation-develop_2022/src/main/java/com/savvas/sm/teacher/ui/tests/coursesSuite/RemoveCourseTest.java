package com.savvas.sm.teacher.ui.tests.coursesSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class RemoveCourseTest {

    private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String browser;
    private String username = null;
    private String password = null;
    private String schoolID;
    private String teacherID;
    String studentDetails;
    String teacherDetails;
    Set<String> loMainListForMath = new HashSet<>();
    Set<String> loMainListForReading = new HashSet<>();
    private static List<String> studentRumbaIds = new ArrayList<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String token = null;
    private String tag = "]</b></i></small>";
    String newlyCreatedCourse = null;

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        //Change this index if you want to select use teacher other than "Teacher4"
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        schoolID = RBSDataSetup.organizationIDs.get( school );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;

        studentDetails = RBSDataSetup.orgStudentDetails.get( school ).get( "Student1" );
        studentRumbaIds.add( SMUtils.getKeyValueFromResponse( studentDetails, "userId" ) );

        //token creation
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ), RBSDataSetupConstants.DEFAULT_PASSWORD );

        //Group
        String groupName = "GroupNo_" + System.nanoTime();
        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails, "userId" ) );
        groupDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( GroupConstants.GROUP_NAME, groupName );
        String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ), "data,groupId" );

    }

    @Test ( description = "Verify the display of Remove Course button for a Default Course", priority = 1 )
    public void tcSMRemoveCourse001() throws Exception {
        
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10383: tcSMRemoveCourse001: Verify the display of Remove Course button for a Default Course <small><b><i>[" + browser + tag );

        try {
            CoursesPage coursePage = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            // Navigate to Courses Tab
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            coursePage.clickMathCourse();

            // Verify Remove button is present
            Log.assertThat( !coursePage.verifyRemoveBtnIsPresent(), "Remove button is not present for a Default Course", "Remove button is present" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the display of Remove Course button for a Focus Course", priority = 2 )
    public void tcSMRemoveCourse002() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10384: tcSMRemoveCourse002: Verify the display of Remove Course button for a Focus Course <small><b><i>[" + browser + tag );

        try {
            CoursesPage coursePage = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );
            // Navigate to Courses Tab
            tHomePage.topNavBar.navigateToCourseListingPage();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );
            coursePage.clickFromCourseListingPage( Constants.SM_FOCUS_MATH_GRADE6 );

            // Verify Remove button is present
            Log.assertThat( !coursePage.verifyRemoveBtnIsPresent(), "Remove button is not present for a Focus Course", "Remove button is present" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the display of Remove Course button for an Assigned Custom Course", priority = 3 )
    public void tcSMRemoveCourse004() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10386: tcSMRemoveCourse004: Verify the display of Remove Course button for an Assigned Custom Course <small><b><i>[" + browser + tag );

        try {
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = new CoursesPage( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            newlyCreatedCourse = coursePage.generateRandomCourseName();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            coursePage.clickReadingCourse();
            coursePage.clickMakeCopyBtn();
            coursePage.enterCourseName( newlyCreatedCourse );
            coursePage.clickNextBtn();
            coursePage.clickCreateBtn();
            tHomePage.topNavBar.navigateToCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            // Verify Remove button is present
            Log.assertThat( coursePage.verifyRemoveBtnIsPresent(), "Remove button is present for an Assigned Custom Course", "Remove button is not present" );

            coursePage.clickAssignBtn();
            coursePage.addCourseToStudents();
            tHomePage.topNavBar.navigateToCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            // Verify Remove button is present
            Log.assertThat( !coursePage.verifyRemoveBtnIsPresent(), "Remove button is not present for an Assigned Custom Course", "Remove button is present" );
            SMUtils.logDescriptionTC( "SMK-18796 - TC038_Verify the Teacher who created the course is not able to 'Remove' the course from the Dashboard Courseware Widget>Courses section once all the listed teachers in the Assigned By popup have removed the students from the shared course" );


            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the display of Remove Course button for a Custom Course that is Unassigned", priority = 4 )
    public void tcSMRemoveCourse005() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10387: tcSMRemoveCourse005: Verify the display of Remove Course button for a Custom Course that is Unassigned <small><b><i>[" + browser + tag );

        try {
            CoursesPage coursePage = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );
            // Navigate to Courses Tab
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            coursePage.clickReadingCourse();
            coursePage.clickMakeCopyBtn();
            newlyCreatedCourse = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newlyCreatedCourse );
            coursePage.clickNextBtn();
            coursePage.clickCreateBtn();
            tHomePage.topNavBar.navigateToCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            // Verify Remove button is present
            Log.assertThat( coursePage.verifyRemoveBtnIsPresent(), "Remove button is displayed for a Custom Course that is Unassigned", "Remove button is not present" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify if on clicking Remove Course button Remove Course Dialog is opened", priority = 5 )
    public void tcSMRemoveCourse006() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10388: tcSMRemoveCourse006: Verify if on clicking Remove Course button Remove Course Dialog is opened <small><b><i>[" + browser + tag );

        try {
            CoursesPage coursePage = new CoursesPage( driver );
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            coursePage.clickReadingCourse();
            coursePage.clickMakeCopyBtn();
            newlyCreatedCourse = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newlyCreatedCourse );
            coursePage.clickNextBtn();
            coursePage.clickCreateBtn();
            tHomePage.topNavBar.navigateToCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.verifyRemoveCourseDialogOpensUp();
            coursePage.closeDialog();

            // Verify if Remove Course Dialog is closed
            Log.assertThat( !coursePage.isRemoveCourseDialogClosed(), "Remove Course Dialog is closed", "Remove Course Dialog is not closed" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify when Remove button is clicked in Remove Course Dialog the course is removed from Course Listing page", priority = 6 )
    public void tcSMRemoveCourse007() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10389: tcSMRemoveCourse007: Verify when Remove button is clicked in Remove Course Dialog the course is removed from Course Listing page <small><b><i>[" + browser + tag );

    	try {
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = new CoursesPage( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();
            CourseListingPage courseListingPage = new CourseListingPage( driver );
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.removeCourse();
            tHomePage.topNavBar.navigateToCourseListingPage();

            SMUtils.logDescriptionTC( "SMK-22468 - TC025_Verify once the custom course is deleted by the teacher its not visible in the Courseware>Courses page" );

            //Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is deleted successfully", " Course is not deleted" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify if on clicking Cancel button from Remove Course dialog teacher is taken back to Course Details Page", priority = 7 )
    public void tcSMRemoveCourse009() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10391: tcSMRemoveCourse009: Verify if on clicking Cancel button from Remove Course dialog teacher is taken back to Course Details Page <small><b><i>[" + browser + tag );

        try {
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = new CoursesPage( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();
            String courseNameGivenByTeacher = coursePage.generateRandomCourseName();
            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            coursePage.clickReadingCourse();
            coursePage.clickMakeCopyBtn();
            coursePage.enterCourseName( courseNameGivenByTeacher );
            coursePage.clickNextBtn();
            coursePage.clickCreateBtn();
            tHomePage.topNavBar.navigateToCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( courseNameGivenByTeacher );
            coursePage.clickCancelInRemoveCourseDialog();

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify if on clicking Close button from Remove Course dialog teacher is taken back to Course Details Page", priority = 8 )
    public void tcSMRemoveCourse010() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-10392: tcSMRemoveCourse010: Verify if on clicking Close button from Remove Course dialog teacher is taken back to Course Details Page <small><b><i>[" + browser + tag );

        try {
            //Sign In
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            // Navigate to Courses Tab
            CoursesPage coursePage = new CoursesPage( driver );
            tHomePage.topNavBar.navigateToCourseListingPage();
            String courseNameGivenByTeacher = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = new CourseListingPage( driver );

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            coursePage.clickReadingCourse();
            coursePage.clickMakeCopyBtn();
            coursePage.enterCourseName( courseNameGivenByTeacher );
            coursePage.clickNextBtn();
            coursePage.clickCreateBtn();
            tHomePage.topNavBar.navigateToCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( courseNameGivenByTeacher );
            coursePage.verifyRemoveCourseDialogOpensUp();
            coursePage.closeDialog();
            coursePage.removeCourse();
            tHomePage.topNavBar.navigateToCourseListingPage();

            // Verify course is removed from Course Listing Page
            Log.assertThat( !coursePage.verifyCourseRemovedSuccessfully( courseNameGivenByTeacher ), "Course is deleted successfully", " Course is not deleted" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
