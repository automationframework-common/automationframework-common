package com.savvas.sm.teacher.ui.tests.SmokeSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.sme7.DataSetup;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.LoginWrapper;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

@Listeners ( EmailReport.class )
public class GroupsTabSmokeTest extends BaseTest {

    private String smUrl;
    private String browser;
    private static String sessionCookie;
    private static String username = null;
    private static String password = DataSetupConstants.DEFAULT_PASSWORD;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private String teacherID;
    String token;
    String organizationId;

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
        String teacherDetails = RBSDataSetup.getMyTeacher( school );
        username = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME );
        teacherID = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        token = new RBSUtils().getAccessToken( SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERNAME ), RBSDataSetupConstants.DEFAULT_PASSWORD );
        organizationId = RBSDataSetup.organizationIDs.get( school );

    }

    @Test ( description = "Verify Group listing page", priority = 1 )
    public void tcSMBVT011() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "tcSMBVT011: Verify Group listing page <small><b><i>[" + browser + "]</b></i></small>" );

        try {
        	GroupAPI group= new GroupAPI();
        	HashMap<String, String> apiDetails = new HashMap<>();
			apiDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
			apiDetails.put( GroupConstants.GROUP_OWNER_ORG_ID, organizationId );
			apiDetails.put( GroupConstants.STAFF_ID, teacherID );
			HashMap<String, String> response =group.getGroupListingForTeacherID( smUrl, apiDetails );
			System.out.println(response);
			List<String> groupId1 = SMUtils.getAllKeyValueFromJsonArray( response.get( Constants.REPORT_BODY ), "groupName" );
		
        	LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
		
            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            Log.assertThat( groupsTab.verifyGroupHeaders(), "Verified Headers successfully!", "Headers not displayed properly" );
        
            List<String> groupsFromUI = groupsTab.getGroupNamesFromGroupsTab();
            System.out.println(groupsFromUI);     
            System.out.println(groupId1); 
            Log.assertThat(SMUtils.sortList (groupsFromUI).equals(SMUtils.sortList( groupId1) ), "Groups listed correctly!", "Group is not listed properly" );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify create new group", priority = 2 )
    public void tcSMBVT012( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	String student1 =RBSDataSetup.teacherStudentMap.get( username ).get( "Student1" );
        String student2 =RBSDataSetup.teacherStudentMap.get( username ).get( "Student2" );
        String groupName = "Smoke_Automation_" + System.nanoTime();
        System.out.println(groupName);
		String stuUserName1 = SMUtils.getKeyValueFromResponse(student1, "userName");
		String stuUserName2 = SMUtils.getKeyValueFromResponse(student2, "userName");

        context.setAttribute( "groupName", groupName );
        context.setAttribute( "Student1", SMUtils.getKeyValueFromResponse( student1, "userName" ) );
        context.setAttribute( "Student2", SMUtils.getKeyValueFromResponse( student2, "userName" ) );

        Log.testCaseInfo( "tcSMBVT012: Verify create new group <small><b><i>[" + browser + "]</b></i></small>" );

        try {
        	LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            // Create group with school students
            groupsTab.createGroupWithoutStudent( groupName );
            groupsTab.viewGroup( groupName );
            // Click add student to group button
            groupsTab.clickAddStudentToGrpBtnGrpPage();
            groupsTab.addNameInTextField( stuUserName1 );
            SMUtils.waitForSpinnertoDisapper( driver );
            try {
                groupsTab.clickAddButton();
            }
            catch(StaleElementReferenceException e) {
            	Log.exception(e , driver);
                groupsTab.clickAddButton();
            }
      
            SMUtils.nap(5);
            groupsTab.addNameInTextField(stuUserName2 );
            SMUtils.waitForSpinnertoDisapper( driver );
            try {
                groupsTab.clickAddButton();
            }
            catch(StaleElementReferenceException e) {
            	Log.exception(e , driver);
                groupsTab.clickAddButton();
            }
            SMUtils.waitForSpinnertoDisapper( driver );
            groupsTab.clickSaveBtnAddStudToGrpPopUp();
            SMUtils.nap(10);

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify View Group", priority = 3 )
    public void tcSMBVT013( ITestContext context ) throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);

    	String groupName = context.getAttribute( "groupName" ).toString();
        String student1 =RBSDataSetup.teacherStudentMap.get( username ).get( "Student1" );
        String student2 =RBSDataSetup.teacherStudentMap.get( username ).get( "Student2" );
        String stuUserName1 = SMUtils.getKeyValueFromResponse(student1, "userName");
        String stuUserName2 = SMUtils.getKeyValueFromResponse(student2, "userName");

        Log.testCaseInfo( "tcSMBVT013: Verify View Group <small><b><i>[" + browser + "]</b></i></small>" );
        

        try {
        	LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

            // Navigate to Groups Tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
            // Verify the groupName present
            groupsTab.viewGroup( groupName );
            System.out.println(groupName);
            SMUtils.nap( 5 );
            HashMap<String, HashMap<String, String>> studentDetails = groupsTab.getStudentDetailsBasedOnGroup( groupName );
            List<String> studentList = new ArrayList<String>();
            List<String> studentListFromUI = new ArrayList<String>();
            studentList.add( context.getAttribute( "Student1" ).toString() );
            studentList.add( context.getAttribute( "Student2" ).toString() );
            studentListFromUI.add(stuUserName1);
            studentListFromUI.add(stuUserName2);
            System.out.println(studentList);
            System.out.println(studentListFromUI);

            Log.assertThat( SMUtils.sortList( studentList ).equals( SMUtils.sortList( studentListFromUI ) ), "Displayed the student Correctly!", "Displayed the student inCorrectly!", driver );
            String newGroupName = groupName + "_updated";
            groupsTab.editGroup( newGroupName );
            Log.assertThat( groupsTab.getZeroStateAssignmentMessage().contentEquals( Constants.groupAssignmentZeroPage ), "Zero state page displayed", "Zero state page not displayed" );
            groupsTab.deleteGroup( newGroupName );

            // SignOut from SM
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
