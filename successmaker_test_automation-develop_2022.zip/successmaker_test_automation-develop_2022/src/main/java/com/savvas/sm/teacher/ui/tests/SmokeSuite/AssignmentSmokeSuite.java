package com.savvas.sm.teacher.ui.tests.SmokeSuite;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EditAssignmentSettingsPopUp;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

import LSTFAI.customfactories.EventFiringWebDriver;

public class AssignmentSmokeSuite {

	private static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	private String smUrl;
	private String browser;
	private String username = null;
	private String password = null;
	String staticCourseName = null;
	List<String> studentDetails;
	private static String teacherDetails;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	List<String> studentRumbaIds = new ArrayList<>();
	String customSettingCourseMath;
	String courseName;
	String studentFirstName;
	String studentMiddleName = null;
	String studentLastName;
	String Custom_Skills_Math = Constants.CUSTOM_BY_SKILLS_MATH_COURSE + System.nanoTime();
	List<String> studentUserNames = null;
	List<String> studentIdList = null;
	private String teacherId;
	List<String> studentID;

	private String studentDetailsOne;
	private String studentDetailsTwo;
	private String studentDetailsThree;

	private String studentUN;
	private String studentUN_Two;
	private String studentUN_Three;

	String Custom_Settings_Math = Constants.CUSTOM_MATH_ASSIGMENT_TITLE + System.nanoTime();

	@BeforeClass
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		teacherId = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID);
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;

		studentDetailsOne = RBSDataSetup.getMyStudent(school, username);
		studentDetailsTwo = RBSDataSetup.getMyStudent(school, username);
		studentDetailsThree = RBSDataSetup.getMyStudent(school, username);

		studentUN = SMUtils.getKeyValueFromResponse(studentDetailsOne, "userName");
		studentUN_Two = SMUtils.getKeyValueFromResponse(studentDetailsTwo, "userName");
		studentUN_Three = SMUtils.getKeyValueFromResponse(studentDetailsThree, "userName");

	}

	@Test(description = "Verify view and edit assignment settings at student level", groups = { "smoke_test_case",
			"teacher_assignment", "P1" }, priority = 1)
	public void Teacher_TC23() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data

		Log.testCaseInfo("Teacher_TC23: Verify view and edit assignment settings at student level <small><b><i>["
				+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Get Student Page
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();

			// Create New Student
			List<String> studentUserNames = new ArrayList<>();
			String studentID = studentsPage.createStudent();
			studentsPage.closePopup();
			studentUserNames.add(studentID);
			SMUtils.nap(60);

			// Add Studnet to Group
			GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();
			Log.assertThat(groupsTab.verifyGroupHeaders(), "Verified Headers successfully!",
					"Headers not displayed properly");
			groupsTab.viewGroup("Successmaker Group 1");
			groupsTab.clickGroupsSubNav(Constants.USERS);
			SMUtils.waitForElement(driver, groupsTab.userTabHeader);
			SMUtils.nap(60);
			// Click on the add students to group button
			groupsTab.clickAddStudentToGroup();
			groupsTab.addStudGroupWithHomeRoomStudents("Successmaker Group 1", studentUserNames);
			groupsTab.clickOnAddStudentsBtn();

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.clickViewAssignment();
			AssignAssignmentPopup assigAssignmentPopup = assignmentDetailsPage.clickAssignButton();
			assigAssignmentPopup.assignMultipleStudentsToCourse();
			String firstStudentsName = assigAssignmentPopup.getFirstStudentsName();
			Log.message("firstStudentsName: " + firstStudentsName);

			assignmentDetailsPage.selectValueFromDropDownSessionLength(Constants.SESSION_LENGHT_SELECTED);
			Log.message("Session Length selected : " + Constants.SESSION_LENGHT_SELECTED);
			assigAssignmentPopup.clickAssignButtonOnPopup();
			Log.message("Successfully Assigned Multiple Students To Course");

			assignmentDetailsPage.clickAssignmentSettingsOfStudent(firstStudentsName);
			EditAssignmentSettingsPopUp editAssignmentSettingsPopUp = new EditAssignmentSettingsPopUp(driver);

			SMUtils.nap(5);
			String sessionLength = editAssignmentSettingsPopUp.getSessionLength();
			System.out.println("Session length is : " + sessionLength);
			Log.assertThat(sessionLength.equalsIgnoreCase(Constants.SESSION_LENGHT_SELECTED),
					"Session Length showed correct", "Session Length showed Incorrect");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Pause / Resume assignment", groups = { "smoke_test_case" }, priority = 1)
	public void Teacher_TC24() throws Throwable {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data

		Log.testCaseInfo(
				"Teacher_TC24: Verify Pause / Resume assignment<small><b><i>[" + browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to CourseWare Tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();

			// Click on ViewAssignments
			AssignmentDetailsPage assignmentDetailsPage = page.clickViewAssignment();

			// Click on Dot ellipsis
			assignmentDetailsPage.clickDotEllipsisButton();

			// Click on Pause Assignment
			assignmentDetailsPage.pauseAssignmentForStudentTab();

			// Click On Pause Button
			assignmentDetailsPage.clickPauseButtononPopUpPage();

			Log.assertThat(assignmentDetailsPage.isAssignmentPaused(), "Assignment paused successfully",
					"Assignment has not Paused");

			// Click Dot ellipsis
			assignmentDetailsPage.clickDotEllipsisButton();

			// Click Resume Element
			assignmentDetailsPage.resumeAssignment();

			// CLick Resume button
			assignmentDetailsPage.clickResumeButtononPopUpPage();

			Log.assertThat(!assignmentDetailsPage.isStudentPaused(), "Assignment has Resumed successfully",
					"Assignment has Paused not resumed");

			// Click on Pause Assignment Level Student
			assignmentDetailsPage.pauseAllStudent();

			// CLick Pause button at assignment level

			assignmentDetailsPage.pauseButtonFoAllSTudent();

			// Verify the assignment got pause

			Log.assertThat(assignmentDetailsPage.isAssignmentPausedatAssignmentLevel(),
					"Assignment paused for all successfully", "Assignment has not Paused");

			// Resume all Assignment
			// Click All Resume Tab
			assignmentDetailsPage.resumeAllAssignment();

			// CLick Resume all assignment
			assignmentDetailsPage.resumeButtonFoAllSTudent();

			// Verify the Pauses After Resume all
			Log.assertThat(!assignmentDetailsPage.isStudentPaused(),
					"Assignment resumed at asignment level for all successfully",
					"Assignment Paused for all successfully");

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {

			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Completed Status when the assignment is completed", groups = {
			"smoke_test_case" }, priority = 1)
	public void Teacher_TC42() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("Teacher_TC42: Verify the Completed Status when the assignment is completed <small><b><i>["
				+ browser + "]</b></i></small>");

		try {

			String staticCourseName;

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);

			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(Boolean.TRUE.equals(courseWidgetDisplayed), "Course widget is diplayed",
					"Course widget is not diplayed");

			CoursesPage courses = new CoursesPage(driver);

			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			List<String> studentListFromTheAssignmentPopup = new ArrayList<>();
			staticCourseName = courses.generateRandomCourseName();

			// Get CourseLising Page
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Make a copy of the course
			courses.copyOfCourse(staticCourseName, Constants.SKILLS, Constants.MATH);

			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			courseListingPage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			courseListingPage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Click on the course
			courses.clickFromCourseListingPage(staticCourseName);
			courses.clickAssignBtn();

			// Get the count of the student from the assignment pop up
			studentListFromTheAssignmentPopup = courses.getAllStudentNameFromAssignPopUp();

			// Assign the course to the student
			courses.addCourseToMultipleStudents();
			courses.clickAssignButton();

			// Traverse to the assignment
			courses.clickAssignmentSubMenu();

			tHomePage.topNavBar.signOutfromSM();

			// Login as Student
			// Get driver
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);
			try {
				LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN,
						password);
				SMUtils.nap(30);
				SMUtils.waitForSpinnertoDisapper(studentDriver);
				StudentDashboardPage studentsPage = new StudentDashboardPage(studentDriver);

				studentsPage.executeMathCourse(username, staticCourseName, "100", "15", "30");
				studentsPage.logout();
			} catch (Exception e) {
				Log.exception(e, studentDriver);
			} finally {
				studentDriver.quit();
				Log.endTestCase();
			}

			// Get driver
			driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);
			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			// Navigate to CourseWare Tab
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Click on Assignment SubMenu
			assignmentDetailsPage = page.viewAssignmentDetailsByAssignmentName(staticCourseName);

			// Verify the Completed Status
			Log.assertThat(assignmentDetailsPage.checkCompletedTag(),
					"Assignment Completed Status Displays Successfully", "Assignment Completed Status Not Displays");

			Log.testCaseResult();
		} catch (Exception e) {
			Log.exception(e);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify if teacher is able to see Student's progress monitoring graph only for Default courseware(Math/Reading) and Custom by Setting course", groups = {
			"smoke_test_case" }, priority = 1)
	public void Teacher_TC53() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data
		Log.testCaseInfo(
				"Teacher_TC53: Verify if teacher is able to see Student's progress monitoring graph only for Default courseware(Math/Reading) and Custom by Setting course<small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// create Reading custom course by settings
			coursePage.createCustomBySettingCourseWithIPOff(Custom_Settings_Math, Constants.MATH);

			// Assigning Course to student
			tHomePage.topNavBar.navigateToCourseListingPage();
			coursePage.clickCourseName(Custom_Settings_Math);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			// SignOut
			tHomePage.topNavBar.signOutfromSM();

			// Get driver
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);
			try {
				LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN,
						password);
				SMUtils.nap(30);
				SMUtils.waitForSpinnertoDisapper(studentDriver);
				StudentDashboardPage stuPage = new StudentDashboardPage(studentDriver);

				stuPage.executeMathCourse(teacherId, Custom_Settings_Math, "95", "5", "30");
				stuPage.logout();

			} catch (IOException e) {
				Log.message("Error occurred while running the simulator");
			} finally {
				studentDriver.quit();
				Log.endTestCase();
			}

			// Navigate to teacher page again
			driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");
			// Navigate to Courseware tab
			SMUtils.nap(10);
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Custom_Settings_Math);

			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			String studentName = assignmentDetailsPage.getStudentName(
					SMUtils.getKeyValueFromResponse(studentDetailsOne, "firstName"),
					SMUtils.getKeyValueFromResponse(studentDetailsOne, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetailsOne, "lastName"));

			assignmentDetailsPage.clickStudentAccordionButton(studentName);
			Log.assertThat(assignmentDetailsPage.isProgressMonitoringGraphDisplayed(),
					"Progress Monitoring Graph Displayed Successfuly", "Progress Monitoring Graph Not Displayed");

			// Sign Out
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the IP Level, Current Level and Session pop up data", groups = {
			"smoke_test_case" }, priority = 1)
	public void Teacher_TC54() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data
		Log.testCaseInfo("Teacher_TC54: Verify the IP Level, Current Level and Session pop up data <small><b><i>["
				+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			// Assigning Course to student
			coursePage.clickCourseName(Constants.MATH);
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
			// SignOut
			tHomePage.topNavBar.signOutfromSM();

			// Get driver
			EventFiringWebDriver studentDriver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);
			try {
				LoginWrapper.loginToSuccessMakerAsStudent(studentDriver, smUrl, UserType.BASIC, null, studentUN,
						password);
				SMUtils.nap(30);
				SMUtils.waitForSpinnertoDisapper(studentDriver);
				StudentDashboardPage stuPage = new StudentDashboardPage(studentDriver);

				stuPage.executeMathCourse(teacherId, Constants.MATH, "100", "5", "30");
				stuPage.logout();

			} catch (IOException e) {
				Log.message("Error occurred while running the simulator");
			} finally {
				studentDriver.quit();
				Log.endTestCase();
			}

			// Navigate to teacher page again
			driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");
			// Navigate to Courseware tab
			SMUtils.nap(10);
			AssignmentsPage page = tHomePage.topNavBar.navigateToAssignmentsPage();
			// Click on Assignment SubMenu
			page.clickAssignmentSubMenu();
			// Click on ViewAssignments
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickOnTheHoveredAssignment(Constants.MATH);
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);
			String studentName = assignmentDetailsPage.getStudentName(
					SMUtils.getKeyValueFromResponse(studentDetailsOne, "firstName"),
					SMUtils.getKeyValueFromResponse(studentDetailsOne, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetailsOne, "lastName"));
			assignmentDetailsPage.clickStudentAccordionButton(studentName);

			Log.assertThat(assignmentDetailsPage.isProgressMonitoringGraphDisplayed(),
					"Progress Monitoring Graph Displayed Successfuly", "Progress Monitoring Graph Not Displayed");

			// Sign Out
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the last session option is avaiable for the Assignment listing - skill Tested", groups = {
			"smoke_test_case" }, priority = 2)
	public void Teacher_TC37() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		// Get Test Data
		Log.testCaseInfo(
				"Teacher_TC37: Verify the last session option is avaiable for the Assignment listing - skill Tested <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			String studentLastName = SMUtils.getKeyValueFromResponse(studentDetailsOne, "lastName");
			String studentMiddleName = SMUtils.getKeyValueFromResponse(studentDetailsOne, "middleName");
			String studentFirstName = SMUtils.getKeyValueFromResponse(studentDetailsOne, "firstName");

			AssignmentsPage assignmentPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage assignmentDetailsPage = assignmentPage.viewAssignmentDetailsByAssignmentName("Math");

			assignmentDetailsPage.clicktoggleButtonForStudent(studentFirstName, studentMiddleName, studentLastName);

			SMUtils.logDescriptionTC("Validate the functionality of Expand (+) icon screen");
			Log.assertThat(assignmentDetailsPage.isSkillTestedExpanded(),
					"Skill tested expanded for the student successfully!", "Issue in expanding skill tested dropdown");

			SMUtils.logDescriptionTC("Validate the Skills Tested Label in the Expanded Skills Tested");
			Log.assertThat(assignmentDetailsPage.getSkillTestedHeader().equals(Constants.SKILL_TESTED_HEADER),
					"Skill tested header displayed for the student successfully!",
					"Skill tested header not displayed!");

			// Sign Out
			tHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Assign from Homepage", groups = { "smoke_test_case", "teacher_assignment",
			"Teacher_TC03", "P1" }, priority = 2)
	public void verifyAssignfromHomepage() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tcSMBVT002: Verify that clicking on Assign button user navigated to Assign course window. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			// Navigating to course page
			CoursesPage courseListingPage = teacherHomePage.navigateToCourseListingPage();
			courseName = courseListingPage.generateRandomCourseName();
			CourseListingPage coursePage = teacherHomePage.topNavBar.getCourseListingPage();
			coursePage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			courseListingPage.copyOfCourse(courseName, Constants.SETTINGS, Constants.MATH);
			teacherHomePage.navigateToCourseListingPage();
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(3);

			coursePage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);
			courseListingPage.clickFromCourseListingPage(courseName);

			// Assigning the assignment to students
			teacherHomePage.navigateToCourseListingPage();
			coursePage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);
			courseListingPage.clickCourseFromTheListing(courseName);
			courseListingPage.clickAssignBtn();
			courseListingPage.addCourseToStudents();

			// Sign out
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify add student to Assignment", groups = { "smoke_test_case", "teacher_assignment",
			"Teacher_TC08", "P1" }, priority = 3)
	public void verifyTeacherAbleToAddStudent() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentsPage_005:SMK-9396 and SMK-9400- Verify teacher can refine the list further by entering search criteria."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);
			CoursesPage coursepage = new CoursesPage(driver);
			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
			Map<String, List<String>> studentDetailsFromStudentTab = studentsPage.getColumnDetailsAsList();
			List<String> studenListFromStudentTab = new ArrayList<>();
			for (int studentValue = 0; studentValue < studentDetailsFromStudentTab.get(Constants.FIRSTNAME)
					.size(); studentValue++) {
				String studentFN = studentDetailsFromStudentTab.get(Constants.FIRSTNAME).get(studentValue);
				String studentLN = studentDetailsFromStudentTab.get(Constants.LASTNAME).get(studentValue);
				studenListFromStudentTab.add(coursepage.completeStudentName(studentFN, "", studentLN));
			}
			String[] FNLN = studenListFromStudentTab.get(0).split(" ");
			String studentFNLN = FNLN[0].concat(FNLN[1]);

			CoursesPage courseListingPage = teacherHomePage.navigateToCourseListingPage();
			courseName = courseListingPage.generateRandomCourseName();
			CourseListingPage coursePage = teacherHomePage.topNavBar.getCourseListingPage();
			coursePage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			courseListingPage.copyOfCourse(courseName, Constants.SETTINGS, Constants.MATH);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(3);

			teacherHomePage.navigateToGroupsMenu();
			teacherHomePage.navigateToCourseListingPage();
			coursePage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);
			courseListingPage.clickFromCourseListingPage(courseName);

			// Assigning the assignment to students
			courseListingPage.clickAssignBtn();
			courseListingPage.addCourseToOneStudent(studentFNLN);
			SMUtils.nap(3);

			StudentsPage navigateToStudentTab = teacherHomePage.navigateToStudentTab();
			navigateToStudentTab.selectAllStudents();
			navigateToStudentTab.addStudentstoAssignment(courseName);

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify Assignment Listing", groups = { "smoke_test_case", "teacher_assignment", "Teacher_TC20",
			"P1" }, priority = 4)
	public void verifyAssignmentListingPage() throws Exception {
//		 Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tcSMBVT002: Verify that clicking on Assign button user navigated to Assign course window. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			// Navigate to 'Assignments' page
			AssignmentsPage assignmentsPage = teacherHomePage.topNavBar.navigateToAssignmentsPage();

			SMUtils.logDescriptionTC("SMK-9450- Verify the 'Assignment Details' page displays with all the students");
			// Clicking on 'view Assignments' button
			assignmentsPage.viewAssignmentDetailsByAssignmentName(Constants.MATH);

			// Sign out
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify Assignment Details Page", groups = { "smoke_test_case", "teacher_assignment",
			"Teacher_TC21", "P5" }, priority = 4)
	public void tcSMBVT021() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		// Get Test Data

		Log.testCaseInfo("Verify Assignment Details Page <small><b><i>[" + browser + "]</b></i></small>");

		try {
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.clickViewAssignment();
			Log.assertThat(
					(assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage()
							.contains(Constants.ACTIVE_STUDENTS_ASSIGMENT_SUBTITILE)
							&& assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage()
									.contains(Constants.PAUSED_STUDENTS_ASSIGMENT_SUBTITILE)),
					"Assignment SubTitle is displayed", "Assignment SubTitle is not displayed");

			Log.assertThat(assignmentDetailsPage.assignElement().isDisplayed(), "Assign button is displayed",
					"Assign button is not displayed");

			assignmentDetailsPage.assignmentLevelEllipsisClicked();

			Log.assertThat(assignmentDetailsPage.assignmentSettingTabTopEllipsis().equals(Constants.ASSIGMENT_SETTINGS),
					"Assignment Settings Tab is displayed", "Assignment Settings Tab is not displayed");
			Log.assertThat(assignmentDetailsPage.pauseAllStudentTopEllipsis().equals(Constants.PAUSED_ALL_STUDENTS),
					"Pause All Student is displayed", "Pause All Student is not displayed");
			Log.assertThat(assignmentDetailsPage.deleteAssignmenttabTopEllipsis().equals(Constants.DELETED_ASSIGNMENT),
					"Delete Assignment Tab is displayed", "Delete Assignment Tab is not displayed");

			Log.assertThat(assignmentDetailsPage.getColumnName().trim().equals(Constants.NAME),
					"NAME Column is displayed in the Assignment_Details_Page",
					"NAME Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnLastSession().trim().equals(Constants.LAST_SESSION),
					"LAST_SESSION Column is displayed in the Assignment_Details_Page",
					"LAST_SESSION Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnIPLevel().trim().equals(Constants.IP_LEVEL),
					"IP_LEVEL Column is displayed in the Assignment_Details_Page",
					"IP_LEVEL Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnAssignedLevel().trim().equals(Constants.ASSIGNED_LEVEL),
					"ASSIGNED_LEVEL Column is displayed in the Assignment_Details_Page",
					"ASSIGNED_LEVEL Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnCurrentLevel().trim().equals(Constants.CURRENT_LEVEL),
					"CURRENT_LEVEL Column is displayed in the Assignment_Details_Page",
					"CURRENT_LEVEL Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnGain().trim().equals(Constants.GAIN),
					"GAIN Column is displayed in the Assignment_Details_Page",
					"GAIN Column is not displayed in the Assignment_Details_Page");

			assignmentDetailsPage.clickDotEllipsisButton();

			Log.assertThat(assignmentDetailsPage.assignmentSettingInEllipsis().equals(Constants.ASSIGMENT_SETTINGS),
					"Assignment Settings Tab is displayed", "Assignment Settings Tab is not displayed");
			Log.assertThat(
					assignmentDetailsPage.pauseAssignmentForStudentTabInEllipsis().equals(
							Constants.PAUSE_ASSIGNMENT_FOR_STUDENTS),
					"Pause Assignment For Student Tab is displayed",
					"Pause Assignment For Student Tab is not displayed");
			Log.assertThat(assignmentDetailsPage.removeStudentTabInEllipsis().equals(Constants.REMOVE_STUDENTS),
					"Remove Student Tab is displayed", "Remove Student Tab is not displayed");
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify add student to Assignment From Student tab", groups = { "smoke_test_case",
			"teacher_assignment", "Teacher_TC26", "P1" }, priority = 5)
	public void verifyTeacherAbleToAddSameStudent() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentsPage_005:SMK-9396 and SMK-9400- Verify teacher can refine the list further by entering search criteria."
						+ Constants.HTML_BEGINING_TAG_FOR_REPORT + browser + Constants.HTML_ENDING_TAG_FOR_REPORT);

		try {
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage teacherHomePage = new TeacherHomePage(driver);

			CoursesPage coursepage = new CoursesPage(driver);
			boolean courseWidgetDisplayed = teacherHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			StudentsPage studentsPage = teacherHomePage.topNavBar.navigateToStudentsTab();
			Map<String, List<String>> studentDetailsFromStudentTab = studentsPage.getColumnDetailsAsList();
			List<String> studenListFromStudentTab = new ArrayList<>();
			for (int studentValue = 0; studentValue < studentDetailsFromStudentTab.get(Constants.FIRSTNAME)
					.size(); studentValue++) {
				String studentFN = studentDetailsFromStudentTab.get(Constants.FIRSTNAME).get(studentValue);
				String studentLN = studentDetailsFromStudentTab.get(Constants.LASTNAME).get(studentValue);

				studenListFromStudentTab.add(coursepage.completeStudentName(studentFN, "", studentLN));

			}
			String[] FNLN = studenListFromStudentTab.get(0).split(" ");
			String studentFNLN = FNLN[0].concat(FNLN[1]);

			CoursesPage courseListingPage = teacherHomePage.navigateToCourseListingPage();
			courseName = courseListingPage.generateRandomCourseName();
			CourseListingPage coursePage = teacherHomePage.topNavBar.getCourseListingPage();
			coursePage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			courseListingPage.copyOfCourse(courseName, Constants.SETTINGS, Constants.MATH);
			SMUtils.waitForSpinnertoDisapper(driver);
			SMUtils.nap(3);

			teacherHomePage.navigateToGroupsMenu();
			teacherHomePage.navigateToCourseListingPage();
			coursePage.selectCourseTypeFromDropDown(Constants.MY_CUSTOM_COURSES);
			courseListingPage.clickFromCourseListingPage(courseName);

			// Assigning the assignment to students
			courseListingPage.clickAssignBtn();
			courseListingPage.addCourseToOneStudent(studentFNLN);
			SMUtils.nap(3);

			StudentsPage navigateToStudentTab = teacherHomePage.navigateToStudentTab();

			ArrayList<String> allStudentsUserNames = navigateToStudentTab.getAllStudentsUserNames();
			navigateToStudentTab.selectStudentByUsername(allStudentsUserNames.get(0));
			navigateToStudentTab.addStudentstoAssignment(courseName);

			// closing the add assignment to students popup
			navigateToStudentTab.closePopup();

			navigateToStudentTab.selectStudentByUsername(allStudentsUserNames.get(0));

			// Selecting all the students in the student tab
			navigateToStudentTab.selectAllStudents();

			// Assigning the course to all the students
			navigateToStudentTab.addStudentstoAssignment(courseName);

			// SignOut from SM
			teacherHomePage.topNavBar.signOutfromSM();
			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}

	}

	@Test(description = "Verify Student Tab", enabled = true, priority = 4, groups = { "smoke_test_case", "Assignments",
			"Teacher_TC01", "P1" })
	public void tc_Assignments001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_Assignments001: Verify Student Tab. <small><b><i>[" + browser + "]</b></i></small>");
		try {
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			CoursesPage coursepage = new CoursesPage(driver);
			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			// Navigating to the student tab
			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
			Log.assertThat(studentsPage.addStudentElement().isDisplayed(), "Add student button is displayed",
					"Add student button is not displayed");

			Log.assertThat(!studentsPage.groupAssignmentIsEnable(), "Group & Assignment button is disabled",
					"Group & Assignment button is Enabled");
			SMUtils.nap(5);
			studentsPage.selectStudentByUsername(studentUN);
			SMUtils.nap(5);
			Log.assertThat(studentsPage.groupAssignmentIsEnable(), "Group & Assignment button is enabled",
					"Group & Assignment button is disabled");

			List<String> textOfEllipsesOptions = studentsPage.getTextOfEllipsesOptions(studentUN);
			Log.assertThat(textOfEllipsesOptions.equals(Constants.Students.ELLIPSES_OPTIONS),
					"Ellipses options is present", "Ellipses options is not present");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Remove student in view assignmnet details page", enabled = true, priority = 4, groups = {
			"smoke_test_case", "Assignments", "Teacher_TC02", "P1" })
	public void tc_Assignments002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo("tc_Assignments002: Remove student in view assignmnet details page. <small><b><i>[" + browser
				+ "]</b></i></small>");
		try {

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			CoursesPage coursepage = tHomePage.topNavBar.navigateToCourseListingPage();
			Log.message("page landed");
			coursepage.clickCourseName(Constants.SM_FOCUS_READING_GRADE3); // Select Focus course

			// Clicking on 'Assign-Widget' and assigning
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();

			// Navigate 'CourseWare' tab and select the 'Assignments' option
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on View Assignment
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.SM_FOCUS_READING_GRADE3);

			assignmentDetailsPage.removeStudentTab();
			Log.assertThat(assignmentDetailsPage.checkCancelbuttonremoveStudent(), "Remove Student option is clickable",
					"Remove Student option is not clickable");

			assignmentDetailsPage.removeStudentFromCourse();
			Log.assertThat(!assignmentDetailsPage.checkRemoveStudent(), "Student removed successfully",
					"Student not removed successfully");

			String getactivePausedText = assignmentDetailsPage.getactivePausedText();
			Log.message(getactivePausedText);

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify assignment details page", enabled = true, priority = 4, groups = { "smoke_test_case",
			"Assignments", "Teacher_TC03", "P1" })
	public void tc_Assignments003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_Assignments003: Verify assignment details page.<small><b><i>[" + browser + "]</b></i></small>");
		try {
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage.clickViewAssignment();

			Log.assertThat(
					(assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage()
							.contains(Constants.ACTIVE_STUDENTS_ASSIGMENT_SUBTITILE)
							&& assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage()
									.contains(Constants.PAUSED_STUDENTS_ASSIGMENT_SUBTITILE)),
					"Assignment SubTitle is displayed", "Assignment SubTitle is not displayed");

			Log.assertThat(assignmentDetailsPage.assignElement().isDisplayed(), "Assign button is displayed",
					"Assign button is not displayed");

			Log.assertThat(assignmentDetailsPage.getColumnName().trim().equals(Constants.NAME),
					"NAME Column is displayed in the Assignment_Details_Page",
					"NAME Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnLastSession().trim().equals(Constants.LAST_SESSION),
					"LAST_SESSION Column is displayed in the Assignment_Details_Page",
					"LAST_SESSION Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnIPLevel().trim().equals(Constants.IP_LEVEL),
					"IP_LEVEL Column is displayed in the Assignment_Details_Page",
					"IP_LEVEL Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnAssignedLevel().trim().equals(Constants.ASSIGNED_LEVEL),
					"ASSIGNED_LEVEL Column is displayed in the Assignment_Details_Page",
					"ASSIGNED_LEVEL Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnCurrentLevel().trim().equals(Constants.CURRENT_LEVEL),
					"CURRENT_LEVEL Column is displayed in the Assignment_Details_Page",
					"CURRENT_LEVEL Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnGain().trim().equals(Constants.GAIN),
					"GAIN Column is displayed in the Assignment_Details_Page",
					"GAIN Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnPercentageCorrect().trim().equals(Constants.PERCENT_CORRECT),
					"Percentage Column is displayed in the Assignment_Details_Page",
					"Percentage Column is not displayed in the Assignment_Details_Page");

			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify assign existing assignment", enabled = true, priority = 1, groups = { "smoke_test_case",
			"Assignments", "Teacher_TC04", "P1" })
	public void Tc_Assignments004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get(browser));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_Assignments004: Verify assign existing assignment.<small><b><i>[" + browser + "]</b></i></small>");
		try {

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed");

			CoursesPage coursepage = tHomePage.topNavBar.navigateToCourseListingPage();
			Log.message("page landed");

			StudentsPage studentsPage = tHomePage.topNavBar.navigateToStudentsTab();
			Map<String, List<String>> studentDetailsFromStudentTab = studentsPage.getColumnDetailsAsList();
			List<String> studenListFromStudentTab = new ArrayList<>();
			for (int studentValue = 0; studentValue < studentDetailsFromStudentTab.get(Constants.FIRSTNAME)
					.size(); studentValue++) {
				String studentFN = studentDetailsFromStudentTab.get(Constants.FIRSTNAME).get(studentValue);
				String studentLN = studentDetailsFromStudentTab.get(Constants.LASTNAME).get(studentValue);
				studenListFromStudentTab.add(coursepage.completeStudentName(studentFN, "", studentLN));
			}
			String[] FNLN = studenListFromStudentTab.get(0).split(" ");
			String studentFNLN = FNLN[0].concat(FNLN[1]);

			courseName = coursepage.generateRandomCourseName();
			CourseListingPage coursePage = tHomePage.topNavBar.getCourseListingPage();
			coursePage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			coursepage.copyOfCourse(courseName, Constants.SETTINGS, Constants.MATH);
			SMUtils.waitForSpinnertoDisapper(driver);

			// Get CourseLising Page
			tHomePage.topNavBar.getCourseListingPage();

			// Select Custom Courses from the first drop down
			coursePage.selectCourseTypeFromDropDown(Constants.CUSTOM_COURSES);

			// Sort by date descending
			coursePage.selectsortByDropDown(Constants.CHECK_DATE_DESCENDING_ORDER);

			// Click on the course
			coursepage.clickFromCourseListingPage(courseName);

			// Clicking on 'Assign-Widget' and assigning
			coursepage.clickAssignBtn();
			coursepage.addCourseToOneStudent(studentFNLN);

			// Get Assignments Page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(courseName);
			AssignAssignmentPopup assigAssignmentPopup = assignmentDetailsPage.clickAssignButton();
			assigAssignmentPopup.assignMultipleStudentsToCourse();
			List<String> StudentList = assigAssignmentPopup.getStudentListFromPopUp();
			assignmentDetailsPage.selectValueFromDropDownSessionLength(Constants.SESSION_LENGHT_SELECTED);
			assigAssignmentPopup.clickAssignButtonOnPopup();
			Log.message("Successfully Assigned Multiple Students To Course");
			List<String> ListofStudents = assignmentDetailsPage.getStudentListfromAssignementDetailsTable();
			List<String> studList = new ArrayList<>();

			for (int i = 0; i < ListofStudents.size(); i++) {
				String[] StudentName = ListofStudents.get(i).split(" ");
				String StuName = StudentName[0] + StudentName[2];
				studList.add(StuName);
			}

			System.out.println(studList);
			Log.assertThat(studList.containsAll(StudentList), "Added students are displayed in Assignments Table",
					"Added students are not displayed in Assignments Table");
			Log.testCaseResult();

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}
}
