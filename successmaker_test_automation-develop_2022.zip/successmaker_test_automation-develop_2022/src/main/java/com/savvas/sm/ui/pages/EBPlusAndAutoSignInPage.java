package com.savvas.sm.ui.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.learningservices.utils.Log;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.utils.SMUtils;

/**
 * EBPlus And Auto LoginPage is used for SM teacher, student and admin. District
 * will only appear in Auto login page if it has a supported Pearson
 * integration.
 *
 */

public class EBPlusAndAutoSignInPage extends LoadableComponent<EBPlusAndAutoSignInPage> {

    private final WebDriver driver;
    private boolean isPageLoaded;

    // ******************Input fields in CAT login page ************************

    @FindBy ( id = "containerLogin" )
    WebElement signInContainer;

    @FindBy ( id = "username" )
    WebElement fldUserName;

    @FindBy ( id = "password" )
    WebElement fldPassword;

    @FindBy ( className = "btn-submit" )
    WebElement btnSignIn;

    @FindBy ( css = "p > a[href*='wayf.rumba']" )
    WebElement lnkEBPlusAndAuto;

    /**
     * constructor of the class
     *
     * @param driver
     */
    public EBPlusAndAutoSignInPage( WebDriver driver ) {

        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void isLoaded() {

        if ( !isPageLoaded ) {
            Assert.fail();
        }

        if ( !driver.getCurrentUrl().toLowerCase().contains( "sso" ) ) {
            Log.fail( "EBPlus & Auto Login Page did not open up. Site might be down.", driver );
        }

    }

    @Override
    protected void load() {
        SMUtils.switchWindow( driver );
        isPageLoaded = true;
        SMUtils.fluentWaitForElement( driver, btnSignIn );
    }

    /**
     * Returns the visibility state of Sign in container
     *
     * @return
     */
    public boolean isSignInContainerDisplayed() {
        return signInContainer.isDisplayed();
    }

    // ************* Methods for login to EB page
    /**
     * To enter the user name in user name field on EBPlusAndAutoSignInPage
     *
     * @param userName as string
     * @param screenshot
     */
    public void enterUserName( String userName, boolean screenshot ) {

        SMUtils.fluentWaitForElement( driver, fldUserName );
        fldUserName.clear();
        fldUserName.sendKeys( userName );
        Log.message( "Entered the UserName: '" + userName + "'", driver, screenshot );
    }

    /**
     * To enter the password in password field on EBPlusAndAutoSignInPage
     *
     * @param pwd as string
     * @param screenshot
     */
    public void enterPassword( String pwd, boolean screenshot ) {
        SMUtils.fluentWaitForElement( driver, fldPassword );
        fldPassword.clear();
        fldPassword.sendKeys( pwd );
        Log.message( "Entered the Password: '" + pwd + "'", driver, screenshot );

    }

    /**
     * To click the sign in button on EBPlusAndAutoSignInPage login page
     *
     * @param screenshot
     */
    public void clickSignInButton( boolean screenshot ) {
        SMUtils.fluentWaitForElement( driver, btnSignIn );
        SMUtils.click( driver, btnSignIn );
        Log.message( "Clicked on 'SignIn' button on EB-PlusAndAuto SignIn Page", driver, screenshot );

    }

    /**
     * Sign in the given teacher user to the successmaker application
     *
     * @param username
     * @param password
     * @return
     */
    public TeacherHomePage signInToSuccessMaker( String username, String password ) {
        enterUserName( username, false );
        enterPassword( password, false );
        clickSignInButton( true );

        return new TeacherHomePage( driver ).get();
    }

    /**
     * Sign in the given user to the success maker application for unauthorized
     * validation
     *
     * @param username
     * @param password
     * @return
     */
    public UnauthorizedModal signInToSuccessMakerUnauthorized( String username, String password ) {
        enterUserName( username, false );
        enterPassword( password, false );
        clickSignInButton( true );
        return new UnauthorizedModal( driver ).get();
    }

    /**
     * Sign in the given student user to the successmaker application
     *
     * @param username
     * @param password
     * @return
     */
    public StudentDashboardPage signInToSuccessMakerAsStudent( String username, String password ) {
        enterUserName( username, false );
        enterPassword( password, false );
        clickSignInButton( true );

        return new StudentDashboardPage( driver ).get();
    }

    /**
     * Sign in the given teacher/admin user to the Mastery mfe application
     *
     * @param username
     * @param password
     * @return
     */
    public void signInToMasteryMfe( String username, String password ) {
        enterUserName( username, false );
        enterPassword( password, false );
        clickSignInButton( true );

        // return MasteryMfe
    }

    /**
     * To Click EBPlus And AutoLink on login page
     *
     * @param screenShot
     */
    public EBPlusAndAutoDistrictPage navigateToEBPlusAndAutoLink() {
        Log.event( "Clicking on 'EB Plus and Auto' link" );
        SMUtils.waitForElement( driver, lnkEBPlusAndAuto );
        SMUtils.click( driver, lnkEBPlusAndAuto );
        Log.message( "Clicked on 'EB Plus and Auto' link in Realize login page", driver );

        return new EBPlusAndAutoDistrictPage( driver ).get();
    }
}