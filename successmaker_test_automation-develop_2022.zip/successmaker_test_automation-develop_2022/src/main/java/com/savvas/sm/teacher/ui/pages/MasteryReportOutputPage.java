package com.savvas.sm.teacher.ui.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.utils.SMUtils;

/**
 * This class contains mastery output screen component
 * 
 * @author madhan.nagarathinam
 *
 */

public class MasteryReportOutputPage extends LoadableComponent<MasteryReportOutputPage> {
    final WebDriver driver;
    boolean isPageLoaded;

    @FindBy ( css = "report-viewer-header h2.header" )
    WebElement masteryHeader;

    @FindBy ( css = "h2.assignment-name.ml-3" )
    WebElement studentName;

    @FindBy ( css = "h2.assignment-grade.ml-3" )
    WebElement gradeValue;

    @FindBy ( css = "h2.assignment-group.ml-3" )
    WebElement assignmentName;

    @FindBy ( css = "section.report-sub-header dl.detail-row dd" )
    WebElement rptRunTime;

    @FindBy ( css = "h2.detail-row.ml-3" )
    WebElement reportRunDetails;

    @FindBy ( css = "div.col-3.mastery-right-border dl dt" )
    List<WebElement> assignmentDetailsTable;

    @FindBy ( css = "div.col-3.mastery-right-border dl dd" )
    List<WebElement> assignmentDetailsTableValue;

    @FindBy ( css = "span.list-head" )
    WebElement legend;

    @FindBy ( css = "dl.detail-row.legends dt" )
    List<WebElement> legendTableKey;

    @FindBy ( css = "dl.detail-row.legends dd" )
    List<WebElement> legendTableValue;

    @FindBy ( css = "tr.header > th:nth-child(1)" )
    WebElement skillorstandardtitle;

    @FindBy ( css = "tr.header > th:nth-child(2)" )
    WebElement masterystatustitle;

    @FindBy ( css = "tr.header > th:nth-child(3)" )
    WebElement skillscompletedtitle;

    @FindBy ( css = "tr.header > th:nth-child(4)" )
    WebElement noofattemptstitle;

    @FindBy ( css = "tr.header > th" )
    List<WebElement> masteryDetailsHeader;

    @FindBy ( css = "tr td:nth-of-type(1)" )
    List<WebElement> skillsorstandardcolumn;

    @FindBy ( css = "tr td:nth-of-type(2)" )
    List<WebElement> masterystatuscolumn;

    @FindBy ( css = "tr td:nth-of-type(3)" )
    List<WebElement> skillscompletedcolumn;

    @FindBy ( css = "tr td:nth-of-type(4)" )
    List<WebElement> noofattemptscolumn;

    @FindBy ( css = "div.report-header span.error-message" )
    WebElement paginationerrmsg;

    @FindBy ( css = "div.report-header div.text-field-container input" )
    WebElement paginationinput;

    @FindBy ( css = "cel-button.back-btn" )
    WebElement paginationBackBtn;

    @FindBy ( css = "cel-button.next-btn" )
    WebElement paginationNextBtn;

    /**
     * 
     * Constructor class for Login page Here we initializing the driver for page
     * factory objects.
     * 
     * @param driver
     * @param url
     */
    public MasteryReportOutputPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this );
    }

    @Override
    protected void load() {
        isPageLoaded = true;
        SMUtils.waitForElement( driver, masteryHeader );

    }

    @Override
    protected void isLoaded() throws Error {
        try {
            SMUtils.waitForSpinnertoDisapper( driver, 30 );
        } catch ( InterruptedException e ) {
            Log.message( "Issue in Spinner Loading" );
        }
        if ( SMUtils.waitForElement( driver, masteryHeader, 30 ) ) {
            Log.message( "Mastery Run Report Page loaded successfully." );
        } else {
            Log.fail( "Mastery Run Report Page not loaded successfully." );
        }

    }

    /**
     * Verifing the Mastery Report page
     */
    public boolean isMasteryReportPageLoaded() {
        boolean flag = false;
        if ( SMUtils.isElementPresent( masteryHeader ) ) {
            flag = true;
            Log.message( "Mastery Report OutputPage is loaded Successfully!!" );
        }
        return flag;
    }

    /**
     * To verify the mastery report table titles
     * 
     * @return
     */

    public boolean verifyMasteryHeaderTitles() {
        boolean flag = true;
        Log.message( "Verifying mastery header titles" );

        if ( skillorstandardtitle.getText().trim().equals( Constants.SKILLORSTANDARD_TITLE ) ) {

            Log.pass( "The skillorstandardtitle text matches!" );
        } else {
            Log.fail( "The skillorstandardtitle text is not matching" );
        }

        if ( masterystatustitle.getText().trim().equals( Constants.MASTERYSTATUS_TITLE ) ) {
            Log.pass( "The masterystatustitle text matches!" );
        } else {
            Log.fail( "The masterystatustitle text is not matching" );
        }
        Log.message( skillscompletedtitle.getText().trim() );
        if ( skillscompletedtitle.getText().trim().equals( Constants.SKILLSCOMPLETED_TITLE ) ) {
            Log.pass( "The skills completed title text matches!" );
        } else {
            Log.fail( "The skills completed title text is not matching" );
        }

        if ( noofattemptstitle.getText().trim().equals( Constants.NOOFATTEMPTS_TITLE ) ) {
            Log.pass( "The no of attempts title text matches!" );
        } else {
            Log.fail( "The no of attempts title text is not matching" );
        }

        return flag;
    }

    public List<String> getSkillOrStandardColumn() {
        Log.message( "Getting Mastery Report getSkillOrStandard Column " );
        SMUtils.waitForElement( driver, skillorstandardtitle );
        return skillsorstandardcolumn.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

    }

    public List<String> getMasteryStatusColumn() {
        Log.message( "Getting Mastery Report getMasteryStatus Column" );
        SMUtils.waitForElement( driver, masterystatustitle );
        return masterystatuscolumn.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

    }

    public List<String> getSkillsCompletedColumn() {
        Log.message( "Getting Mastery Report getskillscompleted column " );
        SMUtils.waitForElement( driver, skillscompletedtitle );
        return skillscompletedcolumn.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

    }

    public String getLegendHeading() {
        SMUtils.waitForElement( driver, legend );
        return legend.getText();
    }

    public List<String> getAssignmentsDetailsKey() {
        Log.message( "Getting Keys are displayed " );
        return assignmentDetailsTable.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

    }

    public String getMasteryHeader() {
        SMUtils.waitForElement( driver, masteryHeader );
        return masteryHeader.getText();
    }

    public String getStudentName() {
        SMUtils.waitForElement( driver, studentName );
        return studentName.getText();
    }

    public String getGradeName() {
        SMUtils.waitForElement( driver, gradeValue );
        return gradeValue.getText();
    }

    public String getAssignmentName() {
        SMUtils.waitForElement( driver, assignmentName );
        return assignmentName.getText();

    }

    public String getReportRunTime() {
        SMUtils.waitForElement( driver, rptRunTime );
        return rptRunTime.getText();

    }

    public void clickPaginationBackBtn() {
        SMUtils.waitForElement( driver, paginationBackBtn );
        SMUtils.click( driver, paginationBackBtn );
        SMUtils.nap( 2 );
    }

    public void clickPaginationNextBtn() {
        SMUtils.waitForElement( driver, paginationNextBtn );
        SMUtils.click( driver, paginationNextBtn );
        SMUtils.nap( 2 );
    }

    public List<String> getLegendLabel() {
        List<String> legendKey = new ArrayList<>();
        SMUtils.waitForElement( driver, legend );
        for ( WebElement legKey : legendTableKey ) {
            legendKey.add( legKey.getText().trim() );
        }
        return legendKey;
    }

    public List<String> getLegengLabelValuey() {
        List<String> legendLabValues = new ArrayList<>();
        SMUtils.waitForElement( driver, legend );
        for ( WebElement legValue : legendTableValue ) {
            legendLabValues.add( legValue.getText().trim() );
        }
        return legendLabValues;
    }

    public String getPaginationError() {
        SMUtils.waitForElement( driver, paginationerrmsg );
        return paginationerrmsg.getText();
    }

    public void setPaginationInput( String pagNo ) {
        SMUtils.waitForElement( driver, paginationinput );
        paginationinput.clear();
        paginationinput.sendKeys( pagNo );
        paginationinput.sendKeys( Keys.ENTER );
        SMUtils.nap( 2 );
    }

    public List<String> getNoofAttemptsColumn() {
        Log.message( "Getting Mastery Report getNoofAttempts Column" );
        SMUtils.waitForElement( driver, noofattemptstitle );
        return noofattemptscolumn.stream().map( element -> SMUtils.getTextOfWebElement( element, driver ) ).collect( Collectors.toList() );

    }

}
