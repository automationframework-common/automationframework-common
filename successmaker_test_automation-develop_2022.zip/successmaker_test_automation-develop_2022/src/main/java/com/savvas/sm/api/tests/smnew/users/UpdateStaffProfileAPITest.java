package com.savvas.sm.api.tests.smnew.users;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.getGroupListAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

/**
 * To test the Update Staff Profile API
 * 
 * @author saniya.joseph
 *
 */

public class UpdateStaffProfileAPITest extends UserAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String orgUsed = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    private String org2Used = RBSDataSetup.getSchools( Schools.READING_SCHOOL );
    String orgId;
    String teacherId;
    String staffId;
    String studentId;
    String username;
    String firstName;
    String middleName;
    String lastName;
    String password;
    String email;
    String teacherUsed;
    String teacher2Used;
    String studentUsed;
    String studentUsername;
    String studentFirstName;
    String studentMiddleName;
    String studentLastName;
    String studentPassword;
    String studentEmail;
    String org1TeacherId2;
    String org1TeacherUsername;
    String teacherUsername;
    String teacherDetails;
    String org1TeacherUsername2;
    // other school details
    private String org2Id;

    RBSUtils rbs = new RBSUtils();
    public String stuId;

    @BeforeClass
    public void BeforeTest() {
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        // Teacher used Details
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        teacherUsed = RBSDataSetup.getMyTeacher( orgUsed );
        teacherId = SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERID );
        username = SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME );
        firstName = SMUtils.getKeyValueFromResponse( teacherUsed, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD );
        middleName = SMUtils.getKeyValueFromResponse( teacherUsed, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD );
        lastName = SMUtils.getKeyValueFromResponse( teacherUsed, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD );
        email = SMUtils.getKeyValueFromResponse( teacherUsed, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAIL_ADDRESS_FIELD );

        // Teacher 2 Details
        teacher2Used = RBSDataSetup.getMyTeacher( orgUsed );
        org1TeacherId2 = SMUtils.getKeyValueFromResponse( teacher2Used, RBSDataSetupConstants.USERID );
        org1TeacherUsername2 = SMUtils.getKeyValueFromResponse( teacher2Used, RBSDataSetupConstants.USERNAME );

        // Other School Details
        org2Id = RBSDataSetup.organizationIDs.get( org2Used );

        // Student used Details

        studentUsed = RBSDataSetup.getMyStudent( orgUsed, username );
        studentId = SMUtils.getKeyValueFromResponse( studentUsed, RBSDataSetupConstants.USERID );
        studentUsername = SMUtils.getKeyValueFromResponse( studentUsed, RBSDataSetupConstants.USERNAME );
        studentFirstName = SMUtils.getKeyValueFromResponse( studentUsed, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD );
        studentMiddleName = SMUtils.getKeyValueFromResponse( studentUsed, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD );
        studentLastName = SMUtils.getKeyValueFromResponse( studentUsed, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD );
        studentEmail = SMUtils.getKeyValueFromResponse( studentUsed, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAIL_ADDRESS_FIELD );

    }

    @Test ( dataProvider = "updateStaffProfilePositiveScenariosData", groups = { "SMK-52027", "Users", "Update Staff Profile", "P1", "API" } )
    public void tcUpdateStaffProfile001( String description, String scenario, String statusCode ) throws Exception {

        HashMap<String, String> staffDetails = new HashMap<>();
        teacherUsername = "teacher" + System.nanoTime();
        teacherDetails = createUserWithCustomization( teacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
        staffId = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );
        JSONObject staffJson = new JSONObject( teacherDetails );
        String teacherFirstName = new SMAPIProcessor().getKeyValues( staffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD ).get( 0 );
        String teacherMiddleName = new SMAPIProcessor().getKeyValues( staffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD ).get( 0 );
        String teacherLastName = new SMAPIProcessor().getKeyValues( staffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD ).get( 0 );
        String teacherEmail = new SMAPIProcessor().getKeyValues( staffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD ).get( 0 );

        Log.testCaseInfo( description );
        switch ( scenario ) {

            case "VALID SCENARIO":
                Log.testCaseInfo( "SMK-16708 : Verify the API for the Teacher Profile if I can update the First name and last name" );
                Log.testCaseInfo( "SMK-16700 :Verify API if I update the Teacher profile with New Password" );
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, staffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, staffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, staffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, teacherMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, teacherEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, teacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "CHANGE_PASSWORD_FALSE":
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, staffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, staffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, staffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, teacherMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, teacherEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, teacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.FALSE );
                break;

            case "EMPTY_MIDDLENAME":
                Log.testCaseInfo( "SMK-16730 : Verify the API creating the students when the non-mandatory fields are empty" );
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, staffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, staffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, staffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, teacherFirstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, teacherLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.EMPTY_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, teacherEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, teacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "VALID_EMAIL":

                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, staffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, staffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, staffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, teacherFirstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, teacherLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, teacherMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.SPCL_CHARACTER_USER_EMAIL_ID );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, teacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "DR_TITLE":
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, staffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, staffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, staffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, teacherFirstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, teacherLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, teacherMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, teacherEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, teacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.DR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "MR_TITLE":
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, staffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, staffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, staffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, teacherFirstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, teacherLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, teacherMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, teacherEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, teacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "MRS_TITLE":
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, staffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, staffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, staffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, teacherFirstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, teacherLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, teacherMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, teacherEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, teacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MRS_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "MS_TITLE":
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, staffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, staffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, staffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, teacherFirstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, teacherLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, teacherMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, teacherEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, teacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MS_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "MISS_TITLE":
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, staffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, staffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, staffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, teacherFirstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, teacherLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, teacherMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, teacherEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, teacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MISS_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "MULTI_ORG_TEACHER":
                String multiOrgTeacherUsername = "multi_org_teacher" + System.nanoTime();
                String multiOrgTeacherDetails = createUserWithCustomization( multiOrgTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId, org2Id ) );
                String multiOrgStaffId = SMUtils.getKeyValueFromResponse( multiOrgTeacherDetails, RBSDataSetupConstants.USERID );
                JSONObject multiOrgStaffJson = new JSONObject( multiOrgTeacherDetails );
                String multiOrgStaffFirstName = new SMAPIProcessor().getKeyValues( multiOrgStaffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD ).get( 0 );
                String multiOrgStaffMiddleName = new SMAPIProcessor().getKeyValues( multiOrgStaffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD ).get( 0 );
                String multiOrgStaffLastName = new SMAPIProcessor().getKeyValues( multiOrgStaffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD ).get( 0 );

                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( multiOrgTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, multiOrgStaffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, multiOrgStaffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, multiOrgStaffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, multiOrgStaffFirstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, multiOrgStaffLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, multiOrgStaffMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.SPCL_CHARACTER_USER_EMAIL_ID );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, multiOrgTeacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "SPECIAL_CHARACTERS":
                Log.testCaseInfo( "SMK-16714 : Verify the reponse when the firstname has combination of special characters and alphabets while sending the request ( request body )" );
                Log.testCaseInfo( "SMK-16715 : Verify the response when the lastname has special characters in request body" );

                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, staffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, staffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, staffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.SPCL_CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.SPCL_CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, teacherMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, teacherEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, teacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "SUSPENDED_TEACHER":

                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                new RBSUtils().suspendUser( Arrays.asList( staffId ) );
                staffDetails.put( UserAPIConstants.USERID, staffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, staffId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, staffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, teacherLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, teacherMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, teacherEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, teacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

        }
        HashMap<String, String> putResponse = updateStaffProfile( smUrl, staffDetails );
        Log.message( putResponse.toString() );
        //Schema validation
        Log.assertThat( new SMAPIProcessor().isSchemaValid( UserAPIConstants.UpdateStaffProfileAPIConstants.UPDATE_STAFF_PROFILE_SCHEMA, statusCode, putResponse.get( Constants.REPORT_BODY ) ), "Schema is returned as expected.",
                "Schema is not as expected." );
        VerifyResponseCode( putResponse, CommonAPIConstants.STATUS_CODE_OK );
        VerifyResponseMessage( putResponse, UserAPIConstants.UpdateStaffProfileAPIConstants.SUCCESS_MESSAGE );

        if ( scenario.equalsIgnoreCase( "VALID SCENARIO" ) ) {
            String firstnameUpdatedValue = SMUtils.getKeyValueFromResponse( putResponse.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ), UserAPIConstants.UpdateStaffProfileAPIConstants.FIRSTNAME_DATAVALUE );
            String lastnameUpdatedValue = SMUtils.getKeyValueFromResponse( putResponse.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ), UserAPIConstants.UpdateStaffProfileAPIConstants.LASTNAME_DATAVALUE );
            Log.assertThat( firstnameUpdatedValue.equals( UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING ), "First name is updated correctly!", "First name is not updated correctly!" );
            Log.assertThat( lastnameUpdatedValue.equals( UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING ), "Last name is updated correctly!", "Last name is not updated correctly!" );

        }
        Log.testCaseResult();

    }

    /**
     * Data provider to give the data of positive scenarios
     * 
     * @return
     */
    @DataProvider ( name = "updateStaffProfilePositiveScenariosData" )
    public Object[][] updateStaffProfilePositiveScenariosData() {

        Object[][] inputData = { { "SMK-16716 : Verify the user data is returned correctly when the valid user details given in User Profile API", "VALID SCENARIO", "200" },
                { "SMK-16703 :Verify the API if i update the password with 'changePassword' is set as false", "CHANGE_PASSWORD_FALSE", "200" },
                { "SMK-16704 : Verify API if I can update the Teacher Profile with Middle Name is empty", "EMPTY_MIDDLENAME", "200" }, { "SMK-16705 : Verify the API for the Teacher Profile if I can update the email Id ", "VALID_EMAIL", "200" },
                { "SMK-16720 : Verify the response when the Title as Miss", "MISS_TITLE", "200" }, { "SMK-16719 : Verify the response when the Title as Mrs.", "MRS_TITLE", "200" },
                { "SMK-16722 : Verify the response when the Title as Ms", "MS_TITLE", "200" }, { "SMK-16718 : Verify the response when the Title as Mr in request body", "MR_TITLE", "200" },
                { "SMK-16721 : Verify the response when the Title as Dr", "DR_TITLE", "200" }, { "SMK-16713 : Verify the reponse when the firstname has special characters while sending the request ( Request Body ) ", "SPECIAL_CHARACTERS", "200" },
                { "SMK-16727 : Verify the teacher is suspended", "SUSPENDED_TEACHER", "200" }, { "SMK-16724 : Verify the user updated in given school when the teacher is part of multiple schools.", "MULTI_ORG_TEACHER", "200" } };
        return inputData;
    }

    /**
     * Data provider to give the data of negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "updateStaffProfileNegativeScenariosData" )
    public Object[][] updateStaffProfileNegativeScenariosData() {

        Object[][] inputData = { { "SMK-16710 : Verify the API for the API for the invalid auth", "INVALID TOKEN", "401" }, { "SMK-16709 : Verify the API for the API for the student Auth", "STUDENT AUTHORIZATION", "403" },
                { "SMK-16731 : Verify the API when personId and staff ID is different", "DIFFERENT IDS", "500" }, { "SMK-16706 : Verify the API for the Teacher Profile if I cannot update the email with invalid format", "INVALID_EMAIL", "400" },
                { "SMK-16732 : Verify the API is not updating the user profile when the staff ID given as student ID", "STUDENT_PROFILE", "400" },
                { "SMK-16733 : Verify the API is not updating the user profile when the staff ID as Admin ID", "ADMIN_PROFILE", "400" }, { "SMK-16728 : Verify the teacher is deleted", "DELETED_TEACHER", "400" },
                { "SMK-16707 : Verify the response when the teacher cannot able to update username", "UPDATE_USERNAME", "400" },
                { "SMK-16729 : Verify the API returning exception when the mandatory fields are missing or empty values", "EMPTY_MANDATORY_FIELDS", "400" }

        };
        return inputData;
    }

    @Test ( dataProvider = "updateStaffProfileNegativeScenariosData", groups = { "SMK-52027", "Users", "Update Staff Profile", "P1", "API" } )
    public void tcUpdateStaffProfile002( String description, String scenario, String statusCode ) throws Exception {
        HashMap<String, String> staffDetails = new HashMap<>();

        if ( scenario.equalsIgnoreCase( "INVALID TOKEN" ) ) {
            statusCode = CommonAPIConstants.STATUS_CODE_UNAUTHORIZED;

        } else if ( scenario.equalsIgnoreCase( "STUDENT AUTHORIZATION" ) ) {
            statusCode = CommonAPIConstants.STATUS_CODE_FORBIDDAN;
        } else if ( scenario.equalsIgnoreCase( "INVALID_URL" ) ) {
            statusCode = CommonAPIConstants.STATUS_CODE_NOTFOUND;
        } else if ( scenario.equalsIgnoreCase( "DIFFERENT IDS" ) ) {
            statusCode = CommonAPIConstants.STATUS_CODE_INTERNAL_ERROR;
        } else {
            statusCode = CommonAPIConstants.STATUS_CODE_BAD_REQUEST;

        }
        Log.testCaseInfo( description );
        switch ( scenario ) {

            case "STUDENT AUTHORIZATION":
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( studentUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, studentId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, teacherId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, teacherId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, lastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, middleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, email );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, username );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "INVALID TOKEN":

                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, getGroupListAPIConstants.INVALID_INPUT );
                staffDetails.put( UserAPIConstants.USERID, teacherId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, teacherId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, teacherId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, lastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, middleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, email );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, username );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "STUDENT_PROFILE":
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, teacherId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, studentId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, studentId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, studentLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, studentMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, studentEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, studentUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "ADMIN_PROFILE":
                String adminUsername = "admin" + System.nanoTime();
                String adminDetails = createUserWithCustomization( adminUsername, RBSDataSetupConstants.ADMIN_ROLE, Arrays.asList( orgId ) );
                String adminId = SMUtils.getKeyValueFromResponse( adminDetails, RBSDataSetupConstants.USERID );
                JSONObject staffJson = new JSONObject( adminDetails );
                String adminMiddleName = new SMAPIProcessor().getKeyValues( staffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD ).get( 0 );
                String adminLastName = new SMAPIProcessor().getKeyValues( staffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD ).get( 0 );
                String adminEmail = new SMAPIProcessor().getKeyValues( staffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD ).get( 0 );
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, teacherId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, adminId );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, adminId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, adminLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, adminMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, adminEmail );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, adminUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "DELETED_TEACHER":
                String teacherUsernameNew = "teacher" + System.nanoTime();
                teacherDetails = createUserWithCustomization( teacherUsernameNew, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                String teacherIDNew = SMUtils.getKeyValueFromResponse( teacherDetails, RBSDataSetupConstants.USERID );

                // Deleting user
                new RBSUtils().deleteUser( Arrays.asList( teacherIDNew ) );
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, teacherId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, teacherIDNew );

                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, teacherIDNew );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, lastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, middleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, email );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, username );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "INVALID_EMAIL":

                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, teacherId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, teacherId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, teacherId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, firstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, lastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, middleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, username );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "DIFFERENT IDS":
                String differentTeacherUsername = "teacher" + System.nanoTime();
                String differentTeacherDetails = createUserWithCustomization( differentTeacherUsername, RBSDataSetupConstants.TEACHER_ROLE, Arrays.asList( orgId ) );
                String differentStaffId = SMUtils.getKeyValueFromResponse( differentTeacherDetails, RBSDataSetupConstants.USERID );
                JSONObject differentStaffJson = new JSONObject( differentTeacherDetails );
                String differentStaffFirstName = new SMAPIProcessor().getKeyValues( differentStaffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD ).get( 0 );
                String differentStaffMiddleName = new SMAPIProcessor().getKeyValues( differentStaffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD ).get( 0 );
                String differentStaffLastName = new SMAPIProcessor().getKeyValues( differentStaffJson, UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD ).get( 0 );
                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( differentTeacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, differentStaffId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, differentStaffId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, teacherId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, differentStaffFirstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, differentStaffLastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, differentStaffMiddleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.CHARACTER_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, differentTeacherUsername );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "EMPTY_MANDATORY_FIELDS":

                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, teacherId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, teacherId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, teacherId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, firstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, lastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, middleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, email );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.EMPTY_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

            case "UPDATE_USERNAME":
                Log.testCaseInfo( "SMK-16712 : Verify the response when the user name has only numerical values in request body" );

                staffDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                staffDetails.put( UserAPIConstants.USERID, teacherId );
                staffDetails.put( UserAPIConstants.ORGID, orgId );
                staffDetails.put( UserAPIConstants.STAFFID, teacherId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.PERSONID_FIELD, teacherId );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.FIRSTNAME_FIELD, firstName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.LASTNAME_FIELD, lastName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.MIDDLENAME_FIELD, middleName );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.EMAILID_FIELD, email );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.USERNAME_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NUMERIC_STRING );
                staffDetails.put( UserAPIConstants.GetUserDetailsUsingUserServiceAPIConstants.TITLE_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.MR_TITLE );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.NEW_PASSWORD );
                staffDetails.put( UserAPIConstants.UpdateStaffProfileAPIConstants.CHANGE_PASSWORD_FIELD, UserAPIConstants.UpdateStaffProfileAPIConstants.TRUE );
                break;

        }
        HashMap<String, String> putResponse = updateStaffProfile( smUrl, staffDetails );
        Log.message( putResponse.toString() );
        Log.message( "Response: " + putResponse.get( Constants.REPORT_BODY ) );

        // Validating Response Code, Schema
        VerifyResponseCode( putResponse, statusCode );
        VerifySchema( statusCode, putResponse );

        Log.testCaseResult();

    }

    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        boolean isValid = false;
        try {
            isValid = new SMAPIProcessor().isSchemaValid( UserAPIConstants.UpdateStaffProfileAPIConstants.UPDATE_STAFF_PROFILE_SCHEMA, StatusCode, response.get( GetUserDetailsUsingUserServiceAPIConstants.BODY_FIELD ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
    }

    public void VerifyResponseCode( HashMap<String, String> response, String expectedCode ) {
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( expectedCode ), "Response status code is as expected - " + expectedCode,
                "Response status code is not as expected - Actual " + response.get( Constants.STATUS_CODE ) + " Expected " + expectedCode );
    }

    public void VerifyResponseMessage( HashMap<String, String> response, String expectedMessage ) {
        if ( SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ).contains( expectedMessage ) ) {
            Log.pass( "Message Verified successfully!" );
        } else {
            Log.fail( "Issue in displaying Message! Expected - " + expectedMessage + " Actual - " + SMUtils.getKeyValueFromResponse( response.get( Constants.REPORT_BODY ), "messages,message" ) );
        }

    }

}
