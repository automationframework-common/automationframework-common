package com.savvas.sm.teacher.ui.tests.AssignmentsSuite;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignAssignmentPopup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.AssignmentsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.LoginPage;
import com.savvas.sm.teacher.ui.pages.StudentDashboardPage;
import com.savvas.sm.teacher.ui.pages.StudentsPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.teacher.ui.pages.TopNavBar;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * The JIRA ID of the stories included in this java class is SMK-39527
 *
 * @author dharani.chandrasekar
 *
 */

public class AssignmentDetailsPageTest extends BaseTest {

	private String smUrl;
	private String browser;
	private String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String schoolID;
	private String teacherID;
	private static String username = null;
	private static String password = null;
	private HashMap<String, String> groupDetails = new HashMap<>();
	private static List<String> studentRumbaIds = new ArrayList<>();
	private String token = null;

	private String chromePlatform = "Windows_10_Chrome_latest"; // for Simulator Execution
	String teacherDetails;
	String studentDetails;
	String studentDetailsSecond;
	String studentDetailsThree;

	List<String> expectedCourseTypesInDropdown = Arrays.asList("Focus Courses", "Default Courses", "Custom Courses",
			"All Courses", "My Custom Courses");

	@BeforeClass (alwaysRun = true)
	public void initTest(ITestContext context) throws Exception {
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		schoolID = RBSDataSetup.organizationIDs.get(school);
		teacherID = SMUtils.getKeyValueFromResponse(teacherDetails, "userId");
		username = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		password = RBSDataSetupConstants.DEFAULT_PASSWORD;

		studentDetails = RBSDataSetup.getMyStudent(school, username);
		studentDetailsSecond = RBSDataSetup.getMyStudent(school, username);
		studentDetailsThree = RBSDataSetup.getMyStudent(school, username);

		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails, "userId"));
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsSecond, "userId"));
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetailsThree, "userId"));

		// token creation
		token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse(teacherDetails, "userName"),
				RBSDataSetupConstants.DEFAULT_PASSWORD);

		// Group
		String groupName = "GroupNo_" + System.nanoTime();
		groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token);
		groupDetails.put(GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse(teacherDetails, "userId"));
		groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get(school));
		groupDetails.put(GroupConstants.GROUP_NAME, groupName);
		String groupId = SMUtils.getKeyValueFromResponse(
				new GroupAPI().createGroup(smUrl, groupDetails, studentRumbaIds).get(Constants.REPORT_BODY),
				"data,groupId");

	}

	@Test(description = "Verify the user able to view the Assignment Details page and also verify the Title and sub-title of assignments (Math_Default_Assignment)", enabled = true, priority = 1, groups = {
			"SMK-39527", "assignments", "assignmentDetailsPage" })
	public void tc_AssignmentDetailsPage001() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


		Log.testCaseInfo(
				"tc_AssignmentDetailsPage001:Verify the user able to view the Assignment Details page and also verify the Title and sub-title of assignments(Math_Default_Assignment). <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to courseWare tab and Courses
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);

			// Click on the course
			CoursesPage coursepage = new CoursesPage(driver);
			// Select Math Course
			coursepage.clickFromCourseListingPage(Constants.MATH);

			coursepage.clickAssignBtn();
			coursepage.addCourseToMultipleStudents();
			coursepage.clickAssignButton();

			tHomePage.topNavBar.getCourseListingPage();
			// Navigate to 'Assignments' page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on 'view Assignments' button
			assignmentsPage.viewAssignmentDetailsByAssignmentName(Constants.MATH);

			SMUtils.logDescriptionTC("SMK-7235- Verify Assignment Details page is getting loaded or not");
			// Verification of getting Assignment Details Page
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver).get();

			SMUtils.logDescriptionTC("SMK-7236- Verify the Assignment Title in the Assignment Details Page");
			// Verification of Assignment Title
			Log.assertThat(assignmentDetailsPage.gettitleOfAssignmentDetailsPage().trim().equals(Constants.MATH),
					"Assignment Title is displayed", "Assignment Title is not displayed");

			SMUtils.logDescriptionTC("SMK-7237- Verify the Assignment sub-Title in the Assignment Details Page");
			// Verification of Assignment Sub-Title
			Log.assertThat(
					(assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage()
							.contains(Constants.ACTIVE_STUDENTS_ASSIGMENT_SUBTITILE)
							&& assignmentDetailsPage.getsubTitleOfAssignmentDetailsPage()
									.contains(Constants.PAUSED_STUDENTS_ASSIGMENT_SUBTITILE)),

					"Assignment SubTitle (Active Students and Paused Students) is displayed",
					"Assignment SubTitle (Active Students and Paused Students) is not displayed");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verification of Assigned_To and Mastery ToogleButtons in the Assignment details page (Math-Default Assignment)", enabled = true, priority = 1, groups = {
			"SMK-39527", "assignments", "assignmentDetailsPage" })
	public void tc_AssignmentDetailsPage002() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentDetailsPage002: SMK-7242- Verification of Assigned_To and Mastery ToogleButtons in the Assignment details page (Math-Default Assignment). <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate 'CourseWare' tab and select the 'Assignments' option
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on View Assignment
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.MATH);

			// Verification of Assigned_To and Mastery ToogleButtons
			Log.assertThat(assignmentDetailsPage.getAssignedToToggleButton().equals(Constants.ASSIGNED_TO),
					"Assigned_To Toogle button is displayed", "Assigned_To Toogle button is not displayed");
			Log.assertThat(assignmentDetailsPage.getMasteryToggleButton().equals(Constants.MASTERY),
					"Mastery Toogle button is displayed", "Mastery Toogle button is not displayed");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Ellispe icon and options at the assignment level in the assignment details page", enabled = true, priority = 1, groups = {
			"SMK-39527", "assignments", "assignmentDetailsPage" })
	public void tc_AssignmentDetailsPage003() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
		Log.testCaseInfo(
				"tc_AssignmentDetailsPage003: SMK-7255- Verify the Ellispe icon and options at the assignment level in the assignment details page. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to HomePage TopNavigationBar
			TopNavBar topNavBar = tHomePage.topNavBar;
			Log.assertThat(topNavBar.isCoursewareDisplayed(), "CourseWare Tab is displayed in TopNavBar",
					"Courseware Tab is not displayed in TopNavBar");

			// Clicking on 'CourseWare' tab and getting the CourseListingPage then Assigning
			// the groups
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
			List<String> actualCourseTypeNamesInDropdwn = courseListingPage.getAllCourseTypeDropDownItems();
			Log.assertThat(SMUtils.compareTwoList(expectedCourseTypesInDropdown, actualCourseTypeNamesInDropdwn),
					"Expected course types are present.", "Expected course types are not present.");

			// Selecting "Default-course" option (Reading) and clicking on 'Assign-Widget'
			courseListingPage.selectCourseTypeFromDropDown(Constants.DEFAULT_COURSES);
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickCourseName(Constants.MATH);
			coursepage.clickAssignBtn();
			coursepage.addCourseToGroups();

			// Navigate to 'Assignments' page
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on 'view Assignments' button
			assignmentsPage.viewAssignmentDetailsByAssignmentName(Constants.MATH);
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver);

			// Verification of Assign button
			Log.assertThat(assignmentDetailsPage.assignElement().isDisplayed(),
					"Assign button is displayed in the Assignment Details Page",
					"Assign button is not displayed in the Assignment Details Page");

			// Clicking on 'Assign' button in the Assignment Details page
			assignmentDetailsPage.clickAssignButton();
			assignmentDetailsPage.addAssignmentToStudents();
//			assignmentDetailsPage.closeButton();

			// Verification of Ellipsis icon at the Assignment Level
			assignmentDetailsPage.assignmentLevelEllipsis();
		//	assignmentDetailsPage.assignmentSettingTabTopEllipsis();
		
			Log.assertThat(assignmentDetailsPage.assignmentSettingTabTopEllipsis().equals(Constants.ASSIGMENT_SETTINGS),
					"Assignment Settings option is displayed", "Assignment Settings option is not displayed");
			Log.assertThat(assignmentDetailsPage.pauseAllStudentTopEllipsis().equals(Constants.PAUSED_ALL_STUDENTS),
					"Pause All Student option is displayed", "Pause All Student option is not displayed");
			Log.assertThat(assignmentDetailsPage.deleteAssignmenttabTopEllipsis().equals(Constants.DELETED_ASSIGNMENT),
					"Delete Assignment option is displayed", "Delete Assignment option is not displayed");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verifying the ColumnNames in the Assignment_Details_Page", enabled = true, priority = 1, groups = {
			"SMK-39527", "assignments", "assignmentDetailsPage" })
	public void tc_AssignmentDetailsPage004() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentDetailsPage004: SMK-7245- Verifying the ColumnNames in the Assignment_Details_Page. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to courseWare tab and Courses
			CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

			// Select Focus course
			courseListingPage.selectCourseTypeFromDropDown(Constants.FOCUS_COURSES);
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickCourseName(Constants.SM_FOCUS_MATH_GRADE1);

			// Clicking on 'Assign-Widget' and assigning
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();

			// Navigate 'CourseWare' tab and select the 'Assignments' option
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on View Assignment
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.SM_FOCUS_MATH_GRADE1);

			// Verifying the ColumnNames in the Assignment_Details_Page
			Log.assertThat(assignmentDetailsPage.getColumnName().trim().equals(Constants.NAME),
					"NAME Column is displayed in the Assignment_Details_Page",
					"NAME Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnLastSession().trim().equals(Constants.LAST_SESSION),
					"LAST_SESSION Column is displayed in the Assignment_Details_Page",
					"LAST_SESSION Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnIPLevel().trim().equals(Constants.IP_LEVEL),
					"IP_LEVEL Column is displayed in the Assignment_Details_Page",
					"IP_LEVEL Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnAssignedLevel().trim().equals(Constants.ASSIGNED_LEVEL),
					"ASSIGNED_LEVEL Column is displayed in the Assignment_Details_Page",
					"ASSIGNED_LEVEL Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnCurrentLevel().trim().equals(Constants.CURRENT_LEVEL),
					"CURRENT_LEVEL Column is displayed in the Assignment_Details_Page",
					"CURRENT_LEVEL Column is not displayed in the Assignment_Details_Page");
			Log.assertThat(assignmentDetailsPage.getColumnGain().trim().equals(Constants.GAIN),
					"GAIN Column is displayed in the Assignment_Details_Page",
					"GAIN Column is not displayed in the Assignment_Details_Page");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the Ellipsis icon and options at the student level in the assignment details page", enabled = true, priority = 1, groups = {
			"SMK-39527", "assignments", "assignmentDetailsPage" })
	public void tc_AssignmentDetailsPage005() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);
		
		Log.testCaseInfo(
				"tc_AssignmentDetailsPage005 :SMK-7255 - Verify the Ellipsis icon and options at the student level in the assignment details page. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to courseWare tab and Courses
			tHomePage.topNavBar.getCourseListingPage();

			// Select Focus course
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickCourseName(Constants.SM_FOCUS_READING_GRADE1);

			// Clicking on 'Assign-Widget' and assigning
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();

			// Navigate 'CourseWare' tab and select the 'Assignments' option
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on View Assignment
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.SM_FOCUS_READING_GRADE1);

			// Clicking on Ellipsis icon at the student level
			assignmentDetailsPage.clickDotEllipsisButton();

			Log.assertThat(assignmentDetailsPage.fluencyFilesInEllipsis().contains(Constants.FLUENCY_FILES),
					"Fluency_Files option is displayed", "Fluency_Files option is not displayed");
			Log.assertThat(assignmentDetailsPage.assignmentSettingInEllipsis().equals(Constants.ASSIGMENT_SETTINGS),
					"Assignment_Settings option is displayed", "Assignment Settings option is not displayed");
			Log.assertThat(
					assignmentDetailsPage.pauseAssignmentForStudentTabInEllipsis()
							.equals(Constants.PAUSE_ASSIGNMENT_FOR_STUDENTS),
					"Pause_Assignment_For_Student option is displayed",
					"Pause_Assignment_For_Student option is not displayed");
			Log.assertThat(assignmentDetailsPage.removeStudentTabInEllipsis().equals(Constants.REMOVE_STUDENTS),
					"Remove_Student option is displayed", "Remove_Student option is not displayed");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Verify the students in view assignment details page after assigning single and multiple students", enabled = true, priority = 1, groups = {
			"SMK-39527", "assignments", "assignmentDetailsPage" })
	public void tc_AssignmentDetailsPage006() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentDetailsPage006: SMK-7238 & SMK-7239 Verify the students in view assignment details page after assigning single and multiple students. <small><b><i>["
						+ browser + "]</b></i></small>");

		try {

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to students tab and get the all students list
			StudentsPage studentPage = tHomePage.topNavBar.navigateToStudentsTab();
			Map<String, List<String>> studentDetailsFromStudentTab = studentPage.getColumnDetailsAsList();
			List<String> studenListFromStudentTab = new ArrayList<>();
			CoursesPage customCourses = new CoursesPage(driver);
			for (int studentValue = 0; studentValue < studentDetailsFromStudentTab.get(Constants.FIRSTNAME)
					.size(); studentValue++) {
				String studentFN = studentDetailsFromStudentTab.get(Constants.FIRSTNAME).get(studentValue);
				String studentLN = studentDetailsFromStudentTab.get(Constants.LASTNAME).get(studentValue);
				studenListFromStudentTab.add(customCourses.completeStudentName(studentFN, "", studentLN));
			}
			String[] FNLN = studenListFromStudentTab.get(0).split(" ");
			String studentFNLN = FNLN[0].concat(FNLN[1]);

			// Navigate to courseWare tab and Courses
			tHomePage.topNavBar.getCourseListingPage();

			// Select Focus course
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickCourseName(Constants.SM_FOCUS_MATH_GRADE2);

			// Clicking on 'Assign-Widget' and assigning
			coursepage.clickAssignBtn();
			coursepage.addCourseToOneStudent(studentFNLN);

			// Navigate 'CourseWare' tab and select the 'Assignments' option
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on View Assignment
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.SM_FOCUS_MATH_GRADE2);

			// Assigning students from Assignment page
			AssignAssignmentPopup assigAssignmentPopup = assignmentDetailsPage.clickAssignButton();
			coursepage.addCourseToStudents();
			Log.message("Successfully Assigned Multiple Students To Course");

			List<String> studentsFromAssignmentPage = assignmentDetailsPage.getStudentFNLNListfromAssignementDetails();

			Log.assertThat(
					SMUtils.sortList(studentsFromAssignmentPage).equals(SMUtils.sortList(studenListFromStudentTab)),
					"Added students are displayed in Assignments Table",
					"Added students are not displayed in Assignments Table");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Pause and Resume the student in view assignmnet details page", enabled = true, priority = 1, groups = {
			"SMK-39527", "assignments", "assignmentDetailsPage" })
	public void tc_AssignmentDetailsPage007() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentDetailsPage007:SMK-7247- Pause and Resume the student in view assignmnet details page. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to courseWare tab and Courses
			tHomePage.topNavBar.getCourseListingPage();

			// Select Focus course
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickCourseName(Constants.SM_FOCUS_READING_GRADE2);

			// Clicking on 'Assign-Widget' and assigning
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();

			// Navigate 'CourseWare' tab and select the 'Assignments' option
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on View Assignment
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.SM_FOCUS_READING_GRADE2);

			// Clicking on Ellipsis icon at the student level
			assignmentDetailsPage.clickDotEllipsisButton();

			// Verifying the Pause_Assignment_For_Student option in the Ellipsis
			assignmentDetailsPage.pauseAssignmentForStudentTab();

			// Verifying the Pause_Button in the Pause Assignment confirm PopUp
			assignmentDetailsPage.clickPauseButtononPopUpPage();
			Log.assertThat(assignmentDetailsPage.isAssignmentPaused(), "Assignment paused successfully",
					"Assignment has not Paused");

			// Clicking on Ellipsis icon at the student level
			assignmentDetailsPage.clickDotEllipsisButton();

			// Verifying the Resume_Assignment_For_Student option in the Ellipsis
			assignmentDetailsPage.resumeAssignment();

			// Verifying the Resume_Button in the Resume Assignment confirm PopUp
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			Log.assertThat(!assignmentDetailsPage.isStudentPaused(),
					"Assignment has Resumed successfully", "Assignment has Paused not resumed");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Remove student in view assignmnet details page", enabled = true, priority = 1, groups = {
			"SMK-39527", "assignments", "assignmentDetailsPage" })
	public void tc_AssignmentDetailsPage008() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentDetailsPage008: SMK-7240 - Remove student in view assignmnet details page. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			String studentFNLN = SMUtils.getKeyValueFromResponse(studentDetails, "firstName") + " "
					+ SMUtils.getKeyValueFromResponse(studentDetails, "lastName");

			// Select Focus course
			CoursesPage coursepage = tHomePage.topNavBar.navigateToCourseListingPage();
			coursepage.clickCourseName(Constants.SM_FOCUS_MATH_GRADE3);

			// Clicking on 'Assign-Widget' and assigning
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();

			SMUtils.nap(5);
			// Navigate 'CourseWare' tab and select the 'Assignments' option
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on View Assignment
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.SM_FOCUS_MATH_GRADE3);

			// Verifying the Remove_Student option in the Ellipsis
			assignmentDetailsPage.removeStudentFromAssignment(studentFNLN);

			Log.assertThat(
					!assignmentDetailsPage.getStudentListfromAssignementDetailsTable().contains(studentFNLN),
					"Mentioned student removed", "Mentioned student not removed");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Edit Assignment settings in the view assignmnet details page", enabled = true, priority = 1, groups = {
			"SMK-39527", "assignments", "assignmentDetailsPage" })
	public void tc_AssignmentDetailsPage009() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentDetailsPage009: Edit Assignment settings in the view assignmnet details page. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {

			// Login to the SM_Application
			LoginPage smLoginPage = new LoginPage(driver, smUrl).get();
			TeacherHomePage tHomePage = smLoginPage.loginToSM(username, password, true);

			// Navigate to courseWare tab and Courses
			tHomePage.topNavBar.getCourseListingPage();

			// Select Focus course
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickCourseName(Constants.SM_FOCUS_READING_GRADE3);

			// Clicking on 'Assign-Widget' and assigning
			coursepage.clickAssignBtn();
			coursepage.addCourseToGroups();

			// Navigate 'CourseWare' tab and select the 'Assignments' option
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on View Assignment
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.SM_FOCUS_READING_GRADE3);

			// Clicking on Ellipsis at studentLevel and AssignmentSettings option
			assignmentDetailsPage.clickAssignmentSetting();

			SMUtils.logDescriptionTC("SMK-7241 - Edit Assignment settings in the view assignmnet details page.");
			// Editing the values using Assignment settings
			assignmentDetailsPage.selectValueFromDropDownSessionLength(Constants.SESSION_LENGHT_SELECTED);
			assignmentDetailsPage.clickSaveButton();
			assignmentDetailsPage.clickAssignmentSetting();
			Log.assertThat(
					assignmentDetailsPage.getsessionLength().toLowerCase().trim()
							.contains(Constants.SESSION_LENGHT_SELECTED.toLowerCase()),
					"Session Length value is Updated", "Session Length value is not updated");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Delete Assignment at AssignmentLevel in the view assignmnet details page", enabled = true, priority = 1, groups = {
			"SMK-39527", "assignments", "assignmentDetailsPage" })
	public void tc_AssignmentDetailsPage010() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentDetailsPage010: Delete Assignment at AssignmentLevel in the view assignmnet details page. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to courseWare tab and Courses
			tHomePage.topNavBar.getCourseListingPage();

			// Select Focus course
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickCourseName(Constants.SM_FOCUS_READING_GRADE3);

			// Clicking on 'Assign-Widget' and assigning
			coursepage.clickAssignBtn();
			coursepage.addCourseToGroups();

			// Navigate 'CourseWare' tab and select the 'Assignments' option
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on View Assignment
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.SM_FOCUS_READING_GRADE3);

			// Closing the Ellipsis icon at the student level
			assignmentDetailsPage.clickDotEllipsisButton();

			// Clicking on the Assignment_Settings option in the Ellipsis
			assignmentDetailsPage.assignmentSettingInEllipsis();

			SMUtils.logDescriptionTC("SMK-7241 - Delete Assignment settings in the view assignmnet details page.");
			// Delete Assignment
			assignmentDetailsPage.deleteAssignmenttab();
			assignmentDetailsPage.deleteAssignmentButton();
			Log.assertThat(assignmentDetailsPage.AssignmentDeleted(),
					"Assignment has deleted successfullyAssignment has deleted successfully",
					"Assignment has not deleted successfully");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Pause all students at AssignmentLevel in the view assignment details page", enabled = true, priority = 2, groups = {
			"SMK-39527", "assignments", "assignmentDetailsPage" })
	public void tc_AssignmentDetailsPage011() throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentDetailsPage011: SMK-7247- Pause all students at AssignmentLevel in the view assignment details page. <small><b><i>["
						+ browser + "]</b></i></small>");
		try {

			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to courseWare tab and Courses
			tHomePage.topNavBar.getCourseListingPage();

			// Select Focus course
			CoursesPage coursepage = new CoursesPage(driver);
			coursepage.clickCourseName(Constants.SM_FOCUS_READING_GRADE4);

			// Clicking on 'Assign-Widget' and assigning
			coursepage.clickAssignBtn();
			coursepage.addCourseToStudents();

			// Navigate 'CourseWare' tab and select the 'Assignments' option
			AssignmentsPage assignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();

			// Clicking on View Assignment
			assignmentsPage.clickAssignmentSubMenu();
			AssignmentDetailsPage assignmentDetailsPage = assignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.SM_FOCUS_READING_GRADE4);

			// Pause all students in the Assignment
			assignmentDetailsPage.pauseAllStudent();
			assignmentDetailsPage.pauseButtonFoAllSTudent();
			Log.assertThat(assignmentDetailsPage.isAssignmentPausedatAssignmentLevel(),
					"Assignment paused for all successfully", "Assignment has not Paused");

			// Resume all students in the Assignment
			assignmentDetailsPage.resumeAllAssignment();
			assignmentDetailsPage.clickResumeButtononPopUpPage();
			Log.assertThat(!assignmentDetailsPage.isStudentPaused(),
					"Assignment resumed at asignment leve for all successfully",
					"Assignment Paused for all successfully");

			// Sign out from the SM_Application
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@Test(description = "Default Math Assignment - Verification of LastSession, IP Level,Assigned Level,Current Level,Gain and %correct fields in the assignment details page", groups = {
			"SMK-43618", "students", "assignments", "studentAssignments" }, priority = 3)
	public void tc_AssignmentDetailsPage012() throws Exception {

		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);

		Log.testCaseInfo(
				"tc_AssignmentDetailsPage012 : Default Math Assignment <small><b><i>[" + browser + "]</b></i></small>");

		try {
			// Login to the SM_Application
			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			TeacherHomePage tHomePage = new TeacherHomePage(driver);

			boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Navigate to CourseListing Page
			CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();

			// Selecting Math Course and assigning to student
			coursePage.clickMathCourse();
			coursePage.clickAssignBtn();
			coursePage.addCourseToStudents();
			coursePage.clickBackIcon();

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();
			driver.quit();

			// Executing Math assignments in student dashboard
			executeSimulator(Constants.MATH, Constants.MATH);

			// Navigate to teacher page again
			driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
			eventListner = new EventListener();
			driver.register(eventListner);

			LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, username, password);
			tHomePage = new TeacherHomePage(driver);

			courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
			Log.softAssertThat(courseWidgetDisplayed, "Course widget is diplayed",
					"Course widget is not diplayed");

			// Getting IP Level, Gain value and other values of assignment from Assignments
			// Tab's Assignment Details Page
			AssignmentsPage mathAssignmentsPage = tHomePage.topNavBar.navigateToAssignmentsPage();
			AssignmentDetailsPage mathAssignmentDetailsPage = mathAssignmentsPage
					.viewAssignmentDetailsByAssignmentName(Constants.MATH);

			Map<String, String> studentIPandGainFromAssignmentDetailsPage = new HashMap<>();
//			studentDetails = DataSetup.teacherStudentMap.get(username).get("Student3");

			String studentID = SMUtils.getKeyValueFromResponse(studentDetails, "userName");

			studentIPandGainFromAssignmentDetailsPage = mathAssignmentDetailsPage.getStudentAssignmentDetailsPageValues(
					SMUtils.getKeyValueFromResponse(studentDetails, "firstName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "middleName"),
					SMUtils.getKeyValueFromResponse(studentDetails, "lastName"));
			AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage(driver).get();

			Log.message("Captured results : " + studentIPandGainFromAssignmentDetailsPage.toString());
			String name = studentIPandGainFromAssignmentDetailsPage.get("Name");
			String lastSession = studentIPandGainFromAssignmentDetailsPage.get("Last session");
			String assignValue = studentIPandGainFromAssignmentDetailsPage.get("Assigned Level");
			String ipValue = studentIPandGainFromAssignmentDetailsPage.get("IP Level");
			String currentLevel = studentIPandGainFromAssignmentDetailsPage.get("Current Level");
			String gain = studentIPandGainFromAssignmentDetailsPage.get("Gain");
			String correct = studentIPandGainFromAssignmentDetailsPage.get("% Correct");

			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			Log.message("Before Format : " + date.toString());
			String currentDate = formatter.format(date).trim();
			Log.message("After Format : " + formatter.format(date));

			SMUtils.logDescriptionTC(
					"SMK-7244 : Verify that the % completion is displaying as 100% after completing the course");
			Log.assertThat(correct.equals(Constants.Assignments.VALUE_FULL), "Correct % values displays correctly",
					"Correct % values displays incorrectly");

			SMUtils.logDescriptionTC(
					"SMK-7249 : Verify the session duration displayed under \"Last session\" column is as expected ");
			SMUtils.logDescriptionTC(
					"SMK-7248 : Verify the data displayed under 'Last session' column is as expected ");
			Log.assertThat(lastSession.contains(currentDate), "Date displays correctly in Last session",
					"Incorrect date displays");

			String fullname = SMUtils.getKeyValueFromResponse(studentDetails, "firstName") + " "
					+ SMUtils.getKeyValueFromResponse(studentDetails, "middleName") + " "
					+ SMUtils.getKeyValueFromResponse(studentDetails, "lastName");
			Log.message("Student Full name : " + fullname);

			SMUtils.logDescriptionTC(
					"SMK-7246 : Verify that the Name column is displayed in 'last name first name' format for all the students");
			Log.assertThat(name.equals(fullname), "Student Full name displays correctly",
					"Student full name displays incorrectly");

			SMUtils.logDescriptionTC(
					"SMK-7250 : Verify the data displayed under 'Assigned Level' column is as expected");
			Log.assertThat(!assignValue.equals(Constants.Assignments.VALUE_ZERO), "Value displays for Assigned Level",
					"Value is not displaying correctly");

			SMUtils.logDescriptionTC(
					"SMK-7251 : Verify the data displayed under 'Current Level' column is as expected");
			Log.assertThat(!currentLevel.equals(Constants.Assignments.VALUE_ZERO), "Value displays for Current Level",
					"Value is not displaying correctly");

			SMUtils.logDescriptionTC("SMK-7252 : Verify the data displayed under '% Correct' column is as expected");
			Log.assertThat(correct.equals(Constants.Assignments.VALUE_FULL), "Value displays for % correct",
					"Value is not displaying correctly");

			SMUtils.logDescriptionTC("SMK-7256 : Verify that the student list default sort order is name descending ");
			Log.assertThat(assignmentDetailsPage.getArrowStateOfnameColumn().equals(Constants.DESCENDING),
					"Default Sorting is in Descending order", "Default Sorting is in Ascending order");

			// SignOut from SM
			tHomePage.topNavBar.signOutfromSM();

			Log.testCaseResult();

		} catch (Exception e) {
			Log.exception(e, driver);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	public void executeSimulator(String assignmentName, String assignmentType) throws Exception {
		// Get driver
		EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( chromePlatform ));
		EventListener eventListner = new EventListener();
		driver.register(eventListner);


		String studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERNAME);
		LoginWrapper.loginToSuccessMakerAsTeacher(driver, smUrl, UserType.BASIC, null, studentUsername, password);
		StudentDashboardPage studentDashboardPageForThirdStudent = new StudentDashboardPage(driver);
		IntStream.rangeClosed(1, 5).forEach(exeCount -> {
			try {
				if (assignmentType.equals("Math")) {
					studentDashboardPageForThirdStudent.executeMathCourse(
							SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"), assignmentName, "100",
							"1", "30");
				} else {
					studentDashboardPageForThirdStudent.executeReadingCourse(
							SMUtils.getKeyValueFromResponse(teacherDetails, "data,personId"), assignmentName, "86", "1",
							"20");
				}
			} catch (IOException e) {

				Log.message("Error occurred while running the simulator");
			}
		});
		driver.quit();
	}
}