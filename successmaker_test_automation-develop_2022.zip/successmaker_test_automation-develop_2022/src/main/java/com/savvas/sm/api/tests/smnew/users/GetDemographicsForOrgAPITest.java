package com.savvas.sm.api.tests.smnew.users;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.common.utils.apiconstants.CommonAPIConstants;
import com.savvas.sm.common.utils.apiconstants.UserAPIConstants;
import com.savvas.sm.common.utils.apiconstants.GroupAPIConstants.DeleteGroupAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.ethnicity;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.gender;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.getDemographicsConstants;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasDisability;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEconomicDisadvantage;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.hasEnglishProficiency;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.isMigrant;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants.specialServices;

/**
 * To test the Get Demographics for Organization
 * 
 * @author saniya.joseph
 */

public class GetDemographicsForOrgAPITest extends UserAPI {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String smUrl;
    String sessionCookie;

    /*
     * private String secondTeacher = null; private String studentUserId = null;
     */

    String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    String classId = null;
    String className = null;

    // Teacher variable used for this class
    private String orgUsed = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    /*
     * private String orgUsed1 = RBSDataSetup.getSchools( Schools.READING_SCHOOL
     * );
     */
    private String teacherUsed = null;
    private String orgId;
    private String teacherId;
    private String studentId;
    private String studentName;
    private String username;
    String studentUsed;

    // Object 
    com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI utilsRepoGroupAPI;

    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {

        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );

        // Teacher used Details
        orgId = RBSDataSetup.organizationIDs.get( orgUsed );
        teacherUsed = RBSDataSetup.getMyTeacher( orgUsed );
        studentUsed = RBSDataSetup.getMyStudent( orgUsed, SMUtils.getKeyValueFromResponse( teacherUsed, RBSDataSetupConstants.USERNAME ) );
        teacherId = SMUtils.getKeyValueFromResponse( teacherUsed, Constants.USERID_HEADER );
        username = SMUtils.getKeyValueFromResponse( teacherUsed, Constants.USER_NAME );

        // Student used Details
        studentId = SMUtils.getKeyValueFromResponse( studentUsed, Constants.USERID_HEADER );
        studentName = SMUtils.getKeyValueFromResponse( studentUsed, Constants.USER_NAME );

        RBSDataSetup.organizationIDs.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) );
        JSONObject otherSchoolTeacherJson = new JSONObject( ( RBSDataSetup.orgTeacherDetails.get( RBSDataSetup.getSchools( Schools.READING_SCHOOL ) ) ).get( "Teacher1" ) );
        new SMAPIProcessor().getKeyValues( otherSchoolTeacherJson, RBSDataSetupConstants.USERID ).get( 0 );
        new SMAPIProcessor().getKeyValues( otherSchoolTeacherJson, RBSDataSetupConstants.USERNAME ).get( 0 );
        utilsRepoGroupAPI = new com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI();

    }

    @Test ( priority = 1, dataProvider = "getDemographicsPositive", groups = { "smoke_test_case", "Smoke_getDemographics01", "SMK-52042", "Student", "Get Demographics for Organization", "P1", "API" } )
    public void tcPositiveTestcases( String description, String scenario, String statusCode ) throws Exception {
        HashMap<String, String> userDetails = new HashMap<>();
        HashMap<String, String> response = null;
        Log.testCaseInfo( description );

        switch ( scenario ) {
            case "VALID":
                Log.testCaseInfo( "SMK-20642 Verify response contains all the demographics with correct values" );
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
                userDetails.put( UserAPIConstants.USERID, teacherId );
                userDetails.put( UserAPIConstants.ORGID, orgId );
                response = getDemographics( smUrl, userDetails );
                VerifyResponseCode( response, statusCode );
                VerifyResponseMessage( response, getDemographicsConstants.SUCCESS_MESSAGE );
                VerifySchema( statusCode, response );
                Log.testCaseResult();
                break;

            case "GENDER":
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
                userDetails.put( UserAPIConstants.USERID, teacherId );
                userDetails.put( UserAPIConstants.ORGID, orgId );
                response = getDemographics( smUrl, userDetails );
                List<String> gendersList = Stream.of( gender.values() ).map( gender::name ).collect( Collectors.toList() );
                verifyDemographics( getDemographicsConstants.GENDER_RESPONSE_VALUE, gendersList, response );
                Log.testCaseResult();
                break;

            case "DISABILITY_STATUS":
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
                userDetails.put( UserAPIConstants.USERID, teacherId );
                userDetails.put( UserAPIConstants.ORGID, orgId );
                response = getDemographics( smUrl, userDetails );
                List<String> disabilityList = Stream.of( hasDisability.values() ).map( hasDisability::name ).collect( Collectors.toList() );
                verifyDemographics( getDemographicsConstants.DISABILITY_STATUS_RESPONSE_VALUE, disabilityList, response );
                Log.testCaseResult();
                break;

            case "MIGRANT_STATUS":
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
                userDetails.put( UserAPIConstants.USERID, teacherId );
                userDetails.put( UserAPIConstants.ORGID, orgId );
                response = getDemographics( smUrl, userDetails );
                List<String> migrantList = Stream.of( isMigrant.values() ).map( isMigrant::name ).collect( Collectors.toList() );
                verifyDemographics( getDemographicsConstants.MIGRANT_STATUS_RESPONSE_VALUE, migrantList, response );
                Log.testCaseResult();
                break;

            case "SOCIOECONOMIC_STATUS":
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
                userDetails.put( UserAPIConstants.USERID, teacherId );
                userDetails.put( UserAPIConstants.ORGID, orgId );
                response = getDemographics( smUrl, userDetails );
                List<String> economicList = Stream.of( hasEconomicDisadvantage.values() ).map( hasEconomicDisadvantage::name ).collect( Collectors.toList() );
                verifyDemographics( getDemographicsConstants.SOCIOECONOMIC_STATUS_RESPONSE_VALUE, economicList, response );
                Log.testCaseResult();
                break;

            case "RACE":
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
                userDetails.put( UserAPIConstants.USERID, teacherId );
                userDetails.put( UserAPIConstants.ORGID, orgId );
                response = getDemographics( smUrl, userDetails );
                //                List<String> raceList = Stream.of( race.values() ).map( race::name ).collect( Collectors.toList() );
                //                verifyDemographics( getDemographicsConstants.RACE_RESPONSE_VALUE, raceList, response );
                Log.testCaseResult();
                break;

            case "ETHINICITY":
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
                userDetails.put( UserAPIConstants.USERID, teacherId );
                userDetails.put( UserAPIConstants.ORGID, orgId );
                response = getDemographics( smUrl, userDetails );
                List<String> ethiniCityList = Stream.of( ethnicity.values() ).map( ethnicity::name ).collect( Collectors.toList() );
                //                verifyDemographics( getDemographicsConstants.ETHINICITY, ethiniCityList, response );
                Log.testCaseResult();
                break;

            case "SPECIAL_SERVICES":
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
                userDetails.put( UserAPIConstants.USERID, teacherId );
                userDetails.put( UserAPIConstants.ORGID, orgId );
                response = getDemographics( smUrl, userDetails );
                List<String> servicesList = Stream.of( specialServices.values() ).map( specialServices::name ).collect( Collectors.toList() );
                verifyDemographics( getDemographicsConstants.SPECIAL_SERVICES_RESPONSE_VALUE, servicesList, response );
                Log.testCaseResult();
                break;

            case "ENGLISH_LANGUAGE":
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( username, password ) );
                userDetails.put( UserAPIConstants.USERID, teacherId );
                userDetails.put( UserAPIConstants.ORGID, orgId );
                response = getDemographics( smUrl, userDetails );
                List<String> englishList = Stream.of( hasEnglishProficiency.values() ).map( hasEnglishProficiency::name ).collect( Collectors.toList() );
                verifyDemographics( getDemographicsConstants.ENGLISH_LANGUAGE_RESPONSE_VALUE, englishList, response );
                Log.testCaseResult();
                break;

        }

    }

    /**
     * Data provider for positive scenarios
     * 
     * @return
     */

    @DataProvider ( name = "getDemographicsPositive" )
    public Object[][] getDemographicsPositive() {

        Object[][] inputData = { { "SMK-20639 Verify response for valid data", "VALID", CommonAPIConstants.STATUS_CODE_OK }, { "SMK-20643 Verify all the values of GENDER", "GENDER", CommonAPIConstants.STATUS_CODE_OK },
                { "SMK-20644 Verify all the values of DISABILITY_STATUS", "DISABILITY_STATUS", CommonAPIConstants.STATUS_CODE_OK }, { "SMK-20645 Verify all the values of MIGRANT_STATUS", "MIGRANT_STATUS", CommonAPIConstants.STATUS_CODE_OK },
                { "SMK-20646 Verify all the values of SOCIOECONOMIC_STATUS", "SOCIOECONOMIC_STATUS", CommonAPIConstants.STATUS_CODE_OK }, { "SMK-20647 Verify all the values of RACE", "RACE", CommonAPIConstants.STATUS_CODE_OK },
                { "Updated With new changes:  Verify all the values of ETHNICITY", "ETHINICITY", CommonAPIConstants.STATUS_CODE_OK }, { "SMK-20648 Verify all the values of SPECIAL_SERVICES", "SPECIAL_SERVICES", CommonAPIConstants.STATUS_CODE_OK },
                { "SMK-20649 Verify all the values of ENGLISH_LANGUAGE", "ENGLISH_LANGUAGE", CommonAPIConstants.STATUS_CODE_OK }

        };
        return inputData;
    }

    @Test ( dataProvider = "getDemographicsNegative", groups = { "SMK-52042", "Student", "Get Demographics for Organization", "P1", "API" } )
    public void tcNegativeTestcases( String description, String scenario, String statusCode ) throws Exception {
        HashMap<String, String> userDetails = new HashMap<>();

        if ( scenario.equalsIgnoreCase( "INVALID TOKEN" ) ) {
            statusCode = CommonAPIConstants.STATUS_CODE_UNAUTHORIZED;

        } else if ( scenario.equalsIgnoreCase( "STUDENT AUTHORIZATION" ) ) {
            statusCode = CommonAPIConstants.STATUS_CODE_FORBIDDAN;
        }
        Log.testCaseInfo( description );
        switch ( scenario ) {

            case "STUDENT AUTHORIZATION":
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, new RBSUtils().getAccessToken( studentName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                userDetails.put( UserAPIConstants.USERID, studentId );
                userDetails.put( UserAPIConstants.ORGID, orgId );
                break;

            case "INVALID TOKEN":
                userDetails.put( RBSDataSetupConstants.BEARER_TOKEN, CommonAPIConstants.INVALID_ACCESS_TOKEN );
                userDetails.put( UserAPIConstants.USERID, teacherId );
                userDetails.put( UserAPIConstants.ORGID, orgId );
                break;

        }
        HashMap<String, String> response = getDemographics( smUrl, userDetails );
        Log.message( response.toString() );
        Log.message( "Response: " + response.get( Constants.REPORT_BODY ) );

        // Validating Response Code, Schema
        VerifyResponseCode( response, statusCode );
        VerifySchema( statusCode, response );

        Log.testCaseResult();

    }

    /**
     * Data provider for negative scenarios
     * 
     * @return
     */
    @DataProvider ( name = "getDemographicsNegative" )
    public Object[][] getDemographicsNegative() {

        Object[][] inputData = { { "SMK-20641 Verify response for wrong authorization(student)", "STUDENT AUTHORIZATION", CommonAPIConstants.STATUS_CODE_FORBIDDAN },
                { "SMK-20640 Verify response for invalid accesstoken", "INVALID TOKEN", CommonAPIConstants.STATUS_CODE_UNAUTHORIZED }

        };
        return inputData;
    }

    /**
     * Verifying the values for the demographics
     * 
     * @param demographicField
     * @param demographicList
     * @param actualResponse
     */
    public void verifyDemographics( String demographicField, List<String> demographicList, HashMap<String, String> actualResponse ) {

        JSONObject actualBodyJsonObj = new JSONObject( actualResponse.get( Constants.REPORT_BODY ) );
        JSONObject dataJsonObj = actualBodyJsonObj.getJSONObject( Constants.DATA );
        JSONArray demographicsArray = new JSONArray( dataJsonObj.get( demographicField ).toString() );
        List<String> demographicValues = new ArrayList<String>();
        for ( int i = 0; i < demographicsArray.length(); i++ ) {
            demographicValues.add( demographicsArray.getJSONObject( i ).getString( getDemographicsConstants.DEMOGRAPHIC_VALUE ) );
        }
        Log.message( demographicValues.toString() );
        Log.assertThat( new SMUtils().compareTwoList( demographicList, demographicValues ), demographicField + " Demographic Values are displayed correctly", demographicField + " Demographic Values are not displayed correctly" );

    }

    /**
     * Verifying the response schema
     * 
     * @param StatusCode
     * @param response
     */
    public void VerifySchema( String StatusCode, HashMap<String, String> response ) {
        try {
            new SMAPIProcessor().isSchemaValid( getDemographicsConstants.GET_DEMOGRAPHICS_SCHEMA, StatusCode, response.get( Constants.REPORT_BODY ) );
        } catch ( IOException e ) {
            e.printStackTrace();
        }
    }

    /**
     * Verifying the response code
     * 
     * @param response
     * @param expectedCode
     */
    public void VerifyResponseCode( HashMap<String, String> response, String expectedCode ) {
        Log.assertThat( response.get( Constants.STATUS_CODE ).equals( expectedCode ), "Response status code is as expected - " + expectedCode,
                "Response status code is not as expected - Actual " + response.get( Constants.STATUS_CODE ) + " Expected " + expectedCode );
    }

    /**
     * Verifying the response message
     * 
     * @param expectedMessage
     * @param response
     */
    public void VerifyResponseMessage( HashMap<String, String> response, String expectedMessage ) {
        boolean flag = false;

        String responseBody = response.get( Constants.REPORT_BODY );

        String message = SMUtils.getKeyValueFromResponse( responseBody, "messages,message" );
        flag = message.equals( expectedMessage ) ? true : false;

        Log.assertThat( flag, "Message is matching as expected!", "The message is not matching not expected " + expectedMessage + " Actual " + message );
    }

}
