package com.savvas.sm.teacher.ui.tests.coursesSuite;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.learningservices.utils.EmailReport;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.Constants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.teacher.ui.pages.AssignmentDetailsPage;
import com.savvas.sm.teacher.ui.pages.CourseListingPage;
import com.savvas.sm.teacher.ui.pages.CoursesPage;
import com.savvas.sm.teacher.ui.pages.EditCourseSettingPage;
import com.savvas.sm.teacher.ui.pages.EventListener;
import com.savvas.sm.teacher.ui.pages.GroupPage;
import com.savvas.sm.teacher.ui.pages.TeacherHomePage;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupConstants;

import LSTFAI.customfactories.EventFiringWebDriver;

/**
 * This is used to test the Edit Course Settings present in the
 * Courseware>Courses page. The JIRA ID of the story is SMK-42904.
 *
 * @author Pooja.Kumbhar
 *
 */

@Listeners ( EmailReport.class )
public class EditCourseSettingTest1 extends BaseTest {
    private String smUrl;
    private String browser;
    private String username = null;
    private String password = null;
    String staticCourseName = null;
    String studentDetails;
    private static String teacherDetails;
    private String token = null;
    private String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    private HashMap<String, String> groupDetails = new HashMap<>();
    List<String> studentRumbaIds = new ArrayList<>();
    private String organizationId = null;
    private String CUSTOM_BY_SETTINGS_COURSE = "Custom by Settings course"+System.nanoTime();
  

    @BeforeTest
    public void initTest( ITestContext context ) throws Exception {
        smUrl = configProperty.getProperty( "SMAppUrl" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
		
		  teacherDetails = RBSDataSetup.getMyTeacher( school ); 
		  username =SMUtils.getKeyValueFromResponse( teacherDetails,RBSDataSetupConstants.USERNAME ); 
		  password =RBSDataSetupConstants.DEFAULT_PASSWORD;
		  
		  //Student Details 
		  studentDetails = RBSDataSetup.getMyStudent( school,username ); 
		  studentRumbaIds.add( SMUtils.getKeyValueFromResponse(studentDetails, "userId" ) ); 
		  organizationId =RBSDataSetup.organizationIDs.get( school );
		  
		  GroupAPI groupAPI = new GroupAPI(); 
		  String groupName = "GroupNo_" +System.nanoTime();
		  
		  //token creation 
		  token = new RBSUtils().getAccessToken(SMUtils.getKeyValueFromResponse( teacherDetails, "userName" ),RBSDataSetupConstants.DEFAULT_PASSWORD ); 
		  groupDetails.put(RBSDataSetupConstants.BEARER_TOKEN, token ); 
		  groupDetails.put(GroupConstants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse(
		  teacherDetails, "userId" ) ); 
		  groupDetails.put(GroupConstants.GROUP_OWNER_ORG_ID, RBSDataSetup.organizationIDs.get( school )); 
		  groupDetails.put( GroupConstants.GROUP_NAME, groupName );
		  
		  String groupId = SMUtils.getKeyValueFromResponse( new GroupAPI().createGroup(
		  smUrl, groupDetails, studentRumbaIds ).get( Constants.REPORT_BODY ),"data,groupId" );
		 
    }

    @Test ( description = "Verify that clicking on any of the Course under Course list page, you are redirected to the CourseDetails page", priority = 1 )
    public void TC001() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC001_Verify that clicking on any of the Course under Course list page, you are redirected to the CourseDetails page <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Default Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            coursePage.clickReadingCourse();

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that on Course details page, setting panel displays with the edit button enabled on the screen\r\n", priority = 1 )
    public void TC002() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC002_Verify that on Course details page, setting panel displays with the edit button enabled on the screen\r\n" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName = editCourseSettingPage.generteCourseName();
            coursePage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Selecting the option 'Course Title (Ascending)' from the sortBy drop down menu
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( courseName );
            editCourseSettingPage.clickEditSettingBtn();

            // Verify wheather edit button is enabled
            Log.softAssertThat( editCourseSettingPage.isEditButtonEnabled(), "Edit button is in enable state", "Edit button is in disable state" );

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that on clicking Course edit button, settings pop up appears", priority = 1 )
    public void TC003() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC003_Verify that on clicking Course edit button, settings pop up appears\r\n" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName = editCourseSettingPage.generteCourseName();
            coursePage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();
            //Select Custom courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Selecting the option 'Course Title (Ascending)' from the sortBy drop down menu
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursePage.clickFromCourseListingPage( courseName );
            editCourseSettingPage.clickEditSettingBtn();

            // Validate Setting pop up displayed or not
            Log.softAssertThat( editCourseSettingPage.isDisplayedEditSettingsPopUp(), "Navigated to Courses edit settings popup", "Not navigated to Courses edit settings popup" );

            coursePage.clickSaveBtn();
            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all the Text boxs and sections are dispalyed sucessfully on Math course edit popup", priority = 1 )
    public void TC004() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC004_Verify all the Text boxs and sections are dispalyed sucessfully on Math course edit popup" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            // Make a copy of math course
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName = editCourseSettingPage.generteCourseName();
            coursesPage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursesPage.clickFromCourseListingPage( courseName );
            editCourseSettingPage.clickEditSettingBtn();
            coursesPage.nap( browser );//Nap is required for safari execution
            // verify SessionLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            // verify IdleLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            // verify show/limt progreass report section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit progress report" );
            // verify InitialPlacement section
            Log.softAssertThat( editCourseSettingPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );
            // verify Calculater section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.CALCULATOR ), "Calculater section is displayed", "Calculater section is not displayed" );
            // verify Translate section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            // verify Scratchpad section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SCRATCHPAD ), "Scratchpad section is displayed", "Scratchpad section is not displayed" );
            // verify ShowAnswer section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHOW_ANSWER ), "ShowAnswer section is displayd", "ShowAnswer section is not displayed" );
            // verify ExitCourseButton section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed", "ExitCourseButton section is not displayed" );
            // verify SpeedGames section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SPEED_GAMES ), "SpeedGames section is displayed", "SpeedGames section is not displayed" );
            // verify ManualSetCourseLevel section
            Log.softAssertThat( editCourseSettingPage.isDisplayedManuallySetCourseLevelSection( Constants.MANUALLY_SET_COURSE_LEVEL ), "ManuallySetCourseLevel section is displayed", "ManuallySetCourseLevel section is not displayed" );

            coursesPage.clickSaveBtn();
            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Create a copy of math course as Skills, Standard and Settings, Verify all the fields are dispalyed sucessfully on course edit settings popup for respective course", priority = 1 )
    public void TC005() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC005_Create a copy of math course as Skills, Standard and Settings, Verify all the fields are dispalyed sucessfully on course edit settings popup for respective course" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName0 = editCourseSettingPage.generteCourseName();

            // Make a copy of math course by standard
            coursesPage.copyOfCourse( courseName0, Constants.STANDARDS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursesPage.clickFromCourseListingPage( courseName0 );
            editCourseSettingPage.clickEditSettingBtn();

            coursesPage.nap( browser );//Nap is required for safari execution
            // verify SessionLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            // verify IdleLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            // verify show/limt progreass report section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit progress report" );
            // verify InitialPlacement section
            Log.softAssertThat( editCourseSettingPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );
            // verify Calculater section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.CALCULATOR ), "Calculater section is displayed", "Calculater section is not displayed" );
            // verify Translate section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            // verify Scratchpad section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SCRATCHPAD ), "Scratchpad section is displayed", "Scratchpad section is not displayed" );
            // verify ShowAnswer section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHOW_ANSWER ), "ShowAnswer section is displayd", "ShowAnswer section is not displayed" );
            // verify ExitCourseButton section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed", "ExitCourseButton section is not displayed" );
            // verify SpeedGames section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SPEED_GAMES ), "SpeedGames section is displayed", "SpeedGames section is not displayed" );
            // verify ManualSetCourseLevel section
            Log.softAssertThat( editCourseSettingPage.isDisplayedManuallySetCourseLevelSection( Constants.MANUALLY_SET_COURSE_LEVEL ), "ManuallySetCourseLevel section is displayed", "ManuallySetCourseLevel section is not displayed" );
            coursesPage.clickSaveBtn();

            // Make a copy of math course by skill

            CourseListingPage courseListingPage1 = tHomePage.topNavBar.getCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName1 = editCourseSettingPage.generteCourseName();
            coursesPage.copyOfCourse( courseName1, Constants.SKILLS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursesPage.clickFromCourseListingPage( courseName1 );
            editCourseSettingPage.clickEditSettingBtn();
            coursesPage.nap( browser );//Nap is required for safari execution
            // verify SessionLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            // verify IdleLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            // verify show/limt progreass report section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit progress report" );
            // verify InitialPlacement section
            Log.softAssertThat( editCourseSettingPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );
            // verify Calculater section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.CALCULATOR ), "Calculater section is displayed", "Calculater section is not displayed" );
            // verify Translate section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            // verify Scratchpad section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SCRATCHPAD ), "Scratchpad section is displayed", "Scratchpad section is not displayed" );
            // verify ShowAnswer section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHOW_ANSWER ), "ShowAnswer section is displayd", "ShowAnswer section is not displayed" );
            // verify ExitCourseButton section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed", "ExitCourseButton section is not displayed" );
            // verify ManualSetCourseLevel section
            Log.softAssertThat( editCourseSettingPage.isDisplayedManuallySetCourseLevelSection( Constants.MANUALLY_SET_COURSE_LEVEL ), "ManuallySetCourseLevel section is displayed", "ManuallySetCourseLevel section is not displayed" );
            coursesPage.clickSaveBtn();

            // Make a copy of math course by setting

            CourseListingPage courseListingPage2 = tHomePage.topNavBar.getCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName2 = editCourseSettingPage.generteCourseName();
            coursesPage.copyOfCourse( courseName2, Constants.SETTINGS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursesPage.clickFromCourseListingPage( courseName2 );
            editCourseSettingPage.clickEditSettingBtn();
            coursesPage.nap( browser );//Nap is required for safari execution
            // verify SessionLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            // verify IdleLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            // verify show/limt progreass report section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit progress report" );
            // verify InitialPlacement section
            Log.softAssertThat( editCourseSettingPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "InitialPlacement section is displayed", "InitialPlacement section is not displayed" );
            // verify Calculater section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.CALCULATOR ), "Calculater section is displayed", "Calculater section is not displayed" );
            // // verify Translate section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            // verify Scratchpad section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SCRATCHPAD ), "Scratchpad section is displayed", "Scratchpad section is not displayed" );
            // verify ShowAnswer section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHOW_ANSWER ), "ShowAnswer section is displayd", "ShowAnswer section is not displayed" );
            // verify ExitCourseButton section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed", "ExitCourseButton section is not displayed" );
            // verify SpeedGames section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SPEED_GAMES ), "SpeedGames section is displayed", "SpeedGames section is not displayed" );
            // verify ManualSetCourseLevel section
            Log.softAssertThat( editCourseSettingPage.isDisplayedManuallySetCourseLevelSection( Constants.MANUALLY_SET_COURSE_LEVEL ), "ManuallySetCourseLevel section is displayed", "ManuallySetCourseLevel section is not displayed" );
            coursesPage.clickSaveBtn();

            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify all the fields are dispalyed sucessfully on Reading course edit popup", priority = 1 )
    public void TC006() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC006_Verify all the fields are dispalyed sucessfully on Reading course edit popup" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            coursesPage.nap( browser );//Nap is required for safari execution
            // make copy of reading

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String readingCourse = editCourseSettingPage.generteCourseName();
            coursesPage.copyOfCourse( readingCourse, Constants.SETTINGS, Constants.READING );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursesPage.clickFromCourseListingPage( readingCourse );
            editCourseSettingPage.clickEditSettingBtn();
            coursesPage.nap( browser );//Nap is required for safari execution
            // verify SessionLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            // verify IdleLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            // verify show/limt progreass report section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit progress report" );
            // verify InitialPlacement section
            Log.softAssertThat( editCourseSettingPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "Initial Placement section is displayd", "Not diplayed Initial Placement section." );
            // verify LoInformation section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.DISPLAY_LO_INFORMATION ), "Display Lo Information section is displayd", "Not diplayed  Display Lo Information." );
            // verify Translate section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            // verify HelpIconActive section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.HELP_ICON_ACTIVE ), "Help Icon Active section is displayd", "Not diplayed Help Icon Active." );
            // verify SpanishGlossary section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SPANISH_GLOSSARY ), "Spanish Glossary section is displayd", "Not diplayed Spanish Glossary." );
            // verify ExitCourseButton section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed", "ExitCourseButton section is not displayed" );
            // verify GrammerStrand section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.GRAMMER_STRAND ), "Grammar Strand section is displayd", "Not diplayed Grammar Strand." );
            // verify fluency section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.FLUENCY ), "Fluency section is displayd", "Not diplayed Fluency." );
            // verify ManualSetCourseLevel section
            Log.softAssertThat( editCourseSettingPage.isDisplayedManuallySetCourseLevelSection( Constants.MANUALLY_SET_COURSE_LEVEL ), "ManuallySetCourseLevel section is displayed", "ManuallySetCourseLevel section is not displayed" );
            coursesPage.clickSaveBtn();
            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Create a copy of reading course as Skills, Standard and Settings, Verify all the fields are dispalyed sucessfully on course edit settings popup for respective course", priority = 1 )
    public void TC007() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC007_Create a copy of reading course as Skills, Standard and Settings, Verify all the fields are dispalyed sucessfully on course edit settings popup for respective course" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String rStandCourse = editCourseSettingPage.generteCourseName();

            // make copy of reading by standard
            coursesPage.copyOfCourse( rStandCourse, Constants.STANDARDS, Constants.READING );
            tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursesPage.clickFromCourseListingPage( rStandCourse );
            editCourseSettingPage.clickEditSettingBtn();
            coursesPage.nap( browser );//Nap is required for safari execution
            // verify SessionLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            // verify IdleLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            // verify show/limt progreass report section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit progress report" );
            // verify LoInformation section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.DISPLAY_LO_INFORMATION ), "Display Lo Information section is displayd", "Not diplayed  Display Lo Information." );
            // verify Translate section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            // verify HelpIconActive section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.HELP_ICON_ACTIVE ), "Help Icon Active section is displayd", "Not diplayed Help Icon Active." );
            // verify SpanishGlossary section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SPANISH_GLOSSARY ), "Spanish Glossary section is displayd", "Not diplayed Spanish Glossary." );
            // verify ExitCourseButton section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed", "ExitCourseButton section is not displayed" );
            // verify fluency section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHARE_AT_DISTRICT_LEVEL ), "Share at District Level? section is displayd", "Not diplayed Share at District Level?." );
            // verify fluency section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.FLUENCY ), "Fluency section is displayd", "Not diplayed Fluency." );
            coursesPage.clickSaveBtn();

            coursesPage.nap( browser );//required for execution in safari
            CourseListingPage courseListingPage1 = tHomePage.topNavBar.getCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String rSkillCourse = editCourseSettingPage.generteCourseName();
            // make copy of reading by skill
            coursesPage.copyOfCourse( rSkillCourse, Constants.SKILLS, Constants.READING );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursesPage.clickFromCourseListingPage( rSkillCourse );
            editCourseSettingPage.clickEditSettingBtn();
            coursesPage.nap( browser );//Nap is required for safari execution
            // verify SessionLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            // verify IdleLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            // verify show/limt progreass report section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit progress report" );
            // verify LoInformation section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.DISPLAY_LO_INFORMATION ), "Display Lo Information section is displayd", "Not diplayed  Display Lo Information." );
            // verify Translate section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            // verify HelpIconActive section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.HELP_ICON_ACTIVE ), "Help Icon Active section is displayd", "Not diplayed Help Icon Active." );
            // verify SpanishGlossary section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SPANISH_GLOSSARY ), "Spanish Glossary section is displayd", "Not diplayed Spanish Glossary." );
            // verify ExitCourseButton section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed", "ExitCourseButton section is not displayed" );
            // verify fluency section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SHARE_AT_DISTRICT_LEVEL ), "Share at District Level? section is displayd", "Not diplayed Share at District Level?." );
            // verify fluency section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.DROPDOWN, Constants.FLUENCY_RECORDING_TIME ), "Fluency recording time section is displayd", "Not diplayed Fluency recording time." );
            coursesPage.clickSaveBtn();
            coursesPage.nap( browser );//required for execution in safari

            CourseListingPage courseListingPage2 = tHomePage.topNavBar.getCourseListingPage();
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String rSettingCourse = editCourseSettingPage.generteCourseName();
            // make copy of reading by setting
            coursesPage.copyOfCourse( rSettingCourse, Constants.SETTINGS, Constants.READING );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursesPage.clickFromCourseListingPage( rSettingCourse );
            editCourseSettingPage.clickEditSettingBtn();
            coursesPage.nap( browser );//Nap is required for safari execution
            // verify SessionLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SESSION_LENGHT ), "Session length section displayed", "Not displayed Session length section" );
            // verify IdleLength section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.IDLE_TIME ), "Idle Time section is displayed", "Not displayed Idle time section" );
            // verify show/limt progreass report section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.DROPDOWN, Constants.SHOW_LIMIT_PROGRESS ), "Show Limit Progress report is displayd", "Not diplayed Show limit progress report" );
            // verify InitialPlacement section
            Log.softAssertThat( editCourseSettingPage.isDisplayedInitialPlacementSections( Constants.INITIAL_PLACEMENT ), "Initial Placement section is displayd", "Not diplayed Initial Placement section." );
            // verify LoInformation section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.DISPLAY_LO_INFORMATION ), "Display Lo Information section is displayd", "Not diplayed  Display Lo Information." );
            // verify Translate section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.TRANSLATE ), "Translate section is displayed", "Translate section is not displayed" );
            // verify HelpIconActive section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.HELP_ICON_ACTIVE ), "Help Icon Active section is displayd", "Not diplayed Help Icon Active." );
            // verify SpanishGlossary section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.SPANISH_GLOSSARY ), "Spanish Glossary section is displayd", "Not diplayed Spanish Glossary." );
            // verify ExitCourseButton section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsFirstColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.EXIT_COURSE_BUTTON ), "ExitCourseButton section is displayed", "ExitCourseButton section is not displayed" );
            // verify GrammerStrand section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.GRAMMER_STRAND ), "Grammar Strand section is displayd", "Not diplayed Grammar Strand." );
            // verify fluency section
            Log.softAssertThat( editCourseSettingPage.isCourseSettingsSecondColumnDisplayed( Constants.TOGGLE_BUTTON, Constants.FLUENCY ), "Fluency section is displayd", "Not diplayed Fluency." );
            // verify ManualSetCourseLevel section
            Log.softAssertThat( editCourseSettingPage.isDisplayedManuallySetCourseLevelSection( Constants.MANUALLY_SET_COURSE_LEVEL ), "ManuallySetCourseLevel section is displayed", "ManuallySetCourseLevel section is not displayed" );
            coursesPage.clickSaveBtn();
            // Sign out
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

            //
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify on selecting Translate toggle button for Math courses, select languages dropdown is displayed.", priority = 1 )
    public void TC008() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC008_Verify on selecting Translate toggle button for Math courses, select languages dropdown is displayed." + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName = editCourseSettingPage.generteCourseName();
            // make copy of math
            coursesPage.copyOfCourse( courseName, Constants.STANDARDS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursesPage.clickFromCourseListingPage( courseName );
            editCourseSettingPage.clickEditSettingBtn();
            editCourseSettingPage.clickOnTranslate( Constants.TRANSLATE );
            // verify Select language drop down section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isDisplayedLanguagesDropDown(), "Available languages section is displayed", "Available languages section is not displayed" );

            coursesPage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify on deselecting Translate toggle button for Math courses, select languages dropdown is invisible", priority = 1 )
    public void TC009() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "TC009_Verify on deselecting Translate toggle button for Math courses, select languages dropdown is invisible" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName = editCourseSettingPage.generteCourseName();
            // make copy of math
            coursesPage.copyOfCourse( courseName, Constants.STANDARDS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );
            coursesPage.clickFromCourseListingPage( courseName );
            editCourseSettingPage.clickEditSettingBtn();
            editCourseSettingPage.clickOnTranslate( Constants.TRANSLATE );
            editCourseSettingPage.clickOnTranslate( Constants.TRANSLATE );

            // verify Select language drop down section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isNotDisplayedLanguagesDropDown(), "Available languages section is not displayed as expected", "Available languages section is displayed" );

            coursesPage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify that toggle button display sucessfully on edit setting screens", priority = 1 )
    public void TC010() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC010_verify that toggle button display sucessfully on edit setting screens" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName = editCourseSettingPage.generteCourseName();
            coursesPage.copyOfCourse( courseName, Constants.SKILLS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursesPage.clickFromCourseListingPage( courseName );
            editCourseSettingPage.clickEditSettingBtn();

            // verify toggle button is displayed or not
            Log.softAssertThat( editCourseSettingPage.isDisplayedToggleButton(), "ToggleButton is displayed", "ToggleButton is not displayed" );

            coursesPage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify that cancel button display sucessfully on edit setting screens", priority = 1 )
    public void TC011() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "TC011_verify that cancel button display sucessfully on edit setting screens" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            // Get CourseLising Page

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName = editCourseSettingPage.generteCourseName();
            coursesPage.copyOfCourse( courseName, Constants.SKILLS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursesPage.clickFromCourseListingPage( courseName );
            editCourseSettingPage.clickEditSettingBtn();

            // verify Select language drop down section is displayed or not
            Log.softAssertThat( editCourseSettingPage.isDisplayedCancelButton(), "Cancel button is displayed", "Cancel button is not displayed" );

            coursesPage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify that the save button display sucessfully on edit setting screens", priority = 1 )
    public void TC012() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC012_verify that the save button display sucessfully on edit setting screens" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            // Get CourseLising Page

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName = editCourseSettingPage.generteCourseName();
            coursesPage.copyOfCourse( courseName, Constants.SKILLS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursesPage.clickFromCourseListingPage( courseName );
            editCourseSettingPage.clickEditSettingBtn();

            // verify Save button is displayed or not
            Log.softAssertThat( editCourseSettingPage.isDisplayedSaveButton(), "save button is displayed", "save button is not displayed" );

            coursesPage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify the toast message \"Course setting updated successfully.\" is displaying after successfully saving", priority = 1 )
    public void TC013() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC013_Verify the toast message \\\"Course setting updated successfully.\" is displaying after successfully saving" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            // Get CourseLising Page

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName = editCourseSettingPage.generteCourseName();
            coursesPage.copyOfCourse( courseName, Constants.SKILLS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DESCENDING_ORDER );

            coursesPage.clickFromCourseListingPage( courseName );
            editCourseSettingPage.clickEditSettingBtn();
            editCourseSettingPage.clickOnTranslate( "Translate" );
            coursesPage.clickSaveBtn();
            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Teacher is able to edit Course name by clicking on Edit button", priority = 1 )
    public void TC014() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC014_Verify Teacher is able to edit Course name by clicking on Edit button" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password);
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            // Get CourseLising Page

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName = editCourseSettingPage.generteCourseName();
            coursesPage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            coursesPage.clickOnCourseNameFromList( courseName );
            coursesPage.clickEditBtnCourseLevel();
            coursesPage.enterCourseName( CUSTOM_BY_SETTINGS_COURSE );
            coursesPage.clickNextBtn();
            
            coursesPage.clickSaveBtnForEdit();
	    //nap required to wait for the save changes in Edit Setting
            SMUtils.nap(5);
            tHomePage.topNavBar.getCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );
            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );
            coursesPage.clickOnCourseNameFromList( CUSTOM_BY_SETTINGS_COURSE );

            //Assersion
            Log.softAssertThat( coursesPage.isCourseNameUpdated(), "Course name updated successfully", "Course name not updated successfully" );

            // Signout
            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify Teacher is able to edit Grade and Standards by clicking on Edit button", priority = 1 )
    public void TC015() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC015_Verify Teacher is able to edit Grade and Standards by clicking on Edit button" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            // Get CourseLising Page

            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );
            String courseName = editCourseSettingPage.generteCourseName();
            coursesPage.copyOfCourse( courseName, Constants.STANDARDS, Constants.MATH );
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            coursesPage.clickOnCourseNameFromList( courseName );
            coursesPage.clickEditBtnCourseLevel();
            coursesPage.clickNextBtn();
            coursesPage.clickNextBtn();
            coursesPage.clickPopupStandardDropdownBtn();
            coursesPage.clickPopupStandardOrGradesInDropdown( Constants.STANDARDS_LIST.get( 3 ), Constants.STANDARDS );
            //coursesPage.getSkillsDropdownTextforFocusCourse();
            //Assertion
            Log.softAssertThat( coursesPage.isDisplayedSelectedStandardFromDropdown(), "Selected Standard and grade from dropdown are displayed successfully!", "Selected Standard and grade from dropdown are not displayed." );
            coursesPage.clickPopupGradeDropdownBtn();
            coursesPage.clickPopupStandardOrGradesInDropdown( Constants.Students.ALL_GRADES.get( 0 ), Constants.SKILLS );
            //Assertion
            Log.softAssertThat( coursesPage.isDisplayedSelectedGardeFromDropdown(), "Selected Standard and grade from dropdown are displayed successfully!", "Selected Standard and grade from dropdown are not displayed." );
            coursesPage.selectLeftStrandForCourses();
            coursesPage.clickSaveBtnForEdit();

            // Signout

            tHomePage.topNavBar.signOutfromSM();
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify that the user is able to select multiple toggle as enabled at a time amd can save it", priority = 1 )
    public void TC016() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC016_verify that the user is able to select multiple toggle as enabled at a time amd can save it" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            //Select default course from dropdown.
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Generate random course name
            String courseName = editCourseSettingPage.generteCourseName();

            //Create setting base course.
            coursesPage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );

            //traverse to courselisting page.
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursesPage.clickOnCourseNameFromList( courseName );

            //Click on edit button in setting pop up
            editCourseSettingPage.clickEditSettingBtn();

            //Turn on Calculator
            coursesPage.turnONCalculator();

            SMUtils.logDescriptionTC( "SMK-18515 -Verify we are able to edit settings of the Custom Default Math course" );

            //Verify calculator toggle is turned on.
            Log.softAssertThat( coursesPage.verifyCalculatorIsON(), "Toggle button of calculator is enabled", "Toggle button of calculator is not enabled" );

            //Turn on translate
            coursesPage.turnONTranslate();

            //Verify translate toggle is turned on.
            Log.softAssertThat( coursesPage.verifyTranslateIsON(), "Toggle button of translate is enabled", "Toggle button of translate is not enabled" );

            //Turn on shared at district level
            coursesPage.turnONSharedAtDistrictLevel();

            //Verify shared at district level toggle is turned on.
            Log.softAssertThat( coursesPage.verifySharedAtDistrictLevelIsON(), "Toggle button of shared at distict level is enabled", "Toggle button of shared at district level is not enabled" );

            //Turn off speed games
            coursesPage.turnOffSpeedGames();

            //Verify speed games toggle is turned off.
            Log.softAssertThat( coursesPage.verifySpeedGamesIsOff(), "speed Games is off", "speed Games is on" );

            //Click on save button.
            coursesPage.clickSaveBtn();

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that on Course details page, the edit button is not displayed on the screen for assigned Courses", priority = 1 )
    public void TC017() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC017_Verify that on Course details page, the edit button is not displayed on the screen for assigned Courses" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage customCourses = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );

            staticCourseName = customCourses.generateRandomCourseName();

            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            customCourses.nap( browser );//Nap is required for safari execution
            customCourses.copyOfCourse( staticCourseName, Constants.SETTINGS, Constants.MATH );
            customCourses.nap( browser );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name
            customCourses.clickCourseName( staticCourseName );

            //Click on edit button for setting
            assignmentDetailsPage.clickEditSettingBtn();

            //Turn off Initial placement
            customCourses.turnOffInitialPlacement();

            //Click on save button.
            customCourses.clickSaveBtn();
            customCourses.nap( browser );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on the course
            customCourses.clickOnCourseNameFromList( staticCourseName );

            //Click on the assignment
            customCourses.clickAssignBtn();

            //Assign the course to the student
            customCourses.addCourseToStudents();

            //Traverse to the assignment
            customCourses.clickAssignmentSubMenu();

            //Click on the View Assignment
            customCourses.clickOnTheHoveredAssignment( staticCourseName );

            //Assertion
            Log.softAssertThat( !editCourseSettingPage.isEditButtonDisplayed(), "Edit button is not displayed!", "Edit button is displayed" );

            SMUtils.logDescriptionTC(
                    "SMK-18797 - TC039_Verify the Teacher who created the course is not able to 'Edit Seetings' of the course from the Dashboard Courseware Widget>Courses section once all the listed teachers in the Assigned By popup have removed the students from the shared course" );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify updated settings are reflecting for individual students", priority = 1 )
    public void TC019() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC019_Verify updated settings are reflecting for individual students" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            //Select default course from dropdown.
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Generate random course name
            String courseName = editCourseSettingPage.generteCourseName();

            //Create setting base course.
            coursesPage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );

            //traverse to courselisting page.
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursesPage.clickOnCourseNameFromList( courseName );

            //Click on edit button in setting pop up
            editCourseSettingPage.clickEditSettingBtn();

            //select seesion length
            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            //select Idle time
            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            //get session length
            String sessionLenthOfCourseLevel = assignmentDetailsPage.getSessionLength();

            //get idle time
            String idealTimeOfCourseLevel = assignmentDetailsPage.getIdealTime();

            //Turn on Calculator
            coursesPage.turnONCalculator();

            //Verify calculator toggle is turned on.
            boolean calculatorStatusAtCourseLevel = coursesPage.verifyCalculatorIsON();
            Log.softAssertThat( coursesPage.verifyCalculatorIsON(), "Toggle button of calculator is enabled", "Toggle button of calculator is not enabled" );

            //Turn on translate
            coursesPage.turnONTranslate();

            //Verify translate toggle is turned on.
            boolean trnaslateStatusAtCourseLevel = coursesPage.verifyTranslateIsON();
            Log.softAssertThat( coursesPage.verifyTranslateIsON(), "Toggle button of translate is enabled", "Toggle button of translate is not enabled" );

            //Turn on shared at district level
            coursesPage.turnONSharedAtDistrictLevel();

            //Verify shared at district level toggle is turned on.
            boolean sharedAtDistrictStatusAtCourseLevel = coursesPage.verifySharedAtDistrictLevelIsON();
            Log.softAssertThat( coursesPage.verifySharedAtDistrictLevelIsON(), "Toggle button of shared at distict level is enabled", "Toggle button of shared at district level is not enabled" );

            //Turn off speed games
            coursesPage.turnOffSpeedGames();

            //Verify speed games toggle is turned off.
            boolean speesdGamesStatusAtCourseLevel = coursesPage.verifySpeedGamesIsOff();
            Log.softAssertThat( coursesPage.verifySpeedGamesIsOff(), "speed Games is off", "speed Games is on" );

            //Click on save button.
            coursesPage.clickSaveBtn();

            //traverse to courselisting page.
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            // Select course
            coursesPage.clickOnCourseNameFromList( courseName );

            //Click on the assignment
            coursesPage.clickAssignBtn();

            coursesPage.nap( browser );//Nap is required for safari execution

            //Assign the course to the student
            coursesPage.addCourseToStudents();

            //Traverse to the assignment
            coursesPage.clickAssignmentSubMenu();

            //Click on the View Assignment
            coursesPage.clickOnTheHoveredAssignment( courseName );

            coursesPage.nap( browser );//Nap is required for safari execution

            //Click on elliplis
            assignmentDetailsPage.clickDotEllipsisButton();

            // Click on assignement setting option.
            assignmentDetailsPage.clickAssignmentSettingInEllipsis();

            //get session length from student settting page
            String sessionLenthOfStudentLevel = assignmentDetailsPage.getSessionLength();

            //get idle time from student setting page.
            String idealTimeOfStudentLevel = assignmentDetailsPage.getIdealTime();

            //get calculator Status At Student Level
            boolean calculatorStatusAtStudentLevel = coursesPage.verifyCalculatorIsON();

            //get trnaslate Status At Studdent Level
            boolean trnaslateStatusAtStuddentLevel = coursesPage.verifyTranslateIsON();

            //get shared At Distric tStatus At Student Level
            boolean sharedAtDistrictStatusAtStudentLevel = coursesPage.verifySharedAtDistrictLevelIsON();

            //get speesd Games Status At Student Level
            boolean speesdGamesStatusAtStudentLevel = coursesPage.verifySpeedGamesIsOffAtStudentLevel();

            //Asserssion Verify Updated Settings session length and idle time are reflecting for individual students.
            Log.softAssertThat( sessionLenthOfCourseLevel.trim().equals( sessionLenthOfStudentLevel ) && ( idealTimeOfCourseLevel.trim().equals( idealTimeOfStudentLevel ) ),
                    "Updated Settings session length and idle time are reflected for individual students...!", "Updated Settings session length and idle time are not reflected for individual students." );

            //Asserssion Verify Updated Settings calculator, translate, shared at district level speed games are reflecting for individual students.
            Log.softAssertThat(
                    calculatorStatusAtCourseLevel == calculatorStatusAtStudentLevel && trnaslateStatusAtCourseLevel == trnaslateStatusAtStuddentLevel && sharedAtDistrictStatusAtCourseLevel == sharedAtDistrictStatusAtStudentLevel
                            && speesdGamesStatusAtCourseLevel == speesdGamesStatusAtStudentLevel,
                    "Updated Settings calculator, translate, shared at district level speed games are reflected successfully for individual students...!",
                    "Updated Settings calculator, translate, shared at district level speed games are not reflected for individual students." );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify updated settings are reflecting for students present in the group", priority = 1 )
    public void TC020( ITestContext context ) throws Exception {

    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "TC020_Verify updated settings are reflecting for students present in the group" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null,username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            //Select default course from dropdown.
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Generate random course name
            String courseName = editCourseSettingPage.generteCourseName();

            //Create setting base course.
            coursesPage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );

            //traverse to courselisting page.
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursesPage.clickOnCourseNameFromList( courseName );

            //Click on edit button in setting pop up
            editCourseSettingPage.clickEditSettingBtn();

            //select seesion length
            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            //select Idle time
            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            //get session length
            String sessionLenthOfCourseLevel = assignmentDetailsPage.getSessionLength();

            //get idle time
            String idealTimeOfCourseLevel = assignmentDetailsPage.getIdealTime();

            //Turn on Calculator
            coursesPage.turnONCalculator();

            //Verify calculator toggle is turned on.
            boolean calculatorStatusAtCourseLevel = coursesPage.verifyCalculatorIsON();
            Log.softAssertThat( coursesPage.verifyCalculatorIsON(), "Toggle button of calculator is enabled", "Toggle button of calculator is not enabled" );

            //Turn on translate
            coursesPage.turnONTranslate();

            //Verify translate toggle is turned on.
            boolean trnaslateStatusAtCourseLevel = coursesPage.verifyTranslateIsON();
            Log.softAssertThat( coursesPage.verifyTranslateIsON(), "Toggle button of translate is enabled", "Toggle button of translate is not enabled" );

            //Turn on shared at district level
            coursesPage.turnONSharedAtDistrictLevel();

            //Verify shared at district level toggle is turned on.
            boolean sharedAtDistrictStatusAtCourseLevel = coursesPage.verifySharedAtDistrictLevelIsON();
            Log.softAssertThat( coursesPage.verifySharedAtDistrictLevelIsON(), "Toggle button of shared at distict level is enabled", "Toggle button of shared at district level is not enabled" );

            //Turn off speed games
            coursesPage.turnOffSpeedGames();

            //Verify speed games toggle is turned off.
            boolean speesdGamesStatusAtCourseLevel = coursesPage.verifySpeedGamesIsOff();
            Log.softAssertThat( coursesPage.verifySpeedGamesIsOff(), "speed Games is off", "speed Games is on" );

            //Click on save button.
            coursesPage.clickSaveBtn();

            //traverse to group tab
            GroupPage groupsTab = tHomePage.topNavBar.navigateToGroupsTab();

            //traverse to course listing page.
            tHomePage.topNavBar.getCourseListingPage();

            CoursesPage coursepage = new CoursesPage( driver );

            //Click course by name.
            coursepage.clickCourseName( courseName );

            //Click on the assignment	
            coursesPage.clickAssignBtn();

            //Assign the course to the student
            coursesPage.addCourseToGroups();

            //traverse to group tab
            tHomePage.topNavBar.navigateToGroupsTab();
            
            //Get groupname to be clicked
            List<String> groupnamefromUI = groupsTab.getGroupNamesFromGroupsTab();
            String groupname = groupnamefromUI.get(0);

            //click on view group button.
            groupsTab.viewGroup( groupname);

            //Click assignment side nav bar
            groupsTab.clickAssignmentSideBar();
            coursesPage.nap( browser );//Nap is required for safari execution
            

            //Click om view assignment button.
            groupsTab.clickViewAssignmentButtonBasedOnCourse( courseName );
            SMUtils.nap(5);

            coursesPage.nap( browser );//Nap is required for safari execution
            //Click on ellipsis icon
            assignmentDetailsPage.clickDotEllipsisButton();

            //Click Assignment setting in ellipsis
            assignmentDetailsPage.clickAssignmentSettingInEllipsis();

            //get session length from student settting page
            String sessionLenthOfStudentLevel = assignmentDetailsPage.getSessionLength();

            //get idle time from group> assignment> student setting page.
            String idealTimeOfStudentLevel = assignmentDetailsPage.getIdealTime();

            //get calculator Status At group> assignment> student Level
            boolean calculatorStatusAtStudentLevel = coursesPage.verifyCalculatorIsON();

            //get trnaslate Status At group> assignment> student Level
            boolean trnaslateStatusAtStuddentLevel = coursesPage.verifyTranslateIsON();

            //get shared At Distric Status At group> assignment> student Level
            boolean sharedAtDistrictStatusAtStudentLevel = coursesPage.verifySharedAtDistrictLevelIsON();

            //get speesd Games Status At group> assignment> student Level
            boolean speesdGamesStatusAtStudentLevel = coursesPage.verifySpeedGamesIsOffAtStudentLevel();

            //Asserssion Verify Updated Settings session length and idle time are reflecting for individual students in group.
            Log.softAssertThat( sessionLenthOfCourseLevel.trim().equals( sessionLenthOfStudentLevel ) && ( idealTimeOfCourseLevel.trim().equals( idealTimeOfStudentLevel ) ),
                    "Updated Settings session length and idle time are reflected for individual students in group...!", "Updated Settings session length and idle time are not reflected for individual students in group." );

            //Asserssion Verify Updated Settings calculator, translate, shared at district level speed games are reflecting for individual students in group.
            Log.softAssertThat(
                    calculatorStatusAtCourseLevel == calculatorStatusAtStudentLevel && trnaslateStatusAtCourseLevel == trnaslateStatusAtStuddentLevel && sharedAtDistrictStatusAtCourseLevel == sharedAtDistrictStatusAtStudentLevel
                            && speesdGamesStatusAtCourseLevel == speesdGamesStatusAtStudentLevel,
                    "Updated Settings calculator, translate, shared at district level speed games are reflected successfully for individual students in group...!",
                    "Updated Settings calculator, translate, shared at district level speed games are not reflected for individual students in group." );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify updated course settings are displaying under settings section while assigning the course", priority = 1 )
    public void TC021() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC021_Verify updated course settings are displaying under settings section while assigning the course" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            //Select default course from dropdown.
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Generate random course name
            String courseName = editCourseSettingPage.generteCourseName();

            //Create setting base course.
            coursesPage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );

            //traverse to courselisting page.
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursesPage.clickOnCourseNameFromList( courseName );

            //Click on edit button in setting pop up
            editCourseSettingPage.clickEditSettingBtn();

            //select seesion length
            assignmentDetailsPage.selectValueFromDropDownSessionLength( Constants.SESSION_LENGHT_SELECTED );

            //select Idle time
            assignmentDetailsPage.selectValueFromDropDownIdleTime( Constants.IDEAL_TIME_SELECTED );

            //get session length
            String sessionLenthOfCourseLevel = assignmentDetailsPage.getSessionLength();

            //get idle time
            String idealTimeOfCourseLevel = assignmentDetailsPage.getIdealTime();

            //Turn on Calculator
            coursesPage.turnONCalculator();

            //Verify calculator toggle is turned on.
            boolean calculatorStatusAtCourseLevel = coursesPage.verifyCalculatorIsON();
            Log.softAssertThat( coursesPage.verifyCalculatorIsON(), "Toggle button of calculator is enabled", "Toggle button of calculator is not enabled" );

            //Turn on translate
            coursesPage.turnONTranslate();

            //Verify translate toggle is turned on.
            boolean trnaslateStatusAtCourseLevel = coursesPage.verifyTranslateIsON();
            Log.softAssertThat( coursesPage.verifyTranslateIsON(), "Toggle button of translate is enabled", "Toggle button of translate is not enabled" );

            //Turn on shared at district level
            coursesPage.turnONSharedAtDistrictLevel();

            //Verify shared at district level toggle is turned on.
            boolean sharedAtDistrictStatusAtCourseLevel = coursesPage.verifySharedAtDistrictLevelIsON();
            Log.softAssertThat( coursesPage.verifySharedAtDistrictLevelIsON(), "Toggle button of shared at distict level is enabled", "Toggle button of shared at district level is not enabled" );

            //Turn off speed games
            coursesPage.turnOffSpeedGames();

            //Verify speed games toggle is turned off.
            boolean speesdGamesStatusAtCourseLevel = coursesPage.verifySpeedGamesIsOff();
            Log.softAssertThat( coursesPage.verifySpeedGamesIsOff(), "speed Games is off", "speed Games is on" );

            //Click on save button.
            coursesPage.clickSaveBtn();

            //traverse to courseware page.
            CoursesPage coursepage = new CoursesPage( driver );

            // Select course
            coursepage.clickCourseName( courseName );

            //Click on the assignment
            coursesPage.clickAssignBtn();

            //get session length setting from Assign To pop up.
            String sessionLenthAtAssignmentLevel = assignmentDetailsPage.getSessionLength();

            //get idle time setting from Assign To pop up.
            String idealTimeAtAssignementLevel = assignmentDetailsPage.getIdealTime();

            //get calculator Status from Assign To pop up.
            boolean calculatorStatusAtAssignmentLevel = coursesPage.verifyCalculatorIsON();

            //get trnaslate Status from Assign To pop up.
            boolean trnaslateStatusAtAssignemntLevel = coursesPage.verifyTranslateIsON();

            //get shared At Distric tStatus from Assign To pop up.
            boolean sharedAtDistrictStatusAtAssignmentLevel = coursesPage.verifySharedAtDistrictLevelIsON();

            //get speesd Games Status from Assign To pop up.
            boolean speesdGamesStatusAtAssignmentLevel = coursesPage.verifySpeedGamesIsOff();

            //Asserssion Verify Updated Settings session length and idle time are reflecting for Assign To pop up.
            Log.softAssertThat( sessionLenthOfCourseLevel.trim().equals( sessionLenthAtAssignmentLevel ) && ( idealTimeOfCourseLevel.trim().equals( idealTimeAtAssignementLevel ) ),
                    "Updated Settings session length and idle time are displayed successfully under settings section while assigning the course...!",
                    "Updated Settings session length and idle time are not displayed under settings section while assigning the course." );

            //Asserssion Verify Updated Settings calculator, translate, shared at district level speed games are reflecting for Assign To pop up.
            Log.softAssertThat(
                    calculatorStatusAtCourseLevel == calculatorStatusAtAssignmentLevel && trnaslateStatusAtCourseLevel == trnaslateStatusAtAssignemntLevel && sharedAtDistrictStatusAtCourseLevel == sharedAtDistrictStatusAtAssignmentLevel
                            && speesdGamesStatusAtCourseLevel == speesdGamesStatusAtAssignmentLevel,
                    "Updated Settings calculator, translate, shared at district level speed games are are displayed successfully under settings section while assigning the course...!",
                    "Updated Settings calculator, translate, shared at district level speed games are not are displayed  under settings section while assigning the course." );

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify teacher is not able to save updated course settings until selecting Available Languages dropdown option when Translate is enabled", priority = 1 )
    public void TC022() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC022_Verify teacher is not able to save updated course settings until selecting Available Languages dropdown option when Translate is enabled" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();
            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            //Select default course from dropdown.
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Generate random course name
            String courseName = editCourseSettingPage.generteCourseName();

            //Create setting base course.
            coursesPage.copyOfCourse( courseName, Constants.SETTINGS, Constants.MATH );

            //Get Course listing page.
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click course by name
            coursesPage.clickOnCourseNameFromList( courseName );

            //Click edit setting button.
            editCourseSettingPage.clickEditSettingBtn();

            //Turn on translate
            coursesPage.turnONTranslate();

            //Click on language dropdown
            coursesPage.clickLanguageDropdown();

            //disselect all language
            coursesPage.clickSelectAllCheckbox();

            //Asserssion
            Log.softAssertThat( coursesPage.isSaveBtnDisabled(), "Save button is disabled as expected and teacher is not able to save updated settings until he selects atleast one language...!",
                    "Save button is enabled and teacher is able to save updated settings until he selects atleast one language." );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "verify that the user is able to select multiple toggle as enabled at a time amd can save it for Reading course", priority = 1 )
    public void TC024() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC016_verify that the user is able to select multiple toggle as enabled at a time amd can save it" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            //Select default course from dropdown.
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Generate random course name
            String courseName = editCourseSettingPage.generteCourseName();

            //Create setting base course.
            coursesPage.copyOfCourse( courseName, Constants.SETTINGS, Constants.READING );

            //traverse to courselisting page.
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursesPage.clickOnCourseNameFromList( courseName );

            //Click on edit button in setting pop up
            editCourseSettingPage.clickEditSettingBtn();

            SMUtils.logDescriptionTC( "SMK-18516 - Verify we are able to edit settings of the Custom Default Reading course" );

            //Turn on shared at district level
            coursesPage.turnONSharedAtDistrictLevel();

            //Verify shared at district level toggle is turned on.
            Log.softAssertThat( coursesPage.verifySharedAtDistrictLevelIsON(), "Toggle button of shared at distict level is enabled", "Toggle button of shared at district level is not enabled" );

            //Click on save button.
            coursesPage.clickSaveBtn();

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that the user is able to select multiple toggle as enabled at a time amd can save it for Custom Focus Reading course", priority = 1 )
    public void TC025() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC016_verify that the user is able to select multiple toggle as enabled at a time amd can save it" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            //Select default course from dropdown.
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Generate random course name
            String courseName = editCourseSettingPage.generteCourseName();

            //Create setting base course.
            coursesPage.copyOfCourse( courseName, Constants.STANDARDS, Constants.SM_FOCUS_READING_GRADE1 );

            //traverse to courselisting page.
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursesPage.clickOnCourseNameFromList( courseName );

            //Click on edit button in setting pop up
            editCourseSettingPage.clickEditSettingBtn();

            SMUtils.logDescriptionTC( "SMK-18517 - Verify we are able to edit settings of the Custom Focus Reading course" );
           
            //Verify shared at district level toggle is turned on.
            Log.softAssertThat( coursesPage.verifySharedAtDistrictLevelIsON(), "Toggle button of shared at distict level is enabled", "Toggle button of shared at district level is not enabled" );

            //Click on save button.
            coursesPage.clickSaveBtn();

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify that the user is able to select multiple toggle as enabled at a time amd can save it for Custom Focus Math course", priority = 1 )
    public void TC026() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
        Log.testCaseInfo( "TC016_verify that the user is able to select multiple toggle as enabled at a time amd can save it" + " <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            SMUtils.waitForSpinnertoDisapper( driver );
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password);
            SMUtils.nap( 10 );
            SMUtils.waitForSpinnertoDisapper( driver );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            CoursesPage coursesPage = tHomePage.topNavBar.navigateToCourseListingPage();
            SMUtils.waitForSpinnertoDisapper( driver );

            // Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            AssignmentDetailsPage assignmentDetailsPage = new AssignmentDetailsPage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );

            //Select default course from dropdown.
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Generate random course name
            String courseName = editCourseSettingPage.generteCourseName();

            //Create setting base course.
            coursesPage.copyOfCourse( courseName, Constants.STANDARDS, Constants.SM_FOCUS_MATH_GRADE1 );

            //traverse to courselisting page.
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursesPage.clickOnCourseNameFromList( courseName );

            //Click on edit button in setting pop up
            editCourseSettingPage.clickEditSettingBtn();

            SMUtils.logDescriptionTC( "SMK-18518 - Verify we are able to edit settings of the Custom Focus Math course" );
	    
            //Verify shared at district level toggle is turned on.
            Log.softAssertThat( coursesPage.verifySharedAtDistrictLevelIsON(), "Toggle button of shared at distict level is enabled", "Toggle button of shared at district level is not enabled" );

            //Click on save button.
            coursesPage.clickSaveBtn();

            // Sign out from the SM_Application
            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18249 - TC001_Verify if teacher is able to see the updated values in the custom course created by Settings from Default Math", priority = 1, groups = { "SMK-54702", "Courses", "courseListing" } )
    public void tcSMEditCourseSettings027() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18249 - TC001_Verify if teacher is able to see the updated values in the custom course created by Settings from Default Math<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18249 - TC001_Verify if teacher is able to see the updated values in the custom course created by Settings from Default Math" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.SETTINGS, Constants.MATH );
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SHOW_ANSWER_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SCRATCH_PAD_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.CALCULATOR_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SHOW_ANSWER_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for show answer", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SCRATCH_PAD_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for scratch pad", "Settings not saved successfully" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.logDescriptionTC( "SMK-18257 - TC009_Verify if teacher is able to see the updated values in the custom course created from Custom course created by Settings from Default Math" );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newCourseName );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SHOW_ANSWER_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SCRATCH_PAD_LABEL );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.CALCULATOR_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SHOW_ANSWER_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for show answer", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SCRATCH_PAD_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for scratch pad", "Settings not saved successfully" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18251 - TC003_Verify if teacher is able to see the updated values in the custom course created by Skills from Default Math", priority = 1, groups = { "SMK-54702", "Courses", "Edit_Course_Settings" } )
    public void tcSMEditCourseSettings028() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18251 - TC003_Verify if teacher is able to see the updated values in the custom course created by Skills from Default Math<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18251 - TC003_Verify if teacher is able to see the updated values in the custom course created by Skills from Default Math" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.SKILLS, Constants.MATH );
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SHOW_ANSWER_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SCRATCH_PAD_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.CALCULATOR_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SHOW_ANSWER_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for show answer", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SCRATCH_PAD_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for scratch pad", "Settings not saved successfully" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            SMUtils.logDescriptionTC( "SMK-18258 - TC010_Verify if teacher is able to see the updated values in the custom course created from Custom course created by Skill from Default Math" );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newCourseName );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SHOW_ANSWER_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SCRATCH_PAD_LABEL );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.CALCULATOR_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SHOW_ANSWER_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for show answer", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SCRATCH_PAD_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for scratch pad", "Settings not saved successfully" );

            SMUtils.logDescriptionTC( "SMK- - TC009_Verify if teacher is able to see the updated values in the custom course created from Custom course created by Settings from Default Math" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18253 - TC005_Verify if teacher is able to see the updated values in the custom course created by Standard from Default Math", priority = 1, groups = { "SMK-54702", "Courses", "Edit_Course_Settings" } )
    public void tcSMEditCourseSettings029() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18253 - TC005_Verify if teacher is able to see the updated values in the custom course created by Standard from Default Math<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18253 - TC005_Verify if teacher is able to see the updated values in the custom course created by Standard from Default Math" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.MATH );
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, "2 Minutes" );

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SHOW_ANSWER_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SCRATCH_PAD_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.CALCULATOR_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SHOW_ANSWER_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for show answer", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SCRATCH_PAD_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for scratch pad", "Settings not saved successfully" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newCourseName );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SHOW_ANSWER_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SCRATCH_PAD_LABEL );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, "2 Minutes" );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18259 - TC011_Verify if teacher is able to see the updated values in the custom course created from Custom course created by Standard from Default Math" );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.CALCULATOR_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SHOW_ANSWER_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for show answer", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SCRATCH_PAD_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for scratch pad", "Settings not saved successfully" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18250 - TC002_Verify if teacher is able to see the updated values in the custom course created by Settings from Default Reading", priority = 1, groups = { "SMK-54702", "Courses", "Edit_Course_Settings" } )
    public void tcSMEditCourseSettings030() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18250 - TC002_Verify if teacher is able to see the updated values in the custom course created by Settings from Default Reading<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18250 - TC002_Verify if teacher is able to see the updated values in the custom course created by Settings from Default Reading" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.SETTINGS, Constants.READING );
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.DISPLAY_LO_INFORMATION ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for display lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.HELP_ICON_ACIVE ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.EXIT_COURSE_BUTTON_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newCourseName );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18260 - TC012_Verify if teacher is able to see the updated values in the custom course created from Custom course created by Settings from Default Reading" );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.DISPLAY_LO_INFORMATION ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for display lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.HELP_ICON_ACIVE ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.EXIT_COURSE_BUTTON_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18252 - TC004_Verify if teacher is able to see the updated values in the custom course created by Skills from Default Reading", priority = 1, groups = { "SMK-54702", "Courses", "Edit_Course_Settings" } )
    public void tcSMEditCourseSettings031() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18252 - TC004_Verify if teacher is able to see the updated values in the custom course created by Skills from Default Reading<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18252 - TC004_Verify if teacher is able to see the updated values in the custom course created by Skills from Default Reading" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.SKILLS, Constants.READING );
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.DISPLAY_LO_INFORMATION ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for display lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.HELP_ICON_ACIVE ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.EXIT_COURSE_BUTTON_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newCourseName );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, "2 Minutes" );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18261 - TC013_Verify if teacher is able to see the updated values in the custom course created from Custom course created by Skill from Default Reading" );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.DISPLAY_LO_INFORMATION ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for display lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.HELP_ICON_ACIVE ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.EXIT_COURSE_BUTTON_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18254 - TC006_Verify if teacher is able to see the updated values in the custom course created by Standard from Default Reading", priority = 1, groups = { "SMK-54702", "Courses", "Edit_Course_Settings" } )
    public void tcSMEditCourseSettings032() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18254 - TC006_Verify if teacher is able to see the updated values in the custom course created by Standard from Default Reading<small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password);
            SMUtils.logDescriptionTC( "SMK-18254 - TC006_Verify if teacher is able to see the updated values in the custom course created by Standard from Default Reading" );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.DEFAULT_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.READING );
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.DISPLAY_LO_INFORMATION ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for display lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.HELP_ICON_ACIVE ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.EXIT_COURSE_BUTTON_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newCourseName );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18262 - TC014_Verify if teacher is able to see the updated values in the custom course created from Custom course created by Standard from Default Reading" );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.DISPLAY_LO_INFORMATION ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for display lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.HELP_ICON_ACIVE ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.EXIT_COURSE_BUTTON_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18256 - TC008_Verify if teacher is able to see the updated values in the custom course created from SM Focus Reading Grade1 ", priority = 1, groups = { "SMK-54702", "Courses", "Edit_Course_Settings" } )
    public void tcSMEditCourseSettings033() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18256 - TC008_Verify if teacher is able to see the updated values in the custom course created from SM Focus Reading Grade1 small><b><i>[" + browser + "]</b></i></small>" );

    	try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18256- TC008_Verify if teacher is able to see the updated values in the custom course created from SM Focus Reading Grade1 " );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.SM_FOCUS_READING_GRADE1 );
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.DISPLAY_LO_INFORMATION ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for display lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.HELP_ICON_ACIVE ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.EXIT_COURSE_BUTTON_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newCourseName );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.DISPLAY_LO_INFORMATION );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.HELP_ICON_ACIVE );
            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.OFF_CAPS, Constants.EXIT_COURSE_BUTTON_LABEL );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18264 - TC016_Verify if teacher is able to see the updated values in the custom course created from Custom course created from SM Focus Reading Grade1" );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.DISPLAY_LO_INFORMATION ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for display lo information",
                    "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.HELP_ICON_ACIVE ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for help icon active", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.EXIT_COURSE_BUTTON_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for exit course button",
                    "Settings not saved successfully" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "SMK-18255 - TC007_Verify if teacher is able to see the updated values in the custom course created from SM Focus Math Grade1 ", priority = 1, groups = { "SMK-54702", "Courses", "Edit_Course_Settings" } )
    public void tcSMEditCourseSettings034() throws Exception {
    	// Get driver
    	EventFiringWebDriver driver = new EventFiringWebDriver(WebDriverFactory.get( browser ));
    	EventListener eventListner = new EventListener();
    	driver.register(eventListner);
    	Log.testCaseInfo( "SMK-18255 - TC007_Verify if teacher is able to see the updated values in the custom course created from SM Focus Math Grade1 <small><b><i>[" + browser + "]</b></i></small>" );

        try {
            LoginWrapper.loginToSuccessMakerAsTeacher( driver, smUrl, UserType.BASIC, null, username, password );
            SMUtils.logDescriptionTC( "SMK-18255 - TC007_Verify if teacher is able to see the updated values in the custom course created from SM Focus Math Grade1 " );
            TeacherHomePage tHomePage = new TeacherHomePage( driver );
            EditCourseSettingPage editCourseSettingPage = new EditCourseSettingPage( driver );
            boolean courseWidgetDisplayed = tHomePage.isCoursesWidgetDisplayed();
            Log.softAssertThat( courseWidgetDisplayed, "Course widget is diplayed", "Course widget is not diplayed" );

            CoursesPage coursePage = tHomePage.topNavBar.navigateToCourseListingPage();
            String newlyCreatedCourse = null;

            newlyCreatedCourse = coursePage.generateRandomCourseName();

            //Get CourseLising Page
            CourseListingPage courseListingPage = tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.FOCUS_COURSES );

            //Make a copy of the course
            coursePage.copyOfCourse( newlyCreatedCourse, Constants.STANDARDS, Constants.SM_FOCUS_MATH_GRADE1 );
            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newlyCreatedCourse ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newlyCreatedCourse );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SHOW_ANSWER_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SCRATCH_PAD_LABEL );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.nap( 10 );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.CALCULATOR_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SHOW_ANSWER_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for show answer", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SCRATCH_PAD_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for scratch pad", "Settings not saved successfully" );

            //Get CourseLising Page
            tHomePage.topNavBar.getCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            coursePage.clickFromCourseListingPage( newlyCreatedCourse );
            coursePage.clickMakeCopyBtn();
            String newCourseName = coursePage.generateRandomCourseName();
            coursePage.enterCourseName( newCourseName );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickNextBtn();
            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );
            coursePage.clickCreateBtn();

            tHomePage.topNavBar.navigateToCourseListingPage();

            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            Log.softAssertThat( coursePage.verifyCourseRemovedSuccessfully( newCourseName ), "Course is created successfully", "Course is not created" );

            tHomePage.topNavBar.navigateToCourseListingPage();
            //Select Custom Courses from the first drop down
            courseListingPage.selectCourseTypeFromDropDown( Constants.MY_CUSTOM_COURSES );

            //Sort by date descending
            courseListingPage.selectsortByDropDown( Constants.CHECK_DATE_DESCENDING_ORDER );

            //Click on course name from list.
            coursePage.clickFromCourseListingPage( newCourseName );

            // Verify whether the course details page is loaded
            Log.softAssertThat( editCourseSettingPage.isLoadedCourseDetailsPage(), "Course detail page is loaded", "Course detail page is not loaded" );

            editCourseSettingPage.clickEditSettingBtn();

            coursePage.changeStatusOfTheRadioButton( Constants.FIRST_COLUMN, Constants.ON_CAPS, Constants.CALCULATOR_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SHOW_ANSWER_LABEL );
            coursePage.changeStatusOfTheRadioButton( Constants.SECOND_COLUMN, Constants.OFF_CAPS, Constants.SCRATCH_PAD_LABEL );

            coursePage.selectTheDropdownValue( Constants.SESSION_LENGTH_LABEL, Constants.SIX_MINUTES );

            coursePage.selectTheDropdownValue( Constants.IDLE_TIME_LABEL, Constants.TWO_MINUTES );

            //Click on save button.
            coursePage.clickSaveBtn();

            //Wait for spinner to go away
            SMUtils.waitForSpinnertoDisapper( driver );

            SMUtils.logDescriptionTC( "SMK-18263 - TC015_Verify if teacher is able to see the updated values in the custom course created from Custom course created from SM Focus Math Grade 1" );

            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SESSION_LENGTH_LABEL ).equals( Constants.SIX ), "Settings applied successfully for session length", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.IDLE_TIME_LABEL ).equals( Constants.TWO ), "Settings applied successfully for idle time", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.CALCULATOR_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for calculator", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SHOW_ANSWER_LABEL ).equalsIgnoreCase( Constants.ON ), "Settings applied successfully for show answer", "Settings not saved successfully" );
            Log.softAssertThat( coursePage.getTheSettingsOfTheCourse( Constants.SCRATCH_PAD_LABEL ).equalsIgnoreCase( Constants.OFF ), "Settings applied successfully for scratch pad", "Settings not saved successfully" );

            tHomePage.topNavBar.signOutfromSM();

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
