package com.savvas.sm.common.utils.apiconstants;

public interface LoginAPIConstants {

    // Constants - API
    public static String ORGID = "org-id";
    public static String USERID = "user-id";
    public static String AUTHORIZATION = "Authorization";
    public static String BEARER = "Bearer ";

    // Constants - Endpoints
    public static String GET_LOGIN_AUTHORIZATION_ENDPOINT = "/lms/web/api/v2/profile/accessParameters";
    public static String GET_DASHBOARD_API_ENDPOINT = "/lms/web/api/v2/profile/dashboard";

    //Static test data for LoginAuthorization testing
    public static String authpassword = "testing123$";
    public static String Districtpassword = "password1";
    public static String valid_Teacher_OrgId_Login_Auth = "8a720bec7e850e85017e909d9857032e";
    public static String valid_Teacher_UserId_Login_Auth = "ffffffff61efc620af88cb00305cec68";
    public static String Teacher_UserName_Login_Auth = "smautoteacherbasic410993049651900";
    public static String invalid_User_Id_Login_Auth = "ffffffff61f2a46f4def5600303134b1";
    public static String invalid_Org_Id_Login_Auth = "8a7200f77de565ac017e1ec313f10471";
    public static String valid_Student_OrgId_Login_Auth = "8a720bec7e850e85017e90a1636f0332";
    public static String valid_Student_UserId_Login_Auth = "ffffffff61efc71aaf88cb00305cec70";
    public static String Student_UserName_Login_Auth = "smuserrumba411243695440500";
    public static String valid_District_CustomerAdmin_UserName_Auth = "customeradmin3";
    public static String Teacher_UserName = "smautoteacherbasic333450856255100";
    public static String Student_UserName = "smuserrumba411598580885800";
    public static String invalid_Teacher_UserName_Login_Auth = "tchun_10000000000000000000@sm2022auto";
    public static String invalid_Student_UserName_Login_Auth = "stuun20001862@sm2022auto";

}
