package com.savvas.sm.api.tests.smnew.license;

import java.util.HashMap;

import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.apiconstants.LicenseAPIConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Admins;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

/***
 * This class contains test scripts for license consumption report from lms
 * 
 * @author madhan.nagarathinam
 *
 */

public class GetLicenseDetailsTest extends BaseAPITest {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    public static String school = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );
    public static String teacherDetails = null;
    public static String teacherUserName, teacherUserId;
    public static String studentDetails1 = null;
    public static String studentUserName1, studentUserId1;
    public static String districtAdminDetails = null;
    public static String districtAdminUserName, districtAdminUserId;
    public static String schoolAdminDetails = null;
    public static String schoolAdminUserName, schoolAdminUserId;
    public static String savvasAdminDetails = null;
    public static String savvasAdminUserName, savvasAdminUserId;
    private String orgId;
    private String savvasAdminOrgId;

    private String smUrl;
    private Response response;
    private String password = LicenseAPIConstants.password;

    @BeforeClass(alwaysRun = true)
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
        orgId = RBSDataSetup.organizationIDs.get( school );

        // Fetching Admin Details
        districtAdminDetails = RBSDataSetup.adminDetails.get( Admins.DISTRICT_ADMIN );
        districtAdminUserName = SMUtils.getKeyValueFromResponse( districtAdminDetails, "userName" );
        districtAdminUserId = SMUtils.getKeyValueFromResponse( districtAdminDetails, "userId" );

        schoolAdminDetails = RBSDataSetup.adminDetails.get( Admins.SCHOOL_ADMIN );
        schoolAdminUserName = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "userName" );
        schoolAdminUserId = SMUtils.getKeyValueFromResponse( schoolAdminDetails, "userId" );

        savvasAdminDetails = RBSDataSetup.adminDetails.get( Admins.SAVVAS_ADMIN );
        savvasAdminUserName = SMUtils.getKeyValueFromResponse( savvasAdminDetails, "userName" );
        savvasAdminUserId = SMUtils.getKeyValueFromResponse( savvasAdminDetails, "userId" );
        savvasAdminOrgId = SMUtils.getKeyValueFromResponse( savvasAdminDetails, "primaryOrgId" );
        ;

        // Fetching Teacher Details
        teacherDetails = RBSDataSetup.getMyTeacher( school );
        teacherUserName = SMUtils.getKeyValueFromResponse( teacherDetails, "userName" );
        teacherUserId = SMUtils.getKeyValueFromResponse( teacherDetails, "userId" );
        Log.message( teacherUserName );

        // Fetching Student Details
        studentDetails1 = RBSDataSetup.getMyStudent( school, teacherUserName );
        studentUserId1 = SMUtils.getKeyValueFromResponse( studentDetails1, "userId" );
        studentUserName1 = SMUtils.getKeyValueFromResponse( studentDetails1, "userName" );

    }

    /**
     * Method for testing license consumption API-Positive cases.
     * 
     * @param tcID
     * @throws Exception
     */

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "Smoke TC_001", "smoke_test_case", "P1", "SMK-51380", "Access license service from LMS", "API" }, priority = 1 )
    public void getLicenseServicesFromLMSTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        // End point for API
        String endPoint = LicenseAPIConstants.GET_LICENSESERVICE_ENDPOINT;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {
            case "VALID":
                headers.put( LicenseAPIConstants.ORGID, orgId );
                headers.put( LicenseAPIConstants.USERID, schoolAdminUserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( schoolAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( headers + "" );
                break;

            case "VALID_TEACHER":
                headers.put( LicenseAPIConstants.ORGID, orgId );
                headers.put( LicenseAPIConstants.USERID, teacherUserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( headers + "" );
                break;

            case "SCH_CA":
                headers.put( LicenseAPIConstants.ORGID, orgId );
                headers.put( LicenseAPIConstants.USERID, schoolAdminUserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( schoolAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( headers + "" );
                break;

            case "SAVVAS_ADMIN":
                headers.put( LicenseAPIConstants.ORGID, savvasAdminOrgId );
                headers.put( LicenseAPIConstants.USERID, savvasAdminUserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( savvasAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( headers + "" );
                break;

            case "STUDENT":
                headers.put( LicenseAPIConstants.ORGID, orgId );
                headers.put( LicenseAPIConstants.USERID, studentUserId1 );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                break;
        }

        response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint );
        int actual_StatusCode = response.getStatusCode();

        Log.assertThat( actual_StatusCode == Integer.parseInt( expected_StatusCode ), "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode );
        Log.message( response.getBody().asString() );
        String licenseId = getLicenseIdFromResponse( response.getBody().asString(), "data" );
        String modifiedResponse = response.getBody().asString().replace( licenseId, "licenseId" );
        Log.message( modifiedResponse );
        Log.assertThat( new SMAPIProcessor().isSchemaValid( "getLicenseService", expected_StatusCode, modifiedResponse ), "Schema is returned as expected.", "Schema is not as expected." );

        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC:01", "200", "Verify 200 status code and response body when customer admin user-id with respective parent org-id is given in the headers", "VALID" },
                { "TC:02", "200", "Verify 200 status code and response body when teacher user-id with respective org-id is given in the headers", "VALID_TEACHER" },
                { "TC:03", "200", "Verify 200 status code and response body when school customer admin user-id with respective school org-id is given in the headers", "SCH_CA" },
                { "TC:04", "200", "Verify 200 status code and response body when savvas admin user-id with any org-id is given in the headers", "SAVVAS_ADMIN" },
                { "TC:05", "200", "Verify 200 status code and response body, when valid student user-id and valid respective org-id is given", "STUDENT" } };
        return data;

    }

    /**
     * Method for testing license consumption API-Positive cases.
     * 
     * @param tcID
     * @throws Exception
     */

    @Test ( dataProvider = "getDataForNegativieScenarios", groups = { "Smoke TC_002", "SMK-51380", "Access license service from LMS", "API" }, priority = 2 )
    public void getLicenseServicesFromLMSTest002( String testcaseName, int expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<String, String>();
        // End point for API
        String endPoint = LicenseAPIConstants.GET_LICENSESERVICE_ENDPOINT;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {
            case "Invalid_User_id":
                headers.put( LicenseAPIConstants.ORGID, orgId );
                headers.put( LicenseAPIConstants.USERID, LicenseAPIConstants.invalid_User_Id );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( headers + "" );
                break;

            case "Invalid_Auth":
                headers.put( LicenseAPIConstants.ORGID, orgId );
                headers.put( LicenseAPIConstants.USERID, districtAdminUserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) + "Invalid" );
                Log.message( headers + "" );
                break;

            case "Invalid_UserId_Valid_OrgId":
                headers.put( LicenseAPIConstants.ORGID, orgId );
                headers.put( LicenseAPIConstants.USERID, LicenseAPIConstants.invalid_User_Id );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( headers + "" );
                break;

            case "Valid_UserId_Invalid_OrgId":
                headers.put( LicenseAPIConstants.ORGID, LicenseAPIConstants.invalid_Org_Id );
                headers.put( LicenseAPIConstants.USERID, teacherUserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( headers + "" );
                break;

            case "Invalid_UserID_Invalid_OrgId":
                headers.put( LicenseAPIConstants.ORGID, LicenseAPIConstants.invalid_Org_Id );
                headers.put( LicenseAPIConstants.USERID, LicenseAPIConstants.invalid_User_Id );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( districtAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( headers + "" );
                break;

            case "Teacher_UserId_with_Parent_OrgId":
                headers.put( LicenseAPIConstants.ORGID, configProperty.getProperty( "district_ID" ).trim() );
                headers.put( LicenseAPIConstants.USERID, teacherUserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                Log.message( headers + "" );
                break;

            case "Sch_CA_UserId_with_Distrtict_OrgId":
                headers.put( LicenseAPIConstants.ORGID, configProperty.getProperty( "district_ID" ).trim() );
                headers.put( LicenseAPIConstants.USERID, schoolAdminUserId );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( schoolAdminUserName, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                break;

            case "Student_UserId_with_Parent_OrgId":
                headers.put( LicenseAPIConstants.ORGID, configProperty.getProperty( "district_ID" ).trim() );
                headers.put( LicenseAPIConstants.USERID, studentUserId1 );
                headers.put( LicenseAPIConstants.AUTHORIZATION, LicenseAPIConstants.BEARER + new RBSUtils().getAccessToken( studentUserName1, RBSDataSetupConstants.DEFAULT_PASSWORD ) );
                break;
        }
        response = RestAssuredAPIUtil.GET( smUrl, headers, endPoint );
        int actual_StatusCode = response.getStatusCode();

        Log.assertThat( actual_StatusCode == expected_StatusCode, "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode );
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getDataForNegativieScenarios() {
        Object[][] data = { { "TC:06", 401, "Verify 401 status code and response body when valid header details and invalid authorization is given", "Invalid_Auth" },
                { "TC:07", 401, "Verify 401 status code and response body when invalid user-id is provided in the headers", "Invalid_User_id" },
                { "TC:08", 401, "Verify 401 status code and response body when invalid user-id with valid org-id is given in the headers", "Invalid_UserId_Valid_OrgId" },
                { "TC:09", 403, "Verify 403 status code and response body when valid user-id and invalid org-id is given in the headers", "Valid_UserId_Invalid_OrgId" },
                { "TC:10", 401, "Verify 401 status code and response body when invalid user-id and invalid org-id is given in the headers", "Invalid_UserId_Invalid_OrgId" },
                { "TC:11", 403, "Verify 403 status code and response body when teacher user-id with ir-respective org-id is given in the headers", "Teacher_UserId_with_Parent_OrgId" },
                { "TC:12", 403, "Verify 403 status code and response body when school customer admin user-id with respective / ir-respective parent org-id is given in the headers", "Sch_CA_UserId_with_Distrtict_OrgId" },
                { "TC:13", 403, "Verify 403 status code and response body, when valid student user-id and valid irrespective org-id is given", "Student_UserId_with_Parent_OrgId" }

        };
        return data;
    }

    /**
     * This method extracts and returns the licenseId from the given response
     * 
     * @param jsonResponse
     * @param arrayName
     * @return
     */
    public String getLicenseIdFromResponse( String jsonResponse, String arrayName ) {
        JSONObject jsonObject = null;
        String[] licenseId = null;
        try {
            jsonObject = new JSONObject( jsonResponse );
            jsonObject = jsonObject.getJSONObject( arrayName );
            licenseId = JSONObject.getNames( jsonObject );

        } catch ( Exception e ) {
            Log.message( "Error extracting licenseId from JsonResponse" );
        }

        return licenseId[0];
    }

}
