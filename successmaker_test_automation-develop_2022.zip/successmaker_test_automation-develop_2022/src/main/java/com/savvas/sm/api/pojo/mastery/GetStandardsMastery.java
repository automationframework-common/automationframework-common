package com.savvas.sm.api.pojo.mastery;

/**
 * This class is the POJO representation of GET- Standards(Mastery) API response
 * 
 * @author magesh.nagamani
 *
 */
public class GetStandardsMastery {

    // declare variables
    public String standardsId;

    public String standardsName;

    public String stateVersionId;

    /**
     * Getter method for standardsId
     * 
     * @return standardsId
     */
    public String getStandardsId() {
        return standardsId;
    }

    /**
     * Getter method for standardsName
     * 
     * @return standardsName
     */
    public String getStandardsName() {
        return standardsName;
    }

    /**
     * Getter method for stateVersionId
     * 
     * @return stateVersionId
     */
    public String getStateVersionId() {
        return stateVersionId;
    }

}
