INSERT INTO school.auser_file(asmt_user_file_id, database_identifier, 
assignment_user_id, learning_object_id, fluency_file_name, 
asmt_teacher_assessment, asmt_file_status_id, exercise_set_sco_id, 
player_audio_list, isdeleted, who_upd, date_created, fluency_audio, 
fluency_file_size, date_updated) VALUES (%s, 
0, %s, 8784, '%s', null, 
4, 3581, 'undefined', 0,'SQE', current_timestamp, 
decode('013d7d16d7ad4fefb61bd95b765c8ceb', 'hex'), 715477, current_timestamp)