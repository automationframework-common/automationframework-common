select standard_version_id as standardFrameworkId, bank_id as gradeId 
from bank where parent_bank_id in 
(select standard_version_id from standard_version where PCS_SUBJECT_ID = <subjectID> order by random() limit 1 )
order by random() limit 1