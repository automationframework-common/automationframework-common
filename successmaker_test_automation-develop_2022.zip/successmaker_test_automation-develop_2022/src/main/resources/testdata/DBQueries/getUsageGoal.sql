SELECT DISTINCT calc.addlMinPerWeek,deviation,calc.bucketName
       FROM
        (SELECT
      au.person_id, a.content_base_id, au.assignment_user_id, ip.ipm_status_name,
       cb.content_type_base_id, to_char(gs.end_date, 'mm/dd/yy') AS end_date, (gs.hours_in_course * 60) AS goalMinutesInCourse, gs.date_updated as lastUpdated
        FROM
       assignment a, assignment_user au,ipm_status ip,content_base cb,teacher_auser_goal_setting gs
        WHERE
       a.assignment_id = au.assignment_id
       AND au.isdeleted=0
        AND a.content_base_id = 1
        AND au.ipm_status_id = ip.ipm_status_id
        AND gs.assignment_user_id= au.assignment_user_id
        AND cb.content_base_id=a.content_base_id
        AND au.assignment_user_id in (<assignment_user_id>)
        ) AS nss
        LEFT JOIN
        (SELECT goal_calc.assignment_user_id, goal_calc.timeInCourse, goal_calc.percentActualTimeInCourse, goal_calc.percentTargetTimeInCourse,
       goal_calc.avgMinPerWeek, goal_calc.addlMinPerWeek,deviation,percentage,
        CASE WHEN (((@goal_calc.deviation) + (goal_calc.percentage * 10.0)) <= 9 OR (goal_calc.deviation >= 0 AND COALESCE(goal_calc.addlMinPerWeek, 0) > 0))
        THEN CASE WHEN COALESCE(goal_calc.addlMinPerWeek, 0) > 20 THEN 'Falling Behind' ELSE 'Watch Closely' END
        WHEN (goal_calc.deviation >= 0 AND COALESCE(goal_calc.addlMinPerWeek, 0) <= 0) THEN 'On Track'
        ELSE 'Falling Behind'
        END AS bucketName
       FROM
       (SELECT data.assignment_user_id, data.percentage,
       round(data.sessionMinutes) AS timeInCourse, round((data.sessionMinutes * 100.0) / data.goalMinutesInCourse) AS percentActualTimeInCourse,
       round(data.percentage * 100.0) AS percentTargetTimeInCourse, round(data.avgMinPerWeek) as avgMinPerWeek,
       CASE WHEN data.weeksToEndDate > 0
       THEN round(((data.goalMinutesInCourse - data.sessionMinutes) / (CASE WHEN data.weeksToEndDate < 1 THEN 1 ELSE data.weeksToEndDate END)) - COALESCE(data.avgMinPerWeek, 0))
       ELSE null END AS addlMinPerWeek,
       ((data.sessionMinutes * 100.0) / (data.goalMinutesInCourse * data.percentage) ) - 100.0 AS deviation
       FROM (
       SELECT DISTINCT
       auinfo.assignment_user_id,auinfo.sessionCount, auinfo.sessionMinutes, auinfo.goalMinutesInCourse, auinfo.recentSessionMinutes,
       (auinfo.goalEndDate - auinfo.currentDate) / 7 AS weeksToEndDate, (auinfo.currentDate - auinfo.courseStartDate + 1) AS studentDaysInCourse,

 

       CASE WHEN (auinfo.currentDate - auinfo.courseStartDate = 0 ) THEN 1
        WHEN (auinfo.goalEndDate - auinfo.courseStartDate = 0) THEN (auinfo.currentDate - auinfo.courseStartDate)
        ELSE (auinfo.currentDate - auinfo.courseStartDate) * 1.0 / (auinfo.goalEndDate - auinfo.courseStartDate) END AS percentage,

 

       (auinfo.recentSessionMinutes * 7) / least((auinfo.currentDate - auinfo.courseStartDate + 1), 28) AS avgMinPerWeek
       FROM (
       SELECT
       au.assignment_user_id, gs.end_date, (gs.hours_in_course * 60) AS goalMinutesInCourse, rsm.recentSessionMinutes,
       date(MIN(sh.session_start_time)) AS courseStartDate, gs.end_date AS goalEndDate,

 

       CASE WHEN (gs.end_date - CURRENT_DATE) <= 0 THEN gs.end_date
        ELSE CURRENT_DATE END AS currentDate,

 

       sum(EXTRACT (EPOCH FROM sh.session_complete_time - sh.session_start_time))/60 AS sessionMinutes, count(sh.math_session_history_id) AS sessionCount
       FROM
       assignment_user au LEFT OUTER JOIN
       (SELECT
       rau.assignment_user_id, sum(EXTRACT (EPOCH FROM rsh.session_complete_time - rsh.session_start_time))/60.0 AS recentSessionMinutes
       FROM
       math_session_history rsh, assignment_user rau, assignment ra
       WHERE
       rsh.assignment_user_id = rau.assignment_user_id
       AND rau.assignment_id = ra.assignment_id
       AND rsh.session_complete_time IS NOT NULL
       AND ra.content_base_id = 1
       AND CURRENT_DATE - 28 <= date(rsh.session_complete_time)
       AND rau.assignment_user_id in (<assignment_user_id>)
       GROUP BY rau.assignment_user_id) AS rsm ON (au.assignment_user_id = rsm.assignment_user_id),
       assignment a, math_session_history sh, teacher_auser_goal_setting gs
       WHERE
       au.assignment_user_id = sh.assignment_user_id
       AND au.assignment_id = a.assignment_id
       AND au.assignment_user_id = gs.assignment_user_id
       AND au.isdeleted = 0
       AND sh.session_complete_time IS NOT NULL
       AND sh.session_complete_time < gs.end_date
       AND a.content_base_id = 1
       AND au.assignment_user_id in (<assignment_user_id>)
       GROUP BY au.assignment_user_id, au.assignment_start_level, au.assignment_current_level,
       gs.end_date, gs.hours_in_course, rsm.recentSessionMinutes
       ) auinfo
       WHERE auinfo.goalEndDate - auinfo.courseStartDate > 0
       ) data
       WHERE data.sessionCount >= 2
       AND data.sessionMinutes >= 20
       AND data.studentDaysInCourse >= 7
        ) AS goal_calc
       ) AS calc ON (calc.assignment_user_id=nss.assignment_user_id)
          ORDER BY bucketName