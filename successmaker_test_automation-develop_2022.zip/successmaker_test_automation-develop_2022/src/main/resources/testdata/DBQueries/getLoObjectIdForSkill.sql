Select catalog_num as catalogNumber
from successmaker.learning_object lo, successmaker.cttype_learning_object clo
where lo.learning_object_id=clo.learning_object_id
and catalog_num not like '%pp%' and catalog_num not like '%ba%'
and cttype_id=<parent_cttype_id>
order by random() limit 1