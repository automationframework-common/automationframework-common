WITH RECURSIVE standard_alignment_with_Lo AS
(
   select
      btoplevel.bank_id,

      (
         btoplevel.state_text || ''
      ) as state_text,
      btoplevel.parent_bank_id,
      btoplevel.is_leaf
   from
      bank btoplevel
   where
      btoplevel.standard_version_id in
   (
      select
         standard_version_id
      from
         standard_version
      where
         standard_version = '<standard_name>'
   )
   and
      btoplevel.parent_bank_id= 0 UNION ALL select
      blevel.bank_id,

      (
         cte.state_text || '>>' || blevel.state_text
      ),
      blevel.parent_bank_id,
      blevel.is_leaf
   from
      bank blevel,
   standard_alignment_with_Lo cte
   where
      blevel.standard_version_id in
   (
      select
         standard_version_id
      from
         standard_version
      where
         standard_version = '<standard_name>'
   )
   and
      blevel.parent_bank_id!= 0
   and
      blevel.parent_bank_id = cte.bank_id
)
SELECT
   state_text,
   string_agg

   (
      lo.catalog_num,
      ';'
      order by
         lo.catalog_num
   ) as LO_IDs
FROM
   standard_alignment_with_Lo,
alignment a,
learning_object lo
where
   is_leaf= 1
and
   a.bank_id= standard_alignment_with_Lo.bank_id
and
   lo.pearson_lobj_id= a.pearson_content_id
GROUP BY
   state_text