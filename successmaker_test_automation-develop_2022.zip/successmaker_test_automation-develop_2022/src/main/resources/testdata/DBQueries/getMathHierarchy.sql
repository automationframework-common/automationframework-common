WITH RECURSIVE cttype_recur
(
   octid,
   cttype_id,
   parent_cttype_id,
   cttype_name,
   lo_order
) AS
(
   SELECT
      cttype_id as octid,
      cttype_id,
      parent_cttype_id,
      cttype_name,
      cttype_name::text::varchar
   FROM
      cttype
   WHERE
      cttype_id in
   (
      SELECT
         cttype_id
      FROM
         cttype_learning_object
      WHERE
         learning_object_id IN
      (
         SELECT
            learning_object_id
         FROM
            learning_object
      )
   )
   UNION ALL SELECT
      ctr.octid,
      sc.cttype_id,
      sc.parent_cttype_id,
      sc.cttype_name,
      sc.cttype_name
      ||
      ' >> '
      ||
      ctr.lo_order
   FROM
      cttype_recur ctr,
   cttype sc
   WHERE
      sc.cttype_id = ctr.parent_cttype_id
)
SELECT
   lo.catalog_num
   ||
   '|'
   ||
   cttr.lo_order
   ||
   ' >> '
   ||
   lo.lobj_description
   ||
   '|'
   ||
   ms.strand_name
   ||
   '|'
   ||
substr
   (
      ms.strand_name || mslo.strand_lo_level,
      1,
      3
   )
   ||
substr
   (
      ms.strand_name || mslo.strand_lo_level,
      5,
      2
   )
   ||
   '' as Math_Res_Data
FROM
   cttype_recur cttr
JOIN cttype_learning_object ctlo ON ctlo.cttype_id = cttr.octid
JOIN learning_object lo ON lo.learning_object_id = ctlo.learning_object_id
JOIN math_strand_learning_object mslo ON mslo.learning_object_id = lo.learning_object_id
JOIN math_strand ms ON ms.strand_id = mslo.strand_id
WHERE
(
   cttr.cttype_name like '%Grade %'
)
AND
   ctlo.cttype_id = cttr.octid
ORDER BY
   lo.catalog_num