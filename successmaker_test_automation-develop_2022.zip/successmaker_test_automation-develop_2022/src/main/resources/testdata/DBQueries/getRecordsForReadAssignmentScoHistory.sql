SELECT COUNT(*) FROM school.read_assignment_sco_history
WHERE assignment_user_id =<assignment_user_id>