SELECT enrollment_option_id from school.enrollment_option where option_name ='<optionName>'
and content_base_id = '<courseID>'