WITH RECURSIVE standard_alignment_with_Lo AS 
( 
select btoplevel.bank_id as bankkkk_id,btoplevel.parent_bank_id, btoplevel.is_leaf 
	from bank btoplevel where btoplevel.standard_version_id=<standard_id> and btoplevel.parent_bank_id=<grade_id>
UNION ALL
select blevel.bank_id, blevel.parent_bank_id, blevel.is_leaf 
	from bank blevel, standard_alignment_with_Lo cte where blevel.standard_version_id=<standard_id> and blevel.parent_bank_id!=0 
and blevel.parent_bank_id = cte.bankkkk_id
)
SELECT bankkkk_id, string_agg(lo.catalog_num,';' order by lo.catalog_num) as "LO IDs" 
FROM standard_alignment_with_Lo, alignment a , learning_object lo where is_leaf=1
and a.bank_id=standard_alignment_with_Lo.bankkkk_id and  lo.pearson_lobj_id=a.pearson_content_id
group by bankkkk_id order by random() limit 1