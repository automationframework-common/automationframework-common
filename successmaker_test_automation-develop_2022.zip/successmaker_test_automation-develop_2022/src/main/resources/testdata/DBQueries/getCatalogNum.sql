SELECT catalog_num,exercise_set_sco_id FROM successmaker.exerset_sco
WHERE exercise_set_sco_id in (
    SELECT exercise_set_sco_id FROM successmaker.exerset_sco
    WHERE exercise_set_sco_name LIKE 'smre%'
    order by random() limit 1
    )
order by random() limit 1