SELECT catalog_num FROM successmaker.learning_object
WHERE learning_object_id = <learning_object_id>