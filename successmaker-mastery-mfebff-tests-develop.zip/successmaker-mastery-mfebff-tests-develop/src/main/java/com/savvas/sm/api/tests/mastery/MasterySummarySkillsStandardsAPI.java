package com.savvas.sm.api.tests.mastery;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.MasteryAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.mastery.MasteryAPI;
import com.savvas.sm.utils.sme187.teacher.api.mastery.MasteryPerformanceConstant;
import com.savvas.sm.utils.sme187.teacher.api.mastery.MasterySummaryConstant;

/**
 * Method for testing the mastery summary -skills/standards in the micro service
 * call
 * 
 * @author madhan.nagarathinam
 */
public class MasterySummarySkillsStandardsAPI extends EnvProperties {
	private String smUrl;
	private String teacherDetails;
	private String teacherUsername;
	private String teacherUserId;
	private String orgId;
	private String studentDetails;
	private String studentUsername;
	private String studentUserId;
	private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
	private List<String> studentRumbaIds = new ArrayList<>();
	private Map<String, String> courseName = new HashMap<>();
	private Map<String, String> assignmentIds = new HashMap<>();
	String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String browser;
	String assignmentUserId;
	private static HashMap<String, String> assignmentDetails = new HashMap<>();
	private static HashMap<String, String> contentBase = new HashMap<>();
	private static HashMap<String, String> contentBaseName = new HashMap<>();

	private Map<String, String> courseIds = new HashMap<>();
	private List<String> schools = new ArrayList<>();
	private HashMap<String, String> response = new HashMap<>();
	private HashMap<String, String> groupDetails = new HashMap<>();
	private HashMap<String, String> userDetails = new HashMap<>();

	@BeforeClass(alwaysRun = true)
	public void init() throws Exception {
		// Retrieving URL & District ID from Config.properites
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		orgId = RBSDataSetup.organizationIDs.get(school);
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		teacherUsername = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		teacherUserId = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID);
		studentDetails = RBSDataSetup.getMyStudent(school, teacherUsername);
		studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERNAME);
		studentUserId = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERID);
		Log.message("Student : " + studentUserId);
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERID));

		String teacherAccessToken = null;
		try {
			teacherAccessToken = new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD);
		} catch (Exception e) {
			Log.message("Issue in get the accces token - " + e.getMessage());
			try {
				Log.message("Retrying to get the access token!!!!");
				teacherAccessToken = new RBSUtils().getAccessToken(teacherUsername,
						RBSDataSetupConstants.DEFAULT_PASSWORD);
			} catch (Exception e1) {
				Log.fail("Unable to create the access token for the teacher - " + teacherUsername);
			}
		}

		HashMap<String, String> staffDetails = new HashMap<>();
		staffDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
		staffDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherUserId);
		staffDetails.put(AssignmentAPIConstants.COURSE_ID, "2");
		staffDetails.put(RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken);

		try {
			// Assigning Assignment
			Log.message("Assigning assignment...");

			HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments(smUrl,
					staffDetails, studentRumbaIds, Arrays.asList(AssignmentAPIConstants.READING));

			Log.message("Assignment Response : " + assignmentResponse);

		} catch (Exception e) {
			Log.fail("Issue in Assigning the assignment to the student!! - " + e.getMessage());
		}

		executeCourse(studentUsername, Constants.READING, false);
	}
	
    @BeforeTest ( alwaysRun = true )
    public void BeforeTest() {
        smUrl = configProperty.getProperty( "SMAppUrl" ).trim();
}

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-51611","somke_test_case", "Mastery API Refactoring (Dev Verification) - Mastery summary API - Standards", "API" }, priority = 1 )
    public void postMasterySummaryTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        // headers
    	Map<String, String> headers = new HashMap<String, String>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		Map<String, Object> payload = new HashMap<>();

        switch ( scenarioType ) {
            case "WITH_MANDATORY_FILEDS":
            	headers.put(Constants.AUTHORIZATION, Constants.BEARER
    					+ new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
    			headers.put(Constants.USERID_SM_HEADER, teacherUserId);
    			headers.put(Constants.ORGID_SM_HEADER, orgId);
    			payload.put(MasteryAPIConstants.MasterySummaryConstants.REQ_SUBJECTID,
    					MasteryAPIConstants.MasterySummaryConstants.READING_SUBJECT_ID);
    			payload.put(MasteryAPIConstants.MasterySummaryConstants.REQ_STUDENTIDS,
    					"[\"" + studentUserId + "\"]");
                break;

            case "WITH_MANDATORY_FILEDS_READING_SUBJECT":
            	headers.put(Constants.AUTHORIZATION, Constants.BEARER
    					+ new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
    			headers.put(Constants.USERID_SM_HEADER, teacherUserId);
    			headers.put(Constants.ORGID_SM_HEADER, orgId);
    			payload.put(MasteryAPIConstants.MasterySummaryConstants.REQ_SUBJECTID,
    					MasteryAPIConstants.MasterySummaryConstants.READING_SUBJECT_ID);
    			payload.put(MasteryAPIConstants.MasterySummaryConstants.REQ_STUDENTIDS,
    					"[\"" + studentUserId + "\"]");
                break;

            case "MANDATORY_FIELDS_WITH_ASSIGNMENTID":
            	headers.put(Constants.AUTHORIZATION, Constants.BEARER
    					+ new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
    			headers.put(Constants.USERID_SM_HEADER, teacherUserId);
    			headers.put(Constants.ORGID_SM_HEADER, orgId);
    			payload.put(MasteryAPIConstants.MasterySummaryConstants.REQ_SUBJECTID,
    					MasteryAPIConstants.MasterySummaryConstants.READING_SUBJECT_ID);
    			payload.put(MasteryAPIConstants.MasterySummaryConstants.REQ_STUDENTIDS,
    					"[\"" + studentUserId + "\"]");
    			payload.put(Constants.ASSIGNMENT_ID, AssignmentAPIConstants.READING);
                break;
                
        }

		HashMap<String, String> masterySummary = getMasterySummary(smUrl, headers, payload);
		String actualstatuscode = masterySummary.get(Constants.STATUS_CODE);
		Log.message(masterySummary.get(Constants.REPORT_BODY));
		Log.assertThat(actualstatuscode.equals(expected_StatusCode),
				"The actual status code " + masterySummary.get(Constants.STATUS_CODE) + "is the same as expected status code "
						+ expected_StatusCode,
				"The actual status code " + masterySummary.get(Constants.STATUS_CODE)
						+ "is not the same as expected status code " + expected_StatusCode);
		
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC01: ", "200", "Verify the 200 status code and response body, when subjectId in request payload is 2 for MATH", "WITH_MANDATORY_FILEDS" },
               { "TC02: ", "200", "Verify the 200 status code and response body, when subjectId in request payload is 2 for READING", "WITH_MANDATORY_FILEDS_READING_SUBJECT" },
                { "TC03: ", "200", "Verify 200 status code and response should fetch relevant assignment data , when assignmentId in request payload is given with single assignmentId", "MANDATORY_FIELDS_WITH_ASSIGNMENTID" },

        };
        return data;
    }

    @Test ( enabled=false,dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51611", "Mastery API Refactoring (Dev Verification) - Mastery summary API - Standards", "API" }, priority = 1 )
    public void postMasterySummaryTest002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, Object> payload = new HashMap<>();

        switch ( scenarioType ) {
            case "VALID_USER_ID_WITH_INVALID_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.MasterySummaryConstants.USERNAME_VALUE, MasteryAPIConstants.MasterySummaryConstants.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID, MasteryAPIConstants.MasterySummaryConstants.INVALID_ORG_ID_VALUE );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.USER_ID, MasteryAPIConstants.MasterySummaryConstants.USER_ID_VALUE );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_SUBJECTID, MasteryAPIConstants.MasterySummaryConstants.MATH_SUBJECT_ID );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_STUDENTIDS, Arrays.asList(MasteryDataSetup.studentUserId1, MasteryDataSetup.studentUserId2, MasteryDataSetup.studentUserId3, MasteryDataSetup.studentUserId4) );
                break;

            case "INVALID_USER_ID_WITH_VALID_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.MasterySummaryConstants.USERNAME_VALUE, MasteryAPIConstants.MasterySummaryConstants.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID, MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.USER_ID, MasteryAPIConstants.MasterySummaryConstants.INVALID_USER_ID_VALUE );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_SUBJECTID, MasteryAPIConstants.MasterySummaryConstants.MATH_SUBJECT_ID );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_STUDENTIDS, Arrays.asList(MasteryDataSetup.studentUserId1, MasteryDataSetup.studentUserId2, MasteryDataSetup.studentUserId3, MasteryDataSetup.studentUserId4) );
                break;

            case "INVALID_SUBJECT_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.MasterySummaryConstants.USERNAME_VALUE, MasteryAPIConstants.MasterySummaryConstants.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID, MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.USER_ID, MasteryAPIConstants.MasterySummaryConstants.USER_ID_VALUE );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_SUBJECTID, MasteryAPIConstants.MasterySummaryConstants.INVALID_SUBJECTID );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_STUDENTIDS, Arrays.asList(MasteryDataSetup.studentUserId1, MasteryDataSetup.studentUserId2, MasteryDataSetup.studentUserId3, MasteryDataSetup.studentUserId4) );
                break;

            case "INVALID_STUDENT_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.MasterySummaryConstants.USERNAME_VALUE, MasteryAPIConstants.MasterySummaryConstants.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID, MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.USER_ID, MasteryAPIConstants.MasterySummaryConstants.USER_ID_VALUE );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_SUBJECTID, MasteryAPIConstants.MasterySummaryConstants.MATH_SUBJECT_ID );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_STUDENTIDS, MasteryAPIConstants.MasterySummaryConstants.INVALID_STUDENTID);
                break;

            case "EMPTY_STUDENT_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.MasterySummaryConstants.USERNAME_VALUE, MasteryAPIConstants.MasterySummaryConstants.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID, MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.USER_ID, MasteryAPIConstants.MasterySummaryConstants.USER_ID_VALUE );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_SUBJECTID, MasteryAPIConstants.MasterySummaryConstants.MATH_SUBJECT_ID );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_STUDENTIDS, "");
                break;

            case "EMPTY_REQUEST_PAYLOAD":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.MasterySummaryConstants.USERNAME_VALUE, MasteryAPIConstants.MasterySummaryConstants.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID, MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.USER_ID, MasteryAPIConstants.MasterySummaryConstants.USER_ID_VALUE );
                break;

            case "INVALID_AUTH":
                headers.put( Constants.AUTHORIZATION, new RBSUtils().getAccessToken( MasteryAPIConstants.MasterySummaryConstants.USERNAME_VALUE, MasteryAPIConstants.MasterySummaryConstants.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID, MasteryAPIConstants.MasterySummaryConstants.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.MasterySummaryConstants.USER_ID, MasteryAPIConstants.MasterySummaryConstants.USER_ID_VALUE );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_SUBJECTID, MasteryAPIConstants.MasterySummaryConstants.MATH_SUBJECT_ID );
                payload.put( MasteryAPIConstants.MasterySummaryConstants.REQ_STUDENTIDS, Arrays.asList(MasteryDataSetup.studentUserId1, MasteryDataSetup.studentUserId2, MasteryDataSetup.studentUserId3, MasteryDataSetup.studentUserId4) );
                break;

        }
        Response response = new MasteryAPI().getMasterySummary( smUrl, headers, payload );
        int actualstatuscode = response.getStatusCode();
        Log.message( response.getBody().asString() );
        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );

    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC:07 ", "403", "Verfiy the 403 status code and response body when valid user-id with irrespective org-id", "VALID_USER_ID_WITH_INVALID_ORG_ID" },
                { "TC:08 ", "401", "Verfiy the 401 status code and response body when invalid user-id with valid org-id", "INVALID_USER_ID_WITH_VALID_ORG_ID" },
                { "TC:09 ", "400", "Verfiy the 400 status code and response body when invalid subject_id is given in the request body", "INVALID_SUBJECT_ID" },
                { "TC:10 ", "400", "Verfiy the 400 status code and response body when invalid student_id is given in the request body", "INVALID_STUDENT_ID" },
                { "TC:11 ", "400", "Verfiy the 400 status code and response body when empty student_id is given in the request body", "EMPTY_STUDENT_ID" },
                { "TC:12 ", "400", "Verfiy the 400 status code and response body when no request body is given", "EMPTY_REQUEST_PAYLOAD" },
                { "TC:13 ", "401", "Verify 401 status code and response body when invalid authorization is provided", "INVALID_AUTH" }, };
        return data;
    }
    
    public void executeCourse( String studentUserName, String courseName, boolean isMath ) throws IOException {
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.message( "Student username " + studentUserName );
        LoginWrapper.loginToSuccessMakerAsStudent( driver, smUrl, UserType.BASIC, null, studentUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
        StudentDashboardPage studentsPage = new StudentDashboardPage( driver );



       if ( isMath ) {
            try {
                studentsPage.executeMathCourse( studentUserName, courseName, "100", "3", "30" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse( studentUserName, courseName, "100", "3", "30" );
                studentsPage.logout();
                driver.close();
            } catch ( Exception e ) {
                driver.close();
            }
        }

	}
    
    public HashMap<String, String> getMasterySummary(String smUrl, Map<String, String> headers,
			Map<String, Object> requestBody) throws Exception {

		String body = "{ \"subjectId\":" + requestBody.get("subjectId") + ",\"studentIds\":"
				+ requestBody.get("studentIds");
		if (Objects.nonNull(requestBody.get("assignmentIds"))) {
			body = body + "\"assignmentIds\":" + requestBody.get("assignmentIds").toString() + "}";
		} else {
			body = body + "}";
		}
		Log.message(body);
		return RestHttpClientUtil.POST(smUrl, headers, new HashMap<>(),
				MasterySummaryConstant.MASTERY_SUMMARY_ENDPOINT, body);

		// return RestAssuredAPIUtil.POST_REQ( smUrl, headers, requestBody,
		// MasteryPerformanceConstant.MASTERY_PERFORMANCE_ENDPOINT);

	}


}
