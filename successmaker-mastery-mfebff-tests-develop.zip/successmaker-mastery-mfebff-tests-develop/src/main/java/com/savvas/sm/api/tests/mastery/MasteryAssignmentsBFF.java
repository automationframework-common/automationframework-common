package com.savvas.sm.api.tests.mastery;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.api.pojo.mastery.GetAssignmentsMasteryBff;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.apiconstants.MasteryAPIConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sql.helper.AssignmentTable.AssignmentMastery;
import com.savvas.sm.utils.sql.helper.SqlHelperAssignment;

import io.restassured.response.Response;


/**
 * Method for testing the realTime assignments data in the GraphQL call
 * 
 * @author madhan.nagarathinam
 */

public class MasteryAssignmentsBFF extends BaseAPITest {
   private String smUrl;
   private String browser;
   public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
   public static String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
 
   private String studentDetails;
   private String studentUsername;
   private String studentUserId;
   
    String MATH_SUBJECT_ID = "1";
    String READING_SUBJECT_ID = "2";
    String INVALID_SUBJECT_ID = "3";
    String subject_Id;
    String userName1;
    String userName2;
    String organizationId1;
    String organizationId2;
    String teacherUserId1;
    String teacherUserId2;
    String teacherDetails1=null;
    String teacherDetails2=null;
    String assignmentList;
    
    private List<String> studentRumbaIds = new ArrayList<>();
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static Map<String, String> contentBase = new HashMap<>();
    private static Map<String, String> contentBaseName = new HashMap<>();
    private static Map<String, String> assignmentIds = new HashMap<>();

    private List<String> courseIDs = new ArrayList<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    HashMap<String, String> assignmentResponse = new HashMap<>();
    
    @BeforeClass
    public void before() throws Exception {
        smUrl = configProperty.getProperty("SMAppUrl");
        browser = configProperty.getProperty("BrowserPlatformToRun");
       
     // Fetching Teacher Details
        organizationId1 =  RBSDataSetup.organizationIDs.get( school );
        teacherDetails1 = RBSDataSetup.getMyTeacher(school);
        userName1 = SMUtils.getKeyValueFromResponse(teacherDetails1, "userName");
        teacherUserId1= SMUtils.getKeyValueFromResponse(teacherDetails1, "userId");
        Log.message(userName1);
        
        // Fetching Teacher Details
        organizationId2 =  RBSDataSetup.organizationIDs.get( school );
        teacherDetails2 = RBSDataSetup.getMyTeacher(school);
        userName2 = SMUtils.getKeyValueFromResponse(teacherDetails2, "userName");
        teacherUserId2= SMUtils.getKeyValueFromResponse(teacherDetails2, "userId");
        Log.message(userName2);
        studentDetails = RBSDataSetup.getMyStudent(school, userName1);
        studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERNAME);
        studentUserId = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERID);
        Log.message("Student : " + studentUserId);
        studentRumbaIds.add(studentUserId);

        String token = new RBSUtils().getAccessToken( userName1, RBSDataSetupConstants.DEFAULT_PASSWORD );

        groupDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );
        groupDetails.put( Constants.GROUP_OWNER_ID, SMUtils.getKeyValueFromResponse( teacherDetails1, "userId" ) );
        groupDetails.put( Constants.GROUP_ORG_ID, RBSDataSetup.organizationIDs.get( school ) );
        groupDetails.put( Constants.GROUP_NAME, "groupName" );

        assignmentDetails.put( AssignmentAPIConstants.ORG_ID, organizationId1 );
        assignmentDetails.put( AssignmentAPIConstants.TEACHER_ID, teacherUserId1 );
        assignmentDetails.put( RBSDataSetupConstants.BEARER_TOKEN, token );

        Log.message( "Created Group" + new GroupAPI().createGroup( smUrl, groupDetails, studentRumbaIds ) );

        contentBaseName.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING_COURSE );
        contentBaseName.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH_COURSE );
        
        Log.message( "contentbasename" + contentBaseName );
        contentBase.put( AssignmentAPIConstants.READING_COURSE, AssignmentAPIConstants.READING );
        contentBase.put( AssignmentAPIConstants.MATH_COURSE, AssignmentAPIConstants.MATH );
        
        courseIDs.add( contentBase.get( AssignmentAPIConstants.READING_COURSE ) );
        courseIDs.add( contentBase.get( AssignmentAPIConstants.MATH_COURSE ) );
        
        Log.message( "Assigning assignment..." );
        assignmentResponse = new AssignmentAPI().assignMultipleAssignments( smUrl, assignmentDetails, studentRumbaIds, courseIDs );
        Log.message( "Assignment Details" + assignmentResponse );
        JSONObject assignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
        JSONArray assignmentList =  assignmentDetailsJson.getJSONArray( Constants.DATA );

        for ( Object assignment : assignmentList ) {
            JSONObject assignmentInfo = new JSONObject( assignment.toString() );
            assignmentIds.put( assignmentInfo.get( "assignmentName" ).toString(), assignmentInfo.get( "assignmentId" ).toString() );
        }
        Log.message( "Assignment IDs - " + assignmentIds );
        executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.MATH_COURSE ), true );
        executeCourse( studentUsername, contentBaseName.get( AssignmentAPIConstants.READING_COURSE ), false );
    }
    
    @Test( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-51593",
            "(Graphql) BFF Assignments api integration - real", "GraphQL", "BFF" }, priority = 1 )
    public void getAssignemntsTest001( String testcaseName, String expected_StatusCode, String testcaseDescription,
            String scenarioType, String expected_subjectId ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();

        // For Constructing QueryItems in request PayLoad
        List<String> queryItems = new ArrayList<String>();
        String queryItem = null;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {

        case "ALL_QUERY_ITEMS":
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER
                            + new RBSUtils().getAccessToken(userName1,
                                    MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId1 );
            headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId1 );

            subject_Id = MATH_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_FIRST_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_LAST_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ID );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.SUBJECT_ID );
            queryItem = constructQueryItems( queryItems );
            break;

        case "MULTIPLE_QUERY_ITEMS":
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER
                            + new RBSUtils().getAccessToken(userName1,
                                    MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId1 );
            headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId1 );

            subject_Id = MATH_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ID );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.SUBJECT_ID );
            queryItem = constructQueryItems( queryItems );
            break;

        case "SINGLE_QUERY_ITEMS":
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER
                            + new RBSUtils().getAccessToken( userName1,
                                    MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,organizationId1 );
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID, teacherUserId1 );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            subject_Id = MATH_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.SUBJECT_ID );
            queryItem = constructQueryItems( queryItems );
            break;
        case "MATH_SUBJECT_ID":
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER
                            + new RBSUtils().getAccessToken(userName1,
                                    MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId1 );
            headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId1 );

            subject_Id = MATH_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_FIRST_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_LAST_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ID );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.SUBJECT_ID );
            queryItem = constructQueryItems( queryItems );
            break;

        case "READING_SUBJECT_ID":
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER
                            + new RBSUtils().getAccessToken(userName1,
                                    MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId1 );
            headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId1 );

            subject_Id = READING_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_FIRST_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_LAST_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ID );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.SUBJECT_ID );
            queryItem = constructQueryItems( queryItems );
            break;

        }

        String payload = String.format( MasteryAPIConstants.Mastery_GraphQL_Assignments.REQ_PAYLOAD, organizationId1,
                teacherUserId1, subject_Id, queryItem );
        Log.message("payload is "+ payload);
        Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL,
                headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
        Log.message( "Response - " +response.getBody().asString() );
        Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ),
                "The actual status code " + response.getStatusCode() + "is the same as expected status code "
                        + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code "
                        + expected_StatusCode );

        String body = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
        String assignment = SMUtils.getKeyValueFromResponse( body, "assignments" );
        Object subjectId = new JSONArray(assignment).getJSONObject(0).get("subjectId");

        Log.assertThat(subjectId.equals(expected_subjectId), "The actual subject id "+subjectId+" is same as expected subject id " + expected_subjectId, 
                "The actual subject id "+subjectId+" is not the same as expected subject id " + expected_subjectId);

//       DB validation for Assignments Data with respect to the GraphQL Response
        if ( scenarioType.equalsIgnoreCase( "MATH_SUBJECT_ID" ) || scenarioType.equalsIgnoreCase( "READING_SUBJECT_ID" ) ) {
            // deSerialize the response
            final ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
            // convert JSON array to List of objects
            String assignments = SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" ).toString();
            JSONArray assign = getJsonArrayFromResponse( assignments, "assignments" );
            for (int i=0; i< assign.length(); i++) {
                Object assignmentName =  new JSONArray(assign).getJSONObject(i).get("assignmentName");  
                if (assignmentName.equals(Constants.MATH) || assignmentName.equals(Constants.READING) ) {
                    assignmentList = new JSONArray(assign).getJSONObject(i).toString();
                }
            }
            List<GetAssignmentsMasteryBff> listAssignmentNamesResponse = Arrays.asList( objectMapper.readValue( assignmentList, GetAssignmentsMasteryBff[].class ) );
            // get values from Database

            List<AssignmentMastery> listAssignmentNamesDB = SqlHelperAssignment.getAssignments( scenarioType, teacherUserId1 );
            // compare
            Log.assertThat( compareStandardsFromApiResponseAndDB( listAssignmentNamesResponse,listAssignmentNamesDB ), "DB records and API response both are same for Assignments- " + scenarioType,
                    "DB records and API response both are different for Assignment- " + scenarioType );
        }
    }

    @Test( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51593",
            "(Graphql) BFF Assignments api integration - real", "GraphQL", "BFF" }, priority = 1 )
    public void getAssignemntsTest002( String testcaseName, String expected_StatusCode, String testcaseDescription,
            String scenarioType ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        // For Constructing QueryItems in request PayLoad
        List<String> queryItems = new ArrayList<String>();
        String queryItem = null;
        String payload = null;
        String orgId = "";
        String userId = "";

        
        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {

        case "TEACHER_WITH_ZERO_ASSIGNMENTS_MATH":
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER + new RBSUtils().getAccessToken(
                            userName2,
                            MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,
                    organizationId2 );
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID,
                    teacherUserId2 );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

            
            subject_Id = MATH_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_FIRST_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_LAST_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ID );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.SUBJECT_ID );
            queryItem = constructQueryItems( queryItems );
             payload = String.format( MasteryAPIConstants.Mastery_GraphQL_Assignments.REQ_PAYLOAD, organizationId2,
                     teacherUserId2, subject_Id, queryItem );
            break;

        case "TEACHER_WITH_ZERO_ASSIGNMENTS_READING":
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER + new RBSUtils().getAccessToken(
                            userName2,
                            MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,
                    organizationId2 );
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID,
                    teacherUserId2 );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            
            
            subject_Id = READING_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_FIRST_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ASSIGNER_LAST_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_ID );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.SUBJECT_ID );
            queryItem = constructQueryItems( queryItems );
            payload = String.format( MasteryAPIConstants.Mastery_GraphQL_Assignments.REQ_PAYLOAD, organizationId2,
                    teacherUserId2, subject_Id, queryItem );
            break;

        case "INVALID_AUTH":
            headers.put( Constants.AUTHORIZATION,
                    new RBSUtils().getAccessToken( userName1,
                            MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD +1));
             headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId1 );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId1 );
            
            subject_Id = READING_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
            queryItem = constructQueryItems( queryItems );
            payload = String.format( MasteryAPIConstants.Mastery_GraphQL_Assignments.REQ_PAYLOAD, organizationId1,
                    teacherUserId1, subject_Id, queryItem );
            break;

        case "INVALID_PAYLOAD":
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER
                            + new RBSUtils().getAccessToken( userName1,
                                    MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
             headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId1 );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId1 );
            subject_Id = READING_SUBJECT_ID;
            queryItems.add( "122" );
            queryItem = constructQueryItems( queryItems );
            payload = String.format( MasteryAPIConstants.Mastery_GraphQL_Assignments.REQ_PAYLOAD, organizationId1,
                    teacherUserId1, subject_Id, queryItem );
            break;

        case "STUDENT":
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER + new RBSUtils().getAccessToken(
                            MasteryAPIConstants.Mastery_GraphQL_Assignments.STUDENT_USER_NAME,
                            MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
             headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId1 );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId1 );
                
            subject_Id = READING_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
            queryItem = constructQueryItems( queryItems );
            payload = String.format( MasteryAPIConstants.Mastery_GraphQL_Assignments.REQ_PAYLOAD, organizationId1,
                    teacherUserId1, subject_Id, queryItem );
            break;
            
          case "INVALID_SUBJECT_ID":
            
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER
                            + new RBSUtils().getAccessToken( userName1,
                                    MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
             headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId1 );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId1 );
                
            subject_Id = INVALID_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
            queryItem = constructQueryItems( queryItems );
            payload = String.format( MasteryAPIConstants.Mastery_GraphQL_Assignments.REQ_PAYLOAD, organizationId1,
                    teacherUserId1, subject_Id, queryItem );
            break;
        case "IRRESPECTIVE_ORG_ID":
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER
                            + new RBSUtils().getAccessToken( userName1,
                                    MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,
                    MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID_VALUE );
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID,
                    MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID_VALUE );
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            orgId = MasteryAPIConstants.Mastery_GraphQL_Assignments.INVALID_ORG_ID_VALUE;
            userId = MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID_VALUE;
            subject_Id = READING_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
            queryItem = constructQueryItems( queryItems );
            payload = String.format( MasteryAPIConstants.Mastery_GraphQL_Assignments.REQ_PAYLOAD, orgId,
                    userId, subject_Id, queryItem );
            break;

        case "BUSSINESS_VIOLATION":
            headers.put( Constants.AUTHORIZATION,
                    Constants.BEARER
                            + new RBSUtils().getAccessToken( userName1,
                                    MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
            headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.ORG_ID,
                    organizationId1 );
            headers.put( MasteryAPIConstants.Mastery_GraphQL_Assignments.USER_ID,
                    teacherUserId1 );
            orgId = MasteryAPIConstants.Mastery_GraphQL_Assignments.INVALID_ORG_ID_VALUE;
            userId = MasteryAPIConstants.Mastery_GraphQL_Assignments.INVALID_USER_ID_VALUE;
            subject_Id = MATH_SUBJECT_ID;
            queryItems.add( MasteryAPIConstants.Mastery_GraphQL_Assignments.ASSIGNMENT_NAME );
            queryItem = constructQueryItems( queryItems );
            payload = String.format( MasteryAPIConstants.Mastery_GraphQL_Assignments.REQ_PAYLOAD, orgId,
                    teacherUserId1, subject_Id, queryItem );
            
            break;
        }
        
        Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL,
                headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
        
        Log.message( response.getBody().asString() );
        Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ),
                "The actual status code " + response.getStatusCode() + "is the same as expected status code "
                        + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code "
                        + expected_StatusCode );
        if (scenarioType.equalsIgnoreCase( "TEACHER_WITH_ZERO_ASSIGNMENTS_MATH" )
                || scenarioType.equalsIgnoreCase( "TEACHER_WITH_ZERO_ASSIGNMENTS_READING" )) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( MasteryConstants.Graphql.skillsandStandards.ASSIGNMENT_NOT_FOUND ),
                    "Getting Unauthorized message for Invalid authorization",
                    "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_AUTH" )) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( MasteryConstants.Graphql.skillsandStandards.UNAUTHORIZED_MESSAGE ),
                    "Getting Unauthorized message for Invalid authorization",
                    "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if (  scenarioType.equalsIgnoreCase( "IRRESPECTIVE_ORG_ID" )
                ||scenarioType.equalsIgnoreCase( "STUDENT" )) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( MasteryConstants.Graphql.skillsandStandards.NOT_AUTHENTICATED ),
                    "Getting Access Denied message for Invalid users / Irrespective org's",
                    "The Access Denied message is not getting displayed for Invalid users / Irrespective org's!");

        } else if ( scenarioType.equalsIgnoreCase( "INVALID_SUBJECT_ID" )) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat(
                    message.equalsIgnoreCase( MasteryConstants.Graphql.skillsandStandards.INVALID_SUBJECT_ID_ERROR1 ),
                    "Getting Access Denied message for Invalid subject ID",
                    "The Access Denied message is not getting displayed for Invalid subject ID" );

        } else if ( scenarioType.equalsIgnoreCase( "BUSSINESS_VIOLATION" )) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( MasteryConstants.Graphql.skillsandStandards.BAD_REQUEST1 ),
                    "Getting Bad request message for Invalid users / Irrespective org's",
                    "The Bad request message is not getting displayed for Invalid users / Irrespective org's!" );
        }

    }

    // This method is for constructing the query Items for payLoad
    public String constructQueryItems( List<String> queryItems ) {
        String frameQuery = "{";
        for ( String item : queryItems ) {
            if ( frameQuery.endsWith("{") )
                frameQuery = frameQuery + item;
            else
                frameQuery = frameQuery + "," + item;
        }
        frameQuery = frameQuery + "}";
        return frameQuery;
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC:001 ", "200",
                "Verify the graphql response is obtaining the predictable result for all set of Fields for assignments query",
                "ALL_QUERY_ITEMS", "1" },
                { "TC:002 ", "200",
                        "Verify the graphql response is obtaining the predictable result for multiple set of Fields given below",
                        "MULTIPLE_QUERY_ITEMS", "1" },
                { "TC:003 ", "200", "Verify 200 status code and valid response when a single set query is given ",
                        "SINGLE_QUERY_ITEMS", "1" },
                { "TC:004 ", "200",
                        "Verify the graphql response is obtaining all the assignments details in the database for all set of Fields for assignment query when Math subject Id is given",
                        "MATH_SUBJECT_ID", "1" },
                { "TC:005 ", "200",
                        "Verify the graphql response is obtaining all the assignment details in the database for all set of Fields for assignment query when Reading subject Id is given",
                        "READING_SUBJECT_ID", "2" }, };
        return data;
    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC:006 ", "200",
                "Verify the graphql response is obtaining zero assignments details in the database for all set of Fields for assignment query when user is not having any math assignments",
                "TEACHER_WITH_ZERO_ASSIGNMENTS_MATH" },
                { "TC:007 ", "200",
                        "Verify the graphql response is obtaining zero assignments details in the database for all set of Fields for assignment query when user is not having any reading assignments",
                        "TEACHER_WITH_ZERO_ASSIGNMENTS_READING" },
                { "TC: 008", "200",
                        "Verify '401: UnAuthorized' message in response when invalid Bearer token is given ",
                        "INVALID_AUTH" },
                { "TC: 009", "400", "Verify '400: Bad Request' in response when invalid query has been given",
                        "INVALID_PAYLOAD" },
                { "TC: 010", "200",
                        "Verify the user is not authorized message on the response when studentid is given the headers and query",
                        "STUDENT" },
                { "TC: 011", "200",
                        "Verify the user is not authorized message on the response when irrespective org is given the headers",
                        "IRRESPECTIVE_ORG_ID" },
                { "TC: 012", "200",
                        "Verify 400 status code and response when invalid subject id is given in the query ",
                        "INVALID_SUBJECT_ID" },
                { "TC: 013", "200",
                        "Verify the BusinessRuleViolationException on the response when the headers and query set is not matching with given  query",
                        "BUSSINESS_VIOLATION" },

        };
        return data;
    }

    /**
     * This method is used to compare the standards list from API response and
     * DB-Table entries
     * 
     * @param listStandardVersionResponse
     * @param listStandardVersionDB
     * @return
     */
    private boolean compareStandardsFromApiResponseAndDB( List<GetAssignmentsMasteryBff> listAssignmentResponse,
            List<AssignmentMastery> listAssignmentDB ) {
        boolean returnParam = false;
        // sort the values by ascending order pointing - StandardsID
        listAssignmentDB.sort( Comparator
                .comparing( com.savvas.sm.utils.sql.helper.AssignmentTable.AssignmentMastery::getAssignmentId ));
        listAssignmentResponse.sort( Comparator.comparing( GetAssignmentsMasteryBff::getAssignmentId ));

        // add to common list for comparison.
        // Since, comparing two list of different object is not possible
        List<String> commonListDB = new ArrayList<String>();
        List<String> commonListResponse = new ArrayList<String>();

        listAssignmentResponse.stream().forEachOrdered(c -> {
            commonListResponse.add( c.getAssignmentId() );
            commonListResponse.add( c.getAssignmentName() );
        });

        listAssignmentDB.stream().forEachOrdered(c -> {
            commonListDB.add( c.getAssignmentId() );
            commonListDB.add( c.getAssignmentName() );
        });
        Log.message( commonListDB + "" );
        Log.message( commonListResponse + "" );

        // compare
        returnParam = commonListDB.equals( commonListResponse );

        return returnParam;
    }

    // This method is extracting error message from response

    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject(0);
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }
    
    /**
     * To execute the course
     *
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse(String studentUserName, String courseName, boolean isMath) throws IOException {
        final WebDriver driver = WebDriverFactory.get(browser);
        Log.message("Student username " + studentUserName);
        LoginWrapper.loginToSuccessMakerAsStudent(driver, smUrl, UserType.BASIC, null, studentUserName,
                RBSDataSetupConstants.DEFAULT_PASSWORD);
        StudentDashboardPage studentsPage = new StudentDashboardPage(driver);

        if (isMath) {
            try {
                studentsPage.executeMathCourse(studentUserName, courseName, "100", "3", "30");
                studentsPage.logout();
                driver.close();
            } catch (Exception e) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse(studentUserName, courseName, "100", "3", "30");
                studentsPage.logout();
                driver.close();
            } catch (Exception e) {
                driver.close();
            }
        }
    }
}
