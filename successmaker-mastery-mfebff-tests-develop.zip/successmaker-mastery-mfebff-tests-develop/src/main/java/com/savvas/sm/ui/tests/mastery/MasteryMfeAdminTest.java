package com.savvas.sm.ui.tests.mastery;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.ui.mastery.pages.MasteryMfePage;
import com.savvas.sm.ui.pages.login.LoginWrapper;

public class MasteryMfeAdminTest extends BaseTest {
    private String masteryAdminSingleMfeUrl;
    private String masteryAdminMultiMfeUrl;
    private String browser;
    
    RBSUtils rbsUtils;
    private static String usernameSuffixTest;
    
    private static String smUrl;
    public static String orgId;
    public static Map<String, String> teacherDetails = new HashMap<>();
    public static Map<String, String> teacherGroupDetails = new HashMap<>();

    public static String districtAdmin;
    public static String schoolAdmin;
    public static String multiSchoolAdmin;
    public static String subDistrictAdmin;

    public static String districtAdminDetails;
    public static String schoolAdminDetails;
    public static String multiSchoolAdminDetails;
    public static String subDistrictAdminDetails;
    
    @BeforeClass
    public void initTest( ITestContext context ) {
        masteryAdminSingleMfeUrl = configProperty.getProperty( "MasteryAdminSingleMfe" );
        masteryAdminMultiMfeUrl = configProperty.getProperty( "MasteryAdminMultiMfe" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
       
        smUrl = configProperty.getProperty( ConfigConstants.SM_APP_URL );
        rbsUtils = new RBSUtils();
        orgId = rbsUtils.getOrganizationIDByName( configProperty.getProperty( ConfigConstants.DISTRICT_ID ), RBSDataSetup.getSchools( Schools.FLEX_SCHOOL ) );

        String envUrl = smUrl.substring( 8 ); //To take out the https:// from the host
        String usernameSuffix = envUrl.split( "\\." )[0];
        usernameSuffixTest = usernameSuffix.replaceAll( "[^a-zA-Z0-9]", "" );

        districtAdmin = String.format( RBSDataSetupConstants.DISTRICT_ADMIN_USERNAME, usernameSuffixTest );
        schoolAdmin = String.format( RBSDataSetupConstants.SCHOOL_ADMIN_USERNAME, usernameSuffixTest );
        multiSchoolAdmin = String.format( RBSDataSetupConstants.MULTI_SCHOOL_ADMIN_USERNAME, usernameSuffixTest );
        subDistrictAdmin = String.format( RBSDataSetupConstants.SUBDISTRICT_ADMIN_USERNAME, usernameSuffixTest );

        districtAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( districtAdmin ) );
        schoolAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( schoolAdmin ) );
        multiSchoolAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( multiSchoolAdmin ) );
        subDistrictAdminDetails = rbsUtils.getUser( rbsUtils.getUserIDByUserName( subDistrictAdmin ) );
    }

    @Test ( priority = 1, groups = { "SMK-51121", "mastery_mfe_admin", "P1", "UI" } )
    public void tcMasteryMfeAdminSingle( ITestContext context ) throws Exception {
        // Get driver
    	final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "Mastery Mfe Admin Test" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {

            // TC_1
            SMUtils.logDescriptionTC( "1.Verify the 'Mastery' title in the mastery filter component" );
            LoginWrapper.loginToMasteryMfe( driver, masteryAdminSingleMfeUrl, districtAdmin, RBSDataSetupConstants.DEFAULT_PASSWORD );
            MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
            Log.assertThat( masteryMfePage.getMasteryHeading().equals( MasteryConstants.Labels.MASTERY_HEADING ), "Mastery Heading is displayed", "Mastery Heading is not displayed" );

            // TC_2    
            SMUtils.logDescriptionTC( "2.Verify 'Help' icon is getting displayed" );
            Log.assertThat( masteryMfePage.isHelpIconDisplayed(), "Help icon is displayed", "Help icon is not displayed" );

            // open mastery view of Admin-Multi
            driver.get( masteryAdminMultiMfeUrl );

            // TC_5
            SMUtils.logDescriptionTC( "5.Verify 'STEP2: Refine Search' label is getting displayed before the subject dropdown when 'Select an Organization' dropdown is displayed" );
            masteryMfePage = new MasteryMfePage( driver ).get();
            Log.assertThat( masteryMfePage.isMasteryStep2HeadingDisplayed(), "STEP2: Refine Search is displayed for multi-admin type", "STEP2: Refine Search is not displayed for multi-admin type" );

            // TC_3 
            if ( !( (RemoteWebDriver) driver ).getCapabilities().getBrowserName().toLowerCase().contains( "safari" ) ) {
                SMUtils.logDescriptionTC( "3.Verify help content is opened in new tab after clicking the 'Help' icon" );
                Log.assertThat( masteryMfePage.isHelpPageOpensInNewTab( driver ), "Help page opened in a new tab", "Help page doesn't opened in a new tab" );
            }
            // TC_6
            SMUtils.logDescriptionTC( "6.Verify Filter component is collapsed after clicking the 'Apply Filter'button" );
            masteryMfePage.getMasteryFilterComponent().applyFilter();
            Log.assertThat( !masteryMfePage.getMasteryFilterComponent().isApplyFilterButtonPresent(), "Mastery Filter section collapses after clicking on Apply filter button",
                    "Mastery Filter section is not collapsed after clicking on Apply filter button!" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( priority = 1, groups = { "SMK-51121", "mastery_mfe_admin", "P1", "UI" } )
    public void tcMasteryMfeAdmin( ITestContext context ) throws Exception {
        // Get driver
    	final WebDriver driver = WebDriverFactory.get(browser);
        Log.testCaseInfo( "Mastery Mfe Admin Test" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {
        	LoginWrapper.loginToMasteryMfe( driver, masteryAdminSingleMfeUrl, schoolAdmin, "testing123$");
            MasteryMfePage masteryMfePage = new MasteryMfePage(driver).get();
         // TC_4
            SMUtils.logDescriptionTC( " 4.Verify 'STEP2: Refine Search' label is not getting displayed before the subject dropdown when 'Select an Organization' dropdown is not available" );
            Log.assertThat( !masteryMfePage.isMasteryStep2HeadingDisplayed(), "STEP2: Refine Search is not displayed for single-admin type", "STEP2: Refine Search is displayed for single-admin type" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }
}
