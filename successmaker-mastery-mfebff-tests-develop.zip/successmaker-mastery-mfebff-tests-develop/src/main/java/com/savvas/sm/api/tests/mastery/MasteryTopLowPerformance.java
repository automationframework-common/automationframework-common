package com.savvas.sm.api.tests.mastery;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.MasteryAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.DataSetupConstants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.course.CourseAPI;
import com.savvas.sm.utils.sme187.teacher.api.groups.GroupAPI;
import com.savvas.sm.utils.sme187.teacher.api.mastery.MasteryAPI;
import com.savvas.sm.utils.sme187.teacher.api.mastery.MasteryPerformanceConstant;

import io.restassured.response.Response;

/**
 * Method for testing the mastery performance -skills in the micro service call
 * 
 * @author aravindan.sivanandan
 */
public class MasteryTopLowPerformance extends EnvProperties {

	private String smUrl;
	private String teacherDetails;
	private String teacherUsername;
	private String teacherUserId;
	private String orgId;
	private String studentDetails;
	private String studentUsername;
	private String studentUserId;
	private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
	private List<String> studentRumbaIds = new ArrayList<>();
	private Map<String, String> courseName = new HashMap<>();
	private Map<String, String> assignmentIds = new HashMap<>();
	String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
	private String browser;
	String assignmentUserId;
	private static HashMap<String, String> assignmentDetails = new HashMap<>();
	private static HashMap<String, String> contentBase = new HashMap<>();
	private static HashMap<String, String> contentBaseName = new HashMap<>();

	private Map<String, String> courseIds = new HashMap<>();
	private List<String> schools = new ArrayList<>();
	private HashMap<String, String> groupDetails = new HashMap<>();
	private HashMap<String, String> userDetails = new HashMap<>();

	@BeforeClass(alwaysRun = true)
	public void init() throws Exception {
		// Retrieving URL & District ID from Config.properites
		smUrl = configProperty.getProperty("SMAppUrl");
		browser = configProperty.getProperty("BrowserPlatformToRun");
		orgId = RBSDataSetup.organizationIDs.get(school);
		teacherDetails = RBSDataSetup.getMyTeacher(school);
		teacherUsername = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
		teacherUserId = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID);
		studentDetails = RBSDataSetup.getMyStudent(school, teacherUsername);
		studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERNAME);
		studentUserId = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERID);
		Log.message("Student : " + studentUserId);
		studentRumbaIds.add(SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERID));

		String teacherAccessToken = null;
		try {
			teacherAccessToken = new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD);
		} catch (Exception e) {
			Log.message("Issue in get the accces token - " + e.getMessage());
			try {
				Log.message("Retrying to get the access token!!!!");
				teacherAccessToken = new RBSUtils().getAccessToken(teacherUsername,
						RBSDataSetupConstants.DEFAULT_PASSWORD);
			} catch (Exception e1) {
				Log.fail("Unable to create the access token for the teacher - " + teacherUsername);
			}
		}

		HashMap<String, String> staffDetails = new HashMap<>();
		staffDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
		staffDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherUserId);
		staffDetails.put(AssignmentAPIConstants.COURSE_ID, "2");
		staffDetails.put(RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken);

		try {
			// Assigning Assignment
			Log.message("Assigning assignment...");

			HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments(smUrl,
					staffDetails, studentRumbaIds, Arrays.asList(AssignmentAPIConstants.READING));

			Log.message("Assignment Response : " + assignmentResponse);

		} catch (Exception e) {
			Log.fail("Issue in Assigning the assignment to the student!! - " + e.getMessage());
		}

		executeCourse(studentUsername, Constants.READING, false);
	}

	@Test(dataProvider = "getDataForPostivieScenarios", groups = { "SMK-51618", "somke_test_case",
			"Mastery API Refactoring ( Dev Verification ) - Mastery performance API - Skills", "API" }, priority = 1)
	public void postMasteryPerformanceTest001(String testcaseName, String expected_StatusCode,
			String testcaseDescription, String scenarioType) throws Exception {
		// headers
		Map<String, String> headers = new HashMap<String, String>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		Map<String, Object> payload = new HashMap<>();
		switch (scenarioType) {
		case "WITH_MANDATORY_FILEDS":
			headers.put(Constants.AUTHORIZATION, Constants.BEARER
					+ new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
			headers.put(Constants.USERID_SM_HEADER, teacherUserId);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_SUBJECTID,
					MasteryAPIConstants.MasteryPerformanceConstants.READING_SUBJECT_ID);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_STUDENTIDS,
					"[\"" + studentUserId + "\"]");
			break;

		case "MANDATORY_FIELDS_WITH_ASSIGNMENTID":
			headers.put(Constants.AUTHORIZATION, Constants.BEARER
					+ new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
			headers.put(Constants.USERID_SM_HEADER, teacherUserId);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_SUBJECTID,
					MasteryAPIConstants.MasteryPerformanceConstants.READING_SUBJECT_ID);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_STUDENTIDS, "[\"" + studentUserId + "\"]");
			payload.put(Constants.ASSIGNMENT_ID, AssignmentAPIConstants.READING);
			break;

		case "MANDATORY_FIELDS_WITH_ALLFIELDS":
			headers.put(Constants.AUTHORIZATION, Constants.BEARER
					+ new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
			headers.put(Constants.USERID_SM_HEADER, teacherUserId);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_SUBJECTID,
					MasteryAPIConstants.MasteryPerformanceConstants.READING_SUBJECT_ID);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_STUDENTIDS, "[\"" + studentUserId + "\"]");
			payload.put(Constants.ASSIGNMENT_ID, AssignmentAPIConstants.READING);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_LIMIT,
					MasteryAPIConstants.MasteryPerformanceConstants.LIMIT);
			break;

		}

		HashMap<String, String> masteryPerformance = getMasteryPerformance(smUrl, headers, payload);
		String actualstatuscode = masteryPerformance.get(Constants.STATUS_CODE);
		Log.message(actualstatuscode);
		Log.message(masteryPerformance.get(Constants.REPORT_BODY));
		Log.assertThat(actualstatuscode.equals(expected_StatusCode),
				"The actual status code " + masteryPerformance.get(Constants.STATUS_CODE) + "is the same as expected status code "
						+ expected_StatusCode,
				"The actual status code " + masteryPerformance.get(Constants.STATUS_CODE)
						+ "is not the same as expected status code " + expected_StatusCode);
		
	}

	@DataProvider
	public Object[][] getDataForPostivieScenarios() {
		Object[][] data = {
				{ "TC:01 ", "200",
						"Verify 200 status code and response body when valid data with mandatory fields are given",
						"WITH_MANDATORY_FILEDS" },
				{ "TC:02 ", "200",
						"Verify 200 status code and response body when valid data are given with Assignment ID ",
						"MANDATORY_FIELDS_WITH_ASSIGNMENTID" },
				{ "TC:03 ", "200", "Verify 200 status code and response body when valid data are given with all fields",
						"MANDATORY_FIELDS_WITH_ALLFIELDS" },

		};
		return data;
	}

	@Test(enabled = false, dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51618",
			"Mastery API Refactoring ( Dev Verification ) - Mastery performance API - Skills", "API" }, priority = 2)
	public void postMasteryPerformanceTest002(String testcaseName, String expected_StatusCode,
			String testcaseDescription, String scenarioType) throws Exception {
		// headers
		Map<String, String> headers = new HashMap<String, String>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		Map<String, Object> payload = new HashMap<>();
		switch (scenarioType) {

		case "INVALID_AUTH":
			headers.put(Constants.AUTHORIZATION,
					new RBSUtils().getAccessToken(MasteryAPIConstants.MasteryPerformanceConstants.USERNAME_VALUE,
							MasteryAPIConstants.MasteryPerformanceConstants.PASSWORD));
			headers.put(MasteryAPIConstants.MasteryPerformanceConstants.ORGANIZATION_ID,
					MasteryAPIConstants.MasteryPerformanceConstants.ORGANIZATION_ID_VALUE);
			headers.put(MasteryAPIConstants.MasteryPerformanceConstants.USER_ID,
					MasteryAPIConstants.MasteryPerformanceConstants.USER_ID_VALUE);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_SUBJECTID,
					MasteryAPIConstants.MasteryPerformanceConstants.MATH_SUBJECT_ID);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_STUDENTIDS,
					Arrays.asList(MasteryAPIConstants.MasteryPerformanceConstants.STUDENT_USER_ID_1));
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_ASSIGNMENTIDS,
					Arrays.asList(MasteryAPIConstants.MasteryPerformanceConstants.ASSIGNMENTID_VALUE1));
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_LIMIT,
					MasteryAPIConstants.MasteryPerformanceConstants.LIMIT);
			break;

		case "INVALID_ORG_ID":
			headers.put(Constants.AUTHORIZATION,
					Constants.BEARER + new RBSUtils().getAccessToken(
							MasteryAPIConstants.MasteryPerformanceConstants.USERNAME_VALUE,
							MasteryAPIConstants.MasteryPerformanceConstants.PASSWORD));
			headers.put(MasteryAPIConstants.MasteryPerformanceConstants.ORGANIZATION_ID,
					MasteryAPIConstants.MasteryPerformanceConstants.INVALID_ORG_ID_VALUE);
			headers.put(MasteryAPIConstants.MasteryPerformanceConstants.USER_ID,
					MasteryAPIConstants.MasteryPerformanceConstants.USER_ID_VALUE);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_SUBJECTID,
					MasteryAPIConstants.MasteryPerformanceConstants.MATH_SUBJECT_ID);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_STUDENTIDS,
					Arrays.asList(MasteryAPIConstants.MasteryPerformanceConstants.STUDENT_USER_ID_1));
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_ASSIGNMENTIDS,
					Arrays.asList(MasteryAPIConstants.MasteryPerformanceConstants.ASSIGNMENTID_VALUE1));
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_LIMIT,
					MasteryAPIConstants.MasteryPerformanceConstants.LIMIT);
			break;

		case "WITHOUT_SUBJECT_ID":
			headers.put(Constants.AUTHORIZATION,
					Constants.BEARER + new RBSUtils().getAccessToken(
							MasteryAPIConstants.MasteryPerformanceConstants.USERNAME_VALUE,
							MasteryAPIConstants.MasteryPerformanceConstants.PASSWORD));
			headers.put(MasteryAPIConstants.MasteryPerformanceConstants.ORGANIZATION_ID,
					MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID_VALUE);
			headers.put(MasteryAPIConstants.MasteryPerformanceConstants.USER_ID,
					MasteryAPIConstants.MasteryDetailsConstant.USER_ID_VALUE);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_STUDENTIDS,
					Arrays.asList(MasteryAPIConstants.MasteryPerformanceConstants.STUDENT_USER_ID_1));
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_ASSIGNMENTIDS,
					Arrays.asList(MasteryAPIConstants.MasteryPerformanceConstants.ASSIGNMENTID_VALUE1));
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_LIMIT,
					MasteryAPIConstants.MasteryPerformanceConstants.LIMIT);
			break;

		case "WITHOUT_STUDENT_ID":
			headers.put(Constants.AUTHORIZATION,
					Constants.BEARER
							+ new RBSUtils().getAccessToken(MasteryAPIConstants.MasteryDetailsConstant.USERNAME_VALUE,
									MasteryAPIConstants.MasteryPerformanceConstants.PASSWORD));
			headers.put(MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID,
					MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID_VALUE);
			headers.put(MasteryAPIConstants.MasteryDetailsConstant.USER_ID,
					MasteryAPIConstants.MasteryDetailsConstant.USER_ID_VALUE);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_SUBJECTID,
					MasteryAPIConstants.MasteryPerformanceConstants.MATH_SUBJECT_ID);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_ASSIGNMENTIDS,
					Arrays.asList(MasteryAPIConstants.MasteryPerformanceConstants.ASSIGNMENTID_VALUE1));
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_LIMIT,
					MasteryAPIConstants.MasteryPerformanceConstants.LIMIT);
			break;

		case "EMPTY_BODY":
			headers.put(Constants.AUTHORIZATION,
					Constants.BEARER + new RBSUtils().getAccessToken(
							MasteryAPIConstants.MasteryPerformanceConstants.USERNAME_VALUE,
							MasteryAPIConstants.MasteryPerformanceConstants.PASSWORD));
			headers.put(MasteryAPIConstants.MasteryPerformanceConstants.ORGANIZATION_ID,
					MasteryAPIConstants.MasteryPerformanceConstants.ORGANIZATION_ID_VALUE);
			headers.put(MasteryAPIConstants.MasteryPerformanceConstants.USER_ID,
					MasteryAPIConstants.MasteryPerformanceConstants.USER_ID_VALUE);
			break;

		}

		HashMap<String, String> masteryPerformance = getMasteryPerformance(smUrl, headers, payload);
		int actualstatuscode = Integer.parseInt(masteryPerformance.get(Constants.STATUS_CODE));
		Log.message(masteryPerformance.get(Constants.REPORT_BODY));
		Log.assertThat(actualstatuscode == Integer.parseInt(expected_StatusCode),
				"The actual status code " + masteryPerformance.get(Constants.STATUS_CODE) + "is the same as expected status code "
						+ expected_StatusCode,
				"The actual status code " + masteryPerformance.get(Constants.STATUS_CODE)
						+ "is not the same as expected status code " + expected_StatusCode);
	}

	@DataProvider
	public Object[][] getDataForNegativeScenarios() {
		Object[][] data = {
				{ "TC:04 ", "401", "Verify 401 status code when invalid authorization is provided", "INVALID_AUTH" },
				{ "TC:05 ", "403", "Verify 403 status code when irrespective org id is given", "INVALID_ORG_ID" },
				{ "TC:06 ", "401", "Verify 401 status code when Subject ID is not given ", "WITHOUT_SUBJECT_ID" },
				{ "TC:07 ", "400", "Verify 400 status code when Student Id is not given", "WITHOUT_STUDENT_ID" },
				{ "TC:08 ", "400", "Verify 400 status code when no request body is given", "EMPTY_BODY" },

		};
		return data;
	}

	/**
	 * Method for testing the mastery performance -Standards in the micro service
	 * call
	 * 
	 * @author saravanan.murugesan
	 */

	@Test(dataProvider = "getDataForPostivieScenariosStandards", groups = { "somke_test_case","SMK-51616",
			"Mastery API Refactoring ( Dev Verification ) - Mastery performance API - Standards", "API" }, priority = 3)
	public void postMasteryPerformanceTestStandard003(String testcaseName, String expected_StatusCode,
			String testcaseDescription, String scenarioType) throws Exception {
		// headers
		Map<String, String> headers = new HashMap<String, String>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		Map<String, Object> payload = new HashMap<>();
		switch (scenarioType) {
		case "WITH_MANDATORY_FIelds":
			headers.put(Constants.AUTHORIZATION, Constants.BEARER
					+ new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
			headers.put(Constants.USERID_SM_HEADER, teacherUserId);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_SUBJECTID,
					MasteryAPIConstants.MasteryPerformanceConstants.READING_SUBJECT_ID);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_STUDENTIDS, "[\"" + studentUserId + "\"]");
			break;

		case "MANDATORY_FIELDS_WITH_Subject_ID":
			headers.put(Constants.AUTHORIZATION, Constants.BEARER
					+ new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
			headers.put(Constants.USERID_SM_HEADER, teacherUserId);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_SUBJECTID,
					MasteryAPIConstants.Mastery_Performance_Standards.READING_SUBJECT_ID);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_STUDENTIDS, "[\"" + studentUserId + "\"]");
			
			break;

		case "MANDATORY_FIELDS_WITH_LIMIT":
			headers.put(Constants.AUTHORIZATION, Constants.BEARER
					+ new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
			headers.put(Constants.USERID_SM_HEADER, teacherUserId);
			headers.put(Constants.ORGID_SM_HEADER, orgId);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_SUBJECTID,
					MasteryAPIConstants.Mastery_Performance_Standards.READING_SUBJECT_ID);
			payload.put(MasteryAPIConstants.MasteryPerformanceConstants.REQ_STUDENTIDS, "[\"" + studentUserId + "\"]");
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_LIMIT,
					MasteryAPIConstants.Mastery_Performance_Standards.LIMIT);
			break;
		}
		HashMap<String, String> masteryPerformance = getMasteryPerformance(smUrl, headers, payload);
		String actualstatuscode = masteryPerformance.get(Constants.STATUS_CODE);
		Log.message(masteryPerformance.get(Constants.REPORT_BODY));
		Log.assertThat(actualstatuscode.equals(expected_StatusCode),
				"The actual status code " + masteryPerformance.get(Constants.STATUS_CODE) + "is the same as expected status code "
						+ expected_StatusCode,
				"The actual status code " + masteryPerformance.get(Constants.STATUS_CODE)
						+ "is not the same as expected status code " + expected_StatusCode);
		
		}
	
	

	@DataProvider
	public Object[][] getDataForPostivieScenariosStandards() {
		Object[][] data = {
				{ "TC:01 ", "200",
						"Verify 200 status code and response body when valid data with mandatory fields are given",
						"WITH_MANDATORY_FIelds" },
				{ "TC:02 ", "200",
						"Verify 200 status code and response body when valid data are given with Standard ID ",
						"MANDATORY_FIELDS_WITH_Subject_ID" },
				{ "TC:03 ", "200", "Verify 200 status code and response body when valid data are given with all fields",
						"MANDATORY_FIELDS_WITH_LIMIT" }, };
		return data;
	}

	@Test(dataProvider = "getDataForNegativeScenariosStandards", groups = { "SMK-51616",
			"Mastery API Refactoring ( Dev Verification ) - Mastery performance API - Standards", "API" }, priority = 4)
	public void postMasteryPerformanceTestStandard004(String testcaseName, String expected_StatusCode,
			String testcaseDescription, String scenarioType) throws Exception {
		// headers
		Map<String, String> headers = new HashMap<String, String>();
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		Map<String, Object> payload = new HashMap<>();
		switch (scenarioType) {

		case "INVALID_AUTH":
			headers.put(Constants.AUTHORIZATION,
					new RBSUtils().getAccessToken(MasteryAPIConstants.Mastery_Performance_Standards.USERNAME_VALUE,
							MasteryAPIConstants.Mastery_Performance_Standards.PASSWORD));
			headers.put(MasteryAPIConstants.Mastery_Performance_Standards.ORGANIZATION_ID,
					MasteryAPIConstants.Mastery_Performance_Standards.ORGANIZATION_ID_VALUE);
			headers.put(MasteryAPIConstants.Mastery_Performance_Standards.USER_ID,
					MasteryAPIConstants.Mastery_Performance_Standards.USER_ID_VALUE);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_SUBJECTID,
					MasteryAPIConstants.Mastery_Performance_Standards.MATH_SUBJECT_ID);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_STUDENTIDS,
					Arrays.asList(MasteryAPIConstants.Mastery_Performance_Standards.STUDENT_USER_ID_1,
							MasteryAPIConstants.Mastery_Performance_Standards.STUDENT_USER_ID_2,
							MasteryAPIConstants.Mastery_Performance_Standards.STUDENT_USER_ID_3));
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_ASSIGNMENTIDS,
					Arrays.asList(MasteryAPIConstants.Mastery_Performance_Standards.ASSIGNMENTID_VALUE1));
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_STANDARDIDS,
					MasteryAPIConstants.Mastery_Performance_Standards.standardId);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_LIMIT,
					MasteryAPIConstants.Mastery_Performance_Standards.LIMIT);
			break;

		case "INVALID_ORG_ID":
			headers.put(Constants.AUTHORIZATION,
					Constants.BEARER + new RBSUtils().getAccessToken(
							MasteryAPIConstants.Mastery_Performance_Standards.USERNAME_VALUE,
							MasteryAPIConstants.Mastery_Performance_Standards.PASSWORD));
			headers.put(MasteryAPIConstants.Mastery_Performance_Standards.ORGANIZATION_ID,
					MasteryAPIConstants.Mastery_Performance_Standards.INVALID_ORG_ID_VALUE);
			headers.put(MasteryAPIConstants.Mastery_Performance_Standards.USER_ID,
					MasteryAPIConstants.Mastery_Performance_Standards.USER_ID_VALUE);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_SUBJECTID,
					MasteryAPIConstants.Mastery_Performance_Standards.MATH_SUBJECT_ID);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_STUDENTIDS,
					Arrays.asList(MasteryAPIConstants.Mastery_Performance_Standards.STUDENT_USER_ID_1,
							MasteryAPIConstants.Mastery_Performance_Standards.STUDENT_USER_ID_2,
							MasteryAPIConstants.Mastery_Performance_Standards.STUDENT_USER_ID_3));
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_ASSIGNMENTIDS,
					Arrays.asList(MasteryAPIConstants.Mastery_Performance_Standards.ASSIGNMENTID_VALUE1));
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_STANDARDIDS,
					MasteryAPIConstants.Mastery_Performance_Standards.standardId);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_LIMIT,
					MasteryAPIConstants.Mastery_Performance_Standards.LIMIT);
			break;

		case "WITHOUT_SUBJECT_ID":
			headers.put(Constants.AUTHORIZATION,
					Constants.BEARER + new RBSUtils().getAccessToken(
							MasteryAPIConstants.Mastery_Performance_Standards.USERNAME_VALUE,
							MasteryAPIConstants.Mastery_Performance_Standards.PASSWORD));
			headers.put(MasteryAPIConstants.Mastery_Performance_Standards.ORGANIZATION_ID,
					MasteryAPIConstants.Mastery_Performance_Standards.ORGANIZATION_ID_VALUE);
			headers.put(MasteryAPIConstants.Mastery_Performance_Standards.USER_ID,
					MasteryAPIConstants.Mastery_Performance_Standards.USER_ID_VALUE);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_STUDENTIDS,
					Arrays.asList(MasteryAPIConstants.Mastery_Performance_Standards.STUDENT_USER_ID_1,
							MasteryAPIConstants.Mastery_Performance_Standards.STUDENT_USER_ID_2,
							MasteryAPIConstants.Mastery_Performance_Standards.STUDENT_USER_ID_3));
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_ASSIGNMENTIDS,
					Arrays.asList(MasteryAPIConstants.Mastery_Performance_Standards.ASSIGNMENTID_VALUE1));
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_STANDARDIDS,
					MasteryAPIConstants.Mastery_Performance_Standards.standardId);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_LIMIT,
					MasteryAPIConstants.Mastery_Performance_Standards.LIMIT);
			break;

		case "WITHOUT_STUDENT_ID":
			headers.put(Constants.AUTHORIZATION,
					Constants.BEARER + new RBSUtils().getAccessToken(
							MasteryAPIConstants.Mastery_Performance_Standards.USERNAME_VALUE,
							MasteryAPIConstants.Mastery_Performance_Standards.PASSWORD));
			headers.put(MasteryAPIConstants.Mastery_Performance_Standards.ORGANIZATION_ID,
					MasteryAPIConstants.Mastery_Performance_Standards.ORGANIZATION_ID_VALUE);
			headers.put(MasteryAPIConstants.Mastery_Performance_Standards.USER_ID,
					MasteryAPIConstants.Mastery_Performance_Standards.USER_ID_VALUE);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_SUBJECTID,
					MasteryAPIConstants.Mastery_Performance_Standards.MATH_SUBJECT_ID);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_ASSIGNMENTIDS,
					Arrays.asList(MasteryAPIConstants.Mastery_Performance_Standards.ASSIGNMENTID_VALUE1));
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_STANDARDIDS,
					MasteryAPIConstants.Mastery_Performance_Standards.standardId);
			payload.put(MasteryAPIConstants.Mastery_Performance_Standards.REQ_LIMIT,
					MasteryAPIConstants.Mastery_Performance_Standards.LIMIT);
			break;

		case "EMPTY_BODY":
			headers.put(Constants.AUTHORIZATION,
					Constants.BEARER + new RBSUtils().getAccessToken(
							MasteryAPIConstants.Mastery_Performance_Standards.USERNAME_VALUE,
							MasteryAPIConstants.Mastery_Performance_Standards.PASSWORD));
			headers.put(MasteryAPIConstants.Mastery_Performance_Standards.ORGANIZATION_ID,
					MasteryAPIConstants.Mastery_Performance_Standards.ORGANIZATION_ID_VALUE);
			headers.put(MasteryAPIConstants.Mastery_Performance_Standards.USER_ID,
					MasteryAPIConstants.Mastery_Performance_Standards.USER_ID_VALUE);
			break;

		}

		HashMap<String, String> masteryPerformance = getMasteryPerformance(smUrl, headers, payload);
		int actualstatuscode = Integer.parseInt(masteryPerformance.get(Constants.STATUS_CODE));
		Log.message(masteryPerformance.get(Constants.REPORT_BODY));
		Log.assertThat(actualstatuscode == Integer.parseInt(expected_StatusCode),
				"The actual status code " + masteryPerformance.get(Constants.STATUS_CODE) + "is the same as expected status code "
						+ expected_StatusCode,
				"The actual status code " + masteryPerformance.get(Constants.STATUS_CODE)
						+ "is not the same as expected status code " + expected_StatusCode);
	}

	@DataProvider
	public Object[][] getDataForNegativeScenariosStandards() {
		Object[][] data = {
				{ "TC:04 ", "401", "Verify 401 status code when invalid authorization is provided", "INVALID_AUTH" },
				{ "TC:05 ", "403", "Verify 403 status code when wrong org id is given", "INVALID_ORG_ID" },
				{ "TC:06 ", "400", "Verify 400 status code when Subject ID is not given ", "WITHOUT_SUBJECT_ID" },
				{ "TC:07 ", "400", "Verify 400 status code when Student Id is not given", "WITHOUT_STUDENT_ID" },
				{ "TC:08 ", "400", "Verify 400 status code when no request body is given", "EMPTY_BODY" }, };
		return data;
	}

	/**
	 * To execute the course
	 *
	 * @param studentUserName
	 * @param courseName
	 * @throws IOException
	 */
	public void executeCourse(String studentUserName, String courseName, boolean isMath) throws IOException {
		final WebDriver driver = WebDriverFactory.get(browser);
		Log.message("Student username " + studentUserName);
		LoginWrapper.loginToSuccessMakerAsStudent(driver, smUrl, UserType.BASIC, null, studentUserName,
				RBSDataSetupConstants.DEFAULT_PASSWORD);
		StudentDashboardPage studentsPage = new StudentDashboardPage(driver);

		if (isMath) {
			try {
				studentsPage.executeMathCourse(studentUserName, courseName, "100", "2", "20");
				studentsPage.logout();
				driver.close();
			} catch (Exception e) {
				driver.close();
			}
		} else {
			try {
				studentsPage.executeReadingCourse(studentUserName, courseName, "100", "2", "20");
				studentsPage.logout();
				driver.close();
			} catch (Exception e) {
				driver.close();
			}
		}

	}

	public HashMap<String, String> getMasteryPerformance(String smUrl, Map<String, String> headers,
			Map<String, Object> requestBody) throws Exception {

		String body = "{ \"subjectId\":" + requestBody.get("subjectId") + ",\"studentIds\":"
				+ requestBody.get("studentIds");
		if (Objects.nonNull(requestBody.get("assignmentIds"))) {
			body = body + "\"assignmentIds\":" + requestBody.get("assignmentIds").toString() + "}";
		} else {
			body = body + "}";
		}
		Log.message(body);
		return RestHttpClientUtil.POST(smUrl, headers, new HashMap<>(),
				MasteryPerformanceConstant.MASTERY_PERFORMANCE_ENDPOINT, body);

		// return RestAssuredAPIUtil.POST_REQ( smUrl, headers, requestBody,
		// MasteryPerformanceConstant.MASTERY_PERFORMANCE_ENDPOINT);

	}

}
