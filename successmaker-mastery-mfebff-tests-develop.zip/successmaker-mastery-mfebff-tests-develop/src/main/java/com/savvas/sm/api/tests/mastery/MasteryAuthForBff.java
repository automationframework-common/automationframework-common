package com.savvas.sm.api.tests.mastery;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.savvas.sm.api.tests.BaseAPITest;
import com.savvas.sm.common.utils.apiconstants.MasteryAPIConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.rbs.RBSUtils;

public class MasteryAuthForBff extends BaseAPITest {

	String orgId;

	/**
	 * Method for testing getThreeSixtyId GraphQL-Positive cases.
	 * 
	 * @param tcID
	 * @throws Exception
	 */

	@Test( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-51120", "Auth integration for BFF", "GraphQL",
			"BFF" }, priority = 1 )
	public void getThreeSixtyIdTest001( String testcaseName, String expected_StatusCode, String testcaseDescription,
			String scenarioType ) throws Exception {

		// headers
		Map<String, String> headers = new HashMap<String, String>();
		headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
		headers.put( Constants.AUTHORIZATION,
				Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_Summary_BFF.CA_USER_NAME,
						MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );

		// For Constructing QueryItems in request PayLoad
		List<String> queryItems = new ArrayList<String>();
		String queryItem = null;

		Log.testCaseInfo( testcaseName + testcaseDescription );
		switch ( scenarioType ) {
		case "ALL_QUERYITEMS":
			orgId = MasteryAPIConstants.Mastery_Summary_BFF.CA_ORG_ID;

			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.DESCRIPTION );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.DISPLAYNAME );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.ADDRESS1 );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.ADDRESS2 );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.CITY );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.STATE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.ZIPCODE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.COUNTRY );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.NAME );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.ORGANIZATIONID );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.STATUS );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.ORGANIZATIONTYPE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.SOURCESYSTEM );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.LASTUPDATEDDATE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.CREATEDDATE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.LASTUPDATEDBY );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.CREATEDBY );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.DISPLAYGROUP );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.ATTRIBUTES );
			List<String> attribute_QueryItems = new ArrayList<String>();
			String Attribute_queryItem = null;
			attribute_QueryItems.add( "attributeValue" );
			attribute_QueryItems.add( "attributeKey" );
			Attribute_queryItem = constructQueryItems( attribute_QueryItems );
			queryItems.add( Attribute_queryItem );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.THREESIXTYID );
			queryItem = constructQueryItems( queryItems );
			break;

		case "ALL_SET_QUERY_ITEMS":
			orgId = MasteryAPIConstants.Mastery_Summary_BFF.CA_ORG_ID;

			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.DESCRIPTION );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.DISPLAYNAME );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.ADDRESS1 );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.ADDRESS2 );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.CITY );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.STATE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.ZIPCODE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.COUNTRY );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.NAME );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.ORGANIZATIONID );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.STATUS );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.ORGANIZATIONTYPE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.SOURCESYSTEM );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.LASTUPDATEDDATE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.CREATEDDATE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.LASTUPDATEDBY );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.CREATEDBY );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.DISPLAYGROUP );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.THREESIXTYID );
			queryItem = constructQueryItems( queryItems );
			break;

		case "SINGLE_QUERY_ITEM":
			orgId = MasteryAPIConstants.Mastery_Summary_BFF.CA_ORG_ID;

			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.THREESIXTYID );
			queryItem = constructQueryItems( queryItems );
			break;

		case "MULTIPLE_QUERY_ITEMS":
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.DESCRIPTION );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.CREATEDDATE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.STATUS );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.THREESIXTYID );
			queryItem = constructQueryItems( queryItems );
			break;

		}

		// frame graphQl payLoad
		String payload = String.format( MasteryConstants.Graphql.Get3SixtyId.REQ_PAYLOAD, orgId, queryItem );

		Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.BASE_URL, headers, payload,
				MasteryConstants.Graphql.ENDPOINT );
		Log.message( response.getBody().asString() );
//        actual_StatusCode = response.getStatusCode();
//        String data = SMUtils.getKeyValueFromResponse(  response.getBody().asString(), "data"  );
//        String getThreesixty = SMUtils.getKeyValueFromResponse(  data, "getThreeSixtyId"  );
//        String threeSixtyId_Value = SMUtils.getKeyValueFromResponse(  getThreesixty, "threeSixtyId"  );
//
//        Log.assertThat(  actual_StatusCode == Integer.parseInt(  expected_StatusCode  ), "The actual status code " + actual_StatusCode + "is the same as expected status code " + expected_StatusCode,
//                "The actual status code " + actual_StatusCode + "is not the same as expected status code " + expected_StatusCode  );
//        Log.assertThat(  threeSixtyId_Value.equalsIgnoreCase(  MasteryConstants.Graphql.Get3SixtyId.EXPECTED_3SIXTYID_VALUE  ), "Returns expected threeSixtyId Value", "The threeSixtyId value is not matched as expected"  );

		if ( scenarioType.equalsIgnoreCase( "ALL_QUERYITEMS" ) ) {
			Log.assertThat( 
					new SMAPIProcessor().isSchemaValid( "getThreeSixtyIdReponseSchema", expected_StatusCode,
							response.getBody().asString() ),
					"Schema is returned as expected.", "Schema is not as expected." );
		} else {
			Log.assertThat( 
					new SMAPIProcessor().isSchemaValid( "getThreeSixtyIdReponseSchema", expected_StatusCode,
							response.getBody().asString() ),
					"Schema is returned as expected.", "Schema is not as expected." );
			Log.assertThat( 
					new SMAPIProcessor().isGraphQlResponseIncludesGivenParams( response.getBody().asString(),
							queryItems ),
					"Response includes the QueryItems", "Response doesn't includes the QueryItems" );
		}
		Log.testCaseResult();
	}

	@Test( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51120", "Auth integration for BFF", "GraphQL",
			"BFF" }, priority = 2 )
	public void getThreeSixtyIdTest002( String testcaseName, String expected_StatusCode, String testcaseDescription,
			String scenarioType ) throws Exception {
		// headers
		Map<String, String> headers = new HashMap<String, String>();
		// For Constructing QueryItems in request PayLoad
		List<String> queryItems = new ArrayList<String>();
		String queryItem = null;

		Log.testCaseInfo( testcaseName + testcaseDescription );
		switch ( scenarioType ) {
		case "INVALID_AUTH":
			headers.put( Constants.AUTHORIZATION,
					Constants.BEARER
							+ new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_Summary_BFF.CA_USER_NAME,
									MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD )
							+ 123 );
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			queryItems.add( MasteryConstants.Graphql.Get3SixtyId.THREESIXTYID );
			queryItem = constructQueryItems( queryItems );
			break;

		case "INVALID_PAYLOAD":
			headers.put( Constants.AUTHORIZATION,
					Constants.BEARER
							+ new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_Summary_BFF.CA_USER_NAME,
									MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );
			headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
			queryItems.add( "122" );
			queryItem = constructQueryItems( queryItems );
			break;
		}

		// frame graphQl payLoad
		String orgId = MasteryAPIConstants.Mastery_Summary_BFF.CA_ORG_ID;
		String payload = String.format( MasteryConstants.Graphql.Get3SixtyId.REQ_PAYLOAD, orgId, queryItem );
		Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.BASE_URL, headers, payload,
				MasteryConstants.Graphql.ENDPOINT );
		Log.message( response.getBody().asString() );

		if ( scenarioType.equalsIgnoreCase( "INVALID_AUTH" ) ) {
			String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
			String message = getErrorMessage( error, "message" );
			Log.assertThat( message.equalsIgnoreCase( MasteryConstants.Graphql.Get3SixtyId.UNAUTHORIZED_MESSAGE ),
					"Getting Unauthorized message for Invalid authorization",
					"The Unauthorized message is not getting displayed for Invalid Authorization!" );
		}

		int actual_StatusCode = response.getStatusCode();
		Log.assertThat( actual_StatusCode == Integer.parseInt( expected_StatusCode ),
				"The actual status code " + actual_StatusCode + "is the same as expected status code "
						+ expected_StatusCode,
				"The actual status code " + actual_StatusCode + "is not the same as expected status code "
						+ expected_StatusCode );
	}

	@DataProvider
	public Object[][] getDataForPostivieScenarios() {
		Object[][] data = {
				{ "TC:01 ", "200",
						"Verify that valid response is fetching when all the schemas are given in query paramaters",
						"ALL_QUERYITEMS" },
				{ "TC:02 ", "200",
						"Verify the graphql response is obtaining the predictable result for all set of Fields",
						"ALL_SET_QUERY_ITEMS" },
				{ "TC:03 ", "200", "Verify 200 status code and valid response when a single set query is given",
						"SINGLE_QUERY_ITEM" },
				{ "TC:04 ", "200", "Verify 200 status code and valid response when a multiple set query is given",
						"MULTIPLE_QUERY_ITEMS" }, };
		return data;

	}

	@DataProvider
	public Object[][] getDataForNegativeScenarios() {
		Object[][] data = {
				{ "TC:05 ", "200", "Verify '401: UnAuthorized' message in response when invalid Bearer token is given ",
						"INVALID_AUTH" },
				{ "TC:06 ", "400", "Verify '400: Bad Request' in response when invalid query has been given ",
						"INVALID_PAYLOAD" },

		};
		return data;
	}

	public String constructQueryItems( List<String> queryItems ) {
		String frameQuery = "{";
		for ( String item : queryItems ) {
			if ( frameQuery.endsWith( "{" ) )
				frameQuery = frameQuery + item;
			else
				frameQuery = frameQuery + "," + item;
		}
		frameQuery = frameQuery + "}";
		return frameQuery;
	}

	public String getErrorMessage( String jsonResponse, String message ) {
		String messageValue = "";
		try {
			JSONArray jsonArray = new JSONArray( jsonResponse );
			JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
			messageValue = jsonObject1.optString( message );

		} catch ( JSONException e ) {
			e.printStackTrace();
		}
		return messageValue;
	}

}
