package com.savvas.sm.api.tests.mastery;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.common.utils.apiconstants.MasteryAPIConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.ui.constants.LoginConstants.UserType;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.ui.pages.simulator.StudentDashboardPage;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestHttpClientUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.SQLUtil;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPI;
import com.savvas.sm.utils.sme187.teacher.api.assignment.AssignmentAPIConstants;
import com.savvas.sm.utils.sme187.teacher.api.mastery.MasteryAPI;
import com.savvas.sm.utils.sme187.teacher.api.mastery.MasteryDetailsConstant;
import com.savvas.sm.utils.sme187.teacher.api.mastery.MasteryPerformanceConstant;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

/**
 * Method for testing the mastery details -skills/standards in the micro service
 * call
 * 
 * @author madhan.nagarathinam
 */
public class MasteryDetailsSkillsStandardsAPI extends EnvProperties {

    private String smUrl;
    private String teacherDetails;
    private String teacherUsername;
    private String teacherUserId;
    private String orgId;
    private String studentDetails;
    private String studentUsername;
    private String studentUserId;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    private List<String> studentRumbaIds = new ArrayList<>();
    private Map<String, String> courseName = new HashMap<>();
    private Map<String, String> assignmentIds = new HashMap<>();
    String school = RBSDataSetup.getSchools(Schools.FLEX_SCHOOL);
    private String browser;
    int assignmentUserId;
    private String skillOjId="";
    private static HashMap<String, String> assignmentDetails = new HashMap<>();
    private static HashMap<String, String> contentBase = new HashMap<>();
    private static HashMap<String, String> contentBaseName = new HashMap<>();

    private Map<String, String> courseIds = new HashMap<>();
    private List<String> schools = new ArrayList<>();
    private HashMap<String, String> groupDetails = new HashMap<>();
    private HashMap<String, String> userDetails = new HashMap<>();

    @BeforeClass(alwaysRun = true)
    public void init() throws Exception {
        // Retrieving URL & District ID from Config.properites
        smUrl = configProperty.getProperty("SMAppUrl");
        browser = configProperty.getProperty("BrowserPlatformToRun");
        orgId = RBSDataSetup.organizationIDs.get(school);
        teacherDetails = RBSDataSetup.getMyTeacher(school);
        teacherUsername = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERNAME);
        teacherUserId = SMUtils.getKeyValueFromResponse(teacherDetails, RBSDataSetupConstants.USERID);
        studentDetails = RBSDataSetup.getMyStudent(school, teacherUsername);
        studentUsername = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERNAME);
        studentUserId = SMUtils.getKeyValueFromResponse(studentDetails, RBSDataSetupConstants.USERID);
        Log.message("Student : " + studentUserId);
        studentRumbaIds.add(studentUserId);

        String teacherAccessToken = null;
        try {
            teacherAccessToken = new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD);
        } catch (Exception e) {
            Log.message("Issue in get the accces token - " + e.getMessage());
            try {
                Log.message("Retrying to get the access token!!!!");
                teacherAccessToken = new RBSUtils().getAccessToken(teacherUsername,
                        RBSDataSetupConstants.DEFAULT_PASSWORD);
            } catch (Exception e1) {
                Log.fail("Unable to create the access token for the teacher - " + teacherUsername);
            }
        }

        HashMap<String, String> staffDetails = new HashMap<>();
        staffDetails.put(AssignmentAPIConstants.ORG_ID, orgId);
        staffDetails.put(AssignmentAPIConstants.TEACHER_ID, teacherUserId);
        staffDetails.put(AssignmentAPIConstants.COURSE_ID, "2");
        staffDetails.put(RBSDataSetupConstants.BEARER_TOKEN, teacherAccessToken);

        try {
            // Assigning Assignment
            Log.message("Assigning assignment...");

            HashMap<String, String> assignmentResponse = new AssignmentAPI().assignMultipleAssignments(smUrl,
                    staffDetails, studentRumbaIds, Arrays.asList( AssignmentAPIConstants.READING));

            Log.message("Assignment Response : " + assignmentResponse);
            
            JSONObject readingAssignmentDetailsJson = new JSONObject( assignmentResponse.get( Constants.REPORT_BODY ) );
	        JSONArray readingAssignmentList = readingAssignmentDetailsJson.getJSONArray( Constants.DATA );
	        JSONObject readingAssignmentInfo = new JSONObject( readingAssignmentList.get( 0 ).toString() );
	        String assignmentId = readingAssignmentInfo.get( "assignmentId" ).toString();
	        assignmentUserId = Integer.parseInt(new SqlHelperCourses().getAssignmentUserId( studentRumbaIds.get( 0 ), assignmentId));
	        

        } catch (Exception e) {
            Log.fail("Issue in Assigning the assignment to the student!! - " + e.getMessage());
        }

        executeCourse(studentUsername, Constants.READING, false);
        
        skillOjId=getSkillObjId(assignmentUserId);
        
    }

    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-51614", "somke_test_case","Mastery API Refactoring (Dev Verification) - Mastery LO details API - Standards", "API" }, priority = 1 )
    public void postMasteryDetailsTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, Object> payload = new HashMap<>();
        switch ( scenarioType ) {
            case "WITH_MANDATORY_FILEDS":
                headers.put(Constants.AUTHORIZATION, Constants.BEARER
                        + new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
                headers.put(Constants.USERID_SM_HEADER, teacherUserId);
                headers.put(Constants.ORGID_SM_HEADER, orgId); 
                payload.put(Constants.ASSIGNMENT_USER_ID_VALUE,(assignmentUserId));
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_LEARNING_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.LEARNING_OBJECT_FOR_READING );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_SKILL_OBJECT_ID,skillOjId );
                
                break;

            case "MANDATORY_FIELDS_WITH_STANDARD_VERSION_ID ":
                headers.put(Constants.AUTHORIZATION, Constants.BEARER
                        + new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
                headers.put(Constants.USERID_SM_HEADER, teacherUserId);
                headers.put(Constants.ORGID_SM_HEADER, orgId);
                payload.put(Constants.ASSIGNMENT_USER_ID_VALUE,assignmentUserId);
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_LEARNING_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.LEARNING_OBJECT_FOR_READING );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_SKILL_OBJECT_ID,skillOjId );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_STANDARD_VERSION_ID, MasteryAPIConstants.MasteryDetailsConstant.STANDARD_VERSION_ID_VALUES );
                break;

            case "FOR_READING_SUBJECT ":
            	  headers.put(Constants.AUTHORIZATION, Constants.BEARER
                          + new RBSUtils().getAccessToken(teacherUsername, RBSDataSetupConstants.DEFAULT_PASSWORD));
                  headers.put(Constants.USERID_SM_HEADER, teacherUserId);
                  headers.put(Constants.ORGID_SM_HEADER, orgId); 
                  payload.put(Constants.ASSIGNMENT_USER_ID_VALUE,assignmentUserId);
                  payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_LEARNING_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.LEARNING_OBJECT_FOR_READING );
                  payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_SKILL_OBJECT_ID,skillOjId );
                  
                break;
        }

//        Response response = new MasteryAPI().getMasteryDetails( smUrl, headers, payload );
//        int actualstatuscode = response.getStatusCode();
//        Log.message( response.getBody().asString() );
//        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
//                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
        
        HashMap<String, String> masteryDetails = getMasteryDetails(smUrl, headers, payload);
        
		int actualstatuscode = Integer.parseInt(masteryDetails.get(Constants.STATUS_CODE));
		Log.message(masteryDetails.get(Constants.REPORT_BODY));
		Log.assertThat(actualstatuscode == Integer.parseInt(expected_StatusCode),
				"The actual status code " + masteryDetails.get(Constants.STATUS_CODE) + "is the same as expected status code "
						+ expected_StatusCode,
				"The actual status code " + masteryDetails.get(Constants.STATUS_CODE)
						+ "is not the same as expected status code " + expected_StatusCode);
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC:01 ", "200", "Verify 200 status code and response body when valid data with mandatory fields are given", "WITH_MANDATORY_FILEDS" },
                { "TC:02 ", "200", "Verify 200 status code and response body when valid data are given with all fields", "MANDATORY_FIELDS_WITH_STANDARD_VERSION_ID " },
                { "TC:03 ", "200", "Verify 200 status code and response body when skill object Id is given", "FOR_READING_SUBJECT " }

        };
        return data;
    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51614", "Mastery API Refactoring (Dev Verification) - Mastery LO details API - Standards", "API" }, priority = 2 )
    public void postMasteryDetailsTest002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        Map<String, Object> payload = new HashMap<>();
        switch ( scenarioType ) {

            case "INVALID_AUTH":
                headers.put( Constants.AUTHORIZATION, new RBSUtils().getAccessToken( MasteryAPIConstants.MasteryDetailsConstant.USERNAME_VALUE, MasteryAPIConstants.MasteryDetailsConstant.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID, MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.USER_ID, MasteryAPIConstants.MasteryDetailsConstant.USER_ID_VALUE );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_LEARNING_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.LEARNING_OBJECT_FOR_MATH );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_SKILL_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.SKILL_OBJECT_ID_FOR_MATH );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_ASSIGNMENT_USER_IDS, MasteryAPIConstants.MasteryDetailsConstant.ASSIGNMENT_USER_ID_VALUES );
                break;

            case "INVALID_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.MasteryDetailsConstant.USERNAME_VALUE, MasteryAPIConstants.MasteryDetailsConstant.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID, MasteryAPIConstants.MasteryDetailsConstant.INVALID_ORG_ID_VALUE );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.USER_ID, MasteryAPIConstants.MasteryDetailsConstant.USER_ID_VALUE );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_LEARNING_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.LEARNING_OBJECT_FOR_MATH );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_SKILL_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.SKILL_OBJECT_ID_FOR_MATH );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_ASSIGNMENT_USER_IDS, MasteryAPIConstants.MasteryDetailsConstant.ASSIGNMENT_USER_ID_VALUES );
                break;

            case "INVALID_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.MasteryDetailsConstant.USERNAME_VALUE, MasteryAPIConstants.MasteryDetailsConstant.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID, MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.USER_ID, MasteryAPIConstants.MasteryDetailsConstant.INVALID_USER_ID_VALUE );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_LEARNING_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.LEARNING_OBJECT_FOR_MATH );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_SKILL_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.SKILL_OBJECT_ID_FOR_MATH );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_ASSIGNMENT_USER_IDS, MasteryAPIConstants.MasteryDetailsConstant.ASSIGNMENT_USER_ID_VALUES );
                break;

            case "INVALID_LEARNING_SKILL_OBJECTID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.MasteryDetailsConstant.USERNAME_VALUE, MasteryAPIConstants.MasteryDetailsConstant.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID, MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.USER_ID, MasteryAPIConstants.MasteryDetailsConstant.USER_ID_VALUE );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_LEARNING_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.LEARNING_OBJECT_FOR_READING );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_SKILL_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.SKILL_OBJECT_ID_FOR_MATH );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_ASSIGNMENT_USER_IDS, MasteryAPIConstants.MasteryDetailsConstant.ASSIGNMENT_USER_ID_VALUES );
                break;

            case "INVALID_USERASSIGNMENT_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.MasteryDetailsConstant.USERNAME_VALUE, MasteryAPIConstants.MasteryDetailsConstant.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID, MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.USER_ID, MasteryAPIConstants.MasteryDetailsConstant.USER_ID_VALUE );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_LEARNING_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.LEARNING_OBJECT_FOR_MATH );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_SKILL_OBJECT_ID, MasteryAPIConstants.MasteryDetailsConstant.SKILL_OBJECT_ID_FOR_MATH );
                payload.put( MasteryAPIConstants.MasteryDetailsConstant.REQ_ASSIGNMENT_USER_IDS, MasteryAPIConstants.MasteryDetailsConstant.INVALID_ASSIGNMENT_USER_ID_VALUES );
                break;

            case "EMPTY_BODY":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.MasteryDetailsConstant.USERNAME_VALUE, MasteryAPIConstants.MasteryDetailsConstant.PASSWORD ) );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID, MasteryAPIConstants.MasteryDetailsConstant.ORGANIZATION_ID_VALUE );
                headers.put( MasteryAPIConstants.MasteryDetailsConstant.USER_ID, MasteryAPIConstants.MasteryDetailsConstant.USER_ID_VALUE );
                break;

        }

        Response response = new MasteryAPI().getMasteryDetails( smUrl, headers, payload );
        int actualstatuscode = response.getStatusCode();
        Log.message( response.getBody().toString() );
        Log.assertThat( actualstatuscode == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC:04 ", "401", "Verify 401 status code when invalid authorization is provided", "INVALID_AUTH" }, { "TC:05 ", "403", "Verify 403 status code when irrespective org id is given", "INVALID_ORG_ID" },
                { "TC:06 ", "401", "Verify 401 status code when invalid user id is given", "INVALID_USER_ID" }, { "TC:07 ", "400", "Verify 400 status code when invalid learning and skill object Id is given", "INVALID_LEARNING_SKILL_OBJECTID" },
                { "TC:08 ", "400", "Verify 400 status code when invalid userassignment Id is given", "INVALID_USERASSIGNMENT_ID" }, { "TC:09 ", "400", "Verify 400 status code when no request body is given", "EMPTY_BODY" },

        };
        return data;
    }
    /**
     * To execute the course
     *
     * @param studentUserName
     * @param courseName
     * @throws IOException
     */
    public void executeCourse(String studentUserName, String courseName, boolean isMath) throws IOException {
        final WebDriver driver = WebDriverFactory.get(browser);
        Log.message("Student username " + studentUserName);
        LoginWrapper.loginToSuccessMakerAsStudent(driver, smUrl, UserType.BASIC, null, studentUserName,
                RBSDataSetupConstants.DEFAULT_PASSWORD);
        StudentDashboardPage studentsPage = new StudentDashboardPage(driver);

        if (isMath) {
            try {
                studentsPage.executeMathCourse(studentUserName, courseName, "100", "3", "30");
                studentsPage.logout();
                driver.close();
            } catch (Exception e) {
                driver.close();
            }
        } else {
            try {
                studentsPage.executeReadingCourse(studentUserName, courseName, "100", "3", "30");
                studentsPage.logout();
                driver.close();
            } catch (Exception e) {
                driver.close();
            }
        }

    }
    
    public String getSkillObjId( int assUId ) {

    	List<Object[]> Skill_Id = SQLUtil.executeQuery( "select skill_objective_id from school.read_interaction where assignment_user_id = '" + assUId + "'" );
    	List<String> arrList = new ArrayList<String>();
    	for ( Object[] list : Skill_Id ) {
    		if ( list.length > 0 ) {
    			arrList.add( list[0].toString() );
    		}
    	}
    	String skillObjIdValue = arrList.get( 0 );
    	return skillObjIdValue;
    }
    
    public HashMap<String, String> getMasteryDetails(String smUrl, Map<String, String> headers,
			Map<String, Object> requestBody) throws Exception {

//		String body = "{ \"subjectId\":" + requestBody.get("subjectId") + ",\"studentIds\":"
//				+ requestBody.get("studentIds");
//		if (Objects.nonNull(requestBody.get("assignmentIds"))) {
//			body = body + "\"assignmentIds\":" + requestBody.get("assignmentIds").toString() + "}";
//		} else {
//			body = body + "}";
//		}

		String body = "{ \"assignmentUserIds\": " + "["
				+ requestBody.get(Constants.ASSIGNMENT_USER_ID_VALUE).toString() + "]"
				+ ", \"learningObjectId\": -1, \"skillObjectId\": "
				+ requestBody.get(MasteryAPIConstants.MasteryDetailsConstant.REQ_SKILL_OBJECT_ID).toString()
				+ " ,\"standardVersionId\": \"\"}" + "";

		Log.message(body);
		return RestHttpClientUtil.POST(smUrl, headers, new HashMap<>(),
				MasteryDetailsConstant.MASTERY_DETAILS_ENDPOINT, body);

		// return RestAssuredAPIUtil.POST_REQ( smUrl, headers, requestBody,
		// MasteryPerformanceConstant.MASTERY_PERFORMANCE_ENDPOINT);

	}
    
}
