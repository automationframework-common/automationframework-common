package com.savvas.sm.api.tests.mastery;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.MasteryAPIConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.rbs.RBSUtils;

/**
 * This class is used to test the mastery LO Details BFF call for teacher and
 * admin users
 * 
 * @author madhan.nagarathinam
 *
 */
public class MasteryLODetailsBff extends EnvProperties {
	int read_SkillObjectId = 65;
	int read_LearningObjectId = -1;
	int math_SkillObjectId = -1;
	int math_LearningObjectId = 404;
	String assignmentUserIds = "[47077, 47061]";
	int standardVersionId = -1;

	@Test( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-51621", "( Graphql ) Mastery lo details data API",
			"Bff", "GraphQL" }, priority = 1 )
	public void postMasteryLODetailsTest001( String testcaseName, String expected_StatusCode, String testcaseDescription,
			String scenarioType ) throws Exception {
		// headers
		Map<String, String> headers = new HashMap<String, String>();
		headers.put( Constants.AUTHORIZATION,
				Constants.BEARER
						+ new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_LoDetails_BFF.TEACHER_USERNAME,
								MasteryAPIConstants.Mastery_LoDetails_BFF.PASSWORD ) );
		headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
		headers.put( MasteryAPIConstants.Mastery_LoDetails_BFF.ORGANIZATION_ID,
				MasteryAPIConstants.Mastery_LoDetails_BFF.ORG_ID_VALUE );
		headers.put( MasteryAPIConstants.Mastery_LoDetails_BFF.USER_ID,
				MasteryAPIConstants.Mastery_LoDetails_BFF.TEACHER_USER_ID_VALUE );

		String payload = null;

		// For Constructing QueryItems in request PayLoad
		List<String> queryItems = new ArrayList<String>();
		String queryItem = null;

		Log.testCaseInfo( testcaseName + testcaseDescription );
		switch ( scenarioType ) {

		case "ALL_QUERY_ITEMS":
			queryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.ID );
			queryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.MASTERY_DETAILS );
			List<String> MasteryDetails_QueryItems = new ArrayList<String>();
			String MasteryDetails_QueryItem = null;
			MasteryDetails_QueryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.ASSIGNMENT_TITLE );
			MasteryDetails_QueryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.PERSON_ID );
			MasteryDetails_QueryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.MASTERY_STATUS_ID );
			MasteryDetails_QueryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.SKILLS_EVALUATED );
			MasteryDetails_QueryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.ATTEMPTS );
			MasteryDetails_QueryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.FIRST_NAME );
			MasteryDetails_QueryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.LAST_NAME );
			MasteryDetails_QueryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.USER_NAME );
			MasteryDetails_QueryItem = constructQueryItems( MasteryDetails_QueryItems );
			queryItems.add( MasteryDetails_QueryItem );
			queryItem = constructQueryItems( queryItems );

			payload = String.format( MasteryAPIConstants.Mastery_LoDetails_BFF.REQ_PAYLOAD, math_LearningObjectId,
					math_SkillObjectId, assignmentUserIds, queryItem );

			break;

		case "SINGLE_QUERY_ITEMS":
			queryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.ID );
			queryItem = constructQueryItems( queryItems );
			payload = String.format( MasteryAPIConstants.Mastery_LoDetails_BFF.REQ_PAYLOAD_ALL_PARAMS,
					read_LearningObjectId, read_SkillObjectId, assignmentUserIds, standardVersionId, queryItem );
			break;

		}

		Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL,
				headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
		Log.message( response.getBody().asString() );
		if ( scenarioType.equalsIgnoreCase( "ALL_QUERY_ITEMS" ) ) {
			Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ),
					"The actual status code " + response.getStatusCode() + "is the same as expected status code "
							+ expected_StatusCode,
					"The actual status code " + response.getStatusCode() + "is not the same as expected status code "
							+ expected_StatusCode );
			Log.assertThat( 
					new SMAPIProcessor().isSchemaValid( "masteryLOBff", expected_StatusCode,
							response.getBody().asString() ),
					"Schema is returned as expected.", "Schema is not as expected." );

		} else {
			Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ),
					"The actual status code " + response.getStatusCode() + "is the same as expected status code "
							+ expected_StatusCode,
					"The actual status code " + response.getStatusCode() + "is not the same as expected status code "
							+ expected_StatusCode );

		}

	}

	@Test( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-51621", "( Graphql ) Mastery lo details data API",
			"Bff", "GraphQL" }, priority = 2 )
	public void postMasteryLODetailsTest002( String testcaseName, String expected_StatusCode, String testcaseDescription,
			String scenarioType ) throws Exception {
		// headers
		Map<String, String> headers = new HashMap<String, String>();
		headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

		String payload = null;
		// For Constructing QueryItems in request PayLoad
		List<String> queryItems = new ArrayList<String>();
		String queryItem = null;

		Log.testCaseInfo( testcaseName + testcaseDescription );
		switch ( scenarioType ) {
		case "INVALID_ORG_ID":
			headers.put( Constants.AUTHORIZATION,
					Constants.BEARER
							+ new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_LoDetails_BFF.TEACHER_USERNAME,
									MasteryAPIConstants.Mastery_LoDetails_BFF.PASSWORD ) );
			headers.put( MasteryAPIConstants.Mastery_LoDetails_BFF.ORGANIZATION_ID,
					MasteryAPIConstants.Mastery_LoDetails_BFF.INVALID_ORG_ID_VALUE );
			headers.put( MasteryAPIConstants.Mastery_LoDetails_BFF.USER_ID,
					MasteryAPIConstants.Mastery_LoDetails_BFF.TEACHER_USER_ID_VALUE );

			queryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.ID );
			queryItem = constructQueryItems( queryItems );

			payload = String.format( MasteryAPIConstants.Mastery_LoDetails_BFF.REQ_PAYLOAD_ALL_PARAMS,
					read_LearningObjectId, read_SkillObjectId, assignmentUserIds, standardVersionId, queryItem );

			break;

		case "INVALID_USER_ID":
			headers.put( Constants.AUTHORIZATION,
					Constants.BEARER
							+ new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_LoDetails_BFF.TEACHER_USERNAME,
									MasteryAPIConstants.Mastery_LoDetails_BFF.PASSWORD ) );
			headers.put( MasteryAPIConstants.Mastery_LoDetails_BFF.ORGANIZATION_ID,
					MasteryAPIConstants.Mastery_LoDetails_BFF.ORG_ID_VALUE );
			headers.put( MasteryAPIConstants.Mastery_LoDetails_BFF.USER_ID,
					MasteryAPIConstants.Mastery_LoDetails_BFF.INVALID_USER_ID_VALUE );

			queryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.ID );
			queryItem = constructQueryItems( queryItems );

			payload = String.format( MasteryAPIConstants.Mastery_LoDetails_BFF.REQ_PAYLOAD_ALL_PARAMS,
					read_LearningObjectId, read_SkillObjectId, assignmentUserIds, standardVersionId, queryItem );

			break;

		case "ACCESS_DENIED":
			headers.put( Constants.AUTHORIZATION,
					Constants.BEARER
							+ new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_LoDetails_BFF.STUDENT_USERNAME,
									MasteryAPIConstants.Mastery_LoDetails_BFF.PASSWORD ) );
			headers.put( MasteryAPIConstants.Mastery_LoDetails_BFF.ORGANIZATION_ID,
					MasteryAPIConstants.Mastery_LoDetails_BFF.ORG_ID_VALUE );
			headers.put( MasteryAPIConstants.Mastery_LoDetails_BFF.USER_ID,
					MasteryAPIConstants.Mastery_LoDetails_BFF.STUDENT_USER_ID_VALUE );

			queryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.ID );
			queryItem = constructQueryItems( queryItems );

			payload = String.format( MasteryAPIConstants.Mastery_LoDetails_BFF.REQ_PAYLOAD_ALL_PARAMS,
					read_LearningObjectId, read_SkillObjectId, assignmentUserIds, standardVersionId, queryItem );

			break;

		case "INVALID_PAYLOAD":
			headers.put( Constants.AUTHORIZATION,
					Constants.BEARER
							+ new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_LoDetails_BFF.TEACHER_USERNAME,
									MasteryAPIConstants.Mastery_LoDetails_BFF.PASSWORD ) );
			headers.put( MasteryAPIConstants.Mastery_LoDetails_BFF.ORGANIZATION_ID,
					MasteryAPIConstants.Mastery_LoDetails_BFF.ORG_ID_VALUE );
			headers.put( MasteryAPIConstants.Mastery_LoDetails_BFF.USER_ID,
					MasteryAPIConstants.Mastery_LoDetails_BFF.INVALID_USER_ID_VALUE );

			queryItems.add( MasteryAPIConstants.Mastery_LoDetails_BFF.ID + "{" );
			queryItem = constructQueryItems( queryItems );

			payload = String.format( MasteryAPIConstants.Mastery_LoDetails_BFF.REQ_PAYLOAD_ALL_PARAMS,
					read_LearningObjectId, read_SkillObjectId, assignmentUserIds, standardVersionId, queryItem );

			break;
		}
		Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL,
				headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
		String errors = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
		String extensions = SMUtils.getKeyValueFromResponseWithArray( errors, "path" );

		Log.message( response.getBody().asString() );
		Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ),
				"The actual status code " + response.getStatusCode() + "is the same as expected status code "
						+ expected_StatusCode,
				"The actual status code " + response.getStatusCode() + "is not the same as expected status code "
						+ expected_StatusCode );
		if ( scenarioType.equalsIgnoreCase( "INVALID_USER_ID" ) ) {
			String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
			String message = getErrorMessage( error, "message" );
			Log.assertThat( message.equalsIgnoreCase( MasteryAPIConstants.Mastery_Summary_BFF.UNAUTHENTICATED ),
					"Getting Unauthorized message for Invalid authorization",
					"The Unauthorized message is not getting displayed for Invalid Authorization!" );
		} else if ( scenarioType.equalsIgnoreCase( "INVALID_ORG_ID" ) ) {
			String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
			String message = getErrorMessage( error, "message" );
			Log.assertThat( message.equalsIgnoreCase( MasteryAPIConstants.Mastery_Summary_BFF.UNAUTHENTICATED ),
					"Getting Access Denied message for Invalid users / Irrespective org's",
					"The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );

		} else if ( scenarioType.contentEquals( "ACCESS_DENIED" ) ) {
			String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
			String message = getErrorMessage( error, "message" );
			Log.assertThat( message.equalsIgnoreCase( MasteryAPIConstants.Mastery_Summary_BFF.ACCESS_DENIED ),
					"Getting Access Denied message for Invalid users / Irrespective org's",
					"The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );

		}
	}

	@DataProvider
	public Object[][] getDataForPostivieScenarios() {
		Object[][] data = {

				{ "TC:01 ", "200",
						"Verify GraphQL is obtaining predictable response when all query params are provided for Math LO Id",
						"ALL_QUERY_ITEMS" },
				{ "TC:02 ", "200",
						"Verify GraphQL is obtaining predictable response when single query params are provided for Reading skill objectId",
						"SINGLE_QUERY_ITEMS" }

		};
		return data;
	}

	@DataProvider
	public Object[][] getDataForNegativeScenarios() {
		Object[][] data = {

				{ "TC:03 ", "200", "Verify 403 code when ir-respective org-id is provided", "INVALID_ORG_ID" },
				{ "TC:04 ", "200", "Verify 401 code and unauthorized error message when invalid user-id is provided",
						"INVALID_USER_ID" },
				{ "TC:05 ", "200", "Verify 403 code error message when student Id is given", "ACCESS_DENIED" },
				{ "TC:06 ", "400", "Verify 400 status code when invalid request Payload is given", "INVALID_PAYLOAD" },

		};
		return data;
	}

	// This method is for constructing the query Items for payload
	public String constructQueryItems( List<String> queryItems ) {
		String frameQuery = "{";
		for ( String item : queryItems ) {
			if ( frameQuery.endsWith( "{" ) )
				frameQuery = frameQuery + item;
			else
				frameQuery = frameQuery + "," + item;
		}
		frameQuery = frameQuery + "}";
		return frameQuery;
	}

	// This method is extracting error message from response

	public String getErrorMessage( String jsonResponse, String message ) {
		String messageValue = "";
		try {
			JSONArray jsonArray = new JSONArray( jsonResponse );
			JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
			messageValue = jsonObject1.optString( message );

		} catch ( JSONException e ) {
			e.printStackTrace();
		}
		return messageValue;
	}

}
