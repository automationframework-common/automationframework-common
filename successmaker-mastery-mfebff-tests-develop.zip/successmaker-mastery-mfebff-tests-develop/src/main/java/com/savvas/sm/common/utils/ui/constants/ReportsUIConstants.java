package com.savvas.sm.common.utils.ui.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.learningservices.utils.EnvironmentPropertiesReader;

public interface ReportsUIConstants {
    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();

    public String MFEURL = configProperty.getProperty( "AdminDashboardMFE" );
    String ADMIN_REPORT_MFE_URL = configProperty.getProperty( "AdminReportMFE" );
    String MFE_TEACHER_URL = configProperty.getProperty( "TeacherReportMfe" );
    String AFG_OUTPUT_MFEURL = "https://successmaker-reports-webapp-dev.smdemo.info/teacher-reports/areas-for-growth";
    String MASTERY_MFE_URL = "https://successmaker-mastery-webapp-dev.smdemo.info/";
    String RSR_OUTPUT_MFEURL = "https://successmaker-reports-webapp-dev.smdemo.info/report-viewer/recent-sessions";
    List<String> REPORT_EXECUTION_PERCENTAGE = Arrays.asList( "100", "50", "10", "0" );

    public interface ReportTypes {
        String AREAS_FOR_GROWTH = "Areas For Growth";
        String CUMULATIVE_PERFORMANCE = "Cumulative Performance";
        String CUMULATIVE_PERFORMANCE_AGGREGATE = "Cumulative Performance Aggregate";
        String RECENT_SESSIONS = "Last Session";
        String PRESCRIPTIVE_SCHEDULING = "Prescriptive Scheduling";
        String STUDENT_PERFORMANCE = "Student Performance";
        String SYSTEM_ENROLLMENT_AND_USAGE = "System Enrollment and Usage";
        String LAST_SESSION = "Last Session";
    }

    public interface CPAPayload {
        String PAYLOAD_VALUES = "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getCPAAdminReportData(\\n    organizationId: \\\"{orgId}\\\"\\n    userId: \\\"{userId}\\\"\\n    filterParams: {subject: \\\"{subject}\\\", courseList: [], additionalGrouping: {additionalGrouping}, filterBySchool: [\\\"{selectedOrgId}\\\"], filterByDemographics: {disabilityStatus: [], englishLanguageProficiency: [], gender: [], migrantStatus: [], race: [], ethnicity: [], socioeconomicStatus: [], specialServices: []}}\\n  ) {\\n    courseName\\n    reportRun\\n    grade\\n    dataRows {\\n      orgData {\\n        organizationName\\n        numberOfStudents\\n      }\\n      levelDataMean {\\n        currentCourseLevel\\n        ipLevel\\n        gain\\n      }\\n      usageMean {\\n        timeSpent\\n        totalSessions\\n      }\\n      instructionalPerformanceMean {\\n        exercisesCorrect\\n        exercisesAttempted\\n        exercisesPercentCorrect\\n      }\\n      masteryMean {\\n        skillsAssessed\\n        skillsMastered\\n        skillsPercentMastered\\n        percentStudentsWithAP\\n      }\\n    }\\n  }\\n}\\n\"}";
        List<String> CPA_FILTERS = Arrays.asList( "{subject}", "{courses}", "{additionalGrouping}", "{orgId}", "{userId}", "{selectedOrgId}" );
        List<String> grades = Arrays.asList( "%s (K - %s)", "%s (G1 - %s)", "%s (G2 - %s)", "%s (G3 - %s)", "%s (G4 - %s)", "%s (G5 - %s)", "%s (G6 - %s)", "%s (G7 - %s)", "%s (G8 - %s)", "%s (G9 - %s)", "%s (G10 - %s)", "%s (G11 - %s)", "%s (G12 - %s)" );

    }

    // demographics dropdown
    String STUDENT_DEMOGRAPHICS = "Student Demographics";
    String DISABILITY_STATUS = "Disability Status";
    String ENGLISH_LANGUAGE_PROFICIENCY = "English Language Proficiency";
    String GENDER = "Gender";
    String MIGRANT_STATUS = "Migrant Status";
    String RACE = "Race";
    String ETHNICITY = "Ethnicity";
    String SOCIOECONOMIC_STATUS = "Socioeconomic Status";
    String SPECIAL_SERVICES = "Special Services";
    
    String NONE_OF_THE_OPTIONS_SELECTED = "Choose one or more";
    List<String> DISABILITY_STATUS_OPTIONS = Arrays.asList( "Select All", "Yes", "No", "Not Specified" );
    List<String> GENDER_OPTIONS = Arrays.asList( "Select All", "Female", "Male", "Not Specified" );
    List<String> RACE_OPTIONS = Arrays.asList( "Select All", "White", "Black or African American", "Asian", "American Native or Alaskan Native", "Native Hawaiian or Pacific Islander", "Hispanic/Latino", "Unknown", "Not Specified" );
    List<String> SOCIOECONOMIC_STATUS_OPTIONS = Arrays.asList( "Select All", "Economically disadvantaged", "Not economically disadvantaged", "Not Specified" );
    List<String> ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS = Arrays.asList( "Select All", "English", "English Language Learner", "Not Specified" );
    List<String> MIGRANT_STATUS_OPTIONS = Arrays.asList( "Select All", "Migrant", "Non-Migrant", "Not Specified" );
    List<String> ETHNICITY_OPTIONS = Arrays.asList( "Select All", "Hispanic or Latino", "Not Hispanic or Latino", "Not Specified" );
    List<String> SPECIAL_SERVICES_OPTIONS = Arrays.asList( "Select All", "504 Plan", "Gifted / Talented", "IEP", "Other", "No Special Services", "Not Specified" );

    public static String TEACHER_LABEL = "Teacher";
    public static String SELECT_STUDENT_BY = "Select students by";
    public static String GRADE_LABEL = "Grade";
    public static String GROUP_LABEL = "Group";
    public static String STUDENT_LABEL = "Students";
    public static String SORT_LABEL = "Sort";
    public static String DISPLAY_LABEL = "Display";
    public static String STUDENTID = "STUDENT_ID";
    public static String ADDITIONAL_GROUPING_LBL = "Additional Grouping";
    public static String MASK_STUDENT_DISPLAY = "Mask Student Display";

    public static List<String> PRESCRIPTIVE_SCHEDULING_MASK_STUDENT_DISPLAY = new ArrayList<>( Arrays.asList( "Mask Student Display" ) );
    public static List<String> ADDITIONAL_GROUPING = new ArrayList<>( Arrays.asList( "None", "Teacher", "Grade", "Group" ) );
    public static List<String> ADDITIONAL_GROUPING_CPAR = new ArrayList<>( Arrays.asList( "None", "Grade" ) );
    public static List<String> DISPLAY = new ArrayList<>( Arrays.asList( "Student Name", "Student ID", "Student Username" ) );
    public static List<String> SORT = new ArrayList<>( Arrays.asList( "Student", "Current Course Level", "Exercises Correct", "Exercises Attempted", "Percent Correct", "Help Used", "Time Spent", "Total Sessions", "Session Date" ) );
    public static List<String> SORT_CPAR = new ArrayList<>( Arrays.asList( "School", "Current Course Level (Mean)", "IP Level (Mean)", "Gain (Mean)", "Time Spent (Mean)", "Total Sessions (Mean)", "Exercises Correct (Mean)", "Exercises Attempted (Mean)",
            "Exercises Percent Correct (Mean)", "Skills Assessed (Mean)", "Skills Mastered (Mean)", "Skills Percent Mastered (Mean)", "Percent Students With AP" ) );

    public static String ALL = "Select All";
    public static String ZERO_STATE_TEACHER = "Choose one or more teachers";
    public static String ZERO_STATE_GRADES = "Choose one or more grades";
    public static String ZERO_STATE_GROUPS = "Choose one or more groups";
    public static String TEACHEROPTION = "Teacher 1";
    public static String TEACHEROPTION_SEC = "Teacher 2";
    public static String GRADE_OPTION = "Grade 1";
    public static String GRADE_OPTION_SEC = "Grade 2";
    public static String GROUP_OPTION = "Group 1";
    public static String GROUP_OPTION_SEC = "Group 2";
    public static String SELECTED_OPTION = "(2) Selected";

    public static String REPORTS_IFRAME = "reportsIFrame";
    public static String ASSIGNMENTS_LBL = "Assignments";
    public static String ORGANIZATIONS_LABEL = "ORGANIZATIONS";

    // Recent Session Constants
    String RECENT_SESSION_PAGE_TITLE = "Last Session Report";
    String RECENT_SESSION_PAGE_DESCRIPTION = "The Last Session Report (LSR) for both Math and Reading provides information for last session for groups of students and for individual students in the group.";
    String RECENT_SESSION_SAVE_REPORT_OPTION_LABEL = "SAVED REPORT OPTIONS";
    String RECENT_SESSION_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK = "Choose from your list of saved options";
    String RECENT_SESSION_SAVE_REPORT_OPTION_WATER_MARK = "No Saved report options [...]";
    String RECENT_SESSION_ORGANIZATIONS_LABEL = "ORGANIZATIONS";
    String RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_WATER_MARK = "Choose one or more organizations";
    String RECENT_SESSION_ORGANIZATIONS_DROP_DOWN_SEARCH_WATER_MARK = "Search organizations";
    String RECENT_SESSION_COURSE_SELECTION_LABEL = "COURSE SELECTION";
    String RECENT_SESSION_SUBJECT_LABEL = "Subject";
    String RECENT_SESSION_SUBJECT_WATERMARK = "Choose a subject";
    String RECENT_SESSION_COURSES_LABEL = "Course(s)";
    List<String> SUBJECTS = Arrays.asList( "Math", "Reading" );
    String SEU_SUJECT_LBL = "Subject (all courses)";
    String MATH = "Math";
    String READING = "Reading";
    String GRADETHENGROUP = "Grade Then Group";
    String STUDENTUSERNAME = "Student Username";
    String CURRENTCOURSELEVEL = "Current Course Level";
    String ALL_OPTION = "ALL";
    List<String> LAST_SESSION_SORT = new ArrayList<>( Arrays.asList( "Student", "Current Course Level", "Exercises Correct", "Exercises Attempted", "Percent Correct", "Help Used", "Time Spent", "Total Sessions", "Session Date" ) );

    String SEU_ALL_MATH_WITH_CUSTOM = "All Math Courses (Includes custom)";
    String SEU_ALL_READING_WITH_CUSTOM = "All Reading Courses (Includes custom)";
    String SEU_ALL_MATH_WITH_READING = "All courses (Math and Reading, includes custom)";

    String NEW_REPORT_CONFIGURATION_LABEL = "Name and save this new custom report configuration.";
    String SAVE_REPORT_OPTIONS = "Save Report Options";
    String EXISTING_REPORT_CONFIGURATION_LABEL = "Select an existing custom report configuration to be replaced/updated.";
    String ALREADY_EXISTS_ERROR_MESSAGE = "This name already exists in your saved report options list.";
    String LENGTHY_NAME = "SM_REPORT_FILTER_LENGHTY_NAME_TEST_123456789_123456789_23e1928y83fwfsadcsvsa23";
    String NAME_EXCEED_ERROR_MESSAGE = "Exceeds maximum length.";

    // Recent Sessions Report Output

    List<String> SUB_HEADER_GRADE = Arrays.asList( "K", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" );
    String RSR_PGAE_TITLE = "Recent Sessions";
    String REPORT_RUN_LABEL = "Report Run:";
    List<String> INFO_LABELS = new ArrayList<>( Arrays.asList( "School:", "Teacher:", "Grade:", "Group:" ) );
    String SELECTED_OPTION_HEADER = "Selected Options";
    String SPR_PAGE_TITLE = "Student Performance";
    String RSR_PAGE_TITLE = "Recent Sessions";
    String LEGEND_HEADER = "Legend:";
    String STRAND_HEADER = "Performance by Strand - Cumulative";
    List<String> LEGEND_LABELS = new ArrayList<>( Arrays.asList( "In IP", "NA", "F", "- -", "*" ) );
    List<String> LEGEND_LABELS_VALUES = new ArrayList<>( Arrays.asList( "Student still in Initial Placement", "Data does not apply. Some courses and settings may not report data for all columns",
            "Student encountered content from Reading Fluency strands in this session", "Data has not been reported yet", "Student exited the session early" ) );
    String PAGINATION_TEXT = "Go toof %s";
    // Recent Session Report Grid
    List<String> REPORT_TABLE_TITTLE = Arrays.asList( "Student", "Level", "Raw Performance", "Usage" );
    List<String> REPORT_TABLE_SUB_TITTLE = Arrays.asList( "", "Current Course Level", "Excercises Correct", "Excercises Attempted", "Excercises Percent Correct", "Help Used", "Time Spent", "Total Sessions minimum of 1 assignment", "Session Date" );
    List<String> REPORT_TABLE_LAST_TWO_ROW = Arrays.asList( "Mean - 8 Students", "Standard Deviation" );
    String REPORT_TABLE_NOTES = "Notes: Initial Placement included in session and performance data and time is shown in hours and minutes (hh:mm)";

    // Sub Header
    String OUTPUT_SUB_HEADER_TEACHER = "All";
    String OUTPUT_SUB_HEADER_GRADE = "Multiple Grades Selected";
    String OUTPUT_SUB_HEADER_GROUP = "All";

    // Sub Header Selected Options
    String ADDITIONAL_GROUPING_NONE = "No additional grouping";
    String ADDITIONAL_GROUPING_TEACHER = "Additional grouping by Teacher";
    String ADDITIONAL_GROUPING_GRADE = "Additional grouping by Grade";
    String ADDITIONAL_GROUPING_GROUP = "Additional grouping by Group";

    String SELECTED_OPTION_SORT = "Sort by %s";
    String SORT_AS_STUDENT = "Sort by Student Name";
    String SORT_AS_PERCENT_CORRECT = "Sort by Exercises Percent Correct";
    String DEMOGRAPHIC_FILTERS_NOT_USED = "Demographic filters not used";
    String DEMOGRAPHIC_FILTERS_USED = "Demographic filters used (see end of report)";

    // Student Performance Report
    List<String> STUDENT_DISABILITY_STATUS_OPTIONS = Arrays.asList( "ALL", "Yes", "No", "Not Specified" );
    List<String> STUDENT_GENDER_OPTIONS = Arrays.asList( "ALL", "Female", "Male", "Not Specified" );
    List<String> STUDENT_RACE_OPTIONS = Arrays.asList( "ALL", "White", "Black or African American", "Asian", "American Native or Alaskan Native", "Native Hawaiian or Pacific Islander", "Hispanic/Latino", "Unknown" );
    List<String> STUDENT_SOCIOECONOMIC_STATUS_OPTIONS = Arrays.asList( "ALL", "Economically Disadvantaged", "Not Economically Disadvantaged", "Not Specified" );
    List<String> STUDENT_ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS = Arrays.asList( "ALL", "English", "English Language Learner", "Not Specified" );
    List<String> STUDENT_MIGRANT_STATUS_OPTIONS = Arrays.asList( "ALL", "Migrant", "Non Migrant", "Not Specified" );
    List<String> STUDENT_ETHNICITY_OPTIONS = Arrays.asList( "ALL", "Hispanic or Latino", "Not Hispanic or Latino" );
    List<String> STUDENT_SPECIAL_SERVICES_OPTIONS = Arrays.asList( "ALL", "504 Plan", "Gifted/Talented", "IEP", "Other", "No Special Services" );
    public static String INCLUDE_PERFORMANCE_SUMMARY = "Include Performance Summary";
    public static String INCLUDE_PERFORMANCE_STRAND = "Include Performance By Strand";
    public static String INCLUDE_AREAS_OF_GROWTH = "Include Areas Of Growth";
    public static String DATE_AT_RISK = "Dates at risk";
    public static List<String> DATE_AT_RISK_OPTIONS = new ArrayList<>( Arrays.asList( "Since IP", "24 Weeks", "20 Weeks", "16 Weeks", "12 Weeks", "8 Weeks", "4 Weeks", "2 Weeks", "1 Week" ) );
    public static String LANGUAGE = "Language";
    public static String LANGUAGE_SPANISH = "Spanish";
    public static List<String> LANGUAGE_OPTIONS = new ArrayList<>( Arrays.asList( "English", "Spanish" ) );
    public static String DEFAULT_DISPLAY = "Student Name";
    public static String DEFAULT_LANGUAGE = "English";
    public static String DEFAULT_DATE_AT_RISK = "Since IP";
    public static String DEFAULT_SORT = "Strand";
    public static String DEFAULT_ADDITIONAL_GROUPING = "None";
    List<String> LEGEND_LABELS_SP = new ArrayList<>( Arrays.asList( "IP", "NA", "TOP", "CRI", "- -", "++" ) );
    List<String> LEGEND_LABELS_VALUES_SP = new ArrayList<>( Arrays.asList( "Initial Placement", "Not Applicable", "Topped out", "Computation Retention Index", "Data not available", "Strand is on but level not yet reached" ) );

    // Cumulative Performance Report

    public static String COLOR_CPRAGGREGATE = "#333333";
    public String CPR_HEADER = "Cumulative Performance Report";
    public String CPR_DESCRIPTION = "The Cumulative Performance Report (CPR) provides information about student performance and progress including students' current course level and gain, usage time, raw exercise performance, and mastery performance.";
    public String COURSES_ZERO_STATE = "No courses are available for the selecte...";
    public String CPR_COURSE_SELECTION_LABEL = "COURSE SELECTION";
    public String CPR_SUBJECT_LABEL = "Subject";
    public String CPR_COURSES_LABEL = "Course(s)";
    public String SAVED_REPORT_OPTIONS = "SAVED REPORT OPTIONS";
    public String SAVED_REPORT_OPTIONS_TEXT_COLOR = "#767676";

    // Output Report UI Constants
    List<String> INITIAL_PLACEMENT_CONSTANTS = new ArrayList<>( Arrays.asList( "IP Level", "IP Correct", "IP Attempted", "IP Percent Correct", "IP Time Spent", "Placed" ) );
    public String PERFORMANCE_BY_STRAND_CUMULATIVE = "Performance by Strand - Cumulative";
    public String COMPUTATION_STRANDS = "Computation Strands";
    public String APPLICATION_STRANDS = "Application Strands";
    public String AREAS_FOR_GROWTH_SINCE_IP = "Areas For Growth - Since IP";
    public String SKILLS_IN_DELAYED_PRESENTATION = "Skills in Delayed Presentation";
    public String SKILLS_NOT_MASTERED = "Skills Not Mastered";

    public String SAVED_REPORT_OPTIONS_UPDATE_DROPDOWN = "Select an existing custom report configuration to be replaced/updated.";

    // Prescriptive scheduling report
    public static String SELECT_ALL = "Select All";
    String PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTIONS = "SAVED REPORT OPTIONS";
    String PRESCRIPTIVE_SCHEDULING_PAGE_TITLE = "Prescriptive Scheduling Report";
    String PRESCRIPTIVE_SCHEDULING_PAGE_DESCRIPTION = "The Prescriptive Scheduling Report (PSR) is a forecasting tool that enables you to monitor student progress and adjust schedules to reach performance goals.";
    String PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_LABEL = "SAVED REPORT OPTIONS";
    String PRESCRIPTIVE_SCHEDULING_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK = "Choose from your list of saved options";
    String PRESCRIPTIVE_SCHEDULING_COURSE_SELECTION_LABEL = "COURSE SELECTION";
    String PRESCRIPTIVE_SCHEDULING_SUBJECT_LABEL = "Subject";
    String PRESCRIPTIVE_SCHEDULING_ADDITIONAL_GROUPING_LABEL = "Additional Grouping";
    String PRESCRIPTIVE_SCHEDULING_DISPLAY_LABEL = "Display";
    String PRESCRIPTIVE_SCHEDULING_SORT_LABEL = "Sort";
    String PRESCRIPTIVE_SCHEDULING_SUBJECT_WATERMARK = "Math";
    String PRESCRIPTIVE_SCHEDULING_COURSES_LABEL = "Course(s)";
    String PRESCRIPTIVE_SCHEDULING_SET_TARGET_DATE = "SET TARGET DATE";
    String PRESCRIPTIVE_SCHEDULING_SET_TARGET_LEVEL_PER_GRADE = "SET TARGET LEVEL PER GRADE";
    List<String> PRESCRIPTIVE_SCHEDULING_ADDITIONAL_GROUPING = new ArrayList<>( Arrays.asList( "Grade", "Grade Then Group" ) );
    List<String> PRESCRIPTIVE_SCHEDULING_SORT = new ArrayList<>( Arrays.asList( "Student", "Current Course Level", "IP/Start Level", "Time (Since IP-if used)", "Recent % of Skills Mastered", "Session Length Setting", "Average Min/Day",
            "Current Learning Rate", "Current Forecast Time", "Current Forecast Level", "Add`l Sessions To Target", "Add`l Time To Target", "Add`l Min/Day To Target" ) );

    // mastery Report Output Screen
    String SKILLORSTANDARD_TITLE = "Skill or Standard";
    String MASTERYSTATUS_TITLE = "Mastery Status";
    String SKILLSCOMPLETED_TITLE = "# of Skills Completed/Judged";
    String NOOFATTEMPTS_TITLE = "# of Attempts";
    List<String> MASTERYREPORT_LEGEND_LABELS = new ArrayList<>( Arrays.asList( "IP", "NA" ) );
    List<String> MASTERYREPORT_LEGEND_LABELS_VALUES = new ArrayList<>( Arrays.asList( "Initial Placement", "Not Applicable" ) );
    List<String> MASTERYREPORT_MASTERY_STATUS_VALUES = new ArrayList<>( Arrays.asList( "Mastered", "At Risk", "Not Mastered" ) );
    List<String> MASTERYREPORT_ASSIGNMENTDETAILS_LABELS = new ArrayList<>( Arrays.asList( "Assigned course level:", "Current course level:", "IP level:", "Time spent:", "Total sessions:", "Average session time:" ) );
    String INVALID_PAGINATION_ERRMSG = "Invalid";
    String INVALID_PAGINATION_INPUT = "200";
    String VALID_PAGINATION_THREE = "3";
    String VALID_PAGINATION_FIVE = "5";
    String MASTERY_HEADER = "Mastery";

    // warning model
    String WARNING_MODEL_POPUP = "Display Student ID";
    String TEXT_STUDENT_ID = "Because student ID's are optional, selecting \"Display Student ID\" may result in no ID shown under the student column in the report. Student data will display, but there will be no associated name or ID.";

    public interface CPAReport {
        List<String> SELECTED_OPTIONS_LABELS = Arrays.asList( "No additional grouping", "Sort by Current Course Level", "All assigned grade levels included", "Demographic filters not used" );
        List<String> LEGEND_OPTIONS_LABELS = Arrays.asList( "AP Acceptable Performance (90% Skills Mastered)", "NA Data does not apply. Some courses and settings may not report data for all columns", "- - Data has not been reported yet" );
        String ADDITONAL_GROUPING_BY_GRADE = "Additional grouping by Grade";
        List<String> LEGEND_KEYS = Arrays.asList( "AP", "NA", "- -" );
        String LAST_SESSION = "Last Session";
        List<String> LEGEND_VALUES = Arrays.asList( "Acceptable Performance (90% Skills Mastered)", "Data does not apply. Some courses and settings may not report data for all columns", "Data has not been reported yet" );
        List<String> TABLE_HEADER = Arrays.asList( "School (Grade - # of Students)", "Level Data Mean", "Usage Mean", "Instructional Performance Mean", "Mastery Mean" );
    }

    public String CPRA_HEADER = "Cumulative Performance Aggregate";

    // Cumulative Performance Admin Dropdown constants
    String CUMULATIVE_PERFORMANCE_ORGANIZATIONS_LABEL = "ORGANIZATIONS";
    String CP_SELECT_STUDENT_BY1 = "SELECT STUDENTS BY";
    String CP_MFEURL = "https://successmaker-reports-webapp-stage.smdemo.info/reports";
    public static String CP_GROUP_LABEL = "Group";

    // CP Report Input Screen
    String CP_SELECT_STUDENT_BY = "SELECT STUDENTS BY";
    public static String SELECTED_DISABLITY_OPTION = "Yes";
    public static String SELECTED_ENGLISH_PROFICIENCY_OPTION = "English Language Learner";
    public static String SELECTED_ETHNICITY_OPTION = "Hispanic or Latino";
    public static String SELECTED_MIGRANT_STATUS_OPTION = "Non-Migrant";
    public static String SELECTED_RACE_OPTION = "White";
    public static String SELECTED_SPECIAL_SERVICES = "Gifted / Talented";
    public static String SELECTED_SOCIOECONOMIC_STATUS = "Not economically disadvantaged";
    public static String SELECTED_ALL_OPTION = "(All) Selected";
    public static String SELECTED_ADDITIONAL_OPTION = "Teacher";

    List<String> ADDITIONGROUP = Arrays.asList( "None", "Grade", "Group" );
    List<String> DISPLAYNAME = Arrays.asList( "Student Name", "Student ID", "Student Username" );
    List<String> SORTNAME = Arrays.asList( "Strand", "Level", "Skill Description" );
    List<String> DATESATRISK = Arrays.asList( "Since IP", "24 Weeks", "20 Weeks", "16 Weeks", "12 Weeks", "8 Weeks", "4 Weeks", "2 Weeks", "1 Week" );

    public interface AFGReportConstants {
        List<String> LEGEND_HEADERS = new ArrayList<>( Arrays.asList( "Selected Options", "Legend" ) );
        List<String> COLUMN_HEADERS = Arrays.asList( "Strand", "Level", "Skill Description" );
        List<String> COLUMN_SUBHEADERS = Arrays.asList( "", "", "Student", "Date at Risk", "Targeted Lesson" );

        String REPORT_HEADER_INPUT = "Areas For Growth Report";
        String AFG_SUBJECT_LABEL = "Subject";
        String AFG_DISPLAY_LABEL = "Display";
        String AFG_ADD_GROUPING_LABEL = "Additional Grouping";
        String AFG_SORT_LABEL = "Sort";
        String MATH = "Math";
        String READING = "Reading";
        String NONE = "None";
        String GRADE = "Grade";
        String GROUPS = "Groups";
        String GROUP = "Group";
        String STUDENT_USERNAME = "Student Username";

        String DATA = "data";
        String GET_AFG_ADMIN_REPORT_DATA = "getAFGAdminReportData";
        String ORG_ROWS = "orgRows";
        String ASSIGNMENT_TITLE = "assignmentTitle";
        String STRAND_SKILL_ROWS = "strandSkillRows";
        String STRAND = "Strand";
        String STRAND_NAME = "strandName";
        String STRAND_LEVEL = "strandLevel";
        String LEVEL = "Level";
        String SKILL_DESCRIPTION = "Skill Description";
        String TARGETED_LESSON = "Targeted Lesson";
        String CATALOG_NUM = "catalogNum";
        String LO_DESCRIPTION = "loDescription";
        String LESSON_NUMBER = "lessonNumber";
        String LESSON_TITLE = "lessonTitle";
        String STUDENT_ROWS = "studentRows";
        String FAILED_DATE = "failedDate";
        String STUDENT_NAME = "studentName";
        String LEGEND_HEADER = "Legend";
        String ROLE_CSS_PROPERTY = "Role";
        String ROLE_CSS_VALUE = "link";
        String BG_COLOR_BACK_BUTTON = "#fff";
        String BG_COLOR_NEXT_BUTTON = "#e2e2e2";
        String LEGEND_VALUE = "Targeted Lesson Resources";
        String SELECTED_OPTION_HEADER = "Selected Options:";
        String NO_ADDITIONAL_GROUPING = "No additional grouping";
        String ADDITIONAL_GROUPING_BY_GROUP = "Additional grouping by Group";
        String ADDITIONAL_GROUPING_BY_GRADE = "Additional grouping by Grade";
        String SORT_BY_STRAND = "Sort by Strand";
        String SORT_BY_LEVEL = "Sort by Level";
        String SHOW_ALL_DATES_AT_RISK = "Show all dates at risk";
        String NUMBER_OF_GROUPS_SELECTED = "groups selected";
        String ZERO_STATE_MESSAGE = "No data to display";

        List<String> MATH_LEGEND_LABELS = new ArrayList<>( Arrays.asList( "AS", "MD", "FD", "RE", "NA" ) );
        List<String> MATH_LEGEND_LABELS_VALUES = new ArrayList<>(
                Arrays.asList( "Addition and Subtraction", "Multiplication and Division", "Fractions and Decimals", "Ratios and Equations", "Data does not apply. Some courses and settings may not report data for all columns" ) );
        List<String> READING_LEGEND_LABELS = new ArrayList<>( Arrays.asList( "PA", "PS", "C1", "C2", "NA" ) );
        List<String> READING_LEGEND_LABELS_VALUES = new ArrayList<>(
                Arrays.asList( "Phonological and Print Awareness", "Phonics and Spelling", "Comparing Texts Vol. 1", "Comparing Texts Vol. 2", "Data does not apply. Some courses and settings may not report data for all columns" ) );
        List<String> INFO_LABELS = new ArrayList<>( Arrays.asList( "School:", "Teacher:", "Grade:", "Group:" ) );
        String SHOW_ALL_DATE_AT_RISK = "Show all dates at risk - recent %s";
    }

    // area for growth constant
    String AREA_FOR_GROWTH_PAGE_TITLE = "Areas For Growth Report";
    String AREA_FOR_GROWTH_PAGE_DESCRIPTION = "The Areas For Growth (AFG) Report lists the Math and Reading skills with which the selected students are having difficulty. The report groups students by these skills to allow teachers to determine which students require assistance and/or intervention.";
    String AREA_FOR_GROWTH_SAVE_REPORT_OPTION_LABEL = "SAVED REPORT OPTIONS";
    String AREA_FOR_GROWTH_SAVE_REPORT_OPTION_DROP_DOWN_WATER_MARK = "Choose from your list of saved options";
    String AREA_FOR_GROWTH_ORGANIZATIONS_LABEL = "ORGANIZATIONS";
    String AREA_FOR_GROWTH_ORGANIZATIONS_DROP_DOWN_WATER_MARK = "Choose one or more organizations";
    String AREA_FOR_GROWTH_ORGANIZATIONS_DROP_DOWN_SEARCH_WATER_MARK = "Search organizations";
    String AREA_FOR_GROWTH_COURSE_SELECTION_LABEL = "COURSE SELECTION";
    String AREA_FOR_GROWTH_SUBJECT_LABEL = "Subject";
    String AREA_FOR_GROWTH_SUBJECT_WATERMARK = "Choose a subject";
    String AREA_FOR_GROWTH_COURSES_LABEL = "Course(s)";
    String AREA_FOR_GROWTH_OPTIONAL_FILTER_LABEL = "Optional Filters";
    String MULTIPLE_TEACHERS_SELECTED = "Multiple Teachers Selected";
    String MULTIPLE_GRADES_SELECTED = "Multiple Grades Selected";
    String MULTIPLE_GROUPS_SELECTED = "Multiple Groups Selected";
    String ALL_VALUES = "All";
    String AREA_FOR_GROWTH_MULTIGROUP_VALUE = "Multiple Groups Selected";

    List<String> AFG_DISABILITY_STATUS_OPTIONS = Arrays.asList( "Select All", "Yes", "No", "Not Specified" );
    List<String> AFG_GENDER_OPTIONS = Arrays.asList( "Select All", "Female", "Male", "Not Specified" );
    List<String> AFG_RACE_OPTIONS = Arrays.asList( "Select All", "White", "Black or African American", "Asian", "American Native or Alaskan Native", "Native Hawaiian or Pacific Islander", "Hispanic/Latino", "Unknown", "Not Specified" );
    List<String> AFG_SOCIOECONOMIC_STATUS_OPTIONS = Arrays.asList( "Select All", "Economically disadvantaged", "Not Specified", "Not economically disadvantaged" );
    List<String> AFG_ENGLISH_LANGUAGE_PROFICIENCY_OPTIONS = Arrays.asList( "Select All", "English", "English Language Learner", "Not Specified" );
    List<String> AFG_MIGRANT_STATUS_OPTIONS = Arrays.asList( "Select All", "Migrant", "Non-Migrant", "Not Specified" );
    List<String> AFG_ETHNICITY_OPTIONS = Arrays.asList( "Select All", "Hispanic or Latino", "Not Hispanic or Latino", "Not Specified" );
    List<String> AFG_SPECIAL_SERVICES_OPTIONS = Arrays.asList( "Select All", "504 Plan", "Gifted / Talented", "IEP", "No Special Services", "Not Specified", "Other" );
    Object AFG_HEADER = "Areas For Growth";

    public static List<String> AFG_SORT = new ArrayList<>( Arrays.asList( "Strand", "Level", "Skill Description" ) );
    public static List<String> AFG_DATE_AT_RISK_OPTIONS = new ArrayList<>( Arrays.asList( "Since IP", "24 Weeks", "20 Weeks", "16 Weeks", "1 week" ) );

    //Different Grades For Prespective Schedule Page
    String GRADE_K = "k";
    String GRADE_1 = "1";
    String GRADE_2 = "2";
    String GRADE_3 = "3";
    String GRADE_4 = "4";
    String GRADE_5 = "5";
    String GRADE_6 = "6";
    String GRADE_7 = "7";
    String GRADE_8 = "8";
    String GRADE_9 = "9";
    String GRADE_10 = "10";
    String GRADE_11 = "11";
    String GRADE_12 = "12";

    String DEMOGRAPHIC_FILTER_USED = "Demographic filters used (see end of report)";
    String DEMOGRAPHIC_FILTER_NOT_USED = "Demographic filters not used";
    String NO_DATA_TO_DISPLAY = "No data to display";

    public interface DemographicFilters {
        ArrayList<String> DISABILITY_STATUS = new ArrayList<String>( Arrays.asList( "Yes", "No", "Not Specified" ) );
        ArrayList<String> ENGLISH_LANGUAGE = new ArrayList<String>( Arrays.asList( "English", "English Language Learner", "Not Specified" ) );
        ArrayList<String> ETHNICITY = new ArrayList<String>( Arrays.asList( "Hispanic or Latino", "Not Hispanic or Latino", "Not Specified" ) );
        ArrayList<String> MIGRANT_STATUS = new ArrayList<String>( Arrays.asList( "Migrant", "Non-Migrant", "Not Specified" ) );
        ArrayList<String> RACE = new ArrayList<String>( Arrays.asList( "White", "Black or African American", "Asian", "American Native or Alaskan Native", "Native Hawaiian or Pacific Islander", "Hispanic/Latino", "Unknown", "Not Specified" ) );
        ArrayList<String> SOCIOECONOMIC_STATUS = new ArrayList<String>( Arrays.asList( "Economically disadvantaged", "Not economically disadvantaged", "Not Specified" ) );
        ArrayList<String> SPECIAL_SERVICES = new ArrayList<String>( Arrays.asList( "504 Plan", "Gifted / Talented", "IEP", "Other", "No Special Services", "Not Specified" ) );
    }

    public static enum ReportSubHeader {
        School,
        Teacher,
        Grade,
        Group
    }

    public static enum SEUReportSelectedOptions {
        Courses,
        Additional_Grouping,
        Sort,
        Teacher,
        Grade,
        Group,
        Demographic
    }

    public interface SEUReportConstants {

        List<String> NO_DATA = Arrays.asList( "", "--" );
        List<String> SUB_HEADERS = Arrays.asList( "", "Username", "Student ID", "SM Math", "SM Reading", "Custom Courses", "Total Time Spent", "Total Sessions", "Average Session Time", "Last Session Date" );
        List<String> SORT = Arrays.asList( "Student", "Username (login)", "Student ID", "Time Spent-SM Math", "Time Spent-SM Reading", "Time Spent-Custom Course", "Total Time Spent", "Total Sessions", "Average Session Time", "Last Session Date" );
        String SELECTED_OPTION_ADDITIONAL_GROUPING = "Additional grouping by %s";
    }

    // Areas For Growth Report Output Page
    List<String> SELECTED_OPTIONS_LABELS_AFG = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk", "No groups selected", "No grades selected", "Demographic filters not used" );
    List<String> LEGENDS_OPTIONS_LABELS_AFG_MATH = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk", "No groups selected", "No grades selected", "Demographic filters not used" );
    List<String> LEGENDS_OPTIONS_LABELS_AFG_READING = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk", "No groups selected", "No grades selected", "Demographic filters not used" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_SECOND_CASE = Arrays.asList( "Additional grouping by Teacher", "Sort by Level", "Show all dates at risk", "No groups selected", "No grades selected", "Demographic filters not used" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_THIRD_CASE = Arrays.asList( "Additional grouping by Grade", "Sort by Skill Description", "Show all dates at risk", "No groups selected", "No grades selected", "Demographic filters not used" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_FORTH_CASE = Arrays.asList( "Additional grouping by Group", "Sort by Strand", "Show all dates at risk - recent 24 weeks", "No groups selected", "No grades selected", "Demographic filters not used" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_FIFTH_CASE = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk - recent 20 weeks", "1 group selected", "No grades selected", "Demographic filters not used" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_SIXTH_CASE = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk - recent 16 weeks", "2 groups selected", "No grades selected", "Demographic filters not used" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_SEVENTH_CASE = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk - recent 12 weeks", "All groups selected", "No grades selected", "Demographic filters not used" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_EIGHT_CASE = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk - recent 8 weeks", "No groups selected", "1 grade selected", "Demographic filters not used" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_NINTH_CASE = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk - recent 4 weeks", "No groups selected", "2 grades selected", "Demographic filters not used" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_TENTH_CASE = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk - recent 2 weeks", "No groups selected", "All grades selected", "Demographic filters not used" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_ELEVENTH_CASE = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk", "No groups selected", "All grades selected", "Demographic filters used (see end of report)" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_TWELVETH_CASE = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk", "No groups selected", "No grades selected", "Demographic filters used (see end of report)" );
    List<String> SELECTED_OPTIONS_LABELS_AFG_THIRTEENTH_CASE = Arrays.asList( "No additional grouping", "Sort by Strand", "Show all dates at risk - recent 1 week", "No groups selected", "All grades selected",
            "Demographic filters used (see end of report)" );

    //Export Functionality
    String EXPORT_DATA_HEADER = "Export Report CSV";
    String EXPORT_DEFAULT = "Export Default Columns";
    String CUSTOMIZE_EXPORT = "Export Selected Columns";
    String EXPORTING_CSV_FILE = "Exporting CSV File";
    String DELAY_POPUP_TEXT = "Your report is successfully generated and will now begin downloading. It may take a few minutes for your CSV download to complete. Please don't close this browser tab or your browser while the download is in progress.Exporting a CSV is not recommended on Android or iOS devices.";
    String DOWNLOAD_ERROR = "Download Error";
    String ERROR_POPUP_TEXT = "Sorry, we encountered a problem generating your file. Please try again later.";

    public interface LastSessionConstants {

        List<String> NO_DATA = Arrays.asList( "In IP", "NA" );
        List<String> GRID_SUB_HEADER = Arrays.asList( "Current Course Level", " Exercises Correct ", " Exercises Attempted ", " Exercises Percent Correct ", " Help Used ", " Time Spent ", " Total Sessions ", "Total Sessions" );
        String TIME_SPEND = "*";
        List<String> SORT = Arrays.asList( "Student", "Current Course Level", "Exercises Correct", "Exercises Attempted", "Percent Correct", "Help Used", "Time Spent", "Total Sessions", "Session Date" );
        List<String> READING_COLUMN_HEADERS = Arrays.asList( "Current Course Level", "Exercises Correct", "Exercises Attempted", "Exercises Percent Correct", "Instructional", "Independent Practice", "Remediation", "Help Used", "Time Spent",
                "Total Sessions", "Session Date" );


    }

    public interface PSUIConstants {
        public static String STUDENT = "Student";
        public static String PERFOMANCE_DATA = "Performance Data";
        public static String CURRENT_COURSE_LEVEL = "Current Course Level";
        public static String IP_LEVEL = "IP Level";
        public static String TIME_SINCE_IP = "Time Since IP";
        public static String SKILLS_PERCENT_MASTERED = "Skills Percent Mastered";
        public static String CURRENT_RATE = "Current Rate";
        public static String SESSION_LENGTH_SETTING = "Session Length Setting";
        public static String AVERAGE_MIN_DAY = "Average Min/Day";
        public static String CURRENT_LEARNING_RATE = "Current Learning Rate";
        public static String CURRENT_FORECAST = "Current Forecast";
        public static String TIME = "Time";
        public static String LEVEL = "Level";
        public static String PRESCRIPTON = "Prescription";
        public static String ADDL_SESSIONS_TO_TARGET = "Add'l Sessions to Target";
        public static String ADDL_TIME_TO_TARGET = "Add'l Time to Target";
        public static String ADDL_MIN_PER_DAY_TO_TARGET = "Add'l Min/Day to Target";

    }

    /**
     * @author raseem.mohamed Used to switch the different reports
     * 
     */
    public enum Reports {
        AREAS_FOR_GROWTH( "Areas For Growth" ),
        CUMULATIVE_PERFORMANCE( "Cumulative Performance" ),
        LAST_SESSION( "Last Session" ),
        STUDENT_PERFORMANCE( "Student Performance" ),
        PRESCRIPTIVE_SCHEDULING( "Prescriptive Scheduling" ),
        SYSTEM_ENROLLMENT_AND_USAGE( "System Enrollment and Usage" );

        private String displayName;

        Reports( String displayName ) {
            this.displayName = displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }

    public interface LSRExportCsv {
        List<String> DEFAULT_MATH_HEADERS = Arrays.asList( "\"Assignment\"", "\"Report Run\"", "\"School\"", "\"Teacher\"", "\"Grade\"", "\"Group\"", "\"Student\"", "\"Current Course Level\"", "\"Exercises Correct\"", "\"Exercises Attempted\"",
                "\"Exercises Percent Correct\"", "\"Help Used\"", "\"Time Spent\"", "\"Total Sessions\"", "\"Session Date\"", "\"Current Course Level (Mean)\"", "\"Exercises Correct (Mean)\"", "\"Exercises Attempted (Mean)\"",
                "\"Exercises Percent Correct (Mean)\"", "\"Help Used (Mean)\"", "\"Time Spent (Mean)\"", "\"Total Sessions (Mean)\"", "\"Current Course Level (SD)\"", "\"Exercises Correct (SD)\"", "\"Exercises Attempted (SD)\"",
                "\"Exercises Percent Correct (SD)\"", "\"Help Used (SD)\"", "\"Time Spent (SD)\"", "\"Total Sessions (SD)\"" );

        List<String> DEFAULT_READING_HEADERS = Arrays.asList( "\"Assignment\"", "\"Report Run\"", "\"School\"", "\"Teacher\"", "\"Grade\"", "\"Group\"", "\"Student\"", "\"Current Course Level\"", "\"Exercises Correct\"", "\"Exercises Attempted\"",
                "\"Exercises Percent Correct\"", "\"Help Used\"", "\"Time Spent\"", "\"Total Sessions\"", "\"Session Date\"", "\"Current Course Level (Mean)\"", "\"Exercises Correct (Mean)\"", "\"Exercises Attempted (Mean)\"",
                "\"Exercises Percent Correct (Mean)\"", "\"Help Used (Mean)\"", "\"Time Spent (Mean)\"", "\"Total Sessions (Mean)\"", "\"Current Course Level (SD)\"", "\"Exercises Correct (SD)\"", "\"Exercises Attempted (SD)\"",
                "\"Exercises Percent Correct (SD)\"", "\"Help Used (SD)\"", "\"Time Spent (SD)\"", "\"Total Sessions (SD)\"", "\"Instructional - Exercises Correct\"", "\"Instructional - Exercises Attempted\"",
                "\"Independent Practice - Exercises Correct\"", "\"Independent Practice - Exercises Attempted\"", "\"Remediation - Exercises Correct\"", "\"Remediation - Exercises Attempted\"", "\"Instructional - Exercises Correct (Mean)\"",
                "\"Instructional - Exercises Attempted (Mean)\"", "\"Independent Practice - Exercises Correct (Mean)\"", "\"Independent Practice - Exercises Attempted (Mean)\"", "\"Remediation - Exercises Correct (Mean)\"",
                "\"Remediation - Exercises Attempted (Mean)\"", "\"Instructional - Exercises Correct (SD)\"", "\"Instructional - Exercises Attempted (SD)\"", "\"Independent Practice - Exercises Correct (SD)\"",
                "\"Independent Practice - Exercises Attempted (SD)\"", "\"Remediation - Exercises Correct (SD)\"", "\"Remediation - Exercises Attempted (SD)\"" );

        List<String> READING_CUSTOM_AVAILABLE_COLUMNS = Arrays.asList( "reportRun", "assignmentTitle", "organizationName", "teacherID", "teacherName", "grade", "groupID", "groupName", "studentID", "studentName", "studentUsername", "currentCourseLevel",
                "exercisesCorrect", "exercisesAttempted", "exercisesPercentCorrect", "helpUsed", "timeSpent", "totalSessions", "sessionDate", "sessionStartDate", "sessionCompleteDate", "sessionLength", "fluencyFlag", "ipmStatusID", "courseType",
                "meanCurrentCourseLevel", "meanExercisesCorrect", "meanExercisesAttempted", "meanExercisesPercentCorrect", "meanHelpUsed", "meanTimeSpent", "meanTotalSessions", "stdCurrentCourseLevel", "stdExercisesCorrect", "stdExercisesAttempted",
                "stdExercisesPercentCorrect", "stdHelpUsed", "stdTimeSpent", "stdTotalSessions", "instructionalCorrect", "instructionalAttempted", "independentPracticeCorrect", "independentPracticeAttempted", "remediationCorrect", "remediationAttempted",
                "meanInstructionalCorrect", "meanInstructionalAttempted", "meanIndependentPracticeCorrect", "meanIndependentPracticeAttempted", "meanRemediationCorrect", "meanRemediationAttempted", "stdInstructionalCorrect", "stdInstructionalAttempted",
                "stdIndependentPracticeCorrect", "stdIndependentPracticeAttempted", "stdRemediationCorrect", "stdRemediationAttempted" );

        List<String> MATH_CUSTOM_SELECTED_FILTERS = Arrays.asList( "reportRun", "assignmentTitle", "organizationName", "teacherID", "teacherName", "grade", "groupID", "groupName", "studentID", "studentName", "studentUsername", "currentCourseLevel",
                "rawPerformance.exercisesCorrect", "rawPerformance.exercisesAttempted", "rawPerformance.exercisesPercentCorrect", "usage.helpUsed", "usage.timeSpent", "usage.totalSessions", "usage.sessionDate", "usage.sessionStartDate",
                "usage.sessionCompleteDate", "usage.sessionLength", "fluencyFlag", "ipmStatusID", "courseType", "mean.currentCourseLevel", "mean.exercisesCorrect", "mean.exercisesAttempted", "mean.exercisesPercentCorrect", "mean.helpUsed",
                "mean.timeSpent", "mean.totalSessions", "standardDeviation.currentCourseLevel", "standardDeviation.exercisesCorrect", "standardDeviation.exercisesAttempted", "standardDeviation.exercisesPercentCorrect", "standardDeviation.helpUsed",
                "standardDeviation.timeSpent", "standardDeviation.totalSessions" );
    }

    public static String PDF_POP_TEXT = "Export Report PDF";
    public static String ALL_PSGES_TEXT = "All page(s)";
    public static String CURRENT_PAGE_TEXT = "Current page";
    public static String PDF_TEXT = "PDF";
    public static String PAGES_TEXT = "Page(s)";
    public static String OK_EXT = "OK";
    public static String CANCEL_TEXT = "Cancel";
    public static String POP_UP_PDF_FILE = "Exporting PDF File";
    public static String DOWNLOADING_TEXT = "It may take a few minutes for your PDF generation to complete. Please don't close this browser tab or your browser while the download is in progress.";
    public static String SUCCESS_TEXT = "Your report is successfully generated and will now begin downloading. It may take a few minutes for your PDF download to complete. Please don't close this browser tab or your browser while the download is in progress.";
    public static String SUCCESS_TEXT_SECOND = "Exporting a PDF is not recommended on Android or iOS devices.";
    public static String DOWNLOADING_TEXT_SECOND = "Exporting a PDF is not recommended on Android or iOS devices.";
}
