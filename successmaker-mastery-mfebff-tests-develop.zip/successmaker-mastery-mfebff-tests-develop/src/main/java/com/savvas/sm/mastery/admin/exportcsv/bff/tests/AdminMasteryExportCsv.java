package com.savvas.sm.mastery.admin.exportcsv.bff.tests;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.data.ReportDataCollection;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;
import com.savvas.sm.utils.sme187.admin.api.reports.Reports;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.AdminReportCsv;
import com.savvas.sm.utils.sme187.admin.api.reports.exportcsv.ExportCsvConstants;
import com.savvas.sm.utils.sme187.report.exportutils.ExportCsvUtils;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

import io.restassured.response.Response;

public class AdminMasteryExportCsv extends EnvProperties {

    public String smUrl;
    public String browser;
    public String username;
    public String userId;
    public String orgId;
    public String schoolId;
    public static String password = RBSDataSetupConstants.DEFAULT_PASSWORD;
    public String stdId;
    public String organizationName;
    public String teacherUserName;
    public String firstStudent;
    public String secondStudent;
    public String mathSettingIPOnCourse;
    public String mathSettingIPOffCourse;
    public String mathSkillCourse;
    public String mathStandardCourse;
    public String readingSettingIPOnCourse;
    public String readingSettingIPOffCourse;
    public String readingSkillCourse;
    public String readingStandardCourse;
    public String firstStudentID;
    public String secondStudentID;

    @BeforeClass
    public void BeforeTest() throws Exception {
        smUrl = "https://sm-reports-bff-srv-stack-dev.smdemo.info";
        browser = configProperty.getProperty( "BrowserPlatformToRun" );

        // Getting District admin username and password
        username = ReportDataCollection.districtAdmin;
        password = RBSDataSetupConstants.DEFAULT_PASSWORD;
        userId = SMUtils.getKeyValueFromResponse( ReportDataCollection.districtAdminDetails, Constants.USERID );
        orgId = configProperty.getProperty( ConfigConstants.DISTRICT_ID );
        schoolId = ReportDataCollection.orgId;
        organizationName = RBSDataSetup.getSchools( Schools.FLEX_SCHOOL );

        List<String> teacherUsernames = new ArrayList<>( ReportDataCollection.teacherDetails.keySet() );
        // Getting student username
        teacherUserName = teacherUsernames.get( 0 );

        RBSUtils rbsUtils = new RBSUtils();

        Map<String, String> studentDetails = ReportDataCollection.defaultMathAssignmentDetails.get( teacherUserName );

        String ipClearedStudentUserId = studentDetails.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( studentDetails.get( student ), "ipStatus" ).equalsIgnoreCase( "COMPLETE" ) ).findFirst().get();
        String ipNotClearedStudentUserId = studentDetails.keySet().stream().filter( student -> SMUtils.getKeyValueFromResponse( studentDetails.get( student ), "ipStatus" ).equalsIgnoreCase( "PENDING" )
                && SMUtils.getKeyValueFromResponse( studentDetails.get( student ), "currentLevel" ).contains( "null" ) ).findFirst().get();

        String ipClearedStudentFirstname = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( ipClearedStudentUserId ), "firstName" );
        String ipClearedStudentLastname = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( ipClearedStudentUserId ), "lastName" );

        String ipNotClearedStudentFirstname = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( ipNotClearedStudentUserId ), "firstName" );
        String ipNotClearedStudentLastname = SMUtils.getKeyValueFromResponse( rbsUtils.getUser( ipNotClearedStudentUserId ), "lastName" );

        firstStudent = ipClearedStudentFirstname + " " + ipClearedStudentLastname;
        secondStudent = ipNotClearedStudentFirstname + " " + ipNotClearedStudentLastname;

        // Getting Math course name
        mathSettingIPOnCourse = SMUtils.getKeyValueFromResponse( ReportDataCollection.mathSettingIPMONAssignmentDetails.get( teacherUserName ).get( ipClearedStudentUserId ), "courseDetail,name" );
        mathSettingIPOffCourse = SMUtils.getKeyValueFromResponse( ReportDataCollection.mathSettingIPMOFFAssignmentDetails.get( teacherUserName ).get( ipClearedStudentUserId ), "courseDetail,name" );
        mathSkillCourse = SMUtils.getKeyValueFromResponse( ReportDataCollection.mathSkillAssignmentDetails.get( teacherUserName ).get( ipClearedStudentUserId ), "courseDetail,name" );
        mathStandardCourse = SMUtils.getKeyValueFromResponse( ReportDataCollection.mathStandardAssignmentDetails.get( teacherUserName ).get( ipClearedStudentUserId ), "courseDetail,name" );

        // Getting Reading course name
        readingSettingIPOnCourse = SMUtils.getKeyValueFromResponse( ReportDataCollection.readingSettingIPMONAssignmentDetails.get( teacherUserName ).get( ipClearedStudentUserId ), "courseDetail,name" );
        readingSettingIPOffCourse = SMUtils.getKeyValueFromResponse( ReportDataCollection.readingSettingIPMOFFAssignmentDetails.get( teacherUserName ).get( ipClearedStudentUserId ), "courseDetail,name" );
        readingSkillCourse = SMUtils.getKeyValueFromResponse( ReportDataCollection.readingSkillAssignmentDetails.get( teacherUserName ).get( ipClearedStudentUserId ), "courseDetail,name" );
        readingStandardCourse = SMUtils.getKeyValueFromResponse( ReportDataCollection.readingStandardAssignmentDetails.get( teacherUserName ).get( ipClearedStudentUserId ), "courseDetail,name" );

    }

    @Test ( dataProvider = "getDataforPostive", priority = 1, groups = { "SMK-67546", "Mastery admin", "Export CSV", "API" } )
    public void masteryExportCSV( String testcaseID, String testDescription, String statusCode, String scenario ) throws Exception {
        Log.testCaseInfo( testcaseID + " - " + testDescription );

        HashMap<String, String> headers = new HashMap<>();
        List<Map<String, String>> splitCSVDataFromResponse = new ArrayList<>();
        List<String> customExport = new ArrayList<>();
        Response getResponse;
        String requestId;
        Response saveAdminMasteryReportOptionResponse;
        String masteryExport;
        String masteryOutpage;
        String getStatusCode;
        String masteryCsv;
        Response masteryResponce;
        Reports report = new Reports();
        AdminReportCsv exportCsv = new AdminReportCsv();
        Reports masteryReport = new Reports();
        String token = new RBSUtils().getAccessToken( username, password );
        headers.put( Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( Constants.AUTHORIZATION, "Bearer " + token );
        headers.put( UserConstants.USERID, userId );
        headers.put( UserConstants.ORGID, orgId );

        switch ( scenario ) {

            case "Mastery Skills - Math":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 1, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, Constants.MATH, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.MATH, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery standard - Math":
                HashMap<String, String> mathGradeStandardDetails = SqlHelperCourses.getGradeStandardID( Constants.MATH, false );
                stdId = mathGradeStandardDetails.get( "StandardID" ).trim();
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "true", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 1, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, Constants.MATH, firstStudent ).trim();
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.MATH, ExportCsvConstants.DEFAULT, "" ).trim();
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery Skills - Reading":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 2, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, Constants.READING, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.READING, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryOutpage ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery standard - reading":
                HashMap<String, String> readingGradeStandardDetails = SqlHelperCourses.getGradeStandardID( Constants.READING, false );
                stdId = readingGradeStandardDetails.get( "StandardID" ).trim();
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "true", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 2, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, Constants.READING, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.READING, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery -math IPM completed":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, "default", requestId, stdId, 1, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, Constants.MATH, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.MATH, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - math IPM not completed":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 1, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, Constants.MATH, secondStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, secondStudent, Constants.MATH, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - reading  IPM completed":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 2, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, Constants.READING, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.READING, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryOutpage ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - reading IPM not completed":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 2, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, Constants.READING, secondStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, secondStudent, Constants.READING, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - math Custom Setting IP On completed":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 1, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, mathSettingIPOnCourse, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, mathSettingIPOnCourse, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - math Custom Setting IP On not completed":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 1, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, mathSettingIPOnCourse, secondStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, secondStudent, mathSettingIPOnCourse, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - reading Custom Setting IP On completed":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 2, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, readingSettingIPOnCourse, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, readingSettingIPOnCourse, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - reading Custom Setting IP On not completed":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 2, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, readingSettingIPOnCourse, secondStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, secondStudent, readingSettingIPOnCourse, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - Math Custom Setting IP Off completed":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 1, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, mathSettingIPOffCourse, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, mathSettingIPOffCourse, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - Reading Custom Setting IP Off not completed":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 2, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, readingSettingIPOffCourse, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, readingSettingIPOffCourse, ExportCsvConstants.DEFAULT, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - Math Custom by skill":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 1, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, mathSkillCourse, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, mathSkillCourse, ExportCsvConstants.DEFAULT, mathSkillCourse );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - Reading Custom by skill":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 2, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, readingSkillCourse, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, readingSkillCourse, ExportCsvConstants.DEFAULT, readingSkillCourse );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - Math - Custom by standard assignment":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 1, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, mathStandardCourse, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, mathStandardCourse, ExportCsvConstants.DEFAULT, mathStandardCourse );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - Reading - Custom by standard assignment":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 2, new ArrayList<>() );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneDefaultStudent( splitCSVDataFromResponse, readingStandardCourse, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, readingStandardCourse, ExportCsvConstants.DEFAULT, readingStandardCourse );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "(Custom) Mastery skill- Math":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                customExport.add( "assignedCourseLevel" );
                customExport.add( "AverageSessionTime" );
                customExport.add( "contentBaseTypeName" );
                customExport.add( "courseId" );
                customExport.add( "courseName" );
                customExport.add( "currentCourseLevel" );
                customExport.add( "grade" );
                customExport.add( "ipLevel" );
                customExport.add( "ipmStatusName" );
                customExport.add( "masteryData.masteryStatus" );
                customExport.add( "masteryData.noOfAttempts" );
                customExport.add( "masteryData.noOfSkillsCompleted" );
                customExport.add( "masteryData.skillStandardName" );
                customExport.add( "studentId" );
                customExport.add( "studentName" );
                customExport.add( "timeSpent" );
                customExport.add( "totalSessions" );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.CUSTOM, requestId, stdId, 1, customExport );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneCustomStudent( splitCSVDataFromResponse, Constants.MATH, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.MATH, ExportCsvConstants.CUSTOM, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "(Custom) Mastery standard- Math":
                HashMap<String, String> mathGradeStandardDetails1 = SqlHelperCourses.getGradeStandardID( Constants.MATH, false );
                stdId = mathGradeStandardDetails1.get( "StandardID" ).trim();
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "true", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                customExport.add( "assignedCourseLevel" );
                customExport.add( "AverageSessionTime" );
                customExport.add( "contentBaseTypeName" );
                customExport.add( "courseId" );
                customExport.add( "courseName" );
                customExport.add( "currentCourseLevel" );
                customExport.add( "grade" );
                customExport.add( "ipLevel" );
                customExport.add( "ipmStatusName" );
                customExport.add( "masteryData.masteryStatus" );
                customExport.add( "masteryData.noOfAttempts" );
                customExport.add( "masteryData.noOfSkillsCompleted" );
                customExport.add( "masteryData.skillStandardName" );
                customExport.add( "studentId" );
                customExport.add( "studentName" );
                customExport.add( "timeSpent" );
                customExport.add( "totalSessions" );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.CUSTOM, requestId, stdId, 1, customExport );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneCustomStudent( splitCSVDataFromResponse, Constants.MATH, firstStudent ).trim();
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.MATH, ExportCsvConstants.CUSTOM, "" ).trim();
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "(Custom) Mastery skill- reading ":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                customExport.add( "assignedCourseLevel" );
                customExport.add( "AverageSessionTime" );
                customExport.add( "contentBaseTypeName" );
                customExport.add( "courseId" );
                customExport.add( "courseName" );
                customExport.add( "currentCourseLevel" );
                customExport.add( "grade" );
                customExport.add( "ipLevel" );
                customExport.add( "ipmStatusName" );
                customExport.add( "masteryData.masteryStatus" );
                customExport.add( "masteryData.noOfAttempts" );
                customExport.add( "masteryData.noOfSkillsCompleted" );
                customExport.add( "masteryData.skillStandardName" );
                customExport.add( "studentId" );
                customExport.add( "studentName" );
                customExport.add( "timeSpent" );
                customExport.add( "totalSessions" );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.CUSTOM, requestId, stdId, 2, customExport );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneCustomStudent( splitCSVDataFromResponse, Constants.READING, firstStudent ).trim();
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.READING, ExportCsvConstants.CUSTOM, "" ).trim();
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "(Custom) Mastery standard - reading":
                HashMap<String, String> readingGradeStandardDetails1 = SqlHelperCourses.getGradeStandardID( Constants.READING, false );
                stdId = readingGradeStandardDetails1.get( "StandardID" ).trim();
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "true", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                customExport.add( "assignedCourseLevel" );
                customExport.add( "AverageSessionTime" );
                customExport.add( "contentBaseTypeName" );
                customExport.add( "courseId" );
                customExport.add( "courseName" );
                customExport.add( "currentCourseLevel" );
                customExport.add( "grade" );
                customExport.add( "ipLevel" );
                customExport.add( "ipmStatusName" );
                customExport.add( "masteryData.masteryStatus" );
                customExport.add( "masteryData.noOfAttempts" );
                customExport.add( "masteryData.noOfSkillsCompleted" );
                customExport.add( "masteryData.skillStandardName" );
                customExport.add( "studentId" );
                customExport.add( "studentName" );
                customExport.add( "timeSpent" );
                customExport.add( "totalSessions" );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.CUSTOM, requestId, stdId, 2, customExport );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneCustomStudent( splitCSVDataFromResponse, Constants.READING, firstStudent ).trim();
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.READING, ExportCsvConstants.CUSTOM, "" ).trim();
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery -Custom single column name":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                customExport.add( "courseId" );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.CUSTOM, requestId, stdId, 1, customExport );
                masteryCsv = getCsvValues( getResponse );
                masteryExport = new ExportCsvUtils().getCsvFileHeasers( masteryCsv ).replace( "\"", "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryExport.equals( customExport.get( 0 ).toString() ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + customExport + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;
            case "Mastery -Custom multiple column name":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                customExport.add( "courseId" );
                customExport.add( "courseName" );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.CUSTOM, requestId, stdId, 1, customExport );
                masteryCsv = getCsvValues( getResponse );
                masteryExport = new ExportCsvUtils().getCsvFileHeasers( masteryCsv ).replace( "\"", "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryExport.equals( customExport.get( 0 ).toString() + "," + customExport.get( 1 ).toString() ), "Column headers and value are resturned as expected",
                        "Column headers and value are not resturned properly" + customExport + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery -Custom all column name":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                customExport.add( "assignedCourseLevel" );
                customExport.add( "AverageSessionTime" );
                customExport.add( "contentBaseTypeName" );
                customExport.add( "courseId" );
                customExport.add( "courseName" );
                customExport.add( "currentCourseLevel" );
                customExport.add( "grade" );
                customExport.add( "ipLevel" );
                customExport.add( "ipmStatusName" );
                customExport.add( "masteryData.masteryStatus" );
                customExport.add( "masteryData.noOfAttempts" );
                customExport.add( "masteryData.noOfSkillsCompleted" );
                customExport.add( "masteryData.skillStandardName" );
                customExport.add( "studentId" );
                customExport.add( "studentName" );
                customExport.add( "timeSpent" );
                customExport.add( "totalSessions" );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.CUSTOM, requestId, stdId, 1, customExport );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneCustomStudent( splitCSVDataFromResponse, Constants.MATH, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.MATH, ExportCsvConstants.CUSTOM, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery -Math custom field":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                customExport.add( "assignedCourseLevel" );
                customExport.add( "AverageSessionTime" );
                customExport.add( "contentBaseTypeName" );
                customExport.add( "courseId" );
                customExport.add( "courseName" );
                customExport.add( "currentCourseLevel" );
                customExport.add( "grade" );
                customExport.add( "ipLevel" );
                customExport.add( "ipmStatusName" );
                customExport.add( "masteryData.masteryStatus" );
                customExport.add( "masteryData.noOfAttempts" );
                customExport.add( "masteryData.noOfSkillsCompleted" );
                customExport.add( "masteryData.skillStandardName" );
                customExport.add( "studentId" );
                customExport.add( "studentName" );
                customExport.add( "timeSpent" );
                customExport.add( "totalSessions" );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.CUSTOM, requestId, stdId, 1, customExport );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneCustomStudent( splitCSVDataFromResponse, Constants.MATH, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 1 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.MATH, ExportCsvConstants.CUSTOM, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - reading custom field":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "2", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                customExport.add( "assignedCourseLevel" );
                customExport.add( "AverageSessionTime" );
                customExport.add( "contentBaseTypeName" );
                customExport.add( "courseId" );
                customExport.add( "courseName" );
                customExport.add( "currentCourseLevel" );
                customExport.add( "grade" );
                customExport.add( "ipLevel" );
                customExport.add( "ipmStatusName" );
                customExport.add( "masteryData.masteryStatus" );
                customExport.add( "masteryData.noOfAttempts" );
                customExport.add( "masteryData.noOfSkillsCompleted" );
                customExport.add( "masteryData.skillStandardName" );
                customExport.add( "studentId" );
                customExport.add( "studentName" );
                customExport.add( "timeSpent" );
                customExport.add( "totalSessions" );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.CUSTOM, requestId, stdId, 2, customExport );
                masteryCsv = getCsvValues( getResponse );
                splitCSVDataFromResponse = splitCSVData( masteryCsv );
                masteryExport = oneCustomStudent( splitCSVDataFromResponse, Constants.READING, firstStudent );
                masteryResponce = masteryReport.postMasteryReport( headers, schoolId, stdId, 2 );
                masteryOutpage = masteryOnestudent( masteryResponce, firstStudent, Constants.READING, ExportCsvConstants.CUSTOM, "" );
                getStatusCode = String.valueOf( getResponse.getStatusCode() );
                Log.assertThat( masteryOutpage.equals( masteryExport ), "Column headers and value are resturned as expected", "Column headers and value are not resturned properly" + masteryOutpage + " Actual - " + masteryExport );
                Log.assertThat( getStatusCode.equals( statusCode ), "Status code returned as expected!", "Issue in returning status code! Expected - " + statusCode + " Actual - " + getResponse.getStatusCode() );
                break;

            case "Mastery - Custom":
                stdId = "";
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                customExport.add( "courseId" );
                customExport.add( "courseName" );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.CUSTOM, requestId, stdId, 1, customExport );
                Log.assertThat( SMUtils.getKeyValueFromResponse( getResponse.getBody().asString(), "uploadUrl" ).contains( requestId ), "Request Id is present in the upload url", "Request Id is not present in the upload url" );
                Log.assertThat( SMUtils.getKeyValueFromResponse( getResponse.getBody().asString(), "signedUrl" ).contains( requestId ), "Request Id is present in the signedUrl", "Request Id is not present in the signedUrlurl" );
                break;

            case "Mastery - Default":
                saveAdminMasteryReportOptionResponse = report.saveAdminMasteryReportOption( headers, schoolId, "1", "false", stdId );
                requestId = getRequestIdFromResponse( saveAdminMasteryReportOptionResponse.getBody().asString() );
                getResponse = exportCsv.postMasteryExportCSVAPI( headers, schoolId, ExportCsvConstants.DEFAULT, requestId, stdId, 1, new ArrayList<>() );
                Log.assertThat( SMUtils.getKeyValueFromResponse( getResponse.getBody().asString(), "uploadUrl" ).contains( requestId ), "Request Id is present in the upload url", "Request Id is not present in the upload url" );
                Log.assertThat( SMUtils.getKeyValueFromResponse( getResponse.getBody().asString(), "signedUrl" ).contains( requestId ), "Request Id is present in the signedUrl", "Request Id is not present in the signedUrlurl" );
                break;
        }

    }

    @DataProvider ( name = "getDataforPostive" )
    public Object[][] getDataforPostive() {

        Object[][] data = { { "tcMasteryadminExportCSV001", "Verify the status code and csv headers (column name) in the response, for Default Export - Math Subject and skill/standard SuccessMaker Mastery Skills - Math", "200", "Mastery Skills - Math" },
                { "tcMasteryadminExportCSV002", "Verify the status code and csv headers (column name) in the response, for Default Export - Math Subject and skill/standard - aimswebPlus", "200", "Mastery standard - Math" },
                { "tcMasteryadminExportCSV003", "Verify the status code and csv headers (column name) in the response, for Default Export - Reading Subject and skill/standard SuccessMaker Mastery Skills - Math", "200", "Mastery Skills - Reading" },

                { "tcMasteryadminExportCSV004", "Verify the status code and csv headers (column name) in the response, for Default Export - Reading Subject and skill/standard - any one standard", "200", "Mastery standard - reading" },
                { "tcMasteryadminExportCSV005", " Verify all the fields in the response for Default math assignment who has cleared the IP.", "200", "Mastery -math IPM completed" },

                { "tcMasteryadminExportCSV006", "Verify all the fields in the response for Default math assignment who has not cleared the IP.", "200", "Mastery - math IPM not completed" },

                { "tcMasteryadminExportCSV008", " Verify all the fields in the response for Default reading assignment who has cleared the IP.", "200", "Mastery - reading  IPM completed" },

                { "tcMasteryadminExportCSV009", "Verify all the fields in the response for Default reading assignment who has not cleared the IP.", "200", "Mastery - reading IPM not completed" },

                { "tcMasteryadminExportCSV010", "Verify all the fields in the response for Math - Custom Setting IP On  assignment who has cleared the IP.", "200", "Mastery - math Custom Setting IP On completed" },
                { "tcMasteryadminExportCSV011", "Verify all the fields in the response for  Math - Custom Setting IP On assignment who has not cleared the IP.", "200", "Mastery - math Custom Setting IP On not completed" },

                { "tcMasteryadminExportCSV012", "Verify all the fields in the response for Reading - Custom Setting IP On  assignment who has cleared the IP.", "200", "Mastery - reading Custom Setting IP On completed" },
                { "tcMasteryadminExportCSV013", " Verify all the fields in the response for  Reading - Custom Setting IP On assignment who has not cleared the IP.", "200", "Mastery - reading Custom Setting IP On not completed" },

                { "tcMasteryadminExportCSV014", "  Verify all the fields in the response for Math - Custom Setting IP Off  assignment.", "200", "Mastery - Math Custom Setting IP Off completed" },
                { "tcMasteryadminExportCSV015", "Verify all the fields in the response for Reading - Custom Setting IP Off assignment.", "200", "Mastery - Reading Custom Setting IP Off not completed" },

                { "tcMasteryadminExportCSV016", " Verify all the fields in the response for Math - Custom by skill assignment.", "200", "Mastery - Math Custom by skill" },
                { "tcMasteryadminExportCSV017", " Verify all the fields in the response for Reading Custom by skill  assignment.", "200", "Mastery - Reading Custom by skill" },

                { "tcMasteryadminExportCSV018", "Verify all the fields in the response for Math - Custom by standard assignment.", "200", "Mastery - Math - Custom by standard assignment" },
                { "tcMasteryadminExportCSV020", "(custom export API) Verify the status code and csv headers (column name) in the response, for custom Export - Math Subject and skill/standard SuccessMaker Mastery Skills - Math", "200",
                        "(Custom) Mastery skill- Math" },

                { "tcMasteryadminExportCSV021", "(custom export API) Verify the status code and csv headers (column name) in the response, for custom Export - Math Subject and skill/standard - aimswebPlus", "200", "(Custom) Mastery standard- Math" },

                { "tcMasteryadminExportCSV022", "(custom export API) Verify the status code and csv headers (column name) in the response, for custom Export - Reading Subject and skill/standard SuccessMaker Mastery Skills - Math", "200",
                        "(Custom) Mastery skill- reading " },
                { "tcMasteryadminExportCSV023", "(custom export API) Verify the status code and csv headers (column name) in the response, for custom Export - Reading Subject and skill/standard - any one standard", "200",
                        "(Custom) Mastery standard - reading" },

                { "tcMasteryadminExportCSV024", "(Custom export API) Verify the status code and response if we pass the single column name in selected fields Ordered", "200", "Mastery - Custom single column name" },
                { "tcMasteryadminExportCSV025", "( Custom export API) Verify the status code and response if we pass the multiple column names in selected fields Ordered", "200", "Mastery -Custom multiple column name" },

                { "tcMasteryadminExportCSV026", "(Custom export API) Verify the status code and response if we pass the all column names in selected fields Ordered", "200", "Mastery -Custom all column name" },
                { "tcMasteryadminExportCSV027", "(Custom export API)  Verify Assigned course level,Current course level and IP level the fields in the response for custom math assignment ", "200", "Mastery -Math custom field" },

                { "tcMasteryadminExportCSV028", "(Custom export API)  Verify Assigned course level,Current course level and IP level the fields in the response for custom reading assignment ", "200", "Mastery - reading custom field" },
                { "tcMasteryadminExportCSV029", "Verify the  Mastery export Bff response for Math subject , if pass single organization and exportType as custom", "200", "Mastery - Custom" },

                { "tcMasteryadminExportCSV030", "Verify the  Mastery export Bff response for Math subject , if pass single organization and exportType as default", "200", "Mastery - Default" }

        };
        return data;

    }

    public String masteryOnestudent( Response getResponse, String student, String course, String CSVType, String skillStandardCourse ) throws Exception {
        String body = getResponse.getBody().asString();
        String keyValueFromResponse = SMUtils.getKeyValueFromResponse( body, "data" );
        String keyVlu = SMUtils.getKeyValueFromResponse( keyValueFromResponse, "getAdminMasteryReportData" );

        String keyValueFromResponse2 = SMUtils.getKeyValueFromResponse( keyVlu, "masteryReportResponse" );

        List<HashMap<String, String>> alldetsil = new ArrayList<>();
        JSONArray ja = new JSONArray( keyValueFromResponse2 );

        for ( int i = 0; i < new JSONArray( keyValueFromResponse2 ).length(); i++ ) {
            String formatedAssignedCourseLevel;
            if ( ja.getJSONObject( i ).get( "assignedCourseLevel" ).toString().equals( "0" ) || ja.getJSONObject( i ).get( "AverageSessionTime" ).toString().equals( "null" ) ) {
                formatedAssignedCourseLevel = "NA";
            } else {
                int assignedCourseLevel = Integer.parseInt( ja.getJSONObject( i ).get( "assignedCourseLevel" ).toString() );
                DecimalFormat df = new DecimalFormat( "#.00" );
                formatedAssignedCourseLevel = df.format( assignedCourseLevel );
            }
            String averageSessionTime = minuteToTime( Integer.parseInt( ja.getJSONObject( i ).get( "AverageSessionTime" ).toString() ) );
            String currentCourseLevel;
            if ( ja.getJSONObject( i ).get( "currentCourseLevel" ).toString().equals( "0" ) || ja.getJSONObject( i ).get( "currentCourseLevel" ).toString().equals( "null" ) ) {
                currentCourseLevel = "NA";
            } else {
                double currentCourseLevelRound = Double.valueOf( ja.getJSONObject( i ).getNumber( "currentCourseLevel" ).toString() );
                DecimalFormat df = new DecimalFormat( "#.00" );
                currentCourseLevel = df.format( currentCourseLevelRound );
            }
            String courseName = ja.getJSONObject( i ).get( "courseName" ).toString();
            String gradeName = ja.getJSONObject( i ).get( "grade" ).toString();
            String iPlevel;
            String studentName = ja.getJSONObject( i ).get( "studentName" ).toString();
            String timeSpent = minuteToTime( Integer.parseInt( ja.getJSONObject( i ).get( "timeSpent" ).toString() ) );
            String totalSession = ja.getJSONObject( i ).get( "totalSessions" ).toString();
            String ipmStatusName = ja.getJSONObject( i ).get( "ipmStatusName" ).toString();
            if ( ipmStatusName.equals( "pending" ) ) {
                iPlevel = "In IP";
            } else if ( ipmStatusName.equals( "inactive" ) ) {
                iPlevel = "NA";

            }

            else {
                double iPlevelRoundOff = Double.valueOf( ja.getJSONObject( i ).getNumber( "ipLevel" ).toString() );
                DecimalFormat df = new DecimalFormat( "#.00" );
                iPlevel = df.format( iPlevelRoundOff );

            }
            if ( gradeName.contains( "0" ) ) {
                gradeName = gradeName.replace( "0", "" );
            }
            if ( CSVType.equals( "default" ) ) {

                if ( studentName.equals( student ) && courseName.equals( course ) ) {
                    String masteryData = ja.getJSONObject( i ).get( "masteryData" ).toString();
                    String masteryStatus;
                    for ( int j = 0; j < new JSONArray( masteryData ).length(); j++ ) {
                        HashMap<String, String> respon = new HashMap<>();
                        if ( course.equals( skillStandardCourse ) ) {
                            respon.put( "Assigned course level", "NA" );
                            respon.put( "Current course level", "NA" );
                            respon.put( "IP level", "NA" );
                        } else {
                            respon.put( "Assigned course level", formatedAssignedCourseLevel );
                            respon.put( "Current course level", currentCourseLevel );
                            respon.put( "IP level", iPlevel );

                        }
                        respon.put( "Average Session Time", averageSessionTime );
                        respon.put( "Course Name", courseName );
                        respon.put( "Grade Name", gradeName );
                        if ( new JSONArray( masteryData ).getJSONObject( j ).get( "masteryStatus" ).toString().equals( "In Progress" ) ) {
                            masteryStatus = "Not Mastered";
                        } else {
                            masteryStatus = new JSONArray( masteryData ).getJSONObject( j ).get( "masteryStatus" ).toString();
                        }
                        respon.put( "Mastery Status", masteryStatus );
                        respon.put( "# of Attempts", new JSONArray( masteryData ).getJSONObject( j ).get( "noOfAttempts" ).toString() );
                        respon.put( "# of Skills Completed/Judged", new JSONArray( masteryData ).getJSONObject( j ).get( "noOfSkillsCompleted" ).toString() );
                        respon.put( "Skill or Standard", new JSONArray( masteryData ).getJSONObject( j ).get( "skillStandardName" ).toString() );
                        respon.put( "Student Name", studentName );
                        respon.put( "Time Spent", timeSpent );
                        respon.put( "Total Sessions", totalSession );
                        alldetsil.add( respon );
                    }
                }

            } else {
                if ( studentName.equals( student ) && courseName.equals( course ) ) {
                    String masteryData = ja.getJSONObject( i ).get( "masteryData" ).toString();
                    for ( int j = 0; j < new JSONArray( masteryData ).length(); j++ ) {
                        HashMap<String, String> respon = new HashMap<>();
                        respon.put( "assignedCourseLevel", ja.getJSONObject( i ).get( "assignedCourseLevel" ).toString() );
                        respon.put( "averageSessionTime", ja.getJSONObject( i ).get( "AverageSessionTime" ).toString() );
                        respon.put( "contentBaseTypeName", ja.getJSONObject( i ).get( "contentBaseTypeName" ).toString() );
                        respon.put( "courseId", ja.getJSONObject( i ).getString( "courseId" ).toString() );
                        respon.put( "courseName", ja.getJSONObject( i ).get( "courseName" ).toString() );
                        respon.put( "currentCourseLevel", ja.getJSONObject( i ).get( "currentCourseLevel" ).toString() );
                        respon.put( "grade", ja.getJSONObject( i ).get( "grade" ).toString() );
                        respon.put( "ipLevel", ja.getJSONObject( i ).get( "ipLevel" ).toString() );
                        respon.put( "ipmStatusName", ja.getJSONObject( i ).get( "ipmStatusName" ).toString() );
                        respon.put( "masteryStatus", new JSONArray( masteryData ).getJSONObject( j ).get( "masteryStatus" ).toString() );
                        respon.put( "noOfAttempts", new JSONArray( masteryData ).getJSONObject( j ).get( "noOfAttempts" ).toString() );
                        respon.put( "noOfSkillsCompleted", new JSONArray( masteryData ).getJSONObject( j ).get( "noOfSkillsCompleted" ).toString() );
                        respon.put( "skillStandardName", new JSONArray( masteryData ).getJSONObject( j ).get( "skillStandardName" ).toString() );
                        respon.put( "studentId", ja.getJSONObject( i ).get( "studentId" ).toString() );
                        respon.put( "studentName", ja.getJSONObject( i ).get( "studentName" ).toString() );
                        respon.put( "timeSpent", ja.getJSONObject( i ).get( "timeSpent" ).toString() );
                        respon.put( "totalSessions", ja.getJSONObject( i ).get( "totalSessions" ).toString() );
                        alldetsil.add( respon );
                    }
                }
            }
        }
        return alldetsil.toString();

    }

    public static String minuteToTime( int minute ) {
        int hour = minute / 60;
        minute %= 60;
        String time = ( hour < 10 ? "0" + hour : hour ) + ":" + ( minute < 10 ? "0" + minute : minute );
        return time;
    }

    /**
     * To Split the one student csv data
     *
     * @return
     *
     * @throws IOException
     *
     */
    public String oneDefaultStudent( List<Map<String, String>> splitCSVDataFromResponse, String courseName, String studentName ) {

        List<HashMap<String, String>> alldetsil = new ArrayList<>();
        for ( int ir = 0; ir < splitCSVDataFromResponse.size(); ir++ ) {
            if ( splitCSVDataFromResponse.get( ir ).get( "\"Course Name\"" ).equalsIgnoreCase( "\"" + courseName + "\"" ) ) {

                if ( splitCSVDataFromResponse.get( ir ).get( "\"Course Name\"" ).equalsIgnoreCase( "\"" + courseName + "\"" ) && splitCSVDataFromResponse.get( ir ).get( "\"Student Name\"" ).equalsIgnoreCase( "\"" + studentName + "\"" ) ) {
                    HashMap<String, String> onestudent = new HashMap<>();
                    onestudent.put( "Assigned course level", splitCSVDataFromResponse.get( ir ).get( "\"Assigned course level\"" ) );
                    onestudent.put( "Average Session Time", splitCSVDataFromResponse.get( ir ).get( "\"Average Session Time\"" ) );
                    onestudent.put( "Course Name", splitCSVDataFromResponse.get( ir ).get( "\"Course Name\"" ) );
                    onestudent.put( "Current course level", splitCSVDataFromResponse.get( ir ).get( "\"Current course level\"" ) );
                    onestudent.put( "Grade Name", splitCSVDataFromResponse.get( ir ).get( "\"Grade Name\"" ) );
                    onestudent.put( "IP level", splitCSVDataFromResponse.get( ir ).get( "\"IP level\"" ) );
                    onestudent.put( "Mastery Status", splitCSVDataFromResponse.get( ir ).get( "\"Mastery Status\"" ) );
                    onestudent.put( "# of Attempts", splitCSVDataFromResponse.get( ir ).get( "\"# of Attempts\"" ) );
                    onestudent.put( "# of Skills Completed/Judged", splitCSVDataFromResponse.get( ir ).get( "\"# of Skills Completed/Judged\"" ) );
                    onestudent.put( "Skill or Standard", splitCSVDataFromResponse.get( ir ).get( "\"Skill or Standard\"" ) );
                    onestudent.put( "Student Name", splitCSVDataFromResponse.get( ir ).get( "\"Student Name\"" ) );
                    onestudent.put( "Time Spent", splitCSVDataFromResponse.get( ir ).get( "\"Time Spent\"" ) );
                    onestudent.put( "Total Sessions", splitCSVDataFromResponse.get( ir ).get( "\"Total Sessions\"" ) );

                    alldetsil.add( onestudent );
                }
            }
        }

        return alldetsil.toString().replace( "\"", "" );
    }

    public String oneCustomStudent( List<Map<String, String>> splitCSVDataFromResponse, String courseName, String studentName ) {

        List<HashMap<String, String>> alldetsil = new ArrayList<>();
        for ( int ir = 0; ir < splitCSVDataFromResponse.size(); ir++ ) {

            if ( splitCSVDataFromResponse.get( ir ).get( "\"courseName\"" ).equalsIgnoreCase( "\"" + courseName + "\"" ) && splitCSVDataFromResponse.get( ir ).get( "\"studentName\"" ).equalsIgnoreCase( "\"" + studentName + "\"" ) ) {
                HashMap<String, String> onestudent = new HashMap<>();

                onestudent.put( "assignedCourseLevel", splitCSVDataFromResponse.get( ir ).get( "\"assignedCourseLevel\"" ) );
                onestudent.put( "averageSessionTime", splitCSVDataFromResponse.get( ir ).get( "\"averageSessionTime\"" ) );
                onestudent.put( "contentBaseTypeName", splitCSVDataFromResponse.get( ir ).get( "\"contentBaseTypeName\"" ) );
                onestudent.put( "courseId", splitCSVDataFromResponse.get( ir ).get( "\"courseId\"" ) );
                onestudent.put( "courseName", splitCSVDataFromResponse.get( ir ).get( "\"courseName\"" ) );
                onestudent.put( "currentCourseLevel", splitCSVDataFromResponse.get( ir ).get( "\"currentCourseLevel\"" ) );
                onestudent.put( "grade", splitCSVDataFromResponse.get( ir ).get( "\"grade\"" ) );
                onestudent.put( "ipLevel", splitCSVDataFromResponse.get( ir ).get( "\"ipLevel\"" ) );
                onestudent.put( "ipmStatusName", splitCSVDataFromResponse.get( ir ).get( "\"ipmStatusName\"" ) );
                onestudent.put( "masteryStatus", splitCSVDataFromResponse.get( ir ).get( "\"masteryStatus\"" ) );
                onestudent.put( "noOfAttempts", splitCSVDataFromResponse.get( ir ).get( "\"noOfAttempts\"" ) );
                onestudent.put( "noOfSkillsCompleted", splitCSVDataFromResponse.get( ir ).get( "\"noOfSkillsCompleted\"" ) );
                onestudent.put( "skillStandardName", splitCSVDataFromResponse.get( ir ).get( "\"skillStandardName\"" ) );
                onestudent.put( "studentId", splitCSVDataFromResponse.get( ir ).get( "\"studentId\"" ) );
                onestudent.put( "studentName", splitCSVDataFromResponse.get( ir ).get( "\"studentName\"" ) );
                onestudent.put( "timeSpent", splitCSVDataFromResponse.get( ir ).get( "\"timeSpent\"" ) );
                onestudent.put( "totalSessions", splitCSVDataFromResponse.get( ir ).get( "\"totalSessions\"" ) );

                alldetsil.add( onestudent );
            }
        }

        return alldetsil.toString().replace( "\"", "" );

    }

    public String getCsvValues( Response csv ) {
        String csvDataFromBS = null;
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        try {
            driver.get( SMUtils.getKeyValueFromResponse( csv.getBody().asString(), "signedUrl" ) );
            csvDataFromBS = ExportCsvUtils.getCsvDataFromBS( driver );

        } catch ( Exception e ) {
            Log.message( "Getting Exception while download the csv file!!!!!" );
        } finally {
            driver.quit();
        }
        return csvDataFromBS;
    }

    /**
     * To split the requestId from the response
     * 
     * @param response
     * @return
     */
    public static String getRequestIdFromResponse( String response ) {
        String requestId = null;
        try {
            requestId = SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( SMUtils.getKeyValueFromResponse( response, "data" ), "saveMasteryReportOption" ), "requestId" );
        } catch ( Exception e ) {
            Log.message( "Getting issue while split the request Id from the response -" + response );
        }
        return requestId;

    }

    /**
     * To Split and Store the response csv data
     *
     * @return
     *
     * @throws IOException
     *
     */
    public static List<Map<String, String>> splitCSVData( String response ) {
        List<Map<String, String>> keysAndValueList = new ArrayList();
        List<String> valueList = new ArrayList<>( Arrays.asList( response.split( "\n" ) ) );
        List<String> keys = Arrays.asList( valueList.get( 0 ).split( "," ) );
        valueList.remove( 0 );
        valueList.forEach( row -> {
            List<String> rowValues = Arrays.asList( row.split( "," ) );
            List<String> rowValue = new ArrayList<>();
            for ( int itr = 0; itr < rowValues.size(); itr++ ) {
                if ( !rowValues.get( itr ).isEmpty() ) {
                    if ( ( rowValues.get( itr ).charAt( 0 ) == '"' && rowValues.get( itr ).charAt( rowValues.get( itr ).length() - 1 ) == '"' )
                            || ( !( rowValues.get( itr ).charAt( 0 ) == '"' ) && !( rowValues.get( itr ).charAt( rowValues.get( itr ).length() - 1 ) == '"' ) ) ) {
                        rowValue.add( rowValues.get( itr ) );
                    } else {
                        String value = rowValues.get( itr );
                        while ( !( value.startsWith( "\"" ) && value.endsWith( "\"" ) ) ) {
                            itr++;
                            value = value + "," + rowValues.get( itr );
                        }
                        rowValue.add( value );
                    }
                }
            }
            Map<String, String> keysAndValue = new HashMap<>();
            IntStream.range( 0, rowValue.size() ).forEach( itr -> {
                keysAndValue.put( keys.get( itr ), rowValue.get( itr ) );
            } );
            keysAndValueList.add( keysAndValue );
        } );

        return keysAndValueList;

    }
}
