package com.savvas.sm.api.tests.mastery;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.MasteryAPIConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.config.EnvProperties;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.rbs.RBSUtils;

/**
 * This class is used to test the mastery Summary BFF call for teacher users
 * 
 * @author madhan.nagarathinam
 *
 */
public class MasterySummaryBff extends EnvProperties {
    Boolean isAdminCall;
    String studentIds;
    int subject_Id;
    String userName;
    String organizationId;
    String teacherUserId;

@BeforeClass
public void before() {
    userName = MasteryDataSetup.teacherUserName;
    organizationId = MasteryDataSetup.orgId;
    teacherUserId = MasteryDataSetup.teacherUserId;
    studentIds = "[\\\""+MasteryDataSetup.studentUserId1+"\\\"]";

}


    @Test ( dataProvider = "getDataForPostivieScenarios", groups = { "SMK-55706", "(Automation) (Graphql) Mastery summary data API", "Bff", "GraphQL" }, priority = 1 )
    public void postMasterySummaryDetailsTest001( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId );
        headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId );

        //Mandatory QueryItemList
       isAdminCall = Boolean.parseBoolean( MasteryAPIConstants.Mastery_Summary_BFF.ISADMINCALL_VALUE_TEACHER ); 
        subject_Id = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.MATH_SUBJECT_ID );

        //For Constructing QueryItems in request PayLoad
        List<String> queryItems = new ArrayList<String>();
        String queryItem = null;

        List<String> flatHierarchyQueryItems = new ArrayList<String>();
        String flatHierarchyQueryItem = null;

        List<String> leafFlatHierarchyQueryItems = new ArrayList<String>();
        String leafFlatHierarchyQueryItem = null;

        List<String> masteryMapQueryItems = new ArrayList<String>();
        String masteryMapQueryItem = null;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {

            case "ALL_QUERY_ITEMS":
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.FLAT_HIERARCHY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NAME );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.TIER_DEPTH );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_NAME );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PARENT_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.CHILD_NODES );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_NODE );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PRINT_PARTNER );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.EMPTY_NODE );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRADE_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.DISPLAY_ORDER );
                flatHierarchyQueryItem = constructQueryItems( flatHierarchyQueryItems );
                queryItems.add( flatHierarchyQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_FLAT_HIERARCHY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NAME );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.TIER_DEPTH );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_NAME );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PARENT_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.CHILD_NODES );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_NODE );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PRINT_PARTNER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.EMPTY_NODE );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRADE_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.DISPLAY_ORDER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LO_COURSE_LEVEL );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LO_CATALOG_NUMBER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.VIEW_LO_URL );
                leafFlatHierarchyQueryItem = constructQueryItems( leafFlatHierarchyQueryItems );
                queryItems.add( leafFlatHierarchyQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERED_COUNT );
                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NOT_MASTERED_COUNT );
                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.AT_RISK_COUNT );
                masteryMapQueryItem = constructQueryItems( masteryMapQueryItems );
                queryItems.add( masteryMapQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_IDS );
                queryItem = constructQueryItems( queryItems );

                break;

            case "SINGLE_QUERY_ITEMS":
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_IDS );
                queryItem = constructQueryItems( queryItems );
                break;

            case "MULIPLE_QUERY_ITEMS":
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.FLAT_HIERARCHY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NAME );
                flatHierarchyQueryItem = constructQueryItems( flatHierarchyQueryItems );
                queryItems.add( flatHierarchyQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_FLAT_HIERARCHY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NAME );
                leafFlatHierarchyQueryItem = constructQueryItems( leafFlatHierarchyQueryItems );
                queryItems.add( leafFlatHierarchyQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERED_COUNT );
                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NOT_MASTERED_COUNT );
                masteryMapQueryItem = constructQueryItems( masteryMapQueryItems );
                queryItems.add( masteryMapQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_IDS );
                queryItem = constructQueryItems( queryItems );

                break;

            case "MATH_SUBJECT_ID":
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERED_COUNT );
                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NOT_MASTERED_COUNT );
                masteryMapQueryItem = constructQueryItems( masteryMapQueryItems );
                queryItems.add( masteryMapQueryItem + "}" );
                queryItem = constructQueryItems( queryItems );

                break;

            case "READING_SUBJECT_ID":
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERED_COUNT );
                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NOT_MASTERED_COUNT );
                masteryMapQueryItem = constructQueryItems( masteryMapQueryItems );
                queryItems.add( masteryMapQueryItem + "}" );
                queryItem = constructQueryItems( queryItems );
                subject_Id = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.READING_SUBJECT_ID );
                break;

        }
        String payload = String.format( MasteryAPIConstants.Mastery_Summary_BFF.REQ_PAYLOAD, subject_Id, isAdminCall, studentIds, queryItem );
        Log.message( "payload " +payload );

        Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL, headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
        Log.message( response.getBody().asString() );
        Log.assertThat( 
				new SMAPIProcessor().isSchemaValid( "MasterySummaryBff", expected_StatusCode,
						response.getBody().asString() ),
				"Schema is returned as expected.", "Schema is not as expected." );
        
        if ( scenarioType.equalsIgnoreCase( "ALL_QUERY_ITEMS" ) ) {
            Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                    "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
            Log.assertThat( new SMAPIProcessor().isSchemaValid( "MasterySummaryBff", expected_StatusCode, response.getBody().asString() ), "Schema is returned as expected.", "Schema is not as expected." );

        } else {
            Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                    "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );

        }

    }

    @Test ( dataProvider = "getDataForNegativeScenarios", groups = { "SMK-55706", "(Automation) (Graphql) Mastery summary data API", "Bff", "GraphQL" }, priority = 2 )
    public void postMasterySummaryDetailsTest002( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        //For Constructing QueryItems in request PayLoad
        List<String> queryItems = new ArrayList<String>();
        String queryItem = null;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {

            case "INVALID_ORG_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, MasteryAPIConstants.Mastery_Summary_BFF.INVALID_ORG_ID_VALUE );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId );

                //Mandatory QueryItemList
                isAdminCall = Boolean.parseBoolean( MasteryAPIConstants.Mastery_Summary_BFF.ISADMINCALL_VALUE_TEACHER );
                studentIds = MasteryAPIConstants.Mastery_Summary_BFF.STUDENT_USER_ID_VALUE;
                subject_Id = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.MATH_SUBJECT_ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_IDS );
                queryItem = constructQueryItems( queryItems );
                break;

            case "INVALID_USER_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, MasteryAPIConstants.Mastery_Summary_BFF.INVALID_USER_ID_VALUE );

                //Mandatory QueryItemList
                isAdminCall = Boolean.parseBoolean( MasteryAPIConstants.Mastery_Summary_BFF.ISADMINCALL_VALUE_TEACHER );
                studentIds = MasteryAPIConstants.Mastery_Summary_BFF.STUDENT_USER_ID_VALUE;
                subject_Id = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.MATH_SUBJECT_ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_IDS );
                queryItem = constructQueryItems( queryItems );

                break;

            case "ACCESS_DENIED":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, MasteryAPIConstants.Mastery_Summary_BFF.STUDENT_ID_VALUE );

                //Mandatory QueryItemList
                isAdminCall = Boolean.parseBoolean( MasteryAPIConstants.Mastery_Summary_BFF.ISADMINCALL_VALUE_TEACHER );
                studentIds = MasteryAPIConstants.Mastery_Summary_BFF.STUDENT_USER_ID_VALUE;
                subject_Id = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.MATH_SUBJECT_ID );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_IDS );
                queryItem = constructQueryItems( queryItems );
                break;

            case "INVALID_SUBJECT_ID":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId );

                //Mandatory QueryItemList
                isAdminCall = Boolean.parseBoolean( MasteryAPIConstants.Mastery_Summary_BFF.ISADMINCALL_VALUE_TEACHER );
                studentIds = MasteryAPIConstants.Mastery_Summary_BFF.STUDENT_USER_ID_VALUE;

                subject_Id = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.INVALID_SUBJECT_ID );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_IDS );
                queryItem = constructQueryItems( queryItems );
                break;

            case "INVALID_PAYLOAD":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId );

                //Mandatory QueryItemList
                isAdminCall = Boolean.parseBoolean( MasteryAPIConstants.Mastery_Summary_BFF.ISADMINCALL_VALUE_TEACHER );
                studentIds = MasteryAPIConstants.Mastery_Summary_BFF.STUDENT_USER_ID_VALUE;

                subject_Id = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.MATH_SUBJECT_ID );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_IDS + "{" );
                queryItem = constructQueryItems( queryItems );
                break;

        }
        String payload = String.format( MasteryAPIConstants.Mastery_Summary_BFF.REQ_PAYLOAD, subject_Id, isAdminCall, studentIds, queryItem );
        Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL, headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
        String errors = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
        String extensions = SMUtils.getKeyValueFromResponseWithArray( errors, "path" );

        Log.message( response.getBody().asString() );
        Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );
        if ( scenarioType.equalsIgnoreCase( "INVALID_USER_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( MasteryAPIConstants.Mastery_Summary_BFF.UNAUTHENTICATED ), "Getting Unauthorized message for Invalid authorization", "The Unauthorized message is not getting displayed for Invalid Authorization!" );
        } else if ( scenarioType.equalsIgnoreCase( "INVALID_ORG_ID" ) || scenarioType.contentEquals( "ACCESS_DENIED" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.equalsIgnoreCase( MasteryAPIConstants.Mastery_Summary_BFF.UNAUTHENTICATED ), "Getting Access Denied message for Invalid users / Irrespective org's",
                    "The Access Denied message is not getting displayed for Invalid users / Irrespective org's!" );

        } else if ( scenarioType.equalsIgnoreCase( "INVALID_SUBJECT_ID" ) ) {
            String error = SMUtils.getKeyValueFromResponseWithArray( response.getBody().asString(), "errors" );
            String message = getErrorMessage( error, "message" );
            Log.assertThat( message.contains( MasteryAPIConstants.Mastery_Summary_BFF.INVALID_SUBJECT_ID_MESSAGE ), "Getting Invalid value passed for subjectId error message for invalid subject Id",
                    "Not getting Invalid value passed for subjectId error message for invalid subject Id!" );
        }
    }

    @Test ( dataProvider = "getDataForAdminScenarios", groups = { "SMK-55707", "(Automation) (Graphql) Mastery summary data API", "Bff", "GraphQL" }, priority = 2 )

    public void postMasterySummaryDetailsTest003( String testcaseName, String expected_StatusCode, String testcaseDescription, String scenarioType ) throws Exception {
        String payload = null;
        int standardId;
        String assignmentIds;
        int contentBaseId;

        // headers
        Map<String, String> headers = new HashMap<String, String>();
        headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_Summary_BFF.CA_USER_NAME, MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );
        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
        headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, MasteryAPIConstants.Mastery_Summary_BFF.CA_ORG_ID );
        headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, MasteryAPIConstants.Mastery_Summary_BFF.CA_ID_VALUE );

        //Mandatory QueryItemList
        isAdminCall = Boolean.parseBoolean( MasteryAPIConstants.Mastery_Summary_BFF.ISADMINCALL_VALUE_ADMIN );
        subject_Id = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.MATH_SUBJECT_ID );

        //For Constructing QueryItems in request PayLoad
        List<String> queryItems = new ArrayList<String>();
        String queryItem = null;

        List<String> flatHierarchyQueryItems = new ArrayList<String>();
        String flatHierarchyQueryItem = null;

        List<String> leafFlatHierarchyQueryItems = new ArrayList<String>();
        String leafFlatHierarchyQueryItem = null;

        List<String> masteryMapQueryItems = new ArrayList<String>();
        String masteryMapQueryItem = null;

        Log.testCaseInfo( testcaseName + testcaseDescription );
        switch ( scenarioType ) {

            case "FOR_ADMIN_CALL":

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( MasteryAPIConstants.Mastery_Summary_BFF.CA_USER_NAME, MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, MasteryAPIConstants.Mastery_Summary_BFF.CA_ORG_ID );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, MasteryAPIConstants.Mastery_Summary_BFF.CA_ID_VALUE );

                //Mandatory QueryItemList
                isAdminCall = Boolean.parseBoolean( MasteryAPIConstants.Mastery_Summary_BFF.ISADMINCALL_VALUE_ADMIN );
                subject_Id = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.MATH_SUBJECT_ID );
                studentIds = MasteryAPIConstants.Mastery_Summary_BFF.EMPTY_STUDENT_ID;

               // studentIds.add("");
                String orgId = MasteryAPIConstants.Mastery_Summary_BFF.CA_ORG_ID;
                
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.FLAT_HIERARCHY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NAME );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.TIER_DEPTH );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_NAME );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PARENT_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.CHILD_NODES );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_NODE );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PRINT_PARTNER );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.EMPTY_NODE );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRADE_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.DISPLAY_ORDER );
                flatHierarchyQueryItem = constructQueryItems( flatHierarchyQueryItems );
                queryItems.add( flatHierarchyQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_FLAT_HIERARCHY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NAME );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.TIER_DEPTH );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_NAME );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PARENT_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.CHILD_NODES );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_NODE );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PRINT_PARTNER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.EMPTY_NODE );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRADE_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.DISPLAY_ORDER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LO_COURSE_LEVEL );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LO_CATALOG_NUMBER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.VIEW_LO_URL );
                leafFlatHierarchyQueryItem = constructQueryItems( leafFlatHierarchyQueryItems );
                queryItems.add( leafFlatHierarchyQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERED_COUNT );
                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NOT_MASTERED_COUNT );
                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.AT_RISK_COUNT );
                masteryMapQueryItem = constructQueryItems( masteryMapQueryItems );
                queryItems.add( masteryMapQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_IDS );
                queryItem = constructQueryItems( queryItems );
                payload = String.format( MasteryAPIConstants.Mastery_Summary_BFF.REQ_PAYLOAD_ADMIN, subject_Id, isAdminCall, orgId,studentIds, queryItem );

                break;

            case "FOR_ADMIN_CALL_WITH_FALSE_STATUS":

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId );

                //Mandatory QueryItemList
                isAdminCall = Boolean.parseBoolean( MasteryAPIConstants.Mastery_Summary_BFF.ISADMINCALL_VALUE_TEACHER );
                subject_Id = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.MATH_SUBJECT_ID );
                studentIds = MasteryAPIConstants.Mastery_Summary_BFF.STUDENT_USER_ID_VALUE;

                //studentIds.add( MasteryDataSetup.studentUserId1);
                
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.FLAT_HIERARCHY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NAME );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.TIER_DEPTH );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_NAME );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PARENT_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.CHILD_NODES );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_NODE );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PRINT_PARTNER );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.EMPTY_NODE );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRADE_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.DISPLAY_ORDER );
                flatHierarchyQueryItem = constructQueryItems( flatHierarchyQueryItems );
                queryItems.add( flatHierarchyQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_FLAT_HIERARCHY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NAME );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.TIER_DEPTH );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_NAME );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PARENT_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.CHILD_NODES );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_NODE );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PRINT_PARTNER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.EMPTY_NODE );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRADE_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.DISPLAY_ORDER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LO_COURSE_LEVEL );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LO_CATALOG_NUMBER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.VIEW_LO_URL );
                leafFlatHierarchyQueryItem = constructQueryItems( leafFlatHierarchyQueryItems );
                queryItems.add( leafFlatHierarchyQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERED_COUNT );
                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NOT_MASTERED_COUNT );
                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.AT_RISK_COUNT );
                masteryMapQueryItem = constructQueryItems( masteryMapQueryItems );
                queryItems.add( masteryMapQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_IDS );
                queryItem = constructQueryItems( queryItems );
                payload = String.format( MasteryAPIConstants.Mastery_Summary_BFF.REQ_PAYLOAD, subject_Id, isAdminCall, studentIds, queryItem );

                break;

            case "FOR_ADMIN_CALL_WITH_ALL_FIELDS":

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, MasteryAPIConstants.Mastery_Summary_BFF.PASSWORD ) );
                headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.ORGANIZATION_ID, organizationId );
                headers.put( MasteryAPIConstants.Mastery_Summary_BFF.USER_ID, teacherUserId );

                //Mandatory QueryItemList
                isAdminCall = Boolean.parseBoolean( MasteryAPIConstants.Mastery_Summary_BFF.ISADMINCALL_VALUE_TEACHER );
                subject_Id = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.MATH_SUBJECT_ID );
                studentIds = MasteryAPIConstants.Mastery_Summary_BFF.STUDENT_USER_ID_VALUE;

                //studentIds.add( MasteryDataSetup.studentUserId1);
                assignmentIds = MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_ID_VALUE;
                standardId = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.STANDARD_ID_VALUE );
                contentBaseId = Integer.parseInt( MasteryAPIConstants.Mastery_Summary_BFF.CONTENT_BASE_ID_VALUE );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.FLAT_HIERARCHY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NAME );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.TIER_DEPTH );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_NAME );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PARENT_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.CHILD_NODES );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_NODE );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PRINT_PARTNER );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.EMPTY_NODE );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRADE_ID );
                flatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.DISPLAY_ORDER );
                flatHierarchyQueryItem = constructQueryItems( flatHierarchyQueryItems );
                queryItems.add( flatHierarchyQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_FLAT_HIERARCHY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NAME );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.TIER_DEPTH );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_NAME );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRAND_PARENT_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PARENT_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.CHILD_NODES );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LEAF_NODE );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.PRINT_PARTNER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.EMPTY_NODE );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.GRADE_ID );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.DISPLAY_ORDER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LO_COURSE_LEVEL );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.LO_CATALOG_NUMBER );
                leafFlatHierarchyQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.VIEW_LO_URL );
                leafFlatHierarchyQueryItem = constructQueryItems( leafFlatHierarchyQueryItems );
                queryItems.add( leafFlatHierarchyQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERY_MAP );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ID );
                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MAP );

                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.MASTERED_COUNT );
                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.NOT_MASTERED_COUNT );
                masteryMapQueryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.AT_RISK_COUNT );
                masteryMapQueryItem = constructQueryItems( masteryMapQueryItems );
                queryItems.add( masteryMapQueryItem + "}" );

                queryItems.add( MasteryAPIConstants.Mastery_Summary_BFF.ASSIGNMENT_IDS );
                queryItem = constructQueryItems( queryItems );
                payload = String.format( MasteryAPIConstants.Mastery_Summary_BFF.REQ_PAYLOAD_ALL_FIELDS, subject_Id, isAdminCall, studentIds, standardId, assignmentIds, contentBaseId, queryItem );

                break;

        }

        Response response = RestAssuredAPIUtil.POSTGraphQl( MasteryConstants.Graphql.skillsandStandards.BASE_URL, headers, payload, MasteryConstants.Graphql.skillsandStandards.ENDPOINT );
        Log.message( response.getBody().asString() );
        Log.assertThat( 
				new SMAPIProcessor().isSchemaValid( "MasterySummaryBff", expected_StatusCode,
						response.getBody().asString() ),
				"Schema is returned as expected.", "Schema is not as expected." );
        
        if ( scenarioType.equals( "FOR_ADMIN_CALL_WITH_ALL_FIELDS" ) ) {
            Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                    "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );

        } else {
            Log.assertThat( response.getStatusCode() == Integer.parseInt( expected_StatusCode ), "The actual status code " + response.getStatusCode() + "is the same as expected status code " + expected_StatusCode,
                    "The actual status code " + response.getStatusCode() + "is not the same as expected status code " + expected_StatusCode );

        }
    }

    @DataProvider
    public Object[][] getDataForPostivieScenarios() {
        Object[][] data = { { "TC:01  ", "200", "Verify the graphql response is obtaining the predictable result for all set of Fields for Mastery Summary query", "ALL_QUERY_ITEMS" },
                { "TC:02  ", "200", "Verify the graphql response is obtaining the predictable result for single of Fields for Mastery Summary query", "SINGLE_QUERY_ITEMS" },
                { "TC:03  ", "200", "Verify the graphql response is obtaining the predictable result for multiple set of Fields for Mastery Summary query", "MULIPLE_QUERY_ITEMS" },
                { "TC:04  ", "200", "Verify the graphql response is obtaining the predictable result for Math Subject Id for Mastery Summary query", "MATH_SUBJECT_ID" },
                { "TC:05  ", "200", "Verify the graphql response is obtaining the predictable result for Reading Subject Id for Mastery Summary query", "READING_SUBJECT_ID" },

        };
        return data;
    }

    @DataProvider
    public Object[][] getDataForNegativeScenarios() {
        Object[][] data = { { "TC:07", "200", "Verify 403 status code and forbidden when invalid org-id is provided", "INVALID_ORG_ID" }, { "TC:08", "200", "Verify unauthorized message  when invalid user-id is provided", "INVALID_USER_ID" },
                { "TC:09", "200", "Verify access denied message when student-user-id is provided", "ACCESS_DENIED" }, { "TC:010", "200", "Verify invalid subject Id message when invalid subject-Id is provided", "INVALID_SUBJECT_ID" },
                { "TC:011", "400", "Verify bad request when invalid request payload is provided", "INVALID_PAYLOAD" },

        };
        return data;
    }

    @DataProvider
    public Object[][] getDataForAdminScenarios() {
        Object[][] data = { { "TC012 ", "200", "Verify the graphql response is obtaining the predictable result for all set of Fields for Mastery Summary query when admin call is set as TRUE", "FOR_ADMIN_CALL" },
                { "TC013 ", "200", "Verify the graphql response is obtaining the predictable result for all set of Fields for Mastery Summary query when admin call is set as False", "FOR_ADMIN_CALL_WITH_FALSE_STATUS" },
                { "TC: 014 ", "200", "Verify the graphql response is obtaining the predictable result for all set of Fields for Mastery Summary query when all the input parameters are given", "FOR_ADMIN_CALL_WITH_ALL_FIELDS" },
                };
        return data;
    }

    //This method is for constructing the query Items for payload
    public String constructQueryItems( List<String> queryItems ) {
        String frameQuery = "{";
        for ( String item : queryItems ) {
            if ( frameQuery.endsWith( "{" ) )
                frameQuery = frameQuery + item;
            else
                frameQuery = frameQuery + "," + item;
        }
        frameQuery = frameQuery + "}";
        return frameQuery;
    }

    //This method is extracting error message from response

    public String getErrorMessage( String jsonResponse, String message ) {
        String messageValue = "";
        try {
            JSONArray jsonArray = new JSONArray( jsonResponse );
            JSONObject jsonObject1 = jsonArray.getJSONObject( 0 );
            messageValue = jsonObject1.optString( message );

        } catch ( JSONException e ) {
            e.printStackTrace();
        }
        return messageValue;
    }

}
