package com.savvas.sm.api.pojo.mastery;

/**
 * This class is the POJO representation of Bff-Mastery Assignments GraphQL
 * response
 * 
 * @author madhan.nagarathinam
 *
 */
public class GetAssignmentsMasteryBff {

    // declare variables
    public String assignmentAssignerFirstName;

    public String assignmentAssignerLastName;

    public String assignmentId;

    public String assignmentName;

    public String subjectId;

    /**
     * Getter method for assignmentAssignerFirstName
     * 
     * @return assignmentAssignerFirstName
     */
    public String getAssignmentAssignerFirstName() {
        return assignmentAssignerFirstName;
    }

    /**
     * Getter method for assignmentAssignerLastName
     * 
     * @return assignmentAssignerLastName
     */
    public String getAssignmentAssignerLastName() {
        return assignmentAssignerLastName;
    }

    /**
     * Getter method for assignmentName
     * 
     * @return assignmentName
     */
    public String getAssignmentName() {
        return assignmentName;
    }

    /**
     * Getter method for assignmentId
     * 
     * @return assignmentId
     */
    public String getAssignmentId() {
        return assignmentId;
    }

    /**
     * Getter method for subjectId
     * 
     * @return subjectId
     */
    public String getSubjectId() {
        return subjectId;
    }

}
