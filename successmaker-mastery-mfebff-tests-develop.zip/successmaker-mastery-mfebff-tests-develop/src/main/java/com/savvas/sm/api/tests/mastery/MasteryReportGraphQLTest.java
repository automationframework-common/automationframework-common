package com.savvas.sm.api.tests.mastery;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;

import java.util.Optional;

import org.testng.annotations.BeforeClass;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;

import com.savvas.sm.data.RBSDataSetup;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.reports.api.report.constant.ReportAPIConstants;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants.Schools;
import com.savvas.sm.utils.rbs.RBSUtils;

import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;

public class MasteryReportGraphQLTest extends UserAPI {

    public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
    private String school = RBSDataSetup.getSchools( Schools.MATH_SCHOOL );
    String teacherDetails;
    String studentDetails;
    String orgId;
    String teacherId;
    String studentId;
    String MATH_SUBJECT_ID = "1";
    String READING_SUBJECT_ID = "2";
    String INVALID_SUBJECT_ID = "3";

    String userId;
    String smUrl;
    Boolean isAdminCall;
    String studentIds;
    int subject_Id;
    String userName;
    String organizationId;
    String teacherUserId;

   
    @BeforeClass ( alwaysRun = true )
    public void BeforeTest() {
        userName = MasteryDataSetup.teacherUserName;
        organizationId = MasteryDataSetup.orgId;
        teacherUserId = MasteryDataSetup.teacherUserId;
        studentIds = MasteryDataSetup.studentUserId1;
    }

    @Test ( dataProvider = "getData", groups = { "SMK-59117 GraphQL API for Mastery report", "smoke_test_case", "P1", "API" }, priority = 1 )
    public void testMasteryRepostAPI( String testcaseName, String statusCode, String testcaseDescription, String scenarioType ) throws Exception {
        HashMap<String, String> headers = new HashMap<>();

        Log.testCaseInfo( testcaseName + testcaseDescription );

        headers.put( Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE );

        String payload;

        Response response = null;
        String responseStatusCode = "";
        switch ( scenarioType ) {

            case "VALID_TEACHER_IDS":

                payload = getMasteryReportDataRequestPayLoad( organizationId, teacherUserId );
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, ReportAPIConstants.PASSWORD ) );
                headers.put( ReportAPIConstants.ORG_IDs, organizationId );
                headers.put( ReportAPIConstants.USER_IDs, teacherUserId );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "VALID_SUBJECT":

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, ReportAPIConstants.PASSWORD ) );
                headers.put( ReportAPIConstants.ORG_IDs, organizationId );
                headers.put( ReportAPIConstants.USER_IDs, teacherUserId );
                payload = getMasteryReportDataRequestPayLoad( organizationId, teacherUserId, ReportAPIConstants.VALID_MATH_SUBJECT_ID );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "VALID_LIMIT":

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, ReportAPIConstants.PASSWORD ) );
                headers.put( ReportAPIConstants.ORG_IDs, organizationId );
                headers.put( ReportAPIConstants.USER_IDs, teacherUserId );
                payload = getMasteryReportDataLimitRequestPayLoad( organizationId, teacherUserId, ReportAPIConstants.LIMITS );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "VALID_OFFSET":

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, ReportAPIConstants.PASSWORD ) );
                headers.put( ReportAPIConstants.ORG_IDs, organizationId );
                headers.put( ReportAPIConstants.USER_IDs, teacherUserId );
                payload = getMasteryReportDataOffsetRequestPayLoad( organizationId, teacherUserId, ReportAPIConstants.OFFSETS );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "VALID_rbs":

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, ReportAPIConstants.PASSWORD ) );
                headers.put( ReportAPIConstants.ORG_IDs, organizationId );
                headers.put( ReportAPIConstants.USER_IDs, teacherUserId );
                payload = getMasteryReportDataRequestPayLoad( organizationId, teacherUserId, ReportAPIConstants.RBSFLAG );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "VALID_STUDENT_IDS":

                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, ReportAPIConstants.PASSWORD ) );
                headers.put( ReportAPIConstants.ORG_IDs, organizationId );
                headers.put( ReportAPIConstants.USER_IDs, teacherUserId );
                payload = getMasteryReportDataStudentRequestPayLoad( organizationId, teacherUserId, studentIds );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

            case "VALID_IS_GROUP_SELECTED":
                headers.put( Constants.AUTHORIZATION, Constants.BEARER + new RBSUtils().getAccessToken( userName, ReportAPIConstants.PASSWORD ) );
                headers.put( ReportAPIConstants.ORG_IDs, organizationId );
                headers.put( ReportAPIConstants.USER_IDs, teacherUserId );
                payload = getMasteryReportDataIsGroupSelectedRequestPayLoad( organizationId, teacherUserId, studentIds, ReportAPIConstants.IS_GROUP_SELECTED_VALUE );
                response = RestAssuredAPIUtil.POSTGraphQl( ReportAPIConstants.GRAPG_QL_BASE_URL, headers, payload, ReportAPIConstants.GRAPH_QL_ENDPOINT );
                responseStatusCode = Optional.ofNullable( response ).isPresent() ? String.valueOf( response.getStatusCode() ) : ReportAPIConstants.NO_RESPONSE_CODE;
                break;

        }
        Log.message( Optional.ofNullable( response ).isPresent() ? response.getBody().asString() : "No Response Found" );
        // Validation
        System.out.println( "Printing the response body : " + response.getBody().asString() );
        String data= SMUtils.getKeyValueFromResponse( response.getBody().asString(), "data" );
        Log.assertThat( SMUtils.getKeyValueFromResponse( data, "getMasteryReportData" ).contains( "masteryReportResponse" ), "Response is Validated", "Failed to validate Response" );
        
        Log.assertThat( responseStatusCode.equals( statusCode ), "The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
                "The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified" );
        if ( responseStatusCode.equals( statusCode ) ) {
            Log.pass( "Test Passed." );
        } else {
            Log.fail( "Test Failed. Check the steps above in red color." );
        }
        Log.endTestCase();
    }

    @DataProvider
    public Object[][] getData() {
        return new Object[][] { { "TC001", "200", "Verify the status code 200 for response body for providing only correct teacherIds in request body", "VALID_TEACHER_IDS" },
                { "TC002", "200", "Verify the status code 200 for response body for providing only correct subjectID in request body", "VALID_SUBJECT" },
                { "TC003", "200", "Verify the status code 200 for response body for providing only Valid limit in request body", "VALID_LIMIT" },
                { "TC004", "200", "Verify the status code 200 for response body for providing only Valid offset in request body", "VALID_OFFSET" },
                { "TC005", "200", "Verify the status code 200 for response body for providing only Valid rbs in request body", "VALID_rbs" },
                { "TC006", "200", "Verify the status code 200 for response body for providing only Valid studentsIDs in request body", "VALID_STUDENT_IDS" },
                { "TC007", "200", "Verify the status code 200 for response body for providing Is Group seleceted in request body", "VALID_IS_GROUP_SELECTED" }, };
    }

    public String getMasteryReportDataRequestPayLoad( String organizationID, String teacherID ) {

        return "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getMasteryReportData(\\n    id: \\\"" + teacherID + "\\\"\\n    organizationId: \\\"" + organizationID
                + "\\\"\\n  ) {\\n    masteryReportResponse {\\n      totalNoOfRows\\n      teacherInfo {\\n        id\\n        title\\n        firstName\\n        lastName\\n        userName\\n      }\\n      organizationName\\n      rows {\\n        districtId\\n        firstName\\n        lastName\\n        userName\\n        grade\\n        assignedCourseLevel\\n        currentCourseLevel\\n        ipLevel\\n        masteryStatus\\n        timeSpent\\n        assignmentUserId\\n        personId\\n        assignmentId\\n        assignmentTitle\\n        assignmentOwnerId\\n        contentBaseTypeName\\n        asmtAssignerId\\n        ipmEndLevel\\n        ipmStatusName\\n        totalSessionMin\\n        sessionPresentedCount\\n        avgSessionTime\\n        bankId\\n        pearsonSkillObjectiveId\\n        masteryStatusName\\n        masteryStatusId\\n        judgements\\n        totalAttempts\\n        standardVersionId\\n        stateText\\n        groupName\\n        student_name\\n      }\\n    }\\n  }\\n}\\n\"}";
    }

    public String getMasteryReportDataRequestPayLoad( String organizationID, String teacherID, float subjectID ) {

        return "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getMasteryReportData(\\n    id: \\\"" + teacherID + "\\\"\\n    organizationId: \\\"" + organizationID + "\\\"\\n    subject: " + subjectID
                + "\\n  ) {\\n    masteryReportResponse {\\n      totalNoOfRows\\n      teacherInfo {\\n        id\\n        title\\n        firstName\\n        lastName\\n        userName\\n      }\\n      organizationName\\n      rows {\\n        districtId\\n        firstName\\n        lastName\\n        userName\\n        grade\\n        assignedCourseLevel\\n        currentCourseLevel\\n        ipLevel\\n        masteryStatus\\n        timeSpent\\n        assignmentUserId\\n        personId\\n        assignmentId\\n        assignmentTitle\\n        assignmentOwnerId\\n        contentBaseTypeName\\n        asmtAssignerId\\n        ipmEndLevel\\n        ipmStatusName\\n        totalSessionMin\\n        sessionPresentedCount\\n        avgSessionTime\\n        bankId\\n        pearsonSkillObjectiveId\\n        masteryStatusName\\n        masteryStatusId\\n        judgements\\n        totalAttempts\\n        standardVersionId\\n        stateText\\n        groupName\\n        student_name\\n      }\\n    }\\n  }\\n}\\n\"}";
    }

    public String getMasteryReportDataLimitRequestPayLoad( String organizationID, String teacherID, float limit ) {

        return "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getMasteryReportData(\\n    id: \\\"" + teacherID + "\\\"\\n    organizationId: \\\"" + organizationID + "\\\"\\n    limit: " + limit
                + "\\n  ) {\\n    masteryReportResponse {\\n      totalNoOfRows\\n      teacherInfo {\\n        id\\n        title\\n        firstName\\n        lastName\\n        userName\\n      }\\n      organizationName\\n      rows {\\n        districtId\\n        firstName\\n        lastName\\n        userName\\n        grade\\n        assignedCourseLevel\\n        currentCourseLevel\\n        ipLevel\\n        masteryStatus\\n        timeSpent\\n        assignmentUserId\\n        personId\\n        assignmentId\\n        assignmentTitle\\n        assignmentOwnerId\\n        contentBaseTypeName\\n        asmtAssignerId\\n        ipmEndLevel\\n        ipmStatusName\\n        totalSessionMin\\n        sessionPresentedCount\\n        avgSessionTime\\n        bankId\\n        pearsonSkillObjectiveId\\n        masteryStatusName\\n        masteryStatusId\\n        judgements\\n        totalAttempts\\n        standardVersionId\\n        stateText\\n        groupName\\n        student_name\\n      }\\n    }\\n  }\\n}\\n\"}";
    }

    public String getMasteryReportDataOffsetRequestPayLoad( String organizationID, String teacherID, float offSet ) {

        return "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getMasteryReportData(\\n    id: \\\"" + teacherID + "\\\"\\n    organizationId: \\\"" + organizationID + "\\\"\\n    offset: " + offSet
                + "\\n  ) {\\n    masteryReportResponse {\\n      totalNoOfRows\\n      teacherInfo {\\n        id\\n        title\\n        firstName\\n        lastName\\n        userName\\n      }\\n      organizationName\\n      rows {\\n        districtId\\n        firstName\\n        lastName\\n        userName\\n        grade\\n        assignedCourseLevel\\n        currentCourseLevel\\n        ipLevel\\n        masteryStatus\\n        timeSpent\\n        assignmentUserId\\n        personId\\n        assignmentId\\n        assignmentTitle\\n        assignmentOwnerId\\n        contentBaseTypeName\\n        asmtAssignerId\\n        ipmEndLevel\\n        ipmStatusName\\n        totalSessionMin\\n        sessionPresentedCount\\n        avgSessionTime\\n        bankId\\n        pearsonSkillObjectiveId\\n        masteryStatusName\\n        masteryStatusId\\n        judgements\\n        totalAttempts\\n        standardVersionId\\n        stateText\\n        groupName\\n        student_name\\n      }\\n    }\\n  }\\n}\\n\"}";
    }

    public String getMasteryReportDataRequestPayLoad( String organizationID, String teacherID, boolean rbsValue ) {

        return "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getMasteryReportData(\\n    id: \\\"" + teacherID + "\\\"\\n    organizationId: \\\"" + organizationID + "\\\"\\n    rbs: " + rbsValue
                + "\\n  ) {\\n    masteryReportResponse {\\n      totalNoOfRows\\n      teacherInfo {\\n        id\\n        title\\n        firstName\\n        lastName\\n        userName\\n      }\\n      organizationName\\n      rows {\\n        districtId\\n        firstName\\n        lastName\\n        userName\\n        grade\\n        assignedCourseLevel\\n        currentCourseLevel\\n        ipLevel\\n        masteryStatus\\n        timeSpent\\n        assignmentUserId\\n        personId\\n        assignmentId\\n        assignmentTitle\\n        assignmentOwnerId\\n        contentBaseTypeName\\n        asmtAssignerId\\n        ipmEndLevel\\n        ipmStatusName\\n        totalSessionMin\\n        sessionPresentedCount\\n        avgSessionTime\\n        bankId\\n        pearsonSkillObjectiveId\\n        masteryStatusName\\n        masteryStatusId\\n        judgements\\n        totalAttempts\\n        standardVersionId\\n        stateText\\n        groupName\\n        student_name\\n      }\\n    }\\n  }\\n}\\n\"}";
    }

    public String getMasteryReportDataStudentRequestPayLoad( String organizationID, String teacherID, String studentID ) {

        return "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getMasteryReportData(\\n    id: \\\"" + teacherID + "\\\"\\n    organizationId: \\\"" + organizationID + "\\\"\\n    studentIds: [\\\"" + studentID
                + "\\\"]\\n  ) {\\n    masteryReportResponse {\\n      totalNoOfRows\\n      teacherInfo {\\n        id\\n        title\\n        firstName\\n        lastName\\n        userName\\n      }\\n      organizationName\\n      rows {\\n        districtId\\n        firstName\\n        lastName\\n        userName\\n        grade\\n        assignedCourseLevel\\n        currentCourseLevel\\n        ipLevel\\n        masteryStatus\\n        timeSpent\\n        assignmentUserId\\n        personId\\n        assignmentId\\n        assignmentTitle\\n        assignmentOwnerId\\n        contentBaseTypeName\\n        asmtAssignerId\\n        ipmEndLevel\\n        ipmStatusName\\n        totalSessionMin\\n        sessionPresentedCount\\n        avgSessionTime\\n        bankId\\n        pearsonSkillObjectiveId\\n        masteryStatusName\\n        masteryStatusId\\n        judgements\\n        totalAttempts\\n        standardVersionId\\n        stateText\\n        groupName\\n        student_name\\n      }\\n    }\\n  }\\n}\\n\"}";
    }

    public String getMasteryReportDataIsGroupSelectedRequestPayLoad( String organizationID, String teacherID, String studentID, boolean isGroupSelected ) {

        return "{\"operationName\":null,\"variables\":{},\"query\":\"{\\n  getMasteryReportData(\\n    id: \\\"" + teacherID + "\\\"\\n    organizationId: \\\"" + organizationID + "\\\"\\n    studentIds: [\\\"" + studentID + "\\\"]\\n    isGroupSelected: "
                + isGroupSelected
                + "\\n  ) {\\n    masteryReportResponse {\\n      totalNoOfRows\\n      teacherInfo {\\n        id\\n        title\\n        firstName\\n        lastName\\n        userName\\n      }\\n      organizationName\\n      rows {\\n        districtId\\n        firstName\\n        lastName\\n        userName\\n        grade\\n        assignedCourseLevel\\n        currentCourseLevel\\n        ipLevel\\n        masteryStatus\\n        timeSpent\\n        assignmentUserId\\n        personId\\n        assignmentId\\n        assignmentTitle\\n        assignmentOwnerId\\n        contentBaseTypeName\\n        asmtAssignerId\\n        ipmEndLevel\\n        ipmStatusName\\n        totalSessionMin\\n        sessionPresentedCount\\n        avgSessionTime\\n        bankId\\n        pearsonSkillObjectiveId\\n        masteryStatusName\\n        masteryStatusId\\n        judgements\\n        totalAttempts\\n        standardVersionId\\n        stateText\\n        groupName\\n        student_name\\n      }\\n    }\\n  }\\n}\\n\"}";
    }

}
