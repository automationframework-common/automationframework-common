package com.savvas.sm.ui.tests.mastery;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasteryMfePage;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;

public class MasteryMFEPageTest extends BaseTest {
    private String masteryTeacherMfe;
    private String browser;

    @BeforeClass
    public void initTest( ITestContext context ) {
        masteryTeacherMfe = configProperty.getProperty( "MasteryTeacherMfe" );
        browser = configProperty.getProperty( "BrowserPlatformToRun" );
    }

    @Test ( priority = 1, groups = { "SMK-51587", "mastery_mfe", "P1", "UI", "Teacher_Mastery_MFE_Page" } )
    public void tcMasteryMfePageTest( ITestContext context ) throws Exception {

        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "MasteryMFE Home Page Test" + "<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            // TC_1
            SMUtils.logDescriptionTC( "1. Verify the BFF is getting re-directed to the next-basic instance 3Sixty id" );
            // login to Mastery mfe as Teacher
            LoginWrapper.loginToMasteryMfe( driver, masteryTeacherMfe, MasteryDataSetup.teacherUserName, RBSDataSetupConstants.DEFAULT_PASSWORD );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver );
            MasteryFiltersComponent masteryFilterComponent = masteryMfePage.getMasteryFilterComponent();
            Log.assertThat( masteryMfePage.isMasteryStep2HeadingDisplayed(), "Mastery MFE Page is loaded successfully without any issues", "Mastery MFE Page is not getting loaded successfully!" );

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

}
