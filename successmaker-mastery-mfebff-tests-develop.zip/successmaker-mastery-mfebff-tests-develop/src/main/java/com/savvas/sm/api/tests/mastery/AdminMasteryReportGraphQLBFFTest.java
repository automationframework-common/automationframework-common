package com.savvas.sm.api.tests.mastery;

import java.util.HashMap;

import java.util.Optional;

import org.testng.annotations.BeforeClass;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

import com.learningservices.utils.EnvironmentPropertiesReader;
import com.learningservices.utils.Log;
import com.savvas.sm.common.utils.apiconstants.MasteryAPIConstants;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.RestAssuredAPIUtil;
import com.savvas.sm.utils.SMAPIProcessor;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.rbs.RBSUtils;

import com.savvas.sm.utils.sme187.teacher.api.users.UserAPI;
import com.savvas.sm.utils.sme187.teacher.api.users.UserConstants;
import com.savvas.sm.utils.sql.helper.SqlHelperCourses;

public class AdminMasteryReportGraphQLBFFTest extends UserAPI {

	public static EnvironmentPropertiesReader configProperty = EnvironmentPropertiesReader.getInstance();
	String studentDetails;
	String orgId;
	String studentId;
	String userId;
	String smUrl;
	String studentIds;
	String studentIds1;
	String userName;
	String organizationId;
	String teacherUserId;
	String adminDetails;
	String districtOrgId;
	String districtAdminUserId;
	String stdId;
	HashMap<String, String> mathGradeStandardDetails;
	HashMap<String, String> readingGradeStandardDetails;

	@BeforeClass(alwaysRun = true)
	public void BeforeTest() {

		smUrl = MasteryConstants.Graphql.skillsandStandards.REPORT_URL
				+ MasteryConstants.Graphql.skillsandStandards.ENDPOINT;
		userName = MasteryDataSetup.districtAdminUserName;
		adminDetails = MasteryDataSetup.districtAdminDetails;
		districtOrgId = configProperty.getProperty(ConfigConstants.DISTRICT_ID);
		districtAdminUserId = MasteryDataSetup.districtAdminUserId;
		organizationId = MasteryDataSetup.orgId;
		studentIds = MasteryDataSetup.studentUserId1;
		
			}

	@Test(dataProvider = "getData", groups = { "Admin Mastery GraphQL Test ", "smoke_test_case", "P1",
			"API" }, priority = 1)
	public void testAdminMasteryRepostAPI(String testcaseName, String statusCode, String testcaseDescription,
			String scenarioType) throws Exception {

		Log.testCaseInfo(testcaseName + testcaseDescription);
		HashMap<String, String> headers = new HashMap<>();
		headers.put( Constants.AUTHORIZATION,Constants.BEARER+ new RBSUtils().getAccessToken(userName,
								MasteryAPIConstants.Mastery_GraphQL_Assignments.PASSWORD ));
		headers.put(Constants.ACCEPT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(Constants.CONTENT_TYPE, Constants.JSON_CONTENT_TYPE);
		headers.put(UserConstants.USERID, districtAdminUserId);
		System.out.println(districtAdminUserId);
		headers.put(UserConstants.ORGID, districtOrgId);
		System.out.println(districtOrgId);
		System.out.println(userName);

		Response response = null;
		String responseStatusCode = "";
		switch (scenarioType) {

		case "MATH_SUBJECT":
			response = testMasteryRepostAPI(smUrl, headers, "1", organizationId, "");
			responseStatusCode = String.valueOf( response.getStatusCode());
			break;

		case "READING_SUBJECT":
			response = testMasteryRepostAPI(smUrl, headers, "2", organizationId, "");
			responseStatusCode = String.valueOf( response.getStatusCode());
			break;

		case "SKILLS_MATH":
			response = testMasteryRepostAPI(smUrl, headers, "1", organizationId, "");
			responseStatusCode = String.valueOf( response.getStatusCode());
			break;

		case "SKILL_READING":
			response = testMasteryRepostAPI(smUrl, headers, "2", organizationId, "");
			responseStatusCode = String.valueOf( response.getStatusCode());
			break;

		case "VALID-ORG_ID":
			response = testMasteryRepostAPI(smUrl, headers, "1", organizationId, "");
			responseStatusCode = String.valueOf( response.getStatusCode());
			break;

		}
		Log.message(Optional.ofNullable(response).isPresent() ? response.getBody().asString() : "No Response Found");
		// Validation			
		Log.assertThat(responseStatusCode.equals(statusCode),
				"The Status code is expected " + statusCode + " and actual " + responseStatusCode + " Verified",
				"The Status code is expected " + statusCode + " and actual " + responseStatusCode + "is not Verified");
		if (responseStatusCode.equals(statusCode)) {
			Log.pass("Test Passed.");
		} else {
			Log.fail("Test Failed. Check the steps above in red color.");
		}
			Log.endTestCase();
	}

	@DataProvider
	public Object[][] getData() {
		return new Object[][] {
				{ "TC001", "200", "Verify the status code 200 for response body for Skill defaut math course",
						"MATH_SUBJECT" },
				{ "TC002", "200", "Verify the status code 200 for response body for Skill defaut readng course",
						"READING_SUBJECT" },
				{ "TC003", "200", "Verify the status code 200 for response body for Standard default math",
						"SKILLS_MATH" },
				{ "TC004", "200", "Verify the status code 200 for response body for Standard default reading",
						"SKILL_READING" },
				{ "TC005", "200", "Verify the status code 200 for response body for providing only Valid org Id",
						"VALID-ORG_ID" }, };

	}

	public Response testMasteryRepostAPI(String Smurl, HashMap<String, String> header, String subId, String orgId,
			String stdId) throws Exception {

		String payload = "{\r\n" + "\r\n" + "    \"operationName\": \"GetAdminMasteryReportData\",\r\n" + "\r\n"
				+ "    \"variables\": {\r\n" + "\r\n" + "        \"subjectId\": {subID},\r\n" + "\r\n"
				+ "        \"organizationId\": \"{ordId}\",\r\n" + "\r\n" + "        \"standardId\": \"{stdID}\"\r\n"
				+ "\r\n" + "    },\r\n" + "\r\n"
				+ "    \"query\": \"query GetAdminMasteryReportData($organizationId: String!, $subjectId: Int!, $standardId: String!, $courseId: String) {\\n  getAdminMasteryReportData(\\n    organizationId: $organizationId\\n    subject: $subjectId\\n    standardId: $standardId\\n    courseId: $courseId\\n  ) {\\n    masteryReportResponse {\\n      studentId\\n      studentName\\n      courseId\\n      courseName\\n      ipmStatusName\\n      contentBaseTypeName\\n      assignedCourseLevel\\n      currentCourseLevel\\n      ipLevel\\n      timeSpent\\n      totalSessions\\n      AverageSessionTime\\n      grade\\n      masteryData {\\n        skillStandardName\\n        masteryStatus\\n        noOfSkillsCompleted\\n        noOfAttempts\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\"\r\n"
				+ "\r\n" + "}";
		payload = payload.replace("{subID}", subId);
		payload = payload.replace("{ordId}", orgId);
		payload = payload.replace("{stdID}", stdId);
	    Response getResponse = RestAssuredAPIUtil.POSTGraphQl(smUrl, header, payload,"");
		return getResponse;
	}
}
