package com.savvas.sm.mastery.ui.teacher.exportpdf.tests;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.learningservices.utils.Log;
import com.learningservices.utils.WebDriverFactory;
import com.savvas.sm.basetests.BaseTest;
import com.savvas.sm.common.utils.ui.constants.MasteryConstants.Graphql.MasteryExportPDFConstants;
import com.savvas.sm.ui.mastery.pages.MasteryFiltersComponent;
import com.savvas.sm.ui.mastery.pages.MasteryMfePage;
import com.savvas.sm.ui.mastery.pages.MasteryReportOutputPage;
import com.savvas.sm.ui.pages.login.LoginWrapper;
import com.savvas.sm.utils.Constants;
import com.savvas.sm.utils.SMUtils;
import com.savvas.sm.utils.constants.ConfigConstants;
import com.savvas.sm.utils.constants.RBSDataSetupConstants;
import com.savvas.sm.masterydatasetup.MasteryDataSetup;

public class TeacherExportPDFMasteryTest extends BaseTest {
    private String masteryMfeUrl;
    private String browser;
    private String mfeTeacherUName;
    private String password = RBSDataSetupConstants.DEFAULT_PASSWORD;

    @BeforeClass ( alwaysRun = true )
    public void init( ITestContext context ) throws Exception {

        mfeTeacherUName = MasteryDataSetup.teacherUserName;
        browser = configProperty.getProperty( ConfigConstants.BROWSER_PLATFORM_TO_RUN );
        masteryMfeUrl = configProperty.getProperty( "MasteryTeacherMfe" );

    }

    @Test ( description = "Verify 'Export PDF' button at the top of the report output screen", groups = { "SMK-32783", "Mastery Reports", "Export Reports", "smoke_test_case" }, priority = 1 )
    public void tcMasteryExportReport001() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcMasteryExportReport001: Verify 'Export PDF' button at the top of the report output screen <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToMasteryMfe( driver, masteryMfeUrl, mfeTeacherUName, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver );
            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            // To select the subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            // To select the Skills
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.SKILL_MATH );

            // To Click the apply filter button
            masteryFiltersComponent.applyFilter();

            // To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFiltersComponent.clickRunReport();

            SMUtils.logDescriptionTC( "Verify 'Export PDF' button at the top of the report output screen" );
            Log.assertThat( masteryReportOutput.validatePDFIcon(), "PDF icon is displaying", "PDF icon is not displaying" );
            Log.assertThat( masteryReportOutput.getPDFText().equalsIgnoreCase( MasteryExportPDFConstants.PDF_TEXT ), "PDF text is displaying", "PDF text is not displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the user is taken to ' Export Report PDF' Model after clicking the 'Export PDF' button", groups = { "SMK-32784/SMK-32785/SMK-32786", "Mastery Reports", "Export Reports", "smoke_test_case" }, priority = 2 )
    public void tcMasteryExportReport002() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcMasteryExportReport002:Verify the user is taken to ' Export Report PDF' Model after clicking the 'Export PDF' button <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToMasteryMfe( driver, masteryMfeUrl, mfeTeacherUName, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver );
            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            // To select the subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            // To select the Skills
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.SKILL_MATH );

            // To Click the apply filter button
            masteryFiltersComponent.applyFilter();

            // To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFiltersComponent.clickRunReport();

            SMUtils.logDescriptionTC( "Verify the user is taken to ' Export Report PDF' Model after clicking the 'Export PDF' button" );
            SMUtils.logDescriptionTC( "Verify the title and subtitle names are displayed as below " );
            masteryReportOutput.clickOnPDF();
            Log.assertThat( masteryReportOutput.validateExportPDFPopUPText().equalsIgnoreCase( MasteryExportPDFConstants.PDF_POP_TEXT ), "Pop up header text is displaying", "Pop up header text is not displaying" );
            Log.assertThat( masteryReportOutput.validatePageText().equalsIgnoreCase( MasteryExportPDFConstants.PAGES_TEXT ), "All Pages text is displaying", "All pages text is displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify All Page(s) and current page of two radio button options are displayed below subheader and All Page(s) option radio button is selected as default" );
            Log.assertThat( masteryReportOutput.validateCurrentPageText().equalsIgnoreCase( MasteryExportPDFConstants.CURRENT_PAGE_TEXT ), "Current page text is displaying", "Current page text is displaying" );
            Log.assertThat( masteryReportOutput.validateAllPageText().equalsIgnoreCase( MasteryExportPDFConstants.ALL_PSGES_TEXT ), "All Pages text is displaying", "All Pages text is displaying" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify Cancel and Close button(X) button is displayed in the 'Export PDF File' model ", groups = { "SMK-32787/SMK-32788", "Mastery Reports", "Export Reports", "smoke_test_case" }, priority = 3 )
    public void tcMasteryExportReport003() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcMasteryExportReport003:Verify Cancel and Close button(X) button is displayed in the 'Export PDF File' model <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToMasteryMfe( driver, masteryMfeUrl, mfeTeacherUName, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver );
            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            // To select the subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            // To select the Skills
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.SKILL_MATH );

            // To Click the apply filter button
            masteryFiltersComponent.applyFilter();

            // To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFiltersComponent.clickRunReport();

            // PDF validation
            masteryReportOutput.clickOnPDF();
            SMUtils.logDescriptionTC( "Verify Cancel and Close button(X) button is displayed in the 'Export PDF File' model " );
            Log.assertThat( masteryReportOutput.validateCancelButton().equalsIgnoreCase( MasteryExportPDFConstants.CANCEL_TEXT ), "Cance button text is displaying", "Cance button text is not displaying" );
            Log.assertThat( masteryReportOutput.isCrossIconDisplayed(), "Cross icon is displaying", "Cross icon is not displaying" );
            Log.testCaseResult();
            masteryReportOutput.clickCancelButton();
            masteryReportOutput.verifyReportPage( driver );
            Log.testCaseResult();

            masteryReportOutput.clickOnPDF();
            masteryReportOutput.clickCrossIcon();
            masteryReportOutput.verifyReportPage( driver );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the user is taken to 'Exporting PDF File' model after clicking the 'OK' button in 'Export Report PDF'", groups = { "SMK-32789/SMK-32791/SMK-32792", "Mastery Reports", "Export Reports", "smoke_test_case" }, priority = 4 )
    public void tcMasteryExportReport004() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcMasteryExportReport004:Verify the user is taken to 'Exporting PDF File' model after clicking the 'OK' button in 'Export Report PDF'<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToMasteryMfe( driver, masteryMfeUrl, mfeTeacherUName, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver );
            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            // To select the subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            // To select the Skills
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.SKILL_MATH );

            // To Click the apply filter button
            masteryFiltersComponent.applyFilter();

            // To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFiltersComponent.clickRunReport();

            // PDF validation
            masteryReportOutput.clickOnPDF();
            SMUtils.logDescriptionTC( "Verify the user is taken to 'Exporting PDF File' model after clicking the 'OK' button in 'Export Report PDF'" );
            masteryReportOutput.clickOkButton();
            Log.assertThat( masteryReportOutput.validateExportPDFPopUPTextForSucces().equalsIgnoreCase( MasteryExportPDFConstants.POP_UP_PDF_FILE ), "Export pdf file text is displaying", "Export pdf file text is displaying" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verifiy following content is displayed in the body of the 'Exporting PDF file' model" );
            Log.assertThat( masteryReportOutput.getSuccessMessage().contains( MasteryExportPDFConstants.DOWNLOADING_TEXT ), "Getting downloading text properly", "Not Getting downloading text properly" );
            Log.testCaseResult();
            SMUtils.logDescriptionTC( "Verifiy following content is displayed in the body of the 'Exporting PDF file' model" );
            Log.assertThat( masteryReportOutput.getSuccessMessage().contains( MasteryExportPDFConstants.DOWNLOADING_TEXT_SECOND ), "Getting downloading text properly", "Not Getting downloading text properly" );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify spinner is showing PDF generation is in-progress and close button on the 'Exporting PDF file' model is disabled", groups = { "SMK-32790", "Mastery Reports", "Export Reports", "smoke_test_case" }, priority = 5 )
    public void tcMasteryExportReport005() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcMasteryExportReport005:Verify spinner is showing PDF generation is in-progress and close button on the 'Exporting PDF file' model is disabled<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToMasteryMfe( driver, masteryMfeUrl, mfeTeacherUName, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver );
            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            // To select the subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            // To select the Skills
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.SKILL_MATH );

            // To Click the apply filter button
            masteryFiltersComponent.applyFilter();

            // To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFiltersComponent.clickRunReport();

            // PDF validation
            masteryReportOutput.clickOnPDF();
            SMUtils.logDescriptionTC( "Verify the user is taken to 'Exporting PDF File' model after clicking the 'OK' button in 'Export Report PDF'" );
            masteryReportOutput.clickOkButton();
            masteryReportOutput.clickCloseButton();
            SMUtils.logDescriptionTC( "Verify spinner is showing PDF generation is in-progress and close button  'Exporting PDF file' model is disabled" );
            if ( !masteryReportOutput.verifyCloseButtonEnableOrDisable() ) {
                Log.message( "Close button is showing as disabled mode while downloading the pdf" );
            } else {
                Log.message( "Close button is showing as enabled mode" );
            }
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }
    }

    @Test ( description = "Verify spinner is showing PDF generation is in-progress and CrossButton X on the 'Exporting PDF file' model is disabled", groups = { "SMK-32790/SMK-32791", "Mastery Reports", "Export Reports", "smoke_test_case" }, priority = 6 )
    public void tcMasteryExportReport006() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcMasteryExportReport006:Verify spinner is showing PDF generation is in-progress and CrossButton X on the 'Exporting PDF file' model is disabled<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToMasteryMfe( driver, masteryMfeUrl, mfeTeacherUName, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver );
            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            // To select the subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            // To select the Skills
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.SKILL_MATH );

            // To Click the apply filter button
            masteryFiltersComponent.applyFilter();

            // To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFiltersComponent.clickRunReport();

            // PDF validation
            masteryReportOutput.clickOnPDF();
            SMUtils.logDescriptionTC( "Verify the user is taken to 'Exporting PDF File' model after clicking the 'OK' button in 'Export Report PDF'" );
            masteryReportOutput.clickOkButton();
            masteryReportOutput.clickCrossButton();
            SMUtils.logDescriptionTC( "Verify spinner is showing PDF generation is in-progress and close button  'Exporting PDF file' model is disabled" );
            if ( !masteryReportOutput.isCrossButtonDisable() ) {
                Log.message( "Close button is showing as disabled mode while downloading the pdf" );
            } else {
                Log.message( "Close button is showing as enabled mode" );
            }

            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify 'Close' button and Close(X) button back to active and user is able to close the model by clicking either Close button or from the close (X)", groups = { "SMK-32793", "Mastery Reports", "Export Reports",
            "smoke_test_case" }, priority = 7 )
    public void tcMasteryExportReport007() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcMasteryExportReport007:Verify 'Close' button and Close(X) button back to active and user is able to close the model by clicking either Close button or from the close (X)<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToMasteryMfe( driver, masteryMfeUrl, mfeTeacherUName, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver );
            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            // To select the subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            // To select the Skills
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.SKILL_MATH );

            // To Click the apply filter button
            masteryFiltersComponent.applyFilter();

            // To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFiltersComponent.clickRunReport();

            // PDF validation
            masteryReportOutput.clickOnPDF();
            masteryReportOutput.clickOkButton();
            SMUtils.logDescriptionTC( "Verifiy following content is displayed in the body of the 'Exporting PDF file' model after report is successfully rendered" );
            SMUtils.nap( 8 );
            Log.assertThat( masteryReportOutput.getSuccessMessage().contains( MasteryExportPDFConstants.SUCCESS_TEXT ), "Getting Success text properly", "Not Getting success text properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verifiy following content is displayed in the body of the 'Exporting PDF file' model after report is successfully rendered" );
            Log.assertThat( masteryReportOutput.getSuccessMessage().contains( MasteryExportPDFConstants.SUCCESS_TEXT_SECOND ), "Getting success text properly", "Not Getting success text properly" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "Verify 'Close' button and Close(X) button back to active and user is able to close the model by clicking either Close button or from the close (X)" );
            Log.assertThat( masteryReportOutput.verifyCloseButtonEnableOrDisable(), "Close button is disable", "Close button is not disable" );
            Log.testCaseResult();

            SMUtils.logDescriptionTC( "User can able to click on close button" );
            masteryReportOutput.clickCloseButton();
            masteryReportOutput.verifyReportPage( driver );
            Log.testCaseResult();

        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify the user is taking to 'Exporting PDF file' model and browser started downloading the PDF and the pdf downloaded properly", groups = { "SMK-32792/SMK-32794", "Mastery Reports", "Export Reports",
            "smoke_test_case" }, priority = 1 )
    public void tcMasteryExportReport008() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );
        Log.testCaseInfo( "tcMasteryExportReport008:Verify the user is taking to 'Exporting PDF file' model and browser started downloading the PDF and the pdf downloaded properly<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToMasteryMfe( driver, masteryMfeUrl, mfeTeacherUName, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver );
            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            // To select the subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            // To select the Skills
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.SKILL_MATH );

            // To Click the apply filter button
            masteryFiltersComponent.applyFilter();

            // To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFiltersComponent.clickRunReport();

            masteryReportOutput.clickOnPDF();

            masteryReportOutput.clickOkButton();
            SMUtils.logDescriptionTC( "Verify the user is taking to 'Exporting PDF file' model and browser started downloading the PDF and the pdf downloaded properly" );
            Log.assertThat( masteryReportOutput.isPDFFileDownloaded( driver ), "The export pdf file is downloaded properly", "The export pdf file is not downloaded properly" );
            SMUtils.logDescriptionTC( "Verify file is downloaded in default download folder and File name should be in correct format" );
            Log.assertThat( masteryReportOutput.getPdfFileNameFromBS( driver ).contains( MasteryExportPDFConstants.MASTERY_EXPORT_FILENAME ), "The exported pdf contain '" + MasteryExportPDFConstants.MASTERY_EXPORT_FILENAME + "' in the file name",
                    "The exported pdf does not contain '" + MasteryExportPDFConstants.MASTERY_EXPORT_FILENAME + "' in the file name" );
            SMUtils.logDescriptionTC( "Verify file is downloaded with valid file size" );
            Log.assertThat( masteryReportOutput.getPdfFileSizeFromBS( driver ) > 0, "The exported pdf file has proper file size.", "The exported pdf not having proper file size ." );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify user able to downlod the PDF report by selecting 'Current Page' and the pdf downloaded properly", groups = { "SMK-32802/SMK-32792", "Mastery Reports", "Export Reports", "smoke_test_case" }, priority = 1 )
    public void tcMasteryExportReport009() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcMasteryExportReport009:Verify user able to downlod the PDF report by selecting 'Current Page' <small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToMasteryMfe( driver, masteryMfeUrl, mfeTeacherUName, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver );
            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            // To select the subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            // To select the Skills
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.SKILL_MATH );

            // To Click the apply filter button
            masteryFiltersComponent.applyFilter();

            // To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFiltersComponent.clickRunReport();

            masteryReportOutput.clickOnPDF();
            SMUtils.logDescriptionTC( "Verify user able to downlod the PDF report by selecting 'Current Page'  and the pdf downloaded properly" );
            masteryReportOutput.clickCurrentPageRadioButton();
            masteryReportOutput.clickOkButton();
            SMUtils.logDescriptionTC( "Verify the user is taking to 'Exporting PDF file' model and browser started downloading the PDF and the pdf downloaded properly" );
            Log.assertThat( masteryReportOutput.isPDFFileDownloaded( driver ), "The export pdf file is downloaded properly", "The export pdf file is not downloaded properly" );
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

    @Test ( description = "Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher Mastery", groups = { "SMK-69993/SMK-68622", "Mastery Reports", "Export Reports", "smoke_test_case" }, priority = 1 )
    public void tcMasteryExportReport010() throws Exception {
        // Get driver
        final WebDriver driver = WebDriverFactory.get( browser );

        Log.testCaseInfo( "tcMasteryExportReport010:Verify CSV/PDF options should disable , when report viewer page throws Something went wrong for teacher Mastery<small><b><i>[" + browser + "]</b></i></small>" );
        try {
            LoginWrapper.loginToMasteryMfe( driver, masteryMfeUrl, mfeTeacherUName, password );
            MasteryMfePage masteryMfePage = new MasteryMfePage( driver );
            MasteryFiltersComponent masteryFiltersComponent = masteryMfePage.getMasteryFilterComponent();

            // To select the subject
            masteryFiltersComponent.selectSubject( Constants.MasteryUI.SUBJECT_MATH );

            // To select the Skills
            masteryFiltersComponent.selectSkillStandards( Constants.MasteryUI.SKILL_MATH );

            // To Click the apply filter button
            masteryFiltersComponent.applyFilter();

            // To click the run report button
            MasteryReportOutputPage masteryReportOutput = masteryFiltersComponent.clickRunReport();

            masteryReportOutput.launchURLWithWrongRequestID();
            Log.message( masteryReportOutput.getPDFButtonDisabled() );
            Log.assertThat( masteryReportOutput.getPDFButtonDisabled().contains( MasteryExportPDFConstants.DISABLED_STATUS ), "PDF button is showing disable mode when error message pops up", "PDF button is not showing disable mode when error message pops up" );
            Log.testCaseResult();
            Log.testCaseResult();
        } catch ( Exception e ) {
            Log.exception( e, driver );
        } finally {
            Log.endTestCase();
            driver.quit();
        }

    }

}
